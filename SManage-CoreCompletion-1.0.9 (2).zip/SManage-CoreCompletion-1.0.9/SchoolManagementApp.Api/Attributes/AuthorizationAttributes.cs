using Microsoft.AspNetCore.Mvc.Filters;
using System.Security.Claims;
// Ambiguity guard: two IPermissionService interfaces exist (legacy ApplicationCore.Interfaces.*
// and the real ApplicationCore.Permissions.*). Only the real one is registered in DI.
using IPermissionService = SchoolManagementApp.ApplicationCore.Permissions.Interfaces.IPermissionService;

namespace SchoolManagementApp.Api.Attributes
{
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method)]
    public class RequirePermissionAttribute : Attribute, IAsyncAuthorizationFilter
    {
        private readonly Permission _permission;
        private readonly bool _requireRead;
        private readonly bool _requireWrite;
        private readonly bool _requireDelete;

        public RequirePermissionAttribute(Permission permission, bool requireRead = true, bool requireWrite = false, bool requireDelete = false)
        {
            _permission = permission;
            _requireRead = requireRead;
            _requireWrite = requireWrite;
            _requireDelete = requireDelete;
        }

        public async Task OnAuthorizationAsync(AuthorizationFilterContext context)
        {
            var user = context.HttpContext.User;
            if (user == null || !user.Identity?.IsAuthenticated == true)
            {
                context.Result = new UnauthorizedResult();
                return;
            }

            // SuperAdmin bypass - check roles in token first
            var roles = user.FindAll(ClaimTypes.Role).Concat(user.FindAll("role")).Select(c => c.Value);
            if (roles.Any(r => string.Equals(r, "SuperAdmin", StringComparison.OrdinalIgnoreCase)))
            {
                return; // Allow access
            }

            var permissionService = context.HttpContext.RequestServices.GetService<IPermissionService>();
            if (permissionService == null)
            {
                context.Result = new UnauthorizedResult();
                return;
            }

            var userIdClaim = user.FindFirst(ClaimTypes.NameIdentifier) ?? user.FindFirst("sub") ?? user.FindFirst("id");
            if (userIdClaim == null || !int.TryParse(userIdClaim.Value, out int userId))
            {
                context.Result = new UnauthorizedResult();
                return;
            }

            bool hasAccess = true;

            if (_requireRead)
            {
                hasAccess &= await permissionService.CanReadAsync(userId, _permission);
            }

            if (_requireWrite)
            {
                hasAccess &= await permissionService.CanWriteAsync(userId, _permission);
            }

            if (_requireDelete)
            {
                hasAccess &= await permissionService.CanDeleteAsync(userId, _permission);
            }

            if (!hasAccess)
            {
                context.Result = new ForbidResult();
            }
        }
    }

    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method)]
    public class RequireRoleAttribute : Attribute, IAuthorizationFilter
    {
        private readonly UserRole[] _requiredRoles;

        public RequireRoleAttribute(params UserRole[] requiredRoles)
        {
            _requiredRoles = requiredRoles;
        }

        public void OnAuthorization(AuthorizationFilterContext context)
        {
            var userRoleClaim = context.HttpContext.User.FindFirst(ClaimTypes.Role);
            if (userRoleClaim == null)
            {
                context.Result = new UnauthorizedResult();
                return;
            }

            if (Enum.TryParse<UserRole>(userRoleClaim.Value, out var userRole))
            {
                if (!_requiredRoles.Contains(userRole))
                {
                    context.Result = new ForbidResult();
                }
            }
            else
            {
                context.Result = new UnauthorizedResult();
            }
        }
    }
}