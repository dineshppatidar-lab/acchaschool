// Global using directives for SchoolManagementApp.Api
// These namespaces are used frequently across the project

global using System;
global using System.Collections.Generic;
global using System.Linq;
global using System.Threading.Tasks;

global using Microsoft.AspNetCore.Authorization;
global using Microsoft.AspNetCore.RateLimiting;
global using Microsoft.AspNetCore.Mvc;
global using Microsoft.EntityFrameworkCore;
global using Microsoft.Extensions.Logging;

global using SchoolManagementApp.ApplicationCore.Entities;
global using SchoolManagementApp.ApplicationCore._Entities;
global using SchoolManagementApp.ApplicationCore.Interfaces;
global using SchoolManagementApp.ApplicationCore._Interfaces;
global using SchoolManagementApp.ApplicationCore.Common.Enums;
global using SchoolManagementApp.ApplicationCore.Common.Models;
global using SchoolManagementApp.ApplicationCore.Fees.Dtos;
global using SchoolManagementApp.ApplicationCore.Setup.Dtos;
global using SchoolManagementApp.ApplicationCore.Students.Dtos;
global using SchoolManagementApp.ApplicationCore.Payroll.Dtos;
global using SchoolManagementApp.ApplicationCore.Authentication.Dtos;

global using SchoolManagementApp.Api.Common;
global using SchoolManagementApp.Api.Attributes;
global using SchoolManagementApp.Api.Services;
global using SchoolManagementApp.Infrastructure.Data;
