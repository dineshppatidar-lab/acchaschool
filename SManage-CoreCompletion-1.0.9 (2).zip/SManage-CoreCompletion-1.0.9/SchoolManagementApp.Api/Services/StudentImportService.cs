using ClosedXML.Excel;
using SchoolManagementApp.ApplicationCore.Entities;
using Microsoft.EntityFrameworkCore;
using System.Text.RegularExpressions;

namespace SchoolManagementApp.Api.Services
{
    /// <summary>
    /// Excel-based bulk student admission import.
    /// - Builds a downloadable template (.xlsx) with an Instructions sheet and a
    ///   data sheet containing the required columns plus example rows.
    /// - Parses uploaded workbooks, validates every row against the SAME rules the
    ///   admission API enforces (StudentManagementService.ValidateStudentDto) plus
    ///   DB-mandatory fields on the Student entity, resolves lookups (Academic Year /
    ///   Class / Section names to IDs) and upserts students.
    /// - Returns a per-row result so the UI can show exactly what succeeded/failed.
    /// </summary>
    public class StudentImportService
    {
        private readonly ApplicationDbContext _context;
        private readonly ILogger<StudentImportService> _logger;

        /// <summary>Required and optional template columns (header row).</summary>
        public static readonly string[] TemplateColumns = new[]
        {
            "Admission Number*",     // ScholarNumber — optional if left blank → auto-generated
            "Roll Number*",          // mandatory per admission-API validation (RollNumber)
            "First Name*",
            "Last Name*",
            "Date of Birth* (yyyy-mm-dd)",
            "Gender* (Male/Female/Other)",
            "Class* (e.g. Class 5 / 10A)",
            "Section (e.g. A / B)",  // optional — falls back to the class's first section (admission-API parity)
            "Academic Year* (e.g. 2024-25)",
            "Contact Number* (10+ digits)",
            "Email*",
            "Address",
            "Admission Date (yyyy-mm-dd)",
            "Parent First Name",
            "Parent Last Name",
            "Parent Phone",
            "Parent Email",
            "Parent Occupation",
            "Category (General/OBC/SC/ST)",
            "Religion"
        };

        // ── Normalized header keys (matched after stripping *, hints and whitespace) ──
        private const string ColAdmissionNumber = "admissionnumber";
        private const string ColRollNumber = "rollnumber";
        private const string ColFirstName = "firstname";
        private const string ColLastName = "lastname";
        private const string ColDob = "dateofbirth";
        private const string ColGender = "gender";
        private const string ColClass = "class";
        private const string ColSection = "section";
        private const string ColAcademicYear = "academicyear";
        private const string ColContactNumber = "contactnumber";
        private const string ColEmail = "email";
        private const string ColAddress = "address";
        private const string ColAdmissionDate = "admissiondate";
        private const string ColParentFirstName = "parentfirstname";
        private const string ColParentLastName = "parentlastname";
        private const string ColParentPhone = "parentphone";
        private const string ColParentEmail = "parentemail";
        private const string ColParentOccupation = "parentoccupation";
        private const string ColCategory = "category";
        private const string ColReligion = "religion";

        public StudentImportService(
            ApplicationDbContext context,
            ILogger<StudentImportService> logger)
        {
            _context = context;
            _logger = logger;
        }

        /// <summary>Normalizes a template header to a stable column key: strips the
        /// mandatory marker, parenthesized hints and whitespace, lowercases.</summary>
        public static string NormalizeHeader(string header)
        {
            var noHint = Regex.Replace(header ?? string.Empty, @"\(.*?\)", string.Empty);
            var noStar = noHint.Replace("*", string.Empty);
            return Regex.Replace(noStar, @"\s+", string.Empty).Trim().ToLowerInvariant();
        }

        /// <summary>
        /// Generates the admission import template workbook with an Instructions
        /// sheet, two example rows, a 'Lookups' sheet bound to THIS tenant's real
        /// Academic Years / Classes / Sections (IDs + names, current session first),
        /// and data-validation dropdowns fed from that sheet — so users can pick
        /// values that are guaranteed to exist in the database at import time.
        /// </summary>
        public async Task<byte[]> GenerateTemplateAsync(int tenantId)
        {
            // ── Load tenant-scoped lookup data (same source the import validates against) ──
            var years = await _context.AcademicYears
                .Where(y => y.TenantId == tenantId)
                .OrderByDescending(y => y.IsCurrent)
                .ThenByDescending(y => y.StartDate)
                .Select(y => new { y.Id, y.Name, y.IsCurrent, y.IsActive })
                .ToListAsync();

            var classes = await _context.Classes
                .Where(c => c.TenantId == tenantId)
                .OrderBy(c => c.AcademicYearId).ThenBy(c => c.Id)
                .Select(c => new { c.Id, c.Name, c.AcademicYearId })
                .ToListAsync();

            var sections = await _context.Sections
                .Where(s => s.TenantId == tenantId)
                .OrderBy(s => s.ClassId).ThenBy(s => s.Id)
                .Select(s => new { s.Id, s.Name, s.ClassId })
                .ToListAsync();

            var yearNameById = years.ToDictionary(y => y.Id, y => y.Name);
            var classNameById = classes.ToDictionary(c => c.Id, c => c.Name);

            // The CURRENT academic session (IsCurrent flag, else first row of the ordered list).
            var currentYear = years.FirstOrDefault(y => y.IsCurrent) ?? years.FirstOrDefault();
            var currentYearName = currentYear?.Name ?? string.Empty;

            using var workbook = new XLWorkbook();

            // ── Instructions sheet ──
            var instructions = workbook.Worksheets.Add("Instructions");
            instructions.Cell(1, 1).Value = "Student Admission Import – Instructions";
            instructions.Cell(1, 1).Style.Font.SetBold().Font.SetFontSize(14);
            var notes = new List<string>
            {
                "1. Fill ONLY the 'Students' sheet. Do not rename or delete sheets.",
                "2. Columns marked with * are REQUIRED – leave nothing blank in these:",
                "   Roll Number*, First Name*, Last Name*, Date of Birth*, Gender*, Class*, Academic Year*, Contact Number*, Email*.",
                "   Optional: Admission Number (blank = auto-generated), Section, Address, Admission Date, Parent details, Category, Religion.",
                "3. Dates must use format yyyy-mm-dd (e.g. 2012-05-14).",
                "4. Gender must be exactly one of: Male, Female, Other (dropdown provided).",
                "5. Contact Number must be at least 10 characters (digits).",
                "6. Email must be a valid email address (e.g. name@example.com).",
                $"7. Academic Year MUST match a value from the 'Lookups' sheet (dropdown provided). The CURRENT session configured in your database is: {currentYearName}.",
                "8. Class MUST match a class name that exists for the chosen Academic Year (dropdown provided from the Lookups sheet).",
                "9. Section is OPTIONAL – leave blank to use the class's first section. If filled, it must match a section of that class (dropdown provided).",
                "10. Category must be one of: General, OBC, SC, ST (dropdown provided).",
                "11. Admission Date is optional – defaults to today when blank on new students.",
                "12. Parent details are optional; if provided, the parent record is created/reused by phone+email.",
                "13. Re-uploading the same Admission Number UPDATES that student instead of duplicating.",
                "14. Save the file as .xlsx and upload it back in this screen.",
                "",
                "The 'Lookups' sheet lists the IDs and names currently configured in YOUR school's database",
                "(Setup → Session / Classes / Sections). Values not listed there will be rejected at import."
            };
            for (int i = 0; i < notes.Count; i++)
            {
                instructions.Cell(3 + i, 1).Value = notes[i];
            }
            instructions.Column(1).AdjustToContents();
            instructions.Protect();

            // ── Lookups sheet: DB-bound reference data (IDs + names) ──
            var lk = workbook.Worksheets.Add("Lookups");
            string[] lkHeaders = { "Academic Year ID", "Academic Year", "Current?", "Class ID", "Class", "Class's Academic Year", "Section ID", "Section", "Section's Class" };
            for (int c = 0; c < lkHeaders.Length; c++)
            {
                var h = lk.Cell(1, c + 1);
                h.Value = lkHeaders[c];
                h.Style.Font.SetBold();
                h.Style.Fill.BackgroundColor = XLColor.FromHtml("#2E7D32");
                h.Style.Font.FontColor = XLColor.White;
            }
            int lr = 2;
            int maxRows = new[] { years.Count, classes.Count, sections.Count }.Max();
            for (int i = 0; i < maxRows; i++)
            {
                if (i < years.Count)
                {
                    lk.Cell(lr, 1).Value = years[i].Id;
                    lk.Cell(lr, 2).Value = years[i].Name;
                    lk.Cell(lr, 3).Value = years[i].IsCurrent ? "YES – current session" : (years[i].IsActive ? "Active" : "Inactive");
                }
                if (i < classes.Count)
                {
                    lk.Cell(lr, 4).Value = classes[i].Id;
                    lk.Cell(lr, 5).Value = classes[i].Name;
                    lk.Cell(lr, 6).Value = yearNameById.TryGetValue(classes[i].AcademicYearId, out var yn) ? yn : string.Empty;
                }
                if (i < sections.Count)
                {
                    lk.Cell(lr, 7).Value = sections[i].Id;
                    lk.Cell(lr, 8).Value = sections[i].Name;
                    lk.Cell(lr, 9).Value = classNameById.TryGetValue(sections[i].ClassId, out var cn) ? cn : string.Empty;
                }
                lr++;
            }
            if (maxRows == 0)
            {
                lk.Cell(2, 1).Value = "(No academic years configured yet – add them in Setup → Session first)";
            }
            lk.SheetView.FreezeRows(1);
            lk.Columns().AdjustToContents();

            // ── Students sheet ──
            var ws = workbook.Worksheets.Add("Students");
            for (int c = 0; c < TemplateColumns.Length; c++)
            {
                var header = ws.Cell(1, c + 1);
                header.Value = TemplateColumns[c];
                header.Style.Font.SetBold();
                header.Style.Fill.BackgroundColor = XLColor.FromHtml("#1565C0");
                header.Style.Font.FontColor = XLColor.White;
            }
            ws.Row(1).Height = 22;
            ws.SheetView.FreezeRows(1);

            // Two example rows the user can overwrite (year pre-filled with the CURRENT session)
            ws.Cell(2, 2).Value = "1";
            ws.Cell(2, 3).Value = "Aarav";
            ws.Cell(2, 4).Value = "Sharma";
            ws.Cell(2, 5).Value = "2012-05-14";
            ws.Cell(2, 6).Value = "Male";
            ws.Cell(2, 7).Value = classes.Count > 0 ? classes[0].Name : "Class 5";
            ws.Cell(2, 8).Value = "A";
            ws.Cell(2, 9).Value = string.IsNullOrEmpty(currentYearName) ? "2024-25" : currentYearName;
            ws.Cell(2, 10).Value = "9876543210";
            ws.Cell(2, 11).Value = "aarav.parent@example.com";

            ws.Cell(3, 2).Value = "2";
            ws.Cell(3, 3).Value = "Diya";
            ws.Cell(3, 4).Value = "Patel";
            ws.Cell(3, 5).Value = "2011-11-02";
            ws.Cell(3, 6).Value = "Female";
            ws.Cell(3, 7).Value = classes.Count > 1 ? classes[1].Name : "Class 6";
            ws.Cell(3, 9).Value = string.IsNullOrEmpty(currentYearName) ? "2024-25" : currentYearName;

            // ── Dropdown validations (rows 2-500) ──
            int ColOf(string key) => Array.FindIndex(TemplateColumns, c => NormalizeHeader(c) == key) + 1;

            // Gender / Category: fixed inline lists
            AddListValidation(ws, ColOf(ColGender), "Male,Female,Other", "Invalid Gender", "Gender must be Male, Female or Other.");
            AddListValidation(ws, ColOf(ColCategory), "General,OBC,SC,ST", "Invalid Category", "Category must be General, OBC, SC or ST.");

            // Academic Year / Class / Section: fed from the Lookups sheet (DB-bound).
            int lkYearCol = 2;  // Lookups!B – year names
            int lkClassCol = 5; // Lookups!E – class names
            int lkSectionCol = 8; // Lookups!H – section names
            int lkLast = Math.Max(2, lr - 1);

            var yearDv = ws.Range(2, ColOf(ColAcademicYear), 500, ColOf(ColAcademicYear)).CreateDataValidation();
            yearDv.AllowedValues = XLAllowedValues.List;
            yearDv.List($"Lookups!$B$2:$B${lkLast}", true);
            yearDv.ErrorTitle = "Invalid Academic Year";
            yearDv.ErrorMessage = "Pick an Academic Year from the dropdown (see the Lookups sheet) – it must exist in your school's Setup → Session.";

            var classDv = ws.Range(2, ColOf(ColClass), 500, ColOf(ColClass)).CreateDataValidation();
            classDv.AllowedValues = XLAllowedValues.List;
            classDv.List($"Lookups!$E$2:$E${lkLast}", true);
            classDv.ErrorTitle = "Invalid Class";
            classDv.ErrorMessage = "Pick a Class from the dropdown (see the Lookups sheet) – it must exist for the chosen Academic Year.";

            var sectionDv = ws.Range(2, ColOf(ColSection), 500, ColOf(ColSection)).CreateDataValidation();
            sectionDv.AllowedValues = XLAllowedValues.List;
            sectionDv.List($"Lookups!$H$2:$H${lkLast}", true);
            sectionDv.ErrorTitle = "Invalid Section";
            sectionDv.ErrorMessage = "Pick a Section from the dropdown (see the Lookups sheet) – it must belong to the chosen Class.";

            ws.Columns().AdjustToContents();

            using var ms = new MemoryStream();
            workbook.SaveAs(ms);
            return ms.ToArray();
        }

        private static void AddListValidation(IXLWorksheet ws, int column, string list, string errorTitle, string errorMessage)
        {
            if (column <= 0) return;
            var dv = ws.Range(2, column, 500, column).CreateDataValidation();
            dv.AllowedValues = XLAllowedValues.List;
            dv.List(list);
            dv.ErrorTitle = errorTitle;
            dv.ErrorMessage = errorMessage;
        }

        /// <summary>
        /// Parses an uploaded workbook and imports students row by row.
        /// Never throws for data issues – problems are reported per row.
        /// A 'Students' sheet is expected; a helpful error is returned otherwise.
        /// </summary>
        public async Task<StudentImportResult> ImportAsync(Stream excelStream, int tenantId, string importedBy)
        {
            var result = new StudentImportResult();
            int tenant = tenantId;

            using var workbook = new XLWorkbook(excelStream);
            var ws = workbook.Worksheet("Students")
                      ?? workbook.Worksheet(1);
            if (ws == null)
            {
                result.GlobalErrors.Add("The uploaded file does not contain a 'Students' sheet.");
                return result;
            }

            var headerRow = ws.FirstRowUsed();
            if (headerRow == null || headerRow.RowNumber() != 1)
            {
                result.GlobalErrors.Add("The 'Students' sheet must have its header in row 1 (use the downloaded template).");
                return result;
            }

            // ── Map headers to column indexes (order-independent) ──
            var map = new Dictionary<string, int>();
            int lastCol = headerRow.LastCellUsed().Address.ColumnNumber;
            for (int c = 1; c <= lastCol; c++)
            {
                var key = NormalizeHeader(headerRow.Cell(c).GetString());
                if (!string.IsNullOrEmpty(key))
                {
                    map[key] = c; // last wins on duplicates
                }
            }

            string[] required = { ColFirstName, ColLastName, ColDob, ColGender, ColClass, ColAcademicYear, ColContactNumber, ColEmail };
            string[] aliases = { ColAdmissionNumber, ColRollNumber, ColSection, ColAddress, ColAdmissionDate, ColParentFirstName, ColParentLastName, ColParentPhone, ColParentEmail, ColParentOccupation, ColCategory, ColReligion };

            foreach (var req in required)
            {
                if (!map.ContainsKey(req))
                {
                    var original = TemplateColumns.First(c => NormalizeHeader(c) == req);
                    result.GlobalErrors.Add($"Missing required column: '{original}'. Please upload the latest template without renaming columns.");
                }
            }
            foreach (var alias in aliases.Where(a => !map.ContainsKey(a)))
            {
                var original = TemplateColumns.First(c => NormalizeHeader(c) == alias);
                _logger.LogWarning("Student import: optional column '{Column}' missing from uploaded template", original);
            }
            if (result.GlobalErrors.Count > 0) return result;

            int? GetCol(string key) => map.TryGetValue(key, out var idx) ? idx : (int?)null;

            // ── Load lookup caches (tenant-scoped) ──
            var years = await _context.AcademicYears
                .Where(y => y.TenantId == tenant)
                .ToDictionaryAsync(y => y.Name.Trim().ToLowerInvariant(), y => y.Id);
            var classes = await _context.Classes
                .Where(c => c.TenantId == tenant)
                .GroupBy(c => c.AcademicYearId)
                .ToDictionaryAsync(g => g.Key, g => g.ToDictionary(
                    c => c.Name.Trim().ToLowerInvariant(), c => c.Id));
            var sections = await _context.Sections
                .Where(s => s.TenantId == tenant)
                .GroupBy(s => s.ClassId)
                .ToDictionaryAsync(g => g.Key, g => g.ToDictionary(
                    s => s.Name.Trim().ToLowerInvariant(), s => s.Id));
            var sectionOrder = await _context.Sections
                .Where(s => s.TenantId == tenant)
                .GroupBy(s => s.ClassId)
                .ToDictionaryAsync(g => g.Key, g => g.OrderBy(s => s.Id).Select(s => s.Id).ToList());

            var existingByScholar = await _context.Students
                .IgnoreQueryFilters()
                .Where(s => s.TenantId == tenant)
                .ToDictionaryAsync(s => s.ScholarNumber.Trim(), s => s, StringComparer.OrdinalIgnoreCase);

            var parentsByPhoneEmail = await _context.Parents
                .Where(p => p.TenantId == tenant)
                .ToListAsync();
            var parentLookup = parentsByPhoneEmail
                .GroupBy(p => (p.PhoneNumber?.Trim().ToLowerInvariant() ?? "", p.Email?.Trim().ToLowerInvariant() ?? ""))
                .ToDictionary(g => g.Key, g => g.First());

            var seenAdmissionNumbers = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

            int rowNumber = headerRow.RowNumber() + 1;
            var lastRow = ws.LastRowUsed();
            if (lastRow == null || lastRow.RowNumber() < rowNumber)
            {
                result.GlobalErrors.Add("No data rows found – please fill the template and try again.");
                return result;
            }

            for (int r = rowNumber; r <= lastRow.RowNumber(); r++)
            {
                var row = ws.Row(r);
                string Cell(string key)
                {
                    var idx = GetCol(key);
                    return idx == null ? string.Empty : row.Cell(idx.Value).GetString().Trim();
                }

                // Skip fully empty rows (any known column carrying a value counts)
                bool anyValue = map.Values.Any(idx => row.Cell(idx).GetString().Trim().Length > 0);
                if (!anyValue) continue;

                var errors = new List<string>();

                var firstName = Cell(ColFirstName);
                var lastName = Cell(ColLastName);
                var gender = Cell(ColGender);
                var className = Cell(ColClass);
                var sectionName = Cell(ColSection);
                var yearName = Cell(ColAcademicYear);
                var dobText = Cell(ColDob);
                var contactNumber = Cell(ColContactNumber);
                var email = Cell(ColEmail);
                var admissionNumber = Cell(ColAdmissionNumber);
                var rollNumber = Cell(ColRollNumber);

                // ── Validation parity with the admission API (ValidateStudentDto) ──
                if (string.IsNullOrWhiteSpace(firstName)) errors.Add("First Name is required");
                if (string.IsNullOrWhiteSpace(lastName)) errors.Add("Last Name is required");

                if (!DateTime.TryParse(dobText, out var dob))
                {
                    errors.Add($"Date of Birth '{dobText}' is not a valid date (use yyyy-mm-dd)");
                }
                else
                {
                    if (dob > DateTime.UtcNow.Date) errors.Add("Date of Birth cannot be in the future");
                    if (dob > DateTime.UtcNow.AddYears(-3)) errors.Add("Student must be at least 3 years old");
                }

                var allowedGenders = new[] { "male", "female", "other" };
                if (string.IsNullOrWhiteSpace(gender))
                    errors.Add("Gender is required");
                else if (!allowedGenders.Contains(gender.ToLowerInvariant()))
                    errors.Add($"Gender '{gender}' must be Male, Female or Other");

                if (string.IsNullOrWhiteSpace(contactNumber))
                    errors.Add("Contact Number is required");
                else if (contactNumber.Length < 10)
                    errors.Add($"Contact Number must be at least 10 digits (got {contactNumber.Length})");

                if (string.IsNullOrWhiteSpace(email))
                    errors.Add("Email is required");
                else if (!IsValidEmail(email))
                    errors.Add($"Email '{email}' is not a valid email address");

                if (string.IsNullOrWhiteSpace(rollNumber))
                    errors.Add("Roll Number is required (mandatory on the admission form)");

                // Resolve Academic Year
                int yearId = 0;
                if (!years.TryGetValue(yearName.ToLowerInvariant(), out yearId) || yearId == 0)
                    errors.Add($"Academic Year '{yearName}' not found – add it in Setup → Session first");

                // Resolve Class within the resolved year
                int classId = 0;
                if (yearId > 0 && classes.TryGetValue(yearId, out var yearClasses))
                {
                    if (!yearClasses.TryGetValue(className.ToLowerInvariant(), out classId) || classId == 0)
                        errors.Add($"Class '{className}' not found for Academic Year '{yearName}' – create it in Setup → Classes first");
                }
                else if (yearId > 0)
                {
                    errors.Add($"Class '{className}' not found for Academic Year '{yearName}' – create it in Setup → Classes first");
                }

                // Resolve Section within the resolved class — optional, falls back to the
                // class's first section (admission-API parity; the API auto-creates "A").
                int sectionId = 0;
                if (classId > 0)
                {
                    if (!string.IsNullOrWhiteSpace(sectionName))
                    {
                        if (!sections.TryGetValue(classId, out var classSections) ||
                            !classSections.TryGetValue(sectionName.ToLowerInvariant(), out sectionId) ||
                            sectionId == 0)
                            errors.Add($"Section '{sectionName}' not found for class '{className}' – create it in Setup → Sections first");
                    }
                    else if (sectionOrder.TryGetValue(classId, out var ordered) && ordered.Count > 0)
                    {
                        sectionId = ordered[0];
                    }
                    else
                    {
                        errors.Add($"Class '{className}' has no sections yet – create one in Setup → Sections (or pass a Section name)");
                    }
                }

                // ── In-file duplicate detection (same admission number twice) ──
                if (!string.IsNullOrWhiteSpace(admissionNumber) && !seenAdmissionNumbers.Add(admissionNumber))
                {
                    errors.Add($"Duplicate Admission Number '{admissionNumber}' appears more than once in this file");
                }

                if (errors.Count > 0)
                {
                    result.FailedRows.Add(new StudentImportRowError
                    {
                        RowNumber = r,
                        StudentName = $"{firstName} {lastName}".Trim(),
                        Errors = errors
                    });
                    continue;
                }

                // ── Upsert by Admission Number (ScholarNumber) ──
                Student? student = null;
                if (!string.IsNullOrWhiteSpace(admissionNumber) &&
                    existingByScholar.TryGetValue(admissionNumber, out var found))
                {
                    student = found; // update existing record
                }

                bool isNew = student == null;
                student ??= new Student
                {
                    TenantId = tenant,
                    ScholarNumber = string.IsNullOrWhiteSpace(admissionNumber)
                        ? await GenerateAdmissionNumberAsync(tenant)
                        : admissionNumber,
                    IsActive = true,
                    Status = "Active",
                    EnrollmentStatus = "Active",
                    CreatedBy = importedBy
                };

                student.FirstName = firstName;
                student.LastName = lastName;
                student.DateOfBirth = dob;
                student.Gender = char.ToUpperInvariant(gender[0]) + gender[1..].ToLowerInvariant();
                student.ClassId = classId;
                student.SectionId = sectionId;
                student.AcademicYearId = yearId;
                student.RollNumber = rollNumber;
                student.ContactNumber = contactNumber;
                student.Email = email;
                student.Address = Cell(ColAddress);
                student.CasteCategory = NullIfEmpty(Cell(ColCategory));
                student.Religion = NullIfEmpty(Cell(ColReligion));

                if (DateTime.TryParse(Cell(ColAdmissionDate), out var admissionDate))
                    student.AdmissionDate = admissionDate;
                else if (isNew)
                    student.AdmissionDate = DateTime.UtcNow.Date;

                // ── Parent: create or reuse by phone+email ──
                var pFirst = Cell(ColParentFirstName);
                var pPhone = Cell(ColParentPhone);
                var pEmail = Cell(ColParentEmail);
                if (!string.IsNullOrWhiteSpace(pFirst))
                {
                    if (!string.IsNullOrWhiteSpace(pEmail) && !IsValidEmail(pEmail))
                        errors.Add("Invalid parent email format");
                    if (errors.Count > 0)
                    {
                        result.FailedRows.Add(new StudentImportRowError
                        {
                            RowNumber = r,
                            StudentName = $"{firstName} {lastName}".Trim(),
                            Errors = errors
                        });
                        continue;
                    }

                    var key = (pPhone.ToLowerInvariant(), pEmail.ToLowerInvariant());
                    if (!parentLookup.TryGetValue(key, out var parent))
                    {
                        parent = new Parent
                        {
                            TenantId = tenant,
                            FirstName = pFirst,
                            LastName = Cell(ColParentLastName),
                            PhoneNumber = pPhone,
                            Email = pEmail,
                            Occupation = Cell(ColParentOccupation),
                            Address = student.Address,
                            CreatedBy = importedBy
                        };
                        _context.Parents.Add(parent);
                        parentLookup[key] = parent;
                    }
                    student.Parent = parent;
                    student.ParentId = parent.Id;
                }

                if (isNew)
                {
                    _context.Students.Add(student);
                    existingByScholar[student.ScholarNumber] = student;
                }
                else
                {
                    _context.Students.Update(student);
                }

                result.SuccessCount++;
                result.ImportedNames.Add($"{student.FirstName} {student.LastName} ({student.ScholarNumber})");
            }

            if (result.SuccessCount > 0)
            {
                await _context.SaveChangesAsync();
                _logger.LogInformation(
                    "Student admission import: {Imported} imported, {Failed} failed rows, tenant {TenantId}, by {User}",
                    result.SuccessCount, result.FailedRows.Count, tenantId, importedBy);
            }

            return result;
        }

        private static string? NullIfEmpty(string? value)
            => string.IsNullOrWhiteSpace(value) ? null : value;

        /// <summary>Admission-API parity email check (System.Net.Mail strictness).</summary>
        private static bool IsValidEmail(string email)
        {
            try
            {
                var addr = new System.Net.Mail.MailAddress(email);
                return addr.Address == email;
            }
            catch
            {
                return false;
            }
        }

        /// <summary>Generates the next sequential admission number for the tenant.</summary>
        private async Task<string> GenerateAdmissionNumberAsync(int tenantId)
        {
            var year = DateTime.UtcNow.Year;
            var maxExisting = await _context.Students
                .IgnoreQueryFilters()
                .Where(s => s.TenantId == tenantId && s.ScholarNumber.StartsWith($"ADM-{year}"))
                .Select(s => s.ScholarNumber)
                .ToListAsync();

            int max = 0;
            foreach (var num in maxExisting)
            {
                var suffix = num[(num.LastIndexOf('-') + 1)..];
                if (int.TryParse(suffix, out var n) && n > max) max = n;
            }
            return $"ADM-{year}-{(max + 1):D5}";
        }
    }

    public class StudentImportResult
    {
        public int SuccessCount { get; set; }
        public List<string> ImportedNames { get; set; } = new();
        public List<StudentImportRowError> FailedRows { get; set; } = new();
        public List<string> GlobalErrors { get; set; } = new();
    }

    public class StudentImportRowError
    {
        public int RowNumber { get; set; }
        public string StudentName { get; set; } = string.Empty;
        public List<string> Errors { get; set; } = new();
    }
}
