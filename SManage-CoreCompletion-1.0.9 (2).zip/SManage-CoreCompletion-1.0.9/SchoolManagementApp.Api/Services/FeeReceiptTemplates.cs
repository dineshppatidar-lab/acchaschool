using SchoolManagementApp.ApplicationCore.Entities;
using System.Text;

namespace SchoolManagementApp.Api.Services
{
    /// <summary>
    /// Printable fee-receipt HTML templates. Three designs are offered:
    ///   classic  — the original blue gradient card (default)
    ///   modern   — clean white layout with a coloured side band, best for A4 letterhead
    ///   minimal  — monospace 80mm thermal-printer friendly slip
    /// All templates are self-contained HTML (inline CSS) so they print directly
    /// from any browser and are safe to email.
    /// </summary>
    public static class FeeReceiptTemplates
    {
        public static string Render(Fee fee, string template)
        {
            return template?.Trim().ToLowerInvariant() switch
            {
                "modern" => new ModernTemplate(fee).Render(),
                "minimal" => new MinimalTemplate(fee).Render(),
                _ => new ClassicTemplate(fee).Render()
            };
        }

        public static IReadOnlyList<string> AvailableTemplates { get; } = new[] { "classic", "modern", "minimal" };

        // ───────────────────────── shared data extraction ─────────────────────────

        internal sealed record ReceiptData(
            string StudentName, string RollNumber, string ScholarNumber,
            string ClassName, string SectionName, string Contact, string Email,
            string FeeType, DateTime DueDate, string Status, decimal Amount,
            decimal TotalPaid, decimal Remaining,
            List<(DateTime Date, string Method, string ReceiptNumber, decimal Amount, string Status)> Payments)
        {
            public string AmountInWords => NumberToWords((long)Math.Floor(Amount));
        }

        internal static ReceiptData Extract(Fee fee)
        {
            var payments = fee.Payments?.ToList() ?? new List<Payment>();
            var totalPaid = payments.Where(p => p.Status == "Success").Sum(p => p.Amount);
            return new ReceiptData(
                fee.Student != null ? $"{fee.Student.FirstName} {fee.Student.LastName}" : $"Student #{fee.StudentId}",
                fee.Student?.RollNumber ?? "N/A",
                fee.Student?.ScholarNumber ?? "N/A",
                fee.Student?.Class?.Name ?? "N/A",
                fee.Student?.Section?.Name ?? "N/A",
                fee.Student?.ContactNumber ?? "N/A",
                fee.Student?.Email ?? "N/A",
                fee.FeeType,
                fee.DueDate,
                fee.Status ?? "Pending",
                fee.Amount,
                totalPaid,
                fee.Amount - totalPaid,
                payments.OrderByDescending(p => p.PaymentDate)
                    .Select(p => (p.PaymentDate, p.PaymentMethod ?? "—", p.ReceiptNumber ?? "—", p.Amount, p.Status ?? "—"))
                    .ToList()
            );
        }

        private static string Esc(string? s) => System.Net.WebUtility.HtmlEncode(s ?? string.Empty);

        internal static string NumberToWords(long number)
        {
            if (number == 0) return "Zero";
            if (number < 0) return "Negative " + NumberToWords(-number);

            string words = "";
            if ((number / 10000000) > 0) { words += NumberToWords(number / 10000000) + " Crore "; number %= 10000000; }
            if ((number / 100000) > 0) { words += NumberToWords(number / 100000) + " Lakh "; number %= 100000; }
            if ((number / 1000) > 0) { words += NumberToWords(number / 1000) + " Thousand "; number %= 1000; }
            if ((number / 100) > 0) { words += NumberToWords(number / 100) + " Hundred "; number %= 100; }

            string[] unitsMap = { "Zero", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten",
                "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen" };
            string[] tensMap = { "Zero", "Ten", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety" };

            if (number > 0)
            {
                if (words != "") words += "and ";
                if (number < 20) words += unitsMap[number];
                else { words += tensMap[number / 10]; if ((number % 10) > 0) words += "-" + unitsMap[number % 10]; }
            }
            return words.Trim();
        }

        // ───────────────────────── shared print helper ─────────────────────────

        private static string PrintScript() => @"
<script>
  window.addEventListener('load', function () {
    var s = document.createElement('style');
    s.textContent = '.print-toolbar{display:flex!important}';
    document.head.appendChild(s);
  });
  function hideBarAndPrint() {
    var b = document.querySelector('.print-toolbar');
    if (b) b.style.display = 'none';
    document.body.style.background = '#fff';
    window.print();
  }
</script>
<div class=""print-toolbar"" style=""display:none;justify-content:center;gap:12px;padding:14px;font-family:Arial,sans-serif;"">
  <button onclick=""hideBarAndPrint()"" style=""padding:10px 22px;border:0;border-radius:8px;background:#1565c0;color:#fff;font-size:14px;cursor:pointer;"">🖨 Print</button>
  <span style=""align-self:center;color:#666;font-size:12px;"">Tip: enable ""Background graphics"" in the print dialog for best results.</span>
</div>";

        // ───────────────────────── CLASSIC (original blue card) ─────────────────────────

        private sealed class ClassicTemplate
        {
            private readonly Fee _fee;
            public ClassicTemplate(Fee fee) { _fee = fee; }

            public string Render()
            {
                var d = Extract(_fee);
                var statusClass = d.Status.ToLower() switch { "paid" => "status-paid", "overdue" => "status-overdue", _ => "status-pending" };
                var statusLabel = d.Status.ToLower() switch { "paid" => "PAID IN FULL", "overdue" => "OVERDUE", _ => "PENDING" };

                var sb = new StringBuilder();
                sb.Append("<!DOCTYPE html><html lang=\"en\"><head><meta charset=\"utf-8\"/><title>Fee Receipt — ").Append(Esc(d.StudentName)).Append("</title><style>");
                sb.Append("body{font-family:'Segoe UI',Arial,Helvetica,sans-serif;color:#1a1a2e;background:#f0f2f5;margin:0;padding:20px}");
                sb.Append(".receipt-container{max-width:700px;margin:0 auto;background:#fff;border-radius:12px;box-shadow:0 2px 12px rgba(0,0,0,.08);overflow:hidden}");
                sb.Append(".receipt-header{background:linear-gradient(135deg,#1a237e,#283593);color:#fff;padding:32px;text-align:center}");
                sb.Append(".receipt-header h1{margin:0 0 4px;font-size:22px;font-weight:700;letter-spacing:1px}");
                sb.Append(".school-name{font-size:14px;opacity:.9;margin-bottom:16px}");
                sb.Append(".receipt-badge{display:inline-block;background:rgba(255,255,255,.2);border-radius:20px;padding:6px 20px;font-size:13px;font-weight:600}");
                sb.Append(".receipt-body{padding:28px 32px}");
                sb.Append(".section-title{font-size:13px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:#5c6bc0;margin:20px 0 12px;padding-bottom:6px;border-bottom:2px solid #e8eaf6}");
                sb.Append(".info-grid{display:grid;grid-template-columns:1fr 1fr;gap:12px 24px}");
                sb.Append(".info-label{font-size:11px;font-weight:600;color:#78909c;text-transform:uppercase;letter-spacing:.05em;display:block;margin-bottom:2px}");
                sb.Append(".info-value{font-size:14px;font-weight:500;color:#263238}");
                sb.Append(".amount-box{background:#f5f7ff;border:1px solid #e0e4f5;border-radius:8px;padding:20px;margin:20px 0;text-align:center}");
                sb.Append(".amount-box .label{font-size:12px;color:#5c6bc0;font-weight:600;text-transform:uppercase;letter-spacing:.05em}");
                sb.Append(".amount-box .amount{font-size:36px;font-weight:800;color:#1a237e;margin:4px 0}");
                sb.Append(".status-paid{color:#2e7d32}.status-pending{color:#e65100}.status-overdue{color:#c62828}");
                sb.Append(".payment-table{width:100%;border-collapse:collapse;margin-top:12px}");
                sb.Append(".payment-table th{background:#f5f7ff;padding:10px 12px;text-align:left;font-size:11px;font-weight:700;text-transform:uppercase;color:#5c6bc0;border-bottom:2px solid #e8eaf6}");
                sb.Append(".payment-table td{padding:10px 12px;font-size:13px;border-bottom:1px solid #f0f0f0;color:#37474f}");
                sb.Append(".summary-row{display:flex;justify-content:space-between;padding:10px 0;font-size:14px}");
                sb.Append(".summary-row.total{border-top:2px solid #e8eaf6;font-weight:700;font-size:16px;color:#1a237e;padding-top:12px}");
                sb.Append(".receipt-footer{background:#f8f9fc;padding:20px 32px;text-align:center;border-top:1px solid #e8eaf6}");
                sb.Append(".receipt-footer p{margin:4px 0;font-size:12px;color:#78909c}");
                sb.Append("@media print{body{background:#fff;padding:0}.receipt-container{box-shadow:none;border-radius:0}}");
                sb.Append("</style></head><body>");
                sb.Append(PrintScript());
                sb.Append("<div class=\"receipt-container\">");

                sb.Append("<div class=\"receipt-header\"><h1>FEE RECEIPT</h1><div class=\"school-name\">School Management System</div>");
                sb.Append("<div class=\"receipt-badge\">Fee Record #").Append(_fee.Id).Append("</div></div>");

                sb.Append("<div class=\"receipt-body\">");

                sb.Append("<div class=\"section-title\">Student Information</div><div class=\"info-grid\">");
                sb.Append(Item("Student Name", Esc(d.StudentName)));
                sb.Append(Item("Roll Number", Esc(d.RollNumber)));
                sb.Append(Item("Scholar Number", Esc(d.ScholarNumber)));
                sb.Append(Item("Class / Section", Esc(d.ClassName) + " / " + Esc(d.SectionName)));
                sb.Append(Item("Contact", Esc(d.Contact)));
                sb.Append(Item("Email", Esc(d.Email)));
                sb.Append("</div>");

                sb.Append("<div class=\"section-title\">Fee Details</div><div class=\"info-grid\">");
                sb.Append(Item("Fee Type", Esc(d.FeeType)));
                sb.Append(Item("Due Date", d.DueDate.ToString("dd MMM yyyy")));
                sb.Append(Item("Status", Esc(d.Status)));
                sb.Append("</div>");

                sb.Append("<div class=\"amount-box\"><div class=\"label\">Total Fee Amount</div><div class=\"amount\">").Append(d.Amount.ToString("N2")).Append("</div><div class=\"status ").Append(statusClass).Append("\">").Append(statusLabel).Append("</div></div>");

                if (d.Payments.Any())
                {
                    sb.Append("<div class=\"section-title\">Payment History</div><table class=\"payment-table\"><thead><tr><th>Date</th><th>Method</th><th>Receipt #</th><th>Amount</th><th>Status</th></tr></thead><tbody>");
                    foreach (var p in d.Payments)
                    {
                        sb.Append("<tr><td>").Append(p.Date.ToString("dd MMM yyyy")).Append("</td><td>").Append(Esc(p.Method)).Append("</td><td>").Append(Esc(p.ReceiptNumber)).Append("</td><td>").Append(p.Amount.ToString("N2")).Append("</td><td>").Append(Esc(p.Status)).Append("</td></tr>");
                    }
                    sb.Append("</tbody></table>");
                }

                sb.Append("<div class=\"section-title\">Summary</div>");
                sb.Append("<div class=\"summary-row\"><span>Total Fee</span><span>").Append(d.Amount.ToString("N2")).Append("</span></div>");
                sb.Append("<div class=\"summary-row\"><span>Amount Paid</span><span style=\"color:#2e7d32\">").Append(d.TotalPaid.ToString("N2")).Append("</span></div>");
                sb.Append(d.Remaining > 0
                    ? $"<div class=\"summary-row total\"><span>Remaining Balance</span><span style=\"color:#c62828\">{d.Remaining:N2}</span></div>"
                    : "<div class=\"summary-row total\"><span>Balance</span><span style=\"color:#2e7d32\">0.00</span></div>");

                sb.Append("</div>"); // body
                sb.Append("<div class=\"receipt-footer\"><p>Generated on ").Append(DateTime.Now.ToString("dd MMM yyyy 'at' hh:mm tt")).Append("</p>");
                sb.Append("<p>This is a system-generated receipt. For queries, please contact the accounts department.</p></div>");
                sb.Append("</div></body></html>");
                return sb.ToString();
            }

            private static string Item(string label, string value) =>
                $"<div><span class=\"info-label\">{label}</span><span class=\"info-value\">{value}</span></div>";
        }

        // ───────────────────────── MODERN (letterhead style) ─────────────────────────

        private sealed class ModernTemplate
        {
            private readonly Fee _fee;
            public ModernTemplate(Fee fee) { _fee = fee; }

            public string Render()
            {
                var d = Extract(_fee);
                var paidColor = d.Remaining <= 0 ? "#2e7d32" : "#e65100";
                var paidLabel = d.Remaining <= 0 ? "PAID IN FULL" : (d.Status.ToLower() == "overdue" ? "OVERDUE" : "PARTIALLY PAID");

                var sb = new StringBuilder();
                sb.Append("<!DOCTYPE html><html lang=\"en\"><head><meta charset=\"utf-8\"/><title>Fee Receipt — ").Append(Esc(d.StudentName)).Append("</title><style>");
                sb.Append("*{box-sizing:border-box}");
                sb.Append("body{font-family:'Segoe UI',Arial,sans-serif;color:#22303f;margin:0;background:#eceff4}");
                sb.Append(".sheet{max-width:820px;margin:24px auto;background:#fff;display:grid;grid-template-columns:14px 1fr;min-height:96vh}");
                sb.Append(".band{background:linear-gradient(180deg,#0d47a1,#1976d2 40%,#42a5f5)}");
                sb.Append(".content{padding:36px 42px}");
                sb.Append(".top{display:flex;justify-content:space-between;align-items:flex-start;border-bottom:3px solid #0d47a1;padding-bottom:18px;margin-bottom:24px}");
                sb.Append(".brand{font-size:24px;font-weight:800;color:#0d47a1;letter-spacing:.5px}");
                sb.Append(".brand small{display:block;font-size:11px;font-weight:600;color:#78909c;letter-spacing:2px;text-transform:uppercase;margin-top:4px}");
                sb.Append(".meta{text-align:right;font-size:12px;color:#5f7086;line-height:1.7}");
                sb.Append(".meta b{color:#22303f}");
                sb.Append("h2{font-size:15px;letter-spacing:2px;text-transform:uppercase;color:#0d47a1;margin:26px 0 12px}");
                sb.Append("h2::after{content:'';display:block;width:44px;height:3px;background:#42a5f5;margin-top:6px;border-radius:2px}");
                sb.Append(".grid{display:grid;grid-template-columns:repeat(3,1fr);gap:14px}");
                sb.Append(".cell .k{font-size:10px;color:#8aa0b4;text-transform:uppercase;letter-spacing:.6px;display:block}");
                sb.Append(".cell .v{font-size:13.5px;font-weight:600;color:#22303f;margin-top:2px}");
                sb.Append(".amounts{display:grid;grid-template-columns:repeat(3,1fr);gap:14px;margin-top:26px}");
                sb.Append(".amt{border:1px solid #e3eaf2;border-radius:10px;padding:16px;text-align:center}");
                sb.Append(".amt .k{font-size:10.5px;color:#8aa0b4;text-transform:uppercase;letter-spacing:.8px}");
                sb.Append(".amt .v{font-size:20px;font-weight:800;margin-top:6px;color:#0d47a1}");
                sb.Append(".amt.green .v{color:#2e7d32}.amt.red .v{color:#c62828}");
                sb.Append(".words{margin-top:18px;font-size:12.5px;color:#5f7086;font-style:italic}");
                sb.Append("table{width:100%;border-collapse:collapse;margin-top:10px;font-size:12.5px}");
                sb.Append("th{background:#f2f6fb;text-align:left;padding:9px 10px;font-size:10.5px;text-transform:uppercase;letter-spacing:.5px;color:#5f7086;border-bottom:2px solid #e3eaf2}");
                sb.Append("td{padding:9px 10px;border-bottom:1px solid #eef2f7}");
                sb.Append(".sign{display:flex;justify-content:space-between;margin-top:70px}");
                sb.Append(".sign .line{width:210px;border-top:1.5px solid #90a4ae;text-align:center;padding-top:8px;font-size:11.5px;color:#5f7086}");
                sb.Append(".footer{margin-top:34px;border-top:1px solid #e3eaf2;padding-top:12px;font-size:11px;color:#90a4ae;text-align:center}");
                sb.Append("@media print{body{background:#fff}.sheet{margin:0;min-height:auto}.band{display:none}.sheet{grid-template-columns:1fr;border-left:14px solid #0d47a1}}");
                sb.Append("</style></head><body>");
                sb.Append(PrintScript());
                sb.Append("<div class=\"sheet\"><div class=\"band\"></div><div class=\"content\">");

                sb.Append("<div class=\"top\"><div class=\"brand\">AcchaSchool<small>Fee Payment Receipt</small></div>");
                sb.Append("<div class=\"meta\"><b>Receipt #</b> FR-").Append(_fee.Id.ToString("D6")).Append("<br/><b>Issue date:</b> ").Append(DateTime.Now.ToString("dd MMM yyyy")).Append("<br/><b>Status:</b> ").Append(Esc(d.Status)).Append("</div></div>");

                sb.Append("<h2>Student</h2><div class=\"grid\">");
                sb.Append(Cell("Name", Esc(d.StudentName)));
                sb.Append(Cell("Class", Esc(d.ClassName) + " — " + Esc(d.SectionName)));
                sb.Append(Cell("Roll / Scholar", Esc(d.RollNumber) + " / " + Esc(d.ScholarNumber)));
                sb.Append(Cell("Contact", Esc(d.Contact)));
                sb.Append(Cell("Email", Esc(d.Email)));
                sb.Append("</div>");

                sb.Append("<h2>Fee</h2><div class=\"grid\">");
                sb.Append(Cell("Fee Type", Esc(d.FeeType)));
                sb.Append(Cell("Due Date", d.DueDate.ToString("dd MMM yyyy")));
                sb.Append(Cell("Payment Status", paidLabel));
                sb.Append("</div>");

                sb.Append("<div class=\"amounts\">");
                sb.Append("<div class=\"amt\"><div class=\"k\">Total Fee</div><div class=\"v\">₹").Append(d.Amount.ToString("N2")).Append("</div></div>");
                sb.Append("<div class=\"amt green\"><div class=\"k\">Paid</div><div class=\"v\">₹").Append(d.TotalPaid.ToString("N2")).Append("</div></div>");
                sb.Append(d.Remaining > 0
                    ? $"<div class=\"amt red\"><div class=\"k\">Balance</div><div class=\"v\">₹{d.Remaining:N2}</div></div>"
                    : "<div class=\"amt green\"><div class=\"k\">Balance</div><div class=\"v\">₹0.00</div></div>");
                sb.Append("</div>");
                sb.Append("<div class=\"words\">Amount in words: ").Append(Esc(d.AmountInWords)).Append(" rupees only</div>");

                if (d.Payments.Any())
                {
                    sb.Append("<h2>Payments</h2><table><thead><tr><th>Date</th><th>Method</th><th>Receipt #</th><th style=\"text-align:right\">Amount</th><th>Status</th></tr></thead><tbody>");
                    foreach (var p in d.Payments)
                    {
                        sb.Append("<tr><td>").Append(p.Date.ToString("dd MMM yyyy")).Append("</td><td>").Append(Esc(p.Method)).Append("</td><td>").Append(Esc(p.ReceiptNumber)).Append("</td><td style=\"text-align:right\">").Append(p.Amount.ToString("N2")).Append("</td><td>").Append(Esc(p.Status)).Append("</td></tr>");
                    }
                    sb.Append("</tbody></table>");
                }

                sb.Append("<div class=\"sign\"><div class=\"line\">Parent / Guardian</div><div class=\"line\">Authorised Signatory</div></div>");
                sb.Append("<div class=\"footer\">This is a computer-generated receipt and does not require a physical signature. For queries contact the accounts office.</div>");

                sb.Append("</div></div></body></html>");
                return sb.ToString();
            }

            private static string Cell(string k, string v) => $"<div class=\"cell\"><span class=\"k\">{k}</span><span class=\"v\">{v}</span></div>";
        }

        // ───────────────────────── MINIMAL (thermal 80mm) ─────────────────────────

        private sealed class MinimalTemplate
        {
            private readonly Fee _fee;
            public MinimalTemplate(Fee fee) { _fee = fee; }

            public string Render()
            {
                var d = Extract(_fee);
                var sb = new StringBuilder();
                sb.Append("<!DOCTYPE html><html lang=\"en\"><head><meta charset=\"utf-8\"/><title>Fee Receipt — ").Append(Esc(d.StudentName)).Append("</title><style>");
                sb.Append("body{font-family:'Courier New',monospace;color:#000;background:#fff;margin:0;padding:10px;width:302px;font-size:12px}");
                sb.Append(".center{text-align:center}");
                sb.Append("h1{font-size:15px;margin:6px 0 2px;letter-spacing:1px}");
                sb.Append(".sub{font-size:10.5px;color:#333}");
                sb.Append("hr{border:0;border-top:1px dashed #000;margin:8px 0}");
                sb.Append(".row{display:flex;justify-content:space-between;gap:8px;font-size:11.5px;line-height:1.55}");
                sb.Append(".row .k{color:#000}");
                sb.Append(".row.big{font-size:14px;font-weight:700}");
                sb.Append(".total{font-size:16px;font-weight:700}");
                sb.Append(".thanks{margin-top:10px;text-align:center;font-size:11px}");
                sb.Append("@media print{body{width:80mm}@page{size:80mm auto;margin:0}}");
                sb.Append("</style></head><body>");
                sb.Append(PrintScript());

                sb.Append("<div class=\"center\"><h1>ACCHASCHOOL</h1><div class=\"sub\">Fee Receipt</div></div><hr/>");
                sb.Append(Row("Receipt #", "FR-" + _fee.Id.ToString("D6")));
                sb.Append(Row("Date", DateTime.Now.ToString("dd/MM/yyyy HH:mm")));
                sb.Append("<hr/>");
                sb.Append(Row("Student", d.StudentName.Length > 26 ? d.StudentName[..26] : d.StudentName));
                sb.Append(Row("Class", d.ClassName + " " + d.SectionName));
                sb.Append(Row("Roll", d.RollNumber));
                sb.Append("<hr/>");
                sb.Append(Row("Fee Type", d.FeeType));
                sb.Append(Row("Due Date", d.DueDate.ToString("dd/MM/yyyy")));
                sb.Append("<hr/>");
                sb.Append(Row("Fee Amount", "Rs." + d.Amount.ToString("N2")));
                sb.Append(Row("Paid", "Rs." + d.TotalPaid.ToString("N2")));
                sb.Append("<div class=\"row big\"><span>BALANCE</span><span>Rs." + d.Remaining.ToString("N2") + "</span></div>");
                sb.Append(Row("Status", d.Remaining <= 0 ? "PAID IN FULL" : d.Status.ToUpper()));
                sb.Append("<hr/>");

                if (d.Payments.Any())
                {
                    foreach (var p in d.Payments)
                    {
                        sb.Append(Row(p.Date.ToString("dd/MM") + " " + p.Method, "Rs." + p.Amount.ToString("N2")));
                    }
                    sb.Append("<hr/>");
                }

                sb.Append("<div class=\"row\"><span>In words</span></div>");
                sb.Append("<div class=\"sub\">" + Esc(d.AmountInWords) + " rupees only</div>");
                sb.Append("<div class=\"thanks\">Thank you!<br/>Computer-generated receipt</div>");
                sb.Append("</body></html>");
                return sb.ToString();
            }

            private static string Row(string k, string v) => $"<div class=\"row\"><span class=\"k\">{Esc(k)}</span><span>{Esc(v)}</span></div>";
        }
    }
}
