using Microsoft.AspNetCore.Http;
using SchoolManagementApp.Api.Middleware;

namespace SchoolManagementApp.Api.Services.Implementation
{
    public class TenantProvider : ITenantProvider
    {
        private readonly IHttpContextAccessor _httpContextAccessor;
        public TenantProvider(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
        }

        public int TenantId
        {
            get
            {
                var context = _httpContextAccessor.HttpContext;

                // Ambient scope (background workers) when there is no HTTP context.
                if (context == null)
                {
                    var ambientNoHttp = SchoolManagementApp.ApplicationCore.Common.AmbientTenantContext.TenantId;
                    return ambientNoHttp.HasValue && ambientNoHttp.Value > 0 ? ambientNoHttp.Value : 1;
                }

                // 1. Try context items (set by middleware)
                if (context.Items.TryGetValue(TenantResolutionMiddleware.TenantItemKey, out var value))
                {
                    if (value is int i && i > 0) return i;
                    if (value is string s && int.TryParse(s, out var j) && j > 0) return j;
                }

                // 2. Fallback: try User claims directly
                if (context.User?.Identity?.IsAuthenticated == true)
                {
                    var claimTenant = context.User.FindFirst("tenant_id")?.Value
                                      ?? context.User.FindFirst("tenantid")?.Value
                                      ?? context.User.FindFirst("TenantId")?.Value
                                      ?? context.User.FindFirst("http://schemas.microsoft.com/identity/claims/tenantid")?.Value;

                    if (int.TryParse(claimTenant, out var tid) && tid > 0)
                    {
                        return tid;
                    }
                }

                // 3. Ambient scope (background workers) takes precedence over the default.
                var ambient = SchoolManagementApp.ApplicationCore.Common.AmbientTenantContext.TenantId;
                if (ambient.HasValue && ambient.Value > 0) return ambient.Value;

                return 1; // default
            }
        }

        public string? CurrentUserId
        {
            get
            {
                var context = _httpContextAccessor.HttpContext;
                if (context == null)
                {
                    // No HTTP context (background job / webhook): use the ambient actor
                    // so audit rows attribute changes to the job, not to "System".
                    return SchoolManagementApp.ApplicationCore.Common.AmbientTenantContext.ActorUserId;
                }

                return context.User?.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value 
                    ?? context.User?.FindFirst("sub")?.Value 
                    ?? context.User?.FindFirst("id")?.Value;
            }
        }
    }
}
