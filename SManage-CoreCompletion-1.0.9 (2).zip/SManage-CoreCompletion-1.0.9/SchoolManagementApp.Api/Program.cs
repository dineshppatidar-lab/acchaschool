using SchoolManagementApp.Api;
using SchoolManagementApp.Infrastructure.Data;
using Microsoft.Extensions.Configuration;

// ── Bootstrap ────────────────────────────────────────────────────────────────
// Program.cs is intentionally minimal. All DI and middleware live in
// Startup.cs and Extension classes, following CorporateFleet's pattern.
// ─────────────────────────────────────────────────────────────────────────────

var builder = WebApplication.CreateBuilder(args);

// Configure WebRootPath for Angular frontend (sibling SchoolManageFrontend/)
ConfigureWebRoot(builder);

// Wire up all services
var startup = new Startup(builder.Configuration, builder.Environment);
startup.ConfigureServices(builder.Services);

var app = builder.Build();

// Wire up middleware pipeline
startup.Configure(app, builder.Environment);

// Debug endpoint (dev only)
if (app.Environment.IsDevelopment())
{
    app.MapGet("/debug-paths", (IWebHostEnvironment env) =>
    {
        var contentRoot = env.ContentRootPath;
        return new
        {
            ContentRootPath = contentRoot,
            WebRootPath = env.WebRootPath,
            WebRootExists = Directory.Exists(env.WebRootPath ?? ""),
            IndexExists = File.Exists(Path.Combine(env.WebRootPath ?? "", "index.html")),
            Time = DateTime.Now.ToString()
        };
    });
}

// ── Database Migration (async, non-blocking) ───────────────────────────────
// Gated by config so production can run migrations as a separate deploy step
// instead of on every cold start (see docs/critical-issues/11-startup-migrations.md).
if (!app.Environment.IsEnvironment("Testing") &&
    app.Configuration.GetValue("Database:RunMigrationsOnStartup", app.Environment.IsDevelopment()))
{
    await MigrateDatabaseAsync(app);
}

app.Run();

// ── Local helpers ────────────────────────────────────────────────────────────
static void ConfigureWebRoot(WebApplicationBuilder builder)
{
    var contentRoot = builder.Environment.ContentRootPath;
    var parentDir = Path.GetDirectoryName(contentRoot) ?? contentRoot;

    var searchPaths = new[]
    {
        Path.Combine(parentDir, "SchoolManageFrontend", "dist", "FrontendProject", "browser"),
        Path.Combine(contentRoot, "FrontendProject", "dist", "FrontendProject", "browser"),
        Path.Combine(contentRoot, "dist", "FrontendProject", "browser"),
        contentRoot
    };

    foreach (var path in searchPaths)
    {
        if (File.Exists(Path.Combine(path, "index.html")))
        {
            builder.Environment.WebRootPath = path;
            break;
        }
    }
}

static async Task MigrateDatabaseAsync(WebApplication app)
{
    using var scope = app.Services.CreateScope();
    var services = scope.ServiceProvider;
    var logger = services.GetRequiredService<ILogger<Program>>();

    try
    {
        var context = services.GetRequiredService<ApplicationDbContext>();

        // Log server/database name only — never the full connection string (credentials).
        var (dataSource, databaseName) = GetSafeDbIdentifiers(context);
        logger.LogInformation("Starting EF Core migration for SQL Server database: {DataSource}/{Database}", dataSource, databaseName);

        if (context.Database.IsSqlServer())
        {
            // Some migrations (e.g. StandardizeAuditAcrossAllTables) run cursor-based SQL
            // over every table, which can exceed the default 30s command timeout.
            context.Database.SetCommandTimeout(TimeSpan.FromMinutes(10));

            // Distributed lock (docs/critical-issues/11-startup-migrations.md):
            // two instances starting simultaneously must not race MigrateAsync —
            // the __EFMigrationsHistory insert race can fail both or leave partial state.
            //
            // sp_getapplock with a Session owner lives on the physical connection, so the
            // connection is held explicitly open across lock → migrate → release. With
            // LockTimeout 0 a second instance skips immediately and serves traffic while
            // the first applies migrations.
            var conn = context.Database.GetDbConnection();
            var lockTaken = false;

            try
            {
                await context.Database.OpenConnectionAsync();

                await using (var lockCommand = conn.CreateCommand())
                {
                    lockCommand.CommandText =
                        @"DECLARE @r INT;
                          EXEC @r = sp_getapplock @Resource = 'school-migrations',
                               @LockMode = 'Exclusive', @LockOwner = 'Session', @LockTimeout = 0;
                          SELECT @r;";
                    var scalar = await lockCommand.ExecuteScalarAsync();
                    lockTaken = scalar != null && Convert.ToInt32(scalar) >= 0;
                }
            }
            catch (Exception ex)
            {
                // e.g. database does not exist yet (first deploy) — fall back to an
                // unlocked migrate, which MigrateAsync handles by creating the database.
                logger.LogWarning(ex, "Could not acquire migration app-lock; proceeding without it.");
            }

            if (!lockTaken && conn.State == System.Data.ConnectionState.Open)
            {
                logger.LogInformation("Another instance holds the migration lock; skipping startup migrations.");
                await context.Database.CloseConnectionAsync();
                return;
            }

            try
            {
                await context.Database.MigrateAsync();
                logger.LogInformation("EF Core migrations completed successfully.");
            }
            finally
            {
                if (lockTaken)
                {
                    try
                    {
                        await using var releaseCommand = conn.CreateCommand();
                        releaseCommand.CommandText =
                            @"EXEC sp_releaseapplock @Resource = 'school-migrations', @LockOwner = 'Session';";
                        await releaseCommand.ExecuteNonQueryAsync();
                    }
                    catch (Exception ex)
                    {
                        logger.LogWarning(ex, "Releasing the migration app-lock failed (lock dies with the connection anyway).");
                    }
                }

                await context.Database.CloseConnectionAsync();
            }
        }
    }
    catch (Exception ex)
    {
        logger.LogError(ex, "Database migration failed. The database may exist without the full schema applied.");
        throw;
    }
}

static (string DataSource, string Database) GetSafeDbIdentifiers(ApplicationDbContext context)
{
    // Best-effort parse of the connection string; falls back to placeholders on failure.
    try
    {
        var csBuilder = new System.Data.Common.DbConnectionStringBuilder
        {
            ConnectionString = context.Database.GetConnectionString() ?? string.Empty
        };
        var server = csBuilder.TryGetValue("Server", out var s) || csBuilder.TryGetValue("Data Source", out s)
            ? s?.ToString() ?? "unknown" : "unknown";
        var database = csBuilder.TryGetValue("Database", out var d) || csBuilder.TryGetValue("Initial Catalog", out d)
            ? d?.ToString() ?? "unknown" : "unknown";
        return (server, database);
    }
    catch
    {
        return ("unknown", "unknown");
    }
}
