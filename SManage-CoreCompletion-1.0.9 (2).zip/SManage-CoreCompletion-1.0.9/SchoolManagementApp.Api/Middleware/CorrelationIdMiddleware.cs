using SchoolManagementApp.ApplicationCore.Common;

namespace SchoolManagementApp.Api.Middleware
{
    /// <summary>
    /// Seeds <see cref="AmbientTenantContext.CorrelationId"/> from
    /// HttpContext.TraceIdentifier at the start of every request, so all audit rows
    /// written during the request share one correlation id out of the box
    /// (docs/critical-issues/13-audit-trail-gaps.md follow-up).
    ///
    /// Runs as the first middleware. A downstream handler can still override the
    /// correlation id (e.g. honor an upstream X-Correlation-ID) via
    /// AmbientTenantContext.SetActor — anything set later simply overwrites the seed.
    /// </summary>
    public class CorrelationIdMiddleware
    {
        public const string HeaderName = "X-Correlation-ID";

        private readonly RequestDelegate _next;

        public CorrelationIdMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        public async Task InvokeAsync(HttpContext context)
        {
            // Honor an upstream-provided id when present (API gateways, load balancers);
            // otherwise use the request's trace identifier.
            var correlationId = context.Request.Headers[HeaderName].ToString();
            if (string.IsNullOrWhiteSpace(correlationId))
            {
                correlationId = context.TraceIdentifier;
            }

            // Echo it back so clients can quote it in support requests.
            context.Response.Headers[HeaderName] = correlationId;

            // Only set the ambient correlation — never an actor id (this is not auth).
            AmbientTenantContext.SetCorrelation(correlationId);

            await _next(context);
        }
    }
}
