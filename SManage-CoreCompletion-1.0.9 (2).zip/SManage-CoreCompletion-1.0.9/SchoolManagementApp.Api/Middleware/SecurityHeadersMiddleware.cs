namespace SchoolManagementApp.Api.Middleware
{
    /// <summary>
    /// Adds baseline security headers to every response and a strict Content-Security-Policy
    /// to HTML responses (the Angular app served by MapFallbackToFile).
    ///
    /// CSP notes (docs/critical-issues/16-jwt-in-localstorage.md, Option 2):
    ///  - styles: 'unsafe-inline' is required — Angular Material injects style attributes
    ///    and Google Fonts stylesheets apply inline during load.
    ///  - connect-src 'self': the API is served same-origin in production; in dev the
    ///    Angular dev server proxies /api and websockets to 'self' as well.
    ///  - CSP is only rendered from HTML documents; applying it to API responses is
    ///    harmless but we scope it to text/html anyway to keep headers precise.
    /// </summary>
    public class SecurityHeadersMiddleware
    {
        public const string CspHeaderValue =
            "default-src 'self'; " +
            "script-src 'self'; " +
            "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; " +
            "font-src 'self' data: https://fonts.gstatic.com; " +
            "img-src 'self' data: blob: https://ui-avatars.com; " +
            "connect-src 'self' wss: ws:; " +
            "media-src 'self'; " +
            "object-src 'none'; " +
            "base-uri 'self'; " +
            "frame-ancestors 'none'; " +
            "form-action 'self'";

        private readonly RequestDelegate _next;

        public SecurityHeadersMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        public async Task InvokeAsync(HttpContext context)
        {
            // Static headers set before the body starts for every response.
            context.Response.Headers["X-Content-Type-Options"] = "nosniff";
            context.Response.Headers["X-Frame-Options"] = "DENY";
            context.Response.Headers["Referrer-Policy"] = "no-referrer";
            context.Response.Headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()";

            // HSTS: intentionally NOT sent. The app must stay reachable over plain
            // HTTP in every environment; once a browser caches Strict-Transport-
            // Security (max-age 1 year) it refuses http:// connections to this host
            // for that period, client-side. If TLS is ever enforced at the reverse
            // proxy, re-add the header there instead of in the app.

            // CSP for HTML documents only (index.html via MapFallbackToFile).
            // Applied here (before _next) so the header survives when the static-file
            // middleware writes the body later in the pipeline.
            var contentType = context.Response.ContentType;
            if (string.IsNullOrEmpty(contentType) || contentType.StartsWith("text/html", StringComparison.OrdinalIgnoreCase))
            {
                context.Response.Headers["Content-Security-Policy"] = CspHeaderValue;
            }

            await _next(context);
        }
    }
}
