using Microsoft.AspNetCore.Http;
using System.Security.Claims;

namespace SchoolManagementApp.Api.Middleware
{

    /// <summary>
    /// Resolves the tenant for the current request.
    ///
    /// Rules (see docs/critical-issues/03-tenant-header-spoofing.md):
    ///  - Authenticated requests: tenant comes ONLY from JWT claims. A valid tenant claim
    ///    is mandatory — missing/invalid claims are rejected with 403 instead of falling
    ///    back to a default. The X-Tenant-ID header is NEVER honored for authenticated
    ///    users (prevents cross-tenant data access via header spoofing).
    ///  - Anonymous requests (login, registration, webhooks): tenant may come from the
    ///    X-Tenant-ID header. No tenant context is forced here — services that need one
    ///    for anonymous work must resolve it explicitly (e.g. login resolves by TenantCode).
    /// </summary>
    public class TenantResolutionMiddleware
    {
        public const string TenantItemKey = "TenantId";
        private readonly RequestDelegate _next;

        public TenantResolutionMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        public async Task InvokeAsync(HttpContext context)
        {
            if (context.User?.Identity?.IsAuthenticated == true)
            {
                // Check multiple possible claim names for tenant identification
                var claimTenant = context.User.FindFirst("tenant_id")?.Value
                                  ?? context.User.FindFirst("tenantid")?.Value
                                  ?? context.User.FindFirst("TenantId")?.Value
                                  ?? context.User.FindFirst("http://schemas.microsoft.com/identity/claims/tenantid")?.Value;

                if (!int.TryParse(claimTenant, out var claimTenantId) || claimTenantId <= 0)
                {
                    // Authenticated but no valid tenant claim → reject rather than guess.
                    // Never honor the client-supplied header in this state.
                    context.Response.StatusCode = StatusCodes.Status403Forbidden;
                    await context.Response.WriteAsJsonAsync(new
                    {
                        message = "Authentication token does not contain a valid tenant claim. Please re-authenticate."
                    });
                    return;
                }

                context.Items[TenantItemKey] = claimTenantId;
                await _next(context);
                return;
            }

            // ── Anonymous request ────────────────────────────────────────
            // Tenant may be hinted via header (login/registration flows). Webhooks and
            // login resolve tenancy themselves; no default tenant is forced here.
            var header = context.Request.Headers["X-Tenant-ID"].ToString();
            if (int.TryParse(header, out var headerTenantId) && headerTenantId > 0)
            {
                context.Items[TenantItemKey] = headerTenantId;
            }

            await _next(context);
        }
    }
}
