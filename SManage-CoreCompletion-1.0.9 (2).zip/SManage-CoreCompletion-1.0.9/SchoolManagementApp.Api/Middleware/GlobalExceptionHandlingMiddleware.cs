using System.Net;
using System.Text.Json;

namespace SchoolManagementApp.Api.Middleware
{
    /// <summary>
    /// Global exception handling middleware for centralized error handling
    /// </summary>
    public class GlobalExceptionHandlingMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly ILogger<GlobalExceptionHandlingMiddleware> _logger;

        public GlobalExceptionHandlingMiddleware(RequestDelegate next, ILogger<GlobalExceptionHandlingMiddleware> logger)
        {
            _next = next;
            _logger = logger;
        }

        public async Task InvokeAsync(HttpContext context)
        {
            try
            {
                await _next(context);
            }
            catch (Exception exception)
            {
                _logger.LogError(exception, "An unhandled exception occurred during request processing");
                await HandleExceptionAsync(context, exception);
            }
        }

        private async Task HandleExceptionAsync(HttpContext context, Exception exception)
        {
            context.Response.ContentType = "application/json";
            // Ensure CORS header is present even for unhandled exceptions, local dev fallback
            if (!context.Response.Headers.ContainsKey("Access-Control-Allow-Origin"))
            {
                context.Response.Headers.Append("Access-Control-Allow-Origin", "http://localhost:4200");
                context.Response.Headers.Append("Access-Control-Allow-Headers", "*");
                context.Response.Headers.Append("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
            }
            
            var response = CreateErrorResponse(exception);
            context.Response.StatusCode = response.StatusCode;

            var jsonResponse = JsonSerializer.Serialize(response, new JsonSerializerOptions
            {
                PropertyNamingPolicy = JsonNamingPolicy.CamelCase
            });

            await context.Response.WriteAsync(jsonResponse);
        }

        private ApiResponse CreateErrorResponse(Exception exception)
        {
            return exception switch
            {
                ArgumentNullException => CreateValidationErrorResponse(exception),
                ArgumentException => CreateValidationErrorResponse(exception),
                InvalidOperationException => CreateBadRequestResponse(exception),
                UnauthorizedAccessException => CreateUnauthorizedResponse(exception),
                KeyNotFoundException => CreateNotFoundResponse(exception),
                NotSupportedException => CreateNotSupportedResponse(exception),
                TimeoutException => CreateTimeoutResponse(exception),
                _ => CreateInternalServerErrorResponse(exception)
            };
        }

        private ApiResponse CreateValidationErrorResponse(Exception exception)
        {
            _logger.LogWarning(exception, "Validation error occurred");
            return ApiResponse.ValidationErrorResult(new List<string> { exception.Message }, "Validation error occurred");
        }

        private ApiResponse CreateBadRequestResponse(Exception exception)
        {
            _logger.LogWarning(exception, "Bad request error occurred");
            return ApiResponse.ErrorResult("Bad request", HttpStatusCode.BadRequest);
        }

        private ApiResponse CreateUnauthorizedResponse(Exception exception)
        {
            _logger.LogWarning(exception, "Unauthorized access attempted");
            return ApiResponse.ErrorResult("Unauthorized access", HttpStatusCode.Unauthorized);
        }

        private ApiResponse CreateNotFoundResponse(Exception exception)
        {
            _logger.LogWarning(exception, "Resource not found");
            return ApiResponse.ErrorResult(exception.Message, HttpStatusCode.NotFound);
        }

        private ApiResponse CreateNotSupportedResponse(Exception exception)
        {
            _logger.LogWarning(exception, "Operation not supported");
            return ApiResponse.ErrorResult(exception.Message, HttpStatusCode.NotImplemented);
        }

        private ApiResponse CreateTimeoutResponse(Exception exception)
        {
            _logger.LogError(exception, "Request timeout occurred");
            return ApiResponse.ErrorResult("The request timed out. Please try again.", HttpStatusCode.RequestTimeout);
        }

        private ApiResponse CreateInternalServerErrorResponse(Exception exception)
        {
            _logger.LogError(exception, "Internal server error occurred");
            
            // In production, don't expose internal error details
            var isDevelopment = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT") == "Development";
            
            var errorMessage = isDevelopment 
                ? exception.Message
                : "An unexpected error occurred. Please contact support.";
                
            return ApiResponse.ErrorResult(errorMessage, HttpStatusCode.InternalServerError);
        }
    }

    /// <summary>
    /// Extension method to register the global exception handling middleware
    /// </summary>
    public static class GlobalExceptionHandlingMiddlewareExtensions
    {
        public static IApplicationBuilder UseGlobalExceptionHandling(this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<GlobalExceptionHandlingMiddleware>();
        }
    }
}