using System.Diagnostics;
using System.Text;

namespace SchoolManagementApp.Api.Middleware
{
    /// <summary>
    /// Middleware for logging HTTP requests and responses with performance metrics
    /// </summary>
    public class RequestResponseLoggingMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly ILogger<RequestResponseLoggingMiddleware> _logger;

        public RequestResponseLoggingMiddleware(RequestDelegate next, ILogger<RequestResponseLoggingMiddleware> logger)
        {
            _next = next;
            _logger = logger;
        }

        public async Task InvokeAsync(HttpContext context)
        {
            var stopwatch = Stopwatch.StartNew();
            var requestId = Guid.NewGuid().ToString();
            
            // Add request ID to context for tracking
            context.Items["RequestId"] = requestId;
            
            // Log request
            await LogRequestAsync(context, requestId);
            
            // Create a new memory stream for the response body
            var originalResponseBody = context.Response.Body;
            using var responseBodyStream = new MemoryStream();
            context.Response.Body = responseBodyStream;
            
            try
            {
                await _next(context);
            }
            finally
            {
                stopwatch.Stop();
                
                // Log response
                await LogResponseAsync(context, requestId, stopwatch.ElapsedMilliseconds);
                
                // Copy response back to original stream
                responseBodyStream.Seek(0, SeekOrigin.Begin);
                await responseBodyStream.CopyToAsync(originalResponseBody);
                context.Response.Body = originalResponseBody;
            }
        }

        private async Task LogRequestAsync(HttpContext context, string requestId)
        {
            var request = context.Request;
            
            // Read request body
            var requestBody = await ReadRequestBodyAsync(request);
            
            var logData = new
            {
                RequestId = requestId,
                Method = request.Method,
                Path = request.Path.Value,
                QueryString = request.QueryString.Value,
                Headers = GetSafeHeaders(request.Headers.Select(h => new KeyValuePair<string, IEnumerable<string>>(h.Key, h.Value))),
                Body = requestBody,
                UserAgent = request.Headers["User-Agent"].ToString(),
                RemoteIP = GetClientIpAddress(context),
                User = context.User?.Identity?.Name ?? "Anonymous",
                Timestamp = DateTime.UtcNow
            };

            _logger.LogInformation("HTTP Request: {@RequestData}", logData);
        }

        private async Task LogResponseAsync(HttpContext context, string requestId, long elapsedMilliseconds)
        {
            var response = context.Response;
            
            // Read response body
            var responseBody = await ReadResponseBodyAsync(response);
            
            var logData = new
            {
                RequestId = requestId,
                StatusCode = response.StatusCode,
                Headers = GetSafeHeaders(response.Headers.ToDictionary(h => h.Key, h => h.Value.AsEnumerable())),
                Body = responseBody,
                ElapsedMilliseconds = elapsedMilliseconds,
                Timestamp = DateTime.UtcNow
            };

            var logLevel = GetLogLevelForStatusCode(response.StatusCode);
            _logger.Log(logLevel, "HTTP Response: {@ResponseData}", logData);
            
            // Log performance warning for slow requests
            if (elapsedMilliseconds > 5000) // 5 seconds
            {
                _logger.LogWarning("Slow request detected - RequestId: {RequestId}, ElapsedMs: {ElapsedMs}, Path: {Path}", 
                    requestId, elapsedMilliseconds, context.Request.Path);
            }
        }

        private async Task<string> ReadRequestBodyAsync(HttpRequest request)
        {
            if (!CanReadBody(request))
                return "[Binary Content or Empty Body]";

            request.EnableBuffering();
            var buffer = new byte[Convert.ToInt32(request.ContentLength ?? 0)];
            await request.Body.ReadAsync(buffer, 0, buffer.Length);
            request.Body.Position = 0;
            
            var bodyText = Encoding.UTF8.GetString(buffer);
            return SanitizeBody(bodyText);
        }

        private async Task<string> ReadResponseBodyAsync(HttpResponse response)
        {
            response.Body.Seek(0, SeekOrigin.Begin);
            var responseBodyText = await new StreamReader(response.Body).ReadToEndAsync();
            response.Body.Seek(0, SeekOrigin.Begin);
            
            return SanitizeBody(responseBodyText);
        }

        private bool CanReadBody(HttpRequest request)
        {
            // Don't log binary content or very large bodies
            if (request.ContentLength == null || request.ContentLength == 0)
                return false;
                
            if (request.ContentLength > 1024 * 1024) // 1MB limit
                return false;
                
            var contentType = request.ContentType?.ToLower();
            return contentType != null && (
                contentType.Contains("application/json") ||
                contentType.Contains("application/xml") ||
                contentType.Contains("text/") ||
                contentType.Contains("application/x-www-form-urlencoded")
            );
        }

        private Dictionary<string, object> GetSafeHeaders(IEnumerable<KeyValuePair<string, IEnumerable<string>>> headers)
        {
            var safeHeaders = new Dictionary<string, object>();
            var sensitiveHeaders = new[] { "authorization", "cookie", "x-api-key", "x-auth-token" };
            
            foreach (var header in headers)
            {
                var key = header.Key.ToLower();
                if (sensitiveHeaders.Contains(key))
                {
                    safeHeaders[header.Key] = "[REDACTED]";
                }
                else
                {
                    safeHeaders[header.Key] = string.Join(", ", header.Value);
                }
            }
            
            return safeHeaders;
        }

        private string SanitizeBody(string body)
        {
            if (string.IsNullOrWhiteSpace(body))
                return "[Empty]";
                
            // Limit body size for logging
            if (body.Length > 4000)
                body = body.Substring(0, 4000) + "... [TRUNCATED]";
                
            // Remove or mask sensitive data (basic implementation)
            var sensitivePatterns = new[]
            {
                @"""password"":\s*""[^""]*""",
                @"""token"":\s*""[^""]*""",
                @"""apiKey"":\s*""[^""]*""",
                @"""secret"":\s*""[^""]*"""
            };
            
            foreach (var pattern in sensitivePatterns)
            {
                body = System.Text.RegularExpressions.Regex.Replace(body, pattern, 
                    match => match.Value.Substring(0, match.Value.IndexOf(':') + 1) + " \"[REDACTED]\"",
                    System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            }
            
            return body;
        }

        private string GetClientIpAddress(HttpContext context)
        {
            return context.Request.Headers["X-Forwarded-For"].FirstOrDefault() ??
                   context.Request.Headers["X-Real-IP"].FirstOrDefault() ??
                   context.Connection.RemoteIpAddress?.ToString() ??
                   "Unknown";
        }

        private LogLevel GetLogLevelForStatusCode(int statusCode)
        {
            return statusCode switch
            {
                >= 200 and < 300 => LogLevel.Information,
                >= 300 and < 400 => LogLevel.Information,
                >= 400 and < 500 => LogLevel.Warning,
                >= 500 => LogLevel.Error,
                _ => LogLevel.Information
            };
        }
    }

    /// <summary>
    /// Extension method to register the request/response logging middleware
    /// </summary>
    public static class RequestResponseLoggingMiddlewareExtensions
    {
        public static IApplicationBuilder UseRequestResponseLogging(this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<RequestResponseLoggingMiddleware>();
        }
    }
}