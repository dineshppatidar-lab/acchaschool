using System;
using System.ComponentModel;

namespace SchoolManagementApp.Api.Validators
{
    // Backward-compatible aliases — validators now live in ApplicationCore module folders.
    // These stubs exist so existing Api references continue to compile.

    [Obsolete("Use SchoolManagementApp.ApplicationCore.Fees.Validators.FeeValidator")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public class FeeValidator : SchoolManagementApp.ApplicationCore.Fees.Validators.FeeValidator { }

    [Obsolete("Use SchoolManagementApp.ApplicationCore.Fees.Validators.PaymentValidator")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public class PaymentValidator : SchoolManagementApp.ApplicationCore.Fees.Validators.PaymentValidator { }

    [Obsolete("Use SchoolManagementApp.ApplicationCore.Fees.Validators.CreateFeeStructureRequestValidator")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public class CreateFeeStructureRequestValidator : SchoolManagementApp.ApplicationCore.Fees.Validators.CreateFeeStructureRequestValidator { }

    [Obsolete("Use SchoolManagementApp.ApplicationCore.Fees.Validators.CreateInstallmentRequestValidator")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public class CreateInstallmentRequestValidator : SchoolManagementApp.ApplicationCore.Fees.Validators.CreateInstallmentRequestValidator { }

    [Obsolete("Use SchoolManagementApp.ApplicationCore.Fees.Validators.ProcessPaymentRequestValidator")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public class ProcessPaymentRequestValidator : SchoolManagementApp.ApplicationCore.Fees.Validators.ProcessPaymentRequestValidator { }

    [Obsolete("Use SchoolManagementApp.ApplicationCore.Fees.Validators.FeePaymentValidator")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public class FeePaymentValidator : SchoolManagementApp.ApplicationCore.Fees.Validators.FeePaymentValidator { }

    [Obsolete("Use SchoolManagementApp.ApplicationCore.Fees.Validators.CreateScholarshipRequestValidator")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public class CreateScholarshipRequestValidator : SchoolManagementApp.ApplicationCore.Fees.Validators.CreateScholarshipRequestValidator { }

    [Obsolete("Use SchoolManagementApp.ApplicationCore.Fees.Validators.CreateExpenseRequestValidator")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public class CreateExpenseRequestValidator : SchoolManagementApp.ApplicationCore.Fees.Validators.CreateExpenseRequestValidator { }

    [Obsolete("Use SchoolManagementApp.ApplicationCore.Fees.Validators.CreateBudgetRequestValidator")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public class CreateBudgetRequestValidator : SchoolManagementApp.ApplicationCore.Fees.Validators.CreateBudgetRequestValidator { }
}
