using System;
using System.ComponentModel;

namespace SchoolManagementApp.Api.Validators
{
    // Backward-compatible aliases — validators now live in ApplicationCore module folders.
    // These stubs exist so existing Api references continue to compile.

    [Obsolete("Use SchoolManagementApp.ApplicationCore.Transport.Validators.VehicleValidator")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public class VehicleValidator : SchoolManagementApp.ApplicationCore.Transport.Validators.VehicleValidator { }

    [Obsolete("Use SchoolManagementApp.ApplicationCore.Transport.Validators.BusRouteValidator")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public class BusRouteValidator : SchoolManagementApp.ApplicationCore.Transport.Validators.BusRouteValidator { }

    [Obsolete("Use SchoolManagementApp.ApplicationCore.Transport.Validators.RouteStopValidator")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public class RouteStopValidator : SchoolManagementApp.ApplicationCore.Transport.Validators.RouteStopValidator { }

    [Obsolete("Use SchoolManagementApp.ApplicationCore.Transport.Validators.BusAttendanceValidator")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public class BusAttendanceValidator : SchoolManagementApp.ApplicationCore.Transport.Validators.BusAttendanceValidator { }

    [Obsolete("Use SchoolManagementApp.ApplicationCore.Students.Validators.RegisterUserDtoValidator")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public class RegisterUserDtoValidator : SchoolManagementApp.ApplicationCore.Students.Validators.RegisterUserDtoValidator { }

    [Obsolete("Use SchoolManagementApp.ApplicationCore.Students.Validators.LoginRequestValidator")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public class LoginRequestValidator : SchoolManagementApp.ApplicationCore.Students.Validators.LoginRequestValidator { }

    [Obsolete("Use SchoolManagementApp.ApplicationCore.Students.Validators.QuickMarkRequestValidator")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public class QuickMarkRequestValidator : SchoolManagementApp.ApplicationCore.Students.Validators.QuickMarkRequestValidator { }

    [Obsolete("Use SchoolManagementApp.ApplicationCore.Students.Validators.FeeReminderRequestValidator")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public class FeeReminderRequestValidator : SchoolManagementApp.ApplicationCore.Students.Validators.FeeReminderRequestValidator { }

    [Obsolete("Use SchoolManagementApp.ApplicationCore.Setup.Validators.CreateAcademicYearRequestValidator")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public class CreateAcademicYearRequestValidator : SchoolManagementApp.ApplicationCore.Setup.Validators.CreateAcademicYearRequestValidator { }

    [Obsolete("Use SchoolManagementApp.ApplicationCore.Setup.Validators.ClassRequestValidator")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public class ClassRequestValidator : SchoolManagementApp.ApplicationCore.Setup.Validators.ClassRequestValidator { }

    [Obsolete("Use SchoolManagementApp.ApplicationCore.Setup.Validators.CreateClassesRequestValidator")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public class CreateClassesRequestValidator : SchoolManagementApp.ApplicationCore.Setup.Validators.CreateClassesRequestValidator { }

    [Obsolete("Use SchoolManagementApp.ApplicationCore.Setup.Validators.SubjectRequestValidator")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public class SubjectRequestValidator : SchoolManagementApp.ApplicationCore.Setup.Validators.SubjectRequestValidator { }

    [Obsolete("Use SchoolManagementApp.ApplicationCore.Setup.Validators.CreateSubjectsRequestValidator")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public class CreateSubjectsRequestValidator : SchoolManagementApp.ApplicationCore.Setup.Validators.CreateSubjectsRequestValidator { }

    [Obsolete("Use SchoolManagementApp.ApplicationCore.Setup.Validators.PaymentMethodRequestValidator")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public class PaymentMethodRequestValidator : SchoolManagementApp.ApplicationCore.Setup.Validators.PaymentMethodRequestValidator { }

    [Obsolete("Use SchoolManagementApp.ApplicationCore.Setup.Validators.CreatePaymentMethodsRequestValidator")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public class CreatePaymentMethodsRequestValidator : SchoolManagementApp.ApplicationCore.Setup.Validators.CreatePaymentMethodsRequestValidator { }
}
