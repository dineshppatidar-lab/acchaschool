using IEmailService = SchoolManagementApp.ApplicationCore.Communication.Interfaces.IEmailService;
using ISmsService = SchoolManagementApp.ApplicationCore.Communication.Interfaces.ISmsService;

namespace SchoolManagementApp.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class DailyOpsController : ControllerBase
    {
        private readonly ApplicationDbContext _db;
        private readonly ILogger<DailyOpsController> _logger;

        public DailyOpsController(ApplicationDbContext db, ILogger<DailyOpsController> logger)
        {
            _db = db;
            _logger = logger;
        }

        [HttpGet("summary")] // GET api/dailyops/summary?date=2025-01-01&academicYearId=3
        [RequirePermission(Permission.DashboardView, requireRead: true)]
        public async Task<IActionResult> GetSummary([FromQuery] DateTime? date, [FromQuery] int? academicYearId)
        {
            var d = (date ?? DateTime.Today).Date;

            // Students (optionally scoped to the selected academic year)
            var studentQuery = _db.Students.AsQueryable();
            if (academicYearId.HasValue && academicYearId.Value > 0)
                studentQuery = studentQuery.Where(s => s.AcademicYearId == academicYearId.Value);

            var totalStudents = await studentQuery.CountAsync();
            var studentIds = await studentQuery.Select(s => s.Id).ToListAsync();
            var presentStudents = await _db.Attendances.CountAsync(a => a.Date == d && a.StudentId != null && studentIds.Contains(a.StudentId.Value) && a.IsPresent);
            var absentStudents = totalStudents - presentStudents;

            // Staff
            var totalStaff = await _db.Staff.CountAsync();
            var staffPresent = await _db.Attendances.CountAsync(a => a.Date == d && a.StaffId != null && a.IsPresent);
            var staffAbsent = totalStaff - staffPresent;

            // Transport (simple heuristics)
            var busesRunning = await _db.BusRoutes.CountAsync();
            var busesOnTime = busesRunning; // TODO: Use GPS/stop arrival times when available

            // Fees
            var feesDueToday = await _db.Fees.CountAsync(f => f.DueDate.Date == d && f.Status != "Paid");
            var feesOverdue = await _db.Fees.CountAsync(f => f.DueDate.Date < d && f.Status != "Paid");

            // Announcements today (_announcements are tenant-scoped, not year-scoped)
            var announcements = await _db.Announcements
                .Where(a => a.IsActive && (a.ValidFrom == null || a.ValidFrom <= d) && (a.ValidTo == null || a.ValidTo >= d))
                .OrderByDescending(a => a.CreatedOn)
                .Select(a => new DailyAnnouncementDto
                {
                    Id = a.Id,
                    Title = a.Title,
                    Type = a.Type.ToString(),
                    Priority = a.Priority.ToString(),
                    CreatedOn = a.CreatedOn
                }).ToListAsync();

            // Events happening today or upcoming within 7 days
            var events = await _db.Events
                .Where(e => e.StartDate.Date <= d.AddDays(7) && e.EndDate.Date >= d)
                .OrderBy(e => e.StartDate)
                .Select(e => new UpcomingEventDto
                {
                    Id = e.Id,
                    Title = e.Title,
                    StartDate = e.StartDate,
                    EndDate = e.EndDate,
                    Location = e.Location
                }).ToListAsync();

            var dto = new DailySummaryDto
            {
                Date = d,
                TotalStudents = totalStudents,
                PresentStudents = presentStudents,
                AbsentStudents = absentStudents,
                StaffPresent = staffPresent,
                StaffAbsent = staffAbsent,
                FeesDueToday = feesDueToday,
                FeesOverdue = feesOverdue,
                BusesRunning = busesRunning,
                BusesOnTime = busesOnTime,
                Announcements = announcements,
                Events = events
            };

            return Ok(dto);
        }

        [HttpPost("attendance/quick-mark")] // Mark present by list, others absent implicitly
        [RequirePermission(Permission.ClassesEdit, requireWrite: true)]
        public async Task<IActionResult> QuickMark([FromBody] QuickMarkRequest req)
        {
            var date = req.Date.Date;

            // Load class + section students (scoped to the current tenant via
            // the global query filter — never trust client-side student ids,
            // they could belong to another tenant).
            var students = await _db.Students
                .Where(s => s.ClassId == req.ClassId && s.SectionId == req.SectionId)
                .ToListAsync();

            if (students.Count == 0)
            {
                return Ok(new { message = "No enrolled students found for this class & section", total = 0, present = 0 });
            }

            var studentIds = students.Select(s => s.Id).ToHashSet();
            var presentSet = req.PresentStudentIds.ToHashSet();

            /* Root-cause fix for "Save Attendance not saving / duplicating":
               the old delete-then-reinsert walked straight into the global
               soft-delete hook. Hard deletes are converted to IsDeleted=1 for
               every entity (Attendance isn't in the hard-delete carve-out
               list), and queries filter !IsDeleted — so the DELETE was really
               a row ISOLATION: the old rows stayed but became invisible, and
               every re-mark kept INSERTING fresh rows. Attendance grew
               unboundedly and history/analytics drifted.

               Correct approach: fetch the existing rows for these students on
               this date (query filter scoping them to the current tenant),
               UPDATE them in place, and INSERT only for students that have no
               row yet. Idempotent re-mark, no duplicates, natural update
               semantics when attendance already exists for the date. */
            var existing = await _db.Attendances
                .Where(a => a.Date == date && a.StudentId != null && studentIds.Contains(a.StudentId.Value))
                .ToDictionaryAsync(a => a.StudentId!.Value);

            foreach (var s in students)
            {
                var isPresent = presentSet.Contains(s.Id);
                if (existing.TryGetValue(s.Id, out var row))
                {
                    row.IsPresent = isPresent;   // update in place
                    row.Remarks = "QuickMark";
                }
                else
                {
                    _db.Attendances.Add(new Attendance
                    {
                        Date = date,
                        StudentId = s.Id,
                        IsPresent = isPresent,
                        Remarks = "QuickMark"
                    });
                }
            }

            await _db.SaveChangesAsync();
            var updated = existing.Count;
            var inserted = students.Count - updated;
            return Ok(new { message = "Attendance quick-marked", total = students.Count, present = presentSet.Count, updated, inserted });
        }

        [HttpGet("attendance/history")] // GET api/dailyops/attendance/history?classId=1&sectionId=1&fromDate=2025-01-01&toDate=2025-01-31
        [RequirePermission(Permission.DashboardView, requireRead: true)]
        public async Task<IActionResult> GetAttendanceHistory(
            [FromQuery] int? classId,
            [FromQuery] int? sectionId,
            [FromQuery] DateTime? fromDate,
            [FromQuery] DateTime? toDate)
        {
            var from = (fromDate ?? DateTime.Today.AddDays(-30)).Date;
            var to = (toDate ?? DateTime.Today).Date;

            // Build the base query for attendance records with student info
            var query = _db.Attendances
                .Where(a => a.StudentId != null && a.Student != null && a.Date >= from && a.Date <= to)
                .Include(a => a.Student)
                    .ThenInclude(s => s!.Class)
                .Include(a => a.Student)
                    .ThenInclude(s => s!.Section)
                .AsQueryable();

            // Optional filters
            if (classId.HasValue)
                query = query.Where(a => a.Student != null && a.Student.ClassId == classId.Value);
            if (sectionId.HasValue)
                query = query.Where(a => a.Student != null && a.Student.SectionId == sectionId.Value);

            var records = await query
                .OrderByDescending(a => a.Date)
                .ThenBy(a => a.Student!.FirstName)
                .Take(500) // Cap at 500 records to prevent unbounded queries
                .Select(a => new AttendanceHistoryDto
                {
                    Date = a.Date,
                    StudentId = a.StudentId!.Value,
                    StudentName = a.Student!.FirstName + " " + a.Student.LastName,
                    RollNumber = a.Student.RollNumber ?? "",
                    ClassId = a.Student.ClassId,
                    ClassName = a.Student.Class != null ? a.Student.Class.Name : "",
                    SectionId = a.Student.SectionId,
                    SectionName = a.Student.Section != null ? a.Student.Section.Name : "",
                    IsPresent = a.IsPresent,
                    Remarks = a.Remarks ?? ""
                })
                .ToListAsync();

            var presentCount = records.Count(r => r.IsPresent);
            var total = records.Count;

            var response = new AttendanceHistoryResponseDto
            {
                Records = records,
                TotalRecords = total,
                PresentCount = presentCount,
                AbsentCount = total - presentCount,
                AttendancePercentage = total > 0 ? Math.Round((decimal)presentCount / total * 100, 1) : 0
            };

            return Ok(response);
        }

        [HttpPost("fees/remind")] // Send reminders to selected students' parents
        [RequirePermission(Permission.FeesCollect, requireWrite: true)]
    public async Task<IActionResult> SendFeeReminders([FromBody] FeeReminderRequest req, [FromServices] IEmailService email, [FromServices] ISmsService sms)
        {
            // Pull minimal data for recipients
            var recipients = await _db.Students
                .Include(s => s.Parent)
                .Where(s => req.StudentIds.Contains(s.Id))
                .Select(s => new { s.Id, s.FirstName, s.LastName, Parent = s.Parent })
                .ToListAsync();

            int sent = 0;
            foreach (var r in recipients)
            {
                var msg = string.IsNullOrWhiteSpace(req.Message)
                    ? $"Dear Parent, fees for {r.FirstName} {r.LastName} are due. Please pay at the earliest."
                    : req.Message;
            }

        if (req.Channel == "Email")
        {
            var emails = recipients.Select(r => r.Parent?.Email).Where(e => !string.IsNullOrWhiteSpace(e)).ToList();
            if (emails.Any()) { await email.SendBulkEmailAsync(emails, "Fee Reminder", req.Message ?? "Fee Reminder", isHtml: false); sent = emails.Count; }
        }
        else if (req.Channel == "SMS")
        {
            var phones = recipients.Select(r => r.Parent?.PhoneNumber).Where(p => !string.IsNullOrWhiteSpace(p)).ToList();
            if (phones.Any()) { await sms.SendBulkSmsAsync(phones, req.Message ?? "Fee Reminder"); sent = phones.Count; }
        }
        else if (req.Channel == "Push")
        {
            // TODO: Integrate push notifications
        }

            return Ok(new { message = "Reminders processed", total = recipients.Count, sent });
        }
    }
}
