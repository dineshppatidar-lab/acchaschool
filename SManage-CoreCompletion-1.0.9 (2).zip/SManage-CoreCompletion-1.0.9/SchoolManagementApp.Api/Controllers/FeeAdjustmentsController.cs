
using SchoolManagementApp.ApplicationCore.Communication.Interfaces;
using SchoolManagementApp.ApplicationCore.Fees.Interfaces;

namespace SchoolManagementApp.Api.Controllers
{
    [ApiController]
    [Authorize]
    [Route("api/advancedfinance/adjustments")]
    public class FeeAdjustmentsController : BaseApiController
    {
        private readonly IAdvancedFeeCalculationService _feeCalculationService;
        private readonly IStudentFeeAdjustmentRepository _adjustmentRepository;
        private readonly ILogger<FeeAdjustmentsController> _logger;

        public FeeAdjustmentsController(
            IAdvancedFeeCalculationService feeCalculationService,
            IStudentFeeAdjustmentRepository adjustmentRepository,
            ILogger<FeeAdjustmentsController> logger) : base(logger)
        {
            _feeCalculationService = feeCalculationService;
            _adjustmentRepository = adjustmentRepository;
            _logger = logger;
        }

        // ==================== WAIVER ENDPOINTS ====================

        /// <summary>
        /// Apply full fee waiver for a student
        /// </summary>
        [HttpPost("waivers")]
        [RequirePermission(Permission.FeesManageStructure, requireWrite: true)]
        public async Task<ActionResult<ApiResponse<StudentFeeAdjustmentDto>>> CreateWaiver(
            [FromBody] CreateWaiverRequest request)
        {
            try
            {
                LogAction($"Creating full waiver for student {request.StudentId}, category: {request.WaiverCategory}");

                var waiver = await _feeCalculationService.CreateOrUpdateWaiverAsync(request);

                return Ok(new ApiResponse<StudentFeeAdjustmentDto>
                {
                    Success = true,
                    Message = $"Full fee waiver created successfully ({waiver.WaiverCategory})",
                    Data = MapToDto(waiver)
                });
            }
            catch (Exception ex)
            {
                LogError(ex, "Error creating waiver");
                return BadRequest(new ApiResponse<StudentFeeAdjustmentDto>
                {
                    Success = false,
                    Message = ex.Message
                });
            }
        }

        /// <summary>
        /// Get active waiver for a student
        /// </summary>
        [HttpGet("waivers/student/{studentId}")]
        [RequirePermission(Permission.FeesView, requireRead: true)]
        public async Task<ActionResult<ApiResponse<StudentFeeAdjustmentDto>>> GetStudentWaiver(int studentId, int academicYearId)
        {
            try
            {
                var waiver = await _adjustmentRepository.GetActiveWaiverAsync(studentId, academicYearId);

                if (waiver == null)
                    return Ok(new ApiResponse<StudentFeeAdjustmentDto>
                    {
                        Success = true,
                        Message = "No active waiver found",
                        Data = null
                    });

                return Ok(new ApiResponse<StudentFeeAdjustmentDto>
                {
                    Success = true,
                    Data = MapToDto(waiver)
                });
            }
            catch (Exception ex)
            {
                LogError(ex, "Error retrieving waiver");
                return BadRequest(new ApiResponse<StudentFeeAdjustmentDto> { Message = ex.Message });
            }
        }

        // ==================== DISCOUNT ENDPOINTS ====================

        /// <summary>
        /// Create percentage or fixed amount discount for a student
        /// </summary>
        [HttpPost("discounts")]
        [RequirePermission(Permission.FeesManageStructure, requireWrite: true)]
        public async Task<ActionResult<ApiResponse<StudentFeeAdjustmentDto>>> CreateDiscount(
            [FromBody] CreateDiscountRequest request)
        {
            try
            {
                LogAction($"Creating discount for student {request.StudentId}, " +
                    $"Type: {(request.IsPercentage ? request.DiscountValue + "%" : "₹" + request.DiscountValue)}");

                var discount = await _feeCalculationService.CreateOrUpdateDiscountAsync(request);

                return Ok(new ApiResponse<StudentFeeAdjustmentDto>
                {
                    Success = true,
                    Message = "Discount created successfully",
                    Data = MapToDto(discount)
                });
            }
            catch (Exception ex)
            {
                LogError(ex, "Error creating discount");
                return BadRequest(new ApiResponse<StudentFeeAdjustmentDto> { Message = ex.Message });
            }
        }

        /// <summary>
        /// Get all active discounts for a student
        /// </summary>
        [HttpGet("discounts/student/{studentId}")]
        [RequirePermission(Permission.FeesView, requireRead: true)]
        public async Task<ActionResult<ApiResponse<IEnumerable<StudentFeeAdjustmentDto>>>> GetStudentDiscounts(
            int studentId, int academicYearId)
        {
            try
            {
                var discounts = await _adjustmentRepository.GetActiveDiscountsAsync(studentId, academicYearId);

                return Ok(new ApiResponse<IEnumerable<StudentFeeAdjustmentDto>>
                {
                    Success = true,
                    Data = discounts.Select(MapToDto).ToList()
                });
            }
            catch (Exception ex)
            {
                LogError(ex, "Error retrieving discounts");
                return BadRequest(new ApiResponse<IEnumerable<StudentFeeAdjustmentDto>> { Message = ex.Message });
            }
        }

        // ==================== CALCULATION ENDPOINTS ====================

        /// <summary>
        /// Calculate final fees after all adjustments
        /// </summary>
        [HttpGet("calculate-final-fees")]
        [RequirePermission(Permission.FeesView, requireRead: true)]
        public async Task<ActionResult<ApiResponse<StudentFinalFeeDto>>> CalculateFinalFees(int studentId, int academicYearId)
        {
            try
            {
                var finalFees = await _feeCalculationService.CalculateFinalStudentFeesAsync(studentId, academicYearId);

                return Ok(new ApiResponse<StudentFinalFeeDto>
                {
                    Success = true,
                    Message = "Final fees calculated successfully",
                    Data = finalFees
                });
            }
            catch (Exception ex)
            {
                LogError(ex, "Error calculating final fees");
                return BadRequest(new ApiResponse<StudentFinalFeeDto> { Message = ex.Message });
            }
        }

        /// <summary>
        /// Calculate outstanding balance for a student
        /// </summary>
        [HttpGet("outstanding-balance")]
        [RequirePermission(Permission.FeesView, requireRead: true)]
        public async Task<ActionResult<ApiResponse<object>>> GetOutstandingBalance(int studentId, int academicYearId)
        {
            try
            {
                var outstanding = await _feeCalculationService.CalculateOutstandingBalanceAsync(studentId, academicYearId);

                return Ok(new ApiResponse<object>
                {
                    Success = true,
                    Data = new { Outstanding = outstanding }
                });
            }
            catch (Exception ex)
            {
                LogError(ex, "Error calculating outstanding balance");
                return BadRequest(new ApiResponse<object> { Message = ex.Message });
            }
        }

        // ==================== ADJUSTMENT MANAGEMENT ====================

        /// <summary>
        /// Revoke/deactivate an adjustment (waiver or discount)
        /// </summary>
        [HttpPost("revoke/{adjustmentId}")]
        [RequirePermission(Permission.FeesManageStructure, requireWrite: true)]
        public async Task<ActionResult<ApiResponse<object>>> RevokeAdjustment(int adjustmentId)
        {
            try
            {
                LogAction($"Revoking adjustment {adjustmentId}");

                var success = await _feeCalculationService.RevokeAdjustmentAsync(adjustmentId);

                if (!success)
                    return NotFound(new ApiResponse<object> { Message = "Adjustment not found" });

                return Ok(new ApiResponse<object>
                {
                    Success = true,
                    Message = "Adjustment revoked successfully"
                });
            }
            catch (Exception ex)
            {
                LogError(ex, "Error revoking adjustment");
                return BadRequest(new ApiResponse<object> { Message = ex.Message });
            }
        }

        /// <summary>
        /// Get all adjustments for a student
        /// </summary>
        [HttpGet("student/{studentId}")]
        [RequirePermission(Permission.FeesView, requireRead: true)]
        public async Task<ActionResult<ApiResponse<IEnumerable<StudentFeeAdjustmentDto>>>> GetStudentAdjustments(
            int studentId, int academicYearId)
        {
            try
            {
                var adjustments = await _feeCalculationService.GetStudentAdjustmentsAsync(studentId, academicYearId);

                return Ok(new ApiResponse<IEnumerable<StudentFeeAdjustmentDto>>
                {
                    Success = true,
                    Data = adjustments.Select(MapToDto).ToList()
                });
            }
            catch (Exception ex)
            {
                LogError(ex, "Error retrieving adjustments");
                return BadRequest(new ApiResponse<IEnumerable<StudentFeeAdjustmentDto>> { Message = ex.Message });
            }
        }

        // ==================== HELPER METHODS ====================

        private StudentFeeAdjustmentDto MapToDto(StudentFeeAdjustment adj)
        {
            return new StudentFeeAdjustmentDto
            {
                Id = adj.Id,
                StudentId = adj.StudentId,
                AdjustmentType = adj.AdjustmentType,
                IsPercentage = adj.IsPercentage,
                DiscountPercentage = adj.DiscountPercentage,
                DiscountAmount = adj.DiscountAmount,
                MaximumCap = adj.MaximumCap,
                IsFullWaiver = adj.IsFullWaiver,
                WaiverCategory = adj.WaiverCategory,
                EffectiveDate = adj.EffectiveDate,
                ExpiryDate = adj.ExpiryDate,
                Status = adj.Status,
                Remarks = adj.Remarks
            };
        }
    }
 
}
