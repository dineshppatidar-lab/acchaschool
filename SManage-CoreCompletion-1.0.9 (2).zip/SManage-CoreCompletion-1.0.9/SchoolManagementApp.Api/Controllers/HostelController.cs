using ClosedXML.Excel;
using SchoolManagementApp.ApplicationCore.Hostel.Interfaces;
using SchoolManagementApp.Infrastructure.Repositories;

namespace SchoolManagementApp.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class HostelController : BaseApiController
    {
        private readonly IHostelRepository _hostelRepository;
        private readonly ApplicationDbContext _context;
        public HostelController(IHostelRepository hostelRepository, ApplicationDbContext context, ILogger<HostelController> logger)
            : base(logger)
        {
            _hostelRepository = hostelRepository;
            _context = context;
        }
        [HttpGet]
        [RequirePermission(Permission.HostelView, requireRead: true)]
        public async Task<IActionResult> GetHostels([FromQuery] int page = 1, [FromQuery] int pageSize = 10, [FromQuery] string sort = "Name", [FromQuery] string order = "asc", [FromQuery] string search = "")
        {
            try
            {
                LogAction($"Getting hostels - Page: {page}, PageSize: {pageSize}");
                var (hostels, total) = await _hostelRepository.GetHostelsAsync(page, pageSize, sort, order, search);
                return PaginatedResult(hostels.ToList(), total, page, pageSize, "Hostels retrieved successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error retrieving hostels");
                return ErrorResult("Failed to retrieve hostels");
            }
        }

        [HttpGet("{id}")]
        [RequirePermission(Permission.HostelView, requireRead: true)]
        public async Task<IActionResult> GetHostel(int id)
        {
            try
            {
                LogAction($"Getting hostel {id}");
                var hostel = await _hostelRepository.GetHostelByIdAsync(id);
                if (hostel == null)
                {
                    return NotFoundResult($"Hostel with ID {id} not found");
                }
                return SuccessResult(hostel, "Hostel retrieved successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error retrieving hostel {id}");
                return ErrorResult("Failed to retrieve hostel");
            }
        }

        [HttpPost]
        [RequirePermission(Permission.HostelManageRooms, requireWrite: true)]
        public async Task<IActionResult> CreateHostel([FromBody] Hostel hostel)
        {
            try
            {
                LogAction($"Creating hostel: {hostel.Name}");
                var createdHostel = await _hostelRepository.CreateHostelAsync(hostel);
                return CreatedResult(createdHostel, "Hostel created successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error creating hostel");
                return ErrorResult("Failed to create hostel");
            }
        }

        [HttpPut("{id}")]
        [RequirePermission(Permission.HostelManageRooms, requireWrite: true)]
        public async Task<IActionResult> UpdateHostel(int id, [FromBody] Hostel hostel)
        {
            try
            {
                LogAction($"Updating hostel {id}");
                if (id != hostel.Id)
                {
                    return ValidationErrorResult(new List<string> { "ID mismatch" }, "Invalid request");
                }
                await _hostelRepository.UpdateHostelAsync(hostel);
                return SuccessResult(hostel, "Hostel updated successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error updating hostel {id}");
                return ErrorResult("Failed to update hostel");
            }
        }

        [HttpDelete("{id}")]
        [RequirePermission(Permission.HostelManageRooms, requireDelete: true)]
        public async Task<IActionResult> DeleteHostel(int id)
        {
            try
            {
                LogAction($"Deleting hostel {id}");
                await _hostelRepository.DeleteHostelAsync(id);
                return SuccessResult(new { message = "Hostel deleted successfully" }, "Hostel deleted");
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error deleting hostel {id}");
                return ErrorResult("Failed to delete hostel");
            }
        }

        // Audit issue #29: the UI advertised export/import but the endpoints were
        // missing and dropdowns relied on hardcoded default values. Implemented
        // following the StaffImportExportController ClosedXML pattern.
        [HttpGet("export")]
        [RequirePermission(Permission.HostelView, requireRead: true)]
        public async Task<IActionResult> ExportHostels()
        {
            try
            {
                var hostels = await _context.Hostels.AsNoTracking()
                    .OrderBy(h => h.Name).ToListAsync();
                var rooms = await _context.Set<HostelRoom>().AsNoTracking().ToListAsync();

                using var workbook = new XLWorkbook();
                var ws = workbook.AddWorksheet("Hostels");
                ws.Cell(1, 1).Value = "Name";
                ws.Cell(1, 2).Value = "Type";
                ws.Cell(1, 3).Value = "Address";
                ws.Cell(1, 4).Value = "Capacity";
                var row = 2;
                foreach (var h in hostels)
                {
                    ws.Cell(row, 1).Value = h.Name;
                    ws.Cell(row, 2).Value = h.Type;
                    ws.Cell(row, 3).Value = h.Address;
                    ws.Cell(row, 4).Value = h.Capacity;
                    row++;
                }

                var sheet2 = workbook.AddWorksheet("Rooms");
                sheet2.Cell(1, 1).Value = "Hostel";
                sheet2.Cell(1, 2).Value = "RoomNumber";
                sheet2.Cell(1, 3).Value = "Capacity";
                sheet2.Cell(1, 4).Value = "Occupied";
                sheet2.Cell(1, 5).Value = "RoomType";
                sheet2.Cell(1, 6).Value = "MonthlyFee";
                row = 2;
                foreach (var r in rooms)
                {
                    sheet2.Cell(row, 1).Value = hostels.FirstOrDefault(h => h.Id == r.HostelId)?.Name ?? string.Empty;
                    sheet2.Cell(row, 2).Value = r.RoomNumber;
                    sheet2.Cell(row, 3).Value = r.Capacity;
                    sheet2.Cell(row, 4).Value = r.Occupied;
                    sheet2.Cell(row, 5).Value = r.RoomType;
                    sheet2.Cell(row, 6).Value = r.MonthlyFee;
                    row++;
                }

                using var stream = new MemoryStream();
                workbook.SaveAs(stream);
                var contentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                var bytes = stream.ToArray();
                return File(bytes, contentType, $"hostels_{DateTime.UtcNow:yyyyMMdd}.xlsx");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error exporting hostels");
                return ErrorResult("Failed to export hostels");
            }
        }

        [HttpPost("import")]
        [RequirePermission(Permission.HostelManageRooms, requireWrite: true)]
        public async Task<IActionResult> ImportHostels(IFormFile file)
        {
            try
            {
                if (file == null || file.Length == 0)
                    return ValidationErrorResult(new List<string> { "File is required" }, "Invalid upload");

                using var stream = new MemoryStream();
                await file.CopyToAsync(stream);
                stream.Position = 0;
                using var workbook = new XLWorkbook(stream);
                var ws = workbook.Worksheet(1);

                var created = 0;
                var skipped = 0;
                var errors = new List<string>();
                var existing = (await _context.Hostels.AsNoTracking().ToListAsync())
                    .Select(h => h.Name.Trim().ToLowerInvariant()).ToHashSet();

                foreach (var excelRow in ws.RowsUsed().Skip(1))
                {
                    var name = excelRow.Cell(1).GetString().Trim();
                    if (name.Length == 0) { skipped++; continue; }
                    if (existing.Contains(name.ToLowerInvariant())) { skipped++; errors.Add($"'{name}' already exists — skipped"); continue; }

                    var hostel = new Hostel
                    {
                        Name = name,
                        Type = excelRow.Cell(2).GetString().Trim(),
                        Address = excelRow.Cell(3).GetString().Trim(),
                        Capacity = excelRow.Cell(4).GetString() is string capStr && int.TryParse(capStr, out var cap) ? cap : 0
                    };
                    _context.Hostels.Add(hostel);
                    existing.Add(name.ToLowerInvariant());
                    created++;
                }
                await _context.SaveChangesAsync();

                return SuccessResult(new { created, skipped, errors }, $"Imported {created} hostels ({skipped} skipped)");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error importing hostels");
                return ErrorResult("Failed to import hostels");
            }
        }
    }
}
