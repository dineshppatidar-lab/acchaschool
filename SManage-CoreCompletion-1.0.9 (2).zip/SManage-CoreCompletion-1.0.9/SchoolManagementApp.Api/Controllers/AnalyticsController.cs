using SchoolManagementApp.ApplicationCore.Analytics.Interfaces;

namespace SchoolManagementApp.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class AnalyticsController : BaseApiController
    {
        private readonly IAnalyticsService _analyticsService;

        public AnalyticsController(
            IAnalyticsService analyticsService,
            ILogger<AnalyticsController> logger) : base(logger)
        {
            _analyticsService = analyticsService;
        }

        // Dashboard Analytics
        [HttpGet("dashboard/overview")]
        [RequirePermission(Permission.DashboardView, requireRead: true)]
        public async Task<IActionResult> GetDashboardOverview()
        {
            try
            {
                LogAction("Getting dashboard overview analytics");
                var overview = await _analyticsService.GetDashboardOverviewAsync();
                return SuccessResult(overview, "Dashboard overview retrieved successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error retrieving dashboard overview");
                return ErrorResult("Failed to retrieve dashboard overview");
            }
        }

        [HttpGet("performance-trends")]
        [RequirePermission(Permission.AnalyticsView, requireRead: true)]
        public async Task<IActionResult> GetPerformanceTrends([FromQuery] int? classId = null, [FromQuery] int months = 6)
        {
            try
            {
                LogAction($"Getting performance trends - Class: {classId}, Months: {months}");
                var analysis = await _analyticsService.GetPerformanceTrendsAsync(classId, months);
                return SuccessResult(analysis, "Performance trends retrieved successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error retrieving performance trends");
                return ErrorResult("Failed to retrieve performance trends");
            }
        }

        [HttpGet("attendance/analytics")]
        [RequirePermission(Permission.AnalyticsView, requireRead: true)]
        public async Task<IActionResult> GetAttendanceAnalytics([FromQuery] int? classId = null, [FromQuery] int? studentId = null)
        {
            try
            {
                LogAction($"Getting attendance analytics - Class: {classId}, Student: {studentId}");
                var analytics = await _analyticsService.GetAttendanceAnalyticsAsync(classId, studentId);
                return SuccessResult(analytics, "Attendance analytics retrieved successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error retrieving attendance analytics");
                return ErrorResult("Failed to retrieve attendance analytics");
            }
        }

        [HttpGet("financial/analytics")]
        [RequirePermission(Permission.FeesReports, requireRead: true)]
        public async Task<IActionResult> GetFinancialAnalytics([FromQuery] int months = 12)
        {
            try
            {
                LogAction($"Getting financial analytics for {months} months");
                var analytics = await _analyticsService.GetFinancialAnalyticsAsync(months);
                return SuccessResult(analytics, "Financial analytics retrieved successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error retrieving financial analytics");
                return ErrorResult("Failed to retrieve financial analytics");
            }
        }

        [HttpGet("students/performance-distribution")]
        [RequirePermission(Permission.AnalyticsView, requireRead: true)]
        public async Task<IActionResult> GetStudentPerformanceDistribution([FromQuery] int? classId = null)
        {
            try
            {
                LogAction($"Getting student performance distribution - Class: {classId}");
                var distribution = await _analyticsService.GetStudentPerformanceDistributionAsync(classId);
                return SuccessResult(distribution, "Performance distribution retrieved successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error retrieving student performance distribution");
                return ErrorResult("Failed to retrieve performance distribution");
            }
        }

        [HttpGet("staff/performance")]
        [RequirePermission(Permission.StaffView, requireRead: true)]
        public async Task<IActionResult> GetStaffPerformance()
        {
            try
            {
                LogAction("Getting staff performance analytics");
                var performance = await _analyticsService.GetStaffPerformanceAsync();
                return SuccessResult(performance, "Staff performance retrieved successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error retrieving staff performance");
                return ErrorResult("Failed to retrieve staff performance");
            }
        }

        [HttpGet("absenteeism-risk")]
        [RequirePermission(Permission.AnalyticsView, requireRead: true)]
        public async Task<IActionResult> GetAbsenteeismRisk()
        {
            try
            {
                LogAction("Getting absenteeism risk analytics");
                var risk = await _analyticsService.GetAbsenteeismRiskAsync();
                return SuccessResult(risk, "Absenteeism risk analysis retrieved successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error retrieving absenteeism risk");
                return ErrorResult("Failed to retrieve absenteeism risk");
            }
        }

        [HttpGet("predictive/insights")]
        [RequirePermission(Permission.AnalyticsView, requireRead: true)]
        public async Task<IActionResult> GetPredictiveInsights()
        {
            try
            {
                LogAction("Getting predictive analytics insights");
                var insights = await _analyticsService.GetPredictiveInsightsAsync();
                return SuccessResult(insights, "Predictive insights retrieved successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error retrieving predictive insights");
                return ErrorResult("Failed to retrieve predictive insights");
            }
        }
    }
}
