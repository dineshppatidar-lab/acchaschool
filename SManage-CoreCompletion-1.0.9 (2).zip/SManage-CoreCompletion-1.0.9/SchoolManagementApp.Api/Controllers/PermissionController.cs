// RBAC Permission Management Controller — thin HTTP mapper over PermissionAdminService
// (docs/critical-issues/09-controller-service-refactoring.md, risk priority #1).
// No DbContext here: all business logic, tenant guards, and audit logging live in
// ApplicationCore.Permissions.Services.PermissionAdminService, which returns Result
// objects this controller maps to HTTP responses.
using SchoolManagementApp.ApplicationCore.Common;
using SchoolManagementApp.ApplicationCore.Permissions.Dtos;
using SchoolManagementApp.ApplicationCore.Permissions.Services;
using PermissionLevel = SchoolManagementApp.ApplicationCore.Permissions.Interfaces.PermissionLevel;
using IPermissionService = SchoolManagementApp.ApplicationCore.Permissions.Interfaces.IPermissionService;

namespace SchoolManagementApp.Api.Controllers
{
    [ApiController]
    [Route("api/permissions")]
    // Previous state: the guard here was commented out and the class had NO
    // [Authorize] — with no global fallback policy, the entire RBAC root of trust
    // (role permission CRUD, user overrides, any user's permission levels) was
    // callable anonymously and from any tenant.
    [Authorize]
    public class PermissionController : ControllerBase
    {
        private readonly PermissionAdminService _admin;
        private readonly IPermissionService _permissionService;

        public PermissionController(PermissionAdminService admin, IPermissionService permissionService)
        {
            _admin = admin;
            _permissionService = permissionService;
        }

        // ── Role permissions ─────────────────────────────────────────────

        /// <summary>Get all permissions for a specific role (persisted, or defaults).</summary>
        [HttpGet("roles/{role}")]
        [Authorize(Roles = "Administrator,SuperAdmin")]
        public async Task<ActionResult<List<RolePermissionDto>>> GetRolePermissions(UserRole role)
        {
            var result = await _admin.GetRolePermissionsAsync(role);
            return result.IsSuccess ? Ok(result.Value) : ToHttp(result);
        }

        /// <summary>Update role permission.</summary>
        [HttpPost("roles/{role}/{permission}")]
        [Authorize(Roles = "Administrator,SuperAdmin")]
        public async Task<ActionResult> UpdateRolePermission(
            UserRole role, Permission permission, [FromBody] UpdateRolePermissionRequest request)
        {
            var result = await _admin.UpdateRolePermissionAsync(
                role, permission, request.CanRead, request.CanWrite, request.CanDelete);
            return result.IsSuccess ? Ok(true) : ToHttp(result);
        }

        /// <summary>Update multiple role permissions at once.</summary>
        [HttpPost("roles/{role}/bulk")]
        [Authorize(Roles = "Administrator,SuperAdmin")]
        public async Task<ActionResult> BulkUpdateRolePermissions(UserRole role, [FromBody] List<BulkUpdatePermissionRequest> requests)
        {
            var result = await _admin.BulkUpdateRolePermissionsAsync(role, requests ?? new List<BulkUpdatePermissionRequest>());
            return result.IsSuccess ? Ok(true) : ToHttp(result);
        }

        /// <summary>Reset role permissions to default.</summary>
        [HttpPost("roles/{role}/reset")]
        [Authorize(Roles = "Administrator,SuperAdmin")]
        public async Task<ActionResult> ResetRolePermissions(UserRole role)
        {
            var result = await _admin.ResetRolePermissionsAsync(role);
            return result.IsSuccess ? Ok(true) : ToHttp(result);
        }

        /// <summary>Reset selected permissions (module) to defaults for a role.</summary>
        [HttpPost("roles/{role}/reset-module")]
        [Authorize(Roles = "Administrator,SuperAdmin")]
        public async Task<ActionResult> ResetRoleModulePermissions(UserRole role, [FromBody] ResetModuleRequest request)
        {
            var result = await _admin.ResetRoleModulePermissionsAsync(role, request?.Permissions ?? Array.Empty<Permission>());
            return result.IsSuccess ? Ok(true) : ToHttp(result);
        }

        // ── User permission overrides ────────────────────────────────────

        /// <summary>Get user-specific permission overrides.</summary>
        [HttpGet("users/{userId}/overrides")]
        [Authorize(Roles = "Administrator,SuperAdmin")]
        public async Task<ActionResult<List<UserPermissionOverride>>> GetUserPermissionOverrides(int userId)
        {
            var result = await _admin.GetUserOverridesAsync(userId);
            return result.IsSuccess ? Ok(result.Value) : ToHttp(result);
        }

        /// <summary>Grant specific permission to a user.</summary>
        [HttpPost("users/{userId}/grant")]
        [Authorize(Roles = "Administrator,SuperAdmin")]
        public async Task<ActionResult> GrantUserPermission(int userId, [FromBody] GrantUserPermissionRequest request)
        {
            var result = await _admin.GrantUserPermissionAsync(
                userId, request.Permission, request.CanRead, request.CanWrite, request.CanDelete);
            return result.IsSuccess ? Ok(true) : ToHttp(result);
        }

        /// <summary>Revoke specific permission from a user.</summary>
        [HttpPost("users/{userId}/revoke")]
        [Authorize(Roles = "Administrator,SuperAdmin")]
        public async Task<ActionResult> RevokeUserPermission(int userId, [FromBody] RevokeUserPermissionRequest request)
        {
            var result = await _admin.RevokeUserPermissionAsync(userId, request.Permission);
            return result.IsSuccess ? Ok(true) : ToHttp(result);
        }

        // ── Computed permissions & metadata ──────────────────────────────

        /// <summary>
        /// Get computed permission levels for a specific user.
        /// Used by the frontend permission service to determine what the current user can do.
        /// A user may read their OWN levels; reading another user's requires Administrator
        /// or SuperAdmin (prevents cross-user/cross-tenant permission probing).
        /// </summary>
        [HttpGet("user/{userId}")]
        public async Task<ActionResult<Dictionary<Permission, PermissionLevel>>> GetUserPermissions(int userId)
        {
            if (!CanAccessUserPermissionData(userId))
            {
                return Forbid();
            }

            try
            {
                var levels = await _permissionService.GetUserPermissionLevelsAsync(userId);
                return Ok(levels);
            }
            catch (Exception ex)
            {
                return BadRequest($"Error retrieving user permissions: {ex.Message}");
            }
        }

        /// <summary>Get all available permissions.</summary>
        [HttpGet("all")]
        public ActionResult<IEnumerable<object>> GetAllPermissions()
        {
            var permissions = Enum.GetValues<Permission>()
                .Select(p => new { Value = (int)p, Name = p.ToString(), Description = DescribePermission(p) })
                .ToList();
            return Ok(permissions);
        }

        /// <summary>Get all available user roles.</summary>
        [HttpGet("roles")]
        public ActionResult<IEnumerable<object>> GetAllRoles()
        {
            var roles = Enum.GetValues<UserRole>()
                .Select(r => new { Value = (int)r, Name = r.ToString(), Description = DescribeRole(r) })
                .ToList();
            return Ok(roles);
        }

        /// <summary>Lightweight POST endpoint to validate connectivity (non-mutating).</summary>
        [HttpPost("ping")]
        [AllowAnonymous]
        public ActionResult<object> Ping()
        {
            return Ok(new { status = "ok", timestamp = DateTime.UtcNow });
        }

        // ── Unified role summary ─────────────────────────────────────────

        /// <summary>Unified role summary (permissions + menu visibility) for the admin page.</summary>
        [HttpGet("role-summary/{role}")]
        [Authorize(Roles = "Administrator,SuperAdmin")]
        public async Task<ActionResult<RoleSummaryDto>> GetRoleSummary(UserRole role)
        {
            var result = await _admin.GetRoleSummaryAsync(role);
            return result.IsSuccess ? Ok(result.Value) : ToHttp(result);
        }

        private ActionResult ToHttp(Result result)
        {
            return result.ErrorType switch
            {
                ResultErrorType.NotFound => NotFound(new { message = result.Error }),
                ResultErrorType.Validation => BadRequest(new { message = result.Error }),
                ResultErrorType.Conflict => Conflict(new { message = result.Error }),
                ResultErrorType.Forbidden => Forbid(),
                _ => StatusCode(500, new { message = result.Error })
            };
        }

        /// <summary>
        /// True when the caller may read the permission levels for `userId`:
        /// their own id, or any Administrator/SuperAdmin.
        /// </summary>
        private bool CanAccessUserPermissionData(int userId)
        {
            var roles = User.FindAll(System.Security.Claims.ClaimTypes.Role)
                .Concat(User.FindAll("role"))
                .Select(c => c.Value)
                .ToHashSet(StringComparer.OrdinalIgnoreCase);
            if (roles.Contains("Administrator") || roles.Contains("SuperAdmin"))
            {
                return true;
            }

            var userIdClaim = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)
                ?? User.FindFirst("sub")
                ?? User.FindFirst("id");
            return userIdClaim != null && int.TryParse(userIdClaim.Value, out var callerId) && callerId == userId;
        }

        private static string DescribePermission(Permission permission)
        {
            return permission switch
            {
                Permission.UsersView => "View user accounts and profiles",
                Permission.UsersCreate => "Create new user accounts",
                Permission.UsersEdit => "Edit existing user accounts",
                Permission.UsersDelete => "Delete user accounts",
                Permission.UsersManageRoles => "Manage user roles and permissions",
                Permission.StudentsView => "View student information",
                Permission.StudentsCreate => "Add new students",
                Permission.StudentsEdit => "Edit student information",
                Permission.StudentsDelete => "Remove students",
                Permission.StudentsViewDetails => "View detailed student information",
                Permission.StudentsManageAdmissions => "Manage student admissions",
                Permission.StaffView => "View staff information",
                Permission.StaffCreate => "Add new staff members",
                Permission.StaffEdit => "Edit staff information",
                Permission.StaffDelete => "Remove staff members",
                Permission.StaffManagePayroll => "Manage staff payroll",
                _ => "Permission description not available"
            };
        }

        private static string DescribeRole(UserRole role)
        {
            return role switch
            {
                UserRole.SuperAdmin => "Full system access and control",
                UserRole.Administrator => "Administrative access to most features",
                UserRole.Principal => "Principal-level access to school operations",
                UserRole.VicePrincipal => "Vice Principal access to academic operations",
                UserRole.Teacher => "Teacher access to classes and students",
                UserRole.Staff => "General staff access to relevant features",
                UserRole.Student => "Student access to personal information and resources",
                UserRole.Parent => "Parent access to child's information",
                UserRole.Librarian => "Library management access",
                UserRole.Accountant => "Financial management access",
                UserRole.Receptionist => "Reception and basic administrative access",
                _ => "Role description not available"
            };
        }
    }
}
