/*

namespace SchoolManagementApp.Api.Core.Entities.Payroll
{
    // DEPRECATED: Use SchoolManagementApp.Core.Models.SalaryComponent instead
    public class SalaryComponent : ITenantEntity
    {
        public int Id { get; set; }
        public int TenantId { get; set; }
        
        public int SalaryStructureId { get; set; }
        
        public string Name { get; set; } = string.Empty; // e.g., "Health Insurance", "Transport Allowance"
        public ComponentType Type { get; set; }
        
        public decimal Amount { get; set; }
        public bool IsPercentage { get; set; } // If true, Amount is calculated as % of BasicSalary
        
        // Audit tracking properties
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        public int CreatedBy { get; set; }
        public DateTime? UpdatedAt { get; set; }
        public int? UpdatedBy { get; set; }

        // Navigation properties
        public virtual SalaryStructure SalaryStructure { get; set; } = null!;
    }
}
*/