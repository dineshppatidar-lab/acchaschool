using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Options;
using SchoolManagementApp.Api.Attributes;
using SchoolManagementApp.Api.Common;
using SchoolManagementApp.ApplicationCore._Entities;
using SchoolManagementApp.Infrastructure.Integrations.Email;
// Ambiguity guard: two IEmailService interfaces exist (legacy ApplicationCore.Interfaces.*
// and the canonical Communication.Interfaces.*). Match TenantService/AuthService convention.
using IEmailService = SchoolManagementApp.ApplicationCore.Communication.Interfaces.IEmailService;

namespace SchoolManagementApp.Api.Controllers
{
    /// <summary>
    /// Admin-only endpoints for diagnosing the email subsystem:
    /// reports the configured transport (SMTP / Hostinger Mail API) and
    /// sends a test email through whichever transport is active.
    /// Guarded by SystemManage (Administrators + SuperAdmin only).
    /// </summary>
    [Authorize]
    [ApiController]
    [Route("api/email-admin")]
    [Produces("application/json")]
    public class EmailAdminController : BaseApiController
    {
        private readonly IEmailService _emailService;
        private readonly EmailSettings _emailSettings;
        private readonly ITenantProvider _tenantProvider;

        public EmailAdminController(
            IEmailService emailService,
            IOptions<EmailSettings> emailSettings,
            ITenantProvider tenantProvider,
            ILogger<EmailAdminController> logger) : base(logger)
        {
            _emailService = emailService;
            _emailSettings = emailSettings.Value;
            _tenantProvider = tenantProvider;
        }

        /// <summary>
        /// Reports the active email transport configuration (secrets are never returned).
        /// </summary>
        [HttpGet("health")]
        [RequirePermission(Permission.SystemManage)]
        public ActionResult<ApiResponse<EmailHealthDto>> GetHealth()
        {
            var transport = (_emailSettings.Transport ?? "Smtp").Trim();
            var isApi = transport.Equals("HostingerApi", StringComparison.OrdinalIgnoreCase);

            var dto = new EmailHealthDto
            {
                Transport = isApi ? "HostingerApi" : "Smtp",
                FromEmail = _emailSettings.FromEmail,
                FromName = _emailSettings.FromName,
                // SMTP diagnostics — never expose the password itself
                SmtpHost = _emailSettings.SmtpHost,
                SmtpPort = _emailSettings.SmtpPort,
                SmtpUsernameConfigured = !string.IsNullOrWhiteSpace(_emailSettings.SmtpUsername),
                SmtpPasswordConfigured = !string.IsNullOrWhiteSpace(_emailSettings.SmtpPassword),
                // Hostinger API diagnostics — never expose the token itself
                ApiBaseUrl = _emailSettings.ApiBaseUrl,
                ApiTokenConfigured = !string.IsNullOrWhiteSpace(_emailSettings.ApiToken),
                ApiMailboxResourceId = _emailSettings.ApiMailboxResourceId
            };

            return SuccessResponse(dto, "Email configuration loaded");
        }

        /// <summary>
        /// Sends a test email through the active transport to verify end-to-end delivery.
        /// </summary>
        [HttpPost("send-test")]
        [RequirePermission(Permission.SystemManage, requireWrite: true)]
        public async Task<ActionResult<ApiResponse<EmailTestResultDto>>> SendTestEmail(
            [FromBody] SendTestEmailRequest request)
        {
            if (string.IsNullOrWhiteSpace(request?.ToEmail))
            {
                return ValidationErrorResponse<EmailTestResultDto>(
                    new List<string> { "Recipient email is required" });
            }

            var tenantId = _tenantProvider.TenantId;
            var transport = (_emailSettings.Transport ?? "Smtp").Trim();
            var transportLabel = transport.Equals("HostingerApi", StringComparison.OrdinalIgnoreCase)
                ? "Hostinger Mail API"
                : "SMTP";

            _logger.LogInformation(
                "Test email requested by user {UserId} (tenant {TenantId}) to {ToEmail} via {Transport}",
                User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value
                    ?? User.FindFirst("sub")?.Value ?? "unknown",
                tenantId, request.ToEmail, transportLabel);

            try
            {
                var subject = "Email Test — School Management System";
                var body = $@"
                    <div style='font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; border: 1px solid #e0e0e0; border-radius: 10px; overflow: hidden;'>
                        <div style='background: linear-gradient(135deg, #1565C0 0%, #0D47A1 100%); color: white; padding: 24px; text-align: center;'>
                            <h1 style='margin: 0; font-size: 22px;'>Email Configuration Test</h1>
                        </div>
                        <div style='padding: 24px; line-height: 1.6; color: #333;'>
                            <p>This is a test email sent from the School Management System admin panel.</p>
                            <div style='background-color: #f8fafc; padding: 16px; border-radius: 8px;'>
                                <p style='margin: 4px 0;'><strong>Transport:</strong> {transportLabel}</p>
                                <p style='margin: 4px 0;'><strong>From:</strong> {System.Net.WebUtility.HtmlEncode(_emailSettings.FromEmail)}</p>
                                <p style='margin: 4px 0;'><strong>Sent at:</strong> {DateTime.UtcNow:u}</p>
                            </div>
                            <p style='color: #666; font-size: 13px;'>If you received this message, the email configuration is working correctly.</p>
                        </div>
                    </div>";

                await _emailService.SendEmailAsync(request.ToEmail, subject, body, isHtml: true);

                return SuccessResponse(new EmailTestResultDto
                {
                    Success = true,
                    Transport = transportLabel,
                    SentTo = request.ToEmail,
                    SentAtUtc = DateTime.UtcNow
                }, $"Test email queued via {transportLabel} to {request.ToEmail}");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Test email to {ToEmail} via {Transport} failed", request.ToEmail, transportLabel);
                return SuccessResponse(new EmailTestResultDto
                {
                    Success = false,
                    Transport = transportLabel,
                    SentTo = request.ToEmail,
                    SentAtUtc = DateTime.UtcNow,
                    Error = ex.Message
                }, "Test email failed — see error details");
            }
        }
    }

    // ── DTOs ──────────────────────────────────────────────────────────────

    public class EmailHealthDto
    {
        public string Transport { get; set; } = "Smtp";
        public string FromEmail { get; set; } = string.Empty;
        public string FromName { get; set; } = string.Empty;

        // SMTP (password is never included)
        public string SmtpHost { get; set; } = string.Empty;
        public int SmtpPort { get; set; }
        public bool SmtpUsernameConfigured { get; set; }
        public bool SmtpPasswordConfigured { get; set; }

        // Hostinger Mail API (token is never included)
        public string ApiBaseUrl { get; set; } = string.Empty;
        public bool ApiTokenConfigured { get; set; }
        public string ApiMailboxResourceId { get; set; } = string.Empty;
    }

    public class SendTestEmailRequest
    {
        public string ToEmail { get; set; } = string.Empty;
    }

    public class EmailTestResultDto
    {
        public bool Success { get; set; }
        public string Transport { get; set; } = string.Empty;
        public string SentTo { get; set; } = string.Empty;
        public DateTime SentAtUtc { get; set; }
        public string? Error { get; set; }
    }
}
