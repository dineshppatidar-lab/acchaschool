using System.Net;
using Microsoft.AspNetCore.Mvc;
using SchoolManagementApp.ApplicationCore.Authentication.Dtos;
using SchoolManagementApp.ApplicationCore.Common.Exceptions;
using SchoolManagementApp.ApplicationCore.Services.Interfaces;
using SchoolManagementApp.ApplicationCore.Entities;

namespace SchoolManagementApp.Api.Controllers
{
    [Authorize]
    public class UsersController : BaseApiController
    {
        private readonly IUserService _userService;

        public UsersController(IUserService userService, ILogger<UsersController> logger) : base(logger)
        {
            _userService = userService;
        }

        [HttpGet("profile")]
        public async Task<IActionResult> GetProfile()
        {
            try
            {
                var userIdStr = GetCurrentUserId() ?? User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
                if (string.IsNullOrEmpty(userIdStr) || !int.TryParse(userIdStr, out int userId))
                {
                    return UnauthorizedResult("User ID not found in token");
                }

                LogAction($"Getting profile for current user ID: {userId}");
                var result = await _userService.GetUserProfileAsync(userId);
                return SuccessResult(result, "Profile retrieved successfully");
            }
            catch (InvalidOperationException ex)
            {
                return NotFoundResult(ex.Message);
            }
            catch (Exception ex)
            {
                LogError(ex, "Error retrieving profile");
                return ErrorResult("An error occurred while retrieving your profile", HttpStatusCode.InternalServerError);
            }
        }

        [HttpPut("profile")]
        public async Task<IActionResult> UpdateProfile([FromBody] User profileData)
        {
            try
            {
                var userIdStr = GetCurrentUserId() ?? User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
                if (string.IsNullOrEmpty(userIdStr) || !int.TryParse(userIdStr, out int userId))
                {
                    return UnauthorizedResult("User ID not found in token");
                }

                LogAction($"Updating profile for current user ID: {userId}");
                var result = await _userService.UpdateUserProfileAsync(userId, profileData);
                LogAction($"Profile updated successfully for user ID: {userId}");
                return SuccessResult(result, "Profile updated successfully");
            }
            catch (InvalidOperationException ex)
            {
                return NotFoundResult(ex.Message);
            }
            catch (Exception ex)
            {
                LogError(ex, "Error updating profile");
                return ErrorResult("An error occurred while updating your profile", HttpStatusCode.InternalServerError);
            }
        }

        [HttpGet]
        [RequirePermission(Permission.UsersView, requireRead: true)]
        [LegacyCompatibility]
        public async Task<IActionResult> GetUsers([FromQuery] string? search = null, [FromQuery] int page = 1, [FromQuery] int pageSize = 20)
        {
            try
            {
                LogAction($"Getting users - Page: {page}, PageSize: {pageSize}, Search: {search}");
                var (users, total) = await _userService.GetUsersAsync(search, page, pageSize);
                var result = new { total, data = users };
                return CompatibleSuccessResult(result, "Users retrieved successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error retrieving users");
                return ErrorResult("An error occurred while retrieving users", HttpStatusCode.InternalServerError);
            }
        }

        [HttpGet("{id}")]
        [RequirePermission(Permission.UsersView, requireRead: true)]
        public async Task<IActionResult> GetUser(int id)
        {
            try
            {
                LogAction($"Getting user with ID: {id}");
                var user = await _userService.GetUserByIdAsync(id);
                if (user == null)
                {
                    LogAction($"User not found with ID: {id}");
                    return NotFoundResult($"User with ID {id} not found");
                }
                return SuccessResult(user, "User retrieved successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error retrieving user with ID: {id}");
                return ErrorResult("An error occurred while retrieving the user", HttpStatusCode.InternalServerError);
            }
        }

        [HttpPost]
        [RequirePermission(Permission.UsersCreate, requireWrite: true)]
        public async Task<IActionResult> CreateUser([FromBody] CreateUserRequest request)
        {
            try
            {
                LogAction($"Creating user: {request?.Username ?? "(null)"}");
                var created = await _userService.CreateUserAsync(request ?? throw new ValidationException("Request body is required."));
                LogAction($"User created successfully with ID: {created.Id}");
                return CreatedResult(created, "User created successfully");
            }
            catch (DomainException dex)
            {
                return ToActionResult(dex, $"Creating user '{request?.Username}'");
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error creating user '{request?.Username}'");
                return ErrorResult("An error occurred while creating the user", HttpStatusCode.InternalServerError);
            }
        }

        [HttpPut("{id}")]
        [RequirePermission(Permission.UsersEdit, requireWrite: true)]
        public async Task<IActionResult> UpdateUser(int id, [FromBody] UpdateUserRequest request)
        {
            try
            {
                LogAction($"Updating user with ID: {id}");
                var updated = await _userService.UpdateUserAsync(id, request ?? throw new ValidationException("Request body is required."));
                if (updated == null)
                {
                    LogAction($"User not found with ID: {id}");
                    return NotFoundResult($"User with ID {id} not found");
                }
                LogAction($"User updated successfully with ID: {id}");
                return SuccessResult(updated, "User updated successfully");
            }
            catch (DomainException dex)
            {
                return ToActionResult(dex, $"Updating user {id}");
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error updating user with ID: {id}");
                return ErrorResult("An error occurred while updating the user", HttpStatusCode.InternalServerError);
            }
        }

        [HttpDelete("{id}")]
        [RequirePermission(Permission.UsersDelete, requireDelete: true)]
        public async Task<IActionResult> DeleteUser(int id)
        {
            try
            {
                LogAction($"Deleting user with ID: {id}");
                var deleted = await _userService.DeleteUserAsync(id);
                if (!deleted)
                {
                    LogAction($"User not found for deletion with ID: {id}");
                    return NotFoundResult($"User with ID {id} not found");
                }
                LogAction($"User deleted successfully with ID: {id}");
                return SuccessResult("User deleted successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error deleting user with ID: {id}");
                return ErrorResult("An error occurred while deleting the user", HttpStatusCode.InternalServerError);
            }
        }

        /// <summary>
        /// Maps domain exceptions to their contracted HTTP status codes:
        /// 400 validation, 404 not-found, 409 duplicate. Unexpected failures
        /// stay 500; messages are always safe for clients (the exception text
        /// itself carries no credentials, SQL or stack traces).
        /// </summary>
        private IActionResult ToActionResult(DomainException exception, string operation)
        {
            LogAction($"User operation rejected ({exception.ErrorCode}) during {operation}: {exception.Message}");

            var statusCode = exception.ErrorCode switch
            {
                "NOT_FOUND" => HttpStatusCode.NotFound,
                "DUPLICATE" => HttpStatusCode.Conflict,
                "VALIDATION" => HttpStatusCode.BadRequest,
                _ => HttpStatusCode.BadRequest
            };
            return ErrorResult(exception.Message, statusCode);
        }
    }
}
