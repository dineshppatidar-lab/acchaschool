using Microsoft.AspNetCore.Http;
using SchoolManagementApp.ApplicationCore.Entities;
using SchoolManagementApp.ApplicationCore.Services.Interfaces;

namespace SchoolManagementApp.Api.Controllers
{
    /// <summary>
    /// Admin (in-app) CRUD for the School Website CMS: settings, media library,
    /// events, gallery albums/photos, achievements, news articles, promo campaigns
    /// and public admission enquiries. Everything operates on the CURRENT tenant
    /// via ITenantProvider — callers never pass a TenantId.
    /// </summary>
    /// Route is explicitly dashed to match the frontend's '/api/website-content'
    /// base (PublicWebsiteController does the same for the public side).
    [ApiController]
    [Route("api/website-content")]
    public class WebsiteContentController : BaseApiController
    {
        private readonly IWebsiteContentService _cms;

        public WebsiteContentController(IWebsiteContentService cms, ILogger<WebsiteContentController> logger) : base(logger)
        {
            _cms = cms;
        }

        // ── Settings ─────────────────────────────────────────────────────────
        [HttpGet("settings")]
        [RequirePermission(Permission.WebsiteView, requireRead: true)]
        public async Task<IActionResult> GetSettings()
            => SuccessResult(await _cms.GetSettingsAsync(), "Website settings loaded");

        [HttpPut("settings")]
        [RequirePermission(Permission.WebsiteManage, requireWrite: true)]
        public async Task<IActionResult> SaveSettings([FromBody] SchoolWebsiteSettings settings)
        {
            if (settings == null) return ValidationErrorResult(new List<string> { "Settings payload is required" });
            var saved = await _cms.SaveSettingsAsync(settings);
            LogAction("School website settings saved");
            return SuccessResult(saved, "Website settings saved");
        }

        // ── Media library ────────────────────────────────────────────────────
        [HttpPost("media")]
        [RequirePermission(Permission.WebsiteManage, requireWrite: true)]
        public async Task<IActionResult> UploadMedia(
            IFormFile file, [FromForm] string? caption, [FromForm] string? altText)
        {
            if (file == null || file.Length == 0)
                return ValidationErrorResult(new List<string> { "File is required" });

            try
            {
                var asset = await _cms.SaveUploadedMediaAsync(file, caption, altText, "website");
                LogAction("Media uploaded to website CMS", new { asset.Id, file.FileName });
                return SuccessResult(asset, "Media uploaded");
            }
            catch (InvalidOperationException ex)
            {
                return ValidationErrorResult(new List<string> { ex.Message });
            }
        }

        [HttpGet("media")]
        [RequirePermission(Permission.WebsiteView, requireRead: true)]
        public async Task<IActionResult> ListMedia([FromQuery] int page = 1, [FromQuery] int pageSize = 60)
            => SuccessResult(await _cms.ListMediaAsync(page, pageSize), "Media library loaded");

        [HttpDelete("media/{id:int}")]
        [RequirePermission(Permission.WebsiteManage, requireDelete: true)]
        public async Task<IActionResult> DeleteMedia([FromRoute] int id)
        {
            var deleted = await _cms.DeleteMediaAsync(id);
            if (deleted == 0) return NotFoundResult("Media not found");
            return SuccessResult("Media deleted");
        }

        // ── Events ───────────────────────────────────────────────────────────
        [HttpGet("events")]
        [RequirePermission(Permission.WebsiteView, requireRead: true)]
        public async Task<IActionResult> ListEvents([FromQuery] bool? published = null)
            => SuccessResult(await _cms.ListEventsAsync(published), "Events loaded");

        [HttpPost("events")]
        [RequirePermission(Permission.WebsiteManage, requireWrite: true)]
        public async Task<IActionResult> UpsertEvent([FromBody] SchoolWebsiteEvent evt)
        {
            try
            {
                var saved = await _cms.UpsertEventAsync(evt);
                LogAction("Website event saved", new { saved.Id, saved.Title });
                return SuccessResult(saved, "Event saved");
            }
            catch (InvalidOperationException ex)
            {
                return ValidationErrorResult(new List<string> { ex.Message });
            }
        }

        [HttpPut("events/{id:int}/publish")]
        [RequirePermission(Permission.WebsiteManage, requireWrite: true)]
        public async Task<IActionResult> SetEventPublished([FromRoute] int id, [FromBody] PublishRequest req)
        {
            try
            {
                var state = await _cms.SetEventPublishedAsync(id, req?.Published ?? false);
                return SuccessResult($"Event {(state ? "published" : "unpublished")}");
            }
            catch (InvalidOperationException ex)
            {
                return NotFoundResult(ex.Message);
            }
        }

        [HttpDelete("events/{id:int}")]
        [RequirePermission(Permission.WebsiteManage, requireDelete: true)]
        public async Task<IActionResult> DeleteEvent([FromRoute] int id)
        {
            try
            {
                await _cms.DeleteEventAsync(id);
                return SuccessResult("Event deleted");
            }
            catch (InvalidOperationException ex)
            {
                return NotFoundResult(ex.Message);
            }
        }

        // ── Gallery albums ───────────────────────────────────────────────────
        [HttpGet("albums")]
        [RequirePermission(Permission.WebsiteView, requireRead: true)]
        public async Task<IActionResult> ListAlbums([FromQuery] bool? published = null)
            => SuccessResult(await _cms.ListAlbumsAsync(published), "Albums loaded");

        [HttpGet("albums/{id:int}")]
        [RequirePermission(Permission.WebsiteView, requireRead: true)]
        public async Task<IActionResult> GetAlbum([FromRoute] int id)
        {
            var (album, media) = await _cms.GetAlbumAsync(id);
            return SuccessResult(new AlbumWithMedia(album, media), "Album loaded");
        }

        [HttpPost("albums")]
        [RequirePermission(Permission.WebsiteManage, requireWrite: true)]
        public async Task<IActionResult> UpsertAlbum([FromBody] UpsertAlbumRequest req)
        {
            if (req?.Album == null) return ValidationErrorResult(new List<string> { "Album payload is required" });
            try
            {
                var saved = await _cms.UpsertAlbumAsync(req.Album, req.TryPublish);
                LogAction("Website gallery album saved", new { saved.Id, saved.Title });
                return SuccessResult(saved, "Album saved");
            }
            catch (InvalidOperationException ex)
            {
                return ValidationErrorResult(new List<string> { ex.Message });
            }
        }

        [HttpPut("albums/{id:int}/publish")]
        [RequirePermission(Permission.WebsiteManage, requireWrite: true)]
        public async Task<IActionResult> SetAlbumPublished([FromRoute] int id, [FromBody] PublishRequest req)
        {
            try
            {
                var state = await _cms.SetAlbumPublishedAsync(id, req?.Published ?? false);
                return SuccessResult($"Album {(state ? "published" : "unpublished")}");
            }
            catch (InvalidOperationException ex)
            {
                return ValidationErrorResult(new List<string> { ex.Message });
            }
        }

        [HttpDelete("albums/{id:int}")]
        [RequirePermission(Permission.WebsiteManage, requireDelete: true)]
        public async Task<IActionResult> DeleteAlbum([FromRoute] int id)
        {
            try
            {
                await _cms.DeleteAlbumAsync(id);
                return SuccessResult("Album deleted");
            }
            catch (InvalidOperationException ex)
            {
                return NotFoundResult(ex.Message);
            }
        }

        // ── Album photos ─────────────────────────────────────────────────────
        [HttpPost("albums/{albumId:int}/media")]
        [RequirePermission(Permission.WebsiteManage, requireWrite: true)]
        public async Task<IActionResult> AddAlbumMedia(
            [FromRoute] int albumId, IFormFile file, [FromForm] string? caption,
            [FromForm] string? altText, [FromForm] string? videoUrl, [FromForm] int displayOrder = 0)
        {
            if (file == null || file.Length == 0)
                return ValidationErrorResult(new List<string> { "File is required" });

            try
            {
                var media = await _cms.AddAlbumMediaAsync(albumId, file, caption, altText, videoUrl, displayOrder);
                LogAction("Album photo added", new { albumId, media.Id, file.FileName });
                return SuccessResult(media, "Photo added to album");
            }
            catch (InvalidOperationException ex)
            {
                return ValidationErrorResult(new List<string> { ex.Message });
            }
        }

        [HttpPut("albums/{albumId:int}/media/reorder")]
        [RequirePermission(Permission.WebsiteManage, requireWrite: true)]
        public async Task<IActionResult> ReorderAlbumMedia(
            [FromRoute] int albumId, [FromBody] ReorderRequest req)
        {
            if (req?.OrderedMediaIds == null || req.OrderedMediaIds.Count == 0)
                return ValidationErrorResult(new List<string> { "OrderedMediaIds is required" });
            return SuccessResult(await _cms.ReorderAlbumMediaAsync(albumId, req.OrderedMediaIds), "Album photos reordered");
        }

        [HttpPut("album-media/{mediaId:int}")]
        [RequirePermission(Permission.WebsiteManage, requireWrite: true)]
        public async Task<IActionResult> UpdateAlbumMediaCaption(
            [FromRoute] int mediaId, [FromBody] UpdateMediaCaptionRequest req)
        {
            if (req == null) return ValidationErrorResult(new List<string> { "Payload is required" });
            await _cms.UpdateMediaCaptionAsync(mediaId, req.Caption, req.AltText);
            return SuccessResult("Photo caption updated");
        }

        [HttpDelete("album-media/{mediaId:int}")]
        [RequirePermission(Permission.WebsiteManage, requireDelete: true)]
        public async Task<IActionResult> DeleteAlbumMedia([FromRoute] int mediaId)
        {
            var deleted = await _cms.DeleteAlbumMediaAsync(mediaId);
            if (!deleted) return NotFoundResult("Photo not found");
            return SuccessResult("Photo removed");
        }

        // ── Achievements ─────────────────────────────────────────────────────
        [HttpGet("achievements")]
        [RequirePermission(Permission.WebsiteView, requireRead: true)]
        public async Task<IActionResult> ListAchievements([FromQuery] bool? published = null)
            => SuccessResult(await _cms.ListAchievementsAsync(published), "Achievements loaded");

        [HttpPost("achievements")]
        [RequirePermission(Permission.WebsiteManage, requireWrite: true)]
        public async Task<IActionResult> UpsertAchievement([FromBody] SchoolWebsiteAchievement achievement)
        {
            try
            {
                var saved = await _cms.UpsertAchievementAsync(achievement);
                LogAction("Website achievement saved", new { saved.Id, saved.Title });
                return SuccessResult(saved, "Achievement saved");
            }
            catch (InvalidOperationException ex)
            {
                return ValidationErrorResult(new List<string> { ex.Message });
            }
        }

        [HttpPut("achievements/{id:int}/publish")]
        [RequirePermission(Permission.WebsiteManage, requireWrite: true)]
        public async Task<IActionResult> SetAchievementPublished([FromRoute] int id, [FromBody] PublishRequest req)
        {
            try
            {
                var state = await _cms.SetAchievementPublishedAsync(id, req?.Published ?? false);
                return SuccessResult($"Achievement {(state ? "published" : "unpublished")}");
            }
            catch (InvalidOperationException ex)
            {
                return NotFoundResult(ex.Message);
            }
        }

        [HttpDelete("achievements/{id:int}")]
        [RequirePermission(Permission.WebsiteManage, requireDelete: true)]
        public async Task<IActionResult> DeleteAchievement([FromRoute] int id)
        {
            try
            {
                await _cms.DeleteAchievementAsync(id);
                return SuccessResult("Achievement deleted");
            }
            catch (InvalidOperationException ex)
            {
                return NotFoundResult(ex.Message);
            }
        }

        // ── News / articles ──────────────────────────────────────────────────
        [HttpGet("articles")]
        [RequirePermission(Permission.WebsiteView, requireRead: true)]
        public async Task<IActionResult> ListArticles(
            [FromQuery] bool? published = null, [FromQuery] string? category = null, [FromQuery] string? search = null)
            => SuccessResult(await _cms.ListArticlesAsync(published, category, search), "Articles loaded");

        [HttpPost("articles")]
        [RequirePermission(Permission.WebsiteManage, requireWrite: true)]
        public async Task<IActionResult> UpsertArticle([FromBody] SchoolWebsiteArticle article)
        {
            try
            {
                var saved = await _cms.UpsertArticleAsync(article);
                LogAction("Website article saved", new { saved.Id, saved.Title });
                return SuccessResult(saved, "Article saved");
            }
            catch (InvalidOperationException ex)
            {
                return ValidationErrorResult(new List<string> { ex.Message });
            }
        }

        [HttpPut("articles/{id:int}/publish")]
        [RequirePermission(Permission.WebsiteManage, requireWrite: true)]
        public async Task<IActionResult> SetArticlePublished([FromRoute] int id, [FromBody] PublishRequest req)
        {
            try
            {
                var state = await _cms.SetArticlePublishedAsync(id, req?.Published ?? false);
                return SuccessResult(state
                    ? "Article published"
                    : "Article scheduled/unpublished — it will go public only when publication rules allow");
            }
            catch (InvalidOperationException ex)
            {
                return ValidationErrorResult(new List<string> { ex.Message });
            }
        }

        [HttpDelete("articles/{id:int}")]
        [RequirePermission(Permission.WebsiteManage, requireDelete: true)]
        public async Task<IActionResult> DeleteArticle([FromRoute] int id)
        {
            try
            {
                await _cms.DeleteArticleAsync(id);
                return SuccessResult("Article deleted");
            }
            catch (InvalidOperationException ex)
            {
                return NotFoundResult(ex.Message);
            }
        }

        // ── Promo campaigns ──────────────────────────────────────────────────
        [HttpGet("campaigns")]
        [RequirePermission(Permission.WebsiteView, requireRead: true)]
        public async Task<IActionResult> ListCampaigns([FromQuery] string? position = null)
        {
            var parsed = ParseEnum<WebsiteCampaignPosition>(position);
            if (!string.IsNullOrWhiteSpace(position) && !parsed.HasValue)
                return ValidationErrorResult(new List<string> { $"Unknown campaign position '{position}'" });
            return SuccessResult(await _cms.ListCampaignsAsync(parsed), "Campaigns loaded");
        }

        [HttpPost("campaigns")]
        [RequirePermission(Permission.WebsiteManage, requireWrite: true)]
        public async Task<IActionResult> UpsertCampaign([FromBody] SchoolPromoCampaign campaign)
        {
            try
            {
                var saved = await _cms.UpsertCampaignAsync(campaign);
                LogAction("Website promo campaign saved", new { saved.Id, saved.Title });
                return SuccessResult(saved, "Campaign saved");
            }
            catch (InvalidOperationException ex)
            {
                return ValidationErrorResult(new List<string> { ex.Message });
            }
        }

        [HttpPut("campaigns/{id:int}/status")]
        [RequirePermission(Permission.WebsiteManage, requireWrite: true)]
        public async Task<IActionResult> SetCampaignStatus([FromRoute] int id, [FromBody] CampaignStatusRequest req)
        {
            var status = ParseEnum<WebsiteCampaignStatus>(req?.Status);
            if (!status.HasValue)
                return ValidationErrorResult(new List<string> { "Status must be one of: Draft, Scheduled, Published, Expired, Unpublished" });
            try
            {
                await _cms.SetCampaignStatusAsync(id, status.Value);
                return SuccessResult($"Campaign status set to {status.Value}");
            }
            catch (InvalidOperationException ex)
            {
                return NotFoundResult(ex.Message);
            }
        }

        [HttpDelete("campaigns/{id:int}")]
        [RequirePermission(Permission.WebsiteManage, requireDelete: true)]
        public async Task<IActionResult> DeleteCampaign([FromRoute] int id)
        {
            try
            {
                await _cms.DeleteCampaignAsync(id);
                return SuccessResult("Campaign deleted");
            }
            catch (InvalidOperationException ex)
            {
                return NotFoundResult(ex.Message);
            }
        }

        // ── Admission enquiries (admin side) ─────────────────────────────────
        [HttpGet("enquiries")]
        [RequirePermission(Permission.WebsiteView, requireRead: true)]
        public async Task<IActionResult> ListEnquiries([FromQuery] string? status = null)
        {
            var parsed = ParseEnum<WebsiteEnquiryStatus>(status);
            if (!string.IsNullOrWhiteSpace(status) && !parsed.HasValue)
                return ValidationErrorResult(new List<string> { $"Unknown enquiry status '{status}'" });
            return SuccessResult(await _cms.ListEnquiriesAsync(parsed), "Enquiries loaded");
        }

        [HttpPut("enquiries/{id:int}")]
        [RequirePermission(Permission.WebsiteManage, requireWrite: true)]
        public async Task<IActionResult> UpdateEnquiry([FromRoute] int id, [FromBody] UpdateEnquiryRequest req)
        {
            if (req == null) return ValidationErrorResult(new List<string> { "Payload is required" });
            var status = ParseEnum<WebsiteEnquiryStatus>(req.Status);
            if (!string.IsNullOrWhiteSpace(req.Status) && !status.HasValue)
                return ValidationErrorResult(new List<string> { $"Unknown enquiry status '{req.Status}'" });
            try
            {
                var updated = await _cms.UpdateEnquiryAsync(id, status, req.StaffNote);
                if (!updated) return NotFoundResult("Enquiry not found");
                return SuccessResult("Enquiry updated");
            }
            catch (InvalidOperationException ex)
            {
                return ValidationErrorResult(new List<string> { ex.Message });
            }
        }

        [HttpPost("enquiries/{id:int}/convert")]
        [RequirePermission(Permission.WebsiteManage, requireWrite: true)]
        public async Task<IActionResult> ConvertEnquiry([FromRoute] int id)
        {
            try
            {
                await _cms.ConvertEnquiryAsync(id);
                LogAction("Website enquiry converted to student enquiry", new { id });
                return SuccessResult("Enquiry converted to a student enquiry");
            }
            catch (InvalidOperationException ex)
            {
                return ValidationErrorResult(new List<string> { ex.Message });
            }
        }

        // ── Dashboard ────────────────────────────────────────────────────────
        [HttpGet("summary")]
        [RequirePermission(Permission.WebsiteView, requireRead: true)]
        public async Task<IActionResult> GetSummary()
        {
            var s = await _cms.GetSummaryAsync();
            return SuccessResult(new CmsSummaryDto(s.Albums, s.Events, s.Articles, s.Campaigns, s.PendingEnquiries, s.PublishedAlbums), "CMS summary loaded");
        }

        private static TEnum? ParseEnum<TEnum>(string? value) where TEnum : struct, Enum
        {
            if (string.IsNullOrWhiteSpace(value)) return null;
            return Enum.TryParse<TEnum>(value.Trim(), ignoreCase: true, out var parsed) ? parsed : null;
        }

        public class PublishRequest { public bool Published { get; set; } }
        public class UpsertAlbumRequest { public SchoolGalleryAlbum? Album { get; set; } public bool TryPublish { get; set; } }
        public class UpdateMediaCaptionRequest { public string? Caption { get; set; } public string? AltText { get; set; } }
        public class ReorderRequest { public List<int> OrderedMediaIds { get; set; } = new(); }
        public class CampaignStatusRequest { public string? Status { get; set; } }
        public class UpdateEnquiryRequest { public string? Status { get; set; } public string? StaffNote { get; set; } }
        public record AlbumWithMedia(SchoolGalleryAlbum Album, List<SchoolGalleryMedia> Media);
        public record CmsSummaryDto(int Albums, int Events, int Articles, int Campaigns, int PendingEnquiries, int PublishedAlbums);
    }
}
