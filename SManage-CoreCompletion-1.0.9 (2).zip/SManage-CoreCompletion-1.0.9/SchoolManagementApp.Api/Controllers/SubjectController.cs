using SchoolManagementApp.Api.Common;
using SchoolManagementApp.ApplicationCore.Academic.Dtos;
using SchoolManagementApp.ApplicationCore.Academic.Interfaces;

namespace SchoolManagementApp.Api.Controllers
{
    /// <summary>
    /// Subject listing (read-only) following the standard layering:
    /// Controller → IAcademicAppService → IAcademicRepository → DbContext.
    /// Subjects are class-scoped (Subjects.ClassId is required), so the list
    /// endpoint supports ?classId= for cascading dropdowns.
    /// </summary>
    [Authorize]
    [ApiController]
    [Route("api/academic/subjects")]
    public class SubjectController : BaseApiController
    {
        private readonly IAcademicAppService _academicAppService;

        public SubjectController(IAcademicAppService academicAppService, ILogger<SubjectController> logger)
            : base(logger)
        {
            _academicAppService = academicAppService;
        }

        /// <summary>
        /// GET api/academic/subjects?classId=5 → subjects of one class (or all)
        /// </summary>
        [HttpGet]
        [RequirePermission(Permission.SubjectsView, requireRead: true)]
        public async Task<ActionResult<ApiResponse<IEnumerable<SubjectDto>>>> GetAllSubjects([FromQuery] int? classId)
        {
            try
            {
                LogAction($"Getting subjects (classId: {classId})");
                var subjects = await _academicAppService.GetSubjectsAsync(classId);
                return SuccessResponse(subjects, "Subjects retrieved successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error retrieving subjects (classId: {classId})");
                return InternalServerErrorResponse<IEnumerable<SubjectDto>>("Failed to retrieve subjects");
            }
        }

        /// <summary>
        /// GET api/academic/subjects/class/{classId} → subjects of one class
        /// </summary>
        [HttpGet("class/{classId}")]
        [RequirePermission(Permission.SubjectsView, requireRead: true)]
        public async Task<ActionResult<ApiResponse<IEnumerable<SubjectDto>>>> GetSubjectsByClass(int classId)
        {
            try
            {
                LogAction($"Getting subjects for class {classId}");
                var subjects = await _academicAppService.GetSubjectsAsync(classId);
                return SuccessResponse(subjects, "Subjects retrieved successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error retrieving subjects for class {classId}");
                return InternalServerErrorResponse<IEnumerable<SubjectDto>>("Failed to retrieve subjects for the class");
            }
        }
    }
}