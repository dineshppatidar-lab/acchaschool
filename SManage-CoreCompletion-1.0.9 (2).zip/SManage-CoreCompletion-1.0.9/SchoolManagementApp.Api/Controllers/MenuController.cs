using SchoolManagementApp.ApplicationCore.Common.Enums;
using SchoolManagementApp.ApplicationCore.Entities;
using SchoolManagementApp.ApplicationCore.Services.Interfaces;
using SchoolManagementApp.ApplicationCore.Permissions.Interfaces;
using SchoolManagementApp.Infrastructure.Data;

namespace SchoolManagementApp.Api.Controllers
{
    /// <summary>
    /// API for dynamic menu management
    /// Provides menu items based on user permissions, tenant, and role
    /// </summary>
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class MenuController : BaseApiController
    {
        private readonly IMenuService _menuService;
        private readonly ApplicationDbContext _context;
        private readonly ApplicationCore.Permissions.Interfaces.IPermissionService _permissionService;

        public MenuController(
            IMenuService menuService,
            ApplicationDbContext context,
            ApplicationCore.Permissions.Interfaces.IPermissionService permissionService,
            ILogger<MenuController> logger)
            : base(logger)
        {
            _menuService = menuService;
            _context = context;
            _permissionService = permissionService;
        }

        private bool TryGetCurrentUserContext(out int userId, out int tenantId)
        {
            userId = 0;
            tenantId = 1;

            var userIdClaim = User.Claims.FirstOrDefault(c =>
                string.Equals(c.Type, System.Security.Claims.ClaimTypes.NameIdentifier, StringComparison.OrdinalIgnoreCase) ||
                string.Equals(c.Type, "sub", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(c.Type, "id", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(c.Type, "userId", StringComparison.OrdinalIgnoreCase));

            var tenantClaim = User.Claims.FirstOrDefault(c =>
                string.Equals(c.Type, "tenant_id", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(c.Type, "tenantId", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(c.Type, "tenantid", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(c.Type, "tenant", StringComparison.OrdinalIgnoreCase));

            if (userIdClaim != null && int.TryParse(userIdClaim.Value?.Trim(), out userId))
            {
                if (tenantClaim != null && int.TryParse(tenantClaim.Value?.Trim(), out tenantId))
                {
                    return true;
                }

                // Tokens without a tenant claim must NOT fall back to TenantId = 1 —
                // that hardcode silently rendered tenant 1's menu to every tenant's
                // users. Resolve the tenant from the authenticated user record
                // instead (the User query filter keeps this tenant-scoped).
                var resolvedUserId = userId;
                var tenantUser = _context.Users.FirstOrDefault(u => u.Id == resolvedUserId);
                if (tenantUser != null)
                {
                    tenantId = tenantUser.TenantId;
                    return true;
                }

                return true;
            }

            return false;
        }

        /// <summary>
        /// Resolves ALL of the current user's roles via the shared
        /// PermissionService.ParseRoles (alias table and JSON array supported).
        /// The DB Roles string is checked FIRST — it is the same authoritative
        /// source PermissionService evaluates role permissions against. The JWT role
        /// claim is only a fallback, because some tokens carry just the FIRST role
        /// ("Teacher" for a Teacher,Accountant user), which would silently make the
        /// one-role user's explicit deny apply as if it were the only role.
        /// multi-role users used to have only their FIRST role drive the menu pass;
        /// the pipeline now sees the complete vector and unions RoleMenuPermissions
        /// across all of them.
        /// </summary>
        private IReadOnlyList<UserRole> GetCurrentUserRoles()
        {
            // Authoritative: the user's Roles string in DB
            if (TryGetCurrentUserContext(out var userId, out _))
            {
                var user = _context.Users.FirstOrDefault(u => u.Id == userId);
                if (user != null)
                {
                    var resolved = _permissionService.ParseRoles(user.Roles);
                    if (resolved.Count > 0)
                    {
                        return resolved;
                    }
                }
            }

            // Fallback: JWT role claim(s)
            var roleClaims = User.Claims.Where(c =>
                string.Equals(c.Type, System.Security.Claims.ClaimTypes.Role, StringComparison.OrdinalIgnoreCase) ||
                string.Equals(c.Type, "role", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(c.Type, "Role", StringComparison.OrdinalIgnoreCase));

            var fromClaims = _permissionService.ParseRoles(string.Join(",", roleClaims.Select(c => c.Value)));
            if (fromClaims.Count > 0)
            {
                return fromClaims;
            }

            return new[] { UserRole.Staff }; // same deny-heavy default as before
        }

        /// <summary>
        /// Get Academic menu items (and all sub-items) for the current user.
        /// Served by the single shared effective-permission pipeline
        /// (MenuService.FilterMenuForUserAsync) so menu visibility always matches
        /// route authorization.
        /// </summary>
        [HttpGet("academic")]
        public async Task<IActionResult> GetAcademicMenu()
        {
            try
            {
                LogAction("Getting academic menu");
                if (!TryGetCurrentUserContext(out var userId, out var tenantId))
                {
                    return ValidationErrorResult(new List<string> { "User context could not be resolved from the authentication token" }, "User context missing");
                }

                var roles = GetCurrentUserRoles();

                var menuDtos = await _menuService.FilterMenuForUserAsync(userId, roles, "Academic", tenantId);

                return SuccessResult(menuDtos, "Academic menu retrieved successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error fetching academic menu");
                return ErrorResult("Error fetching menu");
            }
        }

        /// <summary>
        /// Get all main menu items (top level).
        /// Served by the single shared effective-permission pipeline.
        /// </summary>
        [HttpGet("main")]
        public async Task<IActionResult> GetMainMenu()
        {
            try
            {
                LogAction("Getting main menu");
                if (!TryGetCurrentUserContext(out var userId, out var tenantId))
                {
                    return ValidationErrorResult(new List<string> { "User context could not be resolved from the authentication token" }, "User context missing");
                }

                var roles = GetCurrentUserRoles();

                var menuDtos = await _menuService.FilterMenuForUserAsync(userId, roles, null, tenantId);

                return SuccessResult(menuDtos, "Main menu retrieved successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error fetching main menu");
                return ErrorResult("Error fetching main menu");
            }
        }

        /// <summary>
        /// Get menu items for a specific category.
        /// Served by the single shared effective-permission pipeline.
        /// </summary>
        [HttpGet("category/{category}")]
        public async Task<IActionResult> GetMenuByCategory(string category)
        {
            try
            {
                LogAction($"Getting menu for category: {category}");
                if (!TryGetCurrentUserContext(out var userId, out var tenantId))
                {
                    return ValidationErrorResult(new List<string> { "User context could not be resolved from the authentication token" }, "User context missing");
                }

                var roles = GetCurrentUserRoles();

                var menuDtos = await _menuService.FilterMenuForUserAsync(userId, roles, category, tenantId);

                return SuccessResult(menuDtos, $"Menu for category '{category}' retrieved successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error fetching menu for category: {category}");
                return ErrorResult("Error fetching menu");
            }
        }

        /// <summary>
        /// Admin endpoint: Get all menu items (unfiltered)
        /// </summary>
        [HttpGet("all")]
        [Authorize(Roles = "Administrator,SuperAdmin")]
        public async Task<IActionResult> GetAllMenuItems()
        {
            try
            {
                LogAction("Getting all menu items");
                var allItems = await _menuService.GetAllMenuItemsAsync();
                var dtos = _menuService.MapMenuItemsToDto(allItems.ToList(), new List<string>());
                return SuccessResult(dtos, "All menu items retrieved successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error fetching all menu items");
                return ErrorResult("Error fetching menu items");
            }
        }

        /// <summary>
        /// Admin endpoint: Create new menu item
        /// </summary>
        [HttpPost]
        [Authorize(Roles = "Administrator,SuperAdmin")]
        public async Task<IActionResult> CreateMenuItem([FromBody] MenuItem request)
        {
            try
            {
                LogAction($"Creating new menu item: {request.Label}");
                var created = await _menuService.CreateMenuItemAsync(request);
                return SuccessResult(created, "Menu item created successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error creating menu item");
                return ErrorResult("Error creating menu item");
            }
        }

        /// <summary>
        /// Admin endpoint: Update menu item
        /// </summary>
        [HttpPut("{id}")]
        [Authorize(Roles = "Administrator,SuperAdmin")]
        public async Task<IActionResult> UpdateMenuItem(int id, [FromBody] MenuItem request)
        {
            try
            {
                LogAction($"Updating menu item {id}");
                await _menuService.UpdateMenuItemAsync(id, request);
                return SuccessResult("Menu item updated successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error updating menu item {id}");
                return ErrorResult($"Error updating menu item {id}");
            }
        }

        /// <summary>
        /// Admin endpoint: Delete menu item
        /// </summary>
        [HttpDelete("{id}")]
        [Authorize(Roles = "Administrator,SuperAdmin")]
        public async Task<IActionResult> DeleteMenuItem(int id)
        {
            try
            {
                LogAction($"Deleting menu item {id}");
                await _menuService.DeleteMenuItemAsync(id);
                return SuccessResult("Menu item deleted successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error deleting menu item {id}");
                return ErrorResult($"Error deleting menu item {id}");
            }
        }

        /// <summary>
        /// Invalidate the frontend menu cache.
        /// Call this after permission changes to force the sidebar to reload.
        /// </summary>
        [HttpPost("invalidate-cache")]
        [Authorize(Roles = "Administrator,SuperAdmin")]
        public IActionResult InvalidateCache()
        {
            LogAction("Menu cache invalidated by admin");
            return Ok(new { success = true, message = "Menu cache invalidated. Sidebar will refresh on next load.", timestamp = DateTime.UtcNow });
        }
    }
}
