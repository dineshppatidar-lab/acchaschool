﻿﻿using Microsoft.AspNetCore.Mvc;
using SchoolManagementApp.ApplicationCore.Payroll.Interfaces;

namespace SchoolManagementApp.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    [RequirePermission(Permission.StaffManagePayroll)]
    public class PayrollController : BaseApiController
    {
        private readonly IPayrollService _payrollService;

        public PayrollController(IPayrollService payrollService, ILogger<PayrollController> logger) 
            : base(logger)
        {
            _payrollService = payrollService;
        }

        // GET: /api/payroll/runs
        [HttpGet("runs")]
        public async Task<IActionResult> GetPayrollRuns()
        {
            try
            {
                LogAction("Getting payroll runs");
                var runs = await _payrollService.GetPayrollRunsAsync();
                
                // Map to prevent JSON cycle errors and match frontend models
                var result = runs.Select(r => new {
                    id = r.Id,
                    month = r.Month,
                    year = r.Year,
                    totalAmount = r.TotalAmount,
                    status = r.Status,
                    payDate = r.PayDate
                });
                return SuccessResult(result.ToList(), "Payroll runs retrieved successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error retrieving payroll runs");
                return ErrorResult("Failed to retrieve payroll runs");
            }
        }

        // POST: /api/payroll/process
        [HttpPost("process")]
        public async Task<IActionResult> ProcessPayroll([FromBody] ProcessPayrollRequestDto request)
        {
            try
            {
                if (request == null || request.Month < 1 || request.Month > 12 || request.Year < 2000)
                {
                    return ValidationErrorResult(new List<string> { "Invalid month or year provided." }, "Validation failed");
                }

                LogAction($"Processing payroll for {request.Month}/{request.Year}");
                // Placeholder for current user id
                int userId = 1;
                await _payrollService.ProcessPayrollAsync(request.Year, request.Month, userId);
                return SuccessResult(new { message = $"Payroll for {request.Month}/{request.Year} processed successfully!" }, "Payroll processed successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error processing payroll");
                return ErrorResult("Failed to process payroll");
            }
        }

        // GET: /api/payroll/runs/{id}
        [HttpGet("runs/{id}")]
        public async Task<IActionResult> GetPayrollRunDetails(int id)
        {
            try
            {
                LogAction($"Getting payroll run details for ID: {id}");
                var runDetails = await _payrollService.GetPayrollRunDetailsAsync(id);
                if (runDetails == null) 
                    return NotFoundResult($"Payroll run with ID {id} not found");
                
                // Map to prevent JSON cycle and sync NetPay to frontend's netSalary
                var result = new {
                    id = runDetails.Id,
                    month = runDetails.Month,
                    year = runDetails.Year,
                    totalAmount = runDetails.TotalAmount,
                    status = runDetails.Status,
                    payDate = runDetails.PayDate,
                    payslips = runDetails.Payslips.Select(p => new {
                        id = p.Id,
                        staffId = p.StaffId,
                        basicSalary = p.BasicSalary,
                        netSalary = p.NetPay, // Syncs backend NetPay with frontend netSalary
                        staff = p.Staff != null ? new {
                            id = p.Staff.Id,
                            firstName = p.Staff.FirstName,
                            lastName = p.Staff.LastName
                        } : null
                    })
                };
                return SuccessResult(result, "Payroll run details retrieved successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error retrieving payroll run details for ID: {id}");
                return ErrorResult("Failed to retrieve payroll run details");
            }
        }
    }

    // DTO to capture the JSON body sent from Angular: { "year": 2026, "month": 4 }
    public class ProcessPayrollRequestDto
    {
        public int Year { get; set; }
        public int Month { get; set; }
    }
}