using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;
using SchoolManagementApp.Api.Common;
using SchoolManagementApp.ApplicationCore.Communication.WhatsApp.Interfaces;
using SchoolManagementApp.ApplicationCore.Entities;
using SchoolManagementApp.ApplicationCore._Entities;
using SchoolManagementApp.ApplicationCore._Interfaces;

namespace SchoolManagementApp.Api.Controllers
{
    // ── DTOs ─────────────────────────────────────────────────────────────

    /// <summary>Client-safe configuration payload. Secrets are write-only; only masks are returned.</summary>
    public class WhatsAppConfigDto
    {
        public int Id { get; set; }
        public bool IsEnabled { get; set; }
        public string Provider { get; set; } = "MetaCloudApi";
        public string ApiBaseUrl { get; set; } = "https://graph.facebook.com";
        public string ApiVersion { get; set; } = "v21.0";
        public string? BusinessAccountId { get; set; }
        public string? PhoneNumberId { get; set; }
        /// <summary>Write-only. Empty/null = keep existing.</summary>
        public string? AccessToken { get; set; }
        /// <summary>Read-only masked hint, e.g. "••••4f2a".</summary>
        public string? AccessTokenMask { get; set; }
        public string? SenderNumber { get; set; }

        // Arattai (only used when Provider == "Arattai")
        public string? ArattaiOauthRedirectUri { get; set; }
        public string? ArattaiCompanyId { get; set; }
        public string? ArattaiBusinessNumberId { get; set; }
        /// <summary>Read-only masked hint, e.g. "••••8f3a". Never contains the token.</summary>
        public string? ArattaiRefreshTokenMask { get; set; }

        /// <summary>Write-only.</summary>
        public string? WebhookVerifyToken { get; set; }
        public string? WebhookVerifyTokenMask { get; set; }
        /// <summary>Write-only.</summary>
        public string? WebhookSecret { get; set; }
        public string? WebhookSecretMask { get; set; }
        public string DefaultLanguageCode { get; set; } = "en";
        public string DefaultCountryCode { get; set; } = "91";
        public int RequestTimeoutSeconds { get; set; } = 30;
        public int MaxRetryAttempts { get; set; } = 3;
        public int RetryDelayMinutes { get; set; } = 5;
        public int RateLimitPerMinute { get; set; } = 30;
        public bool EnableLogging { get; set; } = true;
        public bool TestMode { get; set; }
        public string? PaymentLinkBaseUrl { get; set; }
        public string? SchoolNameOverride { get; set; }
        public string? SchoolPhone { get; set; }
        public string? SchoolEmail { get; set; }
        public DateTime? LastTestedOn { get; set; }
        public string? LastTestStatus { get; set; }
        public string? LastTestMessage { get; set; }
    }

    public class SaveWhatsAppConfigRequest
    {
        public WhatsAppConfigDto Config { get; set; } = new();
        public string? AccessToken { get; set; }
        public string? WebhookVerifyToken { get; set; }
        public string? WebhookSecret { get; set; }
        /// <summary>
        /// Write-only. Arattai OAuth refresh token produced by the one-time browser
        /// consent flow (server-side). Omit/null to keep the existing value.
        /// </summary>
        public string? ArattaiRefreshToken { get; set; }
    }

    public class WhatsAppTemplateDto
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public string MessageType { get; set; } = "FeeReminder";
        public string LanguageCode { get; set; } = "en";
        public string? ProviderTemplateName { get; set; }
        /// <summary>Arattai template ID (created in the Arattai Business Platform). Null for Meta sends.</summary>
        public string? ProviderTemplateId { get; set; }
        public string BodyText { get; set; } = string.Empty;
        public bool IsApproved { get; set; }
        public bool IsActive { get; set; } = true;
        public string? Description { get; set; }
    }

    public class WhatsAppReminderRuleDto
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public int TemplateId { get; set; }
        public string? TemplateName { get; set; }
        public bool IsEnabled { get; set; } = true;
        public string OffsetType { get; set; } = "BeforeDueDate";
        public int OffsetDays { get; set; }
        public string SendTime { get; set; } = "09:00:00";
        public int? TargetAcademicYearId { get; set; }
        public int? TargetClassId { get; set; }
        public int? TargetSectionId { get; set; }
        public decimal MinOutstandingAmount { get; set; }
        public DateTime? LastRunOn { get; set; }
    }

    public class WhatsAppBulkSendRequest
    {
        /// <summary>Student ids selected by the user.</summary>
        public List<int> StudentIds { get; set; } = new();
        public int TemplateId { get; set; }
        public string Trigger { get; set; } = "Manual";
    }

    public class WhatsAppPreviewRequest
    {
        public int? AcademicYearId { get; set; }
        public int? ClassId { get; set; }
        public int? SectionId { get; set; }
        public int? StudentId { get; set; }
        /// <summary>"due" | "overdue" | null</summary>
        public string? OverdueStatus { get; set; }
        public decimal? MinOutstanding { get; set; }
        public int? InstallmentId { get; set; }
        public int? TemplateId { get; set; }
    }

    public class WhatsAppTestMessageRequest
    {
        public string PhoneNumber { get; set; } = string.Empty;
    }

    // ── Controller ───────────────────────────────────────────────────────

    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class WhatsAppController : BaseApiController
    {
        private readonly IWhatsAppService _whatsAppService;
        private readonly ITenantProvider _tenantProvider;

        public WhatsAppController(IWhatsAppService whatsAppService, ITenantProvider tenantProvider, ILogger<WhatsAppController> logger) : base(logger)
        {
            _whatsAppService = whatsAppService;
            _tenantProvider = tenantProvider;
        }

        private int TenantId => _tenantProvider.TenantId;

        // ── Configuration ────────────────────────────────────────────────

        /// <summary>Gets the tenant's WhatsApp configuration. Secrets are returned as masks only.</summary>
        [HttpGet("config")]
        [RequirePermission(Permission.WhatsAppView, requireRead: true)]
        public async Task<ActionResult<ApiResponse<WhatsAppConfigDto>>> GetConfig()
        {
            var config = await _whatsAppService.GetOrCreateConfigurationAsync(TenantId);
            return SuccessResponse(ToDto(config), "WhatsApp configuration retrieved");
        }

        /// <summary>
        /// Saves the tenant's WhatsApp configuration. Sensitive fields are write-only:
        /// omit them (or send null/empty) to keep existing values.
        /// </summary>
        [HttpPost("config")]
        [RequirePermission(Permission.WhatsAppConfigure, requireWrite: true)]
        public async Task<ActionResult<ApiResponse<WhatsAppConfigDto>>> SaveConfig([FromBody] SaveWhatsAppConfigRequest request)
        {
            if (request.Config == null)
                return ValidationErrorResponse<WhatsAppConfigDto>(new List<string> { "Configuration payload is required." });

            var entity = new WhatsAppConfiguration
            {
                Id = request.Config.Id,
                TenantId = TenantId,
                IsEnabled = request.Config.IsEnabled,
                Provider = Enum.TryParse<WhatsAppProviderType>(request.Config.Provider, out var provider) ? provider : WhatsAppProviderType.MetaCloudApi,
                ApiBaseUrl = request.Config.ApiBaseUrl ?? "https://graph.facebook.com",
                ApiVersion = request.Config.ApiVersion ?? "v21.0",
                BusinessAccountId = request.Config.BusinessAccountId,
                PhoneNumberId = request.Config.PhoneNumberId,
                SenderNumber = request.Config.SenderNumber,
                ArattaiOauthRedirectUri = request.Config.ArattaiOauthRedirectUri,
                ArattaiCompanyId = request.Config.ArattaiCompanyId,
                ArattaiBusinessNumberId = request.Config.ArattaiBusinessNumberId,
                DefaultLanguageCode = request.Config.DefaultLanguageCode ?? "en",
                DefaultCountryCode = request.Config.DefaultCountryCode ?? "91",
                RequestTimeoutSeconds = request.Config.RequestTimeoutSeconds,
                MaxRetryAttempts = request.Config.MaxRetryAttempts,
                RetryDelayMinutes = request.Config.RetryDelayMinutes,
                RateLimitPerMinute = request.Config.RateLimitPerMinute,
                EnableLogging = request.Config.EnableLogging,
                TestMode = request.Config.TestMode,
                PaymentLinkBaseUrl = request.Config.PaymentLinkBaseUrl,
                SchoolNameOverride = request.Config.SchoolNameOverride,
                SchoolPhone = request.Config.SchoolPhone,
                SchoolEmail = request.Config.SchoolEmail
            };

            var saved = await _whatsAppService.SaveConfigurationAsync(entity, request.AccessToken, request.WebhookVerifyToken, request.WebhookSecret, request.ArattaiRefreshToken);
            return SuccessResponse(ToDto(saved), "WhatsApp configuration saved");
        }

        /// <summary>Tests the saved provider credentials with a cheap API call.</summary>
        [HttpPost("config/test")]
        [RequirePermission(Permission.WhatsAppConfigure, requireWrite: true)]
        public async Task<ActionResult<ApiResponse<WhatsAppSendResult>>> TestConnection()
        {
            var result = await _whatsAppService.TestConnectionAsync(TenantId);
            return SuccessResponse(result, result.Success ? "Connection successful" : "Connection failed");
        }

        /// <summary>Sends a free-form test message to a single number.</summary>
        [HttpPost("config/test-message")]
        [RequirePermission(Permission.WhatsAppConfigure, requireWrite: true)]
        public async Task<ActionResult<ApiResponse<WhatsAppSendResult>>> SendTestMessage([FromBody] WhatsAppTestMessageRequest request)
        {
            if (string.IsNullOrWhiteSpace(request?.PhoneNumber))
                return ValidationErrorResponse<WhatsAppSendResult>(new List<string> { "PhoneNumber is required." });

            var result = await _whatsAppService.SendTestMessageAsync(TenantId, request.PhoneNumber);
            return SuccessResponse(result, result.Success ? "Test message sent" : "Test message failed");
        }

        // ── Templates ────────────────────────────────────────────────────

        [HttpGet("templates")]
        [RequirePermission(Permission.WhatsAppView, requireRead: true)]
        public async Task<ActionResult<ApiResponse<IEnumerable<WhatsAppTemplateDto>>>> GetTemplates()
        {
            var templates = await _whatsAppService.GetTemplatesAsync(TenantId);
            return SuccessResponse(templates.Select(ToDto), "Templates retrieved");
        }

        [HttpPost("templates")]
        [RequirePermission(Permission.WhatsAppManageTemplates, requireWrite: true)]
        public async Task<ActionResult<ApiResponse<WhatsAppTemplateDto>>> SaveTemplate([FromBody] WhatsAppTemplateDto dto)
        {
            if (string.IsNullOrWhiteSpace(dto.Name) || string.IsNullOrWhiteSpace(dto.BodyText))
                return ValidationErrorResponse<WhatsAppTemplateDto>(new List<string> { "Template Name and BodyText are required." });

            var template = new WhatsAppMessageTemplate
            {
                Id = dto.Id,
                TenantId = TenantId,
                Name = dto.Name,
                MessageType = Enum.TryParse<WhatsAppMessageType>(dto.MessageType, out var mt) ? mt : WhatsAppMessageType.FeeReminder,
                LanguageCode = dto.LanguageCode ?? "en",
                ProviderTemplateName = dto.ProviderTemplateName,
                ProviderTemplateId = dto.ProviderTemplateId,
                BodyText = dto.BodyText,
                IsApproved = dto.IsApproved,
                IsActive = dto.IsActive,
                Description = dto.Description
            };

            var saved = await _whatsAppService.SaveTemplateAsync(template);
            return SuccessResponse(ToDto(saved), "Template saved");
        }

        [HttpDelete("templates/{id:int}")]
        [RequirePermission(Permission.WhatsAppManageTemplates, requireDelete: true)]
        public async Task<ActionResult<ApiResponse>> DeleteTemplate(int id)
        {
            await _whatsAppService.DeleteTemplateAsync(id);
            return SuccessResponse("Template deleted");
        }

        // ── Reminder rules (automation) ──────────────────────────────────

        [HttpGet("reminder-rules")]
        [RequirePermission(Permission.WhatsAppView, requireRead: true)]
        public async Task<ActionResult<ApiResponse<IEnumerable<WhatsAppReminderRuleDto>>>> GetReminderRules()
        {
            var rules = await _whatsAppService.GetReminderRulesAsync(TenantId);
            return SuccessResponse(rules.Select(ToDto), "Reminder rules retrieved");
        }

        [HttpPost("reminder-rules")]
        [RequirePermission(Permission.WhatsAppManageAutomation, requireWrite: true)]
        public async Task<ActionResult<ApiResponse<WhatsAppReminderRuleDto>>> SaveReminderRule([FromBody] WhatsAppReminderRuleDto dto)
        {
            if (string.IsNullOrWhiteSpace(dto.Name) || dto.TemplateId <= 0)
                return ValidationErrorResponse<WhatsAppReminderRuleDto>(new List<string> { "Rule Name and TemplateId are required." });

            var rule = new WhatsAppReminderRule
            {
                Id = dto.Id,
                TenantId = TenantId,
                Name = dto.Name,
                TemplateId = dto.TemplateId,
                IsEnabled = dto.IsEnabled,
                OffsetType = Enum.TryParse<WhatsAppReminderOffsetType>(dto.OffsetType, out var ot) ? ot : WhatsAppReminderOffsetType.BeforeDueDate,
                OffsetDays = dto.OffsetDays,
                SendTime = TimeSpan.TryParse(dto.SendTime, out var st) ? st : new TimeSpan(9, 0, 0),
                TargetAcademicYearId = dto.TargetAcademicYearId,
                TargetClassId = dto.TargetClassId,
                TargetSectionId = dto.TargetSectionId,
                MinOutstandingAmount = dto.MinOutstandingAmount
            };

            var saved = await _whatsAppService.SaveReminderRuleAsync(rule);
            return SuccessResponse(ToDto(saved), "Reminder rule saved");
        }

        [HttpDelete("reminder-rules/{id:int}")]
        [RequirePermission(Permission.WhatsAppManageAutomation, requireDelete: true)]
        public async Task<ActionResult<ApiResponse>> DeleteReminderRule(int id)
        {
            await _whatsAppService.DeleteReminderRuleAsync(id);
            return SuccessResponse("Reminder rule deleted");
        }

        // ── Recipients / preview / bulk send ─────────────────────────────

        /// <summary>
        /// Resolves outstanding-fee recipients for the given filters, including
        /// WhatsApp number validation, so the UI can preview before sending.
        /// </summary>
        [HttpPost("recipients/preview")]
        [RequirePermission(Permission.WhatsAppView, requireRead: true)]
        public async Task<ActionResult<ApiResponse<IEnumerable<WhatsAppRecipientPreview>>>> PreviewRecipients([FromBody] WhatsAppPreviewRequest request)
        {
            var recipients = await _whatsAppService.GetOutstandingFeeRecipientsAsync(
                TenantId,
                request?.AcademicYearId,
                request?.ClassId,
                request?.SectionId,
                request?.StudentId,
                request?.OverdueStatus,
                request?.MinOutstanding,
                request?.InstallmentId);

            return SuccessResponse<IEnumerable<WhatsAppRecipientPreview>>(recipients, "Recipients resolved");
        }

        /// <summary>
        /// Enqueues bulk fee reminders. Requires explicit user intent (the UI must
        /// show a confirmation step before calling this). Messages go through the
        /// queue → background worker → provider pipeline.
        /// </summary>
        [HttpPost("send/bulk")]
        [RequirePermission(Permission.WhatsAppSendBulk, requireWrite: true)]
        public async Task<ActionResult<ApiResponse<WhatsAppBulkSendResult>>> SendBulk([FromBody] WhatsAppBulkSendRequest request)
        {
            if (request?.StudentIds == null || request.StudentIds.Count == 0)
                return ValidationErrorResponse<WhatsAppBulkSendResult>(new List<string> { "At least one student must be selected." });
            if (request.TemplateId <= 0)
                return ValidationErrorResponse<WhatsAppBulkSendResult>(new List<string> { "A message template must be selected." });

            var result = await _whatsAppService.EnqueueBulkFeeRemindersAsync(
                TenantId, request.StudentIds, request.TemplateId, request.Trigger ?? "Manual",
                _tenantProvider.CurrentUserId ?? "user");

            _logger.LogInformation("WhatsApp bulk send: tenant {TenantId} queued {Queued}/{Requested} (invalid {Invalid}, duplicates {Dup})",
                TenantId, result.Queued, result.Requested, result.SkippedInvalidNumber, result.SkippedDuplicate);

            return SuccessResponse(result, $"{result.Queued} message(s) queued for sending");
        }

        /// <summary>Runs automated reminder rules for this tenant on demand (admin trigger).</summary>
        [HttpPost("automation/run")]
        [RequirePermission(Permission.WhatsAppManageAutomation, requireWrite: true)]
        public async Task<ActionResult<ApiResponse<int>>> RunAutomation()
        {
            var enqueued = await _whatsAppService.RunAutomatedRemindersAsync(CancellationToken.None);
            return SuccessResponse(enqueued, $"{enqueued} message(s) enqueued by automated rules");
        }

        /// <summary>
        /// Re-enqueues a single failed/cancelled message for a fresh send attempt.
        /// Tenant-scoped; refuses to retry messages already accepted by the provider.
        /// </summary>
        [HttpPost("history/{id:int}/retry")]
        [RequirePermission(Permission.WhatsAppSendBulk, requireWrite: true)]
        public async Task<ActionResult<ApiResponse<WhatsAppSendResult>>> RetryFailed(int id)
        {
            var result = await _whatsAppService.RetryFailedMessageAsync(TenantId, id, _tenantProvider.CurrentUserId ?? "user");
            return SuccessResponse(result, result.Success ? "Message re-queued for sending" : "Retry not possible");
        }

        // ── History ──────────────────────────────────────────────────────

        /// <summary>Paged message history for the tenant with optional filters.</summary>
        [HttpGet("history")]
        [RequirePermission(Permission.WhatsAppViewHistory, requireRead: true)]
        public async Task<ActionResult<ApiResponse<object>>> GetHistory(
            [FromQuery] int page = 1,
            [FromQuery] int pageSize = 25,
            [FromQuery] int? studentId = null,
            [FromQuery] string? status = null,
            [FromQuery] string? trigger = null)
        {
            // Tenant isolation: query the tenant-scoped set directly.
            var query = _whatsAppService.GetHistoryQuery(TenantId);

            if (studentId.HasValue) query = query.Where(m => m.StudentId == studentId.Value);
            if (Enum.TryParse<WhatsAppMessageStatus>(status, ignoreCase: true, out var st))
                query = query.Where(m => m.Status == st);
            if (Enum.TryParse<WhatsAppTriggerType>(trigger, ignoreCase: true, out var tt))
                query = query.Where(m => m.TriggerType == tt);

            var total = await query.CountAsync();
            var items = await query
                .OrderByDescending(m => m.CreatedOn)
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .Select(m => new
                {
                    m.Id,
                    m.StudentId,
                    m.StudentName,
                    m.RecipientName,
                    m.RecipientNumber,
                    MessageType = m.MessageType.ToString(),
                    Provider = m.Provider.ToString(),
                    Channel = m.Provider == WhatsAppProviderType.Arattai ? "Arattai" : "WhatsApp",
                    m.TemplateName,
                    m.TriggerType,
                    Trigger = m.TriggerType.ToString(),
                    Status = m.Status.ToString(),
                    m.FailureReason,
                    m.ProviderMessageId,
                    m.RetryCount,
                    m.OutstandingAmount,
                    m.DueDate,
                    m.SentAt,
                    m.DeliveredAt,
                    m.ReadAt,
                    m.IsTestMode,
                    m.CreatedOn
                })
                .ToListAsync();

            return SuccessResponse<object>(new { items, total, page, pageSize }, "Message history retrieved");
        }

        // ── Mapping helpers ──────────────────────────────────────────────

        private static WhatsAppConfigDto ToDto(WhatsAppConfiguration c) => new()
        {
            Id = c.Id,
            IsEnabled = c.IsEnabled,
            Provider = c.Provider.ToString(),
            ApiBaseUrl = c.ApiBaseUrl,
            ApiVersion = c.ApiVersion,
            BusinessAccountId = c.BusinessAccountId,
            PhoneNumberId = c.PhoneNumberId,
            AccessTokenMask = c.AccessTokenMask,
            SenderNumber = c.SenderNumber,
            ArattaiOauthRedirectUri = c.ArattaiOauthRedirectUri,
            ArattaiCompanyId = c.ArattaiCompanyId,
            ArattaiBusinessNumberId = c.ArattaiBusinessNumberId,
            ArattaiRefreshTokenMask = string.IsNullOrWhiteSpace(c.ArattaiRefreshTokenEncrypted) ? null : _arattaiTokenMask(c),
            WebhookVerifyTokenMask = string.IsNullOrWhiteSpace(c.WebhookVerifyTokenEncrypted) ? null : "••••set",
            WebhookSecretMask = string.IsNullOrWhiteSpace(c.WebhookSecretEncrypted) ? null : "••••set",
            DefaultLanguageCode = c.DefaultLanguageCode,
            DefaultCountryCode = c.DefaultCountryCode,
            RequestTimeoutSeconds = c.RequestTimeoutSeconds,
            MaxRetryAttempts = c.MaxRetryAttempts,
            RetryDelayMinutes = c.RetryDelayMinutes,
            RateLimitPerMinute = c.RateLimitPerMinute,
            EnableLogging = c.EnableLogging,
            TestMode = c.TestMode,
            PaymentLinkBaseUrl = c.PaymentLinkBaseUrl,
            SchoolNameOverride = c.SchoolNameOverride,
            SchoolPhone = c.SchoolPhone,
            SchoolEmail = c.SchoolEmail,
            LastTestedOn = c.LastTestedOn,
            LastTestStatus = c.LastTestStatus,
            LastTestMessage = c.LastTestMessage
        };

        private static string? _arattaiTokenMask(WhatsAppConfiguration c) =>
            string.IsNullOrWhiteSpace(c.ArattaiRefreshTokenMask) ? "••••set" : c.ArattaiRefreshTokenMask;

        private static WhatsAppTemplateDto ToDto(WhatsAppMessageTemplate t) => new()
        {
            Id = t.Id,
            Name = t.Name,
            MessageType = t.MessageType.ToString(),
            LanguageCode = t.LanguageCode,
            ProviderTemplateName = t.ProviderTemplateName,
            ProviderTemplateId = t.ProviderTemplateId,
            BodyText = t.BodyText,
            IsApproved = t.IsApproved,
            IsActive = t.IsActive,
            Description = t.Description
        };

        private static WhatsAppReminderRuleDto ToDto(WhatsAppReminderRule r) => new()
        {
            Id = r.Id,
            Name = r.Name,
            TemplateId = r.TemplateId,
            TemplateName = r.Template?.Name,
            IsEnabled = r.IsEnabled,
            OffsetType = r.OffsetType.ToString(),
            OffsetDays = r.OffsetDays,
            SendTime = r.SendTime.ToString(@"hh\:mm"),
            TargetAcademicYearId = r.TargetAcademicYearId,
            TargetClassId = r.TargetClassId,
            TargetSectionId = r.TargetSectionId,
            MinOutstandingAmount = r.MinOutstandingAmount,
            LastRunOn = r.LastRunOn
        };
    }
}
