﻿using Microsoft.AspNetCore.Authorization;
using SchoolManagementApp.ApplicationCore.Communication.Interfaces;
using SchoolManagementApp.ApplicationCore.Fees.Interfaces;
using SchoolManagementApp.ApplicationCore.Staff.Interfaces;
using System.Text;

namespace SchoolManagementApp.Api.Controllers
{
    [ApiController]
    [Authorize]
    [Route("api/advancedfinance/group-payments")]
    public class GroupPaymentController : BaseApiController
    {
        private readonly IAdvancedFeeCalculationService _feeCalculationService;
        private readonly IGroupPaymentRepository _groupPaymentRepository;
        private readonly IStaffRepository _staffRepository;
        private readonly ILogger<GroupPaymentController> _logger;

        public GroupPaymentController(
            IAdvancedFeeCalculationService feeCalculationService,
            IGroupPaymentRepository groupPaymentRepository,
            IStaffRepository staffRepository,
            ILogger<GroupPaymentController> logger) : base(logger)
        {
            _feeCalculationService = feeCalculationService;
            _groupPaymentRepository = groupPaymentRepository;
            _staffRepository = staffRepository;
            _logger = logger;
        }

        /// <summary>
        /// Initiate a group/family payment
        /// </summary>
        [HttpPost("initiate")]
        [RequirePermission(Permission.PaymentsProcess, requireWrite: true)]
        public async Task<ActionResult<ApiResponse<object>>> InitiateGroupPayment(
            [FromBody] InitiateGroupPaymentRequest request)
        {
            try
            {
                LogAction($"Initiating group payment for {request.StudentIds.Count} students");

                var groupPayment = await _feeCalculationService.InitiateGroupPaymentAsync(request);

                return Ok(new ApiResponse<object>
                {
                    Success = true,
                    Message = "Group payment initiated",
                    Data = new { GroupPaymentId = groupPayment.Id }
                });
            }
            catch (Exception ex)
            {
                LogError(ex, "Error initiating group payment");
                return BadRequest(new ApiResponse<object> { Message = ex.Message });
            }
        }

        /// <summary>
        /// Get server-side receipt metadata and allocation details for a group payment
        /// </summary>
        [HttpGet("{groupPaymentId}/receipt")]
        [RequirePermission(Permission.FeesView, requireRead: true)]
        public async Task<ActionResult<ApiResponse<GroupPaymentReceiptDto>>> GetGroupPaymentReceipt(int groupPaymentId)
        {
            try
            {
                var gp = await _groupPayment_repository_GetWithAllocations(groupPaymentId);
                if (gp == null)
                    return NotFound(new ApiResponse<GroupPaymentReceiptDto> { Message = "Group payment not found" });

                var dto = new GroupPaymentReceiptDto
                {
                    GroupPaymentId = gp.Id,
                    ReceiptNumber = gp.ReceiptNumber,
                    PaymentDate = gp.PaymentDate,
                    TotalAmountPaid = gp.TotalAmountPaid,
                    PaymentMethod = gp.PaymentMethod.ToString(),
                    TransactionId = gp.TransactionId,
                    ProcessedByStaffId = gp.ProcessedByStaffId,
                    Remarks = gp.Remarks
                };

                if (gp.ProcessedByStaffId.HasValue)
                {
                    var staff = await _staffRepository.GetByIdAsync(gp.ProcessedByStaffId.Value);
                    if (staff != null)
                        dto.ProcessedByStaffName = $"{staff.FirstName} {staff.LastName}".Trim();
                }

                foreach (var a in gp.Allocations)
                {
                    dto.Allocations.Add(new AllocationResultDto
                    {
                        StudentId = a.StudentId,
                        StudentName = a.Student != null ? $"{a.Student.FirstName} {a.Student.LastName}".Trim() : "",
                        FeeInstallmentId = a.FeeInstallmentId,
                        InstallmentName = a.FeeInstallment != null ? a.FeeInstallment.Name : "",
                        AllocatedAmount = a.AllocatedAmount,
                        ActualAmountApplied = a.ActualAmountApplied,
                        DiscountApplied = a.DiscountApplied ?? 0,
                        CreatedFeePaymentId = a.CreatedFeePaymentId
                    });
                }

                return Ok(new ApiResponse<GroupPaymentReceiptDto> { Success = true, Data = dto });
            }
            catch (Exception ex)
            {
                LogError(ex, "Error building group payment receipt");
                return BadRequest(new ApiResponse<GroupPaymentReceiptDto> { Message = ex.Message });
            }
        }

        // wrapper to call repository method with safer naming to avoid long diff churn
        private Task<GroupPayment?> _groupPayment_repository_GetWithAllocations(int id)
            => _groupPaymentRepository.GetWithAllocationsByIdAsync(id);

        /// <summary>
        /// Process group payment
        /// </summary>
        [HttpPost("process")]
        [RequirePermission(Permission.PaymentsProcess, requireWrite: true)]
        public async Task<ActionResult<ApiResponse<GroupPaymentProcessResult>>> ProcessGroupPayment(
            [FromBody] ProcessGroupPaymentRequest request)
        {
            try
            {
                LogAction($"Processing group payment {request.GroupPaymentId}");

                var result = await _feeCalculationService.ProcessGroupPaymentAsync(request);

                if (!result.Success)
                    return BadRequest(new ApiResponse<GroupPaymentProcessResult>
                    {
                        Success = false,
                        Message = result.Message,
                        Data = result
                    });

                return Ok(new ApiResponse<GroupPaymentProcessResult>
                {
                    Success = true,
                    Message = result.Message,
                    Data = result
                });
            }
            catch (Exception ex)
            {
                LogError(ex, "Error processing group payment");
                return BadRequest(new ApiResponse<GroupPaymentProcessResult> { Message = ex.Message });
            }
        }

        /// <summary>
        /// Get family payment summary
        /// </summary>
        [HttpGet("family/{familyGroupId}")]
        [RequirePermission(Permission.FeesView, requireRead: true)]
        public async Task<ActionResult<ApiResponse<FamilyPaymentSummaryDto>>> GetFamilyPaymentSummary(
            int familyGroupId, int academicYearId)
        {
            try
            {
                var summary = await _feeCalculationService.GetFamilyPaymentSummaryAsync(familyGroupId, academicYearId);

                return Ok(new ApiResponse<FamilyPaymentSummaryDto>
                {
                    Success = true,
                    Data = summary
                });
            }
            catch (Exception ex)
            {
                LogError(ex, "Error retrieving family payment summary");
                return BadRequest(new ApiResponse<FamilyPaymentSummaryDto> { Message = ex.Message });
            }
        }

        /// <summary>
        /// Download server-side HTML receipt for a group payment
        /// </summary>
        [HttpGet("{groupPaymentId}/receipt/download")]
        [RequirePermission(Permission.FeesView, requireRead: true)]
        public async Task<IActionResult> DownloadGroupPaymentReceipt(int groupPaymentId)
        {
            try
            {
                var gp = await _groupPayment_repository_GetWithAllocations(groupPaymentId);
                if (gp == null)
                    return NotFound(new ApiResponse<string> { Message = "Group payment not found" });

                var sb = new StringBuilder();
                sb.AppendLine("<html><head><meta charset=\"utf-8\"/><title>Receipt</title>");
                sb.AppendLine("<style>body{font-family:Arial,Helvetica,sans-serif}table{width:100%;border-collapse:collapse}th,td{padding:8px;border:1px solid #ddd}</style>");
                sb.AppendLine("</head><body>");
                sb.AppendLine($"<h2>Receipt: {System.Net.WebUtility.HtmlEncode(gp.ReceiptNumber)}</h2>");
                sb.AppendLine($"<p><strong>Date:</strong> {gp.PaymentDate:yyyy-MM-dd HH:mm}</p>");
                sb.AppendLine($"<p><strong>Total Paid:</strong> {gp.TotalAmountPaid:C}</p>");
                sb.AppendLine($"<p><strong>Payment Method:</strong> {gp.PaymentMethod}</p>");
                sb.AppendLine($"<p><strong>Transaction Id:</strong> {System.Net.WebUtility.HtmlEncode(gp.TransactionId)}</p>");
                if (gp.ProcessedByStaffId.HasValue)
                {
                    var staff = await _staffRepository.GetByIdAsync(gp.ProcessedByStaffId.Value);
                    if (staff != null)
                        sb.AppendLine($"<p><strong>Processed By:</strong> {System.Net.WebUtility.HtmlEncode(staff.FirstName + " " + staff.LastName)}</p>");
                }

                sb.AppendLine("<h3>Allocations</h3>");
                sb.AppendLine("<table><thead><tr><th>Student</th><th>Installment</th><th>Allocated</th><th>Applied</th><th>Created Payment Id</th></tr></thead><tbody>");
                foreach (var a in gp.Allocations)
                {
                    var studentName = a.Student != null ? System.Net.WebUtility.HtmlEncode(a.Student.FirstName + " " + a.Student.LastName) : "";
                    var installmentName = a.FeeInstallment != null ? System.Net.WebUtility.HtmlEncode(a.FeeInstallment.Name) : "";
                    sb.AppendLine($"<tr><td>{studentName}</td><td>{installmentName}</td><td>{a.AllocatedAmount:C}</td><td>{a.ActualAmountApplied:C}</td><td>{a.CreatedFeePaymentId?.ToString() ?? ""}</td></tr>");
                }
                sb.AppendLine("</tbody></table>");

                sb.AppendLine($"<p><em>Remarks: {System.Net.WebUtility.HtmlEncode(gp.Remarks)}</em></p>");
                sb.AppendLine("</body></html>");

                var content = Encoding.UTF8.GetBytes(sb.ToString());
                var fileName = $"Receipt_{(string.IsNullOrWhiteSpace(gp.ReceiptNumber) ? gp.Id.ToString() : gp.ReceiptNumber)}.html";

                return File(content, "text/html; charset=utf-8", fileName);
            }
            catch (Exception ex)
            {
                LogError(ex, "Error generating receipt download");
                return BadRequest(new ApiResponse<string> { Message = ex.Message });
            }
        }

        // PDF generation removed; HTML download endpoint remains.
    }
}
