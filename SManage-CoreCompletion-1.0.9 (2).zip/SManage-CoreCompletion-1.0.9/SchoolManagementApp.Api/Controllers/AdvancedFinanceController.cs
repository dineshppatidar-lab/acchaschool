using SchoolManagementApp.ApplicationCore.Common.Services;
using SchoolManagementApp.ApplicationCore.Entities;
using SchoolManagementApp.ApplicationCore.Fees.Dtos;
using SchoolManagementApp.ApplicationCore.Fees.Interfaces;
using SchoolManagementApp.ApplicationCore.Fees.Services;
using SchoolManagementApp.ApplicationCore.Setup.Dtos;
using SchoolManagementApp.Infrastructure.Data;
using System.Security.Claims;

namespace SchoolManagementApp.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class AdvancedFinanceController : BaseApiController
    {
        private readonly IAdvancedFinanceService _advancedFinanceService;
        private readonly IAuditService _auditService;

        public AdvancedFinanceController(
            IAdvancedFinanceService advancedFinanceService,
            IAuditService auditService,
            ILogger<AdvancedFinanceController> logger) : base(logger)
        {
            _advancedFinanceService = advancedFinanceService;
            _auditService = auditService;
        }

        // --- DTO Definitions ---
        public class PaymentMethodDto { public int Id { get; set; } public string Name { get; set; } = string.Empty; }
        public class CreateScholarshipRequest
        {
            public string Name { get; set; } = string.Empty;
            public string? Description { get; set; }
            public ScholarshipType Type { get; set; }
            public decimal Amount { get; set; }
            public bool IsPercentage { get; set; }
            public string? Criteria { get; set; }
            public DateTime ApplicationStartDate { get; set; }
            public DateTime ApplicationEndDate { get; set; }
            public int MaxBeneficiaries { get; set; }
        }
        public class ApplyScholarshipByIdRequest { public int StudentId { get; set; } public string? Remarks { get; set; } }
        public class AssignFeeRequest { public int StudentId { get; set; } public int FeeStructureId { get; set; } public string? Remarks { get; set; } }
        public class CreateRefundRequest
        {
            public int PaymentId { get; set; }
            public int StudentId { get; set; }
            public decimal RefundAmount { get; set; }
            public int RefundMode { get; set; }
            public string RefundReason { get; set; } = string.Empty;
            public string ReferenceNumber { get; set; } = string.Empty;
            public string Remarks { get; set; } = string.Empty;
        }

        // --- Fee Structure Management ---

        [HttpGet("fee-structures")]
        [RequirePermission(Permission.FeesView, requireRead: true)]
        public async Task<ActionResult<ApiResponse<IEnumerable<FeeStructure>>>> GetAllFeeStructures()
        {
            try {
                var structures = await _advancedFinanceService.GetAllFeeStructuresAsync();
                return SuccessResponse(structures, "Fee structures retrieved");
            }
            catch (Exception ex) { LogError(ex, "Error retrieving fee structures"); return ErrorResponse<IEnumerable<FeeStructure>>("Failed"); }
        }

        [HttpPost("fee-structures")]
        [RequirePermission(Permission.FeesManageStructure, requireWrite: true)]
        public async Task<ActionResult<ApiResponse<FeeStructure>>> CreateFeeStructure([FromBody] CreateFeeStructureRequest request)
        {
            // Bind the CreateFeeStructureRequest DTO, NOT the FeeStructure entity.
            // The entity's navigation properties (Class, AcademicYear, FeeInstallment.FeeStructure)
            // are non-nullable and receive implicit [Required] — model binding could never succeed.
            if (request == null)
            {
                return ValidationErrorResponse<FeeStructure>(new List<string> { "Request body cannot be empty" });
            }

            try
            {
                var feeStructure = new FeeStructure
                {
                    Name = request.Name,
                    ClassId = request.ClassId,
                    AcademicYearId = request.AcademicYearId,
                    AnnualFee = request.AnnualFee,
                    RegistrationFee = request.RegistrationFee,
                    TransportFee = request.TransportFee,
                    UniformFee = request.UniformFee,
                    ExaminationFee = request.ExaminationFee,
                    LibraryFee = request.LibraryFee,
                    ComputerFee = request.ComputerFee,
                    LaboratoryFee = request.LaboratoryFee,
                    SportsFee = request.SportsFee,
                    MiscellaneousFee = request.MiscellaneousFee,
                    EffectiveDate = request.EffectiveDate ?? DateTime.UtcNow,
                    IsActive = true,
                    Installments = (request.Installments ?? new()).Select(i => new FeeInstallment
                    {
                        Name = i.Name,
                        Amount = i.Amount,
                        DueDate = i.DueDate,
                        LateFee = i.LateFee,
                        GracePeriodDays = i.GracePeriodDays,
                        IsActive = true
                    }).ToList()
                };

                return SuccessResponse(await _advancedFinanceService.CreateFeeStructureAsync(feeStructure), "Fee structure created");
            }
            catch (InvalidOperationException ex) { return ValidationErrorResponse<FeeStructure>(new List<string> { ex.Message }); }
            catch (Exception ex) { LogError(ex, "Error creating fee structure"); return ErrorResponse<FeeStructure>("Failed"); }
        }

        [HttpDelete("fee-structures/{id}")]
        [RequirePermission(Permission.FeesManageStructure, requireDelete: true)]
        public async Task<ActionResult<ApiResponse>> DeleteFeeStructure(int id)
        {
            try { await _advancedFinanceService.DeleteFeeStructureAsync(id); return SuccessResponse("Fee structure deleted"); }
            catch (Exception ex) { LogError(ex, "Error deleting fee structure"); return ErrorResponse("Failed"); }
        }

        // --- Fee Assignment ---

        [HttpGet("fee-assignments")]
        [RequirePermission(Permission.FeesView, requireRead: true)]
        public async Task<ActionResult<ApiResponse<IEnumerable<object>>>> GetFeeAssignments()
        {
            try
            {
                var result = await _advancedFinanceService.GetFeeAssignmentsAsync();
                return SuccessResponse<IEnumerable<object>>(result, "Fee assignments retrieved");
            }
            catch (Exception ex) { LogError(ex, "Error retrieving fee assignments"); return ErrorResponse<IEnumerable<object>>("Failed"); }
        }

        [HttpPost("fee-assignments")]
        [RequirePermission(Permission.FeesManageStructure, requireWrite: true)]
        public async Task<ActionResult<ApiResponse<StudentFeeAssignment>>> AssignFeeToStudent([FromBody] AssignFeeRequest request)
        {
            try
            {
                var assignment = new StudentFeeAssignment { StudentId = request.StudentId, FeeStructureId = request.FeeStructureId, IsActive = true, Remarks = request.Remarks };
                var result = await _advancedFinanceService.AssignFeeToStudentAsync(assignment);
                return SuccessResponse(result, "Fee assigned successfully");
            }
            catch (InvalidOperationException ex) { return ValidationErrorResponse<StudentFeeAssignment>(new List<string> { ex.Message }); }
            catch (Exception ex) { LogError(ex, "Error assigning fee"); return ErrorResponse<StudentFeeAssignment>("Failed"); }
        }

        // Support legacy/frontend route: POST /api/advancedfinance/students/{studentId}/assign-fees
        [HttpPost("students/{studentId}/assign-fees")]
        [RequirePermission(Permission.FeesManageStructure, requireWrite: true)]
        public async Task<ActionResult<ApiResponse<StudentFeeAssignment>>> AssignFeeToStudentById(int studentId, [FromBody] AssignFeeRequest request)
        {
            try
            {
                if (request == null) request = new AssignFeeRequest();
                if (request.StudentId == 0) request.StudentId = studentId;

                var assignment = new StudentFeeAssignment { StudentId = request.StudentId, FeeStructureId = request.FeeStructureId, IsActive = true, Remarks = request.Remarks };
                var result = await _advancedFinanceService.AssignFeeToStudentAsync(assignment);
                return SuccessResponse(result, "Fee assigned successfully");
            }
            catch (InvalidOperationException ex) { return ValidationErrorResponse<StudentFeeAssignment>(new List<string> { ex.Message }); }
            catch (Exception ex) { LogError(ex, "Error assigning fee"); return ErrorResponse<StudentFeeAssignment>("Failed"); }
        }

        // --- Fee Payment Processing ---

        [HttpPost("payments")]
        [RequirePermission(Permission.PaymentsProcess, requireWrite: true)]
        public async Task<ActionResult<ApiResponse<FeePayment>>> ProcessPayment([FromBody] ProcessPaymentRequest request)
        {
            try
            {
                var payment = new FeePayment { StudentId = request.StudentId, FeeInstallmentId = request.FeeInstallmentId, AmountPaid = request.AmountPaid, PaymentDate = DateTime.UtcNow, PaymentMethod = request.PaymentMethod, TransactionId = request.TransactionId, Remarks = request.Remarks, ReceiptNumber = GenerateReceiptNumber(), Status = PaymentStatus.Completed };
                var result = await _advancedFinanceService.ProcessPaymentAsync(payment);
                return SuccessResponse(result, "Payment processed successfully");
            }
            catch (Exception ex) { LogError(ex, "Error processing payment"); return ErrorResponse<FeePayment>("Failed"); }
        }

        [HttpGet("payments")]
        [RequirePermission(Permission.PaymentsView, requireRead: true)]
        public async Task<ActionResult<ApiResponse<IEnumerable<FeePayment>>>> GetPayments()
        {
            try { return SuccessResponse(await _advancedFinanceService.GetPaymentsAsync(), "Payments retrieved successfully"); }
            catch (Exception ex) { LogError(ex, "Error retrieving payments"); return ErrorResponse<IEnumerable<FeePayment>>("Failed"); }
        }

        [HttpGet("students/{studentId}/fee-installments")]
        [RequirePermission(Permission.FeesView, requireRead: true)]
        public async Task<ActionResult<ApiResponse<IEnumerable<FeeInstallmentDto>>>> GetStudentFeeInstallments(int studentId)
        {
            try
            {
                var result = await _advancedFinanceService.GetStudentFeeInstallmentsAsync(studentId);
                return SuccessResponse<IEnumerable<FeeInstallmentDto>>(result, "Fee installments retrieved");
            }
            catch (Exception ex) { LogError(ex, "Error"); return ErrorResponse<IEnumerable<FeeInstallmentDto>>("Failed"); }
        }

        [HttpGet("students/{studentId}/outstanding-fees")]
        [RequirePermission(Permission.FeesView, requireRead: true)]
        public async Task<ActionResult<ApiResponse<OutstandingFeesDto>>> GetOutstandingFees(int studentId)
        {
            try
            {
                var result = await _advancedFinanceService.GetOutstandingFeesAsync(studentId);
                return SuccessResponse(result, "Outstanding fees retrieved");
            }
            catch (Exception ex) { LogError(ex, "Error retrieving outstanding fees"); return ErrorResponse<OutstandingFeesDto>("Failed"); }
        }

        [HttpGet("payment-methods")]
        [RequirePermission(Permission.PaymentsView, requireRead: true)]
        public async Task<ActionResult<ApiResponse<IEnumerable<PaymentMethodDto>>>> GetPaymentMethods()
        {
            try {
                var dbMethods = await _advancedFinanceService.GetPaymentMethodsAsync();
                return SuccessResponse(dbMethods.Select(m => new PaymentMethodDto { Id = ((dynamic)m).Id, Name = ((dynamic)m).Name }), "Methods retrieved");
            }
            catch (Exception ex) { LogError(ex, "Error"); return ErrorResponse<IEnumerable<PaymentMethodDto>>("Failed"); }
        }

        [HttpGet("scholarships")]
        [RequirePermission(Permission.FeesView, requireRead: true)]
        public async Task<ActionResult<ApiResponse<IEnumerable<Scholarship>>>> GetScholarships()
        {
            try { return SuccessResponse(await _advancedFinanceService.GetScholarshipsAsync(), "Scholarships retrieved"); }
            catch (Exception ex) { LogError(ex, "Error"); return ErrorResponse<IEnumerable<Scholarship>>("Failed"); }
        }

        [HttpPost("scholarships/apply")]
        [RequirePermission(Permission.FeesView, requireWrite: true)]
        public async Task<ActionResult<ApiResponse<ScholarshipApplication>>> ApplyForScholarship([FromBody] ApplyScholarshipRequest request)
        {
            try {
                var app = new ScholarshipApplication { StudentId = request.StudentId, Remarks = request.Remarks };
                return SuccessResponse(await _advancedFinanceService.ApplyForScholarshipAsync(app), "Applied successfully");
            }
            catch (InvalidOperationException ex) { return ValidationErrorResponse<ScholarshipApplication>(new List<string>{ex.Message}); }
            catch (Exception ex) { LogError(ex, "Error"); return ErrorResponse<ScholarshipApplication>("Failed"); }
        }

        [HttpGet("expenses")]
        [RequirePermission(Permission.FeesView, requireRead: true)]
        public async Task<ActionResult<ApiResponse<IEnumerable<Expense>>>> GetExpenses()
        {
            try { return SuccessResponse(await _advancedFinanceService.GetExpensesAsync(), "Expenses retrieved"); }
            catch (Exception ex) { LogError(ex, "Error retrieving expenses"); return ErrorResponse<IEnumerable<Expense>>("Failed"); }
        }

        [HttpPost("scholarships")]
        [RequirePermission(Permission.FeesManageStructure, requireWrite: true)]
        public async Task<IActionResult> CreateScholarship([FromBody] CreateScholarshipRequest request)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(request.Name) || request.Amount <= 0)
                    return ValidationErrorResult(new List<string> { "Name and a positive Amount are required" });

                var scholarship = new Scholarship
                {
                    Name = request.Name,
                    Description = request.Description ?? string.Empty,
                    Type = request.Type,
                    Amount = request.Amount,
                    IsPercentage = request.IsPercentage,
                    Criteria = request.Criteria ?? string.Empty,
                    ApplicationStartDate = request.ApplicationStartDate,
                    ApplicationEndDate = request.ApplicationEndDate,
                    MaxBeneficiaries = request.MaxBeneficiaries,
                    IsActive = true
                };
                return SuccessResult(await _advancedFinanceService.CreateScholarshipAsync(scholarship), "Scholarship created");
            }
            catch (Exception ex) { LogError(ex, "Error creating scholarship"); return ErrorResult("Failed"); }
        }

        [HttpPost("scholarships/{id}/apply")]
        [RequirePermission(Permission.FeesView, requireWrite: true)]
        public async Task<IActionResult> ApplyScholarshipById(int id, [FromBody] ApplyScholarshipByIdRequest request)
        {
            try
            {
                var application = new ScholarshipApplication { ScholarshipId = id, StudentId = request.StudentId, Remarks = request.Remarks ?? string.Empty };
                return SuccessResult(await _advancedFinanceService.ApplyForScholarshipAsync(application), "Applied successfully");
            }
            catch (InvalidOperationException ex) { return ValidationErrorResult(new List<string> { ex.Message }); }
            catch (Exception ex) { LogError(ex, "Error applying for scholarship"); return ErrorResult("Failed"); }
        }

        [HttpPost("expenses")]
        [RequirePermission(Permission.FeesCollect, requireWrite: true)]
        public async Task<IActionResult> CreateExpense([FromBody] CreateExpenseRequest request)
        {
            try
            {
                var exp = new Expense { Title = request.Title, Description = request.Description, Category = request.Category, Amount = request.Amount, ExpenseDate = request.ExpenseDate, VoucherNumber = request.VoucherNumber, VendorName = request.VendorName, ReceiptPath = request.ReceiptPath, RequestedBy = GetCurrentUserIdInt().ToString() };
                var staffId = await _advancedFinanceService.ResolveCurrentStaffIdAsync(GetCurrentUserIdInt(), GetCurrentUserEmail());
                var created = await _advancedFinanceService.CreateExpenseAsync(exp, staffId);
                return CreatedResult(created, "Expense created");
            }
            catch (Exception ex) { LogError(ex, "Error creating expense"); return ErrorResult("Failed"); }
        }

        [HttpGet("budgets")]
        [RequirePermission(Permission.FeesView, requireRead: true)]
        public async Task<ActionResult<ApiResponse<IEnumerable<Budget>>>> GetBudgets()
        {
            try { return SuccessResponse(await _advancedFinanceService.GetBudgetsAsync(), "Budgets retrieved"); }
            catch (Exception ex) { LogError(ex, "Error retrieving budgets"); return ErrorResponse<IEnumerable<Budget>>("Failed"); }
        }

        [HttpPost("budgets")]
        [RequirePermission(Permission.FeesManageStructure, requireWrite: true)]
        public async Task<IActionResult> CreateBudget([FromBody] CreateBudgetRequest request)
        {
            try {
                var b = new Budget { Name = request.Name, AcademicYearId = request.AcademicYearId, Category = request.Category, AllocatedAmount = request.AllocatedAmount, CreatedBy = GetCurrentUserIdInt().ToString() };
                var staffId = await _advancedFinanceService.ResolveCurrentStaffIdAsync(GetCurrentUserIdInt(), GetCurrentUserEmail());
                var created = await _advancedFinanceService.CreateBudgetAsync(b, staffId);
                return CreatedResult(created, "Budget created");
            }
            catch (Exception ex) { LogError(ex, "Error creating budget"); return ErrorResult("Failed"); }
        }

        [HttpPut("expenses/{id}/approve")]
        [RequirePermission(Permission.FeesCollect, requireWrite: true)]
        public async Task<IActionResult> ApproveExpense(int id, [FromBody] ApproveExpenseRequest request)
        {
            try
            {
                var staffId = await _advancedFinanceService.ResolveCurrentStaffIdAsync(GetCurrentUserIdInt(), GetCurrentUserEmail());
                var expense = await _advancedFinanceService.ApproveExpenseAsync(id, GetCurrentUserIdInt().ToString(), request?.Remarks ?? string.Empty, staffId);
                if (expense == null)
                    return StatusCode(404, new ApiResponse<Expense> { Success = false, Message = "Expense not found", StatusCode = 404 });

                _auditService.Log("APPROVE", "Expense", id.ToString(), $"Expense '{expense.Title}' approved");
                return SuccessResult(expense, "Expense approved");
            }
            catch (Exception ex) { LogError(ex, "Error approving expense"); return ErrorResult("Failed"); }
        }

        [HttpPost("notifications/send-due-reminders")]
        [RequirePermission(Permission.FeesView, requireWrite: true)]
        public async Task<IActionResult> SendDueReminders([FromQuery] int daysAhead = 7)
        {
            try
            {
                var queued = await _advancedFinanceService.QueueDueRemindersAsync(daysAhead);
                if (queued > 0)
                    _auditService.Log("SEND_REMINDERS", "FeeNotificationLog", queued.ToString(), $"{queued} due reminders queued (daysAhead={daysAhead})");

                return SuccessResult(new { notificationsSent = queued }, "Due reminders queued");
            }
            catch (Exception ex) { LogError(ex, "Error sending due reminders"); return ErrorResult("Failed"); }
        }

        [HttpGet("analytics/defaulters")]
        [RequirePermission(Permission.FeesView, requireRead: true)]
        public async Task<IActionResult> GetDefaulters([FromQuery] int page = 1, int pageSize = 20, int minDaysOverdue = 1)
        {
            try
            {
                var result = await _advancedFinanceService.GetDefaultersAsync(page, pageSize, minDaysOverdue);
                return SuccessResult(result, "Defaulters retrieved");
            }
            catch (Exception ex) { LogError(ex, "Error retrieving defaulters"); return ErrorResult("Failed"); }
        }

        [HttpGet("analytics/summary")]
        [RequirePermission(Permission.FeesReports, requireRead: true)]
        public async Task<ActionResult<ApiResponse<FinancialSummaryDto>>> GetFinancialSummary()
        {
            try {
                return SuccessResponse(await _advancedFinanceService.GetFinancialSummaryAsync(), "Summary retrieved");
            }
            catch (Exception ex) { LogError(ex, "Error"); return ErrorResponse<FinancialSummaryDto>("Failed"); }
        }

        // Second-precision stamps collide when two payments are processed within the
        // same second (unique index on ReceiptNumber → save fails). Add a short Guid
        // suffix, matching FeeAppService.GenerateReceiptNumberAsync.
        private string GenerateReceiptNumber() => $"RCP{DateTime.UtcNow:yyyyMMddHHmmss}{Guid.NewGuid().ToString().Substring(0, 4).ToUpper()}";

        [HttpGet("students/available-for-fees")]
        // Audit issue #26: this was [AllowAnonymous], exposing the full student
        // roster without any authentication. It now follows the standard
        // permission convention used by every other student-listing endpoint.
        [RequirePermission(Permission.StudentsView, requireRead: true)]
        public async Task<ActionResult<ApiResponse<IEnumerable<object>>>> GetStudentsAvailableForFees()
        {
            try {
                return SuccessResponse<IEnumerable<object>>(await _advancedFinanceService.GetStudentsAvailableForFeesAsync(), "Students retrieved");
            }
            catch (Exception ex) { LogError(ex, "Error"); return ErrorResponse<IEnumerable<object>>("Failed"); }
        }

        [HttpGet("students/search")]
        [RequirePermission(Permission.FeesView, requireRead: true)]
        public async Task<ActionResult<ApiResponse<IEnumerable<object>>>> SearchStudents(string q, int? academicYearId = null)
        {
            try
            {
                var filtered = await _advancedFinanceService.SearchStudentsAsync(q, academicYearId);
                return SuccessResponse<IEnumerable<object>>(filtered, "Students retrieved");
            }
            catch (Exception ex) { LogError(ex, "Error searching students"); return ErrorResponse<IEnumerable<object>>("Failed"); }
        }

        [HttpPost("refunds")]
        [RequirePermission(Permission.FeesCollect, requireWrite: true)]
        public async Task<ActionResult<ApiResponse<object>>> CreateRefund([FromBody] CreateRefundRequest request)
        {
            try
            {
                if (request.PaymentId <= 0 || request.StudentId <= 0 || request.RefundAmount <= 0)
                    return ValidationErrorResponse<object>(new List<string> { "Invalid refund request" });

                var refund = new FeeRefund
                {
                    PaymentId = request.PaymentId,
                    StudentId = request.StudentId,
                    RefundAmount = request.RefundAmount,
                    RefundMode = (PaymentMethodType)request.RefundMode,
                    RefundReason = request.RefundReason,
                    ReferenceNumber = request.ReferenceNumber,
                    Remarks = request.Remarks,
                    CreatedBy = GetCurrentUserIdInt().ToString()
                };

                var result = await _advancedFinanceService.CreateRefundAsync(refund);
                return SuccessResponse<object>(result, "Refund created successfully");
            }
            catch (InvalidOperationException ex)
            {
                return ValidationErrorResponse<object>(new List<string> { ex.Message });
            }
            catch (Exception ex)
            {
                LogError(ex, "Error creating refund");
                return ErrorResponse<object>("Failed to create refund");
            }
        }

        [HttpGet("students/{studentId}/refunds")]
        [RequirePermission(Permission.FeesView, requireRead: true)]
        public async Task<ActionResult<ApiResponse<object>>> GetStudentRefunds(int studentId)
        {
            try
            {
                var refunds = await _advancedFinanceService.GetStudentRefundsAsync(studentId);
                return SuccessResponse<object>(refunds, "Refund history retrieved");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error retrieving refunds");
                return ErrorResponse<object>("Failed to retrieve refund history");
            }
        }

        [HttpGet("students/{studentId}/refundable-balance")]
        [RequirePermission(Permission.FeesView, requireRead: true)]
        public async Task<ActionResult<ApiResponse<object>>> GetRefundableBalance(int studentId)
        {
            try
            {
                var result = await _advancedFinanceService.GetRefundableBalanceAsync(studentId);
                return SuccessResponse<object>(result, "Refundable balance retrieved");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error calculating refundable balance");
                return ErrorResponse<object>("Failed to calculate refundable balance");
            }
        }

        [HttpGet("students/{studentId}/ledger")]
        [RequirePermission(Permission.FeesView, requireRead: true)]
        public async Task<ActionResult<ApiResponse<object>>> GetStudentLedger(int studentId)
        {
            try {
                var result = await _advancedFinanceService.GetStudentLedgerAsync(studentId);
                return SuccessResponse<object>(result, "Ledger retrieved");
            }
            catch (Exception ex) { LogError(ex, "Error"); return ErrorResponse<object>("Failed"); }
        }
    }
}
