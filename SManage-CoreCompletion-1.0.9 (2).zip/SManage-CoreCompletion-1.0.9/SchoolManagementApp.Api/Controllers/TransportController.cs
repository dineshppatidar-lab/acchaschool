using SchoolManagementApp.ApplicationCore.Transport.Interfaces;
using SchoolManagementApp.ApplicationCore.Entities;
using System.ComponentModel.DataAnnotations;
using System.Text;
using System.Globalization;

namespace SchoolManagementApp.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class TransportController : BaseApiController
    {
        private readonly ITransportService _transportService;

        public TransportController(ITransportService transportService, ILogger<TransportController> logger)
            : base(logger)
        {
            _transportService = transportService;
        }

        [HttpGet]
        [RequirePermission(Permission.TransportView, requireRead: true)]
        public async Task<IActionResult> GetTransports([FromQuery] int page = 1, [FromQuery] int pageSize = 10, [FromQuery] string sort = "RouteName", [FromQuery] string order = "asc", [FromQuery] string search = "")
        {
            try
            {
                LogAction($"Getting transports - Page: {page}, PageSize: {pageSize}");
                var (transports, total) = await _transportService.GetTransportsAsync(page, pageSize, sort, order, search);
                return PaginatedResult(transports.ToList(), total, page, pageSize, "Transport routes retrieved successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error retrieving transports");
                return ErrorResult("Failed to retrieve transport routes");
            }
        }

        [HttpGet("{id}")]
        [RequirePermission(Permission.TransportView, requireRead: true)]
        public async Task<IActionResult> GetTransport(int id)
        {
            try
            {
                LogAction($"Getting transport {id}");
                var transport = await _transportService.GetTransportByIdAsync(id);
                if (transport == null)
                {
                    return NotFoundResult($"Transport route with ID {id} not found");
                }
                return SuccessResult(transport, "Transport route retrieved successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error retrieving transport {id}");
                return ErrorResult("Failed to retrieve transport route");
            }
        }

        [HttpPost]
        [RequirePermission(Permission.TransportManageRoutes, requireWrite: true)]
        public async Task<IActionResult> CreateTransport([FromBody] BusRoute transport)
        {
            try
            {
                LogAction($"Creating transport route: {transport.RouteName}");
                if (await _transportService.IsVehicleAssignedToAnotherRouteAsync(transport.VehicleId))
                {
                    return ValidationErrorResult(new List<string> { "This vehicle is already assigned to another route. Please select a different vehicle." }, "Vehicle conflict");
                }

                var createdTransport = await _transportService.CreateTransportAsync(transport);
                return SuccessResult(createdTransport, "Transport route created successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error creating transport route");
                return ErrorResult("Failed to create transport route");
            }
        }

        [HttpPut("{id}")]
        [RequirePermission(Permission.TransportManageRoutes, requireWrite: true)]
        public async Task<IActionResult> UpdateTransport(int id, [FromBody] BusRoute transport)
        {
            try
            {
                LogAction($"Updating transport {id}");
                if (id != transport.Id)
                {
                    return ValidationErrorResult(new List<string> { "ID mismatch" }, "Invalid request");
                }

                if (await _transportService.IsVehicleAssignedToAnotherRouteAsync(transport.VehicleId, id))
                {
                    return ValidationErrorResult(new List<string> { "This vehicle is already assigned to another route. Please select a different vehicle." }, "Vehicle conflict");
                }

                await _transportService.UpdateTransportAsync(transport);
                return SuccessResult(transport, "Transport route updated successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error updating transport {id}");
                return ErrorResult("Failed to update transport route");
            }
        }

        [HttpDelete("{id}")]
        [RequirePermission(Permission.TransportManageRoutes, requireDelete: true)]
        public async Task<IActionResult> DeleteTransport(int id)
        {
            try
            {
                LogAction($"Deleting transport {id}");
                await _transportService.DeleteTransportAsync(id);
                return SuccessResult(new { message = "Transport route deleted successfully" }, "Transport route deleted");
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error deleting transport {id}");
                return ErrorResult("Failed to delete transport route");
            }
        }

        // Vehicles
        [HttpGet("vehicles")]
        [RequirePermission(Permission.TransportManageVehicles, requireRead: true)]
        public async Task<IActionResult> GetVehicles([FromQuery] int page = 1, [FromQuery] int pageSize = 10, [FromQuery] string sort = "VehicleNumber", [FromQuery] string order = "asc", [FromQuery] string search = "")
        {
            try
            {
                LogAction($"Getting vehicles - Page: {page}, PageSize: {pageSize}");
                var (vehicles, total) = await _transportService.GetVehiclesAsync(page, pageSize, sort, order, search);
                return PaginatedResult(vehicles.ToList(), total, page, pageSize, "Vehicles retrieved successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error retrieving vehicles");
                return ErrorResult("Failed to retrieve vehicles");
            }
        }

        /// <summary>
        /// Real assigned-student count per vehicle (via its route), for capacity
        /// utilization stats (issue #7 — replaces the frontend mock of 0 assigned).
        /// </summary>
        [HttpGet("vehicles/statistics")]
        [RequirePermission(Permission.TransportManageVehicles, requireRead: true)]
        public async Task<IActionResult> GetVehicleStatistics()
        {
            try
            {
                var (routes, _) = await _transportService.GetTransportsAsync(1, 10000, "RouteName", "asc", "");
                var studentsByRoute = await _transportService.GetActiveStudentCountByRouteAsync();

                // Vehicle → assigned students, summed across the routes that use the vehicle
                var assignedByVehicle = new Dictionary<int, int>();
                foreach (var route in routes)
                {
                    if (route.VehicleId <= 0) continue;
                    var count = studentsByRoute.GetValueOrDefault(route.Id, 0);
                    assignedByVehicle[route.VehicleId] = assignedByVehicle.GetValueOrDefault(route.VehicleId) + count;
                }

                return SuccessResult(assignedByVehicle, "Vehicle statistics retrieved successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error retrieving vehicle statistics");
                return ErrorResult("Failed to retrieve vehicle statistics");
            }
        }

        [HttpGet("vehicles/{id}")]
        [RequirePermission(Permission.TransportManageVehicles, requireRead: true)]
        public async Task<IActionResult> GetVehicle(int id)
        {
            try
            {
                LogAction($"Getting vehicle {id}");
                var vehicle = await _transportService.GetVehicleByIdAsync(id);
                return vehicle is null ? NotFoundResult($"Vehicle with ID {id} not found") : SuccessResult(vehicle, "Vehicle retrieved successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error retrieving vehicle {id}");
                return ErrorResult("Failed to retrieve vehicle");
            }
        }

        [HttpPost("vehicles")]
        [RequirePermission(Permission.TransportManageVehicles, requireWrite: true)]
        public async Task<IActionResult> CreateVehicle([FromBody] Vehicle vehicle)
        {
            try
            {
                LogAction($"Creating vehicle: {vehicle.VehicleNumber}");
                var created = await _transportService.CreateVehicleAsync(vehicle);
                return SuccessResult(created, "Vehicle created successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error creating vehicle");
                return ErrorResult("Failed to create vehicle");
            }
        }

        [HttpPut("vehicles/{id}")]
        [RequirePermission(Permission.TransportManageVehicles, requireWrite: true)]
        public async Task<IActionResult> UpdateVehicle(int id, [FromBody] Vehicle vehicle)
        {
            try
            {
                LogAction($"Updating vehicle {id}");
                if (id != vehicle.Id)
                    return ValidationErrorResult(new List<string> { "ID mismatch" }, "Invalid request");
                await _transportService.UpdateVehicleAsync(vehicle);
                return SuccessResult(vehicle, "Vehicle updated successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error updating vehicle {id}");
                return ErrorResult("Failed to update vehicle");
            }
        }

        [HttpDelete("vehicles/{id}")]
        [RequirePermission(Permission.TransportManageVehicles, requireDelete: true)]
        public async Task<IActionResult> DeleteVehicle(int id)
        {
            try
            {
                LogAction($"Deleting vehicle {id}");
                await _transportService.DeleteVehicleAsync(id);
                return SuccessResult(new { message = "Vehicle deleted successfully" }, "Vehicle deleted");
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error deleting vehicle {id}");
                return ErrorResult("Failed to delete vehicle");
            }
        }

        // Route stops
        [HttpGet("routes/{routeId}/stops")]
        [RequirePermission(Permission.TransportManageRoutes, requireRead: true)]
        public async Task<IActionResult> GetRouteStops(int routeId)
        {
            try
            {
                LogAction($"Getting stops for route {routeId}");
                var stops = await _transportService.GetRouteStopsAsync(routeId);
                return SuccessResult(stops, "Route stops retrieved successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error retrieving stops for route {routeId}");
                return ErrorResult("Failed to retrieve route stops");
            }
        }

        [HttpPost("routes/{routeId}/stops")]
        [RequirePermission(Permission.TransportManageRoutes, requireWrite: true)]
        public async Task<IActionResult> AddRouteStop(int routeId, [FromBody] RouteStop stop)
        {
            try
            {
                LogAction($"Adding stop to route {routeId}");
                stop.RouteId = routeId;
                var created = await _transportService.AddRouteStopAsync(stop);
                return SuccessResult(created, "Route stop added successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error adding stop to route {routeId}");
                return ErrorResult("Failed to add route stop");
            }
        }

        [HttpPut("routes/{routeId}/stops/{id}")]
        [RequirePermission(Permission.TransportManageRoutes, requireWrite: true)]
        public async Task<IActionResult> UpdateRouteStop(int routeId, int id, [FromBody] RouteStop stop)
        {
            try
            {
                LogAction($"Updating stop {id} for route {routeId}");
                if (id != stop.Id || routeId != stop.RouteId)
                    return ValidationErrorResult(new List<string> { "ID mismatch" }, "Invalid request");
                await _transportService.UpdateRouteStopAsync(stop);
                return SuccessResult(stop, "Route stop updated successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error updating stop {id}");
                return ErrorResult("Failed to update route stop");
            }
        }

        [HttpDelete("routes/{routeId}/stops/{id}")]
        [RequirePermission(Permission.TransportManageRoutes, requireDelete: true)]
        public async Task<IActionResult> DeleteRouteStop(int routeId, int id)
        {
            try
            {
                LogAction($"Deleting stop {id} from route {routeId}");
                await _transportService.DeleteRouteStopAsync(id);
                return SuccessResult(new { message = "Route stop deleted successfully" }, "Route stop deleted");
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error deleting stop {id}");
                return ErrorResult("Failed to delete route stop");
            }
        }

        public record ReorderStopDto(int StopId, int SequenceNumber);
        [HttpPost("routes/{routeId}/stops/reorder")]
        [RequirePermission(Permission.TransportManageRoutes, requireWrite: true)]
        public async Task<IActionResult> ReorderStops(int routeId, [FromBody] List<ReorderStopDto> order)
        {
            try
            {
                LogAction($"Reordering stops for route {routeId}");
                await _transportService.ReorderRouteStopsAsync(routeId, order.Select(o => (o.StopId, o.SequenceNumber)));
                return SuccessResult(new { message = "Stops reordered successfully" }, "Stops reordered");
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error reordering stops for route {routeId}");
                return ErrorResult("Failed to reorder stops");
            }
        }

        // Student assignment to routes
        public record AssignStudentDto([Required] int StudentId, [Required] int RouteId);
        [HttpPost("assign-student")]
        [RequirePermission(Permission.TransportManageRoutes, requireWrite: true)]
        public async Task<IActionResult> AssignStudent([FromBody] AssignStudentDto dto)
        {
            try
            {
                LogAction($"Assigning student {dto.StudentId} to route {dto.RouteId}");
                await _transportService.AssignStudentToRouteAsync(dto.StudentId, dto.RouteId);
                return SuccessResult(new { message = "Student assigned to route" }, "Student assigned");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error assigning student to route");
                return ErrorResult("Failed to assign student to route");
            }
        }

        [HttpPost("unassign-student/{studentId}")]
        [RequirePermission(Permission.TransportManageRoutes, requireWrite: true)]
        public async Task<IActionResult> UnassignStudent(int studentId)
        {
            try
            {
                LogAction($"Unassigning student {studentId} from route");
                await _transportService.UnassignStudentFromRouteAsync(studentId);
                return SuccessResult(new { message = "Student unassigned from route" }, "Student unassigned");
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error unassigning student {studentId}");
                return ErrorResult("Failed to unassign student from route");
            }
        }

        [HttpGet("routes/{routeId}/students")]
        [RequirePermission(Permission.TransportView, requireRead: true)]
        public async Task<IActionResult> GetRouteStudents(int routeId)
        {
            try
            {
                LogAction($"Getting students for route {routeId}");
                var students = await _transportService.GetRouteStudentsAsync(routeId);
                return SuccessResult(students, "Route students retrieved successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error retrieving students for route {routeId}");
                return ErrorResult("Failed to retrieve route students");
            }
        }

        // Attendance
        [HttpPost("routes/{routeId}/attendance")]
        [RequirePermission(Permission.TransportManageRoutes, requireWrite: true)]
        public async Task<IActionResult> MarkBusAttendance(int routeId, [FromBody] BusAttendance attendance)
        {
            try
            {
                LogAction($"Marking attendance for route {routeId}");
                attendance.RouteId = routeId;
                var created = await _transportService.MarkBusAttendanceAsync(attendance);
                return SuccessResult(created, "Bus attendance marked successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error marking attendance for route {routeId}");
                return ErrorResult("Failed to mark bus attendance");
            }
        }

        [HttpGet("routes/{routeId}/attendance")]
        [RequirePermission(Permission.TransportView, requireRead: true)]
        public async Task<IActionResult> GetBusAttendance(int routeId, [FromQuery] DateTime date)
        {
            try
            {
                LogAction($"Getting attendance for route {routeId} on {date:yyyy-MM-dd}");
                var list = await _transportService.GetBusAttendanceAsync(routeId, date);
                return SuccessResult(list, "Bus attendance retrieved successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error retrieving attendance for route {routeId}");
                return ErrorResult("Failed to retrieve bus attendance");
            }
        }

        // Fees
        [HttpGet("fees")]
        [RequirePermission(Permission.TransportView, requireRead: true)]
        public async Task<IActionResult> GetTransportFees()
        {
            try
            {
                LogAction("Getting transport fees");
                var fees = await _transportService.GetTransportFeesAsync();
                return SuccessResult(fees, "Transport fees retrieved successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error retrieving transport fees");
                return ErrorResult("Failed to retrieve transport fees");
            }
        }

        // === Exports ===
        [HttpGet("vehicles/export")]
        [EnableRateLimiting("Export")]
        [RequirePermission(Permission.TransportView, requireRead: true)]
        public async Task<IActionResult> ExportVehiclesCsv([FromQuery] string format = "csv")
        {
            var (vehicles, _) = await _transportService.GetVehiclesAsync(1, 10000);
            var sb = new StringBuilder();
            sb.AppendLine("Id,VehicleNumber,Model,Capacity,Status");
            foreach (var v in vehicles)
            {
                sb.AppendLine(string.Join(',', new[]
                {
                    v.Id.ToString(CultureInfo.InvariantCulture),
                    EscapeCsv(v.VehicleNumber),
                    EscapeCsv(v.Model),
                    v.Capacity.ToString(CultureInfo.InvariantCulture),
                    EscapeCsv(v.Status)
                }));
            }
            var bytes = Encoding.UTF8.GetBytes(sb.ToString());
            return File(bytes, "text/csv", "vehicles_roster.csv");
        }

        [HttpGet("routes/{routeId}/manifest/export")]
        [EnableRateLimiting("Export")]
        [RequirePermission(Permission.TransportView, requireRead: true)]
        public async Task<IActionResult> ExportRouteManifestCsv(int routeId)
        {
            var students = await _transportService.GetRouteStudentsAsync(routeId);
            var sb = new StringBuilder();
            sb.AppendLine("RouteId,StudentId,StudentName,Class,Section,StopSequence,StopName,ArrivalTime");
            foreach (var s in students)
            {
                sb.AppendLine(string.Join(',', new[]
                {
                    routeId.ToString(CultureInfo.InvariantCulture),
                    s.Id.ToString(CultureInfo.InvariantCulture),
                    EscapeCsv($"{s.FirstName} {s.LastName}"),
                    EscapeCsv(s.Class?.Name ?? string.Empty),
                    EscapeCsv(s.Section?.Name ?? string.Empty),
                    string.Empty,
                    string.Empty,
                    string.Empty
                }));
            }
            var bytes = Encoding.UTF8.GetBytes(sb.ToString());
            return File(bytes, "text/csv", $"route_{routeId}_manifest.csv");
        }

        // === Analytics ===
        [HttpGet("analytics/route-utilization")]
        [RequirePermission(Permission.TransportView, requireRead: true)]
        public async Task<IActionResult> GetRouteUtilization()
        {
            var (routes, _) = await _transportService.GetTransportsAsync(1, 10000, "RouteName", "asc", "");
            var (vehicles, _) = await _transportService.GetVehiclesAsync(1, 10000, "VehicleNumber", "asc", "");
            var studentCounts = await _transportService.GetStudentCountByRouteAsync();
            var list = new List<object>();
            foreach (var r in routes)
            {
                var assigned = studentCounts.GetValueOrDefault(r.Id, 0);
                var capacity = vehicles.FirstOrDefault(v => v.Id == r.VehicleId)?.Capacity ?? 0;
                var utilization = capacity > 0 ? Math.Round(assigned * 100.0 / capacity, 2) : 0;
                list.Add(new { routeId = r.Id, r.RouteName, assigned, capacity, utilizationPercent = utilization });
            }
            return Ok(list);
        }

        [HttpGet("analytics/punctuality")]
        [RequirePermission(Permission.TransportView, requireRead: true)]
        public async Task<IActionResult> GetPunctualitySummary([FromQuery] DateTime start, [FromQuery] DateTime end)
        {
            if (end < start) return BadRequest("End date must be after start date");
            var (routes, _) = await _transportService.GetTransportsAsync(1, 10000, "RouteName", "asc", "");
            var studentCounts = await _transportService.GetStudentCountByRouteAsync();
            var attendanceCounts = await _transportService.GetAttendanceCountByRouteAndDateRangeAsync(start, end);
            var results = new List<object>();
            var days = (end.Date - start.Date).Days + 1;
            foreach (var r in routes)
            {
                var totalStudents = studentCounts.GetValueOrDefault(r.Id, 0);
                var totalExpected = totalStudents * Math.Max(days, 1);
                int presentTotal = attendanceCounts.GetValueOrDefault(r.Id, 0);
                var rate = totalExpected > 0 ? Math.Round(presentTotal * 100.0 / totalExpected, 2) : 0;
                results.Add(new { routeId = r.Id, r.RouteName, totalStudents, days, presentTotal, punctualityPercent = rate });
            }
            return Ok(results);
        }

        private static string EscapeCsv(string value)
        {
            if (string.IsNullOrEmpty(value)) return string.Empty;
            var needsQuotes = value.Contains(',') || value.Contains('"') || value.Contains('\n') || value.Contains('\r');
            if (needsQuotes)
            {
                value = value.Replace("\"", "\"\"");
                return $"\"{value}\"";
            }
            return value;
        }
    }
}
