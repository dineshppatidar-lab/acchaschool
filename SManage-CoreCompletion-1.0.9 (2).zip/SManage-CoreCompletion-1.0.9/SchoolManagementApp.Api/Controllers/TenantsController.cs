using Microsoft.AspNetCore.RateLimiting;
using SchoolManagementApp.ApplicationCore.Services.Interfaces;

namespace SchoolManagementApp.Api.Controllers
{
    [Authorize]
    public class TenantsController : BaseApiController
    {
        private readonly ITenantService _tenantService;
        private readonly SchoolManagementApp.ApplicationCore._Interfaces.ITenantProvider _tenantProvider;

        public TenantsController(
            ITenantService tenantService,
            ILogger<TenantsController> logger,
            SchoolManagementApp.ApplicationCore._Interfaces.ITenantProvider tenantProvider) : base(logger)
        {
            _tenantService = tenantService;
            _tenantProvider = tenantProvider;
        }

        [HttpGet]
        [RequirePermission(Permission.SystemManage, requireRead: true)]
        public async Task<ActionResult<ApiResponse<IEnumerable<Tenant>>>> GetTenants()
        {
            var currentTenantId = _tenantProvider.TenantId;
            _logger.LogInformation("Retrieving details for current tenant. TenantId: {TenantId}", currentTenantId);

            var tenants = await _tenantService.GetTenantsAsync(currentTenantId);
            return SuccessResponse<IEnumerable<Tenant>>(tenants, "Tenant details retrieved successfully");
        }

        [HttpPost]
        [RequirePermission(Permission.SystemManage, requireWrite: true)]
        public async Task<ActionResult<ApiResponse<Tenant>>> CreateTenant([FromBody] CreateTenantRequest req)
        {
            var roles = GetCurrentUserRoles();
            var isSuperAdmin = roles.Contains("SuperAdmin", StringComparer.OrdinalIgnoreCase);

            if (!isSuperAdmin)
            {
                return ForbiddenResponse<Tenant>("Only SuperAdmins can create new tenants");
            }

            if (string.IsNullOrWhiteSpace(req.Name))
            {
                return ValidationErrorResponse<Tenant>(new List<string> { "Name is required" });
            }

            try
            {
                var tenant = await _tenantService.CreateTenantAsync(req.Name, req.Domain, req.IsActive, req.LogoUrl, req.WelcomeText);
                LogAction($"Tenant created and seeded successfully: {tenant.Name} (ID: {tenant.Id})");
                return SuccessResponse(tenant, "Tenant created successfully with all menu items and permissions");
            }
            catch (InvalidOperationException ex)
            {
                // Domain validation/uniqueness errors from the service layer
                return ValidationErrorResponse<Tenant>(new List<string> { ex.Message });
            }
        }

        [HttpPut("{id:int}")]
        [RequirePermission(Permission.SystemManage, requireWrite: true)]
        public async Task<ActionResult<ApiResponse<Tenant>>> UpdateTenant([FromRoute] int id, [FromBody] UpdateTenantRequest req)
        {
            var roles = GetCurrentUserRoles();
            var isSuperAdmin = roles.Contains("SuperAdmin", StringComparer.OrdinalIgnoreCase);
            var currentTenantId = _tenantProvider.TenantId;

            if (!isSuperAdmin && id != currentTenantId)
            {
                return ForbiddenResponse<Tenant>("You are only allowed to update your own tenant details");
            }

            if (string.IsNullOrWhiteSpace(req.Name))
            {
                return ValidationErrorResponse<Tenant>(new List<string> { "Name is required" });
            }

            try
            {
                var tenant = await _tenantService.UpdateTenantAsync(id, req.Name, req.Domain, req.IsActive, req.LogoUrl, req.WelcomeText);
                return SuccessResponse(tenant, "Tenant updated successfully");
            }
            catch (InvalidOperationException ex) when (ex.Message == "Tenant not found")
            {
                return NotFoundResponse<Tenant>(ex.Message);
            }
            catch (InvalidOperationException ex)
            {
                // Domain validation/uniqueness errors from the service layer
                return ValidationErrorResponse<Tenant>(new List<string> { ex.Message });
            }
        }

        [AllowAnonymous]
        [HttpPost("register-client")]
        [EnableRateLimiting("PublicRegistration")]
        public async Task<ActionResult<ApiResponse<ClientTenantRegisterResponse>>> RegisterClientTenant([FromBody] ClientTenantRegisterRequest req)
        {
            var errors = new List<string>();
            if (string.IsNullOrWhiteSpace(req.TenantName)) errors.Add("Tenant name is required");
            if (string.IsNullOrWhiteSpace(req.AdminUsername)) errors.Add("Admin username is required");
            if (string.IsNullOrWhiteSpace(req.AdminEmail)) errors.Add("Admin email is required");
            if (string.IsNullOrWhiteSpace(req.Password)) errors.Add("Password is required");
            if (req.Password != req.ConfirmPassword) errors.Add("Password and confirm password do not match");
            if (!req.AcceptedTerms) errors.Add("Terms must be accepted");
            if (errors.Any()) return ValidationErrorResponse<ClientTenantRegisterResponse>(errors);

            try
            {
                var response = await _tenantService.RegisterClientTenantAsync(req);
                return SuccessResponse(response, "Client tenant registered successfully");
            }
            catch (InvalidOperationException ex)
            {
                return ValidationErrorResponse<ClientTenantRegisterResponse>(new List<string> { ex.Message });
            }
        }
    }

    public class CreateTenantRequest
    {
        public string Name { get; set; } = string.Empty;
        public string? Domain { get; set; }
        public bool IsActive { get; set; } = true;
        public string? LogoUrl { get; set; }
        public string? WelcomeText { get; set; }
    }

    public class UpdateTenantRequest
    {
        public string Name { get; set; } = string.Empty;
        public string? Domain { get; set; }
        public bool IsActive { get; set; }
        public string? LogoUrl { get; set; }
        public string? WelcomeText { get; set; }
    }
}