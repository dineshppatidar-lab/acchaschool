using SchoolManagementApp.ApplicationCore.Academic.Dtos;
using SchoolManagementApp.ApplicationCore.Academic.Interfaces;

namespace SchoolManagementApp.Api.Controllers
{
    [Authorize]
    public class AcademicController : BaseApiController
    {
        private readonly IAcademicAppService _academicAppService;
        
        public AcademicController(IAcademicAppService academicAppService, ILogger<AcademicController> logger) : base(logger)
        {
            _academicAppService = academicAppService;
        }
        [HttpGet]
        [RequirePermission(Permission.SystemSettings, requireRead: true)]
        public async Task<ActionResult<PaginatedApiResponse<Class>>> GetClasses([FromQuery] int page = 1, [FromQuery] int pageSize = 10, [FromQuery] string sort = "Name", [FromQuery] string order = "asc", [FromQuery] string search = "")
        {
            var (classes, total) = await _academicAppService.GetClassesAsync(page, pageSize, sort, order, search);
            return PaginatedSuccessResponse(classes, total, page, pageSize);
        }

        /// <summary>
        /// Real per-class aggregates for list-page statistics (issue #7).
        /// </summary>
        [HttpGet("statistics")]
        [RequirePermission(Permission.SystemSettings, requireRead: true)]
        public async Task<ActionResult<ApiResponse<IReadOnlyList<ClassStatisticsDto>>>> GetClassStatistics()
        {
            var stats = await _academicAppService.GetClassStatisticsAsync();
            return SuccessResponse(stats, "Class statistics retrieved successfully");
        }

        [HttpGet("all")]
        // ClassesView, not SystemSettings: this list feeds dropdowns (e.g. Enter Result's
        // class selector) that every authenticated academic user needs. All other class
        // reads on this controller already require ClassesView.
        [RequirePermission(Permission.ClassesView, requireRead: true)]
        public async Task<ActionResult<ApiResponse<List<Class>>>> GetAllClasses()
        {
            var (classes, _) = await _academicAppService.GetClassesAsync(1, 1000, "Name", "asc", "");
            return SuccessResponse(classes.ToList());
        }

        [HttpGet("year/{academicYearId}")]
        [RequirePermission(Permission.SystemSettings, requireRead: true)]
        public async Task<ActionResult<ApiResponse<IEnumerable<Class>>>> GetClassesByAcademicYear(int academicYearId)
        {
            var classes = await _academicAppService.GetClassesByAcademicYearAsync(academicYearId);
            return SuccessResponse(classes);
        }

        [HttpGet("{id}")]
        [RequirePermission(Permission.SystemSettings, requireRead: true)]
        public async Task<ActionResult<ApiResponse<Class>>> GetClass(int id)
        {
            var class_ = await _academicAppService.GetClassByIdAsync(id);
            if (class_ == null)
            {
                return NotFoundResponse<Class>("Class not found");
            }
            return SuccessResponse(class_);
        }

        [HttpPost]
        [RequirePermission(Permission.ClassesCreate, requireWrite: true)]
        public async Task<ActionResult<ApiResponse<Class>>> CreateClass([FromBody] Class class_)
        {
            var createdClass = await _academicAppService.CreateClassAsync(class_);
            return SuccessResponse(createdClass);
        }

        [HttpPut("{id}")]
        [RequirePermission(Permission.ClassesEdit, requireWrite: true)]
        public async Task<ActionResult<ApiResponse>> UpdateClass(int id, [FromBody] Class class_)
        {
            if (id != class_.Id)
            {
                return ValidationErrorResponse(new List<string>{"Route id and body id do not match."});
            }
            await _academicAppService.UpdateClassAsync(class_);
            return SuccessResponse("Class updated successfully");
        }

        [HttpDelete("{id}")]
        [RequirePermission(Permission.ClassesDelete, requireDelete: true)]
        public async Task<ActionResult<ApiResponse>> DeleteClass(int id)
        {
            await _academicAppService.DeleteClassAsync(id);
            return SuccessResponse("Class deleted successfully");
        }

        [HttpGet("sections")]
        [RequirePermission(Permission.SystemSettings, requireRead: true)]
        public async Task<ActionResult<PaginatedApiResponse<Section>>> GetSections([FromQuery] int page = 1, [FromQuery] int pageSize = 10, [FromQuery] string sort = "Name", [FromQuery] string order = "asc", [FromQuery] string search = "")
        {
            var (sections, total) = await _academicAppService.GetSectionsAsync(page, pageSize, sort, order, search);
            return PaginatedSuccessResponse(sections, total, page, pageSize);
        }

        [HttpGet("sections/{id}")]
        [RequirePermission(Permission.SystemSettings, requireRead: true)]
        public async Task<ActionResult<ApiResponse<Section>>> GetSection(int id)
        {
            var section = await _academicAppService.GetSectionByIdAsync(id);
            if (section == null)
            {
                return NotFoundResponse<Section>("Section not found");
            }
            return SuccessResponse(section);
        }

        [HttpGet("class/{classId}/sections")]
        [RequirePermission(Permission.SystemSettings, requireRead: true)]
        public async Task<ActionResult<ApiResponse<IEnumerable<Section>>>> GetSectionsByClass(int classId)
        {
            var sections = await _academicAppService.GetSectionsByClassAsync(classId);
            return SuccessResponse(sections);
        }

        [HttpPost("sections")]
        [RequirePermission(Permission.ClassesCreate, requireWrite: true)]
        public async Task<ActionResult<ApiResponse<Section>>> CreateSection([FromBody] Section section)
        {
            var createdSection = await _academicAppService.CreateSectionAsync(section);
            return SuccessResponse(createdSection);
        }

        [HttpPut("sections/{id}")]
        [RequirePermission(Permission.ClassesEdit, requireWrite: true)]
        public async Task<ActionResult<ApiResponse>> UpdateSection(int id, [FromBody] Section section)
        {
            if (id != section.Id)
            {
                return ValidationErrorResponse(new List<string>{"Route id and body id do not match."});
            }
            await _academicAppService.UpdateSectionAsync(section);
            return SuccessResponse("Section updated successfully");
        }

        [HttpDelete("sections/{id}")]
        [RequirePermission(Permission.ClassesDelete, requireDelete: true)]
        public async Task<ActionResult<ApiResponse>> DeleteSection(int id)
        {
            await _academicAppService.DeleteSectionAsync(id);
            return SuccessResponse("Section deleted successfully");
        }
    }
}
