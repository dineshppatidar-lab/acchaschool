
using SchoolManagementApp.ApplicationCore.Staff.Interfaces;

namespace SchoolManagementApp.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class StaffController : BaseApiController
    {
        private readonly IStaffRepository _staffRepository;
        private readonly SchoolManagementApp.ApplicationCore.Common.Services.IAuditService _auditService;

        public StaffController(IStaffRepository staffRepository, SchoolManagementApp.ApplicationCore.Common.Services.IAuditService auditService, ILogger<StaffController> logger) : base(logger)
        {
            _staffRepository = staffRepository;
            _auditService = auditService;
        }

        [HttpGet]
        [RequirePermission(Permission.StaffView, requireRead: true)]
        public async Task<IActionResult> GetStaff([FromQuery] string? search = null, [FromQuery] int page = 1, [FromQuery] int pageSize = 20, [FromQuery] string sort = "name", [FromQuery] string order = "asc")
        {
            try
            {
                LogAction($"Getting staff list - Page: {page}, PageSize: {pageSize}, Search: {search}");
                
                var query = await _staffRepository.GetAllAsync();
                var staff = string.IsNullOrEmpty(search)
                    ? query
                    : query.Where(s => (s.FirstName + " " + s.LastName).Contains(search ?? string.Empty) || s.Email.Contains(search ?? string.Empty));
                
                var total = staff.Count();
                var paged = staff.Skip((page - 1) * pageSize).Take(pageSize).ToList();
                
                var result = new { total, data = paged };
                LogAction($"Staff list retrieved successfully - Total: {total}, Page items: {paged.Count}");
                
                return CompatibleSuccessResult(result, "Staff list retrieved successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error retrieving staff list");
                return StatusCode(500, new { message = "An error occurred while retrieving staff list" });
            }
        }

        [HttpGet("{id}")]
        [RequirePermission(Permission.StaffView, requireRead: true)]
        public async Task<IActionResult> GetStaffById(int id)
        {
            try
            {
                LogAction($"Getting staff member with ID: {id}");
                
                var staff = await _staffRepository.GetByIdAsync(id);
                if (staff == null)
                {
                    LogAction($"Staff member not found with ID: {id}");
                    return NotFound(new { message = $"Staff member with ID {id} not found" });
                }
                
                return Ok(staff);
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error retrieving staff member with ID: {id}");
                return StatusCode(500, new { message = "An error occurred while retrieving staff member" });
            }
        }

        [HttpPost]
        [RequirePermission(Permission.StaffCreate, requireWrite: true)]
        public async Task<IActionResult> CreateStaff(Staff staff)
        {
            try
            {
                LogAction($"Creating new staff member: {staff.FirstName} {staff.LastName}");
                
                var created = await _staffRepository.CreateAsync(staff);
                _auditService.Log("Create", "Staff", created.Id.ToString(), $"Created staff {created.FirstName} {created.LastName}");
                
                LogAction($"Staff member created successfully with ID: {created.Id}");
                return Ok(created);
            }
            catch (Exception ex)
            {
                LogError(ex, "Error creating staff member");
                return StatusCode(500, new { message = "An error occurred while creating staff member" });
            }
        }

        [HttpPut("{id}")]
        [RequirePermission(Permission.StaffEdit, requireWrite: true)]
        public async Task<IActionResult> UpdateStaff(int id, [FromBody] Staff staff)
        {
            try
            {
                if (id != staff.Id)
                {
                    LogAction($"ID mismatch - URL ID: {id}, Staff ID: {staff.Id}");
                    return BadRequest(new { message = "ID mismatch between URL and staff data" });
                }

                LogAction($"Updating staff member with ID: {id}");
                
                await _staffRepository.UpdateAsync(staff);
                _auditService.Log("Update", "Staff", id.ToString(), $"Updated staff {staff.FirstName} {staff.LastName}");
                
                LogAction($"Staff member updated successfully with ID: {id}");
                return Ok(new { message = "Staff member updated successfully" });
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error updating staff member with ID: {id}");
                return StatusCode(500, new { message = "An error occurred while updating staff member" });
            }
        }

        [HttpDelete("{id}")]
        [RequirePermission(Permission.StaffDelete, requireDelete: true)]
        public async Task<IActionResult> DeleteStaff(int id)
        {
            try
            {
                LogAction($"Deleting staff member with ID: {id}");
                
                await _staffRepository.DeleteAsync(id);
                _auditService.Log("Delete", "Staff", id.ToString(), $"Deleted staff {id}");
                
                LogAction($"Staff member deleted successfully with ID: {id}");
                return Ok(new { message = "Staff member deleted successfully" });
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error deleting staff member with ID: {id}");
                return StatusCode(500, new { message = "An error occurred while deleting staff member" });
            }
        }

        [HttpGet("role/{role}")]
        [RequirePermission(Permission.StaffView, requireRead: true)]
        public async Task<IActionResult> GetStaffByRole(string role)
        {
            try
            {
                LogAction($"Getting staff members by role: {role}");
                
                var staff = await _staffRepository.GetByRoleAsync(role);
                
                LogAction($"Staff members by role retrieved successfully - Count: {staff.Count()}");
                return Ok(staff);
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error retrieving staff members by role: {role}");
                return StatusCode(500, new { message = "An error occurred while retrieving staff members by role" });
            }
        }
    }
}
