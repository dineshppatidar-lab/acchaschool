using Microsoft.AspNetCore.Authorization;
using System.Text.Json;
using System.Security.Cryptography;
using System.Text;
using SchoolManagementApp.ApplicationCore.Common;
using SchoolManagementApp.ApplicationCore.Communication.WhatsApp.Interfaces;
using SchoolManagementApp.ApplicationCore.Entities;
using SchoolManagementApp.ApplicationCore._Interfaces;
using Microsoft.EntityFrameworkCore;

namespace SchoolManagementApp.Api.Controllers
{
    /// <summary>
    /// Anonymous webhook endpoint for WhatsApp provider (Meta Cloud API) callbacks.
    ///
    /// Security model (docs/critical-issues/07-whatsapp-webhook-signature.md):
    ///   1. GET verification handshake: echoes hub.challenge only when hub.verify_token
    ///      matches a tenant's stored token (constant-time comparison).
    ///   2. POST status events: the request is accepted ONLY when the raw body's
    ///      HMAC-SHA256 signature matches X-Hub-Signature-256 for exactly one tenant's
    ///      stored WebhookSecretEncrypted (Meta signs every delivery). The tenant whose
    ///      secret verifies becomes the request's tenant context for downstream
    ///      processing (AmbientTenantContext), so status updates stay tenant-scoped.
    /// Multi-tenant: no JWT exists for provider callbacks — tenancy is established
    /// cryptographically from the signature, never from client-controllable fields.
    /// </summary>
    [ApiController]
    [Route("api/whatsapp/webhook")]
    public class WhatsAppWebhookController : ControllerBase
    {
        private readonly IAppDbContext _context;
        private readonly ISecretProtector _secrets;
        private readonly IWhatsAppService _whatsAppService;
        private readonly ILogger<WhatsAppWebhookController> _logger;

        public WhatsAppWebhookController(IAppDbContext context, ISecretProtector secrets, IWhatsAppService whatsAppService, ILogger<WhatsAppWebhookController> logger)
        {
            _context = context;
            _secrets = secrets;
            _whatsAppService = whatsAppService;
            _logger = logger;
        }

        /// <summary>Meta webhook verification handshake (hub.challenge echo).</summary>
        [HttpGet]
        [AllowAnonymous]
        public async Task<IActionResult> Verify([FromQuery(Name = "hub.mode")] string? mode,
                                                [FromQuery(Name = "hub.verify_token")] string? verifyToken,
                                                [FromQuery(Name = "hub.challenge")] string? challenge)
        {
            if (string.IsNullOrWhiteSpace(verifyToken) || string.IsNullOrWhiteSpace(challenge))
                return BadRequest("Missing verification parameters.");

            // Find the tenant whose verify token matches (tokens are stored encrypted).
            // Comparison is constant-time to prevent token-scanning timing oracles.
            var configs = await _context.Set<WhatsAppConfiguration>().AsNoTracking().IgnoreQueryFilters().ToListAsync();
            foreach (var config in configs)
            {
                var stored = _secrets.Unprotect(config.WebhookVerifyTokenEncrypted);
                if (string.IsNullOrWhiteSpace(stored)) continue;

                if (FixedTimeEquals(stored, verifyToken))
                {
                    _logger.LogInformation("WhatsApp webhook verified for tenant {TenantId}.", config.TenantId);
                    return Content(challenge, "text/plain");
                }
            }

            _logger.LogWarning("WhatsApp webhook verification failed.");
            return Unauthorized();
        }

        /// <summary>
        /// Receives status events (sent/delivered/read/failed) from the provider.
        /// Requests without a valid X-Hub-Signature-256 are rejected with 401 and never processed.
        /// </summary>
        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> Receive()
        {
            // Read the RAW body — the signature is computed over exact bytes, not the
            // re-serialized model. Raw body capture requires buffering (see
            // WhatsAppWebhookRawBodyMiddleware wired in Startup).
            Request.EnableBuffering();
            using var reader = new StreamReader(Request.Body, Encoding.UTF8, detectEncodingFromByteOrderMarks: false,
                bufferSize: 1024 * 64, leaveOpen: true);
            var rawBody = await reader.ReadToEndAsync();
            Request.Body.Position = 0;

            var signatureHeader = Request.Headers["X-Hub-Signature-256"].ToString();

            // Resolve the tenant cryptographically: the payload is trusted only when its
            // signature verifies against a tenant's webhook secret.
            var configs = await _context.Set<WhatsAppConfiguration>().AsNoTracking().IgnoreQueryFilters().ToListAsync();

            WhatsAppConfiguration? verifiedConfig = null;
            foreach (var config in configs)
            {
                var secret = _secrets.Unprotect(config.WebhookSecretEncrypted);
                if (string.IsNullOrWhiteSpace(secret)) continue;

                if (VerifyHmacSignature(rawBody, signatureHeader, secret))
                {
                    verifiedConfig = config;
                    break;
                }
            }

            if (verifiedConfig == null)
            {
                _logger.LogWarning(
                    "WhatsApp webhook POST rejected: missing/invalid X-Hub-Signature-256 (body {Bytes} bytes, remote {Ip}).",
                    rawBody.Length, HttpContext.Connection.RemoteIpAddress?.ToString() ?? "unknown");
                return Unauthorized();
            }

            _logger.LogDebug("WhatsApp webhook signature verified for tenant {TenantId}.", verifiedConfig.TenantId);

            try
            {
                var payload = JsonDocument.Parse(rawBody);

                // Establish tenant context for downstream services (status log updates are
                // tenant-scoped via global query filters).
                using var tenantScope = AmbientTenantContext.BeginScope(verifiedConfig.TenantId);

                // payload.entry[].changes[].value.statuses[] → { id, status, errors[] }
                if (payload.RootElement.ValueKind != JsonValueKind.Object ||
                    !payload.RootElement.TryGetProperty("entry", out var entry) ||
                    entry.ValueKind != JsonValueKind.Array)
                {
                    // Validly signed but unsupported payload shape: 200 so Meta doesn't retry.
                    return Ok();
                }

                foreach (var entryItem in entry.EnumerateArray())
                {
                    if (!entryItem.TryGetProperty("changes", out var changes)) continue;
                    foreach (var change in changes.EnumerateArray())
                    {
                        if (!change.TryGetProperty("value", out var value)) continue;
                        if (!value.TryGetProperty("statuses", out var statuses) || statuses.ValueKind != JsonValueKind.Array) continue;

                        foreach (var status in statuses.EnumerateArray())
                        {
                            var messageId = status.TryGetProperty("id", out var id) ? id.GetString() : null;
                            var statusName = status.TryGetProperty("status", out var st) ? st.GetString() : null;
                            string? failureReason = null;
                            if (status.TryGetProperty("errors", out var errors) && errors.ValueKind == JsonValueKind.Array && errors.GetArrayLength() > 0)
                            {
                                var first = errors[0];
                                failureReason = first.TryGetProperty("message", out var em) ? em.GetString() : null;
                            }

                            if (!string.IsNullOrWhiteSpace(messageId) && !string.IsNullOrWhiteSpace(statusName))
                            {
                                await _whatsAppService.HandleStatusCallbackAsync(messageId, statusName, failureReason);
                                _logger.LogInformation("WhatsApp webhook: message {MessageId} → {Status} (tenant {TenantId}).",
                                    messageId, statusName, verifiedConfig.TenantId);
                            }
                        }
                    }
                }

                return Ok();
            }
            catch (JsonException jex)
            {
                // Signed but malformed — log and 200 so the provider doesn't retry-flood.
                _logger.LogWarning(jex, "WhatsApp webhook payload was not valid JSON (tenant {TenantId}).", verifiedConfig.TenantId);
                return Ok();
            }
            catch (Exception ex)
            {
                // Always 200 so the provider doesn't retry-flood; the failure is logged.
                _logger.LogError(ex, "Error processing WhatsApp webhook payload (tenant {TenantId}).", verifiedConfig.TenantId);
                return Ok();
            }
        }

        /// <summary>
        /// Verifies the Meta X-Hub-Signature-256 header ("sha256=&lt;hex&gt;") against the raw
        /// payload using HMAC-SHA256 with a constant-time final comparison.
        /// Pattern mirrors PaymentGatewayService.GenerateSignature (Issue 07).
        /// </summary>
        internal static bool VerifyHmacSignature(string rawBody, string? signatureHeader, string secret)
        {
            if (string.IsNullOrWhiteSpace(signatureHeader) || string.IsNullOrWhiteSpace(secret))
                return false;

            // Header format: "sha256=<lowercase hex digest>"
            var prefixIndex = signatureHeader.IndexOf('=');
            if (prefixIndex <= 0)
                return false;

            var scheme = signatureHeader[..prefixIndex].Trim();
            var providedHex = signatureHeader[(prefixIndex + 1)..].Trim();

            if (!string.Equals(scheme, "sha256", StringComparison.OrdinalIgnoreCase) || providedHex.Length == 0)
                return false;

            try
            {
                using var hmac = new HMACSHA256(Encoding.UTF8.GetBytes(secret));
                var expectedHex = Convert.ToHexString(hmac.ComputeHash(Encoding.UTF8.GetBytes(rawBody))).ToLowerInvariant();

                return FixedTimeEquals(expectedHex, providedHex);
            }
            catch
            {
                return false;
            }
        }

        /// <summary>Constant-time string equality (no early exit on first mismatch).</summary>
        private static bool FixedTimeEquals(string a, string b)
        {
            var aBytes = Encoding.UTF8.GetBytes(a);
            var bBytes = Encoding.UTF8.GetBytes(b);

            // CryptographicOperations.FixedTimeEquals requires equal lengths; XOR-fold
            // lengths into the result so mismatched lengths don't leak how unequal they are
            // beyond what the length itself already reveals.
            var lengthDiff = aBytes.Length ^ bBytes.Length;
            var maxLen = Math.Max(aBytes.Length, bBytes.Length);
            var diff = lengthDiff;
            for (var i = 0; i < maxLen; i++)
            {
                var aByte = i < aBytes.Length ? aBytes[i] : (byte)0;
                var bByte = i < bBytes.Length ? bBytes[i] : (byte)0;
                diff |= aByte ^ bByte;
            }
            return diff == 0;
        }
    }
}
