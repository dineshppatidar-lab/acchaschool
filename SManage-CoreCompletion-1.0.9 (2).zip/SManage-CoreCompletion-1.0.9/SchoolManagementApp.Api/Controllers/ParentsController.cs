using Microsoft.EntityFrameworkCore;
using SchoolManagementApp.ApplicationCore.Students.Interfaces;
using SchoolManagementApp.ApplicationCore.Entities;

namespace SchoolManagementApp.Api.Controllers
{
    public class ParentDto
    {
        public int Id { get; set; }
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public string? Email { get; set; }
        public string? ContactNumber { get; set; }
        public string? Occupation { get; set; }
        public string? Address { get; set; }
        public string? Relationship { get; set; }
        public bool IsEmergencyContact { get; set; }
    }

    public class ParentStudentDto
    {
        public int StudentId { get; set; }
        public string FullName { get; set; } = string.Empty;
        public string ClassName { get; set; } = string.Empty;
        public string SectionName { get; set; } = string.Empty;
    }

    public class ParentListDto
    {
        public int Id { get; set; }
        public string FirstName { get; set; } = string.Empty;
        public string LastName { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string ContactNumber { get; set; } = string.Empty;
        public string Occupation { get; set; } = string.Empty;
        public string Address { get; set; } = string.Empty;
        public string Relationship { get; set; } = string.Empty;
        public bool IsEmergencyContact { get; set; }
        public List<ParentStudentDto> Students { get; set; } = new();
    }

    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class ParentsController : BaseApiController
    {
        private readonly IParentService _parentService;
        private readonly SchoolManagementApp.Infrastructure.Data.ApplicationDbContext _context;

        public ParentsController(IParentService parentService, SchoolManagementApp.Infrastructure.Data.ApplicationDbContext context, ILogger<ParentsController> logger) : base(logger)
        {
            _parentService = parentService;
            _context = context;
        }

        [HttpGet]
        [RequirePermission(Permission.StudentsView, requireRead: true)]
        public async Task<ActionResult<ApiResponse<IEnumerable<ParentListDto>>>> GetAllParents()
        {
            var parents = await _parentService.GetAllParentsAsync();
            var dtos = parents.Select(p => new ParentListDto
            {
                Id = p.Id,
                FirstName = p.FirstName,
                LastName = p.LastName,
                Email = p.Email,
                ContactNumber = p.PhoneNumber,
                Occupation = p.Occupation,
                Address = p.Address,
                Relationship = p.Relationship,
                IsEmergencyContact = p.IsEmergencyContact,
                Students = p.Students.Select(s => new ParentStudentDto
                {
                    StudentId = s.Id,
                    FullName = $"{s.FirstName} {s.LastName}",
                    ClassName = s.Class?.Name ?? string.Empty,
                    SectionName = s.Section?.Name ?? string.Empty
                }).ToList()
            });
            return SuccessResponse<IEnumerable<ParentListDto>>(dtos, "Parents retrieved successfully");
        }

        [HttpGet("{id}")]
        [RequirePermission(Permission.StudentsViewDetails, requireRead: true)]
        public async Task<ActionResult<ApiResponse<Parent>>> GetParentById(int id)
        {
            var parent = await _parentService.GetParentByIdAsync(id);
            if (parent == null)
            {
                return NotFoundResponse<Parent>("Parent not found");
            }
            return SuccessResponse(parent, "Parent retrieved successfully");
        }

        [HttpPost]
        [RequirePermission(Permission.StudentsCreate, requireWrite: true)]
        public async Task<ActionResult<ApiResponse<Parent>>> CreateParent([FromBody] ParentDto dto)
        {
            var errors = new List<string>();
            if (string.IsNullOrWhiteSpace(dto.FirstName)) errors.Add("First name is required");
            if (string.IsNullOrWhiteSpace(dto.LastName)) errors.Add("Last name is required");
            if (string.IsNullOrWhiteSpace(dto.ContactNumber)) errors.Add("Contact number is required");
            if (errors.Any()) return ValidationErrorResponse<Parent>(errors);

            var parent = new Parent
            {
                FirstName = dto.FirstName!.Trim(),
                LastName = dto.LastName!.Trim(),
                Email = (dto.Email ?? string.Empty).Trim(),
                PhoneNumber = dto.ContactNumber!.Trim(),
                Occupation = (dto.Occupation ?? string.Empty).Trim(),
                Address = (dto.Address ?? string.Empty).Trim(),
                Relationship = (dto.Relationship ?? string.Empty).Trim(),
                IsEmergencyContact = dto.IsEmergencyContact
            };

            try
            {
                var createdParent = await _parentService.CreateParentAsync(parent);
                return SuccessResponse(createdParent, "Parent created successfully");
            }
            catch (InvalidOperationException ex)
            {
                return Conflict(new { success = false, message = ex.Message });
            }
        }

        [HttpPut("{id}")]
        [RequirePermission(Permission.StudentsEdit, requireWrite: true)]
        public async Task<ActionResult<ApiResponse>> UpdateParent(int id, [FromBody] ParentDto dto)
        {
            if (id != dto.Id)
            {
                return ValidationErrorResponse(new List<string> { "Route id and body id do not match." });
            }
            
            var parent = await _parentService.GetParentByIdAsync(id);
            if (parent == null) return NotFoundResponse("Parent not found");

            parent.FirstName = dto.FirstName ?? parent.FirstName;
            parent.LastName = dto.LastName ?? parent.LastName;
            parent.Email = (dto.Email ?? string.Empty).Trim();
            parent.PhoneNumber = dto.ContactNumber ?? parent.PhoneNumber;
            parent.Occupation = (dto.Occupation ?? string.Empty).Trim();
            parent.Address = (dto.Address ?? string.Empty).Trim();
            parent.Relationship = (dto.Relationship ?? string.Empty).Trim();
            parent.IsEmergencyContact = dto.IsEmergencyContact;

            try
            {
                await _parentService.UpdateParentAsync(parent);
            }
            catch (InvalidOperationException ex)
            {
                return Conflict(new { success = false, message = ex.Message });
            }
            return SuccessResponse("Parent updated successfully");
        }

        [HttpDelete("{id}")]
        [RequirePermission(Permission.StudentsDelete, requireDelete: true)]
        public async Task<ActionResult<ApiResponse>> DeleteParent(int id)
        {
            var parent = await _parentService.GetParentByIdAsync(id);
            if (parent == null) return NotFoundResponse("Parent not found");

            if (parent.Students.Any())
            {
                return ValidationErrorResponse(new List<string>
                {
                    $"Cannot delete: {parent.Students.Count} student(s) are linked to this parent. Unlink them first."
                });
            }
            if (!string.IsNullOrWhiteSpace(parent.Email))
            {
                var hasLogin = await _context.Users.IgnoreQueryFilters()
                    .AnyAsync(u => u.Email == parent.Email);
                if (hasLogin)
                {
                    return ValidationErrorResponse(new List<string>
                    {
                        "Cannot delete: this parent has a portal login. Deactivate the user account first."
                    });
                }
            }

            await _parentService.DeleteParentAsync(id);
            return SuccessResponse("Parent deleted successfully");
        }
    }
}
