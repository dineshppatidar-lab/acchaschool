using System.Net;

namespace SchoolManagementApp.Api.Controllers
{
    /// <summary>
    /// Setup Wizard Controller
    /// Manages initial school configuration and setup wizard workflow
    /// Provides endpoints for creating academic years and validating setup progress
    /// </summary>
    [Authorize]
    [ApiController]
    [Route("api/setup")]
    [Produces("application/json")]
    public class SetupController : BaseApiController
    {
        private readonly ITenantProvider _tenantProvider;
        private readonly ISetupService _setupService;
        private readonly ApplicationCore.Services.Interfaces.ILookupService _lookupService;

        public SetupController(
            ITenantProvider tenantProvider,
            ISetupService setupService,
            ApplicationCore.Services.Interfaces.ILookupService lookupService,
            ILogger<SetupController> logger) : base(logger)
        {
            _tenantProvider = tenantProvider;
            _setupService = setupService;
            _lookupService = lookupService;
        }

        /// <summary>
        /// Create a new academic year
        /// </summary>
        /// <param name="request">Academic year details</param>
        /// <returns>Created academic year with ID</returns>
        [HttpPost("academic-years")]
        [RequirePermission(Permission.SystemSettings, requireWrite: true)] // Using a common permission for now
        public async Task<ActionResult<ApiResponse<AcademicYear>>> CreateAcademicYear(
            [FromBody] CreateAcademicYearRequest request)
        {
            _logger.LogInformation("Creating academic year with request: {@Request}", request);

            try
            {
                if (request == null)
                {
                    return ValidationErrorResponse<AcademicYear>(new List<string> { "Request body cannot be empty" });
                }

                int tenantId = _tenantProvider.TenantId;
                var academicYear = await _setupService.CreateAcademicYearAsync(tenantId, request);

                return SuccessResponse(academicYear, "Academic Year created successfully");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating academic year: {Message}", ex.Message);
                return ErrorResponse<AcademicYear>(ex.Message);
            }
        }

        /// <summary>
        /// Update an existing academic year
        /// </summary>
        /// <param name="id">Academic Year ID</param>
        /// <param name="request">Updated academic year details</param>
        /// <returns>Updated academic year</returns>
        [HttpPut("academic-years/{id}")]
        [RequirePermission(Permission.SystemSettings, requireWrite: true)]
        public async Task<ActionResult<ApiResponse<AcademicYear>>> UpdateAcademicYear(
            [FromRoute] int id,
            [FromBody] CreateAcademicYearRequest request)
        {
            _logger.LogInformation("Updating academic year {Id} with request: {@Request}", id, request);

            try
            {
                if (request == null)
                {
                    return ValidationErrorResponse<AcademicYear>(new List<string> { "Request body cannot be empty" });
                }

                int tenantId = _tenantProvider.TenantId;
                var academicYear = await _setupService.UpdateAcademicYearAsync(tenantId, id, request);

                return SuccessResponse(academicYear, "Academic Year updated successfully");
            }
            catch (KeyNotFoundException ex)
            {
                return ErrorResponse<AcademicYear>(ex.Message, HttpStatusCode.NotFound);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error updating academic year {Id}", id);
                return ErrorResponse<AcademicYear>("Error updating academic year: " + ex.Message);
            }
        }

        /// <summary>
        /// Get all academic years for current tenant
        /// </summary>
        /// <returns>List of academic years</returns>
        [HttpGet("academic-years")]
        // DashboardView, not SystemSettings: this list feeds the app-wide academic-year
        // selector (topbar, attendance, timetable) — every authenticated user needs it.
        // Requiring SystemSettings made the year selector silently fail for all other
        // roles (found via end-to-end UI verification).
        [RequirePermission(Permission.DashboardView, requireRead: true)]
        public async Task<ActionResult<ApiResponse<List<AcademicYear>>>> GetAcademicYears()
        {
            _logger.LogInformation("Retrieving academic years");

            try
            {
                int tenantId = _tenantProvider.TenantId;
                var academicYears = await _setupService.GetAcademicYearsAsync(tenantId);

                return SuccessResponse(academicYears, "Academic Years retrieved successfully");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving academic years");
                return ErrorResponse<List<AcademicYear>>("Error retrieving academic years: " + ex.Message);
            }
        }

        /// <summary>
        /// Get classes for a specific academic year
        /// </summary>
        /// <param name="academicYearId">Academic Year ID</param>
        /// <returns>List of classes</returns>
        [HttpGet("academic-years/{academicYearId}/classes")]
        [RequirePermission(Permission.SystemSettings, requireRead: true)]
        public async Task<ActionResult<ApiResponse<List<Class>>>> GetClassesByYear([FromRoute] int academicYearId)
        {
            _logger.LogInformation("Retrieving classes for academic year {AcademicYearId}", academicYearId);

            try
            {
                int tenantId = _tenantProvider.TenantId;
                var classes = await _setupService.GetClassesByYearAsync(tenantId, academicYearId);

                return SuccessResponse(classes, "Classes retrieved successfully");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving classes for academic year {AcademicYearId}", academicYearId);
                return ErrorResponse<List<Class>>("Error retrieving classes: " + ex.Message);
            }
        }

        /// <summary>
        /// Create classes
        /// </summary>
        /// <param name="request">Classes to create</param>
        /// <returns>Created classes</returns>
        [HttpPost("classes")]
        [RequirePermission(Permission.SystemSettings, requireWrite: true)]
        public async Task<ActionResult<ApiResponse<List<Class>>>> CreateClasses(
            [FromBody] CreateClassesRequest request)
        {
            _logger.LogInformation("Creating classes");

            try
            {
                if (request?.Classes == null || request.Classes.Count == 0)
                {
                    return ValidationErrorResponse<List<Class>>(new List<string> { "At least one class is required" });
                }

                int tenantId = _tenantProvider.TenantId;
                var createdClasses = await _setupService.CreateClassesAsync(tenantId, request);

                return SuccessResponse(createdClasses, "Classes created successfully");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating classes");
                return ErrorResponse<List<Class>>("Error creating classes: " + ex.Message);
            }
        }

        /// <summary>
        /// Get sections for a specific class
        /// </summary>
        /// <param name="classId">Class ID</param>
        /// <returns>List of sections</returns>
        [HttpGet("classes/{classId}/sections")]
        [RequirePermission(Permission.SystemSettings, requireRead: true)]
        public async Task<ActionResult<ApiResponse<List<Section>>>> GetSectionsByClass([FromRoute] int classId)
        {
            _logger.LogInformation("Retrieving sections for class {ClassId}", classId);

            try
            {
                int tenantId = _tenantProvider.TenantId;
                var sections = await _setupService.GetSectionsByClassAsync(tenantId, classId);

                return SuccessResponse(sections, "Sections retrieved successfully");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving sections for class {ClassId}", classId);
                return ErrorResponse<List<Section>>("Error retrieving sections: " + ex.Message);
            }
        }

        /// <summary>
        /// Create sections
        /// </summary>
        /// <param name="request">Sections to create</param>
        /// <returns>Created sections</returns>
        [HttpPost("sections")]
        [RequirePermission(Permission.SystemSettings, requireWrite: true)]
        public async Task<ActionResult<ApiResponse<List<Section>>>> CreateSections(
            [FromBody] CreateSectionsRequest request)
        {
            _logger.LogInformation("Creating sections");

            try
            {
                if (request?.Sections == null || request.Sections.Count == 0)
                {
                    return ValidationErrorResponse<List<Section>>(new List<string> { "At least one section is required" });
                }

                int tenantId = _tenantProvider.TenantId;
                var createdSections = await _setupService.CreateSectionsAsync(tenantId, request);

                return SuccessResponse(createdSections, "Sections created successfully");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating sections");
                return ErrorResponse<List<Section>>("Error creating sections: " + ex.Message);
            }
        }

        /// <summary>
        /// Create subjects
        /// </summary>
        /// <param name="request">Subjects to create</param>
        /// <returns>Created subjects</returns>
        [HttpPost("subjects")]
        [RequirePermission(Permission.SystemSettings, requireWrite: true)]
        public async Task<ActionResult<ApiResponse<List<Subject>>>> CreateSubjects(
            [FromBody] CreateSubjectsRequest request)
        {
            _logger.LogInformation("Creating subjects");

            try
            {
                if (request?.Subjects == null || request.Subjects.Count == 0)
                {
                    return ValidationErrorResponse<List<Subject>>(new List<string> { "At least one subject is required" });
                }

                int tenantId = _tenantProvider.TenantId;
                var createdSubjects = await _setupService.CreateSubjectsAsync(tenantId, request);

                return SuccessResponse(createdSubjects, "Subjects created successfully");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating subjects");
                return ErrorResponse<List<Subject>>("Error creating subjects: " + ex.Message);
            }
        }

        /// <summary>
        /// Get subjects for a specific class
        /// </summary>
        /// <param name="classId">Class ID</param>
        /// <returns>List of subjects</returns>
        [HttpGet("classes/{classId}/subjects")]
        [RequirePermission(Permission.SystemSettings, requireRead: true)]
        public async Task<ActionResult<ApiResponse<List<Subject>>>> GetSubjectsByClass([FromRoute] int classId)
        {
            _logger.LogInformation("Retrieving subjects for class {ClassId}", classId);

            try
            {
                int tenantId = _tenantProvider.TenantId;
                var subjects = await _setupService.GetSubjectsByClassAsync(tenantId, classId);

                return SuccessResponse(subjects, "Subjects retrieved successfully");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving subjects for class {ClassId}", classId);
                return ErrorResponse<List<Subject>>("Error retrieving subjects: " + ex.Message);
            }
        }

        /// <summary>
        /// Get all staff records for the current tenant (Setup Wizard Staff tab)
        /// </summary>
        [HttpGet("staff")]
        [RequirePermission(Permission.SystemSettings, requireRead: true)]
        public async Task<ActionResult<ApiResponse<List<Staff>>>> GetStaff()
        {
            _logger.LogInformation("Retrieving staff for setup wizard");

            try
            {
                int tenantId = _tenantProvider.TenantId;
                var staff = await _setupService.GetStaffAsync(tenantId);

                return SuccessResponse(staff, "Staff retrieved successfully");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving staff for setup wizard");
                return ErrorResponse<List<Staff>>("Error retrieving staff: " + ex.Message);
            }
        }

        /// <summary>
        /// Create staff members
        /// </summary>
        /// <param name="request">Staff member details</param>
        /// <returns>Created staff member</returns>
        [HttpPost("staff")]
        [RequirePermission(Permission.SystemSettings, requireWrite: true)]
        public async Task<ActionResult<ApiResponse<Staff>>> CreateStaff(
            [FromBody] CreateStaffRequest request)
        {
            _logger.LogInformation("Creating staff member");

            try
            {
                if (request == null)
                {
                    return ValidationErrorResponse<Staff>(new List<string> { "Request body cannot be empty" });
                }

                int tenantId = _tenantProvider.TenantId;
                var staff = await _setupService.CreateStaffAsync(tenantId, request);

                return SuccessResponse(staff, "Staff member created successfully");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating staff member");
                return ErrorResponse<Staff>("Error creating staff member: " + ex.Message);
            }
        }

        /// <summary>
        /// Create staff structure (departments and positions)
        /// </summary>
        /// <param name="request">Staff structure details</param>
        /// <returns>Success status</returns>
        [HttpPost("staff-structure/setup")]
        [RequirePermission(Permission.SystemSettings, requireWrite: true)]
        public async Task<ActionResult<ApiResponse<bool>>> CreateStaffStructure(
            [FromBody] CreateStaffStructureRequest request)
        {
            _logger.LogInformation("Creating staff structure");

            try
            {
                if (request == null)
                {
                    return ValidationErrorResponse<bool>(new List<string> { "Request body cannot be empty" });
                }

                if (request.Departments == null || request.Departments.Count == 0)
                {
                    return ValidationErrorResponse<bool>(new List<string> { "At least one department is required" });
                }

                int tenantId = _tenantProvider.TenantId;
                var success = await _setupService.CreateStaffStructureAsync(tenantId, request);

                return SuccessResponse(success, "Staff structure created successfully");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating staff structure");
                return ErrorResponse<bool>("Error creating staff structure: " + ex.Message);
            }
        }

        /// <summary>
        /// Create one saved staff-structure lookup value (department or position).
        /// Uses SystemSettings (like the rest of the wizard) rather than the lookup
        /// admin's SystemManage, so the admin doing first-time setup can manage the
        /// tab end-to-end with the same permission.
        /// </summary>
        [HttpPost("staff-structure/lookup")]
        [RequirePermission(Permission.SystemSettings, requireWrite: true)]
        public async Task<ActionResult<ApiResponse<ApplicationCore.Services.Interfaces.LookupItemDto>>> CreateStaffStructureLookup(
            [FromBody] RenameStaffLookupRequest request)
        {
            _logger.LogInformation("Creating staff structure lookup {LookupType} = {Label}", request?.LookupType, request?.Label);

            try
            {
                var error = ValidateStaffLookupType(request?.LookupType);
                if (error != null)
                {
                    return ValidationErrorResponse<ApplicationCore.Services.Interfaces.LookupItemDto>(new List<string> { error });
                }

                var created = await _lookupService.CreateLookupValueAsync(request!.LookupType, request.Label ?? string.Empty);
                return SuccessResponse(created, "Staff structure entry created successfully");
            }
            catch (InvalidOperationException ex)
            {
                return ErrorResponse<ApplicationCore.Services.Interfaces.LookupItemDto>(ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating staff structure lookup");
                return ErrorResponse<ApplicationCore.Services.Interfaces.LookupItemDto>("Error creating staff structure entry: " + ex.Message);
            }
        }

        /// <summary>
        /// Rename a saved staff-structure lookup value (department or position).
        /// Delegates to the same DB-backed lookup CRUD used by the
        /// Departments/Designations admin screens, so both stay in sync.
        /// </summary>
        [HttpPut("staff-structure/lookup/{id}")]
        [RequirePermission(Permission.SystemSettings, requireWrite: true)]
        public async Task<ActionResult<ApiResponse<ApplicationCore.Services.Interfaces.LookupItemDto>>> RenameStaffStructureLookup(
            [FromRoute] int id,
            [FromBody] RenameStaffLookupRequest request)
        {
            _logger.LogInformation("Renaming staff structure lookup {Id} to {Label}", id, request?.Label);

            try
            {
                var error = ValidateStaffLookupType(request?.LookupType);
                if (error != null)
                {
                    return ValidationErrorResponse<ApplicationCore.Services.Interfaces.LookupItemDto>(new List<string> { error });
                }

                var updated = await _lookupService.UpdateLookupValueAsync(request!.LookupType, id, request.Label ?? string.Empty);
                return SuccessResponse(updated, "Staff structure entry updated successfully");
            }
            catch (InvalidOperationException ex) when (ex.Message == "Lookup value not found")
            {
                return ErrorResponse<ApplicationCore.Services.Interfaces.LookupItemDto>(ex.Message, HttpStatusCode.NotFound);
            }
            catch (InvalidOperationException ex)
            {
                return ErrorResponse<ApplicationCore.Services.Interfaces.LookupItemDto>(ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error renaming staff structure lookup {Id}", id);
                return ErrorResponse<ApplicationCore.Services.Interfaces.LookupItemDto>("Error renaming staff structure entry: " + ex.Message);
            }
        }

        /// <summary>
        /// Delete (soft) a saved staff-structure lookup value (department or position).
        /// </summary>
        [HttpDelete("staff-structure/lookup/{id}")]
        [RequirePermission(Permission.SystemSettings, requireDelete: true)]
        public async Task<ActionResult<ApiResponse<bool>>> DeleteStaffStructureLookup(
            [FromRoute] int id,
            [FromQuery] string lookupType)
        {
            _logger.LogInformation("Deleting staff structure lookup {Id} of type {LookupType}", id, lookupType);

            try
            {
                var error = ValidateStaffLookupType(lookupType);
                if (error != null)
                {
                    return ValidationErrorResponse<bool>(new List<string> { error });
                }

                await _lookupService.DeleteLookupValueAsync(lookupType, id);
                return SuccessResponse(true, "Staff structure entry deleted successfully");
            }
            catch (InvalidOperationException ex) when (ex.Message == "Lookup value not found")
            {
                return ErrorResponse<bool>(ex.Message, HttpStatusCode.NotFound);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error deleting staff structure lookup {Id}", id);
                return ErrorResponse<bool>("Error deleting staff structure entry: " + ex.Message);
            }
        }

        private static string? ValidateStaffLookupType(string? lookupType)
        {
            return lookupType == "staff-departments" || lookupType == "staff-positions"
                ? null
                : "lookupType must be 'staff-departments' or 'staff-positions'.";
        }

        /// <summary>
        /// Create fee structure using existing DailyOps DTO
        /// </summary>
        /// <param name="request">Fee structure details from DailyOps</param>
        /// <returns>Created fee structure</returns>
        [HttpPost("fees/structure/setup")]
        [RequirePermission(Permission.SystemSettings, requireWrite: true)]
        public async Task<ActionResult<ApiResponse<FeeStructure>>> CreateFeeStructure(
            [FromBody] CreateFeeStructureRequest request)
        {
            _logger.LogInformation("Creating fee structure");

            try
            {
                if (request == null)
                {
                    return ValidationErrorResponse<FeeStructure>(new List<string> { "Request body cannot be empty" });
                }

                int tenantId = _tenantProvider.TenantId;
                var feeStructure = await _setupService.CreateFeeStructureAsync(tenantId, request);

                return SuccessResponse(feeStructure, "Fee structure created successfully");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating fee structure");
                return ErrorResponse<FeeStructure>("Error creating fee structure: " + ex.Message);
            }
        }

        /// <summary>
        /// Create fee installments
        /// </summary>
        /// <param name="request">Fee installment details</param>
        /// <returns>Created installments</returns>
        [HttpPost("fees/installments/setup")]
        [RequirePermission(Permission.SystemSettings, requireWrite: true)]
        public async Task<ActionResult<ApiResponse<FeeInstallmentsResponse>>> CreateFeeInstallments(
            [FromBody] CreateFeeInstallmentsRequest request)
        {
            _logger.LogInformation("Creating fee installments");

            try
            {
                if (request == null || request.FeeStructureId <= 0)
                {
                    return ValidationErrorResponse<FeeInstallmentsResponse>(new List<string> { "Fee structure ID is required" });
                }

                int tenantId = _tenantProvider.TenantId;
                var response = await _setupService.CreateFeeInstallmentsAsync(tenantId, request);

                return SuccessResponse(response, "Fee installments created successfully");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating fee installments");
                return ErrorResponse<FeeInstallmentsResponse>("Error creating fee installments: " + ex.Message);
            }
        }

        /// <summary>
        /// Create payment methods
        /// </summary>
        /// <param name="request">Payment methods to create</param>
        /// <returns>Created payment methods</returns>
        [HttpPost("payment-methods/setup")]
        [RequirePermission(Permission.SystemSettings, requireWrite: true)]
        public async Task<ActionResult<ApiResponse<List<PaymentMethod>>>> CreatePaymentMethods(
            [FromBody] CreatePaymentMethodsRequest request)
        {
            _logger.LogInformation("Creating payment methods");

            try
            {
                if (request?.PaymentMethods == null || request.PaymentMethods.Count == 0)
                {
                    return ValidationErrorResponse<List<PaymentMethod>>(new List<string> { "At least one payment method is required" });
                }

                int tenantId = _tenantProvider.TenantId;
                var createdMethods = await _setupService.CreatePaymentMethodsAsync(tenantId, request);

                return SuccessResponse(createdMethods, "Payment methods created successfully");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating payment methods");
                return ErrorResponse<List<PaymentMethod>>("Error creating payment methods: " + ex.Message);
            }
        }

        /// <summary>
        /// Get all active payment methods
        /// </summary>
        /// <returns>List of payment methods</returns>
        [HttpGet("payment-methods")]
        [RequirePermission(Permission.SystemSettings, requireRead: true)]
        public async Task<ActionResult<ApiResponse<List<PaymentMethod>>>> GetPaymentMethods()
        {
            _logger.LogInformation("Retrieving payment methods");

            try
            { 
                // SystemSettings read permission is used here (instead of PaymentsView):
                // this endpoint is consumed by the Setup Wizard's Payment tab, where an
                // administrator configuring the school may not have finance permissions.
                var methods = await _setupService.GetPaymentMethodsAsync();

                return SuccessResponse(methods, "Payment methods retrieved successfully");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving payment methods");
                return ErrorResponse<List<PaymentMethod>>("Error retrieving payment methods: " + ex.Message);
            }
        }

        /// <summary>
        /// App-level setup status for the current tenant: required-only progress
        /// plus per-step completion. Powers the persistent setup banner, dashboard
        /// card and sidebar badge. Uses DashboardView (not SystemSettings) so any
        /// authenticated staff user can see onboarding status; mutation still
        /// requires SystemSettings on the individual setup endpoints.
        /// </summary>
        [HttpGet("status")]
        [RequirePermission(Permission.DashboardView, requireRead: true)]
        public async Task<ActionResult<ApiResponse<ApplicationCore.Setup.Interfaces.SetupStatusSummary>>> GetSetupStatus()
        {
            _logger.LogInformation("Getting setup status");

            try
            {
                int tenantId = _tenantProvider.TenantId;
                var status = await _setupService.GetSetupStatusSummaryAsync(tenantId);

                return SuccessResponse(status, "Setup status retrieved successfully");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting setup status");
                return ErrorResponse<ApplicationCore.Setup.Interfaces.SetupStatusSummary>("Error getting setup status: " + ex.Message);
            }
        }

        /// <summary>
        /// Validate current setup progress
        /// </summary>
        /// <returns>Setup validation result</returns>
        [HttpGet("validate")]
        [RequirePermission(Permission.SystemSettings, requireRead: true)]
        public async Task<ActionResult<ApiResponse<SetupValidationResult>>> ValidateSetup()
        {
            _logger.LogInformation("Validating setup");

            try
            {
                int tenantId = _tenantProvider.TenantId;
                var validation = await _setupService.ValidateSetupAsync(tenantId);

                return SuccessResponse(validation, "Setup validation completed");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error validating setup");
                return ErrorResponse<SetupValidationResult>("Error validating setup: " + ex.Message);
            }
        }

        /// <summary>
        /// Get setup checklist with progress
        /// </summary>
        /// <returns>Setup checklist</returns>
        [HttpGet("checklist")]
        [RequirePermission(Permission.SystemSettings, requireRead: true)]
        public async Task<ActionResult<ApiResponse<SetupChecklistResult>>> GetSetupChecklist()
        {
            _logger.LogInformation("Getting setup checklist");

            try
            {
                int tenantId = _tenantProvider.TenantId;
                var checklist = await _setupService.GetSetupChecklistAsync(tenantId);

                return SuccessResponse(checklist, "Setup checklist retrieved successfully");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving setup checklist");
                return ErrorResponse<SetupChecklistResult>("Error retrieving setup checklist: " + ex.Message);
            }
        }

        /// <summary>
        /// Mark setup wizard as complete
        /// </summary>
        /// <param name="request">Completion details</param>
        /// <returns>Setup status</returns>
        [HttpPost("complete")]
        [RequirePermission(Permission.SystemSettings, requireWrite: true)]
        public async Task<ActionResult<ApiResponse<SetupCompleteResponse>>> CompleteSetup(
            [FromBody] CompleteSetupRequest request)
        {
            _logger.LogInformation("Completing setup");

            try
            {
                int tenantId = _tenantProvider.TenantId;
                int userId = int.Parse(GetCurrentUserId() ?? "0");

                var setupStatus = await _setupService.MarkSetupCompleteAsync(
                    tenantId, userId, request?.CompletionNotes);

                var response = new SetupCompleteResponse
                {
                    TenantId = setupStatus.TenantId,
                    SetupCompletedOn = setupStatus.SetupCompletedOn,
                    SetupCompletedBy = setupStatus.SetupCompletedBy,
                    CompletionNotes = setupStatus.CompletionNotes,
                    CanStartTeaching = setupStatus.IsComplete
                };

                return SuccessResponse(response, "Setup marked as complete");
            }
            catch (InvalidOperationException ex)
            {
                _logger.LogWarning(ex, "Setup completion validation failed");
                return ValidationErrorResponse<SetupCompleteResponse>(new List<string> { ex.Message });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error completing setup");
                return ErrorResponse<SetupCompleteResponse>("Error completing setup: " + ex.Message);
            }
        }
    }
}
