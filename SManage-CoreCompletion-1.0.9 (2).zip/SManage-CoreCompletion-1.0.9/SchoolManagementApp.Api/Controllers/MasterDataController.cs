﻿using Microsoft.AspNetCore.Authorization;

// TODO: This DTO should be moved to a shared DTOs folder in your Application layer.
public class DropdownItemDto
{
    public int Id { get; set; }
    public string Name { get; set; }
}

[Authorize] // 1. SECURE: Protects the endpoint, ensuring only logged-in users can access it.
[ApiController]
[Route("api/master-data")] // Matches the apiUrl in your service
public class MasterDataController : ControllerBase
{
    // 2. DEPENDENCY INJECTION: Injecting a service from the Application Layer.
    // This follows the Clean Architecture principles from your SystemArchitecture.md.
    // private readonly IMasterDataApplicationService _masterDataService;

    public MasterDataController()
    {
        // _masterDataService = masterDataService;
    }

    [HttpGet("student-lookups")]
    public async Task<IActionResult> GetStudentLookups()
    {
        // 3. ASYNC & DELEGATION: The controller's job is to handle HTTP, not business logic.
        // We delegate the work to the service and make the method asynchronous.
        // var lookups = await _masterDataService.GetStudentLookupsAsync();

        // NOTE: Using mock data until the service is implemented.
        var lookups = new
        {
            bloodGroups = new List<DropdownItemDto> { new DropdownItemDto { Id = 1, Name = "O+" } },
            religions = new List<DropdownItemDto> { new DropdownItemDto { Id = 1, Name = "Christianity" } },
            categories = new List<DropdownItemDto> { new DropdownItemDto { Id = 1, Name = "General" } }
        };
        return Ok(await Task.FromResult(lookups)); // Simulating async call
    }

    [HttpGet("parent-lookups")]
    public async Task<IActionResult> GetParentLookups()
    {
        // var lookups = await _masterDataService.GetParentLookupsAsync();
        var lookups = new
        {
            relationships = new List<DropdownItemDto> { new DropdownItemDto { Id = 1, Name = "Father" } },
            occupations = new List<DropdownItemDto> { new DropdownItemDto { Id = 1, Name = "Engineer" } },
            incomeGroups = new List<DropdownItemDto> { new DropdownItemDto { Id = 1, Name = "10-20 LPA" } }
        };
        return Ok(await Task.FromResult(lookups)); // Simulating async call
    }
}
