using Microsoft.AspNetCore.Http;
using System.IO;
using System.Text;
using ClosedXML.Excel;

namespace SchoolManagementApp.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class StaffImportExportController : ControllerBase
    {
        private readonly ApplicationDbContext _context;
        public StaffImportExportController(ApplicationDbContext context)
        {
            _context = context;
        }

        /// <summary>
        /// Imports staff from an uploaded Excel (.xlsx) file. Expects headers
        /// FirstName, LastName, Email on the first worksheet (header row optional).
        /// </summary>
        [HttpPost("import")]
        [EnableRateLimiting("Export")]
        [RequirePermission(Permission.StaffCreate, requireWrite: true)]
        public async Task<IActionResult> ImportStaff(IFormFile file)
        {
            if (file == null || file.Length == 0) return BadRequest("No file uploaded");

            var ext = Path.GetExtension(file.FileName).ToLowerInvariant();
            if (ext != ".xlsx")
                return BadRequest(new { message = "Please upload an Excel (.xlsx) file. CSV is not supported." });

            try
            {
                using var workbook = new XLWorkbook(file.OpenReadStream());
                var ws = workbook.Worksheet(1);
                var rows = ws.RowsUsed();

                var staffList = new List<Staff>();
                var failedRows = new List<object>();
                var firstRow = ws.FirstRowUsed();
                var headerIsText = firstRow != null &&
                    string.Equals(firstRow.Cell(1).GetString().Trim(), "FirstName", StringComparison.OrdinalIgnoreCase);

                foreach (var row in rows)
                {
                    // Skip the header row when present
                    if (headerIsText && row.RowNumber() == firstRow!.RowNumber()) continue;

                    var firstName = row.Cell(1).GetString().Trim();
                    var lastName = row.Cell(2).GetString().Trim();
                    var email = row.Cell(3).GetString().Trim();

                    if (string.IsNullOrWhiteSpace(firstName) && string.IsNullOrWhiteSpace(lastName))
                    {
                        failedRows.Add(new { row = row.RowNumber(), error = "FirstName and LastName are required" });
                        continue;
                    }

                    staffList.Add(new Staff
                    {
                        FirstName = firstName,
                        LastName = lastName,
                        Email = email
                    });
                }

                _context.Staff.AddRange(staffList);
                await _context.SaveChangesAsync();
                return Ok(new { count = staffList.Count, failedCount = failedRows.Count, failedRows });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Error importing staff: " + ex.Message });
            }
        }

        /// <summary>
        /// Exports all staff of the current tenant as an Excel (.xlsx) workbook.
        /// </summary>
        [HttpGet("export")]
        [EnableRateLimiting("Export")]
        [RequirePermission(Permission.ReportsView, requireRead: true)]
        public IActionResult ExportStaff()
        {
            var staffList = _context.Staff.ToList();

            using var workbook = new XLWorkbook();
            var ws = workbook.Worksheets.Add("Staff");

            ws.Cell(1, 1).Value = "FirstName";
            ws.Cell(1, 2).Value = "LastName";
            ws.Cell(1, 3).Value = "Email";
            ws.Range(1, 1, 1, 3).Style.Font.Bold = true;

            var rowIdx = 2;
            foreach (var s in staffList)
            {
                ws.Cell(rowIdx, 1).Value = s.FirstName;
                ws.Cell(rowIdx, 2).Value = s.LastName;
                ws.Cell(rowIdx, 3).Value = s.Email;
                rowIdx++;
            }

            ws.Columns().AdjustToContents();

            using var stream = new MemoryStream();
            workbook.SaveAs(stream);
            var bytes = stream.ToArray();

            const string contentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
            return File(bytes, contentType, $"staff_{DateTime.UtcNow:yyyyMMdd}.xlsx");
        }
    }
}
