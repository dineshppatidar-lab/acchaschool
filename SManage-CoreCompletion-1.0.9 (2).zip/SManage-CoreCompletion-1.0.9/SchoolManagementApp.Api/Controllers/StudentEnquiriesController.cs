using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SchoolManagementApp.Api.Common;
using SchoolManagementApp.ApplicationCore.Common.Models;
using SchoolManagementApp.ApplicationCore.Entities;
using SchoolManagementApp.ApplicationCore.Students.Interfaces;

namespace SchoolManagementApp.Api.Controllers
{
    /// <summary>
    /// Student Enquiry endpoints — pre-admission enquiries captured for
    /// information only. No relation to the admission flow or the Students
    /// table. All data access goes through IStudentEnquiryService.
    /// </summary>
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class StudentEnquiriesController : BaseApiController
    {
        private readonly IStudentEnquiryService _enquiryService;

        public StudentEnquiriesController(IStudentEnquiryService enquiryService, ILogger<StudentEnquiriesController> logger)
            : base(logger)
        {
            _enquiryService = enquiryService;
        }

        [HttpGet]
        [RequirePermission(Permission.StudentsView, requireRead: true)]
        public async Task<ActionResult<ApiResponse<List<StudentEnquiry>>>> GetEnquiries([FromQuery] string? search = null)
        {
            try
            {
                var enquiries = await _enquiryService.GetAllEnquiriesAsync(search);
                return SuccessResponse(enquiries.ToList(), "Student enquiries retrieved successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error retrieving student enquiries", new { search });
                return ErrorResponse<List<StudentEnquiry>>("Failed to retrieve student enquiries");
            }
        }

        [HttpGet("{id}")]
        [RequirePermission(Permission.StudentsView, requireRead: true)]
        public async Task<ActionResult<ApiResponse<StudentEnquiry>>> GetEnquiry(int id)
        {
            try
            {
                var enquiry = await _enquiryService.GetEnquiryByIdAsync(id);
                if (enquiry == null)
                {
                    return NotFoundResponse<StudentEnquiry>($"Student enquiry with ID {id} not found");
                }

                return SuccessResponse(enquiry, "Student enquiry retrieved successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error retrieving student enquiry", new { id });
                return ErrorResponse<StudentEnquiry>("Failed to retrieve student enquiry");
            }
        }

        [HttpPost]
        [RequirePermission(Permission.StudentsCreate, requireWrite: true)]
        public async Task<ActionResult<ApiResponse<StudentEnquiry>>> CreateEnquiry([FromBody] StudentEnquiry enquiry)
        {
            try
            {
                var validationErrors = ValidateMandatoryFields(enquiry);
                if (validationErrors.Count > 0)
                {
                    return ValidationErrorResponse<StudentEnquiry>(validationErrors);
                }

                var created = await _enquiryService.CreateEnquiryAsync(enquiry);
                return SuccessResponse(created, "Student enquiry saved successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error creating student enquiry", new { enquiry.StudentName });
                return ErrorResponse<StudentEnquiry>("Failed to save student enquiry");
            }
        }

        [HttpPut("{id}")]
        [RequirePermission(Permission.StudentsEdit, requireWrite: true)]
        public async Task<ActionResult<ApiResponse<StudentEnquiry>>> UpdateEnquiry(int id, [FromBody] StudentEnquiry enquiry)
        {
            try
            {
                var validationErrors = ValidateMandatoryFields(enquiry);
                if (validationErrors.Count > 0)
                {
                    return ValidationErrorResponse<StudentEnquiry>(validationErrors);
                }

                var updated = await _enquiryService.UpdateEnquiryAsync(id, enquiry);
                if (updated == null)
                {
                    return NotFoundResponse<StudentEnquiry>($"Student enquiry with ID {id} not found");
                }

                return SuccessResponse(updated, "Student enquiry updated successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error updating student enquiry", new { id });
                return ErrorResponse<StudentEnquiry>("Failed to update student enquiry");
            }
        }

        [HttpDelete("{id}")]
        [RequirePermission(Permission.StudentsDelete, requireDelete: true)]
        public async Task<ActionResult<ApiResponse>> DeleteEnquiry(int id)
        {
            try
            {
                var deleted = await _enquiryService.DeleteEnquiryAsync(id);
                if (!deleted)
                {
                    return NotFoundResponse($"Student enquiry with ID {id} not found");
                }

                return SuccessResponse("Student enquiry deleted successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error deleting student enquiry", new { id });
                return ErrorResponse("Failed to delete student enquiry");
            }
        }

        private static List<string> ValidateMandatoryFields(StudentEnquiry enquiry)
        {
            var errors = new List<string>();
            if (string.IsNullOrWhiteSpace(enquiry.StudentName))
            {
                errors.Add("Student name is required.");
            }
            if (string.IsNullOrWhiteSpace(enquiry.ContactNo))
            {
                errors.Add("Contact number is required.");
            }
            return errors;
        }
    }
}
