
using SchoolManagementApp.ApplicationCore.Academic.Interfaces;

namespace SchoolManagementApp.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class ExaminationTypeController : BaseApiController
    {
        private readonly IExaminationTypeRepository _examinationTypeRepository;
        private readonly IExaminationRepository _examinationRepository;

        public ExaminationTypeController(
            IExaminationTypeRepository examinationTypeRepository,
            IExaminationRepository examinationRepository,
            ILogger<ExaminationTypeController> logger) : base(logger)
        {
            _examinationTypeRepository = examinationTypeRepository;
            _examinationRepository = examinationRepository;
        }

        [HttpGet]
        [RequirePermission(Permission.ExaminationsView, requireRead: true)]
        public async Task<IActionResult> GetAll()
        {
            try
            {
                var types = await _examinationTypeRepository.GetAllAsync();
                return SuccessResult(types, "Examination types retrieved successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error retrieving examination types");
                return ErrorResult("Failed to retrieve examination types");
            }
        }

        [HttpGet("{id}")]
        [RequirePermission(Permission.ExaminationsView, requireRead: true)]
        public async Task<IActionResult> GetById(int id)
        {
            try
            {
                var type = await _examinationTypeRepository.GetByIdAsync(id);
                return type != null ? SuccessResult(type) : NotFound("Examination type not found");
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error retrieving examination type {id}");
                return ErrorResult("Failed to retrieve examination type");
            }
        }

        [HttpPost]
        [RequirePermission(Permission.ExaminationsEdit, requireWrite: true)]
        public async Task<IActionResult> Create([FromBody] ExaminationType type)
        {
            try
            {
                LogAction("Creating new examination type");
                var result = await _examinationTypeRepository.AddAsync(type);
                return CreatedResult(result, "Examination type created successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error creating examination type");
                return ErrorResult("Failed to create examination type");
            }
        }

        [HttpPut("{id}")]
        [RequirePermission(Permission.ExaminationsEdit, requireWrite: true)]
        public async Task<IActionResult> Update(int id, [FromBody] ExaminationType type)
        {
            try
            {
                LogAction($"Updating examination type: {id}");
                var existing = await _examinationTypeRepository.GetByIdAsync(id);
                if (existing == null) return NotFound("Examination type not found");

                existing.Name = type.Name;
                existing.Description = type.Description;
                existing.WeightagePercentage = type.WeightagePercentage;
                existing.IsActive = type.IsActive;

                await _examinationTypeRepository.UpdateAsync(existing);
                return SuccessResult(existing, "Examination type updated successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error updating examination type {id}");
                return ErrorResult("Failed to update examination type");
            }
        }

        [HttpDelete("{id}")]
        [RequirePermission(Permission.ExaminationsEdit, requireDelete: true)]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                LogAction($"Deleting examination type: {id}");
                
                var inUse = await _examinationRepository.ExistsAsync(e => e.ExaminationTypeId == id);
                if (inUse)
                {
                    return ErrorResult("Cannot delete examination type as it is in use by existing examinations.");
                }

                await _examinationTypeRepository.DeleteAsync(id);
                return SuccessResult("Examination type deleted successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error deleting examination type {id}");
                return ErrorResult("Failed to delete examination type");
            }
        }
    }
}
