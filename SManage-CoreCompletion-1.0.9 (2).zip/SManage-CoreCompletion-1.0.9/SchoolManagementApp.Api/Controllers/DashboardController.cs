using SchoolManagementApp.ApplicationCore.Services.Interfaces;

namespace SchoolManagementApp.Api.Controllers
{
    [Authorize]
    public class DashboardController : BaseApiController
    {
        private readonly IDashboardService _dashboardService;
        
        public DashboardController(IDashboardService dashboardService, ILogger<DashboardController> logger) : base(logger)
        {
            _dashboardService = dashboardService;
        }

        [HttpGet]
        // Dashboard is open to every authenticated user — all roles get value from it,
        // and every role in PermissionService already receives DashboardView by default.
        [Authorize]
        [LegacyCompatibility] // Maintain compatibility with existing frontend
        public async Task<IActionResult> GetDashboard()
        {
            try
            {
                LogAction("Getting dashboard data");
                
                var dashboardData = await _dashboardService.GetDashboardDataAsync();

                return CompatibleSuccessResult(dashboardData, "Dashboard data retrieved successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error retrieving dashboard data");
                return ErrorResult("An error occurred while retrieving dashboard data");
            }
        }
    }
}
