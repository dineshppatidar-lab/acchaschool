using SchoolManagementApp.ApplicationCore.Services.Interfaces;

namespace SchoolManagementApp.Api.Controllers
{
    [ApiController]
    [Route("api/lookup")]
    [Authorize] // Secured lookup data
    public class LookupController : BaseApiController
    {
        private readonly ILookupService _lookupService;

        public LookupController(ILookupService lookupService, ILogger<LookupController> logger) : base(logger)
        {
            _lookupService = lookupService;
        }

        [HttpGet("staff-positions")]
        public async Task<ActionResult<LookupItemDto[]>> GetStaffPositions() => Ok(await _lookupService.GetStaffPositionsAsync());

        [HttpGet("staff-departments")]
        public async Task<ActionResult<LookupItemDto[]>> GetStaffDepartments() => Ok(await _lookupService.GetStaffDepartmentsAsync());

        [HttpGet("staff-qualifications")]
        public async Task<ActionResult<LookupItemDto[]>> GetStaffQualifications() => Ok(await _lookupService.GetStaffQualificationsAsync());

        [HttpGet("fee-types")]
        public async Task<ActionResult<FeeTypeDto[]>> GetFeeTypes() => Ok(await _lookupService.GetFeeTypesAsync());

        [HttpGet("fee-statuses")]
        public async Task<ActionResult<FeeStatusDto[]>> GetFeeStatuses() => Ok(await _lookupService.GetFeeStatusesAsync());

        [HttpGet("payment-methods")]
        public async Task<ActionResult<PaymentLookupMethodDto[]>> GetPaymentMethods() => Ok(await _lookupService.GetPaymentMethodsAsync());

        [HttpGet("message-priorities")]
        public async Task<ActionResult<EnumLookupDto[]>> GetMessagePriorities() => Ok(await _lookupService.GetMessagePrioritiesAsync());

        [HttpGet("message-types")]
        public async Task<ActionResult<EnumLookupDto[]>> GetMessageTypes() => Ok(await _lookupService.GetMessageTypesAsync());

        [HttpGet("expense-categories")]
        public async Task<ActionResult<EnumLookupDto[]>> GetExpenseCategories() => Ok(await _lookupService.GetExpenseCategoriesAsync());

        [HttpGet("user-roles")]
        public async Task<ActionResult<UserRoleDto[]>> GetUserRoles() => Ok(await _lookupService.GetUserRolesAsync());

        // ---------------------------------------------------------
        // DB-backed CRUD for lookup lists (designations, departments, ...)
        // ---------------------------------------------------------

        // GET returns items with real DB IDs so edit/delete work; seeds defaults on first read
        [HttpGet("{lookupType}")]
        [RequirePermission(Permission.SystemManage, requireRead: true)]
        public async Task<IActionResult> GetGenericLookup(string lookupType)
        {
            return Ok(await _lookupService.GetGenericLookupAsync(lookupType));
        }

        [HttpPost("{lookupType}")]
        [RequirePermission(Permission.SystemManage, requireWrite: true)]
        public async Task<IActionResult> CreateLookup(string lookupType, [FromBody] LookupItemDto payload)
        {
            try
            {
                var created = await _lookupService.CreateLookupValueAsync(lookupType, payload.Label);
                return Ok(new { success = true, message = "Created successfully.", data = created });
            }
            catch (InvalidOperationException ex)
            {
                return BadRequest(new { success = false, message = ex.Message });
            }
        }

        [HttpPut("{lookupType}/{id}")]
        [RequirePermission(Permission.SystemManage, requireWrite: true)]
        public async Task<IActionResult> UpdateLookup(string lookupType, int id, [FromBody] LookupItemDto payload)
        {
            try
            {
                var updated = await _lookupService.UpdateLookupValueAsync(lookupType, id, payload.Label);
                return Ok(new { success = true, message = "Updated successfully.", data = updated });
            }
            catch (InvalidOperationException ex) when (ex.Message == "Lookup value not found")
            {
                return NotFound(new { success = false, message = ex.Message });
            }
            catch (InvalidOperationException ex)
            {
                return BadRequest(new { success = false, message = ex.Message });
            }
        }

        [HttpDelete("{lookupType}/{id}")]
        [RequirePermission(Permission.SystemManage, requireDelete: true)]
        public async Task<IActionResult> DeleteLookup(string lookupType, int id)
        {
            try
            {
                await _lookupService.DeleteLookupValueAsync(lookupType, id);
                return Ok(new { success = true, message = "Deleted successfully." });
            }
            catch (InvalidOperationException ex) when (ex.Message == "Lookup value not found")
            {
                return NotFound(new { success = false, message = ex.Message });
            }
        }
    }
}