
using SchoolManagementApp.ApplicationCore.Students.Interfaces;

namespace SchoolManagementApp.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class StudentsController : BaseApiController
    {
        private readonly IStudentRepository _studentRepository;
        private readonly SchoolManagementApp.ApplicationCore.Common.Services.IAuditService _auditService;
        private readonly SchoolManagementApp.ApplicationCore.Students.Services.IStudentManagementService _studentManagementService;

        public StudentsController(
            IStudentRepository studentRepository, 
            SchoolManagementApp.ApplicationCore.Common.Services.IAuditService auditService, 
            SchoolManagementApp.ApplicationCore.Students.Services.IStudentManagementService studentManagementService,
            ILogger<StudentsController> logger) : base(logger)
        {
            _studentRepository = studentRepository;
            _auditService = auditService;
            _studentManagementService = studentManagementService;
        }

        [HttpGet]
        [RequirePermission(Permission.StudentsView, requireRead: true)]
        public async Task<ActionResult<PaginatedApiResponse<Student>>> GetStudents([FromQuery] PaginatedRequest request)
        {
            try
            {
                LogAction("GetStudents", new { request.Page, request.PageSize, request.Search });
                
                var query = await _studentRepository.GetAllAsync();
                var students = query;
                if (!string.IsNullOrEmpty(request.Search))
                {
                    var term = request.Search.Trim();
                    students = query.Where(s =>
                        (!string.IsNullOrEmpty(s.FirstName) && (s.FirstName + " " + s.LastName).IndexOf(term, StringComparison.OrdinalIgnoreCase) >= 0)
                        || (!string.IsNullOrEmpty(s.Email) && s.Email.IndexOf(term, StringComparison.OrdinalIgnoreCase) >= 0)
                        || (!string.IsNullOrEmpty(s.RollNumber) && s.RollNumber.IndexOf(term, StringComparison.OrdinalIgnoreCase) >= 0)
                        || (!string.IsNullOrEmpty(s.ScholarNumber) && s.ScholarNumber.IndexOf(term, StringComparison.OrdinalIgnoreCase) >= 0)
                    );
                }
                    
                var total = students.Count();
                var paged = students.Skip(request.Skip).Take(request.Take).ToList();
                
                return PaginatedSuccessResponse(paged, total, request.Page, request.PageSize, "Students retrieved successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error retrieving students", request);
                return PaginatedErrorResponse<Student>("Failed to retrieve students");
            }
        }

        [HttpGet("{id}")]
        [RequirePermission(Permission.StudentsViewDetails, requireRead: true)]
        public async Task<ActionResult<ApiResponse<Student>>> GetStudent(int id)
        {
            try
            {
                LogAction("GetStudent", new { StudentId = id });
                
                var student = await _studentRepository.GetByIdAsync(id);
                if (student == null)
                {
                    return NotFoundResponse<Student>($"Student with ID {id} not found");
                }
                
                return SuccessResponse(student, "Student retrieved successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error retrieving student", new { StudentId = id });
                return ErrorResponse<Student>("Failed to retrieve student");
            }
        }

        [HttpPost]
        [RequirePermission(Permission.StudentsCreate, requireWrite: true)]
        public async Task<ActionResult<ApiResponse<Student>>> CreateStudent(Student student)
        {
            var createdStudent = await _studentRepository.CreateAsync(student);
            _auditService.Log("Create", "Student", createdStudent.Id.ToString(), $"Created student {createdStudent.FirstName} {createdStudent.LastName}");
            return SuccessResponse(createdStudent, "Student created successfully");
        }

        [HttpPut("{id}")]
        [RequirePermission(Permission.StudentsEdit, requireWrite: true)]
        public async Task<ActionResult<ApiResponse>> UpdateStudent(int id, Student student)
        {
            if (id != student.Id)
            {
                return ValidationErrorResponse(new List<string> { "Route id and body id do not match." });
            }

            await _studentRepository.UpdateAsync(student);
            _auditService.Log("Update", "Student", id.ToString(), $"Updated student {student.FirstName} {student.LastName}");
            return SuccessResponse("Student updated successfully");
        }

        [HttpDelete("{id}")]
        [RequirePermission(Permission.StudentsDelete, requireDelete: true)]
        public async Task<ActionResult<ApiResponse>> DeleteStudent(int id)
        {
            await _studentRepository.DeleteAsync(id);
            _auditService.Log("Delete", "Student", id.ToString(), $"Deleted student {id}");
            return SuccessResponse("Student deleted successfully");
        }

        [HttpGet("class/{classId}")]
        [RequirePermission(Permission.StudentsView, requireRead: true)]
        public async Task<ActionResult<ApiResponse<IEnumerable<Student>>>> GetStudentsByClass(int classId)
        {
            var students = await _studentRepository.GetByClassAsync(classId);
            return SuccessResponse<IEnumerable<Student>>(students, "Students by class retrieved successfully");
        }

        [HttpGet("section/{sectionId}")]
        [RequirePermission(Permission.StudentsView, requireRead: true)]
        public async Task<ActionResult<ApiResponse<IEnumerable<Student>>>> GetStudentsBySection(int sectionId)
        {
            var students = await _studentRepository.GetBySectionAsync(sectionId);
            return SuccessResponse<IEnumerable<Student>>(students, "Students by section retrieved successfully");
        }

        [HttpGet("full-details")]
        [RequirePermission(Permission.StudentsView, requireRead: true)]
        public async Task<ActionResult<PaginatedApiResponse<StudentFullDetailsDto>>> GetAllStudentFullDetails([FromQuery] string? search = null, [FromQuery] int page = 1, [FromQuery] int pageSize = 20)
        {
            var students = await _studentManagementService.GetAllStudentFullDetailsAsync();
            var filteredStudents = students;
            if (!string.IsNullOrEmpty(search))
            {
                var term = search.Trim();
                filteredStudents = students.Where(s =>
                    (!string.IsNullOrEmpty(s.FirstName) && (s.FirstName + " " + s.LastName).IndexOf(term, StringComparison.OrdinalIgnoreCase) >= 0)
                    || (!string.IsNullOrEmpty(s.Email) && s.Email.IndexOf(term, StringComparison.OrdinalIgnoreCase) >= 0)
                    || (!string.IsNullOrEmpty(s.RollNumber) && s.RollNumber.IndexOf(term, StringComparison.OrdinalIgnoreCase) >= 0)
                    || (!string.IsNullOrEmpty(s.ScholarNumber) && s.ScholarNumber.IndexOf(term, StringComparison.OrdinalIgnoreCase) >= 0)
                );
            }
            var total = filteredStudents.Count();
            var paged = filteredStudents.Skip((page - 1) * pageSize).Take(pageSize).ToList();
            return PaginatedSuccessResponse(paged, total, page, pageSize, "Student full details retrieved successfully");
        }

        [HttpPost("full-details")]
        [RequirePermission(Permission.StudentsCreate, requireWrite: true)]
        public async Task<ActionResult<ApiResponse<StudentFullDetailsDto>>> CreateStudentFullDetails([FromBody] StudentFullDetailsDto studentDto)
        {
            var createdStudent = await _studentManagementService.CreateStudentFullDetailsAsync(studentDto);
            return SuccessResponse(createdStudent, "Student full details created successfully");
        }

        [HttpGet("full-details/{id}")]
        [RequirePermission(Permission.StudentsViewDetails, requireRead: true)]
        public async Task<ActionResult<ApiResponse<StudentFullDetailsDto>>> GetStudentFullDetails(int id)
        {
            var student = await _studentManagementService.GetStudentFullDetailsAsync(id);
            if (student == null)
            {
                return NotFoundResponse<StudentFullDetailsDto>("Student full details not found");
            }
            return SuccessResponse(student, "Student full details retrieved successfully");
        }

        [HttpPut("full-details/{id}")]
        [RequirePermission(Permission.StudentsEdit, requireWrite: true)]
        public async Task<ActionResult<ApiResponse>> UpdateStudentFullDetails(int id, [FromBody] StudentFullDetailsDto studentDto)
        {
            await _studentManagementService.UpdateStudentFullDetailsAsync(id, studentDto);
            return SuccessResponse("Student full details updated successfully");
        }

        [HttpPost("full-details/mock")]
        [RequirePermission(Permission.StudentsCreate, requireWrite: true)]
        public ActionResult<ApiResponse<StudentFullDetailsDto>> SaveMockStudentFullDetails([FromBody] StudentFullDetailsDto studentDto)
        {
            // In a real application, you would save the studentDto to a database or other persistent storage.
            // For this mock endpoint, we'll just return the received DTO.
            Console.WriteLine($"Received mock student full details: {studentDto.FirstName} {studentDto.LastName}");
            return SuccessResponse(studentDto, "Mock student full details saved successfully");
        }
    }
}
