using SchoolManagementApp.ApplicationCore.Entities;
using SchoolManagementApp.ApplicationCore.Common.Services;
using SchoolManagementApp.ApplicationCore.Fees.Interfaces;

namespace SchoolManagementApp.Api.Controllers
{
    /// <summary>
    /// Fee Rules Engine CRUD — implements the API the Fee Rules UI
    /// (/app/fees/rules) already calls: late fees, sibling discounts,
    /// merit discounts, early-payment discounts, overdue fines.
    /// Delegates all data access to IAdvancedFinanceService (service/repository pattern).
    /// </summary>
    [ApiController]
    [Authorize]
    [Route("api/advancedfinance/fee-rules")]
    public class FeeRulesController : BaseApiController
    {
        private readonly IAdvancedFinanceService _financeService;
        private readonly AuditService _auditService;

        public FeeRulesController(
            IAdvancedFinanceService financeService,
            AuditService auditService,
            ILogger<FeeRulesController> logger) : base(logger)
        {
            _financeService = financeService;
            _auditService = auditService;
        }

        public class CreateFeeRuleRequest
        {
            public string Name { get; set; } = string.Empty;
            public string Description { get; set; } = string.Empty;
            public FeeRuleType RuleType { get; set; } = FeeRuleType.LateFee;
            public FeeRuleCondition Condition { get; set; } = FeeRuleCondition.Always;
            public decimal ConditionValue { get; set; }
            public decimal ActionValue { get; set; }
            public bool IsPercentage { get; set; }
            public int Priority { get; set; } = 1;
            public int? AcademicYearId { get; set; }
            public int? ClassId { get; set; }
        }

        [HttpGet]
        [RequirePermission(Permission.FeesView, requireRead: true)]
        public async Task<IActionResult> GetAll([FromQuery] int? ruleType = null)
        {
            try
            {
                var rules = await _financeService.GetFeeRulesAsync(ruleType);
                return SuccessResult(rules, "Fee rules retrieved");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error retrieving fee rules");
                return ErrorResult("Error retrieving fee rules");
            }
        }

        [HttpPost]
        [RequirePermission(Permission.FeesManageStructure, requireWrite: true)]
        public async Task<IActionResult> Create([FromBody] CreateFeeRuleRequest request)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(request.Name))
                    return ErrorResult("Rule name is required");
                if (request.ActionValue <= 0)
                    return ErrorResult("Action value must be greater than 0");

                var rule = new FeeRule
                {
                    Name = request.Name,
                    Description = request.Description ?? string.Empty,
                    RuleType = request.RuleType,
                    Condition = request.Condition,
                    ConditionValue = request.ConditionValue,
                    ActionValue = request.ActionValue,
                    IsPercentage = request.IsPercentage,
                    Priority = request.Priority,
                    AcademicYearId = request.AcademicYearId,
                    ClassId = request.ClassId,
                    IsActive = true
                };

                var created = await _financeService.CreateFeeRuleAsync(rule);
                _auditService.Log("Create", "FeeRule", created.Id.ToString(), $"Created fee rule '{created.Name}'");
                return CreatedResult(created, "Fee rule created");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error creating fee rule");
                return ErrorResult("Error creating fee rule");
            }
        }

        [HttpPut("{id}")]
        [RequirePermission(Permission.FeesManageStructure, requireWrite: true)]
        public async Task<IActionResult> Update(int id, [FromBody] CreateFeeRuleRequest request)
        {
            try
            {
                var rule = new FeeRule
                {
                    Name = request.Name,
                    Description = request.Description ?? string.Empty,
                    RuleType = request.RuleType,
                    Condition = request.Condition,
                    ConditionValue = request.ConditionValue,
                    ActionValue = request.ActionValue,
                    IsPercentage = request.IsPercentage,
                    Priority = request.Priority,
                    AcademicYearId = request.AcademicYearId,
                    ClassId = request.ClassId,
                    IsActive = true
                };

                var updated = await _financeService.UpdateFeeRuleAsync(id, rule);
                if (updated == null) return StatusCode(404, new ApiResponse { Message = "Fee rule not found" });

                _auditService.Log("Update", "FeeRule", id.ToString(), $"Updated fee rule '{updated.Name}'");
                return SuccessResult(updated, "Fee rule updated");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error updating fee rule");
                return ErrorResult("Error updating fee rule");
            }
        }

        [HttpDelete("{id}")]
        [RequirePermission(Permission.FeesManageStructure, requireDelete: true)]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                var deleted = await _financeService.DeleteFeeRuleAsync(id);
                if (!deleted) return StatusCode(404, new ApiResponse { Message = "Fee rule not found" });

                _auditService.Log("Delete", "FeeRule", id.ToString(), $"Deleted fee rule {id}");
                return SuccessResult("Fee rule deleted");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error deleting fee rule");
                return ErrorResult("Error deleting fee rule");
            }
        }
    }
}
