using SchoolManagementApp.ApplicationCore.Fees.Interfaces;
using SchoolManagementApp.Infrastructure.Repositories;
using System.Text;
using IEmailService = SchoolManagementApp.ApplicationCore.Communication.Interfaces.IEmailService;

namespace SchoolManagementApp.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class FeesController : BaseApiController
    {
        private readonly IFeesRepository _feesRepository;
        private readonly IFeePaymentRepository _feePaymentRepository;
        private readonly IStudentFeeAdjustmentRepository _adjustmentRepository;
        private readonly IGroupPaymentRepository _groupPaymentRepository;
        private readonly ITenantProvider _tenantProvider;
        private readonly IEmailService _emailService;

        public FeesController(
            IFeesRepository feesRepository,
            IFeePaymentRepository feePaymentRepository,
            IStudentFeeAdjustmentRepository adjustmentRepository,
            IGroupPaymentRepository groupPaymentRepository,
            ILogger<FeesController> logger,
            ITenantProvider tenantProvider,
            IEmailService emailService) : base(logger)
        {
            _feesRepository = feesRepository;
            _feePaymentRepository = feePaymentRepository;
            _adjustmentRepository = adjustmentRepository;
            _groupPaymentRepository = groupPaymentRepository;
            _tenantProvider = tenantProvider;
            _emailService = emailService;
        }

        [HttpGet]
        [RequirePermission(Permission.FeesView, requireRead: true)]
        public async Task<ActionResult<PaginatedApiResponse<Fee>>> GetFees(
            [FromQuery] int page = 1,
            [FromQuery] int pageSize = 10,
            [FromQuery] string sort = "Name",
            [FromQuery] string order = "asc",
            [FromQuery] string search = "")
        {
            var (fees, total) = await _feesRepository.GetFeesAsync(page, pageSize, sort, order, search);
            return PaginatedSuccessResponse(fees, total, page, pageSize, "Fees retrieved successfully");
        }

        [HttpGet("{id}")]
        [RequirePermission(Permission.FeesView, requireRead: true)]
        public async Task<ActionResult<ApiResponse<Fee>>> GetFee(int id)
        {
            var fee = await _feesRepository.GetFeeByIdAsync(id);
            if (fee == null)
            {
                return NotFoundResponse<Fee>("Fee not found");
            }
            return SuccessResponse(fee, "Fee retrieved successfully");
        }

        [HttpPost]
        [RequirePermission(Permission.FeesCollect, requireWrite: true)]
        public async Task<ActionResult<ApiResponse<Fee>>> CreateFee([FromBody] Fee fee)
        {
            if (!ModelState.IsValid)
            {
                var errors = ModelState.Values
                    .SelectMany(v => v.Errors)
                    .Select(e => string.IsNullOrWhiteSpace(e.ErrorMessage) ? "Invalid fee data" : e.ErrorMessage)
                    .Distinct()
                    .ToList();

                return ValidationErrorResponse<Fee>(errors, "All required fields must be completed to create the fee record");
            }

            var createdFee = await _feesRepository.CreateFeeAsync(fee);
            _logger.LogInformation("Fee created for tenant {TenantId} and student {StudentId}", _tenantProvider.TenantId, fee.StudentId);
            return SuccessResponse(createdFee, "Fee created successfully");
        }

        [HttpPut("{id}")]
        [RequirePermission(Permission.FeesCollect, requireWrite: true)]
        public async Task<ActionResult<ApiResponse>> UpdateFee(int id, [FromBody] Fee fee)
        {
            if (id != fee.Id)
            {
                return ValidationErrorResponse(new List<string> { "Route id and body id do not match." });
            }
            await _feesRepository.UpdateFeeAsync(fee);
            return SuccessResponse("Fee updated successfully");
        }

        [HttpDelete("{id}")]
        [RequirePermission(Permission.FeesCollect, requireDelete: true)]
        public async Task<ActionResult<ApiResponse>> DeleteFee(int id)
        {
            await _feesRepository.DeleteFeeAsync(id);
            return SuccessResponse("Fee deleted successfully");
        }

        // ==================== FEE REPORT ENDPOINTS ====================

        /// <summary>
        /// Fee collection report: totals for the period plus breakdowns by day,
        /// payment method, class and fee type. Powers /app/finance/reports.
        /// </summary>
        [HttpGet("reports/collection")]
        [RequirePermission(Permission.FeesView, requireRead: true)]
        public async Task<ActionResult<ApiResponse<object>>> GetFeeCollectionReport(
            [FromQuery] DateTime? fromDate,
            [FromQuery] DateTime? toDate)
        {
            try
            {
                var start = (fromDate ?? DateTime.Today.AddDays(-30)).Date;
                var end = (toDate ?? DateTime.Today).Date.AddDays(1).AddTicks(-1);

                var payments = (await _feePaymentRepository.GetSuccessfulPaymentsWithDetailsAsync(start, end)).ToList();

                var totalCollected = payments.Sum(p => p.AmountPaid);
                var totalLateFees = payments.Sum(p => p.LateFeeAmount ?? 0);
                var totalDiscounts = payments.Sum(p => p.DiscountAmount ?? 0);
                var transactionCount = payments.Count;

                var byDay = payments
                    .GroupBy(p => p.PaymentDate.Date)
                    .Select(g => new { date = g.Key.ToString("yyyy-MM-dd"), amount = g.Sum(x => x.AmountPaid), count = g.Count() })
                    .OrderBy(x => x.date)
                    .ToList();

                var byMethod = payments
                    .GroupBy(p => p.PaymentMethod.ToString())
                    .Select(g => new { method = g.Key, amount = g.Sum(x => x.AmountPaid), count = g.Count() })
                    .OrderByDescending(x => x.amount)
                    .ToList();

                var byClass = payments
                    .GroupBy(p => p.Student?.Class?.Name ?? "Unassigned")
                    .Select(g => new { className = g.Key, amount = g.Sum(x => x.AmountPaid), count = g.Count() })
                    .OrderByDescending(x => x.amount)
                    .ToList();

                var byFeeType = payments
                    .GroupBy(p => p.FeeInstallment?.Name ?? "Other")
                    .Select(g => new { feeType = g.Key, amount = g.Sum(x => x.AmountPaid), count = g.Count() })
                    .OrderByDescending(x => x.amount)
                    .ToList();

                var recent = payments.Take(50).Select(p => new
                {
                    receiptNumber = p.ReceiptNumber,
                    paymentDate = p.PaymentDate,
                    studentName = p.Student != null ? $"{p.Student.FirstName} {p.Student.LastName}" : $"Student #{p.StudentId}",
                    className = p.Student?.Class?.Name,
                    feeType = p.FeeInstallment?.Name,
                    amount = p.AmountPaid,
                    method = p.PaymentMethod.ToString(),
                    transactionId = p.TransactionId
                }).ToList();

                object report = new
                {
                    fromDate = start,
                    toDate = end,
                    totalCollected,
                    totalLateFees,
                    totalDiscounts,
                    transactionCount,
                    averageTransaction = transactionCount > 0 ? Math.Round(totalCollected / transactionCount, 2) : 0,
                    byDay,
                    byMethod,
                    byClass,
                    byFeeType,
                    recentTransactions = recent
                };
                return SuccessResponse(report, "Fee collection report generated");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error generating fee collection report");
                return ErrorResponse<object>("Error generating fee collection report");
            }
        }

        // ==================== RECEIPT ENDPOINTS ====================

        [HttpGet("{id}/receipt/download")]
        [RequirePermission(Permission.FeesView, requireRead: true)]
        public async Task<IActionResult> DownloadFeeReceipt(int id, [FromQuery] string template = "classic")
        {
            try
            {
                var fee = await _feesRepository.GetFeeByIdAsync(id);
                if (fee == null)
                    return NotFound(new ApiResponse { Message = "Fee not found" });

                var html = FeeReceiptTemplates.Render(fee, template);
                var content = Encoding.UTF8.GetBytes(html);
                var fileName = $"FeeReceipt_{fee.Id}_{fee.Student?.FirstName}_{fee.FeeType}.html";

                return File(content, "text/html; charset=utf-8", fileName);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error generating fee receipt for fee {FeeId}", id);
                return BadRequest(new ApiResponse { Message = "Error generating receipt" });
            }
        }

        [HttpPost("{id}/receipt/email")]
        [RequirePermission(Permission.FeesCollect, requireWrite: true)]
        public async Task<IActionResult> EmailFeeReceipt(int id)
        {
            try
            {
                var fee = await _feesRepository.GetFeeByIdAsync(id);
                if (fee == null)
                    return NotFound(new ApiResponse { Message = "Fee not found" });

                if (fee.Student == null)
                    return BadRequest(new ApiResponse { Message = "Student information not found for this fee" });

                // Try to get parent email first, fall back to student email
                var parentEmail = fee.Student.Parent?.Email;
                var studentEmail = fee.Student.Email;
                var recipientEmail = !string.IsNullOrWhiteSpace(parentEmail) ? parentEmail : studentEmail;

                if (string.IsNullOrWhiteSpace(recipientEmail))
                    return BadRequest(new ApiResponse { Message = "No email address found for this student or parent" });

                var studentName = $"{fee.Student.FirstName} {fee.Student.LastName}";
                var subject = $"Fee Receipt - {fee.FeeType} - {studentName}";
                var body = FeeReceiptTemplates.Render(fee, "classic");

                await _emailService.SendEmailAsync(recipientEmail, subject, body, isHtml: true);

                _logger.LogInformation("Fee receipt emailed to {Email} for fee {FeeId}", recipientEmail, id);
                return Ok(new ApiResponse { Success = true, Message = $"Receipt emailed successfully to {recipientEmail}" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error emailing fee receipt for fee {FeeId}", id);
                return BadRequest(new ApiResponse { Success = false, Message = "Failed to send email. Please try again." });
            }
        }

        // ==================== RECEIPT HTML GENERATOR ====================

        private string GenerateReceiptHtml(Fee fee)
        {
            var studentName = fee.Student != null
                ? System.Net.WebUtility.HtmlEncode($"{fee.Student.FirstName} {fee.Student.LastName}")
                : $"Student #{fee.StudentId}";

            var rollNumber = fee.Student?.RollNumber ?? "N/A";
            var scholarNumber = fee.Student?.ScholarNumber ?? "N/A";
            var className = fee.Student?.Class?.Name ?? "N/A";
            var sectionName = fee.Student?.Section?.Name ?? "N/A";
            var contactNumber = fee.Student?.ContactNumber ?? "N/A";
            var email = fee.Student?.Email ?? "N/A";

            var payments = fee.Payments?.ToList() ?? new List<Payment>();
            var totalPaid = payments.Where(p => p.Status == "Success").Sum(p => p.Amount);
            var remaining = fee.Amount - totalPaid;

            var sb = new StringBuilder();
            sb.AppendLine("<!DOCTYPE html>");
            sb.AppendLine("<html lang=\"en\">");
            sb.AppendLine("<head><meta charset=\"utf-8\"/>");
            sb.AppendLine("<title>Fee Receipt</title>");
            sb.AppendLine("<style>");
            sb.AppendLine("body { font-family: 'Segoe UI', Arial, Helvetica, sans-serif; color: #1a1a2e; background: #f0f2f5; margin: 0; padding: 20px; }");
            sb.AppendLine(".receipt-container { max-width: 700px; margin: 0 auto; background: white; border-radius: 12px; box-shadow: 0 2px 12px rgba(0,0,0,0.08); overflow: hidden; }");
            sb.AppendLine(".receipt-header { background: linear-gradient(135deg, #1a237e, #283593); color: white; padding: 32px; text-align: center; }");
            sb.AppendLine(".receipt-header h1 { margin: 0 0 4px; font-size: 22px; font-weight: 700; letter-spacing: 1px; }");
            sb.AppendLine(".receipt-header .school-name { font-size: 14px; opacity: 0.9; margin-bottom: 16px; }");
            sb.AppendLine(".receipt-header .receipt-badge { display: inline-block; background: rgba(255,255,255,0.2); border-radius: 20px; padding: 6px 20px; font-size: 13px; font-weight: 600; }");
            sb.AppendLine(".receipt-body { padding: 28px 32px; }");
            sb.AppendLine(".section-title { font-size: 13px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.08em; color: #5c6bc0; margin: 20px 0 12px; padding-bottom: 6px; border-bottom: 2px solid #e8eaf6; }");
            sb.AppendLine(".info-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px 24px; }");
            sb.AppendLine(".info-item { display: flex; flex-direction: column; }");
            sb.AppendLine(".info-label { font-size: 11px; font-weight: 600; color: #78909c; text-transform: uppercase; letter-spacing: 0.05em; margin-bottom: 2px; }");
            sb.AppendLine(".info-value { font-size: 14px; font-weight: 500; color: #263238; }");
            sb.AppendLine(".amount-box { background: #f5f7ff; border: 1px solid #e0e4f5; border-radius: 8px; padding: 20px; margin: 20px 0; text-align: center; }");
            sb.AppendLine(".amount-box .label { font-size: 12px; color: #5c6bc0; font-weight: 600; text-transform: uppercase; letter-spacing: 0.05em; }");
            sb.AppendLine(".amount-box .amount { font-size: 36px; font-weight: 800; color: #1a237e; margin: 4px 0; }");
            sb.AppendLine(".amount-box .status { font-size: 13px; font-weight: 600; margin-top: 4px; }");
            sb.AppendLine(".status-paid { color: #2e7d32; }");
            sb.AppendLine(".status-pending { color: #e65100; }");
            sb.AppendLine(".status-overdue { color: #c62828; }");
            sb.AppendLine(".payment-table { width: 100%; border-collapse: collapse; margin-top: 12px; }");
            sb.AppendLine(".payment-table th { background: #f5f7ff; padding: 10px 12px; text-align: left; font-size: 11px; font-weight: 700; text-transform: uppercase; color: #5c6bc0; border-bottom: 2px solid #e8eaf6; }");
            sb.AppendLine(".payment-table td { padding: 10px 12px; font-size: 13px; border-bottom: 1px solid #f0f0f0; color: #37474f; }");
            sb.AppendLine(".summary-row { display: flex; justify-content: space-between; padding: 10px 0; font-size: 14px; }");
            sb.AppendLine(".summary-row.total { border-top: 2px solid #e8eaf6; font-weight: 700; font-size: 16px; color: #1a237e; padding-top: 12px; }");
            sb.AppendLine(".receipt-footer { background: #f8f9fc; padding: 20px 32px; text-align: center; border-top: 1px solid #e8eaf6; }");
            sb.AppendLine(".receipt-footer p { margin: 4px 0; font-size: 12px; color: #78909c; }");
            sb.AppendLine("</style></head><body>");

            sb.AppendLine("<div class=\"receipt-container\">");

            // Header
            sb.AppendLine("<div class=\"receipt-header\">");
            sb.AppendLine("<h1>FEE RECEIPT</h1>");
            sb.AppendLine("<div class=\"school-name\">School Management System</div>");
            sb.AppendLine($"<div class=\"receipt-badge\">Fee Record #{fee.Id}</div>");
            sb.AppendLine("</div>");

            // Body
            sb.AppendLine("<div class=\"receipt-body\">");

            // Student Info
            sb.AppendLine("<div class=\"section-title\">Student Information</div>");
            sb.AppendLine("<div class=\"info-grid\">");
            sb.AppendLine($"<div class=\"info-item\"><span class=\"info-label\">Student Name</span><span class=\"info-value\">{studentName}</span></div>");
            sb.AppendLine($"<div class=\"info-item\"><span class=\"info-label\">Roll Number</span><span class=\"info-value\">{System.Net.WebUtility.HtmlEncode(rollNumber)}</span></div>");
            sb.AppendLine($"<div class=\"info-item\"><span class=\"info-label\">Scholar Number</span><span class=\"info-value\">{System.Net.WebUtility.HtmlEncode(scholarNumber)}</span></div>");
            sb.AppendLine($"<div class=\"info-item\"><span class=\"info-label\">Class / Section</span><span class=\"info-value\">{System.Net.WebUtility.HtmlEncode(className)} / {System.Net.WebUtility.HtmlEncode(sectionName)}</span></div>");
            sb.AppendLine($"<div class=\"info-item\"><span class=\"info-label\">Contact</span><span class=\"info-value\">{System.Net.WebUtility.HtmlEncode(contactNumber)}</span></div>");
            sb.AppendLine($"<div class=\"info-item\"><span class=\"info-label\">Email</span><span class=\"info-value\">{System.Net.WebUtility.HtmlEncode(email)}</span></div>");
            sb.AppendLine("</div>");

            // Fee Details
            sb.AppendLine("<div class=\"section-title\">Fee Details</div>");
            sb.AppendLine("<div class=\"info-grid\">");
            sb.AppendLine($"<div class=\"info-item\"><span class=\"info-label\">Fee Type</span><span class=\"info-value\">{System.Net.WebUtility.HtmlEncode(fee.FeeType)}</span></div>");
            sb.AppendLine($"<div class=\"info-item\"><span class=\"info-label\">Due Date</span><span class=\"info-value\">{fee.DueDate:dd MMM yyyy}</span></div>");
            sb.AppendLine($"<div class=\"info-item\"><span class=\"info-label\">Status</span><span class=\"info-value\">{fee.Status}</span></div>");
            sb.AppendLine("</div>");

            // Amount Box
            var statusClass = fee.Status?.ToLower() switch
            {
                "paid" => "status-paid",
                "overdue" => "status-overdue",
                _ => "status-pending"
            };
            var statusLabel = fee.Status?.ToLower() switch
            {
                "paid" => "PAID IN FULL",
                "overdue" => "OVERDUE",
                _ => "PENDING"
            };
            sb.AppendLine("<div class=\"amount-box\">");
            sb.AppendLine("<div class=\"label\">Total Fee Amount</div>");
            sb.AppendLine($"<div class=\"amount\">{fee.Amount:N2}</div>");
            sb.AppendLine($"<div class=\"status {statusClass}\">{statusLabel}</div>");
            sb.AppendLine("</div>");

            // Payment History
            if (payments.Any())
            {
                sb.AppendLine("<div class=\"section-title\">Payment History</div>");
                sb.AppendLine("<table class=\"payment-table\">");
                sb.AppendLine("<thead><tr><th>Date</th><th>Method</th><th>Receipt #</th><th>Amount</th><th>Status</th></tr></thead>");
                sb.AppendLine("<tbody>");
                foreach (var p in payments.OrderByDescending(p => p.PaymentDate))
                {
                    sb.AppendLine("<tr>");
                    sb.AppendLine($"<td>{p.PaymentDate:dd MMM yyyy}</td>");
                    sb.AppendLine($"<td>{System.Net.WebUtility.HtmlEncode(p.PaymentMethod)}</td>");
                    sb.AppendLine($"<td>{System.Net.WebUtility.HtmlEncode(p.ReceiptNumber)}</td>");
                    sb.AppendLine($"<td>{p.Amount:N2}</td>");
                    sb.AppendLine($"<td>{p.Status}</td>");
                    sb.AppendLine("</tr>");
                }
                sb.AppendLine("</tbody></table>");
            }

            // Summary
            sb.AppendLine("<div class=\"section-title\">Summary</div>");
            sb.AppendLine($"<div class=\"summary-row\"><span>Total Fee</span><span>{fee.Amount:N2}</span></div>");
            sb.AppendLine($"<div class=\"summary-row\"><span>Amount Paid</span><span style=\"color:#2e7d32\">{totalPaid:N2}</span></div>");
            if (remaining > 0)
            {
                sb.AppendLine($"<div class=\"summary-row total\"><span>Remaining Balance</span><span style=\"color:#c62828\">{remaining:N2}</span></div>");
            }
            else
            {
                sb.AppendLine("<div class=\"summary-row total\"><span>Balance</span><span style=\"color:#2e7d32\">0.00</span></div>");
            }

            sb.AppendLine("</div>"); // receipt-body

            // Footer
            sb.AppendLine("<div class=\"receipt-footer\">");
            sb.AppendLine($"<p>Generated on {DateTime.Now:dd MMM yyyy 'at' hh:mm tt}</p>");
            sb.AppendLine("<p>This is a system-generated receipt. For queries, please contact the accounts department.</p>");
            sb.AppendLine("</div>");

            sb.AppendLine("</div>"); // receipt-container
            sb.AppendLine("</body></html>");

            return sb.ToString();
        }

        // ==================== FEE WAIVER ENDPOINTS ====================

        [HttpGet("waivers")]
        [RequirePermission(Permission.FeesView, requireRead: true)]
        public async Task<ActionResult<ApiResponse<List<StudentFeeAdjustmentDto>>>> GetWaivers(
            [FromQuery] int? studentId = null,
            [FromQuery] int? academicYearId = null,
            [FromQuery] string status = "all")
        {
            try
            {
                var waivers = await _adjustmentRepository.GetWaiversAsync();
                
                if (studentId.HasValue)
                    waivers = waivers.Where(w => w.StudentId == studentId.Value);
                
                if (academicYearId.HasValue)
                    waivers = waivers.Where(w => w.AcademicYearId == academicYearId.Value);

                if (status != "all")
                {
                    if (Enum.TryParse<FeeAdjustmentStatus>(status, ignoreCase: true, out var statusEnum))
                        waivers = waivers.Where(w => w.Status == statusEnum);
                }

                var dtos = waivers.Select(w => MapToDto(w)).ToList();
                return SuccessResponse(dtos, "Waivers retrieved successfully");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving waivers");
                return ErrorResponse<List<StudentFeeAdjustmentDto>>("Error retrieving waivers");
            }
        }

        [HttpPost("waivers")]
        [RequirePermission(Permission.FeesCollect, requireWrite: true)]
        public async Task<ActionResult<ApiResponse<StudentFeeAdjustmentDto>>> CreateWaiver(
            [FromBody] CreateWaiverRequest request)
        {
            try
            {
                var waiver = new StudentFeeAdjustment
                {
                    TenantId = _tenantProvider.TenantId,
                    StudentId = request.StudentId,
                    AcademicYearId = request.AcademicYearId,
                    AdjustmentType = FeeAdjustmentType.Waiver,
                    IsFullWaiver = true,
                    WaiverCategory = request.WaiverCategory,
                    EffectiveDate = request.EffectiveDate,
                    ExpiryDate = request.ExpiryDate,
                    Status = FeeAdjustmentStatus.PendingApproval,
                    CreatedBy = User.FindFirst("Id")?.Value ?? "0",
                    CreatedOn = DateTime.UtcNow,
                    ApprovedBy = !string.IsNullOrEmpty(request.ApprovedBy) ? request.ApprovedBy : null,
                    ApprovedDate = !string.IsNullOrEmpty(request.ApprovedBy) ? (DateTime?)DateTime.UtcNow : null,
                    Remarks = request.Remarks,
                    SpecificInstallmentId = request.SpecificInstallmentId > 0 ? (int?)request.SpecificInstallmentId : null
                };

                var createdWaiver = await _adjustmentRepository.AddAsync(waiver);
                _logger.LogInformation("Waiver created for student {StudentId}", request.StudentId);
                return SuccessResponse(MapToDto(createdWaiver), "Waiver created successfully");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating waiver");
                return ErrorResponse<StudentFeeAdjustmentDto>("Error creating waiver");
            }
        }

        [HttpPut("waivers/{id}")]
        [RequirePermission(Permission.FeesCollect, requireWrite: true)]
        public async Task<ActionResult<ApiResponse>> UpdateWaiver(int id, [FromBody] StudentFeeAdjustmentDto dto)
        {
            try
            {
                var waiver = await _adjustmentRepository.GetByIdAsync(id);
                if (waiver == null)
                    return NotFoundResponse("Waiver not found");

                waiver.Status = dto.Status;
                waiver.ApprovedBy = User.FindFirst("Id")?.Value ?? "0";
                waiver.ApprovedDate = DateTime.UtcNow;
                waiver.Remarks = dto.Remarks;

                await _adjustmentRepository.UpdateAsync(waiver);
                return SuccessResponse("Waiver updated successfully");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error updating waiver");
                return ErrorResponse("Error updating waiver");
            }
        }

        [HttpDelete("waivers/{id}")]
        [RequirePermission(Permission.FeesCollect, requireDelete: true)]
        public async Task<ActionResult<ApiResponse>> DeleteWaiver(int id)
        {
            try
            {
                await _adjustmentRepository.DeleteAsync(id);
                return SuccessResponse("Waiver deleted successfully");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error deleting waiver");
                return ErrorResponse("Error deleting waiver");
            }
        }

        // ==================== STUDENT DISCOUNT ENDPOINTS ====================

        [HttpGet("discounts")]
        [RequirePermission(Permission.FeesView, requireRead: true)]
        public async Task<ActionResult<ApiResponse<List<StudentFeeAdjustmentDto>>>> GetDiscounts(
            [FromQuery] int? studentId = null,
            [FromQuery] int? academicYearId = null,
            [FromQuery] string status = "all")
        {
            try
            {
                var discounts = await _adjustmentRepository.GetDiscountsAsync();

                if (studentId.HasValue)
                    discounts = discounts.Where(d => d.StudentId == studentId.Value);

                if (academicYearId.HasValue)
                    discounts = discounts.Where(d => d.AcademicYearId == academicYearId.Value);

                if (status != "all")
                {
                    if (Enum.TryParse<FeeAdjustmentStatus>(status, ignoreCase: true, out var statusEnum))
                        discounts = discounts.Where(d => d.Status == statusEnum);
                }

                var dtos = discounts.Select(d => MapToDto(d)).ToList();
                return SuccessResponse(dtos, "Discounts retrieved successfully");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving discounts");
                return ErrorResponse<List<StudentFeeAdjustmentDto>>("Error retrieving discounts");
            }
        }

        [HttpPost("discounts")]
        [RequirePermission(Permission.FeesCollect, requireWrite: true)]
        public async Task<ActionResult<ApiResponse<StudentFeeAdjustmentDto>>> CreateDiscount(
            [FromBody] CreateDiscountRequest request)
        {
            try
            {
                var discount = new StudentFeeAdjustment
                {
                    TenantId = _tenantProvider.TenantId,
                    StudentId = request.StudentId,
                    AcademicYearId = request.AcademicYearId,
                    AdjustmentType = FeeAdjustmentType.Discount,
                    IsPercentage = request.IsPercentage,
                    DiscountPercentage = request.IsPercentage ? request.DiscountValue : null,
                    DiscountAmount = !request.IsPercentage ? request.DiscountValue : null,
                    MaximumCap = request.MaximumCap,
                    EffectiveDate = request.EffectiveDate,
                    ExpiryDate = request.ExpiryDate,
                    Status = FeeAdjustmentStatus.Active,
                    CreatedBy = request.CreatedBy,
                    CreatedOn = DateTime.UtcNow,
                    Remarks = request.Remarks,
                    SpecificInstallmentId = request.SpecificInstallmentId > 0 ? request.SpecificInstallmentId : null
                };

                var createdDiscount = await _adjustmentRepository.AddAsync(discount);
                _logger.LogInformation("Discount created for student {StudentId}", request.StudentId);
                return SuccessResponse(MapToDto(createdDiscount), "Discount created successfully");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating discount");
                return ErrorResponse<StudentFeeAdjustmentDto>("Error creating discount");
            }
        }

        [HttpPut("discounts/{id}")]
        [RequirePermission(Permission.FeesCollect, requireWrite: true)]
        public async Task<ActionResult<ApiResponse<StudentFeeAdjustmentDto>>> UpdateDiscount(
            int id,
            [FromBody] CreateDiscountRequest request)
        {
            try
            {
                var discount = await _adjustmentRepository.GetByIdAsync(id);
                if (discount == null)
                    return NotFoundResponse<StudentFeeAdjustmentDto>("Discount not found");

                discount.AcademicYearId = request.AcademicYearId;
                discount.IsPercentage = request.IsPercentage;
                discount.DiscountPercentage = request.IsPercentage ? request.DiscountValue : null;
                discount.DiscountAmount = !request.IsPercentage ? request.DiscountValue : null;
                discount.MaximumCap = request.MaximumCap;
                discount.EffectiveDate = request.EffectiveDate;
                discount.ExpiryDate = request.ExpiryDate;
                discount.Remarks = request.Remarks;

                await _adjustmentRepository.UpdateAsync(discount);
                return SuccessResponse(MapToDto(discount), "Discount updated successfully");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error updating discount");
                return ErrorResponse<StudentFeeAdjustmentDto>("Error updating discount");
            }
        }

        [HttpDelete("discounts/{id}")]
        [RequirePermission(Permission.FeesCollect, requireDelete: true)]
        public async Task<ActionResult<ApiResponse>> DeleteDiscount(int id)
        {
            try
            {
                await _adjustmentRepository.DeleteAsync(id);
                return SuccessResponse("Discount deleted successfully");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error deleting discount");
                return ErrorResponse("Error deleting discount");
            }
        }

        // ==================== FAMILY PAYMENT ENDPOINTS ====================

        [HttpGet("families/{familyId}/members-fees")]
        [RequirePermission(Permission.FeesView, requireRead: true)]
        public async Task<ActionResult<ApiResponse<FamilyPaymentSummaryDto>>> GetFamilyMembersFees(int familyId)
        {
            try
            {
                _logger.LogInformation("GetFamilyMembersFees called with familyId: {FamilyId}", familyId);
                var summary = await _groupPaymentRepository.GetFamilyPaymentSummaryAsync(familyId, 0);
                _logger.LogInformation("GetFamilyMembersFees returning summary for familyGroupId: {FamilyGroupId}", summary?.FamilyGroupId);
                return SuccessResponse(summary, "Family member fees retrieved successfully");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving family member fees");
                return ErrorResponse<FamilyPaymentSummaryDto>("Error retrieving family member fees");
            }
        }

        [HttpPost("family-payments/process")]
        [RequirePermission(Permission.FeesCollect, requireWrite: true)]
        public async Task<ActionResult<ApiResponse<GroupPaymentProcessResult>>> ProcessFamilyPayment(
            [FromBody] ProcessGroupPaymentRequest request)
        {
            try
            {
                var groupPayment = new GroupPayment { Id = request.GroupPaymentId, TenantId = _tenantProvider.TenantId, FamilyGroupId = request.FamilyGroupId, TotalAmountPaid = request.TotalAmountPaid, Status = GroupPaymentStatus.Completed };
                await _groupPaymentRepository.UpdateAsync(groupPayment);
                var result = new GroupPaymentProcessResult { Success = true, GroupPaymentId = groupPayment.Id, TotalApplied = request.TotalAmountPaid, Message = "Payment processed successfully" };
                
                if (!result.Success)
                    return BadRequest(new ApiResponse { Message = result.Message, Success = false });

                _logger.LogInformation("Family payment processed. GroupPaymentId: {GroupPaymentId}", result.GroupPaymentId);
                return SuccessResponse(result, "Family payment processed successfully");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error processing family payment");
                return ErrorResponse<GroupPaymentProcessResult>("Error processing family payment");
            }
        }

        // ==================== HELPER METHODS ====================

        private StudentFeeAdjustmentDto MapToDto(StudentFeeAdjustment adjustment)
        {
            return new StudentFeeAdjustmentDto
            {
                Id = adjustment.Id,
                StudentId = adjustment.StudentId,
                // Resolve the student name from the included navigation (repository loads Student)
                StudentName = adjustment.Student != null ? $"{adjustment.Student.FirstName} {adjustment.Student.LastName}".Trim() : string.Empty,
                AdjustmentType = adjustment.AdjustmentType,
                IsPercentage = adjustment.IsPercentage,
                DiscountPercentage = adjustment.DiscountPercentage,
                DiscountAmount = adjustment.DiscountAmount,
                MaximumCap = adjustment.MaximumCap,
                IsFullWaiver = adjustment.IsFullWaiver,
                WaiverCategory = adjustment.WaiverCategory,
                EffectiveDate = adjustment.EffectiveDate,
                ExpiryDate = adjustment.ExpiryDate,
                Status = adjustment.Status,
                Remarks = adjustment.Remarks
            };
        }
    }
}
