using SchoolManagementApp.ApplicationCore.Communication.Interfaces;
using SchoolManagementApp.ApplicationCore.Entities;

namespace SchoolManagementApp.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class NotificationController : BaseApiController
    {
        private readonly INotificationService _notificationService;

        public NotificationController(INotificationService notificationService, ILogger<NotificationController> logger)
            : base(logger)
        {
            _notificationService = notificationService;
        }

        [HttpGet]
        public async Task<IActionResult> Get()
        {
            try
            {
                LogAction("Getting notifications");
                var userId = GetCurrentUserIdInt();
                var notifications = await _notificationService.GetNotificationsByUserIdAsync(userId);
                return SuccessResult(notifications, $"Retrieved {notifications.Count()} notifications");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error retrieving notifications");
                return ErrorResult("Failed to retrieve notifications");
            }
        }

        [HttpPost]
        [Authorize(Roles = "Admin,Staff")]
        public async Task<IActionResult> Create([FromBody] Notification notification)
        {
            try
            {
                LogAction($"Creating notification for user: {notification.UserId}");
                var created = await _notificationService.CreateNotificationAsync(notification);
                return SuccessResult(created, "Notification created successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error creating notification");
                return ErrorResult("Failed to create notification");
            }
        }

        [HttpPost("mark-read/{id}")]
        public async Task<IActionResult> MarkRead(int id)
        {
            try
            {
                LogAction($"Marking notification {id} as read");
                var userId = GetCurrentUserIdInt();
                var notification = await _notificationService.MarkAsReadAsync(id, userId);
                if (notification == null)
                    return NotFoundResult($"Notification with ID {id} not found");
                return SuccessResult(notification, "Notification marked as read");
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error marking notification {id} as read");
                return ErrorResult("Failed to mark notification as read");
            }
        }

        [HttpPost("mark-all-read")]
        public async Task<IActionResult> MarkAllRead()
        {
            try
            {
                LogAction("Marking all notifications as read");
                var userId = GetCurrentUserIdInt();
                var count = await _notificationService.MarkAllAsReadAsync(userId);
                return SuccessResult(new { markedCount = count }, $"Marked {count} notifications as read");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error marking all notifications as read");
                return ErrorResult("Failed to mark notifications as read");
            }
        }

        [HttpGet("unread-count")]
        public async Task<IActionResult> GetUnreadCount()
        {
            try
            {
                var userId = GetCurrentUserIdInt();
                var count = await _notificationService.GetUnreadCountAsync(userId);
                return SuccessResult(new { count }, "Unread count retrieved");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error getting unread count");
                return ErrorResult("Failed to get unread count");
            }
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                LogAction($"Deleting notification {id}");
                var userId = GetCurrentUserIdInt();
                await _notificationService.DeleteNotificationAsync(id, userId);
                return SuccessResult("Notification deleted successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error deleting notification {id}");
                return ErrorResult("Failed to delete notification");
            }
        }
    }
}
