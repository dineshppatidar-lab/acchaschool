using Microsoft.AspNetCore.RateLimiting;
using SchoolManagementApp.ApplicationCore.Authentication.Dtos;
using SchoolManagementApp.ApplicationCore.Common;
using SchoolManagementApp.ApplicationCore.Services.Interfaces;

namespace SchoolManagementApp.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuthController : BaseApiController
    {
        private readonly IAuthService _authService;
        private readonly IConfiguration _config;
        private readonly ITenantProvider _tenantProvider;
        private readonly ILoginAttemptTracker _loginTracker;
        private readonly ITenantService _tenantService;

        public AuthController(
            IAuthService authService,
            IConfiguration config,
            ILogger<AuthController> logger,
            ITenantProvider tenantProvider,
            ILoginAttemptTracker loginTracker,
            ITenantService tenantService)
            : base(logger)
        {
            _authService = authService;
            _config = config;
            _tenantProvider = tenantProvider;
            _loginTracker = loginTracker;
            _tenantService = tenantService;
        }

        [HttpPost("login-debug")]
        public IActionResult LoginDebug([FromBody] AppLoginRequest req)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    var errors = ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage).ToList();
                    LogAction($"[LoginDebug] ModelState invalid: {string.Join(", ", errors)}");
                    return BadRequest(new { message = "Validation failed", errors = errors, modelState = ModelState });
                }

                LogAction("[LoginDebug] ModelState valid");
                var passwordDisplay = (req?.Password?.Length ?? 0) > 0 ? "***" : "empty";
                LogAction($"[LoginDebug] Request: Username={req?.Username}, Password={passwordDisplay}");

                return Ok(new { message = "Debug OK", received = req });
            }
            catch (Exception ex)
            {
                LogError(ex, "LoginDebug error");
                return StatusCode(500, new { message = $"Error: {ex.Message}" });
            }
        }

        [HttpPost("login")]
        [EnableRateLimiting("Auth")]
        public async Task<IActionResult> Login([FromBody] AppLoginRequest req)
        {
            // NOTE: this endpoint is anonymous — auth.User is unauthenticated here,
            // so tenant resolution for the LOCKOUT KEY comes from the client-supplied
            // tenant code only (never from X-Tenant-ID, which unauthenticated callers
            // could freely spoof to rotate lockout keys).
            var clientIp = HttpContext.Connection.RemoteIpAddress?.ToString();
            try
            {
                var requestBody = req != null ? System.Text.Json.JsonSerializer.Serialize(req) : "null";
                LogAction($"[Login] Request received. Body: {requestBody}");

                if (req == null)
                {
                    LogAction("Login failed - request body is null");
                    return BadRequest(new { message = "Request body cannot be empty" });
                }

                if (string.IsNullOrWhiteSpace(req.Username))
                {
                    LogAction("Login failed - username is empty");
                    return BadRequest(new { message = "Username is required" });
                }

                if (string.IsNullOrWhiteSpace(req.Password))
                {
                    LogAction("Login failed - password is empty");
                    return BadRequest(new { message = "Password is required" });
                }

                string? tenantCode = req.TenantCode?.Trim();

                // ── Failed-attempt lockout: per-user (5/1min) + per-IP (30/5min) ──
                if (_loginTracker.IsLockedOut(tenantCode ?? "", req.Username, clientIp))
                {
                    var retryAfter = _loginTracker.GetRemainingLockoutSeconds(tenantCode ?? "", req.Username, clientIp);
                    LogAction($"Login blocked - account temporarily locked for user: {req.Username} ({retryAfter}s remaining)");
                    AuditSecurityEvent("Login.Lockout", $"Login blocked for user '{req.Username}' (tenant code '{tenantCode ?? "default"}') — {retryAfter}s lockout remaining.", req.Username, clientIp);
                    Response.Headers.RetryAfter = retryAfter.ToString();
                    return StatusCode(StatusCodes.Status429TooManyRequests, new
                    {
                        message = $"Too many failed attempts. Try again in {Math.Max(1, retryAfter)} second{(retryAfter == 1 ? "" : "s")}.",
                        retryAfterSeconds = retryAfter
                    });
                }

                // Domain binding: when no school code is given, the host the browser is
                // on (e.g. greenfield.acchaschool.com) resolves the tenant via Tenant.Domain.
                var requestDomain = req.TenantCode == null || req.TenantCode.Trim().Length == 0
                    ? HttpContext.Request.Host.Value
                    : null;
                var (user, token, tenantId, permissions) = await _authService.LoginAsync(req.Username, req.Password, tenantCode, requestDomain);

                if (user == null || token == null)
                {
                    LogAction($"Login failed for user: {req.Username}");
                    AuditSecurityEvent("Login.Failure", $"Failed login attempt for user '{req.Username}' (tenant code '{tenantCode ?? "default"}').", req.Username, clientIp);

                    var justLocked = _loginTracker.RecordFailure(tenantCode ?? "", req.Username, clientIp);
                    var remainingLockout = _loginTracker.GetRemainingLockoutSeconds(tenantCode ?? "", req.Username, clientIp);

                    // Attempts left before lockout (0 once locked)
                    int attemptsLeft = remainingLockout > 0
                        ? 0
                        : Math.Max(0, LoginAttemptTracker.MaxAttempts - GetFailureCount(tenantCode ?? "", req.Username));

                    Response.Headers.RetryAfter = remainingLockout.ToString();
                    string message;
                    if (justLocked)
                    {
                        message = $"Too many failed attempts. Account locked for {Math.Max(1, remainingLockout)} seconds.";
                    }
                    else if (remainingLockout > 0)
                    {
                        message = $"Too many failed attempts. Try again in {Math.Max(1, remainingLockout)} seconds.";
                    }
                    else
                    {
                        message = "Invalid username or password"
                            + (attemptsLeft > 0
                                ? $". {attemptsLeft} attempt{(attemptsLeft == 1 ? "" : "s")} remaining."
                                : ".");
                    }

                    return Unauthorized(new { message, attemptsLeft, justLocked });
                }

                _loginTracker.RecordSuccess(tenantCode ?? "", req.Username);

                // Issue a rotating refresh token alongside the short-lived access token.
                var refreshToken = await _authService.IssueRefreshTokenAsync(user, clientIp);

                var loginData = new
                {
                    token,
                    refreshToken,
                    user = new
                    {
                        user.Id,
                        user.Username,
                        user.Roles,
                        user.Email,
                        tenantId = user.TenantId,
                        permissions
                    }
                };

                LogAction($"Login successful for user: {req.Username} in tenant: {tenantId} with {permissions.Count} permissions");
                AuditSecurityEvent("Login.Success", $"User '{req.Username}' logged in to tenant {tenantId} with {permissions.Count} permissions.", req.Username, clientIp, tenantId);
                return Ok(loginData);
            }
            catch (Exception ex)
            {
                LogError(ex, "Login error");
                return StatusCode(500, new { message = "An error occurred during login" });
            }
        }

        private int GetFailureCount(string tenantCode, string username)
            => _loginTracker.GetFailureCount(tenantCode, username);

        /// <summary>
        /// Exchanges a valid refresh token for a new access + refresh token pair
        /// (rotation). Replay of an already-rotated token revokes the whole session
        /// family — see docs/critical-issues/05-jwt-lifecycle.md.
        /// </summary>
        [HttpPost("refresh")]
        [AllowAnonymous]
        [EnableRateLimiting("Auth")]
        public async Task<IActionResult> Refresh([FromBody] RefreshRequest req)
        {
            if (string.IsNullOrWhiteSpace(req?.RefreshToken))
                return BadRequest(new { message = "Refresh token is required" });

            var clientIp = HttpContext.Connection.RemoteIpAddress?.ToString();
            var result = await _authService.RefreshAsync(req.RefreshToken, clientIp);

            if (!result.Success)
            {
                LogAction($"Refresh rejected: {result.Error}");
                return Unauthorized(new { message = result.Error });
            }

            return Ok(new { token = result.AccessToken, refreshToken = result.RefreshToken });
        }

        /// <summary>Revokes the supplied refresh token (client-side logout).</summary>
        [HttpPost("logout")]
        [AllowAnonymous]
        public async Task<IActionResult> Logout([FromBody] RefreshRequest req)
        {
            if (!string.IsNullOrWhiteSpace(req?.RefreshToken))
                await _authService.LogoutAsync(req.RefreshToken);

            return Ok(new { message = "Logged out." });
        }

        /// <summary>
        /// Domain binding (public): resolves the tenant whose Tenant.Domain matches the
        /// host the browser is on. Lets a school's own URL render its own branding on the
        /// login screen (name, logo, welcome text, school code pre-fill) and lets the
        /// frontend distinguish "school subdomain with no binding" (school-not-found)
        /// from the platform/main domain. No default-tenant fallback: nothing is matched
        /// unless the host is explicitly bound. The bound tenant is reported even when
        /// inactive so the frontend can show a suspended-school state.
        /// </summary>
        [HttpGet("resolve-domain")]
        [AllowAnonymous]
        public async Task<IActionResult> ResolveDomain([FromQuery] string? host = null)
        {
            // Anonymous callers are restricted to the host the request actually came from.
            // Authenticated SuperAdmins may probe any host — used by the tenant admin screen's "Test binding".
            string? probeHost = null;
            if (!string.IsNullOrWhiteSpace(host))
            {
                var isSuperAdmin = User.Identities.Any(i => i.IsAuthenticated) &&
                    GetCurrentUserRoles().Contains("SuperAdmin", StringComparer.OrdinalIgnoreCase);
                if (!isSuperAdmin)
                {
                    return Forbid();
                }
                probeHost = host;
            }

            try
            {
                var effectiveHost = probeHost ?? HttpContext.Request.Host.Value;
                var tenant = await _tenantService.GetTenantByDomainAsync(effectiveHost);
                if (tenant == null)
                {
                    return Ok(new
                    {
                        matched = false,
                        active = false,
                        tenantCode = (string?)null,
                        tenantName = (string?)null,
                        logoUrl = (string?)null,
                        welcomeText = (string?)null,
                        baseDomain = GetBaseDomain()
                    });
                }

                return Ok(new
                {
                    matched = true,
                    active = tenant.IsActive,
                    tenantCode = tenant.TenantCode,
                    tenantName = tenant.Name,
                    logoUrl = tenant.LogoUrl,
                    welcomeText = ExtractWelcomeText(tenant.SettingsJson),
                    baseDomain = GetBaseDomain()
                });
            }
            catch (Exception ex)
            {
                LogError(ex, "Resolve domain error");
                return Ok(new
                {
                    matched = false,
                    active = false,
                    tenantCode = (string?)null,
                    tenantName = (string?)null,
                    logoUrl = (string?)null,
                    welcomeText = (string?)null,
                    baseDomain = GetBaseDomain()
                });
            }
        }

        /// <summary>Platform root domain for unknown-subdomain detection ("" when unconfigured).</summary>
        private string GetBaseDomain()
        {
            try
            {
                return _config.GetSection("MultiTenancy")["BaseDomain"]
                    ?? _config["MultiTenancy:BaseDomain"] ?? string.Empty;
            }
            catch
            {
                return string.Empty;
            }
        }

        /// <summary>Welcome text is stored inside SettingsJson ("welcomeText" key); safe parse.</summary>
        private static string? ExtractWelcomeText(string? settingsJson)
        {
            if (string.IsNullOrWhiteSpace(settingsJson)) return null;
            try
            {
                var node = System.Text.Json.Nodes.JsonNode.Parse(settingsJson);
                var value = node?["welcomeText"]?.GetValue<string>();
                return string.IsNullOrWhiteSpace(value) ? null : value;
            }
            catch
            {
                return null;
            }
        }

        public class RefreshRequest
        {
            public string? RefreshToken { get; set; }
        }

        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] RegisterUserDto req)
        {
            try
            {
                LogAction($"User registration attempt for: {req.Username}");

                if (string.IsNullOrWhiteSpace(req.Username) || string.IsNullOrWhiteSpace(req.Email) ||
                    string.IsNullOrWhiteSpace(req.Password) || string.IsNullOrWhiteSpace(req.FirstName) ||
                    string.IsNullOrWhiteSpace(req.LastName))
                {
                    return BadRequest(new RegisterResponseDto
                    {
                        Success = false,
                        Message = "All required fields must be provided"
                    });
                }

                if (req.Password != req.ConfirmPassword)
                {
                    return BadRequest(new RegisterResponseDto
                    {
                        Success = false,
                        Message = "Password and confirm password do not match"
                    });
                }

                if (await _authService.UserExistsAsync(req.Username, req.Email))
                {
                    return BadRequest(new RegisterResponseDto
                    {
                        Success = false,
                        Message = "Username or email already exists"
                    });
                }

                if (!req.AcceptedTerms)
                {
                    return BadRequest(new RegisterResponseDto
                    {
                        Success = false,
                        Message = "Terms and conditions must be accepted"
                    });
                }

                int tenantId = _tenantProvider?.TenantId > 0 ? _tenantProvider.TenantId : 1;

                var user = await _authService.RegisterUserAsync(req, tenantId);

                LogAction($"User registered successfully: {req.Username} in tenant: {tenantId}");

                return Ok(new RegisterResponseDto
                {
                    Success = true,
                    Message = "Registration successful! You can now login with your credentials.",
                    UserId = user.Id,
                    Username = user.Username,
                    Email = user.Email ?? string.Empty
                });
            }
            catch (Exception ex)
            {
                LogError(ex, "User registration error");
                return StatusCode(500, new RegisterResponseDto
                {
                    Success = false,
                    Message = "An error occurred during registration. Please try again."
                });
            }
        }

        [HttpPost("register-admin")]
        public async Task<IActionResult> RegisterAdmin([FromBody] AdminRegisterRequest req)
        {
            try
            {
                LogAction($"Admin registration attempt for: {req.Username}");

                int tenantId = _tenantProvider?.TenantId > 0 ? _tenantProvider.TenantId : 1;

                await _authService.RegisterAdminAsync(req.Username, req.Password, req.Email, tenantId);

                LogAction($"Admin registered successfully: {req.Username} in tenant: {tenantId}");
                return SuccessResult("Admin registered successfully.");
            }
            catch (Exception ex)
            {
                LogError(ex, "Admin registration error");
                return ErrorResult("An error occurred during registration");
            }
        }

        [HttpPost("forgot-password")]
        [AllowAnonymous]
        [EnableRateLimiting("Auth")]
        public async Task<IActionResult> ForgotPassword([FromBody] ForgotPasswordRequest req)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(req.SchoolCode) || string.IsNullOrWhiteSpace(req.Email))
                {
                    return BadRequest(new { success = false, message = "School code and email are required" });
                }

                await _authService.ForgotPasswordAsync(req.SchoolCode, req.Email);

                return Ok(new { success = true, message = "If an account with that email exists, a reset link has been sent." });
            }
            catch (Exception ex)
            {
                LogError(ex, "Forgot password error");
                return StatusCode(500, new { success = false, message = "An error occurred. Please try again." });
            }
        }

        [HttpPost("reset-password")]
        [AllowAnonymous]
        [EnableRateLimiting("Auth")]
        public async Task<IActionResult> ResetPassword([FromBody] ResetPasswordRequest req)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(req.Token) || string.IsNullOrWhiteSpace(req.NewPassword))
                {
                    return BadRequest(new { success = false, message = "Token and new password are required" });
                }

                await _authService.ResetPasswordAsync(req.Token, req.NewPassword, req.ConfirmPassword);

                return Ok(new { success = true, message = "Password reset successful. You can now sign in with your new password." });
            }
            catch (InvalidOperationException ex)
            {
                return BadRequest(new { success = false, message = ex.Message });
            }
            catch (Exception ex)
            {
                LogError(ex, "Reset password error");
                return StatusCode(500, new { success = false, message = "An error occurred. Please try again." });
            }
        }
    }

    // DTOs kept in controller for backward compatibility with existing frontend
    public class AppLoginRequest
    {
        public string Username { get; set; } = string.Empty;
        public string Password { get; set; } = string.Empty;
        public string? TenantCode { get; set; }
    }

    public class AdminRegisterRequest
    {
        public string Username { get; set; } = string.Empty;
        public string Password { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
    }
}
