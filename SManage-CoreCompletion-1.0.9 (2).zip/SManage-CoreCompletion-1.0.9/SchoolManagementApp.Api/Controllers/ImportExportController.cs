using Microsoft.AspNetCore.Mvc;
using SchoolManagementApp.Api.Services;

namespace SchoolManagementApp.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class ImportExportController : ControllerBase
    {
        private readonly ApplicationDbContext _context;
        private readonly StudentImportService _studentImportService;

        public ImportExportController(
            ApplicationDbContext context,
            StudentImportService studentImportService)
        {
            _context = context;
            _studentImportService = studentImportService;
        }

        /// <summary>
        /// Downloads the Excel template for bulk student admission import.
        /// Contains an Instructions sheet, a 'Lookups' sheet with the academic years /
        /// classes / sections (IDs + names) currently configured for THIS school
        /// (current session flagged), and a 'Students' sheet with the required columns,
        /// example rows pre-filled with the current session, and dropdown validations.
        /// </summary>
        [HttpGet("students/admission-template")]
        [RequirePermission(Permission.StudentsCreate, requireRead: true)]
        public async Task<IActionResult> DownloadAdmissionTemplate()
        {
            var bytes = await _studentImportService.GenerateTemplateAsync(_context.CurrentTenantId);
            const string fileName = "Student_Admission_Template.xlsx";
            return File(
                bytes,
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                fileName);
        }

        /// <summary>
        /// Imports students from an uploaded Excel admission template.
        /// Validates every row and returns per-row errors; valid rows are saved.
        /// </summary>
        [HttpPost("students/import")]
        [EnableRateLimiting("Export")]
        [RequirePermission(Permission.StudentsCreate, requireWrite: true)]
        [RequestSizeLimit(10 * 1024 * 1024)] // 10 MB
        public async Task<IActionResult> ImportStudents(IFormFile file)
        {
            if (file == null || file.Length == 0)
                return BadRequest(new { message = "No file uploaded" });

            var ext = Path.GetExtension(file.FileName).ToLowerInvariant();
            if (ext != ".xlsx")
                return BadRequest(new { message = "Please upload the .xlsx template file downloaded from this screen. CSV is not supported for admission import." });

            try
            {
                await using var stream = file.OpenReadStream();
                var result = await _studentImportService.ImportAsync(
                    stream,
                    _context.CurrentTenantId,
                    User?.Identity?.Name ?? "system");

                return Ok(new
                {
                    success = true,
                    importedCount = result.SuccessCount,
                    imported = result.ImportedNames,
                    failedCount = result.FailedRows.Count,
                    failedRows = result.FailedRows,
                    errors = result.GlobalErrors
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Error importing students: " + ex.Message });
            }
        }

        /// <summary>
        /// Exports all students of the current tenant as an Excel (.xlsx) workbook.
        /// Headers mirror the admission template EXACTLY (StudentImportService.TemplateColumns)
        /// so the exported file can be edited and re-imported without 'Missing required column' errors.
        /// </summary>
        [HttpGet("students/export")]
        [EnableRateLimiting("Export")]
        [RequirePermission(Permission.StudentsCreate, requireRead: true)]
        public IActionResult ExportStudents()
        {
            var students = _context.Students
                .Include(s => s.Class)
                .Include(s => s.Section)
                .Include(s => s.Parent)
                .ToList();

            var yearNames = _context.AcademicYears.ToDictionary(y => y.Id, y => y.Name);

            using var workbook = new ClosedXML.Excel.XLWorkbook();
            var ws = workbook.Worksheets.Add("Students");

            // Exactly the template's header row — import maps by normalized header name,
            // so keeping the hints/marks identical guarantees round-tripping.
            for (var i = 0; i < StudentImportService.TemplateColumns.Length; i++)
            {
                var h = ws.Cell(1, i + 1);
                h.Value = StudentImportService.TemplateColumns[i];
                h.Style.Font.SetBold();
            }

            var rowIdx = 2;
            foreach (var s in students)
            {
                ws.Cell(rowIdx, 1).Value = s.ScholarNumber;   // Admission Number*
                ws.Cell(rowIdx, 2).Value = s.RollNumber;      // Roll Number*
                ws.Cell(rowIdx, 3).Value = s.FirstName;       // First Name*
                ws.Cell(rowIdx, 4).Value = s.LastName;        // Last Name*
                ws.Cell(rowIdx, 5).Value = s.DateOfBirth.ToString("yyyy-MM-dd");
                ws.Cell(rowIdx, 6).Value = s.Gender;
                ws.Cell(rowIdx, 7).Value = s.Class?.Name ?? string.Empty;
                ws.Cell(rowIdx, 8).Value = s.Section?.Name ?? string.Empty;
                ws.Cell(rowIdx, 9).Value = s.AcademicYearId != null && yearNames.TryGetValue(s.AcademicYearId.Value, out var yn) ? yn : string.Empty;
                ws.Cell(rowIdx, 10).Value = s.ContactNumber;
                ws.Cell(rowIdx, 11).Value = s.Email;
                ws.Cell(rowIdx, 12).Value = s.Address;
                ws.Cell(rowIdx, 13).Value = s.AdmissionDate == default ? string.Empty : s.AdmissionDate.ToString("yyyy-MM-dd");
                ws.Cell(rowIdx, 14).Value = s.Parent?.FirstName ?? string.Empty;
                ws.Cell(rowIdx, 15).Value = s.Parent?.LastName ?? string.Empty;
                ws.Cell(rowIdx, 16).Value = s.Parent?.PhoneNumber ?? string.Empty;
                ws.Cell(rowIdx, 17).Value = s.Parent?.Email ?? string.Empty;
                ws.Cell(rowIdx, 18).Value = s.Parent?.Occupation ?? string.Empty;
                ws.Cell(rowIdx, 19).Value = s.CasteCategory ?? string.Empty;
                ws.Cell(rowIdx, 20).Value = s.Religion ?? string.Empty;
                rowIdx++;
            }

            ws.Columns().AdjustToContents();

            using var stream = new MemoryStream();
            workbook.SaveAs(stream);

            const string contentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
            return File(stream.ToArray(), contentType, $"students_{DateTime.UtcNow:yyyyMMdd}.xlsx");
        }
    }
}
