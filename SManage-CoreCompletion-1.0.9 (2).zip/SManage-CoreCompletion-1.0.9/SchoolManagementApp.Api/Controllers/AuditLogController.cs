using Microsoft.AspNetCore.Mvc;
using SchoolManagementApp.ApplicationCore.Audit;

namespace SchoolManagementApp.Api.Controllers
{
    /// <summary>
    /// Read side of the security audit trail. Thin HTTP mapper over
    /// IAuditLogQueryService (docs/critical-issues/09 risk priority #3) —
    /// no DbContext, no query composition; the service owns tenant scoping,
    /// filtering, and paging. The response shape is unchanged.
    /// </summary>
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class AuditLogController : ControllerBase
    {
        private readonly IAuditLogQueryService _auditLogQueryService;

        public AuditLogController(IAuditLogQueryService auditLogQueryService)
        {
            _auditLogQueryService = auditLogQueryService;
        }

        /// <summary>
        /// Paged, filterable audit log – newest records first.
        /// GET api/auditlog?page=1&amp;pageSize=20&amp;search=x&amp;action=x&amp;entity=x&amp;user=x&amp;from=2026-01-01&amp;to=2026-01-31
        /// </summary>
        [HttpGet]
        [RequirePermission(Permission.SystemAuditLogs, requireRead: true)]
        public async Task<IActionResult> GetAll(
            [FromQuery] int page = 1,
            [FromQuery] int pageSize = 20,
            [FromQuery] string? search = null,
            [FromQuery] string? action = null,
            [FromQuery] string? entity = null,
            [FromQuery] string? user = null,
            [FromQuery] DateTime? from = null,
            [FromQuery] DateTime? to = null)
        {
            var result = await _auditLogQueryService.SearchAsync(new AuditLogQuery
            {
                Page = page,
                PageSize = pageSize,
                Search = search,
                Action = action,
                Entity = entity,
                User = user,
                From = from,
                To = to
            });

            return Ok(new
            {
                success = true,
                message = "Audit logs retrieved successfully",
                data = result.Items,
                pagination = new
                {
                    page = result.Page,
                    pageSize = result.PageSize,
                    totalRecords = result.TotalRecords,
                    totalPages = result.TotalPages
                }
            });
        }

        /// <summary>Distinct filter values for the dropdowns.</summary>
        [HttpGet("filters")]
        [RequirePermission(Permission.SystemAuditLogs, requireRead: true)]
        public async Task<IActionResult> GetFilters()
        {
            var facets = await _auditLogQueryService.GetFacetsAsync();
            return Ok(new { success = true, data = new { facets.Actions, facets.Entities, facets.Users } });
        }
    }
}
