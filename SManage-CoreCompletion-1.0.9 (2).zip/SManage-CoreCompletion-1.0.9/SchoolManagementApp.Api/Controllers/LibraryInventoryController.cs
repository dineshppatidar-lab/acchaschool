using IEmailService = SchoolManagementApp.ApplicationCore.Communication.Interfaces.IEmailService;
using IRealtimeNotificationService = SchoolManagementApp.ApplicationCore.Communication.Interfaces.IRealtimeNotificationService;

namespace SchoolManagementApp.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class LibraryInventoryController : BaseApiController
    {
        private readonly IBookRepository _bookRepository;
        private readonly IAssetRepository _assetRepository;
        private readonly IInventoryItemRepository _inventoryRepository;
        private readonly IMaintenanceRecordRepository _maintenanceRepository;
        private readonly IRealtimeNotificationService _notificationService;
        private readonly IEmailService _emailService;

        public LibraryInventoryController(
            IBookRepository bookRepository,
            IAssetRepository assetRepository,
            IInventoryItemRepository inventoryRepository,
            IMaintenanceRecordRepository maintenanceRepository,
            IRealtimeNotificationService notificationService,
            IEmailService emailService,
            ILogger<LibraryInventoryController> logger) : base(logger)
        {
            _bookRepository = bookRepository;
            _assetRepository = assetRepository;
            _inventoryRepository = inventoryRepository;
            _maintenanceRepository = maintenanceRepository;
            _notificationService = notificationService;
            _emailService = emailService;
        }

        // Library Management
        [HttpGet("books")]
        [RequirePermission(Permission.LibraryView, requireRead: true)]
        public async Task<IActionResult> GetBooks(
            [FromQuery] string search = "", 
            [FromQuery] string category = "", 
            [FromQuery] string? status = null, 
            [FromQuery] int page = 1, 
            [FromQuery] int pageSize = 20)
        {
            try
            {
                LogAction($"Getting books - Search: {search}, Category: {category}, Status: {status}");

                var (books, totalCount) = await _bookRepository.GetBooksAsync(search, category, status, page, pageSize);

                return PaginatedResult<Book>(books, totalCount, page, pageSize, "Books retrieved successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error retrieving books");
                return ErrorResult("Failed to retrieve books: " + ex.Message);
            }
        }

        [HttpPost("books")]
        [RequirePermission(Permission.LibraryManageInventory, requireWrite: true)]
        public async Task<IActionResult> CreateBook([FromBody] Book book)
        {
            try
            {
                LogAction($"Creating new book: {book.Title}");

                if (!ModelState.IsValid)
                    return ValidationErrorResult(ModelState.Values
                        .SelectMany(v => v.Errors)
                        .Select(e => e.ErrorMessage)
                        .ToList());

                book.CreatedOn = DateTime.UtcNow;
                book.Status = BookStatus.Available;
                
                book.CreatedBy = GetCurrentUserId();

                var createdBook = await _bookRepository.AddAsync(book);

                // Send notification
                await _notificationService.SendNotificationAsync(
                    "Library",
                    $"New book '{book.Title}' added to library",
                    new[] { "Librarian", "Staff" });

                return CreatedResult(createdBook, "Book created successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error creating book: {book?.Title}");
                return ErrorResult("Failed to create book: " + ex.Message);
            }
        }

        [HttpPut("books/{id}")]
        [RequirePermission(Permission.LibraryManageInventory, requireWrite: true)]
        public async Task<IActionResult> UpdateBook(int id, [FromBody] Book book)
        {
            try
            {
                LogAction($"Updating book ID: {id}");

                if (id != book.BookId && id != book.Id)
                    return BadRequest("Book ID mismatch");

                if (!ModelState.IsValid)
                    return ValidationErrorResult(ModelState.Values
                        .SelectMany(v => v.Errors)
                        .Select(e => e.ErrorMessage)
                        .ToList());

                var existingBook = await _bookRepository.GetByIdAsync(id);
                if (existingBook == null)
                    return NotFound($"Book with ID {id} not found");

                await _bookRepository.UpdateAsync(book);

                return SuccessResult(book, "Book updated successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error updating book ID: {id}");
                return ErrorResult("Failed to update book: " + ex.Message);
            }
        }

        [HttpPost("books/{bookId}/issue")]
        [RequirePermission(Permission.LibraryIssueBooks, requireWrite: true)]
        public async Task<IActionResult> IssueBook(int bookId, [FromBody] IssueBookRequest request)
        {
            try
            {
                LogAction($"Issuing book ID: {bookId} to student: {request.StudentId}");

                var book = await _bookRepository.GetByIdAsync(bookId);
                if (book == null)
                    return NotFound($"Book with ID {bookId} not found");

                if (book.Status != BookStatus.Available)
                    return BadRequest("Book is not available for issue");

                // Check if student already has maximum books issued
                var issuedCount = await _bookRepository.GetIssuedBooksCountAsync(request.StudentId);
                if (issuedCount >= 5) // Assuming max 5 books per student
                    return BadRequest("Student has reached maximum book issue limit");

                book.Status = BookStatus.Issued;
                book.IssuedToStudentId = request.StudentId;
                book.IssueDate = DateTime.UtcNow;
                book.DueDate = DateTime.UtcNow.AddDays(request.IssuePeriodDays ?? 14);
                
                var userIdStr = GetCurrentUserId();
                if (int.TryParse(userIdStr, out int userId))
                {
                    book.IssuedByStaffId = userId;
                }

                await _bookRepository.UpdateAsync(book);

                // Send notification to student
                await _notificationService.SendNotificationAsync(
                    "Library",
                    $"Book '{book.Title}' issued to you. Due date: {book.DueDate:yyyy-MM-dd}",
                    new[] { request.StudentId.ToString() });

                return SuccessResult(book, "Book issued successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error issuing book ID: {bookId}");
                return ErrorResult("Failed to issue book: " + ex.Message);
            }
        }

        [HttpPost("books/{bookId}/return")]
        [RequirePermission(Permission.LibraryReturnBooks, requireWrite: true)]
        public async Task<IActionResult> ReturnBook(int bookId, [FromBody] ReturnBookRequest request)
        {
            try
            {
                LogAction($"Returning book ID: {bookId}");

                var book = await _bookRepository.GetByIdAsync(bookId);
                if (book == null)
                    return NotFound($"Book with ID {bookId} not found");

                if (book.Status != BookStatus.Issued)
                    return BadRequest("Book is not currently issued");

                var returnDate = DateTime.UtcNow;
                var fineAmount = 0m;

                // Calculate fine for overdue books
                if (returnDate > book.DueDate)
                {
                    var overdueDays = (returnDate - book.DueDate.Value).Days;
                    fineAmount = overdueDays * 2m; // ₹2 per day fine
                }

                book.Status = BookStatus.Available;
                book.ReturnDate = returnDate;
                book.FineAmount = fineAmount;
                book.BookCondition = request.BookCondition.ToString();
                book.ReturnNotes = request.Notes;

                // Clear issue information
                book.IssuedToStudentId = null;
                book.IssueDate = null;
                book.DueDate = null;

                await _bookRepository.UpdateAsync(book);

                var result = new
                {
                    Book = book,
                    FineAmount = fineAmount,
                    IsOverdue = returnDate > book.DueDate,
                    OverdueDays = returnDate > book.DueDate ? (returnDate - book.DueDate.Value).Days : 0
                };

                return SuccessResult(result, "Book returned successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error returning book ID: {bookId}");
                return ErrorResult("Failed to return book: " + ex.Message);
            }
        }

        [HttpGet("books/overdue")]
        [RequirePermission(Permission.LibraryView, requireRead: true)]
        public async Task<IActionResult> GetOverdueBooks()
        {
            try
            {
                LogAction("Getting overdue books");

                var overdueBooks = await _bookRepository.GetOverdueBooksAsync();

                return SuccessResult(overdueBooks, "Overdue books retrieved successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error retrieving overdue books");
                return ErrorResult("Failed to retrieve overdue books: " + ex.Message);
            }
        }

        // Asset Management
        [HttpGet("assets")]
        [RequirePermission(Permission.LibraryManageInventory, requireRead: true)]
        public async Task<IActionResult> GetAssets(
            [FromQuery] string search = "", 
            [FromQuery] string? type = null, 
            [FromQuery] string? status = null, 
            [FromQuery] int page = 1, 
            [FromQuery] int pageSize = 20)
        {
            try
            {
                LogAction($"Getting assets - Search: {search}, Type: {type}, Status: {status}");

                var (assets, totalCount) = await _assetRepository.GetAssetsAsync(search, type, status, page, pageSize);

                return PaginatedResult<Asset>(assets, totalCount, page, pageSize, "Assets retrieved successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error retrieving assets");
                return ErrorResult("Failed to retrieve assets: " + ex.Message);
            }
        }

        [HttpPost("assets")]
        [RequirePermission(Permission.LibraryManageInventory, requireWrite: true)]
        public async Task<IActionResult> CreateAsset([FromBody] Asset asset)
        {
            try
            {
                LogAction($"Creating new asset: {asset.Name}");

                if (!ModelState.IsValid)
                    return ValidationErrorResult(ModelState.Values
                        .SelectMany(v => v.Errors)
                        .Select(e => e.ErrorMessage)
                        .ToList());

                asset.PurchaseDate = DateTime.UtcNow;
                asset.Status = AssetStatus.Available;

                var createdAsset = await _assetRepository.AddAsync(asset);

                return CreatedResult(createdAsset, "Asset created successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error creating asset: {asset?.Name}");
                return ErrorResult("Failed to create asset: " + ex.Message);
            }
        }

        [HttpPost("assets/{assetId}/transfer")]
        [RequirePermission(Permission.LibraryManageInventory, requireWrite: true)]
        public async Task<IActionResult> TransferAsset(int assetId, [FromBody] AssetTransferRequest request)
        {
            try
            {
                LogAction($"Transferring asset ID: {assetId}");

                var asset = await _assetRepository.GetByIdAsync(assetId);
                if (asset == null)
                    return NotFound($"Asset with ID {assetId} not found");

                // Create transfer record
                var transfer = new AssetTransfer
                {
                    AssetId = assetId,
                    FromDepartment = asset.AssignedDepartment,
                    ToDepartment = request.ToDepartment,
                    TransferDate = DateTime.UtcNow,
                    TransferReason = request.Reason,
                    Notes = request.Notes
                };
                
                var userIdStr = GetCurrentUserId();
                if (int.TryParse(userIdStr, out int userId))
                {
                    transfer.ApprovedBy = userId;
                }

                asset.AssignedDepartment = request.ToDepartment;
                asset.Location = request.NewLocation;

                await _assetRepository.UpdateAsync(asset);
                await _assetRepository.AddTransferAsync(transfer);

                return SuccessResult(transfer, "Asset transferred successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error transferring asset ID: {assetId}");
                return ErrorResult("Failed to transfer asset: " + ex.Message);
            }
        }

        // Inventory Management
        [HttpGet("inventory")]
        [RequirePermission(Permission.LibraryView, requireRead: true)]
        public async Task<IActionResult> GetInventory(
            [FromQuery] string search = "", 
            [FromQuery] string? category = null, 
            [FromQuery] int page = 1, 
            [FromQuery] int pageSize = 20)
        {
            try
            {
                LogAction($"Getting inventory - Search: {search}, Category: {category}");

                var (items, totalCount) = await _inventoryRepository.GetInventoryAsync(search, category, page, pageSize);

                return PaginatedResult<InventoryItem>(items, totalCount, page, pageSize, "Inventory retrieved successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error retrieving inventory");
                return ErrorResult("Failed to retrieve inventory: " + ex.Message);
            }
        }

        [HttpPost("inventory/{itemId}/transaction")]
        [RequirePermission(Permission.LibraryManageInventory, requireWrite: true)]
        public async Task<IActionResult> CreateInventoryTransaction(int itemId, [FromBody] InventoryTransactionRequest request)
        {
            try
            {
                LogAction($"Creating inventory transaction for item ID: {itemId}");

                var item = await _inventoryRepository.GetByIdAsync(itemId);
                if (item == null)
                    return NotFound($"Inventory item with ID {itemId} not found");

                // Validate transaction
                if (request.TransactionType == InventoryTransactionType.Out && 
                    request.Quantity > item.AvailableQuantity)
                    return BadRequest("Insufficient stock for outward transaction");

                var transaction = new InventoryTransaction
                {
                    ItemId = itemId,
                    Type = (TransactionType)request.TransactionType,
                    Quantity = request.Quantity,
                    TransactionDate = DateTime.UtcNow,
                    Purpose = request.Purpose,
                    Remarks = request.Notes
                };
                
                var userIdStr = GetCurrentUserId();
                if (int.TryParse(userIdStr, out int userId))
                {
                    transaction.ProcessedBy = userId;
                }

                // Update stock
                if (request.TransactionType == InventoryTransactionType.In)
                    item.AvailableQuantity += request.Quantity;
                else
                    item.AvailableQuantity -= request.Quantity;

                item.UpdatedOn = DateTime.UtcNow;

                await _inventoryRepository.UpdateAsync(item);
                await _inventoryRepository.AddTransactionAsync(transaction);

                // Check for low stock alert
                if (item.AvailableQuantity <= item.ReorderLevel)
                {
                    await _notificationService.SendNotificationAsync(
                        "Inventory Alert",
                        $"Low stock alert: {item.Name} (Current: {item.AvailableQuantity}, Minimum: {item.ReorderLevel})",
                        new[] { "Admin", "Staff" });
                }

                return CreatedResult(transaction, "Inventory transaction created successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error creating inventory transaction for item ID: {itemId}");
                return ErrorResult("Failed to create inventory transaction: " + ex.Message);
            }
        }

        [HttpGet("inventory/low-stock")]
        [RequirePermission(Permission.LibraryView, requireRead: true)]
        public async Task<IActionResult> GetLowStockItems()
        {
            try
            {
                LogAction("Getting low stock items");

                var lowStockItems = await _inventoryRepository.GetLowStockItemsAsync();

                return SuccessResult(lowStockItems, "Low stock items retrieved successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error retrieving low stock items");
                return ErrorResult("Failed to retrieve low stock items: " + ex.Message);
            }
        }

        // Maintenance Management
        [HttpPost("assets/{assetId}/maintenance")]
        [RequirePermission(Permission.LibraryManageInventory, requireWrite: true)]
        public async Task<IActionResult> ScheduleMaintenance(int assetId, [FromBody] MaintenanceScheduleRequest request)
        {
            try
            {
                LogAction($"Scheduling maintenance for asset ID: {assetId}");

                var asset = await _assetRepository.GetByIdAsync(assetId);
                if (asset == null)
                    return NotFound($"Asset with ID {assetId} not found");

                var maintenance = new MaintenanceRecord
                {
                    AssetId = assetId,
                    Type = request.MaintenanceType,
                    ScheduledDate = request.ScheduledDate,
                    Description = request.Description,
                    Priority = request.Priority.ToString(),
                    Status = MaintenanceStatus.Scheduled,
                    EstimatedCost = request.EstimatedCost,
                    CreatedOn = DateTime.UtcNow
                };
                
                var userIdStr = GetCurrentUserId();
                if (int.TryParse(userIdStr, out int userId))
                {
                    maintenance.RequestedBy = userId;
                }

                var createdMaintenance = await _maintenanceRepository.AddAsync(maintenance);

                // Update asset status if maintenance is critical
                if (request.Priority == MaintenancePriority.Critical)
                {
                    asset.Status = AssetStatus.UnderMaintenance;
                    await _assetRepository.UpdateAsync(asset);
                }

                return CreatedResult(createdMaintenance, "Maintenance scheduled successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error scheduling maintenance for asset ID: {assetId}");
                return ErrorResult("Failed to schedule maintenance: " + ex.Message);
            }
        }

        [HttpPut("maintenance/{maintenanceId}/complete")]
        [RequirePermission(Permission.LibraryManageInventory, requireWrite: true)]
        public async Task<IActionResult> CompleteMaintenance(int maintenanceId, [FromBody] MaintenanceCompletionRequest request)
        {
            try
            {
                LogAction($"Completing maintenance ID: {maintenanceId}");

                var maintenance = await _maintenanceRepository.GetByIdAsync(maintenanceId);
                if (maintenance == null)
                    return NotFound($"Maintenance record with ID {maintenanceId} not found");

                maintenance.Status = MaintenanceStatus.Completed;
                maintenance.CompletedDate = DateTime.UtcNow;
                maintenance.ActualCost = request.ActualCost;
                maintenance.CompletionNotes = request.CompletionNotes;
                
                var userIdStr = GetCurrentUserId();
                if (int.TryParse(userIdStr, out int userId))
                {
                    maintenance.CompletedBy = userId;
                }

                await _maintenanceRepository.UpdateAsync(maintenance);

                // Update asset status
                if (maintenance.AssetId.HasValue)
                {
                    var asset = await _assetRepository.GetByIdAsync(maintenance.AssetId.Value);
                    if (asset != null)
                    {
                        asset.Status = AssetStatus.Available;
                        asset.LastMaintenanceDate = DateTime.UtcNow;
                        await _assetRepository.UpdateAsync(asset);
                    }
                }

                return SuccessResult(maintenance, "Maintenance completed successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error completing maintenance ID: {maintenanceId}");
                return ErrorResult("Failed to complete maintenance: " + ex.Message);
            }
        }

        [HttpGet("reports/library-usage")]
        [RequirePermission(Permission.LibraryView, requireRead: true)]
        public async Task<IActionResult> GetLibraryUsageReport([FromQuery] DateTime? startDate = null, [FromQuery] DateTime? endDate = null)
        {
            try
            {
                LogAction($"Generating library usage report from {startDate} to {endDate}");

                var report = await _bookRepository.GetLibraryUsageReportAsync(
                    startDate ?? DateTime.UtcNow.AddMonths(-1),
                    endDate ?? DateTime.UtcNow);

                return SuccessResult(report, "Library usage report generated successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error generating library usage report");
                return ErrorResult("Failed to generate library usage report: " + ex.Message);
            }
        }
    }

    // Request DTOs
    public class IssueBookRequest
    {
        public int StudentId { get; set; }
        public int? IssuePeriodDays { get; set; } = 14;
    }

    public class ReturnBookRequest
    {
        public BookCondition BookCondition { get; set; }
        public string Notes { get; set; }
    }

    public class AssetTransferRequest
    {
        public string ToDepartment { get; set; }
        public string NewLocation { get; set; }
        public string Reason { get; set; }
        public string Notes { get; set; }
    }

    public class InventoryTransactionRequest
    {
        public InventoryTransactionType TransactionType { get; set; }
        public int Quantity { get; set; }
        public string Purpose { get; set; }
        public string Notes { get; set; }
    }

    public class MaintenanceScheduleRequest
    {
        public MaintenanceType MaintenanceType { get; set; }
        public DateTime ScheduledDate { get; set; }
        public string Description { get; set; }
        public MaintenancePriority Priority { get; set; }
        public decimal? EstimatedCost { get; set; }
    }

    public class MaintenanceCompletionRequest
    {
        public decimal? ActualCost { get; set; }
        public string CompletionNotes { get; set; }
    }
}
