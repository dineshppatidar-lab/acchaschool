using SchoolManagementApp.ApplicationCore.Academic.Interfaces;
using SchoolManagementApp.ApplicationCore.Communication.Interfaces;
using System.Text;

namespace SchoolManagementApp.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class AdvancedAcademicController : BaseApiController
    {
        private readonly ITimeTableRepository _timeTableRepository;
        private readonly IExaminationRepository _examinationRepository;
        private readonly IExaminationTypeRepository _examinationTypeRepository;
        private readonly IExamScheduleRepository _examScheduleRepository;
        private readonly IAcademicYearRepository _academicYearRepository;
        private readonly IAssignmentRepository _assignmentRepository;
        private readonly IAssignmentSubmissionRepository _assignmentSubmissionRepository;
        private readonly IGradingSchemeRepository _gradingSchemeRepository;
        private readonly IRealtimeNotificationService _notificationService;
        private readonly IExamResultRepository _examResultRepository;

        public AdvancedAcademicController(
            ITimeTableRepository timeTableRepository,
            IExaminationRepository examinationRepository,
            IExaminationTypeRepository examinationTypeRepository,
            IExamScheduleRepository examScheduleRepository,
            IAcademicYearRepository academicYearRepository,
            IAssignmentRepository assignmentRepository,
            IAssignmentSubmissionRepository assignmentSubmissionRepository,
            IGradingSchemeRepository gradingSchemeRepository,
            IRealtimeNotificationService notificationService,
            IExamResultRepository examResultRepository,
            ILogger<AdvancedAcademicController> logger) : base(logger)
        {
            _timeTableRepository = timeTableRepository;
            _examinationRepository = examinationRepository;
            _examinationTypeRepository = examinationTypeRepository;
            _examScheduleRepository = examScheduleRepository;
            _academicYearRepository = academicYearRepository;
            _assignmentRepository = assignmentRepository;
            _assignmentSubmissionRepository = assignmentSubmissionRepository;
            _gradingSchemeRepository = gradingSchemeRepository;
            _notificationService = notificationService;
            _examResultRepository = examResultRepository;
        }

        // TimeTable Management
    [HttpGet("timetable/class/{classId}/section/{sectionId}")]
    [RequirePermission(Permission.TimetablesView, requireRead: true)]
        public async Task<IActionResult> GetTimeTableByClass(int classId, int sectionId)
        {
            try
            {
                LogAction($"Getting timetable for class {classId}, section {sectionId}");
                var timetable = await _timeTableRepository.GetTimeTableByClassAsync(classId, sectionId);
                return SuccessResult(timetable, "Timetable retrieved successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error retrieving timetable for class {classId}, section {sectionId}");
                return ErrorResult("Failed to retrieve timetable");
            }
        }

    [HttpGet("timetable/staff/{staffId}")]
    [RequirePermission(Permission.TimetablesView, requireRead: true)]
        public async Task<IActionResult> GetTimeTableByStaff(int staffId)
        {
            try
            {
                LogAction($"Getting timetable for staff {staffId}");
                var timetable = await _timeTableRepository.GetTimeTableByStaffAsync(staffId);
                return SuccessResult(timetable, "Staff timetable retrieved successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error retrieving timetable for staff {staffId}");
                return ErrorResult("Failed to retrieve staff timetable");
            }
        }

    [HttpPost("timetable")]
        [RequirePermission(Permission.TimetablesManage, requireWrite: true)]
        public async Task<IActionResult> CreateTimeTable([FromBody] TimeTable timeTable)
        {
            try
            {
                LogAction($"Creating new timetable entry for class {timeTable.ClassId}");

                // Default SectionId to the class's first section when the client omits it
                if (timeTable.SectionId == 0)
                {
                    timeTable.SectionId = await _timeTableRepository.GetDefaultSectionIdAsync(timeTable.ClassId);
                    if (timeTable.SectionId == 0)
                    {
                        return BadRequest("This class has no sections — add a section first.");
                    }
                }

                // Check for conflicts
                var hasConflict = await _timeTableRepository.CheckTimeSlotConflictAsync(
                    timeTable.StaffId, timeTable.DayOfWeek, timeTable.StartTime, timeTable.EndTime);
                
                if (hasConflict)
                {
                    return BadRequest("Time slot conflict detected for the selected staff member");
                }

                timeTable.CreatedOn = DateTime.UtcNow;
                var result = await _timeTableRepository.AddAsync(timeTable);
                
                // Notify affected parties
                await _notificationService.SendNotificationAsync(
                    "timetable",
                    $"New class scheduled: {timeTable.DayOfWeek} {timeTable.StartTime}-{timeTable.EndTime}",
                    new[] { timeTable.StaffId.ToString() });

                return CreatedResult(result, "Timetable entry created successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error creating timetable entry");
                return ErrorResult("Failed to create timetable entry");
            }
        }

        // Additional timetable endpoints to support frontend
    [HttpGet("timetables")]
    [RequirePermission(Permission.TimetablesView, requireRead: true)]
        public async Task<IActionResult> GetTimetables([FromQuery] int page = 1, [FromQuery] int pageSize = 20)
        {
            try
            {
                var items = await _timeTableRepository.GetPagedAsync(page, pageSize);
                return SuccessResult(items, "Timetables retrieved successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error retrieving timetables");
                return ErrorResult("Failed to retrieve timetables");
            }
        }

    [HttpGet("timetables/class/{classId}")]
    [RequirePermission(Permission.TimetablesView, requireRead: true)]
        public async Task<IActionResult> GetTimetableByClassSimple(int classId)
        {
            try
            {
                var items = await _timeTableRepository.GetByClassWithDetailsAsync(classId);
                var dtos = items.Select(t => new
                {
                    id = t.Id,
                    classId = t.ClassId,
                    sectionId = t.SectionId,
                    subjectId = t.SubjectId,
                    staffId = t.StaffId,
                    dayOfWeek = (int)t.DayOfWeek,
                    startTime = t.StartTime.ToString(),
                    endTime = t.EndTime.ToString(),
                    roomNumber = t.RoomNumber,
                    subjectName = t.Subject?.Name ?? string.Empty,
                    teacherName = t.Staff != null ? $"{t.Staff.FirstName} {t.Staff.LastName}".Trim() : string.Empty,
                    sectionName = t.Section?.Name ?? string.Empty
                });
                return SuccessResult(dtos, "Class timetable retrieved successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error retrieving timetable for class {classId}");
                return ErrorResult("Failed to retrieve timetable");
            }
        }

        [HttpPut("timetables/{id}")]
        [RequirePermission(Permission.TimetablesManage, requireWrite: true)]
        public async Task<IActionResult> UpdateTimetable(int id, [FromBody] TimeTable timeTable)
        {
            try
            {
                if (id != timeTable.Id) return BadRequest("ID mismatch");
                await _timeTableRepository.UpdateAsync(timeTable);
                return SuccessResult("Timetable updated successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error updating timetable {id}");
                return ErrorResult("Failed to update timetable");
            }
        }

        [HttpDelete("timetables/{id}")]
        [RequirePermission(Permission.TimetablesManage, requireDelete: true)]
        public async Task<IActionResult> DeleteTimetable(int id)
        {
            try
            {
                await _timeTableRepository.DeleteAsync(id);
                return SuccessResult("Timetable deleted successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error deleting timetable {id}");
                return ErrorResult("Failed to delete timetable");
            }
        }

        [HttpPost("timetables/validate")]
        [RequirePermission(Permission.TimetablesManage, requireRead: true)]
        public async Task<IActionResult> ValidateTimetable([FromBody] TimeTable check)
        {
            try
            {
                var conflict = await _timeTableRepository.CheckTimeSlotConflictAsync(
                    check.StaffId, check.DayOfWeek, check.StartTime, check.EndTime);
                return SuccessResult(new { hasConflict = conflict }, conflict ? "Conflict detected" : "No conflicts");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error validating timetable entry");
                return ErrorResult("Failed to validate timetable entry");
            }
        }

        [HttpPost("timetables/generate/{classId}")]
        [RequirePermission(Permission.TimetablesManage, requireWrite: true)]
        public async Task<IActionResult> GenerateTimetable(int classId, [FromBody] object? preferences)
        {
            try
            {
                var generated = await _timeTableRepository.GenerateForClassAsync(classId);
                return SuccessResult(generated, "Timetable generated successfully");
            }
            catch (InvalidOperationException ex)
            {
                return BadRequest(new { message = ex.Message });
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error generating timetable for class {classId}");
                return ErrorResult("Failed to generate timetable");
            }
        }

        [HttpGet("timetables/conflicts")]
        [RequirePermission(Permission.TimetablesView, requireRead: true)]
        public async Task<IActionResult> GetTimetableConflicts([FromQuery] int? staffId = null)
        {
            try
            {
                var all = await _timeTableRepository.GetAllAsync();
                var list = staffId.HasValue ? all.Where(t => t.StaffId == staffId.Value).ToList() : all.ToList();
                var conflicts = new List<object>();
                foreach (var g in list.GroupBy(t => new { t.StaffId, t.DayOfWeek }))
                {
                    var ordered = g.OrderBy(t => t.StartTime).ToList();
                    for (int i = 0; i < ordered.Count - 1; i++)
                    {
                        if (ordered[i + 1].StartTime < ordered[i].EndTime)
                        {
                            conflicts.Add(new { first = ordered[i].Id, second = ordered[i + 1].Id, staff = g.Key.StaffId, day = g.Key.DayOfWeek });
                        }
                    }
                }
                return SuccessResult(conflicts, "Timetable conflicts computed");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error computing timetable conflicts");
                return ErrorResult("Failed to compute conflicts");
            }
        }

        [HttpGet("timetables/export/{classId}")]
        [EnableRateLimiting("Export")]
        [RequirePermission(Permission.TimetablesView, requireRead: true)]
        public async Task<IActionResult> ExportTimetable(int classId)
        {
            try
            {
                var items = await _timeTableRepository.FindAsync(t => t.ClassId == classId);
                var csv = new StringBuilder();
                csv.AppendLine("Day,Start,End,Room,StaffId,SubjectId,SectionId");
                foreach (var t in items)
                {
                    csv.AppendLine($"{t.DayOfWeek},{t.StartTime},{t.EndTime},{t.RoomNumber},{t.StaffId},{t.SubjectId},{t.SectionId}");
                }
                var bytes = Encoding.UTF8.GetBytes(csv.ToString());
                return File(bytes, "text/csv", $"timetable_class_{classId}.csv");
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error exporting timetable for class {classId}");
                return ErrorResult("Failed to export timetable");
            }
        }

        // Examination Management
    [HttpGet("examinations")]
    [RequirePermission(Permission.ExaminationsView, requireRead: true)]
        public async Task<IActionResult> GetExaminations([FromQuery] int? academicYearId, [FromQuery] int? typeId)
        {
            try
            {
                LogAction($"Getting examinations - Academic Year: {academicYearId}, Type: {typeId}");
                
                IEnumerable<Examination> examinations;
                if (academicYearId.HasValue)
                {
                    examinations = await _examinationRepository.GetExaminationsByAcademicYearAsync(academicYearId.Value);
                }
                else if (typeId.HasValue)
                {
                    examinations = await _examinationRepository.GetExaminationsByTypeAsync(typeId.Value);
                }
                else
                {
                    examinations = await _examinationRepository.GetUpcomingExaminationsAsync();
                }
                
                return SuccessResult(examinations, "Examinations retrieved successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error retrieving examinations");
                return ErrorResult("Failed to retrieve examinations");
            }
        }

        [HttpPost("examinations")]
        [RequirePermission(Permission.ExaminationsCreate, requireWrite: true)]
        public async Task<IActionResult> CreateExamination([FromBody] Examination examination)
        {
            try
            {
                LogAction($"Creating new examination: {examination.Title}");

                examination.CreatedOn = DateTime.UtcNow;
                var userId = GetCurrentUserId();

                examination.CreatedBy = int.TryParse(userId, out var uid)
                    ? uid.ToString()
                    : "0";

                examination.ExaminationType = null;
                examination.AcademicYear = null;

                // The type dropdown falls back to "General" when no types exist yet —
                // an ExaminationType FK value pointing at an empty table would otherwise
                // fail the insert with an unhelpful generic error.
                if (examination.ExaminationTypeId > 0)
                {
                    var typeExists = await _examinationTypeRepository.GetByIdAsync(examination.ExaminationTypeId);
                    if (typeExists == null)
                    {
                        var created = await _examinationTypeRepository.AddAsync(new ExaminationType
                        {
                            Name = "General",
                            Description = "Default type created automatically on first examination",
                            IsActive = true
                        });
                        examination.ExaminationTypeId = created.Id;
                    }
                }
                else
                {
                    var firstType = (await _examinationTypeRepository.GetAllAsync()).FirstOrDefault();
                    if (firstType == null)
                    {
                        var created = await _examinationTypeRepository.AddAsync(new ExaminationType
                        {
                            Name = "General",
                            Description = "Default type created automatically on first examination",
                            IsActive = true
                        });
                        examination.ExaminationTypeId = created.Id;
                    }
                    else
                    {
                        examination.ExaminationTypeId = firstType.Id;
                    }
                }

                var result = await _examinationRepository.AddAsync(examination);
                
                // Notify all relevant staff
                await _notificationService.SendNotificationToGroupAsync(
                    "academic-staff", 
                    $"New examination scheduled: {examination.Title}",
                    "examination");

                return CreatedResult(result, "Examination created successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error creating examination: " + ex.Message);
                return ErrorResult("Failed to create examination: " + ex.Message);
            }
        }

        [HttpPut("examinations/{id}")]
        [RequirePermission(Permission.ExaminationsEdit, requireWrite: true)]
        public async Task<IActionResult> UpdateExamination(int id, [FromBody] Examination examination)
        {
            try
            {
                LogAction($"Updating examination: {id}");
                if (id != examination.Id)
                {
                    return BadRequest("ID mismatch between URL and examination body");
                }

                var existing = await _examinationRepository.GetByIdAsync(id);
                if (existing == null)
                {
                    return NotFound("Examination not found");
                }

                // Update properties explicitly
                existing.Title = examination.Title;
                existing.ExaminationTypeId = examination.ExaminationTypeId;
                existing.AcademicYearId = examination.AcademicYearId;
                existing.StartDate = examination.StartDate;
                existing.EndDate = examination.EndDate;
                existing.Instructions = examination.Instructions;
                existing.IsPublished = examination.IsPublished;

                await _examinationRepository.UpdateAsync(existing);
                return SuccessResult("Examination updated successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error updating examination {id}: " + ex.Message);
                return ErrorResult("Failed to update examination: " + ex.Message);
            }
        }

        [HttpDelete("examinations/{id}")]
        [RequirePermission(Permission.ExaminationsDelete, requireDelete: true)]
        public async Task<IActionResult> DeleteExamination(int id)
        {
            try
            {
                LogAction($"Deleting examination: {id}");
                await _examinationRepository.DeleteAsync(id);
                return SuccessResult("Examination deleted successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error deleting examination {id}");
                return ErrorResult("Failed to delete examination");
            }
        }

        [HttpGet("examinations/{id}/schedules")]
    [RequirePermission(Permission.ExaminationsView, requireRead: true)]
        public async Task<IActionResult> GetExamSchedules(int id)
        {
            try
            {
                LogAction($"Getting schedules for examination {id}");
                var schedules = await _examScheduleRepository.GetSchedulesByExaminationAsync(id);
                return SuccessResult(schedules, "Exam schedules retrieved successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error retrieving exam schedules for examination {id}");
                return ErrorResult("Failed to retrieve exam schedules");
            }
        }

        [HttpPost("examinations/{id}/schedules")]
        [RequirePermission(Permission.ExaminationsCreate, requireWrite: true)]
        public async Task<IActionResult> CreateExamSchedule(int id, [FromBody] ExamSchedule schedule)
        {
            try
            {
                LogAction($"Creating schedule for examination {id}");
                schedule.ExaminationId = id;
                var result = await _examScheduleRepository.AddAsync(schedule);
                return CreatedResult(result, "Exam schedule created successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error creating exam schedule for examination {id}");
                return ErrorResult("Failed to create exam schedule");
            }
        }

        [HttpPost("examinations/{id}/generate-timetable")]
        [RequirePermission(Permission.ExaminationsCreate, requireWrite: true)]
        public async Task<IActionResult> GenerateExamTimetable(int id)
        {
            try
            {
                var schedules = await _examScheduleRepository.GetSchedulesByExaminationAsync(id);
                return SuccessResult(schedules, "Generated exam timetable (placeholder)");
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error generating exam timetable for exam {id}");
                return ErrorResult("Failed to generate exam timetable");
            }
        }

        [HttpPost("examinations/{id}/generate-schedule")]
        [RequirePermission(Permission.ExaminationsCreate, requireWrite: true)]
        public IActionResult GenerateExamSchedule(int id, [FromBody] object? request)
        {
            try
            {
                return SuccessResult(new { examinationId = id, status = "generated" }, "Exam schedule generated (placeholder)");
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error generating exam schedule for exam {id}");
                return ErrorResult("Failed to generate exam schedule");
            }
        }

        [HttpGet("examinations/{id}/report")]
        [RequirePermission(Permission.ExaminationsView, requireRead: true)]
        public async Task<IActionResult> GetExaminationReport(int id)
        {
            try
            {
                var exam = await _examinationRepository.GetByIdAsync(id);
                var schedules = await _examScheduleRepository.GetSchedulesByExaminationAsync(id);
                var report = new { exam.Id, exam.Title, exam.StartDate, exam.EndDate, scheduleCount = schedules.Count() };
                return SuccessResult(report, "Examination report generated");
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error generating report for exam {id}");
                return ErrorResult("Failed to generate report");
            }
        }

        [HttpGet("examinations/{id}/export")]
        [EnableRateLimiting("Export")]
        [RequirePermission(Permission.ExaminationsView, requireRead: true)]
        public async Task<IActionResult> ExportExamination(int id)
        {
            try
            {
                var schedules = await _examScheduleRepository.GetSchedulesByExaminationAsync(id);
                var csv = new StringBuilder();
                csv.AppendLine("ClassId,SubjectId,ExamDate,StartTime,EndTime,RoomNumber");
                foreach (var s in schedules)
                {
                    csv.AppendLine($"{s.ClassId},{s.SubjectId},{s.ExamDate:yyyy-MM-dd},{s.StartTime},{s.EndTime},{s.RoomNumber}");
                }
                var bytes = Encoding.UTF8.GetBytes(csv.ToString());
                return File(bytes, "text/csv", $"examination_{id}_schedule.csv");
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error exporting examination {id}");
                return ErrorResult("Failed to export examination");
            }
        }

        // Assignment Management
    [HttpGet("assignments/class/{classId}/section/{sectionId}")]
    [RequirePermission(Permission.ClassesView, requireRead: true)]
        public async Task<IActionResult> GetAssignmentsByClass(int classId, int sectionId)
        {
            try
            {
                LogAction($"Getting assignments for class {classId}, section {sectionId}");
                var assignments = await _assignmentRepository.GetAssignmentsByClassAsync(classId, sectionId);
                return SuccessResult(assignments, "Assignments retrieved successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error retrieving assignments for class {classId}, section {sectionId}");
                return ErrorResult("Failed to retrieve assignments");
            }
        }

    [HttpGet("assignments/student/{studentId}")]
    [RequirePermission(Permission.ClassesView, requireRead: true)]
        public async Task<IActionResult> GetAssignmentsByStudent(int studentId)
        {
            try
            {
                LogAction($"Getting assignments for student {studentId}");
                var assignments = await _assignmentRepository.GetAssignmentsByStudentAsync(studentId);
                return SuccessResult(assignments, "Student assignments retrieved successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error retrieving assignments for student {studentId}");
                return ErrorResult("Failed to retrieve student assignments");
            }
        }

        [HttpPost("assignments")]
        [RequirePermission(Permission.ClassesEdit, requireWrite: true)]
        public async Task<IActionResult> CreateAssignment([FromBody] Assignment assignment)
        {
            try
            {
                LogAction($"Creating new assignment: {assignment.Title}");

                // Default SectionId to the class's first section when the client omits it
                if (assignment.SectionId == 0)
                {
                    assignment.SectionId = await _timeTableRepository.GetDefaultSectionIdAsync(assignment.ClassId);
                    if (assignment.SectionId == 0)
                    {
                        return BadRequest("This class has no sections — add a section first.");
                    }
                }

                assignment.AssignedBy = int.TryParse(GetCurrentUserId() ?? "0", out var currentId) ? currentId : 0;
                assignment.AssignedDate = DateTime.UtcNow;

                // Navigation properties are resolved by EF on read — a client never
                // posts them, and non-null required navigations fail ModelState
                // validation ([ApiController]) with "The Class field is required."
                assignment.Class = null!;
                assignment.Section = null!;
                assignment.Subject = null!;
                assignment.AssignedByStaff = null!;

                var result = await _assignmentRepository.AddAsync(assignment);
                
                // Notify students in the class
                await _notificationService.SendNotificationToGroupAsync(
                    $"class-{assignment.ClassId}-section-{assignment.SectionId}",
                    $"New assignment posted: {assignment.Title} (Due: {assignment.DueDate:MMM dd})",
                    "assignment");

                return CreatedResult(result, "Assignment created successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error creating assignment");
                return ErrorResult("Failed to create assignment");
            }
        }

        [HttpPost("assignments/{assignmentId}/submissions")]
        [Authorize(Roles = "Student")]
        public async Task<IActionResult> SubmitAssignment(int assignmentId, [FromBody] AssignmentSubmission submission)
        {
            try
            {
                LogAction($"Submitting assignment {assignmentId} by student {submission.StudentId}");
                
                // Check if already submitted
                var existingSubmission = await _assignmentSubmissionRepository
                    .GetSubmissionByStudentAndAssignmentAsync(submission.StudentId, assignmentId);
                
                if (existingSubmission != null)
                {
                    return BadRequest("Assignment already submitted");
                }

                submission.AssignmentId = assignmentId;
                submission.SubmittedDate = DateTime.UtcNow;
                submission.Status = "Submitted";
                
                var result = await _assignmentSubmissionRepository.AddAsync(submission);
                
                // Notify teacher
                var assignment = await _assignmentRepository.GetByIdAsync(assignmentId);
                await _notificationService.SendNotificationAsync(
                    "submission",
                    $"Assignment submission received for: {assignment.Title}",
                    new[] { assignment.AssignedBy.ToString() });

                return CreatedResult(result, "Assignment submitted successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error submitting assignment");
                return ErrorResult("Failed to submit assignment");
            }
        }

        [HttpGet("assignments/{assignmentId}/submissions")]
        [RequirePermission(Permission.ClassesView, requireRead: true)]
        public async Task<IActionResult> GetAssignmentSubmissions(int assignmentId)
        {
            try
            {
                LogAction($"Getting submissions for assignment {assignmentId}");
                var list = await _assignmentSubmissionRepository.GetSubmissionsByAssignmentAsync(assignmentId);
                return SuccessResult(list, "Assignment submissions retrieved successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error retrieving submissions for assignment {assignmentId}");
                return ErrorResult("Failed to retrieve assignment submissions");
            }
        }

        [HttpPut("assignments/submissions/{submissionId}/grade")]
        [RequirePermission(Permission.ResultsEnter, requireWrite: true)]
        public async Task<IActionResult> GradeSubmission(int submissionId, [FromBody] GradeSubmissionRequest request)
        {
            try
            {
                LogAction($"Grading submission {submissionId}");
                
                var submission = await _assignmentSubmissionRepository.GetByIdAsync(submissionId);
                if (submission == null)
                {
                    return NotFound("Submission not found");
                }

                submission.MarksObtained = request.MarksObtained;
                submission.FeedBack = request.Feedback;
                submission.GradedDate = DateTime.UtcNow;
                submission.GradedBy = int.TryParse(GetCurrentUserId() ?? "0", out var graderId) ? graderId : null;
                submission.Status = "Graded";
                
                await _assignmentSubmissionRepository.UpdateAsync(submission);
                
                // Notify student
                await _notificationService.SendNotificationAsync(
                    "grade",
                    $"Your assignment has been graded. Marks: {request.MarksObtained}",
                    new[] { submission.StudentId.ToString() });

                return SuccessResult("Assignment graded successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error grading assignment");
                return ErrorResult("Failed to grade assignment");
            }
        }

        [HttpPut("assignments/{id}")]
        [RequirePermission(Permission.ClassesEdit, requireWrite: true)]
        public async Task<IActionResult> UpdateAssignment(int id, [FromBody] Assignment assignment)
        {
            try
            {
                if (id != assignment.Id) return BadRequest("ID mismatch");
                if (!ModelState.IsValid)
                {
                    var errors = ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage).ToList();
                    return BadRequest(new { message = "Validation failed", errors });
                }
                LogAction($"Updating assignment {id}");

                // Keep SectionId valid if the client didn't send one
                if (assignment.SectionId == 0)
                {
                    var existing = await _assignmentRepository.GetByIdAsync(id);
                    if (existing != null) assignment.SectionId = existing.SectionId;
                }

                // Never post navigation properties (see CreateAssignment)
                assignment.Class = null!;
                assignment.Section = null!;
                assignment.Subject = null!;
                assignment.AssignedByStaff = null!;

                await _assignmentRepository.UpdateAsync(assignment);
                return SuccessResult("Assignment updated successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error updating assignment {id}");
                return ErrorResult("Failed to update assignment");
            }
        }

        [HttpDelete("assignments/{id}")]
        [RequirePermission(Permission.ClassesDelete, requireDelete: true)]
        public async Task<IActionResult> DeleteAssignment(int id)
        {
            try
            {
                LogAction($"Deleting assignment {id}");
                await _assignmentRepository.DeleteAsync(id);
                return SuccessResult("Assignment deleted successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error deleting assignment {id}");
                return ErrorResult("Failed to delete assignment");
            }
        }

        [HttpPost("assignments/{assignmentId}/grade")]
        [RequirePermission(Permission.ResultsEnter, requireWrite: true)]
        public async Task<IActionResult> GradeAssignmentForStudent(int assignmentId, [FromBody] GradeAssignmentRequest request)
        {
            try
            {
                LogAction($"Grading assignment {assignmentId} for student {request.StudentId}");
                var submission = await _assignmentSubmissionRepository.GetSubmissionByStudentAndAssignmentAsync(request.StudentId, assignmentId);
                if (submission == null)
                {
                    submission = new AssignmentSubmission
                    {
                        AssignmentId = assignmentId,
                        StudentId = request.StudentId,
                        SubmittedDate = DateTime.UtcNow,
                        Status = "Submitted"
                    };
                    submission = await _assignmentSubmissionRepository.AddAsync(submission);
                }

                submission.MarksObtained = request.MarksObtained;
                submission.FeedBack = request.Feedback ?? string.Empty;
                submission.GradedDate = DateTime.UtcNow;
                submission.GradedBy = int.TryParse(GetCurrentUserId() ?? "0", out var graderId) ? graderId : null;
                submission.Status = "Graded";

                await _assignmentSubmissionRepository.UpdateAsync(submission);
                return SuccessResult("Assignment graded successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error grading assignment {assignmentId}");
                return ErrorResult("Failed to grade assignment");
            }
        }

        [HttpPost("assignments/{assignmentId}/bulk-grade")]
        [RequirePermission(Permission.ResultsEnter, requireWrite: true)]
        public async Task<IActionResult> BulkGradeAssignments(int assignmentId, [FromBody] IEnumerable<GradeAssignmentRequest> grades)
        {
            try
            {
                LogAction($"Bulk grading assignment {assignmentId}");
            
            var studentIds = grades.Select(g => g.StudentId).ToList();
            var existingSubmissions = (await _assignmentSubmissionRepository.FindAsync(s => s.AssignmentId == assignmentId && studentIds.Contains(s.StudentId))).ToList();
            
            var toAdd = new List<AssignmentSubmission>();
            var toUpdate = new List<AssignmentSubmission>();
            var graderId = int.TryParse(GetCurrentUserId() ?? "0", out var gid) ? gid : (int?)null;

                foreach (var g in grades)
                {
                var submission = existingSubmissions.FirstOrDefault(s => s.StudentId == g.StudentId);
                if (submission == null)
                {
                    submission = new AssignmentSubmission
                    {
                        AssignmentId = assignmentId,
                        StudentId = g.StudentId,
                        SubmittedDate = DateTime.UtcNow,
                        Status = "Graded",
                        MarksObtained = g.MarksObtained,
                        FeedBack = g.Feedback ?? string.Empty,
                        GradedDate = DateTime.UtcNow,
                        GradedBy = graderId
                    };
                    toAdd.Add(submission);
                }
                else
                {
                    submission.MarksObtained = g.MarksObtained;
                    submission.FeedBack = g.Feedback ?? string.Empty;
                    submission.GradedDate = DateTime.UtcNow;
                    submission.GradedBy = graderId;
                    submission.Status = "Graded";
                    toUpdate.Add(submission);
                }
            }

            if (toAdd.Any()) await _assignmentSubmissionRepository.AddRangeAsync(toAdd);
            if (toUpdate.Any()) await _assignmentSubmissionRepository.UpdateRangeAsync(toUpdate);

                return SuccessResult("Bulk grading completed successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error during bulk grading for assignment {assignmentId}");
                return ErrorResult("Failed to bulk grade assignments");
            }
        }

        [HttpGet("assignments/{assignmentId}/export")]
        [EnableRateLimiting("Export")]
        [RequirePermission(Permission.ClassesView, requireRead: true)]
        public async Task<IActionResult> ExportAssignmentGrades(int assignmentId)
        {
            try
            {
                var subs = await _assignmentSubmissionRepository.GetSubmissionsByAssignmentAsync(assignmentId);
                var csv = new StringBuilder();
                csv.AppendLine("StudentId,MarksObtained,Status,GradedDate");
                foreach (var s in subs)
                {
                    csv.AppendLine($"{s.StudentId},{s.MarksObtained},{s.Status},{(s.GradedDate.HasValue ? s.GradedDate.Value.ToString("yyyy-MM-dd HH:mm") : string.Empty)}");
                }
                var bytes = Encoding.UTF8.GetBytes(csv.ToString());
                return File(bytes, "text/csv", $"assignment_{assignmentId}_grades.csv");
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error exporting assignment {assignmentId} grades");
                return ErrorResult("Failed to export assignment grades");
            }
        }

        // Academic Year Management
    [HttpGet("academic-years")]
    // DashboardView, not SystemSettings: this list feeds the advanced-academic page's
    // year dropdown — same rationale as GET /api/setup/academic-years, where requiring
    // SystemSettings silently broke the app-wide year selector for non-admin roles.
    [RequirePermission(Permission.DashboardView, requireRead: true)]
        public async Task<IActionResult> GetAcademicYears()
        {
            try
            {
                LogAction("Getting academic years");
                var academicYears = await _academicYearRepository.GetActiveAcademicYearsAsync();
                return SuccessResult(academicYears, "Academic years retrieved successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error retrieving academic years");
                return ErrorResult("Failed to retrieve academic years");
            }
        }

        // Analytics and Reports
        [HttpGet("analytics/teacher-workload")]
        [RequirePermission(Permission.AnalyticsView, requireRead: true)]
        public async Task<IActionResult> GetTeacherWorkload([FromQuery] int? teacherId)
        {
            try
            {
                var pending = teacherId.HasValue
                    ? await _assignmentSubmissionRepository.CountAsync(s => s.GradedBy == null && s.Assignment.AssignedBy == teacherId.Value)
                    : await _assignmentSubmissionRepository.CountAsync(s => s.GradedBy == null);
                    
                var totalSlots = teacherId.HasValue 
                    ? await _timeTableRepository.CountAsync(t => t.StaffId == teacherId.Value)
                    : await _timeTableRepository.CountAsync();
                    
                var result = new
                {
                    totalSlots = totalSlots,
                    pendingGrading = pending
                };
                return SuccessResult(result, "Teacher workload computed");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error computing teacher workload");
                return ErrorResult("Failed to compute teacher workload");
            }
        }

        [HttpGet("analytics/classroom-utilization")]
        [RequirePermission(Permission.AnalyticsView, requireRead: true)]
        public async Task<IActionResult> GetClassroomUtilization()
        {
            try
            {
                var timetables = await _timeTableRepository.GetAllAsync();
                var utilization = timetables
                    .Where(t => !string.IsNullOrWhiteSpace(t.RoomNumber))
                    .GroupBy(t => t.RoomNumber)
                    .Select(g => new { room = g.Key, slots = g.Count() })
                    .OrderByDescending(x => x.slots)
                    .ToList();
                return SuccessResult(utilization, "Classroom utilization computed");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error computing classroom utilization");
                return ErrorResult("Failed to compute classroom utilization");
            }
        }

        [HttpGet("analytics/assignment-statistics")]
        [RequirePermission(Permission.AnalyticsView, requireRead: true)]
        public async Task<IActionResult> GetAssignmentStatistics([FromQuery] int? classId)
        {
            try
            {
                var total = classId.HasValue 
                    ? await _assignmentRepository.CountAsync(a => a.ClassId == classId.Value)
                    : await _assignmentRepository.CountAsync();
                    
                var overdue = classId.HasValue
                    ? await _assignmentRepository.CountAsync(a => a.ClassId == classId.Value && a.DueDate < DateTime.UtcNow && a.IsActive)
                    : await _assignmentRepository.CountAsync(a => a.DueDate < DateTime.UtcNow && a.IsActive);
                    
                var active = classId.HasValue
                    ? await _assignmentRepository.CountAsync(a => a.ClassId == classId.Value && a.IsActive)
                    : await _assignmentRepository.CountAsync(a => a.IsActive);
                    
                var stats = new
                {
                    total = total,
                    overdue = overdue,
                    active = active
                };
                return SuccessResult(stats, "Assignment statistics computed");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error computing assignment statistics");
                return ErrorResult("Failed to compute assignment statistics");
            }
        }

    [HttpGet("academic-years/current")]
    [RequirePermission(Permission.DashboardView, requireRead: true)]
        public async Task<IActionResult> GetCurrentAcademicYear()
        {
            try
            {
                LogAction("Getting current academic year");
                var currentYear = await _academicYearRepository.GetCurrentAcademicYearAsync();
                return SuccessResult(currentYear, "Current academic year retrieved successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error retrieving current academic year");
                return ErrorResult("Failed to retrieve current academic year");
            }
        }

        // Grading System
    [HttpGet("grading-schemes")]
    [RequirePermission(Permission.SubjectsView, requireRead: true)]
        public async Task<IActionResult> GetGradingSchemes()
        {
            try
            {
                LogAction("Getting grading schemes");
                var schemes = await _gradingSchemeRepository.GetActiveGradingSchemesAsync();
                return SuccessResult(schemes, "Grading schemes retrieved successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error retrieving grading schemes");
                return ErrorResult("Failed to retrieve grading schemes");
            }
        }

        [HttpPost("grading-schemes")]
        [RequirePermission(Permission.SubjectsManage, requireWrite: true)]
        public async Task<IActionResult> CreateGradingScheme([FromBody] GradingScheme scheme)
        {
            try
            {
                var created = await _gradingSchemeRepository.AddAsync(scheme);
                return CreatedResult(created, "Grading scheme created successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error creating grading scheme");
                return ErrorResult("Failed to create grading scheme");
            }
        }

        [HttpPut("grading-schemes/{id}")]
        [RequirePermission(Permission.SubjectsManage, requireWrite: true)]
        public async Task<IActionResult> UpdateGradingScheme(int id, [FromBody] GradingScheme scheme)
        {
            try
            {
                if (id != scheme.Id) return BadRequest("ID mismatch");
                await _gradingSchemeRepository.UpdateAsync(scheme);
                return SuccessResult("Grading scheme updated successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error updating grading scheme {id}");
                return ErrorResult("Failed to update grading scheme");
            }
        }

        [HttpDelete("grading-schemes/{id}")]
        [RequirePermission(Permission.SubjectsManage, requireDelete: true)]
        public async Task<IActionResult> DeleteGradingScheme(int id)
        {
            try
            {
                await _gradingSchemeRepository.DeleteAsync(id);
                return SuccessResult("Grading scheme deleted successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error deleting grading scheme {id}");
                return ErrorResult("Failed to delete grading scheme");
            }
        }

        [HttpGet("assignments/filtered")]
        [RequirePermission(Permission.ClassesView, requireRead: true)]
        public async Task<IActionResult> GetFilteredAssignments([FromQuery] Dictionary<string, string> filters)
        {
            try
            {
                // GetAllAsync() leaves the Class/Subject/Section navigations null,
                // so className/subjectName below mapped to empty strings and the
                // frontend list columns came out blank.
                var all = await _assignmentRepository.GetAllWithNavigationsAsync();
                var query = all.AsQueryable();
                if (filters.TryGetValue("classId", out var classIdStr) && int.TryParse(classIdStr, out var cId))
                    query = query.Where(a => a.ClassId == cId);
                if (filters.TryGetValue("subjectId", out var subjectIdStr) && int.TryParse(subjectIdStr, out var sId))
                    query = query.Where(a => a.SubjectId == sId);
                if (filters.TryGetValue("status", out var status) && !string.IsNullOrWhiteSpace(status))
                {
                    // Map simple status to IsActive flag as a placeholder (active/inactive)
                    if (string.Equals(status, "active", StringComparison.OrdinalIgnoreCase))
                        query = query.Where(a => a.IsActive);
                    else if (string.Equals(status, "inactive", StringComparison.OrdinalIgnoreCase))
                        query = query.Where(a => !a.IsActive);
                }

                var list = query.ToList();
                var dtos = list.Select(a => new
                {
                    id = a.Id,
                    assignmentId = a.Id,
                    classId = a.ClassId,
                    subjectId = a.SubjectId,
                    sectionId = a.SectionId,
                    title = a.Title,
                    description = a.Description,
                    assignedDate = a.AssignedDate,
                    dueDate = a.DueDate,
                    maxMarks = a.MaxMarks,
                    isActive = a.IsActive,
                    className = a.Class?.Name ?? string.Empty,
                    subjectName = a.Subject?.Name ?? string.Empty,
                    sectionName = a.Section?.Name ?? string.Empty
                });
                return SuccessResult(dtos, "Filtered assignments retrieved");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error filtering assignments");
                return ErrorResult("Failed to filter assignments");
            }
        }

        

        

        [HttpPost("bulk-actions")]
        [RequirePermission(Permission.ClassesEdit, requireWrite: true)]
        public IActionResult PerformBulkActions([FromBody] object payload)
        {
            try
            {
                return SuccessResult(new { status = "ok" }, "Bulk action processed (placeholder)");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error performing bulk action");
                return ErrorResult("Failed to perform bulk action");
            }
        }

        // Exam Results
    [HttpGet("results")]
    [RequirePermission(Permission.ResultsView, requireRead: true)]
        public async Task<IActionResult> GetResults([FromQuery] int? studentId, [FromQuery] string? examType, [FromQuery] int? subjectId)
        {
            try
            {
                LogAction("Getting exam results", new { studentId, examType, subjectId });
                var results = await _examResultRepository.GetResultsByFiltersAsync(studentId, examType, subjectId);
                // Project to a flat DTO — navigations are lazy/absent and full entities
                // can create JSON reference cycles (same pattern as the Parents endpoint).
                var dtos = results.Select(r => new
                {
                    id = r.Id,
                    studentId = r.StudentId,
                    subjectId = r.SubjectId,
                    studentName = r.Student != null ? $"{r.Student.FirstName} {r.Student.LastName}".Trim() : string.Empty,
                    subjectName = r.Subject != null ? r.Subject.Name : string.Empty,
                    examType = r.ExamType,
                    examDate = r.ExamDate,
                    marksObtained = r.MarksObtained,
                    totalMarks = r.TotalMarks,
                    grade = r.Grade,
                    remarks = r.Remarks
                });
                return SuccessResult(dtos, "Exam results retrieved successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error retrieving exam results");
                return ErrorResult("Failed to retrieve exam results");
            }
        }

        [HttpPost("results")]
        [RequirePermission(Permission.ResultsEnter, requireWrite: true)]
        public async Task<IActionResult> CreateResult([FromBody] ExamResult result)
        {
            try
            {
                LogAction("Creating exam result");
                var created = await _examResultRepository.AddAsync(result);
                return CreatedResult(created, "Exam result created successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error creating exam result");
                return ErrorResult("Failed to create exam result");
            }
        }

        [HttpPut("results/{id}")]
        [RequirePermission(Permission.ResultsEnter, requireWrite: true)]
        public async Task<IActionResult> UpdateResult(int id, [FromBody] ExamResult result)
        {
            try
            {
                if (id != result.Id) return BadRequest("ID mismatch");
                LogAction($"Updating exam result {id}");
                await _examResultRepository.UpdateAsync(result);
                return SuccessResult("Exam result updated successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error updating exam result {id}");
                return ErrorResult("Failed to update exam result");
            }
        }

        [HttpDelete("results/{id}")]
        [RequirePermission(Permission.ResultsEnter, requireDelete: true)]
        public async Task<IActionResult> DeleteResult(int id)
        {
            try
            {
                LogAction($"Deleting exam result {id}");
                await _examResultRepository.DeleteAsync(id);
                return SuccessResult("Exam result deleted successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error deleting exam result {id}");
                return ErrorResult("Failed to delete exam result");
            }
        }

    [HttpGet("grading-schemes/calculate/{marks}")]
    [RequirePermission(Permission.ResultsView, requireRead: true)]
        public async Task<IActionResult> CalculateGrade(decimal marks)
        {
            try
            {
                LogAction($"Calculating grade for marks: {marks}");
                var grade = await _gradingSchemeRepository.GetGradeByMarksAsync(marks);
                return SuccessResult(grade, "Grade calculated successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error calculating grade for marks: {marks}");
                return ErrorResult("Failed to calculate grade");
            }
        }

        // Utility Methods
        // Removed local GetCurrentUserId to avoid hiding BaseApiController method
    }

    // DTOs
    public class GradeSubmissionRequest
    {
        public decimal MarksObtained { get; set; }
        public string Feedback { get; set; } = string.Empty;
    }

    public class GradeAssignmentRequest
    {
        public int StudentId { get; set; }
        public decimal MarksObtained { get; set; }
        public string? Feedback { get; set; }
    }
}