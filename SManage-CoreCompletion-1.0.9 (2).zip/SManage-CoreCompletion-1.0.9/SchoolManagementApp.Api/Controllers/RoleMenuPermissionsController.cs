using SchoolManagementApp.ApplicationCore.Common.Enums;
using SchoolManagementApp.ApplicationCore.Entities;
using SchoolManagementApp.ApplicationCore.Services.Interfaces;
using SchoolManagementApp.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;

namespace SchoolManagementApp.Api.Controllers
{
    /// <summary>
    /// CRUD API for fine-grained per-role menu visibility control.
    /// These overrides are applied AFTER the default permission-based filtering.
    /// </summary>
    [ApiController]
    [Route("api/role-menu-permissions")]
    [Authorize(Roles = "Administrator,SuperAdmin")]
    public class RoleMenuPermissionsController : BaseApiController
    {
        private readonly IMenuService _menuService;
        private readonly ApplicationDbContext _context;

        public RoleMenuPermissionsController(
            IMenuService menuService,
            ApplicationDbContext context,
            ILogger<RoleMenuPermissionsController> logger)
            : base(logger)
        {
            _menuService = menuService;
            _context = context;
        }

        /// <summary>
        /// Get all menu visibility overrides for a specific role.
        /// Returns the full list of menu items with their CanView status.
        /// </summary>
        [HttpGet("{role}")]
        public async Task<ActionResult<List<RoleMenuPermissionDto>>> GetRoleMenuPermissions(UserRole role)
        {
            try
            {
                LogAction($"Getting menu permissions for role: {role}");

                // Get all menu items for context, scoped to the current tenant so
                // legacy/orphaned rows and other tenants' menus never appear here.
                // Inactive items are INCLUDED so the page can act as the global
                // on/off control for them (they carry an IsActive=false flag).
                int tenantId = _context.CurrentTenantId;
                var allMenuItems = await _context.MenuItems
                    .Where(m => !m.IsDeleted && m.TenantId == tenantId)
                    .OrderBy(m => m.DisplayOrder)
                    .ToListAsync();

                // Get existing permissions for this role
                var existingPermissions = await _menuService.GetRoleMenuPermissionsAsync(role);
                var permLookup = existingPermissions.ToDictionary(p => p.MenuItemId, p => p.CanView);

                // Build response with all menu items and their CanView status
                var result = allMenuItems.Select(mi => new RoleMenuPermissionDto
                {
                    MenuItemId = mi.Id,
                    MenuItemLabel = mi.Label,
                    MenuItemRoute = mi.Route,
                    ParentId = mi.ParentId,
                    DisplayOrder = mi.DisplayOrder,
                    Category = mi.Category,
                    HasOverride = permLookup.ContainsKey(mi.Id),
                    CanView = permLookup.TryGetValue(mi.Id, out var cv) ? cv : true,
                    IsActive = mi.IsActive
                }).ToList();

                return Ok(result);
            }
            catch (Exception ex)
            {
                return BadRequest($"Error retrieving role menu permissions: {ex.Message}");
            }
        }

        /// <summary>
        /// Get only the menu items that are explicitly overridden for a role
        /// (i.e., those that have a RoleMenuPermission record).
        /// </summary>
        [HttpGet("{role}/overrides")]
        public async Task<ActionResult<List<RoleMenuPermissionDto>>> GetRoleMenuPermissionOverrides(UserRole role)
        {
            try
            {
                LogAction($"Getting menu permission overrides for role: {role}");

                var overrides = await _menuService.GetRoleMenuPermissionsAsync(role);
                if (!overrides.Any())
                {
                    return Ok(new List<RoleMenuPermissionDto>());
                }

                var menuIds = overrides.Select(o => o.MenuItemId).ToList();
                var menuItems = await _context.MenuItems
                    .Where(m => menuIds.Contains(m.Id))
                    .ToListAsync();

                var result = overrides.Select(o =>
                {
                    var mi = menuItems.FirstOrDefault(m => m.Id == o.MenuItemId);
                    return new RoleMenuPermissionDto
                    {
                        MenuItemId = o.MenuItemId,
                        MenuItemLabel = mi?.Label ?? $"Menu #{o.MenuItemId}",
                        MenuItemRoute = mi?.Route ?? "",
                        ParentId = mi?.ParentId,
                        DisplayOrder = mi?.DisplayOrder ?? 0,
                        Category = mi?.Category ?? "",
                        HasOverride = true,
                        CanView = o.CanView
                    };
                }).ToList();

                return Ok(result);
            }
            catch (Exception ex)
            {
                return BadRequest($"Error retrieving role menu permission overrides: {ex.Message}");
            }
        }

        /// <summary>
        /// Global (all-roles) on/off switch for a menu item.
        /// Deactivated menus are hidden from every role and cannot be re-enabled
        /// by per-role overrides — use this to take a menu out of service entirely.
        /// </summary>
        [HttpPost("menu-item/{menuItemId}/active")]
        public async Task<ActionResult> SetMenuItemActive(int menuItemId, [FromBody] SetMenuItemActiveRequest request)
        {
            try
            {
                LogAction($"Setting menu item {menuItemId} IsActive = {request.IsActive}");

                var menuItem = await _context.MenuItems.FindAsync(menuItemId);
                if (menuItem == null)
                {
                    return NotFound($"Menu item with ID {menuItemId} not found");
                }

                // Tenant guard: cannot modify another tenant's menus
                if (menuItem.TenantId != _context.CurrentTenantId)
                {
                    return NotFound($"Menu item {menuItemId} does not belong to the current tenant");
                }

                menuItem.IsActive = request.IsActive;
                menuItem.UpdatedOn = DateTime.UtcNow;
                await _context.SaveChangesAsync();

                return Ok(new
                {
                    success = true,
                    message = $"Menu '{menuItem.Label}' is now {(request.IsActive ? "enabled" : "disabled")} for all roles"
                });
            }
            catch (Exception ex)
            {
                return BadRequest($"Error setting menu item active state: {ex.Message}");
            }
        }

        /// <summary>
        /// Set a single menu permission for a role.
        /// </summary>
        [HttpPost("{role}")]
        public async Task<ActionResult> SetRoleMenuPermission(
            UserRole role,
            [FromBody] SetRoleMenuPermissionRequest request)
        {
            try
            {
                LogAction($"Setting menu permission for role: {role}, menu: {request.MenuItemId}");

                // Validate menu item exists
                var menuItem = await _context.MenuItems.FindAsync(request.MenuItemId);
                if (menuItem == null)
                {
                    return NotFound($"Menu item with ID {request.MenuItemId} not found");
                }

                await _menuService.SetRoleMenuPermissionAsync(role, request.MenuItemId, request.CanView);

                return Ok(new { success = true, message = $"Menu visibility for '{menuItem.Label}' set to {(request.CanView ? "visible" : "hidden")} for role {role}" });
            }
            catch (Exception ex)
            {
                return BadRequest($"Error setting role menu permission: {ex.Message}");
            }
        }

        /// <summary>
        /// Bulk-set menu permissions for a role.
        /// Use this to configure the entire menu visibility for a role in one call.
        /// </summary>
        [HttpPost("{role}/bulk")]
        public async Task<ActionResult> BulkSetRoleMenuPermissions(
            UserRole role,
            [FromBody] BulkSetRoleMenuPermissionsRequest request)
        {
            try
            {
                LogAction($"Bulk setting menu permissions for role: {role}, count: {request.Permissions?.Count ?? 0}");

                if (request.Permissions == null || !request.Permissions.Any())
                {
                    return BadRequest("No permissions provided");
                }

                // Validate all menu items exist
                var menuIds = request.Permissions.Select(p => p.MenuItemId).ToList();
                var existingMenuItems = await _context.MenuItems
                    .Where(m => menuIds.Contains(m.Id))
                    .ToListAsync();

                if (existingMenuItems.Count != menuIds.Count)
                {
                    var foundIds = existingMenuItems.Select(m => m.Id).ToHashSet();
                    var missingIds = menuIds.Where(id => !foundIds.Contains(id));
                    return NotFound($"Menu items not found: {string.Join(", ", missingIds)}");
                }

                var permData = request.Permissions
                    .Select(p => (p.MenuItemId, p.CanView))
                    .ToList();

                await _menuService.BulkSetRoleMenuPermissionsAsync(role, permData);

                return Ok(new
                {
                    success = true,
                    message = $"Bulk updated {permData.Count} menu permissions for role {role}"
                });
            }
            catch (Exception ex)
            {
                return BadRequest($"Error bulk setting role menu permissions: {ex.Message}");
            }
        }

        /// <summary>
        /// Delete a single menu permission override for a role.
        /// After deletion, the menu item reverts to default permission-based filtering.
        /// </summary>
        [HttpDelete("{role}/{menuItemId}")]
        public async Task<ActionResult> DeleteRoleMenuPermission(UserRole role, int menuItemId)
        {
            try
            {
                LogAction($"Deleting menu permission override for role: {role}, menu: {menuItemId}");

                var existing = await _context.RoleMenuPermissions
                    .FirstOrDefaultAsync(rmp => rmp.Role == role && rmp.MenuItemId == menuItemId);

                if (existing == null)
                {
                    return NotFound($"No menu permission override found for role {role} and menu item {menuItemId}");
                }

                _context.RoleMenuPermissions.Remove(existing);
                await _context.SaveChangesAsync();

                return Ok(new { success = true, message = $"Menu permission override deleted for role {role}" });
            }
            catch (Exception ex)
            {
                return BadRequest($"Error deleting role menu permission: {ex.Message}");
            }
        }

        /// <summary>
        /// Reset all menu permissions for a role to default (no overrides).
        /// After reset, the role reverts to default permission-based filtering.
        /// </summary>
        [HttpPost("{role}/reset")]
        public async Task<ActionResult> ResetRoleMenuPermissions(UserRole role)
        {
            try
            {
                LogAction($"Resetting all menu permissions for role: {role}");

                await _menuService.DeleteRoleMenuPermissionsByRoleAsync(role);

                return Ok(new { success = true, message = $"All menu permissions reset for role {role}. Reverted to default permission-based filtering." });
            }
            catch (Exception ex)
            {
                return BadRequest($"Error resetting role menu permissions: {ex.Message}");
            }
        }

        /// <summary>
        /// Preview what menus a role would see after applying both
        /// permission-based filtering and RoleMenuPermissions overrides.
        /// Useful for testing before committing changes.
        /// </summary>
        [HttpGet("{role}/preview")]
        public async Task<ActionResult<List<MenuItemDto>>> PreviewMenuForRole(UserRole role, [FromQuery] string? category = null)
        {
            try
            {
                LogAction($"Previewing menu for role: {role}, category: {category}");

                // Use current tenant to get the baseline permission-based menus
                // then apply the RoleMenuPermissions override
                var tenantId = _context.CurrentTenantId;
                var menuItems = await _menuService.GetMenuItemsAsync(category, tenantId);
                var menuTree = _menuService.BuildMenuTree(menuItems);

                // Apply the RoleMenuPermissions override
                var filteredMenu = await _menuService.FilterMenuByRoleMenuPermissionsAsync(menuTree, role);

                // Map to DTOs (using empty permissions list since we're just previewing visibility)
                var menuDtos = _menuService.MapMenuItemsToDto(filteredMenu, new List<string>());

                return Ok(menuDtos);
            }
            catch (Exception ex)
            {
                return BadRequest($"Error previewing menu for role: {ex.Message}");
            }
        }
    }

    // ──────────────────────────────────────────────────────
    // Request / Response DTOs
    // ──────────────────────────────────────────────────────

    public class RoleMenuPermissionDto
    {
        public int MenuItemId { get; set; }
        public string MenuItemLabel { get; set; } = string.Empty;
        public string MenuItemRoute { get; set; } = string.Empty;
        public int? ParentId { get; set; }
        public int DisplayOrder { get; set; }
        public string Category { get; set; } = string.Empty;
        /// <summary>True if an explicit override record exists for this role+menu combination.</summary>
        public bool HasOverride { get; set; }
        /// <summary>Whether the menu item is visible. Default true when no override exists.</summary>
        public bool CanView { get; set; } = true;
        /// <summary>
        /// Global (all-roles) switch from MenuItems.IsActive. Inactive items are hidden
        /// from every role regardless of per-role overrides and are shown as disabled
        /// on the Permission Management page.
        /// </summary>
        public bool IsActive { get; set; } = true;
    }

    public class SetMenuItemActiveRequest
    {
        public bool IsActive { get; set; }
    }

    public class SetRoleMenuPermissionRequest
    {
        public int MenuItemId { get; set; }
        public bool CanView { get; set; } = true;
    }

    public class BulkSetRoleMenuPermissionsRequest
    {
        public List<SetRoleMenuPermissionRequest> Permissions { get; set; } = new();
    }
}
