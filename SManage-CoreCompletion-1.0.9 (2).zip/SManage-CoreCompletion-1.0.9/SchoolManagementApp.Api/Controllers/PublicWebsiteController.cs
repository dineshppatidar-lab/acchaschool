using Microsoft.AspNetCore.RateLimiting;
using SchoolManagementApp.ApplicationCore.Entities;
using SchoolManagementApp.ApplicationCore.Services.Interfaces;

namespace SchoolManagementApp.Api.Controllers
{
    /// <summary>
    /// Anonymous, host-resolved public School Website API. The tenant comes ONLY
    /// from the bound host (same semantics as /api/auth/resolve-domain) — never
    /// from client input — so nothing here can read another school's content or
    /// any draft/private data. Draft content is never returned; only the
    /// currently-published website parts of the ACTIVE bound tenant.
    /// </summary>
    [ApiController]
    [AllowAnonymous]
    [Route("api/public-website")]
    [Produces("application/json")]
    public class PublicWebsiteController : ControllerBase
    {
        private readonly IPublicWebsiteContentService _publicCms;
        private readonly ILogger<PublicWebsiteController> _logger;

        public PublicWebsiteController(IPublicWebsiteContentService publicCms, ILogger<PublicWebsiteController> logger)
        {
            _publicCms = publicCms;
            _logger = logger;
        }

        private string Host => HttpContext.Request.Host.Value ?? string.Empty;

        // ── Branding / meta ──────────────────────────────────────────────────
        /// <summary>Branding + website settings for the bound host. Unknown host → matched:false (neutral holding page), no content.</summary>
        [HttpGet("branding")]
        public async Task<IActionResult> GetBranding()
        {
            try
            {
                var (tenant, settings) = await _publicCms.GetBrandingAsync(Host);
                return Ok(new PublicBrandingResponse
                {
                    Matched = true,
                    Active = tenant.IsActive,
                    TenantCode = tenant.TenantCode,
                    TenantName = tenant.Name,
                    LogoUrl = tenant.LogoUrl,
                    Tagline = settings.Tagline,
                    WebsiteTitle = settings.WebsiteTitle,
                    MetaDescription = settings.MetaDescription,
                    PrimaryColor = settings.PrimaryColor,
                    SecondaryColor = settings.SecondaryColor,
                    FaviconUrl = settings.FaviconUrl,
                    Address = settings.Address,
                    ContactPhone = settings.ContactPhone,
                    ContactEmail = settings.ContactEmail,
                    MapEmbedUrl = settings.MapEmbedUrl,
                    SocialLinksJson = settings.SocialLinksJson,
                    AboutHtml = settings.AboutHtml,
                    AdmissionsHtml = settings.AdmissionsHtml,
                    IsWebsitePublished = settings.IsPublished,
                    IsEnquiryEnabled = settings.EnquiriesEnabled
                });
            }
            catch (InvalidOperationException)
            {
                // Unknown/unbound host — neutral "not matched", no content.
                return Ok(PublicBrandingResponse.NotMatched);
            }
        }

        [HttpGet("enquiry-status")]
        public async Task<IActionResult> EnquiryStatus()
        {
            var enabled = await _publicCms.IsEnquiryEnabledAsync(Host);
            return Ok(new { enabled });
        }

        // ── Events ───────────────────────────────────────────────────────────
        [HttpGet("events")]
        public async Task<IActionResult> GetEvents([FromQuery] int? take = null)
        {
            var events = await _publicCms.ListPublishedEventsAsync(Host, take ?? 0);
            return Ok(events);
        }

        [HttpGet("events/{slug}")]
        public async Task<IActionResult> GetEvent([FromRoute] string slug)
        {
            var evt = await _publicCms.GetPublishedEventAsync(Host, slug);
            return evt == null ? NotFound() : Ok(evt);
        }

        // ── Gallery albums ───────────────────────────────────────────────────
        [HttpGet("albums")]
        public async Task<IActionResult> GetAlbums([FromQuery] int? take = null)
        {
            var albums = await _publicCms.ListPublishedAlbumsAsync(Host, take ?? 0);
            return Ok(albums);
        }

        [HttpGet("albums/{slug}")]
        public async Task<IActionResult> GetAlbum([FromRoute] string slug)
        {
            var (album, media) = await _publicCms.GetPublishedAlbumAsync(Host, slug);
            return Ok(new { album = (object?)album, media });
        }

        // ── Achievements ─────────────────────────────────────────────────────
        [HttpGet("achievements")]
        public async Task<IActionResult> GetAchievements([FromQuery] bool? homepageOnly = null)
        {
            var items = await _publicCms.ListPublishedAchievementsAsync(Host, homepageOnly);
            return Ok(items);
        }

        // ── News / articles ──────────────────────────────────────────────────
        [HttpGet("articles")]
        public async Task<IActionResult> GetArticles(
            [FromQuery] string? category = null, [FromQuery] string? search = null,
            [FromQuery] int page = 1, [FromQuery] int pageSize = 10)
        {
            var articles = await _publicCms.ListPublishedArticlesAsync(Host, category, search, page, pageSize);
            return Ok(articles);
        }

        [HttpGet("articles/{slug}")]
        public async Task<IActionResult> GetArticle([FromRoute] string slug)
        {
            var article = await _publicCms.GetPublishedArticleAsync(Host, slug);
            return article == null ? NotFound() : Ok(article);
        }

        // ── Promo campaigns ──────────────────────────────────────────────────
        [HttpGet("campaigns")]
        public async Task<IActionResult> GetCampaigns([FromQuery] string? position = null)
        {
            if (!string.IsNullOrWhiteSpace(position) &&
                !Enum.TryParse<WebsiteCampaignPosition>(position.Trim(), ignoreCase: true, out _))
            {
                return BadRequest(new { message = $"Unknown campaign position '{position}'" });
            }

            var parsed = string.IsNullOrWhiteSpace(position)
                ? (WebsiteCampaignPosition?)null
                : Enum.Parse<WebsiteCampaignPosition>(position.Trim(), ignoreCase: true);

            var campaigns = await _publicCms.GetActiveCampaignsAsync(Host, parsed, DateTime.UtcNow);
            return Ok(campaigns);
        }

        // ── Public admission enquiry ─────────────────────────────────────────
        [HttpPost("enquiry")]
        [EnableRateLimiting("PublicRegistration")]
        public async Task<IActionResult> SubmitEnquiry([FromBody] SchoolWebsiteEnquiry enquiry)
        {
            if (enquiry == null || string.IsNullOrWhiteSpace(enquiry.ParentName) || string.IsNullOrWhiteSpace(enquiry.Phone))
                return BadRequest(new { message = "Parent name and phone are required." });

            try
            {
                await _publicCms.CreateEnquiryAsync(Host, enquiry);
                _logger.LogInformation("Public website enquiry accepted for host {Host}", Host);
                return Ok(new { message = "Thank you — your enquiry has been received." });
            }
            catch (InvalidOperationException ex)
            {
                return StatusCode(403, new { message = ex.Message });
            }
        }

        // ── Counts (for the public site footer/home) ─────────────────────────
        [HttpGet("counts")]
        public async Task<IActionResult> GetCounts()
        {
            var c = await _publicCms.GetPublicCountsAsync(Host);
            return Ok(new { publishedAlbums = c.PublishedAlbums, publishedEvents = c.PublishedEvents, publishedArticles = c.PublishedArticles, achievements = c.Achievements });
        }

        public class PublicBrandingResponse
        {
            public bool Matched { get; set; }
            public bool Active { get; set; }
            public string? TenantCode { get; set; }
            public string? TenantName { get; set; }
            public string? LogoUrl { get; set; }
            public string? Tagline { get; set; }
            public string? WebsiteTitle { get; set; }
            public string? MetaDescription { get; set; }
            public string? PrimaryColor { get; set; }
            public string? SecondaryColor { get; set; }
            public string? FaviconUrl { get; set; }
            public string? Address { get; set; }
            public string? ContactPhone { get; set; }
            public string? ContactEmail { get; set; }
            public string? MapEmbedUrl { get; set; }
            public string? SocialLinksJson { get; set; }
            public string? AboutHtml { get; set; }
            public string? AdmissionsHtml { get; set; }
            public bool IsWebsitePublished { get; set; } = true;
            public bool IsEnquiryEnabled { get; set; } = true;

            public static PublicBrandingResponse NotMatched { get; } = new() { Matched = false, Active = false, IsWebsitePublished = false, IsEnquiryEnabled = false };
        }
    }
}
