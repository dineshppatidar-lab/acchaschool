using SchoolManagementApp.ApplicationCore.Communication.Interfaces;
using IEmailService = SchoolManagementApp.ApplicationCore.Communication.Interfaces.IEmailService;
using IRealtimeNotificationService = SchoolManagementApp.ApplicationCore.Communication.Interfaces.IRealtimeNotificationService;
using ISmsService = SchoolManagementApp.ApplicationCore.Communication.Interfaces.ISmsService;

namespace SchoolManagementApp.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class CommunicationController : BaseApiController
    {
        private readonly IMessageRepository _messageRepository;
        private readonly IMessageRecipientRepository _messageRecipientRepository;
        private readonly IMessageReplyRepository _messageReplyRepository;
        private readonly IAnnouncementRepository _announcementRepository;
        private readonly IEventRepository _eventRepository;
        private readonly IParentTeacherMeetingRepository _meetingRepository;
        private readonly IRealtimeNotificationService _notificationService;
        private readonly IEmailService _emailService;
        private readonly ISmsService _smsService;

        public CommunicationController(
            IMessageRepository messageRepository,
            IMessageRecipientRepository messageRecipientRepository,
            IMessageReplyRepository messageReplyRepository,
            IAnnouncementRepository announcementRepository,
            IEventRepository eventRepository,
            IParentTeacherMeetingRepository meetingRepository,
            IRealtimeNotificationService notificationService,
            IEmailService emailService,
            ISmsService smsService,
            ILogger<CommunicationController> logger) : base(logger)
        {
            _messageRepository = messageRepository;
            _messageRecipientRepository = messageRecipientRepository;
            _messageReplyRepository = messageReplyRepository;
            _announcementRepository = announcementRepository;
            _eventRepository = eventRepository;
            _meetingRepository = meetingRepository;
            _notificationService = notificationService;
            _emailService = emailService;
            _smsService = smsService;
        }

        // Message Management
        [HttpGet("messages")]
        [RequirePermission(Permission.MessagesView, requireRead: true)]
        public async Task<IActionResult> GetMessages(
            [FromQuery] string? messageType = null, 
            [FromQuery] string? status = null, 
            [FromQuery] string? search = null,
            [FromQuery] string? userType = null, 
            [FromQuery] int? userId = null)
        {
            try
            {
                var currentUserId = userId ?? GetCurrentUserIdInt();
                var currentUserType = userType ?? GetCurrentUserType();

                LogAction($"Getting messages for user {currentUserId} ({currentUserType}) - Filter: {messageType}/{status}/{search}");
                
                var messages = await _messageRepository.GetMessagesWithFiltersAsync(
                    currentUserId, 
                    currentUserType, 
                    messageType, 
                    status, 
                    search);

                return SuccessResult(messages, "Messages retrieved successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error retrieving messages");
                return ErrorResult("Failed to retrieve messages");
            }
        }

        [HttpGet("messages/unread")]
        [RequirePermission(Permission.MessagesView, requireRead: true)]
        public async Task<IActionResult> GetUnreadMessages([FromQuery] string? userType = null, [FromQuery] int? userId = null)
        {
            try
            {
                var currentUserId = userId ?? GetCurrentUserIdInt();
                var currentUserType = userType ?? GetCurrentUserType();

                LogAction($"Getting unread messages for user {currentUserId}");
                var messages = await _messageRepository.GetUnreadMessagesAsync(currentUserId, currentUserType);
                return SuccessResult(messages, "Unread messages retrieved successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error retrieving unread messages");
                return ErrorResult("Failed to retrieve unread messages");
            }
        }

        [HttpGet("messages/stats")]
        [RequirePermission(Permission.MessagesView, requireRead: true)]
        public async Task<IActionResult> GetMessageStats([FromQuery] string? userType = null, [FromQuery] int? userId = null)
        {
            try
            {
                var currentUserId = userId ?? GetCurrentUserIdInt();
                var currentUserType = userType ?? GetCurrentUserType();

                var stats = await _messageRepository.GetMessageStatsAsync(currentUserId, currentUserType);
                return SuccessResult(stats, "Message stats retrieved successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error retrieving message stats");
                return ErrorResult("Failed to retrieve message stats");
            }
        }

        [HttpPost("messages")]
        [RequirePermission(Permission.MessagesSend, requireWrite: true)]
        public async Task<IActionResult> SendMessage([FromBody] SendMessageRequest request)
        {
            try
            {
                LogAction($"Sending message: {request.Subject}");

                var message = new Message
                {
                    Subject = request.Subject,
                    Content = request.Content,
                    SenderId = request.SenderId,
                    SenderType = request.SenderType,
                    SentDate = DateTime.UtcNow,
                    Priority = request.Priority,
                    Type = request.Type,
                    AttachmentPath = request.AttachmentPath
                };

                var result = await _messageRepository.AddAsync(message);

                // Add recipients
                var recipients = request.Recipients.Select(r => new MessageRecipient
                {
                    MessageId = result.Id,
                    RecipientId = r.RecipientId,
                    RecipientType = r.RecipientType,
                    IsRead = false,
                    TenantId = result.TenantId
                }).ToList();

                await _messageRecipientRepository.AddRangeAsync(recipients);

                // Send real-time notifications in bulk
                var recipientIds = request.Recipients.Select(r => r.RecipientId.ToString()).ToList();
                if (recipientIds.Any())
                {
                    await _notificationService.SendNotificationAsync("message", $"New message: {request.Subject}", recipientIds);
                }

                // Send email notifications if enabled
                if (request.SendEmailNotification)
                {
                    var emails = request.Recipients.Select(r => r.Email).Where(e => !string.IsNullOrEmpty(e)).ToList();
                    if (emails.Any())
                    {
                        //await _emailService.SendBulkEmailAsync(
                        //    emails,
                        //    $"New Message: {request.Subject}",
                        //    $"You have received a new message from {request.SenderName}. Please check your school portal for details.",
                        //    false);
                    }
                }

                return CreatedResult(result, "Message sent successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error sending message");
                return ErrorResult("Failed to send message");
            }
        }

        [HttpPut("messages/{id}")]
        [RequirePermission(Permission.MessagesSend, requireWrite: true)]
        public async Task<IActionResult> UpdateMessage(int id, [FromBody] SendMessageRequest request)
        {
            try
            {
                LogAction($"Updating message: {id}");

                var message = await _messageRepository.GetByIdAsync(id);
                if (message == null)
                {
                    return NotFound("Message not found");
                }

                message.Subject = request.Subject;
                message.Content = request.Content;
                message.Priority = request.Priority;
                message.Type = request.Type;
                message.AttachmentPath = request.AttachmentPath;

                await _messageRepository.UpdateAsync(message);

                // Update recipients if provided
                if (request.Recipients != null && request.Recipients.Any())
                {
                    // For simplicity in this implementation, we'll replace recipients
                    var existingRecipients = await _messageRecipientRepository.FindAsync(r => r.MessageId == id);
                    await _messageRecipientRepository.DeleteRangeAsync(existingRecipients);

                    var newRecipients = request.Recipients.Select(r => new MessageRecipient
                    {
                        MessageId = id,
                        RecipientId = r.RecipientId,
                        RecipientType = r.RecipientType,
                        IsRead = false,
                        TenantId = message.TenantId
                    }).ToList();

                    await _messageRecipientRepository.AddRangeAsync(newRecipients);
                }

                return SuccessResult(message, "Message updated successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error updating message {id}");
                return ErrorResult("Failed to update message");
            }
        }

        [HttpPost("messages/{messageId}/reply")]
        [RequirePermission(Permission.MessagesSend, requireWrite: true)]
        public async Task<IActionResult> ReplyToMessage(int messageId, [FromBody] ReplyMessageRequest request)
        {
            try
            {
                LogAction($"Replying to message {messageId}");

                var reply = new MessageReply
                {
                    OriginalMessageId = messageId,
                    Content = request.Content,
                    SenderId = request.SenderId,
                    SenderType = request.SenderType,
                    SentDate = DateTime.UtcNow,
                    AttachmentPath = request.AttachmentPath
                };

                var result = await _messageReplyRepository.AddAsync(reply);

                // Notify original sender
                var originalMessage = await _messageRepository.GetByIdAsync(messageId);
                await _notificationService.SendNotificationAsync(
                    "message-reply",
                    $"Reply received for: {originalMessage.Subject}",
                    new[] { originalMessage.SenderId.ToString() });

                return CreatedResult(result, "Reply sent successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error replying to message {messageId}");
                return ErrorResult("Failed to send reply");
            }
        }

        [HttpPut("messages/{messageId}/read")]
        [RequirePermission(Permission.MessagesView, requireWrite: true)]
        public async Task<IActionResult> MarkMessageAsRead(int messageId, [FromQuery] int? userId = null)
        {
            try
            {
                var currentUserId = userId ?? GetCurrentUserIdInt();
                LogAction($"Marking message {messageId} as read for user {currentUserId}");
                await _messageRepository.MarkMessageAsReadAsync(messageId, currentUserId);
                return SuccessResult("Message marked as read");
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error marking message {messageId} as read");
                return ErrorResult("Failed to mark message as read");
            }
        }

        // Announcements
        [HttpGet("announcements")]
        [RequirePermission(Permission.MessagesView, requireRead: true)]
        public async Task<IActionResult> GetAnnouncements([FromQuery] string? targetType = null, [FromQuery] int? targetId = null)
        {
            try
            {
                var effectiveTargetType = targetType ?? GetCurrentUserType();
                var effectiveTargetId = targetId ?? GetCurrentUserIdInt();

                LogAction($"Getting announcements - Target: {effectiveTargetType}/{effectiveTargetId}");
                
                IEnumerable<Announcement> announcements;
                if (!string.IsNullOrEmpty(effectiveTargetType))
                {
                    announcements = await _announcementRepository.GetAnnouncementsByTargetAsync(effectiveTargetType, effectiveTargetId);
                }
                else
                {
                    announcements = await _announcementRepository.GetActiveAnnouncementsAsync();
                }
                
                return SuccessResult(announcements, "Announcements retrieved successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error retrieving announcements");
                return ErrorResult("Failed to retrieve announcements");
            }
        }

        [HttpPost("announcements")]
        [RequirePermission(Permission.AnnouncementsSend, requireWrite: true)]
        public async Task<IActionResult> CreateAnnouncement([FromBody] CreateAnnouncementRequest request)
        {
            try
            {
                LogAction($"Creating announcement: {request.Title}");

                var announcement = new Announcement
                {
                    Title = request.Title,
                    Content = request.Content,
                    Type = request.Type,
                    Priority = request.Priority,
                    CreatedOn = DateTime.UtcNow,
                    ValidFrom = request.ValidFrom,
                    ValidTo = request.ValidTo,
                    CreatedBy = GetCurrentUserIdInt().ToString(),
                    IsActive = true,
                    TargetAudience = request.TargetAudience,
                    AttachmentPath = request.AttachmentPath
                };

                var result = await _announcementRepository.AddAsync(announcement);

                // Send notifications based on target audience
                switch (request.TargetAudience.ToLower())
                {
                    case "all":
                        await _notificationService.SendNotificationToGroupAsync("all-users", "announcement", request.Title);
                        break;
                    case "students":
                        await _notificationService.SendNotificationToGroupAsync("students", "announcement", request.Title);
                        break;
                    case "parents":
                        await _notificationService.SendNotificationToGroupAsync("parents", "announcement", request.Title);
                        break;
                    case "staff":
                        await _notificationService.SendNotificationToGroupAsync("staff", "announcement", request.Title);
                        break;
                }

                return CreatedResult(result, "Announcement created successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error creating announcement");
                return ErrorResult("Failed to create announcement");
            }
        }

        [HttpPut("announcements/{id}")]
        [RequirePermission(Permission.AnnouncementsSend, requireWrite: true)]
        public async Task<IActionResult> UpdateAnnouncement(int id, [FromBody] CreateAnnouncementRequest request)
        {
            try
            {
                LogAction($"Updating announcement: {id}");

                var announcement = await _announcementRepository.GetByIdAsync(id);
                if (announcement == null)
                {
                    return NotFound("Announcement not found");
                }

                announcement.Title = request.Title;
                announcement.Content = request.Content;
                announcement.Type = request.Type;
                announcement.Priority = request.Priority;
                announcement.ValidFrom = request.ValidFrom;
                announcement.ValidTo = request.ValidTo;
                announcement.TargetAudience = request.TargetAudience;
                announcement.AttachmentPath = request.AttachmentPath;
                announcement.UpdatedOn = DateTime.UtcNow;
                announcement.UpdatedBy = GetCurrentUserIdInt().ToString();

                await _announcementRepository.UpdateAsync(announcement);

                return SuccessResult(announcement, "Announcement updated successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error updating announcement {id}");
                return ErrorResult("Failed to update announcement");
            }
        }

        // Events & Calendar
        [HttpGet("events")]
        [RequirePermission(Permission.MessagesView, requireRead: true)]
        public async Task<IActionResult> GetEvents([FromQuery] DateTime? startDate = null, [FromQuery] DateTime? endDate = null, [FromQuery] int upcoming = 30)
        {
            try
            {
                LogAction($"Getting events - Date range: {startDate} to {endDate}");
                
                IEnumerable<Event> events;
                if (startDate.HasValue || endDate.HasValue)
                {
                    // If either date is provided, use the range path
                    // Use safer dates for SQL Server compatibility
                    var start = startDate ?? new DateTime(1900, 1, 1);
                    var end = endDate ?? new DateTime(2100, 12, 31);

                    LogAction($"Filtering events by range: {start} to {end}");
                    var eventList = (await _eventRepository.GetEventsByDateRangeAsync(start, end)).ToList();
                    LogAction($"Retrieved {eventList.Count} events by range");
                    events = eventList;
                }
                else
                {
                    // For general view (default), include upcoming public events AND all events the user is participating in
                    var currentUserId = GetCurrentUserIdInt();
                    var currentUserType = GetCurrentUserType();

                    LogAction($"Getting upcoming events (next {upcoming} days) for user {currentUserId}");
                    var upcomingEvents = await _eventRepository.GetUpcomingEventsAsync(upcoming);
                    var myEvents = await _eventRepository.GetEventsByParticipantAsync(currentUserId, currentUserType);

                    // Merge and filter
                    var mergedEvents = upcomingEvents.UnionBy(myEvents, e => e.Id).OrderBy(e => e.StartDate).ToList();
                    LogAction($"Retrieved {mergedEvents.Count} total events for general view");
                    events = mergedEvents;
                }                
                return SuccessResult(events, "Events retrieved successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error retrieving events");
                return ErrorResult("Failed to retrieve events");
            }
        }

        [HttpGet("events/{id}")]
        [RequirePermission(Permission.EventsManage, requireRead: true)]
        public async Task<IActionResult> GetEventDetails(int id)
        {
            try
            {
                LogAction($"Getting event details for {id}");
                var eventDetails = await _eventRepository.GetEventWithParticipantsAsync(id);
                
                if (eventDetails == null)
                {
                    return NotFound("Event not found");
                }
                
                return SuccessResult(eventDetails, "Event details retrieved successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error retrieving event details for {id}");
                return ErrorResult("Failed to retrieve event details");
            }
        }

        [HttpPost("events")]
        [RequirePermission(Permission.EventsManage, requireWrite: true)]
        public async Task<IActionResult> CreateEvent([FromBody] CreateEventRequest request)
        {
            try
            {
                LogAction($"Creating event: {request.Title}");

                var eventItem = new Event
                {
                    Title = request.Title,
                    Description = request.Description,
                    Type = request.Type,
                    StartDate = request.StartDate,
                    EndDate = request.EndDate,
                    Location = request.Location,
                    OrganizedBy = GetCurrentUserIdInt(),
                    IsAllDay = request.IsAllDay,
                    IsPublic = request.IsPublic,
                    Color = request.Color,
                    Status = EventStatus.Scheduled,
                    MaxParticipants = request.MaxParticipants,
                    CreatedOn = DateTime.UtcNow
                };

                var result = await _eventRepository.AddAsync(eventItem);

                // Send notifications to relevant groups
                if (request.IsPublic)
                {
                    await _notificationService.SendNotificationToGroupAsync(
                        "all-users",
                        $"New event: {request.Title} on {request.StartDate:MMM dd}",
                        "event");
                }

                return CreatedResult(result, "Event created successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error creating event");
                return ErrorResult("Failed to create event");
            }
        }

        [HttpPut("events/{id}")]
        [RequirePermission(Permission.EventsManage, requireWrite: true)]
        public async Task<IActionResult> UpdateEvent(int id, [FromBody] CreateEventRequest request)
        {
            try
            {
                LogAction($"Updating event: {id}");

                var eventItem = await _eventRepository.GetByIdAsync(id);
                if (eventItem == null)
                {
                    return NotFound("Event not found");
                }

                eventItem.Title = request.Title;
                eventItem.Description = request.Description;
                eventItem.Type = request.Type;
                eventItem.StartDate = request.StartDate;
                eventItem.EndDate = request.EndDate;
                eventItem.Location = request.Location;
                eventItem.IsAllDay = request.IsAllDay;
                eventItem.IsPublic = request.IsPublic;
                eventItem.Color = request.Color;
                eventItem.MaxParticipants = request.MaxParticipants;
                eventItem.UpdatedOn = DateTime.UtcNow;
                eventItem.UpdatedBy = GetCurrentUserIdInt().ToString();

                await _eventRepository.UpdateAsync(eventItem);

                return SuccessResult(eventItem, "Event updated successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error updating event {id}");
                return ErrorResult("Failed to update event");
            }
        }

        // Issue #20: the Events UI has had a Cancel action whose service call
        // (PUT events/{id}/cancel) had no backend endpoint — the request 404'd
        // and the status never persisted.
        [HttpPut("events/{id}/cancel")]
        [RequirePermission(Permission.EventsManage, requireWrite: true)]
        public async Task<IActionResult> CancelEvent(int id)
        {
            try
            {
                LogAction($"Cancelling event: {id}");

                var eventItem = await _eventRepository.GetByIdAsync(id);
                if (eventItem == null)
                {
                    return NotFound("Event not found");
                }

                if (eventItem.Status == EventStatus.Cancelled)
                {
                    return SuccessResult(eventItem, "Event is already cancelled");
                }

                eventItem.Status = EventStatus.Cancelled;
                eventItem.UpdatedOn = DateTime.UtcNow;
                eventItem.UpdatedBy = GetCurrentUserIdInt().ToString();

                await _eventRepository.UpdateAsync(eventItem);

                return SuccessResult(eventItem, "Event cancelled successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error cancelling event {id}");
                return ErrorResult("Failed to cancel event");
            }
        }

        // Audit issue #28: the Angular service exposes deleteEvent() → DELETE
        // events/{id}, but no endpoint existed — deletes failed. Soft delete
        // keeps historical data and relies on the tenant query filter.
        [HttpDelete("events/{id}")]
        [RequirePermission(Permission.EventsManage, requireWrite: true)]
        public async Task<IActionResult> DeleteEvent(int id)
        {
            try
            {
                LogAction($"Deleting event: {id}");

                var eventItem = await _eventRepository.GetByIdAsync(id);
                if (eventItem == null)
                {
                    return NotFound("Event not found");
                }

                eventItem.IsDeleted = true;
                eventItem.UpdatedOn = DateTime.UtcNow;
                eventItem.UpdatedBy = GetCurrentUserIdInt().ToString();

                await _eventRepository.UpdateAsync(eventItem);

                return SuccessResult("Event deleted successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, $"Error deleting event {id}");
                return ErrorResult("Failed to delete event");
            }
        }

        // Parent-Teacher Meetings
        [HttpGet("meetings")]
        [RequirePermission(Permission.MessagesView, requireRead: true)]
        public async Task<IActionResult> GetMeetings([FromQuery] string? userType = null, [FromQuery] int? userId = null)
        {
            try
            {
                var currentUserId = userId ?? GetCurrentUserIdInt();
                var currentUserType = userType ?? GetCurrentUserType();

                LogAction($"Getting meetings for {currentUserType} {currentUserId}");
                
                IEnumerable<ParentTeacherMeeting> meetings;
                if (currentUserType.ToLower() == "parent")
                {
                    meetings = await _meetingRepository.GetMeetingsByParentAsync(currentUserId);
                }
                else
                {
                    meetings = await _meetingRepository.GetMeetingsByStaffAsync(currentUserId);
                }
                
                return SuccessResult(meetings, "Meetings retrieved successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error retrieving meetings");
                return ErrorResult("Failed to retrieve meetings");
            }
        }

        [HttpPost("meetings")]
        [RequirePermission(Permission.MessagesSend, requireWrite: true)]
        public async Task<IActionResult> ScheduleMeeting([FromBody] ScheduleMeetingRequest request)
        {
            try
            {
                LogAction($"Scheduling meeting between parent {request.ParentId} and staff {request.StaffId}");

                var meeting = new ParentTeacherMeeting
                {
                    ParentId = request.ParentId,
                    StaffId = request.StaffId,
                    StudentId = request.StudentId,
                    ScheduledDate = request.ScheduledDate,
                    StartTime = request.StartTime,
                    EndTime = request.EndTime,
                    Purpose = request.Purpose,
                    Status = MeetingStatus.Scheduled,
                    Location = request.Location,
                    CreatedOn = DateTime.UtcNow,
                    CreatedBy = GetCurrentUserIdInt().ToString()
                };

                var result = await _meetingRepository.AddAsync(meeting);

                // Notify both parties
                await _notificationService.SendNotificationAsync(
                    "meeting",
                    $"Meeting scheduled for {request.ScheduledDate:MMM dd} at {request.StartTime}",
                    new[] { request.ParentId.ToString() });

                await _notificationService.SendNotificationAsync(
                    "meeting",
                    $"Parent meeting scheduled for {request.ScheduledDate:MMM dd} at {request.StartTime}",
                    new[] { request.StaffId.ToString() });

                return CreatedResult(result, "Meeting scheduled successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error scheduling meeting");
                return ErrorResult("Failed to schedule meeting");
            }
        }

        // Bulk Communication
        [HttpPost("bulk/notification")]
        [RequirePermission(Permission.AnnouncementsSend, requireWrite: true)]
        public async Task<IActionResult> SendBulkNotification([FromBody] BulkNotificationRequest request)
        {
            try
            {
                LogAction($"Sending bulk notification to {request.UserIds?.Count() ?? 0} users");

                if (request.UserIds != null && request.UserIds.Any())
                {
                    await _notificationService.SendBulkNotificationAsync(
                        request.Type,
                        request.Message,
                        request.UserIds);
                }
                else
                {
                    await _notificationService.SendNotificationToGroupAsync(
                        request.GroupName ?? "all-users",
                        request.Message,
                        request.Type);
                }

                return SuccessResult("Bulk notification sent successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error sending bulk notification");
                return ErrorResult("Failed to send bulk notification");
            }
        }

        [HttpPost("bulk/email")]
        [RequirePermission(Permission.AnnouncementsSend, requireWrite: true)]
        public async Task<IActionResult> SendBulkEmail([FromBody] BulkEmailRequest request)
        {
            try
            {
                LogAction($"Sending bulk email to {request.Recipients?.Count() ?? 0} recipients");

                if (request.Recipients != null && request.Recipients.Any())
                {
                    await _emailService.SendBulkEmailAsync(request.Recipients, request.Subject, request.Body, request.IsHtml);
                }

                return SuccessResult("Bulk email sent successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error sending bulk email");
                return ErrorResult("Failed to send bulk email");
            }
        }

        [HttpPost("bulk/sms")]
        [RequirePermission(Permission.AnnouncementsSend, requireWrite: true)]
        public async Task<IActionResult> SendBulkSMS([FromBody] BulkSMSRequest request)
        {
            try
            {
                LogAction($"Sending bulk SMS to {request.PhoneNumbers?.Count() ?? 0} recipients");

                if (request.PhoneNumbers != null && request.PhoneNumbers.Any())
                {
                    await _smsService.SendBulkSMSAsync(request.PhoneNumbers, request.Message);
                }

                return SuccessResult("Bulk SMS sent successfully");
            }
            catch (Exception ex)
            {
                LogError(ex, "Error sending bulk SMS");
                return ErrorResult("Failed to send bulk SMS");
            }
        }

        private string GetCurrentUserType()
        {
            var roles = GetCurrentUserRoles();
            if (roles.Contains("Admin") || roles.Contains("SuperAdmin") || roles.Contains("Principal") || roles.Contains("Teacher") || roles.Contains("Staff"))
                return "Staff";
            if (roles.Contains("Parent"))
                return "Parent";
            if (roles.Contains("Student"))
                return "Student";
            
            return "Staff"; // Default
        }
    }

    // Request DTOs
    public class SendMessageRequest
    {
        public string Subject { get; set; } = string.Empty;
        public string Content { get; set; } = string.Empty;
        public int SenderId { get; set; }
        public string SenderType { get; set; } = string.Empty;
        public string SenderName { get; set; } = string.Empty;
        public MessagePriority Priority { get; set; } = MessagePriority.Normal;
        public MessageType Type { get; set; } = MessageType.General;
        public string AttachmentPath { get; set; } = string.Empty;
        public bool SendEmailNotification { get; set; }
        public List<RecipientInfo> Recipients { get; set; } = new List<RecipientInfo>();
    }

    public class RecipientInfo
    {
        public int RecipientId { get; set; }
        public string RecipientType { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
    }

    public class ReplyMessageRequest
    {
        public string Content { get; set; } = string.Empty;
        public int SenderId { get; set; }
        public string SenderType { get; set; } = string.Empty;
        public string AttachmentPath { get; set; } = string.Empty;
    }

    public class CreateAnnouncementRequest
    {
        public string Title { get; set; } = string.Empty;
        public string Content { get; set; } = string.Empty;
        public AnnouncementType Type { get; set; }
        public AnnouncementPriority Priority { get; set; } = AnnouncementPriority.Normal;
        public DateTime? ValidFrom { get; set; }
        public DateTime? ValidTo { get; set; }
        public string TargetAudience { get; set; } = "All";
        public string AttachmentPath { get; set; } = string.Empty;
    }

    public class CreateEventRequest
    {
        public string Title { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public EventType Type { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string Location { get; set; } = string.Empty;
        public bool IsAllDay { get; set; }
        public bool IsPublic { get; set; } = true;
        public string Color { get; set; } = "#1976d2";
        public int? MaxParticipants { get; set; }
    }

    public class ScheduleMeetingRequest
    {
        public int ParentId { get; set; }
        public int StaffId { get; set; }
        public int StudentId { get; set; }
        public DateTime ScheduledDate { get; set; }
        public TimeSpan StartTime { get; set; }
        public TimeSpan EndTime { get; set; }
        public string Purpose { get; set; } = string.Empty;
        public string Location { get; set; } = string.Empty;
    }

    public class BulkNotificationRequest
    {
        public IEnumerable<int>? UserIds { get; set; }
        public string? GroupName { get; set; }
        public string Message { get; set; } = string.Empty;
        public string Type { get; set; } = "info";
    }

    public class BulkEmailRequest
    {
        public IEnumerable<string> Recipients { get; set; } = new List<string>();
        public string Subject { get; set; } = string.Empty;
        public string Body { get; set; } = string.Empty;
        public bool IsHtml { get; set; } = true;
    }

    public class BulkSMSRequest
    {
        public IEnumerable<string> PhoneNumbers { get; set; } = new List<string>();
        public string Message { get; set; } = string.Empty;
    }
}