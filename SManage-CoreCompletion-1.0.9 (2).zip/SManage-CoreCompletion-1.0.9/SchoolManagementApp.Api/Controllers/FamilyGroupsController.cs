
namespace SchoolManagementApp.Api.Controllers
{
    [ApiController]
    [Authorize]
    [Route("api/fees")]
    public class FamilyGroupsController : BaseApiController
    {
        private readonly ApplicationDbContext _db;
        private readonly ILogger<FamilyGroupsController> _logger;

        public FamilyGroupsController(ApplicationDbContext db, ILogger<FamilyGroupsController> logger) : base(logger)
        {
            _db = db;
            _logger = logger;
        }

        [HttpGet("families")]
        [RequirePermission(Permission.FeesView, requireRead: true)]
        public async Task<IActionResult> GetFamilies()
        {
            try
            {
                var families = await _db.Set<FamilyGroup>()
                    .OrderBy(f => f.FamilyName)
                    .Select(f => new { id = f.Id, familyName = f.FamilyName })
                    .ToListAsync();

                return SuccessResult(families, "Families retrieved");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving families");
                return ErrorResult("Error retrieving families");
            }
        }

        [HttpPost("families")]
        [RequirePermission(Permission.FeesCollect, requireWrite: true)]
        public async Task<IActionResult> CreateFamily([FromBody] CreateFamilyRequest request)
        {
            if (string.IsNullOrWhiteSpace(request.FamilyName))
            return ValidationErrorResult(new List<string> { "FamilyName is required" });

            try
            {
                var family = new FamilyGroup
                {
                    FamilyName = request.FamilyName,
                    CreatedOn = DateTime.UtcNow,
                    CreatedBy = GetCurrentUserId() ?? "system",
                    TenantId = _db.CurrentTenantId
                };

                _db.Set<FamilyGroup>().Add(family);
                await _db.SaveChangesAsync();

                // Optionally add members
                if (request.MemberStudentIds != null && request.MemberStudentIds.Any())
                {
                    foreach (var sid in request.MemberStudentIds)
                    {
                        var member = new FamilyGroupMember
                        {
                            FamilyGroupId = family.Id,
                            StudentId = sid,
                            CreatedOn = DateTime.UtcNow,
                            CreatedBy = GetCurrentUserId() ?? "system",
                            TenantId = _db.CurrentTenantId
                        };
                        _db.Set<FamilyGroupMember>().Add(member);
                    }
                    await _db.SaveChangesAsync();
                }

                return CreatedResult(new { id = family.Id, familyName = family.FamilyName }, "Family created");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating family");
                return ErrorResult("Error creating family");
            }
        }

        public class CreateFamilyRequest
        {
            public string FamilyName { get; set; } = string.Empty;
            public List<int>? MemberStudentIds { get; set; }
        }
    }
}
