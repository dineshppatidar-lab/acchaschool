using System.Text;
using FluentValidation.AspNetCore;
using FluentValidation;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.IdentityModel.Tokens;
using SchoolManagementApp.Api.Common;
using SchoolManagementApp.Api.Extensions;
using SchoolManagementApp.Api.Validators;
using SchoolManagementApp.ApplicationCore.Interfaces;
using SchoolManagementApp.Infrastructure;
using SchoolManagementApp.SignalR;
using System.Threading.RateLimiting;

namespace SchoolManagementApp.Api
{
    /// <summary>
    /// Orchestrates all DI service registration.
    /// Follows CorporateFleet's Startup pattern — Program.cs stays minimal.
    /// </summary>
    public class Startup
    {
        public IConfiguration Configuration { get; }
        public IHostEnvironment Environment { get; }

        public Startup(IConfiguration configuration, IHostEnvironment environment)
        {
            Configuration = configuration;
            Environment = environment;
        }

        public void ConfigureServices(IServiceCollection services)
        {
            // ── Core MVC ───────────────────────────────────────────────
            services.AddControllers()
                .AddJsonOptions(options =>
                {
                    options.JsonSerializerOptions.PropertyNamingPolicy = System.Text.Json.JsonNamingPolicy.CamelCase;
                    options.JsonSerializerOptions.Converters.Add(new System.Text.Json.Serialization.JsonStringEnumConverter());
                    options.JsonSerializerOptions.ReferenceHandler = System.Text.Json.Serialization.ReferenceHandler.IgnoreCycles;
                })
                .ConfigureApiBehaviorOptions(options =>
                {
                    options.InvalidModelStateResponseFactory = context =>
                        new ValidationFailedResult(context.ModelState);
                });

            // ── Swagger ────────────────────────────────────────────────
            services.AddAppSwagger();

            // ── Data Protection (production IIS) ──────────────────────
            // Shared IIS hosting gives the app pool no user profile / HKLM registry,
            // so without this the keys live in an ephemeral in-memory repository:
            // auth cookies and antiforgery tokens break on every app restart.
            // Persisting under the content root survives restarts and deployments
            // of the app root.
            var dataProtectionKeysPath = Path.Combine(Environment.ContentRootPath, "App_Data", "DataProtection-Keys");
            Directory.CreateDirectory(dataProtectionKeysPath);
            services.AddDataProtection()
                .PersistKeysToFileSystem(new DirectoryInfo(dataProtectionKeysPath))
                .SetApplicationName("SchoolManagementApp");

            // ── HTTPS redirect: intentionally DISABLED ─────────────────
            // Plain HTTP must be accepted in all environments (local dev AND the
            // production host), so neither the redirect middleware nor its port
            // pinning is registered. TLS termination, if desired, belongs to the
            // reverse proxy in front of the app — not to forced app-level redirects.
            // services.AddHttpsRedirection(options => options.HttpsPort = 443);

            // ── CORS ──────────────────────────────────────────────────
            services.AddAppCors(Configuration);

            // ── SignalR ───────────────────────────────────────────────
            services.AddSignalRServices();

            // ── Infrastructure (DbContext, Repositories, Services) ─────
            services.ConfigureInfrastructureServices(Configuration);

            // ── Health checks (docs/critical-issues/11-startup-migrations.md) ──────
            // /health → 200 when the DB is reachable; feeds CI deploy smoke tests.
            services.AddHealthChecks()
                .AddDbContextCheck<ApplicationDbContext>("database");

            // ── Api-specific services
            services.AddHttpContextAccessor();
            services.AddScoped<ITenantProvider, SchoolManagementApp.Api.Services.Implementation.TenantProvider>();
            services.AddScoped<SchoolManagementApp.Api.Services.StudentImportService>();

            // ── Auth ──────────────────────────────────────────────────
            services.AddAuthentication(options =>
            {
                options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultScheme = JwtBearerDefaults.AuthenticationScheme;
            })
            .AddJwtBearer(JwtBearerDefaults.AuthenticationScheme, options =>
            {
                var jwtKey = Configuration["Jwt:Key"];
                if (string.IsNullOrWhiteSpace(jwtKey))
                    throw new InvalidOperationException("Jwt:Key is not configured in appsettings.");

                options.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateIssuer = true,
                    ValidateAudience = true,
                    ValidateLifetime = true,
                    ValidateIssuerSigningKey = true,
                    ValidIssuer = Configuration["Jwt:Issuer"],
                    ValidAudience = Configuration["Jwt:Audience"],
                    IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtKey))
                };

                // Preserve custom claim types (tenant_id, etc.) without mapping
                options.MapInboundClaims = false;

                // SignalR websockets cannot set an Authorization header — clients pass
                // the access token via access_token query param on /activityHub.
                options.Events = new JwtBearerEvents
                {
                    OnMessageReceived = context =>
                    {
                        var accessToken = context.Request.Query["access_token"];
                        var path = context.HttpContext.Request.Path;
                        if (!string.IsNullOrEmpty(accessToken) && path.StartsWithSegments("/activityHub"))
                        {
                            context.Token = accessToken;
                        }
                        return Task.CompletedTask;
                    }
                };
            });

            // ── FluentValidation ──────────────────────────────────────
            services.AddFluentValidationAutoValidation();
            services.AddValidatorsFromAssembly(typeof(LoginRequestValidator).Assembly);

            // ── Rate Limiting ─────────────────────────────────────────
            // Docs: docs/critical-issues/06-rate-limiting-gaps.md
            //
            // Layers:
            //  1. Global limiter — EVERY request. Token bucket keyed by tenant_id
            //     (authenticated) or IP (anonymous). Absorbs bursts, throttles scrapers.
            //  2. "Auth" policy — login / forgot / reset / refresh. 5/min per IP,
            //     sliding window so distributed attempts can't align to window edges.
            //  3. "Export" policy — CSV/XLSX blob endpoints. 5/min per user; these do
            //     heavy DB reads and produce large payloads.
            //  4. "PublicRegistration" policy — tenant registration. 5/min per IP (kept).
            //
            // Policies are enforced via [EnableRateLimiting] attributes; the global
            // limiter composes with (adds on top of) any policy limit.
            services.AddRateLimiter(options =>
            {
                options.RejectionStatusCode = StatusCodes.Status429TooManyRequests;

                options.OnRejected = async (context, cancellationToken) =>
                {
                    context.HttpContext.Response.StatusCode = StatusCodes.Status429TooManyRequests;
                    if (context.Lease.TryGetMetadata(MetadataName.RetryAfter, out var retryAfter))
                    {
                        context.HttpContext.Response.Headers.RetryAfter = ((int)retryAfter.TotalSeconds).ToString();
                    }
                    await context.HttpContext.Response.WriteAsJsonAsync(new
                    {
                        message = "Too many requests. Please slow down and try again shortly."
                    }, cancellationToken);
                };

                // ── 1. Global limiter (all requests) ──────────────────
                options.GlobalLimiter = PartitionedRateLimiter.Create<HttpContext, string>(httpContext =>
                {
                    // Key by tenant when authenticated (survives IP rotation for
                    // authenticated scraping), by IP otherwise (offices behind one NAT
                    // share a bucket, but the burst budget absorbs normal office use).
                    var tenantClaim = httpContext.User?.FindFirst("tenant_id")?.Value
                                      ?? httpContext.User?.FindFirst("tenantid")?.Value;
                    var partitionKey = !string.IsNullOrEmpty(tenantClaim)
                        ? $"tenant:{tenantClaim}"
                        : $"ip:{httpContext.Connection.RemoteIpAddress?.ToString() ?? "anon"}";

                    return RateLimitPartition.GetTokenBucketLimiter(
                        partitionKey,
                        _ => new TokenBucketRateLimiterOptions
                        {
                            TokenLimit = 300,               // burst capacity
                            TokensPerPeriod = 100,          // refill size
                            ReplenishmentPeriod = TimeSpan.FromSeconds(10), // refill rate
                            QueueLimit = 0,
                            QueueProcessingOrder = QueueProcessingOrder.OldestFirst
                        });
                });

                // ── 2. Auth policy (login/forgot/reset/refresh) ──────
                options.AddPolicy("Auth", httpContext =>
                    RateLimitPartition.GetSlidingWindowLimiter(
                        partitionKey: $"auth:{httpContext.Connection.RemoteIpAddress?.ToString() ?? "anon"}",
                        factory: _ => new SlidingWindowRateLimiterOptions
                        {
                            PermitLimit = 5,
                            Window = TimeSpan.FromMinutes(1),
                            SegmentsPerWindow = 6, // 10s segments — smooths window-edge bursts
                            QueueProcessingOrder = QueueProcessingOrder.OldestFirst,
                            QueueLimit = 0
                        }));

                // ── 3. Export policy (CSV/XLSX blob endpoints) ───────
                options.AddPolicy("Export", httpContext =>
                {
                    // Key by user id when authenticated (each staff member gets their own
                    // budget); fall back to tenant/IP for anything unexpected.
                    var userId = httpContext.User?.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value
                                 ?? httpContext.User?.FindFirst("sub")?.Value;
                    var tenantClaim = httpContext.User?.FindFirst("tenant_id")?.Value;
                    var partitionKey = !string.IsNullOrEmpty(userId)
                        ? $"export:user:{userId}"
                        : $"export:{tenantClaim ?? httpContext.Connection.RemoteIpAddress?.ToString() ?? "anon"}";

                    return RateLimitPartition.GetFixedWindowLimiter(
                        partitionKey,
                        _ => new FixedWindowRateLimiterOptions
                        {
                            PermitLimit = 5,
                            Window = TimeSpan.FromMinutes(1),
                            QueueProcessingOrder = QueueProcessingOrder.OldestFirst,
                            QueueLimit = 0
                        });
                });

                // ── 4. PublicRegistration policy (kept from before) ──
                options.AddPolicy("PublicRegistration", httpContext =>
                    RateLimitPartition.GetFixedWindowLimiter(
                        partitionKey: httpContext.Connection.RemoteIpAddress?.ToString() ?? "anon",
                        factory: _ => new FixedWindowRateLimiterOptions
                        {
                            PermitLimit = 5,
                            Window = TimeSpan.FromMinutes(1),
                            QueueProcessingOrder = QueueProcessingOrder.OldestFirst,
                            QueueLimit = 2
                        }));
            });
        }

        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            // ── Middleware pipeline ────────────────────────────────────
            app.UseApiMiddleware();

            // Security headers + CSP on HTML responses
            // (docs/critical-issues/16-jwt-in-localstorage.md Option 2).
            app.UseMiddleware<Middleware.SecurityHeadersMiddleware>();

            // HTTPS redirect: intentionally disabled — the app must serve plain
            // HTTP (e.g. http://localhost:5013, and the production host) without
            // 307-redirecting to https. See the note in ConfigureServices above.

            // ── Static files (Angular frontend) ────────────────────────
            var webRootPath = env.WebRootPath ?? Path.Combine(env.ContentRootPath, "wwwroot");
            var fileProvider = new Microsoft.Extensions.FileProviders.PhysicalFileProvider(webRootPath);
            app.UseDefaultFiles(new DefaultFilesOptions { FileProvider = fileProvider });
            app.UseStaticFiles(new StaticFileOptions { FileProvider = fileProvider });

            app.UseRouting();
            app.UseAppCors();
            app.UseAppSwagger();
            app.UseAuthentication();
            app.UseAuthorization();

            // TenantResolutionMiddleware MUST run AFTER UseAuthentication
            // so that context.User claims (including tenant_id from JWT) are available.
            // It was originally in UseApiMiddleware which runs before authentication.
            app.UseMiddleware<SchoolManagementApp.Api.Middleware.TenantResolutionMiddleware>();
            app.UseRateLimiter();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
                endpoints.MapHub<SchoolManagementApp.SignalR.Hubs.ActivityHub>("/activityHub");
                endpoints.MapHealthChecks("/health");
                endpoints.MapFallbackToFile("index.html", new StaticFileOptions
                {
                    FileProvider = new Microsoft.Extensions.FileProviders.PhysicalFileProvider(webRootPath)
                });
            });
        }
    }
}
