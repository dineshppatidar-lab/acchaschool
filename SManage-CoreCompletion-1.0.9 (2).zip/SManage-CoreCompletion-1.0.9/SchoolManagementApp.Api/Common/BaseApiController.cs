using System.Net;
using System.Reflection;
using Microsoft.Extensions.DependencyInjection;

namespace SchoolManagementApp.Api.Common
{
    /// <summary>
    /// Base controller with common functionality for all API controllers
    /// </summary>
    [ApiController]
    [Route("api/[controller]")]
    [Produces("application/json")]
    public abstract class BaseApiController : ControllerBase
    {
        protected readonly ILogger _logger;

        protected BaseApiController(ILogger logger)
        {
            _logger = logger;
        }

        /// <summary>
        /// Returns a standardized success response with data
        /// </summary>
        protected ActionResult<ApiResponse<T>> SuccessResponse<T>(T data, string message = "Operation successful")
        {
            var response = ApiResponse<T>.SuccessResult(data, message);
            return Ok(response);
        }

        /// <summary>
        /// Returns a standardized success response without data
        /// </summary>
        protected ActionResult<ApiResponse> SuccessResponse(string message = "Operation successful")
        {
            var response = ApiResponse.SuccessResult(message);
            return Ok(response);
        }

        /// <summary>
        /// Returns a standardized paginated success response
        /// </summary>
        protected ActionResult<PaginatedApiResponse<T>> PaginatedSuccessResponse<T>(
            IEnumerable<T> data, 
            int totalRecords, 
            int page, 
            int pageSize, 
            string message = "Data retrieved successfully")
        {
            var response = PaginatedApiResponse<T>.SuccessResult(data, totalRecords, page, pageSize, message);
            return Ok(response);
        }

        /// <summary>
        /// Returns a standardized error response
        /// </summary>
        protected ActionResult<ApiResponse<T>> ErrorResponse<T>(string message, HttpStatusCode statusCode = HttpStatusCode.BadRequest)
        {
            var response = ApiResponse<T>.ErrorResult(message, statusCode);
            return StatusCode((int)statusCode, response);
        }

        /// <summary>
        /// Returns a standardized error response without generic type
        /// </summary>
        protected ActionResult<ApiResponse> ErrorResponse(string message, HttpStatusCode statusCode = HttpStatusCode.BadRequest)
        {
            var response = ApiResponse.ErrorResult(message, statusCode);
            return StatusCode((int)statusCode, response);
        }

        /// <summary>
        /// Returns a standardized validation error response
        /// </summary>
        protected ActionResult<ApiResponse<T>> ValidationErrorResponse<T>(List<string> errors, string message = "Validation failed")
        {
            var response = ApiResponse<T>.ValidationErrorResult(errors, message);
            return BadRequest(response);
        }

        /// <summary>
        /// Returns a standardized validation error response without generic type
        /// </summary>
        protected ActionResult<ApiResponse> ValidationErrorResponse(List<string> errors, string message = "Validation failed")
        {
            var response = ApiResponse.ValidationErrorResult(errors, message);
            return BadRequest(response);
        }

        /// <summary>
        /// Returns a standardized not found response
        /// </summary>
        protected ActionResult<ApiResponse<T>> NotFoundResponse<T>(string message = "Resource not found")
        {
            var response = ApiResponse<T>.NotFoundResult(message);
            return NotFound(response);
        }

        /// <summary>
        /// Returns a standardized not found response without generic type
        /// </summary>
        protected ActionResult<ApiResponse> NotFoundResponse(string message = "Resource not found")
        {
            var response = ApiResponse.ErrorResult(message, HttpStatusCode.NotFound);
            return NotFound(response);
        }

        /// <summary>
        /// Returns a standardized unauthorized response
        /// </summary>
        protected ActionResult<ApiResponse<T>> UnauthorizedResponse<T>(string message = "Unauthorized access")
        {
            var response = ApiResponse<T>.UnauthorizedResult(message);
            return Unauthorized(response);
        }

        /// <summary>
        /// Returns a standardized unauthorized response without generic type
        /// </summary>
        protected ActionResult<ApiResponse> UnauthorizedResponse(string message = "Unauthorized access")
        {
            var response = ApiResponse.ErrorResult(message, HttpStatusCode.Unauthorized);
            return Unauthorized(response);
        }

        /// <summary>
        /// Returns a standardized forbidden response
        /// </summary>
        protected ActionResult<ApiResponse<T>> ForbiddenResponse<T>(string message = "Access forbidden")
        {
            var response = ApiResponse<T>.ForbiddenResult(message);
            return Forbid();
        }

        /// <summary>
        /// Returns a standardized internal server error response
        /// </summary>
        protected ActionResult<ApiResponse<T>> InternalServerErrorResponse<T>(string message = "Internal server error occurred")
        {
            var response = ApiResponse<T>.InternalServerErrorResult(message);
            return StatusCode(500, response);
        }

        /// <summary>
        /// Returns a standardized paginated error response
        /// </summary>
        protected ActionResult<PaginatedApiResponse<T>> PaginatedErrorResponse<T>(string message, HttpStatusCode statusCode = HttpStatusCode.BadRequest)
        {
            var response = new PaginatedApiResponse<T>
            {
                Success = false,
                Message = message,
                StatusCode = (int)statusCode,
                Timestamp = DateTime.UtcNow,
                Errors = new Dictionary<string, string[]> { { "general", new[] { message } } },
                Data = Enumerable.Empty<T>(),
                Pagination = new PaginationMetadata()
            };
            return StatusCode((int)statusCode, response);
        }

        /// <summary>
        /// Gets the current user ID from JWT claims as an integer.
        /// Defaults to 1 for anonymous or unparseable IDs.
        /// </summary>
        protected int GetCurrentUserIdInt()
        {
            var userIdStr = GetCurrentUserId();
            return int.TryParse(userIdStr, out var id) ? id : 1;
        }

        /// <summary>
        /// Gets the current user ID from JWT claims
        /// </summary>
        protected string? GetCurrentUserId()
        {
            return User?.FindFirst("sub")?.Value ?? User?.FindFirst("id")?.Value;
        }

        /// <summary>
        /// Gets the current user name from JWT claims
        /// </summary>
        protected string? GetCurrentUserName()
        {
            return User?.FindFirst("name")?.Value ?? User?.Identity?.Name;
        }

        /// <summary>
        /// Gets the current user email from JWT claims
        /// </summary>
        protected string? GetCurrentUserEmail()
        {
            return User?.FindFirst("email")?.Value;
        }

        /// <summary>
        /// Gets the current user roles from JWT claims
        /// </summary>
        protected IEnumerable<string> GetCurrentUserRoles()
        {
            if (User == null) return Enumerable.Empty<string>();
            
            // Try both URI-based and simple 'role' claims
            var roleClaims = User.FindAll(System.Security.Claims.ClaimTypes.Role)
                .Concat(User.FindAll("role"))
                .Select(c => c.Value)
                .Distinct();
                
            return roleClaims;
        }

        /// <summary>
        /// Logs an action with user context
        /// </summary>
        protected void LogAction(string action, object? data = null)
        {
            _logger.LogInformation("Action: {Action}, User: {User}, Data: {@Data}", 
                action, GetCurrentUserName() ?? "Anonymous", data);
        }

        /// <summary>
        /// Records a security event (login success/failure/lockout, permission denied, etc.)
        /// into the queryable AuditLog table, in addition to the structured log
        /// (docs/critical-issues/13-audit-trail-gaps.md). Fire-and-forget safe: failures to
        /// write the audit row are logged but never fail the request.
        /// </summary>
        protected void AuditSecurityEvent(string action, string details, string actorName, string? ipAddress = null, int? tenantId = null)
        {
            try
            {
                var log = new AuditLog
                {
                    UserName = actorName,
                    Action = action,
                    Entity = "Authentication",
                    EntityId = actorName,
                    Details = details,
                    IpAddress = ipAddress ?? HttpContext.Connection.RemoteIpAddress?.ToString() ?? string.Empty,
                    Timestamp = DateTime.UtcNow
                };

                // Use the scoped DbContext via HttpContext.RequestServices when available;
                // falls back silently in tests/edge contexts without a request scope.
                var db = HttpContext?.RequestServices?.GetService<SchoolManagementApp.Infrastructure.Data.ApplicationDbContext>();
                if (db == null)
                {
                    _logger.LogWarning("AuditSecurityEvent skipped — no DbContext available for action {Action}", action);
                    return;
                }

                db.AuditLogs.Add(log);
                db.SaveChanges();
            }
            catch (Exception ex)
            {
                // Never let audit write failures break auth flows.
                _logger.LogError(ex, "Failed to record security audit event: {Action}", action);
            }
        }

        /// <summary>
        /// Logs an error with user context
        /// </summary>
        protected void LogError(Exception exception, string message, object? data = null)
        {
            _logger.LogError(exception, "Error: {Message}, User: {User}, Data: {@Data}", 
                message, GetCurrentUserName() ?? "Anonymous", data);
        }

        // ========== IActionResult Compatibility Methods ==========
        // These methods return IActionResult for backward compatibility with existing controllers

        /// <summary>
        /// Returns a standardized success response with data (IActionResult version)
        /// </summary>
        protected IActionResult SuccessResult<T>(T data, string message = "Operation successful")
        {
            var response = ApiResponse<T>.SuccessResult(data, message);
            return Ok(response);
        }

        /// <summary>
        /// Returns a standardized success response without data (IActionResult version)
        /// </summary>
        protected IActionResult SuccessResult(string message = "Operation successful")
        {
            var response = ApiResponse.SuccessResult(message);
            return Ok(response);
        }

        /// <summary>
        /// Returns a standardized error response (IActionResult version)
        /// </summary>
        protected IActionResult ErrorResult(string message, HttpStatusCode statusCode = HttpStatusCode.BadRequest)
        {
            var response = ApiResponse.ErrorResult(message, statusCode);
            return StatusCode((int)statusCode, response);
        }

        /// <summary>
        /// Returns a standardized unauthorized response (IActionResult version)
        /// </summary>
        protected IActionResult UnauthorizedResult(string message = "Unauthorized access")
        {
            var response = ApiResponse.ErrorResult(message, HttpStatusCode.Unauthorized);
            return Unauthorized(response);
        }

        /// <summary>
        /// Returns a standardized not found response (IActionResult version)
        /// </summary>
        protected IActionResult NotFoundResult(string message = "Resource not found")
        {
            var response = ApiResponse.ErrorResult(message, HttpStatusCode.NotFound);
            return NotFound(response);
        }

        /// <summary>
        /// Returns a response that's compatible with legacy frontend expectations
        /// Checks if the calling method has LegacyCompatibilityAttribute and returns raw data if so
        /// </summary>
        protected IActionResult CompatibleSuccessResult<T>(T data, string message = "Operation successful")
        {
            // Check if the calling method has LegacyCompatibilityAttribute
            var callingMethod = new System.Diagnostics.StackFrame(1).GetMethod();
            if (callingMethod != null && callingMethod.GetCustomAttribute<LegacyCompatibilityAttribute>() != null)
            {
                return Ok(data);
            }
            
            // Otherwise return wrapped response
            return SuccessResult(data, message);
        }

        /// <summary>
        /// Returns a response that's compatible with legacy frontend expectations (no data)
        /// </summary>
        protected IActionResult CompatibleSuccessResult(string message = "Operation successful")
        {
            // Check if the calling method has LegacyCompatibilityAttribute
            var callingMethod = new System.Diagnostics.StackFrame(1).GetMethod();
            if (callingMethod != null && callingMethod.GetCustomAttribute<LegacyCompatibilityAttribute>() != null)
            {
                return Ok(new { message });
            }
            
            // Otherwise return wrapped response
            return SuccessResult(message);
        }

        /// <summary>
        /// Returns a standardized created response with data
        /// </summary>
        protected IActionResult CreatedResult<T>(T data, string message = "Resource created successfully")
        {
            var response = ApiResponse<T>.SuccessResult(data, message);
            return StatusCode(201, response);
        }

        /// <summary>
        /// Returns a standardized created response without data
        /// </summary>
        protected IActionResult CreatedResult(string message = "Resource created successfully")
        {
            var response = ApiResponse.SuccessResult(message);
            return StatusCode(201, response);
        }

        /// <summary>
        /// Returns a validation error response
        /// </summary>
        protected IActionResult ValidationErrorResult(List<string> errors, string message = "Validation failed")
        {
            var response = ApiResponse.ErrorResult(message);
            response.Errors = new Dictionary<string, string[]> { { "general", errors.ToArray() } };
            return BadRequest(response);
        }

        /// <summary>
        /// Returns a paginated result
        /// </summary>
        protected IActionResult PaginatedResult<T>(
            IEnumerable<T> data, 
            int totalRecords, 
            int page, 
            int pageSize, 
            string message = "Data retrieved successfully")
        {
            var response = PaginatedApiResponse<T>.SuccessResult(data, totalRecords, page, pageSize, message);
            return Ok(response);
        }
    }
}