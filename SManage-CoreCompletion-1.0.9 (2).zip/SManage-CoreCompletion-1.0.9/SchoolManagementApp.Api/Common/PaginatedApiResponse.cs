namespace SchoolManagementApp.Api.Common
{
    /// <summary>
    /// Paginated API response for list operations
    /// </summary>
    /// <typeparam name="T">Type of items in the list</typeparam>
    public class PaginatedApiResponse<T> : ApiResponse<IEnumerable<T>>
    {
        public PaginationMetadata Pagination { get; set; }

        public PaginatedApiResponse()
        {
            Pagination = new PaginationMetadata();
        }

        public PaginatedApiResponse(IEnumerable<T> data, PaginationMetadata pagination, string message = "Data retrieved successfully")
            : base(data, message)
        {
            Pagination = pagination;
        }

        /// <summary>
        /// Creates a successful paginated response
        /// </summary>
        public static PaginatedApiResponse<T> SuccessResult(
            IEnumerable<T> data, 
            int totalRecords, 
            int page, 
            int pageSize, 
            string message = "Data retrieved successfully")
        {
            return new PaginatedApiResponse<T>(data, new PaginationMetadata
            {
                TotalRecords = totalRecords,
                Page = page,
                PageSize = pageSize,
                TotalPages = (int)Math.Ceiling((double)totalRecords / pageSize)
            }, message);
        }
    }

    /// <summary>
    /// Pagination metadata for paginated responses
    /// </summary>
    public class PaginationMetadata
    {
        public int TotalRecords { get; set; }
        public int Page { get; set; }
        public int PageSize { get; set; }
        public int TotalPages { get; set; }
        public bool HasPrevious => Page > 1;
        public bool HasNext => Page < TotalPages;
        public int? PreviousPage => HasPrevious ? Page - 1 : null;
        public int? NextPage => HasNext ? Page + 1 : null;
    }

    /// <summary>
    /// Request model for paginated queries
    /// </summary>
    public class PaginatedRequest
    {
        private int _page = 1;
        private int _pageSize = 20;

        public int Page
        {
            get => _page;
            set => _page = value < 1 ? 1 : value;
        }

        public int PageSize
        {
            get => _pageSize;
            set => _pageSize = value switch
            {
                < 1 => 20,
                > 100 => 100, // Maximum page size limit
                _ => value
            };
        }

        public string? Search { get; set; }
        public string? SortBy { get; set; }
        public string? SortDirection { get; set; } = "asc";

        public int Skip => (Page - 1) * PageSize;
        public int Take => PageSize;
    }
}