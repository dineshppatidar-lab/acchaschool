using Microsoft.AspNetCore.Mvc.Filters;

namespace SchoolManagementApp.Api.Common
{
    /// <summary>
    /// Attribute to mark endpoints that should maintain legacy response format for frontend compatibility
    /// </summary>
    [AttributeUsage(AttributeTargets.Method, AllowMultiple = false)]
    public class LegacyCompatibilityAttribute : Attribute, IActionFilter
    {
        public void OnActionExecuting(ActionExecutingContext context)
        {
            // Nothing to do before action executes
        }

        public void OnActionExecuted(ActionExecutedContext context)
        {
            // If the result is an ObjectResult containing an ApiResponse, unwrap it
            if (context.Result is ObjectResult objectResult && 
                objectResult.Value != null && 
                objectResult.Value.GetType().IsGenericType &&
                objectResult.Value.GetType().GetGenericTypeDefinition() == typeof(ApiResponse<>))
            {
                var apiResponse = objectResult.Value;
                var dataProperty = apiResponse.GetType().GetProperty("Data");
                if (dataProperty != null)
                {
                    var data = dataProperty.GetValue(apiResponse);
                    objectResult.Value = data;
                }
            }
        }
    }
}