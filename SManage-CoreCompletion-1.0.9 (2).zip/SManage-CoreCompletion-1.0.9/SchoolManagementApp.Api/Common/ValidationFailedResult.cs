using Microsoft.AspNetCore.Mvc.ModelBinding;

namespace SchoolManagementApp.Api.Common
{
    public class ValidationFailedResult : ObjectResult
    {
        public ValidationFailedResult(ModelStateDictionary modelState)
            : base(new ApiResponse(modelState))
        {
            StatusCode = StatusCodes.Status400BadRequest;
        }
    }
}