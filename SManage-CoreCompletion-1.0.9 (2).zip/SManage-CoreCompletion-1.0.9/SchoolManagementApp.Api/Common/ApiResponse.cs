using System.Net;
using Microsoft.AspNetCore.Mvc.ModelBinding;

namespace SchoolManagementApp.Api.Common
{
    /// <summary>
    /// Standard API response wrapper for consistent response format
    /// </summary>
    /// <typeparam name="T">Type of data being returned</typeparam>
    public class ApiResponse<T>
    {
        public bool Success { get; set; }
        public string Message { get; set; }
        public T? Data { get; set; }
        public Dictionary<string, string[]> Errors { get; set; } = new Dictionary<string, string[]>();
        public int StatusCode { get; set; }
        public DateTime Timestamp { get; set; }
        public string? RequestId { get; set; }

        public ApiResponse()
        {
            Timestamp = DateTime.UtcNow;
            Errors = new Dictionary<string, string[]>();
        }

        public ApiResponse(T data, string message = "Operation successful")
        {
            Success = true;
            Message = message;
            Data = data;
            StatusCode = (int)HttpStatusCode.OK;
            Timestamp = DateTime.UtcNow;
            Errors = new Dictionary<string, string[]>();
        }

        public ApiResponse(string message, HttpStatusCode statusCode = HttpStatusCode.BadRequest)
        {
            Success = false;
            Message = message;
            StatusCode = (int)statusCode;
            Timestamp = DateTime.UtcNow;
            Errors = new Dictionary<string, string[]>();
        }

        public ApiResponse(List<string> errors, string message = "Validation failed", HttpStatusCode statusCode = HttpStatusCode.BadRequest)
        {
            Success = false;
            Message = message;
            // Convert list to dictionary format for consistency
            Errors = new Dictionary<string, string[]> { { "general", errors.ToArray() } };
            StatusCode = (int)statusCode;
            Timestamp = DateTime.UtcNow;
        }

        public ApiResponse(ModelStateDictionary modelState)
        {
            Success = false;
            Message = "Validation failed";
            StatusCode = (int)HttpStatusCode.BadRequest;
            Timestamp = DateTime.UtcNow;
            Errors = modelState.Keys.ToDictionary(k => k, k => modelState[k]?.Errors.Select(e => e.ErrorMessage).ToArray() ?? Array.Empty<string>());
        }


        /// <summary>
        /// Creates a successful response with data
        /// </summary>
        public static ApiResponse<T> SuccessResult(T data, string message = "Operation successful")
        {
            return new ApiResponse<T>(data, message);
        }

        /// <summary>
        /// Creates a successful response without data
        /// </summary>
        public static ApiResponse<T> SuccessResult(string message = "Operation successful")
        {
            return new ApiResponse<T>
            {
                Success = true,
                Message = message,
                StatusCode = (int)HttpStatusCode.OK,
                Timestamp = DateTime.UtcNow,
                Errors = new Dictionary<string, string[]>()
            };
        }

        /// <summary>
        /// Creates an error response
        /// </summary>
        public static ApiResponse<T> ErrorResult(string message, HttpStatusCode statusCode = HttpStatusCode.BadRequest)
        {
            return new ApiResponse<T>(message, statusCode);
        }

        /// <summary>
        /// Creates a validation error response
        /// </summary>
        public static ApiResponse<T> ValidationErrorResult(List<string> errors, string message = "Validation failed")
        {
            return new ApiResponse<T>(errors, message);
        }

        /// <summary>
        /// Creates a not found error response
        /// </summary>
        public static ApiResponse<T> NotFoundResult(string message = "Resource not found")
        {
            return new ApiResponse<T>(message, HttpStatusCode.NotFound);
        }

        /// <summary>
        /// Creates an unauthorized error response
        /// </summary>
        public static ApiResponse<T> UnauthorizedResult(string message = "Unauthorized access")
        {
            return new ApiResponse<T>(message, HttpStatusCode.Unauthorized);
        }

        /// <summary>
        /// Creates a forbidden error response
        /// </summary>
        public static ApiResponse<T> ForbiddenResult(string message = "Access forbidden")
        {
            return new ApiResponse<T>(message, HttpStatusCode.Forbidden);
        }

        /// <summary>
        /// Creates an internal server error response
        /// </summary>
        public static ApiResponse<T> InternalServerErrorResult(string message = "Internal server error occurred")
        {
            return new ApiResponse<T>(message, HttpStatusCode.InternalServerError);
        }
    }

    /// <summary>
    /// Standard API response wrapper without generic type for simple operations
    /// </summary>
    public class ApiResponse : ApiResponse<object>
    {
        public ApiResponse() : base() { }
        
        public ApiResponse(string message, HttpStatusCode statusCode = HttpStatusCode.BadRequest) 
            : base(message, statusCode) { }

        public ApiResponse(List<string> errors, string message = "Validation failed", HttpStatusCode statusCode = HttpStatusCode.BadRequest)
            : base(errors, message, statusCode) { }

        public ApiResponse(ModelStateDictionary modelState) : base(modelState) { }

        /// <summary>
        /// Creates a successful response without data
        /// </summary>
        public static new ApiResponse SuccessResult(string message = "Operation successful")
        {
            var response = new ApiResponse();
            response.Success = true;
            response.Message = message;
            response.StatusCode = (int)HttpStatusCode.OK;
            response.Timestamp = DateTime.UtcNow;
            response.Errors = new Dictionary<string, string[]>();
            return response;
        }

        /// <summary>
        /// Creates an error response
        /// </summary>
        public static new ApiResponse ErrorResult(string message, HttpStatusCode statusCode = HttpStatusCode.BadRequest)
        {
            return new ApiResponse(message, statusCode);
        }

        /// <summary>
        /// Creates a validation error response
        /// </summary>
        public static new ApiResponse ValidationErrorResult(List<string> errors, string message = "Validation failed")
        {
            return new ApiResponse(errors, message);
        }
    }
}