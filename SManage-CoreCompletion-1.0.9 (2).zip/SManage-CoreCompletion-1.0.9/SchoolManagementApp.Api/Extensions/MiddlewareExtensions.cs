using SchoolManagementApp.Api.Middleware;

namespace SchoolManagementApp.Api.Extensions
{
    /// <summary>
    /// Extension methods for configuring middleware in the pipeline.
    /// Follows CorporateFleet's pattern of separating middleware registration from implementation.
    /// </summary>
    public static class MiddlewareExtensions
    {
        public static IApplicationBuilder UseApiMiddleware(this IApplicationBuilder app)
        {
            // Correlation id seed first, so every log/audit row of the request carries it
            // (docs/critical-issues/13-audit-trail-gaps.md follow-up).
            app.UseMiddleware<CorrelationIdMiddleware>();
            app.UseGlobalExceptionHandling();
            app.UseRequestResponseLogging();
            // TenantResolutionMiddleware removed from here — now registered in Startup.cs
            // AFTER UseAuthentication so JWT tenant_id claims are available.
            return app;
        }
    }
}
