using Microsoft.Extensions.Configuration;

namespace SchoolManagementApp.Api.Extensions
{
    /// <summary>
    /// Extension methods for CORS configuration.
    /// Origins are whitelisted via configuration ("Cors:AllowedOrigins") — never AllowAnyOrigin.
    /// See docs/critical-issues/02-cors-wide-open.md.
    /// </summary>
    public static class CorsExtensions
    {
        public const string PolicyName = "Frontend";

        public static IServiceCollection AddAppCors(this IServiceCollection services, IConfiguration configuration)
        {
            var allowedOrigins = configuration.GetSection("Cors:AllowedOrigins").Get<string[]>()
                ?? new[] { "http://localhost:4200" };

            services.AddCors(options =>
            {
                options.AddPolicy(PolicyName, policy => policy
                    .WithOrigins(allowedOrigins)
                    .AllowAnyMethod()
                    .AllowAnyHeader()
                    .AllowCredentials()); // required for authenticated SignalR negotiate/websockets
            });

            return services;
        }

        public static IApplicationBuilder UseAppCors(this IApplicationBuilder app)
        {
            app.UseCors(PolicyName);
            return app;
        }
    }
}
