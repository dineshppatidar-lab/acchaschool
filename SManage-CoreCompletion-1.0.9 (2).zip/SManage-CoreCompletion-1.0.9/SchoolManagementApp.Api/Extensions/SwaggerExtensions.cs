using Microsoft.OpenApi.Models;

namespace SchoolManagementApp.Api.Extensions
{
    /// <summary>
    /// Extension methods for Swagger/OpenAPI configuration.
    /// Follows CorporateFleet's pattern of separate extension classes per concern.
    /// </summary>
    public static class SwaggerExtensions
    {
        public static IServiceCollection AddAppSwagger(this IServiceCollection services)
        {
            services.AddEndpointsApiExplorer();
            services.AddSwaggerGen(options =>
            {
                options.SwaggerDoc("v1", new() { Title = "SchoolManagement API", Version = "v1" });

                options.AddServer(new OpenApiServer { Url = "http://schoolwala.runasp.net", Description = "Production Server" });
                options.AddServer(new OpenApiServer { Url = "http://localhost:5013", Description = "Development Server" });

                options.CustomSchemaIds(type => type.FullName);
                options.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
                {
                    Name = "Authorization",
                    Type = SecuritySchemeType.ApiKey,
                    Scheme = "Bearer",
                    BearerFormat = "JWT",
                    In = ParameterLocation.Header,
                    Description = "Enter JWT token like: `Bearer eyJhbGciOiJIUzI1NiIsIn...`"
                });

                options.AddSecurityRequirement(new OpenApiSecurityRequirement
                {
                    {
                        new OpenApiSecurityScheme
                        {
                            Reference = new OpenApiReference
                            {
                                Type = ReferenceType.SecurityScheme,
                                Id = "Bearer"
                            }
                        },
                        Array.Empty<string>()
                    }
                });
            });

            return services;
        }

        public static IApplicationBuilder UseAppSwagger(this IApplicationBuilder app)
        {
            app.UseSwagger();
            app.UseSwaggerUI();
            return app;
        }
    }
}
