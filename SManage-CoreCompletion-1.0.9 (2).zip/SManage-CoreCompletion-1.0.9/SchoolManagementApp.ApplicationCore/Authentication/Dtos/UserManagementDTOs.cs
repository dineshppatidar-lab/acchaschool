namespace SchoolManagementApp.ApplicationCore.Authentication.Dtos
{
    /// <summary>
    /// Administrator-supplied payload for creating a user from User Management.
    /// The password is ALWAYS received in clear text and hashed by the service
    /// before persistence — it is never stored or echoed verbatim.
    /// Deliberately excludes TenantId: the tenant comes from the authenticated
    /// JWT claim via ITenantProvider, never from client input.
    /// </summary>
    public class CreateUserRequest
    {
        public string Username { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string Password { get; set; } = string.Empty;
        public string Roles { get; set; } = string.Empty;
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public string? Phone { get; set; }
        public bool IsActive { get; set; } = true;
    }

    /// <summary>
    /// Administrator-supplied payload for updating a user. Null fields are
    /// left unchanged; a non-empty Password is re-hashed server-side.
    /// Deliberately excludes TenantId (tenant moves are not an update use case)
    /// and exposes no hash — the stored PasswordHash is only ever replaced
    /// through a freshly hashed Password.
    /// </summary>
    public class UpdateUserRequest
    {
        public string? Username { get; set; }
        public string? Email { get; set; }
        public string? Roles { get; set; }
        public string? Password { get; set; }
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public string? Phone { get; set; }
        public bool? IsActive { get; set; }
    }
}
