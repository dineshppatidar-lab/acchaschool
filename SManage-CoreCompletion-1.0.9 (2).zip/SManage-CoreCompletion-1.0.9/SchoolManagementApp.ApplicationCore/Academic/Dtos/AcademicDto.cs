namespace SchoolManagementApp.ApplicationCore.Academic.Dtos
{
    public class AcademicDto
    {
        public int Id { get; set; }
        public string Subject { get; set; } = string.Empty;
        public int ClassId { get; set; }
    }

    public class AcademicRequest
    {
        public string Subject { get; set; } = string.Empty;
        public int ClassId { get; set; }
    }

    /// <summary>
    /// Real per-class aggregates for list-page statistics (issue #7).
    /// </summary>
    public class ClassStatisticsDto
    {
        public int ClassId { get; set; }
        public int StudentCount { get; set; }
        public int SectionCount { get; set; }
        public int SubjectCount { get; set; }
    }

    /// <summary>
    /// Flat subject view for dropdowns and the subjects list screen.
    /// Subjects are class-scoped (Subjects.ClassId is required).
    /// </summary>
    public class SubjectDto
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public string Code { get; set; } = string.Empty;
        public int ClassId { get; set; }
        public string ClassName { get; set; } = string.Empty;
        public int CreditHours { get; set; }
    }
}
