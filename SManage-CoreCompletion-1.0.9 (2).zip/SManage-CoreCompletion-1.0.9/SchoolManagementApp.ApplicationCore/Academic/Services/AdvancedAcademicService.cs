using System.Text;
using Microsoft.Extensions.Logging;
using SchoolManagementApp.ApplicationCore.Communication.Interfaces;
using SchoolManagementApp.ApplicationCore.Entities;
using GradeAssignmentRequest = SchoolManagementApp.ApplicationCore.Academic.Interfaces.GradeAssignmentRequest;
using ITimeTableRepository = SchoolManagementApp.ApplicationCore.Academic.Interfaces.ITimeTableRepository;
using IExaminationRepository = SchoolManagementApp.ApplicationCore.Academic.Interfaces.IExaminationRepository;
using IExamScheduleRepository = SchoolManagementApp.ApplicationCore.Academic.Interfaces.IExamScheduleRepository;
using IAcademicYearRepository = SchoolManagementApp.ApplicationCore.Academic.Interfaces.IAcademicYearRepository;
using IAssignmentRepository = SchoolManagementApp.ApplicationCore.Academic.Interfaces.IAssignmentRepository;
using IAssignmentSubmissionRepository = SchoolManagementApp.ApplicationCore.Academic.Interfaces.IAssignmentSubmissionRepository;
using IGradingSchemeRepository = SchoolManagementApp.ApplicationCore.Academic.Interfaces.IGradingSchemeRepository;
using IExamResultRepository = SchoolManagementApp.ApplicationCore.Academic.Interfaces.IExamResultRepository;

namespace SchoolManagementApp.ApplicationCore.Academic.Services
{
    /// <summary>
    /// Service implementation for Advanced Academic operations
    /// </summary>
    public class AdvancedAcademicService : Academic.Interfaces.IAdvancedAcademicService
    {
        private readonly ITimeTableRepository _timeTableRepository;
        private readonly IExaminationRepository _examinationRepository;
        private readonly IExamScheduleRepository _examScheduleRepository;
        private readonly IAcademicYearRepository _academicYearRepository;
        private readonly IAssignmentRepository _assignmentRepository;
        private readonly IAssignmentSubmissionRepository _assignmentSubmissionRepository;
        private readonly IGradingSchemeRepository _gradingSchemeRepository;
        private readonly IExamResultRepository _examResultRepository;
        private readonly Communication.Interfaces.IRealtimeNotificationService _notificationService;
        private readonly ILogger<AdvancedAcademicService> _logger;

        public AdvancedAcademicService(
            ITimeTableRepository timeTableRepository,
            IExaminationRepository examinationRepository,
            IExamScheduleRepository examScheduleRepository,
            IAcademicYearRepository academicYearRepository,
            IAssignmentRepository assignmentRepository,
            IAssignmentSubmissionRepository assignmentSubmissionRepository,
            IGradingSchemeRepository gradingSchemeRepository,
            IExamResultRepository examResultRepository,
            Communication.Interfaces.IRealtimeNotificationService notificationService,
            ILogger<AdvancedAcademicService> logger)
        {
            _timeTableRepository = timeTableRepository;
            _examinationRepository = examinationRepository;
            _examScheduleRepository = examScheduleRepository;
            _academicYearRepository = academicYearRepository;
            _assignmentRepository = assignmentRepository;
            _assignmentSubmissionRepository = assignmentSubmissionRepository;
            _gradingSchemeRepository = gradingSchemeRepository;
            _examResultRepository = examResultRepository;
            _notificationService = notificationService;
            _logger = logger;
        }

        // ==================== Timetable Operations ====================

        public async Task<IEnumerable<TimeTable>> GetTimeTableByClassAsync(int classId, int sectionId)
        {
            return await _timeTableRepository.GetTimeTableByClassAsync(classId, sectionId);
        }

        public async Task<IEnumerable<TimeTable>> GetTimeTableByStaffAsync(int staffId)
        {
            return await _timeTableRepository.GetTimeTableByStaffAsync(staffId);
        }

        public async Task<TimeTable> CreateTimeTableAsync(TimeTable timeTable, string? staffUserId)
        {
            var hasConflict = await _timeTableRepository.CheckTimeSlotConflictAsync(
                timeTable.StaffId, timeTable.DayOfWeek, timeTable.StartTime, timeTable.EndTime);

            if (hasConflict)
                throw new InvalidOperationException("Time slot conflict detected for the selected staff member");

            timeTable.CreatedOn = DateTime.UtcNow;
            var result = await _timeTableRepository.AddAsync(timeTable);

            await _notificationService.SendNotificationAsync(
                "timetable",
                $"New class scheduled: {timeTable.DayOfWeek} {timeTable.StartTime}-{timeTable.EndTime}",
                new[] { timeTable.StaffId.ToString() });

            return result;
        }

        public async Task<bool> CheckTimeSlotConflictAsync(int staffId, DayOfWeek dayOfWeek, TimeSpan startTime, TimeSpan endTime)
        {
            return await _timeTableRepository.CheckTimeSlotConflictAsync(staffId, dayOfWeek, startTime, endTime);
        }

        public async Task<IEnumerable<TimeTable>> GetTimetablesAsync(int page, int pageSize)
        {
            return await _timeTableRepository.GetPagedAsync(page, pageSize);
        }

        public async Task UpdateTimetableAsync(int id, TimeTable timeTable)
        {
            if (id != timeTable.Id)
                throw new InvalidOperationException("ID mismatch");

            await _timeTableRepository.UpdateAsync(timeTable);
        }

        public async Task DeleteTimetableAsync(int id)
        {
            await _timeTableRepository.DeleteAsync(id);
        }

        public async Task<List<object>> GetTimetableConflictsAsync(int? staffId)
        {
            var all = await _timeTableRepository.GetAllAsync();
            var list = staffId.HasValue ? all.Where(t => t.StaffId == staffId.Value).ToList() : all.ToList();
            var conflicts = new List<object>();

            foreach (var g in list.GroupBy(t => new { t.StaffId, t.DayOfWeek }))
            {
                var ordered = g.OrderBy(t => t.StartTime).ToList();
                for (int i = 0; i < ordered.Count - 1; i++)
                {
                    if (ordered[i + 1].StartTime < ordered[i].EndTime)
                    {
                        conflicts.Add(new { first = ordered[i].Id, second = ordered[i + 1].Id, staff = g.Key.StaffId, day = g.Key.DayOfWeek });
                    }
                }
            }
            return conflicts;
        }

        public async Task<string> ExportTimetableCsvAsync(int classId)
        {
            var items = await _timeTableRepository.FindAsync(t => t.ClassId == classId);
            var csv = new StringBuilder();
            csv.AppendLine("Day,Start,End,Room,StaffId,SubjectId,SectionId");
            foreach (var t in items)
            {
                csv.AppendLine($"{t.DayOfWeek},{t.StartTime},{t.EndTime},{t.RoomNumber},{t.StaffId},{t.SubjectId},{t.SectionId}");
            }
            return csv.ToString();
        }

        // ==================== Examination Operations ====================

        public async Task<IEnumerable<Examination>> GetExaminationsAsync(int? academicYearId, int? typeId)
        {
            if (academicYearId.HasValue)
                return await _examinationRepository.GetExaminationsByAcademicYearAsync(academicYearId.Value);
            else if (typeId.HasValue)
                return await _examinationRepository.GetExaminationsByTypeAsync(typeId.Value);
            else
                return await _examinationRepository.GetUpcomingExaminationsAsync();
        }

        public async Task<Examination> CreateExaminationAsync(Examination examination, string? createdByUserId)
        {
            examination.CreatedOn = DateTime.UtcNow;
            examination.CreatedBy = createdByUserId ?? "0";

            var result = await _examinationRepository.AddAsync(examination);

            await _notificationService.SendNotificationToGroupAsync(
                "academic-staff",
                $"New examination scheduled: {examination.Title}",
                "examination");

            return result;
        }

        public async Task<Examination> UpdateExaminationAsync(int id, Examination examination)
        {
            if (id != examination.Id)
                throw new InvalidOperationException("ID mismatch between URL and examination body");

            var existing = await _examinationRepository.GetByIdAsync(id);
            if (existing == null)
                throw new InvalidOperationException("Examination not found");

            existing.Title = examination.Title;
            existing.ExaminationTypeId = examination.ExaminationTypeId;
            existing.AcademicYearId = examination.AcademicYearId;
            existing.StartDate = examination.StartDate;
            existing.EndDate = examination.EndDate;
            existing.Instructions = examination.Instructions;
            existing.IsPublished = examination.IsPublished;

            await _examinationRepository.UpdateAsync(existing);
            return existing;
        }

        public async Task DeleteExaminationAsync(int id)
        {
            await _examinationRepository.DeleteAsync(id);
        }

        public async Task<IEnumerable<ExamSchedule>> GetExamSchedulesAsync(int examinationId)
        {
            return await _examScheduleRepository.GetSchedulesByExaminationAsync(examinationId);
        }

        public async Task<ExamSchedule> CreateExamScheduleAsync(int examinationId, ExamSchedule schedule)
        {
            schedule.ExaminationId = examinationId;
            return await _examScheduleRepository.AddAsync(schedule);
        }

        public async Task<object> GetExaminationReportAsync(int id)
        {
            var exam = await _examinationRepository.GetByIdAsync(id);
            var schedules = await _examScheduleRepository.GetSchedulesByExaminationAsync(id);
            return new { exam.Id, exam.Title, exam.StartDate, exam.EndDate, scheduleCount = schedules.Count() };
        }

        public async Task<string> ExportExaminationCsvAsync(int id)
        {
            var schedules = await _examScheduleRepository.GetSchedulesByExaminationAsync(id);
            var csv = new StringBuilder();
            csv.AppendLine("ClassId,SubjectId,ExamDate,StartTime,EndTime,RoomNumber");
            foreach (var s in schedules)
            {
                csv.AppendLine($"{s.ClassId},{s.SubjectId},{s.ExamDate:yyyy-MM-dd},{s.StartTime},{s.EndTime},{s.RoomNumber}");
            }
            return csv.ToString();
        }

        // ==================== Assignment Operations ====================

        public async Task<IEnumerable<Assignment>> GetAssignmentsByClassAsync(int classId, int sectionId)
        {
            return await _assignmentRepository.GetAssignmentsByClassAsync(classId, sectionId);
        }

        public async Task<IEnumerable<Assignment>> GetAssignmentsByStudentAsync(int studentId)
        {
            return await _assignmentRepository.GetAssignmentsByStudentAsync(studentId);
        }

        public async Task<Assignment> CreateAssignmentAsync(Assignment assignment, string? createdByUserId)
        {
            assignment.AssignedBy = int.TryParse(createdByUserId ?? "0", out var currentId) ? currentId : 0;
            assignment.AssignedDate = DateTime.UtcNow;

            var result = await _assignmentRepository.AddAsync(assignment);

            await _notificationService.SendNotificationToGroupAsync(
                $"class-{assignment.ClassId}-section-{assignment.SectionId}",
                $"New assignment posted: {assignment.Title} (Due: {assignment.DueDate:MMM dd})",
                "assignment");

            return result;
        }

        public async Task<AssignmentSubmission> SubmitAssignmentAsync(int assignmentId, AssignmentSubmission submission)
        {
            var existingSubmission = await _assignmentSubmissionRepository
                .GetSubmissionByStudentAndAssignmentAsync(submission.StudentId, assignmentId);

            if (existingSubmission != null)
                throw new InvalidOperationException("Assignment already submitted");

            submission.AssignmentId = assignmentId;
            submission.SubmittedDate = DateTime.UtcNow;
            submission.Status = "Submitted";

            var result = await _assignmentSubmissionRepository.AddAsync(submission);

            var assignment = await _assignmentRepository.GetByIdAsync(assignmentId);
            await _notificationService.SendNotificationAsync(
                "submission",
                $"Assignment submission received for: {assignment.Title}",
                new[] { assignment.AssignedBy.ToString() });

            return result;
        }

        public async Task<IEnumerable<AssignmentSubmission>> GetAssignmentSubmissionsAsync(int assignmentId)
        {
            return await _assignmentSubmissionRepository.GetSubmissionsByAssignmentAsync(assignmentId);
        }

        public async Task GradeSubmissionAsync(int submissionId, decimal marks, string feedback, string? graderUserId)
        {
            var submission = await _assignmentSubmissionRepository.GetByIdAsync(submissionId);
            if (submission == null)
                throw new InvalidOperationException("Submission not found");

            submission.MarksObtained = marks;
            submission.FeedBack = feedback;
            submission.GradedDate = DateTime.UtcNow;
            submission.GradedBy = int.TryParse(graderUserId ?? "0", out var graderId) ? graderId : null;
            submission.Status = "Graded";

            await _assignmentSubmissionRepository.UpdateAsync(submission);

            await _notificationService.SendNotificationAsync(
                "grade",
                $"Your assignment has been graded. Marks: {marks}",
                new[] { submission.StudentId.ToString() });
        }

        public async Task UpdateAssignmentAsync(int id, Assignment assignment)
        {
            if (id != assignment.Id)
                throw new InvalidOperationException("ID mismatch");

            await _assignmentRepository.UpdateAsync(assignment);
        }

        public async Task DeleteAssignmentAsync(int id)
        {
            await _assignmentRepository.DeleteAsync(id);
        }

        public async Task GradeAssignmentForStudentAsync(int assignmentId, int studentId, decimal marks, string? feedback, string? graderUserId)
        {
            var submission = await _assignmentSubmissionRepository.GetSubmissionByStudentAndAssignmentAsync(studentId, assignmentId);
            if (submission == null)
            {
                submission = new AssignmentSubmission
                {
                    AssignmentId = assignmentId,
                    StudentId = studentId,
                    SubmittedDate = DateTime.UtcNow,
                    Status = "Submitted"
                };
                submission = await _assignmentSubmissionRepository.AddAsync(submission);
            }

            submission.MarksObtained = marks;
            submission.FeedBack = feedback ?? string.Empty;
            submission.GradedDate = DateTime.UtcNow;
            submission.GradedBy = int.TryParse(graderUserId ?? "0", out var graderId) ? graderId : null;
            submission.Status = "Graded";

            await _assignmentSubmissionRepository.UpdateAsync(submission);
        }

        public async Task BulkGradeAssignmentsAsync(int assignmentId, IEnumerable<GradeAssignmentRequest> grades, string? graderUserId)
        {
            var studentIds = grades.Select(g => g.StudentId).ToList();
            var existingSubmissions = (await _assignmentSubmissionRepository.FindAsync(s => s.AssignmentId == assignmentId && studentIds.Contains(s.StudentId))).ToList();

            var toAdd = new List<AssignmentSubmission>();
            var toUpdate = new List<AssignmentSubmission>();
            var graderId = int.TryParse(graderUserId ?? "0", out var gid) ? gid : (int?)null;

            foreach (var g in grades)
            {
                var submission = existingSubmissions.FirstOrDefault(s => s.StudentId == g.StudentId);
                if (submission == null)
                {
                    submission = new AssignmentSubmission
                    {
                        AssignmentId = assignmentId,
                        StudentId = g.StudentId,
                        SubmittedDate = DateTime.UtcNow,
                        Status = "Graded",
                        MarksObtained = g.MarksObtained,
                        FeedBack = g.Feedback ?? string.Empty,
                        GradedDate = DateTime.UtcNow,
                        GradedBy = graderId
                    };
                    toAdd.Add(submission);
                }
                else
                {
                    submission.MarksObtained = g.MarksObtained;
                    submission.FeedBack = g.Feedback ?? string.Empty;
                    submission.GradedDate = DateTime.UtcNow;
                    submission.GradedBy = graderId;
                    submission.Status = "Graded";
                    toUpdate.Add(submission);
                }
            }

            if (toAdd.Any()) await _assignmentSubmissionRepository.AddRangeAsync(toAdd);
            if (toUpdate.Any()) await _assignmentSubmissionRepository.UpdateRangeAsync(toUpdate);
        }

        public async Task<string> ExportAssignmentGradesCsvAsync(int assignmentId)
        {
            var subs = await _assignmentSubmissionRepository.GetSubmissionsByAssignmentAsync(assignmentId);
            var csv = new StringBuilder();
            csv.AppendLine("StudentId,MarksObtained,Status,GradedDate");
            foreach (var s in subs)
            {
                csv.AppendLine($"{s.StudentId},{s.MarksObtained},{s.Status},{(s.GradedDate.HasValue ? s.GradedDate.Value.ToString("yyyy-MM-dd HH:mm") : string.Empty)}");
            }
            return csv.ToString();
        }

        public async Task<IEnumerable<Assignment>> GetFilteredAssignmentsAsync(Dictionary<string, string> filters)
        {
            // Includes keep Class/Subject/Section navigations populated, so
            // className/subjectName resolve instead of mapping to empty strings.
            var all = await _assignmentRepository.GetAllWithNavigationsAsync();
            var query = all.AsQueryable();
            if (filters.TryGetValue("classId", out var classIdStr) && int.TryParse(classIdStr, out var cId))
                query = query.Where(a => a.ClassId == cId);
            if (filters.TryGetValue("subjectId", out var subjectIdStr) && int.TryParse(subjectIdStr, out var sId))
                query = query.Where(a => a.SubjectId == sId);
            if (filters.TryGetValue("status", out var status) && !string.IsNullOrWhiteSpace(status))
            {
                if (string.Equals(status, "active", StringComparison.OrdinalIgnoreCase))
                    query = query.Where(a => a.IsActive);
                else if (string.Equals(status, "inactive", StringComparison.OrdinalIgnoreCase))
                    query = query.Where(a => !a.IsActive);
            }
            return query.ToList();
        }

        // ==================== Academic Year Operations ====================

        public async Task<IEnumerable<AcademicYear>> GetAcademicYearsAsync()
        {
            return await _academicYearRepository.GetActiveAcademicYearsAsync();
        }

        public async Task<AcademicYear> GetCurrentAcademicYearAsync()
        {
            return await _academicYearRepository.GetCurrentAcademicYearAsync();
        }

        // ==================== Grading Operations ====================

        public async Task<IEnumerable<GradingScheme>> GetGradingSchemesAsync()
        {
            return await _gradingSchemeRepository.GetActiveGradingSchemesAsync();
        }

        public async Task<GradingScheme> CreateGradingSchemeAsync(GradingScheme scheme)
        {
            return await _gradingSchemeRepository.AddAsync(scheme);
        }

        public async Task UpdateGradingSchemeAsync(int id, GradingScheme scheme)
        {
            if (id != scheme.Id)
                throw new InvalidOperationException("ID mismatch");

            await _gradingSchemeRepository.UpdateAsync(scheme);
        }

        public async Task DeleteGradingSchemeAsync(int id)
        {
            await _gradingSchemeRepository.DeleteAsync(id);
        }

        public async Task<GradingScheme> CalculateGradeAsync(decimal marks)
        {
            return await _gradingSchemeRepository.GetGradeByMarksAsync(marks);
        }

        // ==================== Exam Results Operations ====================

        public async Task<IEnumerable<ExamResult>> GetResultsAsync(int? studentId, string? examType, int? subjectId)
        {
            return await _examResultRepository.GetResultsByFiltersAsync(studentId, examType, subjectId);
        }

        public async Task<ExamResult> CreateResultAsync(ExamResult result)
        {
            return await _examResultRepository.AddAsync(result);
        }

        public async Task UpdateResultAsync(int id, ExamResult result)
        {
            if (id != result.Id)
                throw new InvalidOperationException("ID mismatch");

            await _examResultRepository.UpdateAsync(result);
        }

        public async Task DeleteResultAsync(int id)
        {
            await _examResultRepository.DeleteAsync(id);
        }

        // ==================== Analytics ====================

        public async Task<object> GetTeacherWorkloadAsync(int? teacherId)
        {
            var pending = teacherId.HasValue
                ? await _assignmentSubmissionRepository.CountAsync(s => s.GradedBy == null && s.Assignment.AssignedBy == teacherId.Value)
                : await _assignmentSubmissionRepository.CountAsync(s => s.GradedBy == null);

            var totalSlots = teacherId.HasValue
                ? await _timeTableRepository.CountAsync(t => t.StaffId == teacherId.Value)
                : await _timeTableRepository.CountAsync();

            return new { totalSlots, pendingGrading = pending };
        }

        public async Task<object> GetClassroomUtilizationAsync()
        {
            var timetables = await _timeTableRepository.GetAllAsync();
            return timetables
                .Where(t => !string.IsNullOrWhiteSpace(t.RoomNumber))
                .GroupBy(t => t.RoomNumber)
                .Select(g => new { room = g.Key, slots = g.Count() })
                .OrderByDescending(x => x.slots)
                .ToList();
        }

        public async Task<object> GetAssignmentStatisticsAsync(int? classId)
        {
            var total = classId.HasValue
                ? await _assignmentRepository.CountAsync(a => a.ClassId == classId.Value)
                : await _assignmentRepository.CountAsync();

            var overdue = classId.HasValue
                ? await _assignmentRepository.CountAsync(a => a.ClassId == classId.Value && a.DueDate < DateTime.UtcNow && a.IsActive)
                : await _assignmentRepository.CountAsync(a => a.DueDate < DateTime.UtcNow && a.IsActive);

            var active = classId.HasValue
                ? await _assignmentRepository.CountAsync(a => a.ClassId == classId.Value && a.IsActive)
                : await _assignmentRepository.CountAsync(a => a.IsActive);

            return new { total, overdue, active };
        }
    }
}
