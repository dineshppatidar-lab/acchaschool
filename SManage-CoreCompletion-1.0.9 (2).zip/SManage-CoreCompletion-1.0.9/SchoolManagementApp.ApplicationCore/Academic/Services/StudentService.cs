using SchoolManagementApp.ApplicationCore;
using SchoolManagementApp.ApplicationCore.Entities;
using SchoolManagementApp.ApplicationCore.Students.Dtos;
using SchoolManagementApp.ApplicationCore.Students.Services;
using SchoolManagementApp.ApplicationCore.Academic.Interfaces;
using SchoolManagementApp.ApplicationCore.Common.Services;
using IStudentService = SchoolManagementApp.ApplicationCore.Students.Interfaces.IStudentService;
using Microsoft.Extensions.Logging;
using SchoolManagementApp.ApplicationCore.Students.Interfaces;

namespace SchoolManagementApp.ApplicationCore.Academic.Services
{
    /// <summary>
    /// Service implementation for Student operations
    /// </summary>
    public class StudentService : Students.Interfaces.IStudentService
    {
        private readonly IStudentRepository _studentRepository;
        private readonly IStudentManagementService _studentManagementService;
        private readonly IAuditService _auditService;
        private readonly ILogger<StudentService> _logger;

        public StudentService(
            IStudentRepository studentRepository,
            IStudentManagementService studentManagementService,
            IAuditService auditService,
            ILogger<StudentService> logger)
        {
            _studentRepository = studentRepository;
            _studentManagementService = studentManagementService;
            _auditService = auditService;
            _logger = logger;
        }

        public async Task<IEnumerable<Student>> GetAllStudentsAsync()
        {
            return await _studentRepository.GetAllAsync();
        }

        public async Task<Student?> GetStudentByIdAsync(int id)
        {
            return await _studentRepository.GetByIdAsync(id);
        }

        public async Task<Student> CreateStudentAsync(Student student)
        {
            var createdStudent = await _studentRepository.CreateAsync(student);
            _auditService.Log("Create", "Student", createdStudent.Id.ToString(), 
                $"Created student {createdStudent.FirstName} {createdStudent.LastName}");
            return createdStudent;
        }

        public async Task UpdateStudentAsync(Student student)
        {
            await _studentRepository.UpdateAsync(student);
            _auditService.Log("Update", "Student", student.Id.ToString(), 
                $"Updated student {student.FirstName} {student.LastName}");
        }

        public async Task DeleteStudentAsync(int id)
        {
            await _studentRepository.DeleteAsync(id);
            _auditService.Log("Delete", "Student", id.ToString(), $"Deleted student {id}");
        }

        public async Task<IEnumerable<Student>> GetStudentsByClassAsync(int classId)
        {
            return await _studentRepository.GetByClassAsync(classId);
        }

        public async Task<IEnumerable<Student>> GetStudentsBySectionAsync(int sectionId)
        {
            return await _studentRepository.GetBySectionAsync(sectionId);
        }

        public async Task<(IEnumerable<Student> Students, int Total)> GetStudentsPaginatedAsync(
            int page, int pageSize, string? search = null)
        {
            var allStudents = await _studentRepository.GetAllAsync();
            var students = allStudents.AsEnumerable();

            if (!string.IsNullOrEmpty(search))
            {
                var term = search.Trim();
                students = students.Where(s =>
                    (!string.IsNullOrEmpty(s.FirstName) && 
                     (s.FirstName + " " + s.LastName).IndexOf(term, StringComparison.OrdinalIgnoreCase) >= 0)
                    || (!string.IsNullOrEmpty(s.Email) && 
                     s.Email.IndexOf(term, StringComparison.OrdinalIgnoreCase) >= 0)
                    || (!string.IsNullOrEmpty(s.RollNumber) && 
                     s.RollNumber.IndexOf(term, StringComparison.OrdinalIgnoreCase) >= 0)
                    || (!string.IsNullOrEmpty(s.ScholarNumber) && 
                     s.ScholarNumber.IndexOf(term, StringComparison.OrdinalIgnoreCase) >= 0)
                );
            }

            var total = students.Count();
            var paged = students.Skip((page - 1) * pageSize).Take(pageSize).ToList();

            return (paged, total);
        }

        public async Task<IEnumerable<StudentFullDetailsDto>> GetAllStudentFullDetailsAsync()
        {
            return await _studentManagementService.GetAllStudentFullDetailsAsync();
        }

        public async Task<StudentFullDetailsDto?> GetStudentFullDetailsAsync(int id)
        {
            return await _studentManagementService.GetStudentFullDetailsAsync(id);
        }

        public async Task<StudentFullDetailsDto> CreateStudentFullDetailsAsync(StudentFullDetailsDto studentDto)
        {
            return await _studentManagementService.CreateStudentFullDetailsAsync(studentDto);
        }

        public async Task UpdateStudentFullDetailsAsync(int id, StudentFullDetailsDto studentDto)
        {
            await _studentManagementService.UpdateStudentFullDetailsAsync(id, studentDto);
        }
    }
}
