using Microsoft.Extensions.Logging;
using IExaminationTypeRepository = SchoolManagementApp.ApplicationCore.Academic.Interfaces.IExaminationTypeRepository;
using IExaminationRepository = SchoolManagementApp.ApplicationCore.Academic.Interfaces.IExaminationRepository;

namespace SchoolManagementApp.ApplicationCore.Academic.Services
{
    /// <summary>
    /// Service implementation for Examination Type operations
    /// </summary>
    public class ExaminationService : Academic.Interfaces.IExaminationService
    {
        private readonly IExaminationTypeRepository _examinationTypeRepository;
        private readonly IExaminationRepository _examinationRepository;
        private readonly ILogger<ExaminationService> _logger;

        public ExaminationService(
            IExaminationTypeRepository examinationTypeRepository,
            IExaminationRepository examinationRepository,
            ILogger<ExaminationService> logger)
        {
            _examinationTypeRepository = examinationTypeRepository;
            _examinationRepository = examinationRepository;
            _logger = logger;
        }

        public async Task<IEnumerable<ExaminationType>> GetAllExaminationTypesAsync()
        {
            return await _examinationTypeRepository.GetAllAsync();
        }

        public async Task<ExaminationType?> GetExaminationTypeByIdAsync(int id)
        {
            return await _examinationTypeRepository.GetByIdAsync(id);
        }

        public async Task<ExaminationType> CreateExaminationTypeAsync(ExaminationType type)
        {
            return await _examinationTypeRepository.AddAsync(type);
        }

        public async Task<ExaminationType> UpdateExaminationTypeAsync(int id, ExaminationType type)
        {
            var existing = await _examinationTypeRepository.GetByIdAsync(id);
            if (existing == null)
                throw new InvalidOperationException($"Examination type with ID {id} not found");

            existing.Name = type.Name;
            existing.Description = type.Description;
            existing.WeightagePercentage = type.WeightagePercentage;
            existing.IsActive = type.IsActive;

            await _examinationTypeRepository.UpdateAsync(existing);
            return existing;
        }

        public async Task<bool> DeleteExaminationTypeAsync(int id)
        {
            var inUse = await _examinationRepository.ExistsAsync(e => e.ExaminationTypeId == id);
            if (inUse)
                throw new InvalidOperationException("Cannot delete examination type as it is in use by existing examinations.");

            await _examinationTypeRepository.DeleteAsync(id);
            return true;
        }
    }
}
