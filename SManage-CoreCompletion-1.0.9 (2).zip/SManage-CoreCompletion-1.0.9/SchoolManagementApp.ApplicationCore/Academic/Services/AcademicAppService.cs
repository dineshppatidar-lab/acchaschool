using Microsoft.Extensions.Logging;
using Microsoft.EntityFrameworkCore;
using SchoolManagementApp.ApplicationCore.Academic.Dtos;
using SchoolManagementApp.ApplicationCore.Academic.Interfaces;
using SchoolManagementApp.ApplicationCore.Common.Services;
using SchoolManagementApp.ApplicationCore._Interfaces;

// Use explicit namespace to avoid ambiguity with deprecated IAcademicRepository
using IAcademicRepository = SchoolManagementApp.ApplicationCore.Academic.Interfaces.IAcademicRepository;

namespace SchoolManagementApp.ApplicationCore.Academic.Services
{
    /// <summary>
    /// Application service for Academic operations (Classes and Sections).
    /// Follows CorporateFleet's {Name}AppService pattern.
    /// </summary>
    public class AcademicAppService : IAcademicAppService
    {
        private readonly IAcademicRepository _academicRepository;
        private readonly IAuditService _auditService;
        private readonly ILogger<AcademicAppService> _logger;
        private readonly IAppDbContext _context;

        public AcademicAppService(
            IAcademicRepository academicRepository,
            IAuditService auditService,
            ILogger<AcademicAppService> logger,
            IAppDbContext context)
        {
            _academicRepository = academicRepository;
            _auditService = auditService;
            _logger = logger;
            _context = context;
        }

        // ==================== Class Management ====================

        public async Task<(IEnumerable<Class>, int)> GetClassesAsync(int page, int pageSize, string sort, string order, string search)
        {
            return await _academicRepository.GetClassesAsync(page, pageSize, sort, order, search);
        }

        public async Task<IEnumerable<Class>> GetAllClassesAsync()
        {
            var (classes, _) = await _academicRepository.GetClassesAsync(1, 1000, "Name", "asc", "");
            return classes;
        }

        public async Task<IEnumerable<Class>> GetClassesByAcademicYearAsync(int academicYearId)
        {
            return await _academicRepository.GetClassesByAcademicYearAsync(academicYearId);
        }

        public async Task<Class?> GetClassByIdAsync(int id)
        {
            return await _academicRepository.GetClassByIdAsync(id);
        }

        public async Task<Class> CreateClassAsync(Class class_)
        {
            var createdClass = await _academicRepository.CreateClassAsync(class_);
            _auditService.Log("Create", "Class", createdClass.Id.ToString(),
                $"Created class '{createdClass.Name}'");
            _logger.LogInformation("Class created: {ClassId} - {ClassName}", createdClass.Id, createdClass.Name);

            // Every class must have at least one section so admissions and admin
            // screens that require a section always have a valid one to pick.
            // Create a default "A" section for brand-new classes.
            int tenantId = _context.CurrentTenantId;
            if (!await _context.Sections.AnyAsync(s => s.TenantId == tenantId && s.ClassId == createdClass.Id))
            {
                _context.Sections.Add(new Section
                {
                    TenantId = tenantId,
                    ClassId = createdClass.Id,
                    Name = "A"
                });
                await _context.SaveChangesAsync();
                _logger.LogInformation("Default section 'A' created for class {ClassId}", createdClass.Id);
            }

            return createdClass;
        }

        public async Task UpdateClassAsync(Class class_)
        {
            await _academicRepository.UpdateClassAsync(class_);
            _auditService.Log("Update", "Class", class_.Id.ToString(),
                $"Updated class '{class_.Name}'");
            _logger.LogInformation("Class updated: {ClassId} - {ClassName}", class_.Id, class_.Name);
        }

        public async Task DeleteClassAsync(int id)
        {
            await _academicRepository.DeleteClassAsync(id);
            _auditService.Log("Delete", "Class", id.ToString(), $"Deleted class {id}");
            _logger.LogInformation("Class deleted: {ClassId}", id);
        }

        /// <summary>
        /// Real per-class aggregates (active students, sections, subjects) for statistics
        /// cards and per-row counts (issue #7 — replaces the hardcoded 25-student mock).
        /// </summary>
        public async Task<IReadOnlyList<ClassStatisticsDto>> GetClassStatisticsAsync()
        {
            int tenantId = _context.CurrentTenantId;

            var studentCounts = await _context.Students
                .AsNoTracking()
                .Where(s => s.TenantId == tenantId && s.IsActive && s.Status == "Active")
                .GroupBy(s => s.ClassId)
                .Select(g => new { ClassId = g.Key, Count = g.Count() })
                .ToDictionaryAsync(x => x.ClassId, x => x.Count);

            var sectionCounts = await _context.Sections
                .AsNoTracking()
                .Where(s => s.TenantId == tenantId)
                .GroupBy(s => s.ClassId)
                .Select(g => new { ClassId = g.Key, Count = g.Count() })
                .ToDictionaryAsync(x => x.ClassId, x => x.Count);

            var subjectCounts = await _context.Subjects
                .AsNoTracking()
                .Where(s => s.TenantId == tenantId)
                .GroupBy(s => s.ClassId)
                .Select(g => new { ClassId = g.Key, Count = g.Count() })
                .ToDictionaryAsync(x => x.ClassId, x => x.Count);

            var classIds = studentCounts.Keys
                .Concat(sectionCounts.Keys)
                .Concat(subjectCounts.Keys)
                .Distinct();

            return classIds
                .Select(id => new ClassStatisticsDto
                {
                    ClassId = id,
                    StudentCount = studentCounts.GetValueOrDefault(id),
                    SectionCount = sectionCounts.GetValueOrDefault(id),
                    SubjectCount = subjectCounts.GetValueOrDefault(id)
                    })
                .ToList();
        }

        // ==================== Section Management ====================

        public async Task<(IEnumerable<Section>, int)> GetSectionsAsync(int page, int pageSize, string sort, string order, string search)
        {
            return await _academicRepository.GetSectionsAsync(page, pageSize, sort, order, search);
        }

        public async Task<Section?> GetSectionByIdAsync(int id)
        {
            return await _academicRepository.GetSectionByIdAsync(id);
        }

        public async Task<IEnumerable<Section>> GetSectionsByClassAsync(int classId)
        {
            return await _academicRepository.GetSectionsByClassAsync(classId);
        }

        public async Task<Section> CreateSectionAsync(Section section)
        {
            var createdSection = await _academicRepository.CreateSectionAsync(section);
            _auditService.Log("Create", "Section", createdSection.Id.ToString(),
                $"Created section '{createdSection.Name}'");
            _logger.LogInformation("Section created: {SectionId} - {SectionName}", createdSection.Id, createdSection.Name);
            return createdSection;
        }

        public async Task UpdateSectionAsync(Section section)
        {
            await _academicRepository.UpdateSectionAsync(section);
            _auditService.Log("Update", "Section", section.Id.ToString(),
                $"Updated section '{section.Name}'");
            _logger.LogInformation("Section updated: {SectionId} - {SectionName}", section.Id, section.Name);
        }

        public async Task DeleteSectionAsync(int id)
        {
            await _academicRepository.DeleteSectionAsync(id);
            _auditService.Log("Delete", "Section", id.ToString(), $"Deleted section {id}");
            _logger.LogInformation("Section deleted: {SectionId}", id);
        }

        // ==================== Subject Management ====================

        public async Task<IEnumerable<SubjectDto>> GetSubjectsAsync(int? classId = null)
        {
            return await _academicRepository.GetSubjectsAsync(classId);
        }

        public async Task<SubjectDto?> GetSubjectByIdAsync(int id)
        {
            return await _academicRepository.GetSubjectByIdAsync(id);
        }
    }
}
