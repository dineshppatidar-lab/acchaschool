using Ardalis.Specification;
using SchoolManagementApp.ApplicationCore.Entities;

namespace SchoolManagementApp.ApplicationCore.Academic.Specifications
{
    public class SectionsByClassSpec : Specification<Section>
    {
        public SectionsByClassSpec(int classId)
        {
            Query.Where(s => s.ClassId == classId)
                 .OrderBy(s => s.Name);
        }
    }
}
