using Ardalis.Specification;
using SchoolManagementApp.ApplicationCore.Entities;

namespace SchoolManagementApp.ApplicationCore.Academic.Specifications
{
    public class SubjectsByClassSpec : Specification<Subject>
    {
        public SubjectsByClassSpec(int classId)
        {
            Query.Where(s => s.ClassId == classId)
                 .OrderBy(s => s.Name);
        }
    }
}
