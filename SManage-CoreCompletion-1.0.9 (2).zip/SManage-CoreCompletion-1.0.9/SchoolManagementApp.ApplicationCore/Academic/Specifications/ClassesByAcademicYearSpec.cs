using Ardalis.Specification;
using SchoolManagementApp.ApplicationCore.Entities;

namespace SchoolManagementApp.ApplicationCore.Academic.Specifications
{
    /// <summary>
    /// Specification to filter classes by academic year.
    /// </summary>
    public class ClassesByAcademicYearSpec : Specification<Class>
    {
        public ClassesByAcademicYearSpec(int academicYearId)
        {
            Query.Where(c => c.AcademicYearId == academicYearId)
                 .OrderBy(c => c.Name)
                 .Include(c => c.Sections);
        }
    }
}
