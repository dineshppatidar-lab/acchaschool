# Specifications

This folder contains specification classes following the Ardalis.Specification pattern.

## Example
\x60\x60\x60csharp
public class StudentsByClassSpec : Specification<Student>
{
    public StudentsByClassSpec(int classId)
    {
        Query.Where(s => s.ClassId == classId)
             .OrderBy(s => s.LastName);
    }
}
\x60\x60\x60
