using FluentValidation;
using SchoolManagementApp.ApplicationCore.Academic.Dtos;

namespace SchoolManagementApp.ApplicationCore.Academic.Validators
{
    public class AcademicRequestValidator : AbstractValidator<AcademicRequest>
    {
        public AcademicRequestValidator()
        {
            RuleFor(x => x.Subject).NotEmpty().MaximumLength(200);
            RuleFor(x => x.ClassId).GreaterThan(0);
        }
    }
}
