
namespace SchoolManagementApp.ApplicationCore.Academic.Interfaces
{
    /// <summary>
    /// Service interface for Academic operations (Classes and Sections)
    /// </summary>
    public interface IAcademicService
    {
        // Class Management
        Task<(IEnumerable<Class>, int)> GetClassesAsync(int page, int pageSize, string sort, string order, string search);
        Task<IEnumerable<Class>> GetAllClassesAsync();
        Task<IEnumerable<Class>> GetClassesByAcademicYearAsync(int academicYearId);
        Task<Class?> GetClassByIdAsync(int id);
        Task<Class> CreateClassAsync(Class class_);
        Task UpdateClassAsync(Class class_);
        Task DeleteClassAsync(int id);

        // Section Management
        Task<(IEnumerable<Section>, int)> GetSectionsAsync(int page, int pageSize, string sort, string order, string search);
        Task<Section?> GetSectionByIdAsync(int id);
        Task<IEnumerable<Section>> GetSectionsByClassAsync(int classId);
        Task<Section> CreateSectionAsync(Section section);
        Task UpdateSectionAsync(Section section);
        Task DeleteSectionAsync(int id);
    }
}
