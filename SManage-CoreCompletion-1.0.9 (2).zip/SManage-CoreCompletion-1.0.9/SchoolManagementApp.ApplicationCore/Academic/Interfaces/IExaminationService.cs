
namespace SchoolManagementApp.ApplicationCore.Academic.Interfaces
{
    /// <summary>
    /// Service interface for Examination Type operations
    /// </summary>
    public interface IExaminationService
    {
        Task<IEnumerable<ExaminationType>> GetAllExaminationTypesAsync();
        Task<ExaminationType?> GetExaminationTypeByIdAsync(int id);
        Task<ExaminationType> CreateExaminationTypeAsync(ExaminationType type);
        Task<ExaminationType> UpdateExaminationTypeAsync(int id, ExaminationType type);
        Task<bool> DeleteExaminationTypeAsync(int id);
    }
}
