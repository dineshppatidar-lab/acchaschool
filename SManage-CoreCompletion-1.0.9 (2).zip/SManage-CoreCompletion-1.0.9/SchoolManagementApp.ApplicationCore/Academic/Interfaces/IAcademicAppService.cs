using SchoolManagementApp.ApplicationCore.Academic.Dtos;

namespace SchoolManagementApp.ApplicationCore.Academic.Interfaces
{
    // (Subject operations are declared below)
    /// <summary>
    /// Service interface for Academic operations (Classes and Sections)
    /// Moved from Students/Interfaces/ per CorporateFleet module pattern.
    /// </summary>
    public interface IAcademicAppService
    {
        // Class Management
        Task<(IEnumerable<Class>, int)> GetClassesAsync(int page, int pageSize, string sort, string order, string search);
        Task<IEnumerable<Class>> GetAllClassesAsync();
        Task<IEnumerable<Class>> GetClassesByAcademicYearAsync(int academicYearId);
        Task<Class?> GetClassByIdAsync(int id);
        Task<Class> CreateClassAsync(Class class_);
        Task UpdateClassAsync(Class class_);
        Task DeleteClassAsync(int id);

        /// <summary>
        /// Real per-class aggregates (active students, sections, subjects) for statistics cards.
        /// </summary>
        Task<IReadOnlyList<ClassStatisticsDto>> GetClassStatisticsAsync();

        // Section Management
        Task<(IEnumerable<Section>, int)> GetSectionsAsync(int page, int pageSize, string sort, string order, string search);
        Task<Section?> GetSectionByIdAsync(int id);
        Task<IEnumerable<Section>> GetSectionsByClassAsync(int classId);
        Task<Section> CreateSectionAsync(Section section);
        Task UpdateSectionAsync(Section section);
        Task DeleteSectionAsync(int id);

        // Subject Management (subjects are class-scoped)
        Task<IEnumerable<SubjectDto>> GetSubjectsAsync(int? classId = null);
        Task<SubjectDto?> GetSubjectByIdAsync(int id);
    }
}
