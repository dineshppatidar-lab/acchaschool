namespace SchoolManagementApp.ApplicationCore.Academic.Interfaces
{
    /// <summary>
    /// Service interface for Examination Type operations
    /// Moved from Students/Interfaces/ per CorporateFleet module pattern.
    /// </summary>
    public interface IExaminationAppService
    {
        Task<IEnumerable<ExaminationType>> GetAllExaminationTypesAsync();
        Task<ExaminationType?> GetExaminationTypeByIdAsync(int id);
        Task<ExaminationType> CreateExaminationTypeAsync(ExaminationType type);
        Task<ExaminationType> UpdateExaminationTypeAsync(int id, ExaminationType type);
        Task<bool> DeleteExaminationTypeAsync(int id);
    }
}
