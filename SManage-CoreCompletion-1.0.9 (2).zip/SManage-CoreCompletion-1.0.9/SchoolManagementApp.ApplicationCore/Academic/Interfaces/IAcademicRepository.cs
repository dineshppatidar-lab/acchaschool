
namespace SchoolManagementApp.ApplicationCore.Academic.Interfaces
{
    using SchoolManagementApp.ApplicationCore.Academic.Dtos;

    public interface IAcademicRepository
    {
        Task<(IEnumerable<Class>, int)> GetClassesAsync(int page, int pageSize, string sort, string order, string search);
        Task<IEnumerable<Class>> GetClassesByAcademicYearAsync(int academicYearId);
        Task<Class> GetClassByIdAsync(int id);
        Task<Class> CreateClassAsync(Class class_);
        Task UpdateClassAsync(Class class_);
        Task DeleteClassAsync(int id);

        Task<(IEnumerable<Section>, int)> GetSectionsAsync(int page, int pageSize, string sort, string order, string search);
        Task<IEnumerable<Section>> GetSectionsByClassAsync(int classId);
        Task<Section> GetSectionByIdAsync(int id);
        Task<Section> CreateSectionAsync(Section section);
        Task UpdateSectionAsync(Section section);
        Task DeleteSectionAsync(int id);

        // Subject Management (subjects are class-scoped)
        Task<IEnumerable<SubjectDto>> GetSubjectsAsync(int? classId = null);
        Task<SubjectDto?> GetSubjectByIdAsync(int id);
    }

    public interface ITimeTableRepository : IGenericRepository<TimeTable>
    {
        Task<IEnumerable<TimeTable>> GetTimeTableByClassAsync(int classId, int sectionId);
        Task<IEnumerable<TimeTable>> GetTimeTableByStaffAsync(int staffId);
        Task<bool> CheckTimeSlotConflictAsync(int staffId, DayOfWeek dayOfWeek, TimeSpan startTime, TimeSpan endTime);
        Task<IEnumerable<TimeTable>> GetTimeTableByRoomAsync(string roomNumber);
        Task<IEnumerable<TimeTable>> GetTimeTableForWeekAsync(int classId, int sectionId, DateTime weekStart);

        /// <summary>Class timetable entries with Subject/Staff/Section names resolved.</summary>
        Task<List<TimeTable>> GetByClassWithDetailsAsync(int classId);
        /// <summary>First section of a class — used to default SectionId when the client omits it.</summary>
        Task<int> GetDefaultSectionIdAsync(int classId);
        /// <summary>Replaces the class timetable with a generated schedule built from the class's subjects and available staff.</summary>
        Task<List<TimeTable>> GenerateForClassAsync(int classId);
    }

    public interface IExaminationRepository : IGenericRepository<Examination>
    {
        Task<IEnumerable<Examination>> GetExaminationsByAcademicYearAsync(int academicYearId);
        Task<Examination> GetExaminationWithSchedulesAsync(int id);
        Task<IEnumerable<Examination>> GetUpcomingExaminationsAsync();
        Task<IEnumerable<Examination>> GetExaminationsByTypeAsync(int examinationTypeId);
    }

    public interface IExaminationTypeRepository : IGenericRepository<ExaminationType>
    {
        Task<IEnumerable<ExaminationType>> GetActiveExaminationTypesAsync();
    }

    public interface IExamScheduleRepository : IGenericRepository<ExamSchedule>
    {
        Task<IEnumerable<ExamSchedule>> GetSchedulesByExaminationAsync(int examinationId);
        Task<IEnumerable<ExamSchedule>> GetSchedulesByClassAsync(int classId);
        Task<IEnumerable<ExamSchedule>> GetSchedulesByDateRangeAsync(DateTime startDate, DateTime endDate);
    }

    public interface IAcademicYearRepository : IGenericRepository<AcademicYear>
    {
        Task<AcademicYear> GetCurrentAcademicYearAsync();
        Task<IEnumerable<AcademicYear>> GetActiveAcademicYearsAsync();
    }

    public interface IStudentPromotionRepository : IGenericRepository<StudentPromotion>
    {
        Task<IEnumerable<StudentPromotion>> GetPromotionsByAcademicYearAsync(int academicYearId);
        Task<StudentPromotion> GetPromotionByStudentAsync(int studentId, int academicYearId);
    }

    public interface IGradingSchemeRepository : IGenericRepository<GradingScheme>
    {
        Task<IEnumerable<GradingScheme>> GetActiveGradingSchemesAsync();
        Task<GradingScheme> GetGradeByMarksAsync(decimal marks);
    }

    public interface IAssignmentRepository : IGenericRepository<Assignment>
    {
        /// <summary>All assignments with Class/Subject/Section loaded, so DTO
        /// mappers can resolve display names (className/subjectName).</summary>
        Task<IEnumerable<Assignment>> GetAllWithNavigationsAsync();
        Task<IEnumerable<Assignment>> GetAssignmentsByClassAsync(int classId, int sectionId);
        Task<IEnumerable<Assignment>> GetAssignmentsByStudentAsync(int studentId);
        Task<IEnumerable<Assignment>> GetAssignmentsByStaffAsync(int staffId);
        Task<IEnumerable<Assignment>> GetPendingAssignmentsAsync(int studentId);
        Task<IEnumerable<Assignment>> GetOverdueAssignmentsAsync();
    }

    public interface IAssignmentSubmissionRepository : IGenericRepository<AssignmentSubmission>
    {
        Task<IEnumerable<AssignmentSubmission>> GetSubmissionsByAssignmentAsync(int assignmentId);
        Task<AssignmentSubmission> GetSubmissionByStudentAndAssignmentAsync(int studentId, int assignmentId);
        Task<IEnumerable<AssignmentSubmission>> GetPendingGradingAsync(int staffId);
    }

    public interface IExamResultRepository : IGenericRepository<ExamResult>
    {
        Task<IEnumerable<ExamResult>> GetResultsByStudentAsync(int studentId);
        Task<IEnumerable<ExamResult>> GetResultsByFiltersAsync(int? studentId = null, string? examType = null, int? subjectId = null);
    }
}
