
namespace SchoolManagementApp.ApplicationCore.Academic.Interfaces
{
    /// <summary>
    /// Service interface for Advanced Academic operations
    /// </summary>
    public interface IAdvancedAcademicService
    {
        // Timetable Operations
        Task<IEnumerable<TimeTable>> GetTimeTableByClassAsync(int classId, int sectionId);
        Task<IEnumerable<TimeTable>> GetTimeTableByStaffAsync(int staffId);
        Task<TimeTable> CreateTimeTableAsync(TimeTable timeTable, string? staffUserId);
        Task<bool> CheckTimeSlotConflictAsync(int staffId, DayOfWeek dayOfWeek, TimeSpan startTime, TimeSpan endTime);
        Task<IEnumerable<TimeTable>> GetTimetablesAsync(int page, int pageSize);
        Task UpdateTimetableAsync(int id, TimeTable timeTable);
        Task DeleteTimetableAsync(int id);
        Task<List<object>> GetTimetableConflictsAsync(int? staffId);
        Task<string> ExportTimetableCsvAsync(int classId);

        // Examination Operations
        Task<IEnumerable<Examination>> GetExaminationsAsync(int? academicYearId, int? typeId);
        Task<Examination> CreateExaminationAsync(Examination examination, string? createdByUserId);
        Task<Examination> UpdateExaminationAsync(int id, Examination examination);
        Task DeleteExaminationAsync(int id);
        Task<IEnumerable<ExamSchedule>> GetExamSchedulesAsync(int examinationId);
        Task<ExamSchedule> CreateExamScheduleAsync(int examinationId, ExamSchedule schedule);
        Task<object> GetExaminationReportAsync(int id);
        Task<string> ExportExaminationCsvAsync(int id);

        // Assignment Operations
        Task<IEnumerable<Assignment>> GetAssignmentsByClassAsync(int classId, int sectionId);
        Task<IEnumerable<Assignment>> GetAssignmentsByStudentAsync(int studentId);
        Task<Assignment> CreateAssignmentAsync(Assignment assignment, string? createdByUserId);
        Task<AssignmentSubmission> SubmitAssignmentAsync(int assignmentId, AssignmentSubmission submission);
        Task<IEnumerable<AssignmentSubmission>> GetAssignmentSubmissionsAsync(int assignmentId);
        Task GradeSubmissionAsync(int submissionId, decimal marks, string feedback, string? graderUserId);
        Task UpdateAssignmentAsync(int id, Assignment assignment);
        Task DeleteAssignmentAsync(int id);
        Task GradeAssignmentForStudentAsync(int assignmentId, int studentId, decimal marks, string? feedback, string? graderUserId);
        Task BulkGradeAssignmentsAsync(int assignmentId, IEnumerable<GradeAssignmentRequest> grades, string? graderUserId);
        Task<string> ExportAssignmentGradesCsvAsync(int assignmentId);
        Task<IEnumerable<Assignment>> GetFilteredAssignmentsAsync(Dictionary<string, string> filters);

        // Academic Year Operations
        Task<IEnumerable<AcademicYear>> GetAcademicYearsAsync();
        Task<AcademicYear> GetCurrentAcademicYearAsync();

        // Grading Operations
        Task<IEnumerable<GradingScheme>> GetGradingSchemesAsync();
        Task<GradingScheme> CreateGradingSchemeAsync(GradingScheme scheme);
        Task UpdateGradingSchemeAsync(int id, GradingScheme scheme);
        Task DeleteGradingSchemeAsync(int id);
        Task<GradingScheme> CalculateGradeAsync(decimal marks);

        // Exam Results Operations
        Task<IEnumerable<ExamResult>> GetResultsAsync(int? studentId, string? examType, int? subjectId);
        Task<ExamResult> CreateResultAsync(ExamResult result);
        Task UpdateResultAsync(int id, ExamResult result);
        Task DeleteResultAsync(int id);

        // Analytics
        Task<object> GetTeacherWorkloadAsync(int? teacherId);
        Task<object> GetClassroomUtilizationAsync();
        Task<object> GetAssignmentStatisticsAsync(int? classId);
    }

    // NOTE: GradeSubmissionRequest and GradeAssignmentRequest are defined in IAdvancedAcademicAppService.cs (canonical version)
    // This file only contains the deprecated interface definition
}
