using AutoMapper;
using SchoolManagementApp.ApplicationCore.Entities;
using SchoolManagementApp.ApplicationCore.Academic.Dtos;

namespace SchoolManagementApp.ApplicationCore.Academic
{
    public class AcademicObjectMapping : Profile
    {
        public AcademicObjectMapping()
        {
            // TODO: Academic entity not yet defined in Entities namespace
            // CreateMap<SchoolManagementApp.ApplicationCore.Entities.Academic, AcademicDto>().ReverseMap();
        }
    }
}
