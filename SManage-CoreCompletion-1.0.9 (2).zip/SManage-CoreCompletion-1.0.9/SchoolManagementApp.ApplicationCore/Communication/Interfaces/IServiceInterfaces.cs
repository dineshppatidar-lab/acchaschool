using Microsoft.AspNetCore.Http;

namespace SchoolManagementApp.ApplicationCore.Communication.Interfaces
{
    public interface IRealtimeNotificationService
    {
        Task NotifyAssignmentDeadlineAsync(int studentId, string assignmentTitle, DateTime deadline);
        Task NotifyAssignmentSubmittedAsync(int staffId, string studentName, string assignmentTitle);
        Task NotifyAssignmentGradedAsync(int studentId, string assignmentTitle, string grade);
        Task NotifyExamScheduleAsync(int studentId, string examName, DateTime examDate, string venue);
        Task NotifyExamResultPublishedAsync(int studentId, string examName);
        Task NotifyExamCancelledAsync(IEnumerable<int> studentIds, string examName, string reason);
        Task NotifyFeePaymentDueAsync(int studentId, decimal amount, DateTime dueDate, string feeType);
        Task NotifyFeePaymentReceivedAsync(int studentId, decimal amount, string receiptNumber);
        Task NotifyScholarshipApprovedAsync(int studentId, string scholarshipName, decimal amount);
        Task NotifyLowAttendanceAsync(int studentId, double attendancePercentage);
        Task NotifyAbsentAsync(int parentId, string studentName, DateTime date);
        Task NotifyAttendanceAlertAsync(IEnumerable<int> parentIds, string message);
        Task NotifyBookDueDateAsync(int memberId, string memberType, string bookTitle, DateTime dueDate);
        Task NotifyBookOverdueAsync(int memberId, string memberType, string bookTitle, int overdueDays);
        Task NotifyBookReservedAsync(int memberId, string memberType, string bookTitle);
        Task NotifyBookAvailableAsync(int memberId, string memberType, string bookTitle);
        Task NotifyMeetingScheduledAsync(int parentId, int teacherId, DateTime meetingDateTime, string purpose);
        Task NotifyMeetingRescheduledAsync(int parentId, int teacherId, DateTime oldDateTime, DateTime newDateTime);
        Task NotifyMeetingCancelledAsync(int parentId, int teacherId, DateTime meetingDateTime, string reason);
        Task NotifySystemMaintenanceAsync(IEnumerable<int> userIds, DateTime scheduledTime, string duration);
        Task NotifySystemUpdateAsync(IEnumerable<int> userIds, string updateDetails);
        Task NotifyEmergencyAsync(IEnumerable<int> userIds, string emergencyMessage, string alertLevel);
        Task NotifyAcademicProgressAsync(int studentId, string subject, string progressDetails);
        Task NotifyMonthlyReportReadyAsync(int parentId, string studentName, string month);
        Task AddUserToGroupAsync(string userId, string groupName);
        Task RemoveUserFromGroupAsync(string userId, string groupName);
        Task SendGroupNotificationAsync(string groupName, string message, string type = "info");
        Task SendNotificationAsync(string type, string message, IEnumerable<string> recipients);
        Task SendNotificationToGroupAsync(string groupName, string type, string message);
        Task SendBulkNotificationAsync(string type, string message, IEnumerable<int> userIds);
    }

    public interface IEmailService
    {
        Task SendEmailAsync(string to, string subject, string body, bool isHtml = true);
        Task SendEmailAsync(string to, string subject, string body, IEnumerable<string>? cc, IEnumerable<string>? bcc, bool isHtml = true);
        Task SendBulkEmailAsync(IEnumerable<string> recipients, string subject, string body, bool isHtml = true);
        Task SendWelcomeEmailAsync(string email, string userName, string tempPassword, string schoolName);
        Task SendPasswordResetEmailAsync(string email, string resetToken, string userName);
        Task SendAssignmentReminderEmailAsync(string email, string studentName, string assignmentTitle, DateTime dueDate);
        Task SendExamNotificationEmailAsync(string email, string studentName, string examName, DateTime examDate, string venue);
        Task SendFeeReminderEmailAsync(string email, string parentName, string studentName, decimal amount, DateTime dueDate, string feeType);
        Task SendAttendanceAlertEmailAsync(string email, string parentName, string studentName, double attendancePercentage);
        Task SendMeetingConfirmationEmailAsync(string email, string participantName, string meetingType, DateTime meetingDateTime, string agenda);
        Task SendSystemAlertEmailAsync(string email, string userName, string alertTitle, string alertMessage, string severity);
        Task SendReportEmailAsync(string email, string recipientName, string reportTitle, byte[] reportData, string fileName);
        Task SendAnnouncementEmailAsync(IEnumerable<string> emails, string subject, string announcement, string senderName);
        Task SendEventInvitationEmailAsync(string email, string participantName, string eventName, DateTime eventDate, string venue, string description);
        Task<bool> ValidateEmailAddressAsync(string email);
        Task<string> GetEmailTemplateAsync(string templateName);
        Task SendTemplatedEmailAsync(string email, string templateName, object data);
        Task SendAssignmentReminderAsync(int studentId, string assignmentTitle, DateTime dueDate);
        Task SendAttendanceAlertToParentsAsync(int studentId, double attendancePercentage, int absentDays);
        Task SendMeetingConfirmationAsync(int parentId, int teacherId, DateTime meetingDateTime, string purpose);
    }

    public interface ISmsService
    {
        Task SendSmsAsync(string phoneNumber, string message);
        Task SendBulkSmsAsync(IEnumerable<string> phoneNumbers, string message);
        Task SendOtpAsync(string phoneNumber, string otp, int expiryMinutes = 5);
        Task SendWelcomeSmsAsync(string phoneNumber, string userName, string schoolName);
        Task SendAttendanceAlertAsync(string phoneNumber, string studentName, double attendancePercentage);
        Task SendFeeReminderAsync(int studentId, decimal amount, DateTime dueDate, string feeType);
        Task SendExamReminderAsync(string phoneNumber, string studentName, string examName, DateTime examDate);
        Task SendResultNotificationAsync(string phoneNumber, string studentName, string examName, string result);
        Task SendEmergencyAlertAsync(IEnumerable<string> phoneNumbers, string alertMessage);
        Task SendHolidayNotificationAsync(IEnumerable<string> phoneNumbers, string holidayName, DateTime startDate, DateTime endDate);
        Task SendEventReminderAsync(string phoneNumber, string eventName, DateTime eventDate, string venue);
        Task SendLibraryReminderAsync(string phoneNumber, string studentName, string bookTitle, DateTime dueDate);
        Task SendTransportAlertAsync(string phoneNumber, string studentName, string alertType, string details);
        Task SendMeetingReminderAsync(string phoneNumber, string recipientName, string meetingType, DateTime meetingDateTime);
        Task<bool> ValidatePhoneNumberAsync(string phoneNumber);
        Task<SmsDeliveryStatus> GetDeliveryStatusAsync(string messageId);
        Task SendBulkSMSAsync(IEnumerable<string> phoneNumbers, string message);
    }

    public interface IFileStorageService
    {
        Task<FileUploadResult> UploadFileAsync(IFormFile file, string category, int? userId = null);
        Task<FileUploadResult> UploadMultipleFilesAsync(IEnumerable<IFormFile> files, string category, int? userId = null);
        Task<FileDownloadResult> GetFileAsync(Guid fileId);
        Task<FileDownloadResult> GetFileByPathAsync(string filePath);
        Task<bool> DeleteFileAsync(Guid fileId);
        Task<bool> DeleteFilesByUserAsync(int userId);
        Task<List<FileMetadata>> GetFilesByCategoryAsync(string category, int pageNumber = 1, int pageSize = 50);
        Task<List<FileMetadata>> GetFilesByUserAsync(int userId);
        Task<StorageStats> GetStorageStatsAsync();
        Task CleanupOrphanedFilesAsync();
    }

    public interface IPaymentGatewayService
    {
        Task<PaymentResponse> InitiatePaymentAsync(PaymentRequest request);
        Task<PaymentVerificationResult> VerifyPaymentAsync(PaymentVerificationRequest request);
        Task<RefundResponse> ProcessRefundAsync(RefundRequest request);
        Task<PaymentStatusResult> GetPaymentStatusAsync(string paymentId);
        Task<List<PaymentHistoryItem>> GetPaymentHistoryAsync(int studentId, DateTime? fromDate = null, DateTime? toDate = null);
        Task<bool> ValidateWebhookSignatureAsync(string payload, string signature, string secret);
    }

    public interface IBackupService
    {
        Task<BackupResult> CreateFullBackupAsync(string backupName = "");
        Task<BackupResult> CreateDatabaseBackupAsync(string backupName = "");
        Task<RestoreResult> RestoreBackupAsync(Guid backupId, RestoreOptions options);
        Task<List<BackupInfo>> GetBackupHistoryAsync(int pageNumber = 1, int pageSize = 20);
        Task<bool> DeleteBackupAsync(Guid backupId);
        Task CleanupOldBackupsAsync();
        Task<BackupValidationResult> ValidateBackupAsync(Guid backupId);
    }

    //[Obsolete("Use SchoolManagementApp.ApplicationCore.Common.Services.IAuditService instead. This interface will be removed in Phase 2.")]
    //public interface IAuditService : SchoolManagementApp.ApplicationCore.Common.Services.IAuditService { }

    //[Obsolete("Use SchoolManagementApp.ApplicationCore._Interfaces.ITenantProvider instead. This interface will be removed in Phase 2.")]
    //public interface ITenantProvider : SchoolManagementApp.ApplicationCore._Interfaces.ITenantProvider { }

    // Service Models
    public class SmsDeliveryStatus
    {
        public string MessageId { get; set; } = string.Empty;
        public string Status { get; set; } = string.Empty;
        public DateTime? DeliveredAt { get; set; }
        public string? FailureReason { get; set; }
    }

    public class FileMetadata
    {
        public Guid Id { get; set; }
        public string OriginalFileName { get; set; } = string.Empty;
        public string StoredFileName { get; set; } = string.Empty;
        public string FilePath { get; set; } = string.Empty;
        public string? ThumbnailPath { get; set; }
        public long FileSize { get; set; }
        public string ContentType { get; set; } = string.Empty;
        public string Category { get; set; } = string.Empty;
        public int? UploadedBy { get; set; }
        public DateTime UploadedAt { get; set; }
        public string FileHash { get; set; } = string.Empty;
        public bool IsActive { get; set; } = true;
    }

    public class FileUploadResult
    {
        public bool IsSuccess { get; set; }
        public Guid FileId { get; set; }
        public string? FileName { get; set; }
        public string? FilePath { get; set; }
        public string? ThumbnailPath { get; set; }
        public long FileSize { get; set; }
        public string? ContentType { get; set; }
        public string? FileUrl { get; set; }
        public string? Message { get; set; }
        public string? ErrorMessage { get; set; }
        public List<FileUploadResult>? UploadResults { get; set; }
    }

    public class FileDownloadResult
    {
        public bool IsSuccess { get; set; }
        public byte[]? FileBytes { get; set; }
        public string? FileName { get; set; }
        public string? ContentType { get; set; }
        public long FileSize { get; set; }
        public string? ErrorMessage { get; set; }
    }

    public class StorageStats
    {
        public int TotalFiles { get; set; }
        public long TotalSizeBytes { get; set; }
        public Dictionary<string, CategoryStats> CategoryStats { get; set; } = new();
    }

    public class CategoryStats
    {
        public int FileCount { get; set; }
        public long TotalSizeBytes { get; set; }
    }

    public class PaymentRequest
    {
        public int StudentId { get; set; }
        public decimal Amount { get; set; }
        public string FeeType { get; set; } = string.Empty;
        public string AcademicYear { get; set; } = string.Empty;
        public string StudentName { get; set; } = string.Empty;
        public string StudentEmail { get; set; } = string.Empty;
        public string StudentPhone { get; set; } = string.Empty;
        public Dictionary<string, string> AdditionalInfo { get; set; } = new();
    }

    public class PaymentResponse
    {
        public bool IsSuccess { get; set; }
        public string OrderId { get; set; } = string.Empty;
        public decimal Amount { get; set; }
        public string Currency { get; set; } = string.Empty;
        public string KeyId { get; set; } = string.Empty;
        public int StudentId { get; set; }
        public string FeeType { get; set; } = string.Empty;
        public string CallbackUrl { get; set; } = string.Empty;
        public string Message { get; set; } = string.Empty;
        public string ErrorCode { get; set; } = string.Empty;
    }

    public class PaymentVerificationRequest
    {
        public string PaymentId { get; set; } = string.Empty;
        public string OrderId { get; set; } = string.Empty;
        public string Signature { get; set; } = string.Empty;
    }

    public class PaymentVerificationResult
    {
        public bool IsSuccess { get; set; }
        public string Status { get; set; } = string.Empty;
        public string PaymentId { get; set; } = string.Empty;
        public string OrderId { get; set; } = string.Empty;
        public decimal Amount { get; set; }
        public string Method { get; set; } = string.Empty;
        public DateTime TransactionDate { get; set; }
        public string Message { get; set; } = string.Empty;
    }

    public class RefundRequest
    {
        public string PaymentId { get; set; } = string.Empty;
        public decimal Amount { get; set; }
        public string Reason { get; set; } = string.Empty;
        public string RequestedBy { get; set; } = string.Empty;
        public int? StudentId { get; set; }
        public string? Speed { get; set; } = "normal";
    }

    public class RefundResponse
    {
        public bool IsSuccess { get; set; }
        public string RefundId { get; set; } = string.Empty;
        public string PaymentId { get; set; } = string.Empty;
        public decimal Amount { get; set; }
        public string Status { get; set; } = string.Empty;
        public string Message { get; set; } = string.Empty;
        public string ErrorCode { get; set; } = string.Empty;
    }

    public class PaymentStatusResult
    {
        public bool IsSuccess { get; set; }
        public string PaymentId { get; set; } = string.Empty;
        public string Status { get; set; } = string.Empty;
        public decimal Amount { get; set; }
        public string Method { get; set; } = string.Empty;
        public DateTime CreatedAt { get; set; }
        public string Message { get; set; } = string.Empty;
    }

    public class PaymentHistoryItem
    {
        public string PaymentId { get; set; } = string.Empty;
        public string OrderId { get; set; } = string.Empty;
        public decimal Amount { get; set; }
        public string Status { get; set; } = string.Empty;
        public string Method { get; set; } = string.Empty;
        public string FeeType { get; set; } = string.Empty;
        public DateTime TransactionDate { get; set; }
        public string Description { get; set; } = string.Empty;
    }

    public class BackupInfo
    {
        public Guid Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public BackupType Type { get; set; }
        public BackupStatus Status { get; set; }
        public string FilePath { get; set; } = string.Empty;
        public long SizeBytes { get; set; }
        public DateTime StartTime { get; set; }
        public DateTime? EndTime { get; set; }
        public string CreatedBy { get; set; } = string.Empty;
        public string? ErrorMessage { get; set; }
        public TimeSpan? Duration => EndTime - StartTime;
    }

    public class BackupResult
    {
        public bool IsSuccess { get; set; }
        public Guid BackupId { get; set; }
        public string? BackupPath { get; set; }
        public long SizeBytes { get; set; }
        public TimeSpan? Duration { get; set; }
        public string? Message { get; set; }
        public string? ErrorMessage { get; set; }
    }

    public class RestoreResult
    {
        public bool IsSuccess { get; set; }
        public Guid RestoreId { get; set; }
        public string? Message { get; set; }
        public string? ErrorMessage { get; set; }
        public List<string> RestoredComponents { get; set; } = new();
    }

    public class RestoreOptions
    {
        public bool RestoreDatabase { get; set; } = true;
        public bool RestoreFiles { get; set; } = true;
        public bool RestoreConfiguration { get; set; } = false;
        public bool BackupExisting { get; set; } = true;
        public bool ContinueOnError { get; set; } = false;
        public string? RestoreToPath { get; set; }
    }

    public class BackupValidationResult
    {
        public bool IsValid { get; set; }
        public List<string> ValidationIssues { get; set; } = new();
        public long BackupSize { get; set; }
        public string? ErrorMessage { get; set; }
    }

    public enum BackupType { Full, Database, Files, Configuration }
    public enum BackupStatus { Scheduled, InProgress, Completed, Failed, Cancelled }
}
