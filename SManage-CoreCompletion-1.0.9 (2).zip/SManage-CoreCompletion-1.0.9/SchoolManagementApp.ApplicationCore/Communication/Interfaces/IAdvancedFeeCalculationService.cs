using SchoolManagementApp.ApplicationCore.Fees.Dtos;
using SchoolManagementApp.ApplicationCore.Entities;

namespace SchoolManagementApp.ApplicationCore.Communication.Interfaces
{
    /// <summary>
    /// Service interface for Advanced Fee Calculation operations
    /// This is the canonical location for this interface
    /// </summary>
    public interface IAdvancedFeeCalculationService
    {
        // Core Calculation Methods
        Task<StudentFinalFeeDto> CalculateFinalStudentFeesAsync(int studentId, int academicYearId);
        Task<decimal> CalculateInstallmentAmountAfterAdjustmentsAsync(int studentId, int installmentId);
        Task<decimal> CalculateOutstandingBalanceAsync(int studentId, int academicYearId);

        // Waiver & Discount Management
        Task<StudentFeeAdjustment> CreateOrUpdateWaiverAsync(CreateWaiverRequest request);
        Task<StudentFeeAdjustment> CreateOrUpdateDiscountAsync(CreateDiscountRequest request);
        Task<bool> RevokeAdjustmentAsync(int adjustmentId);
        Task<IEnumerable<StudentFeeAdjustment>> GetStudentAdjustmentsAsync(int studentId, int academicYearId);

        // Group Payments
        Task<GroupPayment> InitiateGroupPaymentAsync(InitiateGroupPaymentRequest request);
        Task<GroupPaymentProcessResult> ProcessGroupPaymentAsync(ProcessGroupPaymentRequest request);
        Task<FamilyPaymentSummaryDto> GetFamilyPaymentSummaryAsync(int familyGroupId, int academicYearId);
    }
}
