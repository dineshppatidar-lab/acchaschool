namespace SchoolManagementApp.ApplicationCore.Communication.Interfaces
{
    /// <summary>
    /// Service interface for Communication operations
    /// Moved from Students/Interfaces/ per CorporateFleet module pattern.
    /// DTOs are defined in ICommunicationService.cs in this same namespace.
    /// </summary>
    public interface ICommunicationAppService
    {
        // Message Management
        Task<IEnumerable<Message>> GetMessagesAsync(int userId, string userType, string? messageType, string? status, string? search);
        Task<IEnumerable<Message>> GetUnreadMessagesAsync(int userId, string userType);
        Task<MessageStatsDto> GetMessageStatsAsync(int userId, string userType);
        Task<Message> SendMessageAsync(SendMessageDto request);
        Task<Message> UpdateMessageAsync(int id, SendMessageDto request);
        Task<MessageReply> ReplyToMessageAsync(int messageId, ReplyMessageDto request);
        Task MarkMessageAsReadAsync(int messageId, int userId);

        // Announcement Management
        Task<IEnumerable<Announcement>> GetAnnouncementsAsync(string? targetType, int? targetId, string currentUserType, int currentUserId);
        Task<Announcement> CreateAnnouncementAsync(CreateAnnouncementDto request, int createdBy);
        Task<Announcement> UpdateAnnouncementAsync(int id, CreateAnnouncementDto request, int updatedBy);

        // Event Management
        Task<IEnumerable<Event>> GetEventsAsync(DateTime? startDate, DateTime? endDate, int upcoming, int currentUserId, string currentUserType);
        Task<Event> GetEventDetailsAsync(int id);
        Task<Event> CreateEventAsync(CreateEventDto request, int organizedBy);
        Task<Event> UpdateEventAsync(int id, CreateEventDto request, int updatedBy);

        // Parent-Teacher Meetings
        Task<IEnumerable<ParentTeacherMeeting>> GetMeetingsAsync(string userType, int userId);
        Task<ParentTeacherMeeting> ScheduleMeetingAsync(ScheduleMeetingDto request, int createdBy);

        // Bulk Communication
        Task SendBulkNotificationAsync(BulkNotificationDto request);
        Task SendBulkEmailAsync(BulkEmailDto request);
        Task SendBulkSMSAsync(BulkSMSDto request);
    }
}
