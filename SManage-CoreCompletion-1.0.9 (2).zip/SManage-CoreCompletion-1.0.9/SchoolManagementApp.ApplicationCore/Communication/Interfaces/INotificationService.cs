using SchoolManagementApp.ApplicationCore.Entities;

namespace SchoolManagementApp.ApplicationCore.Communication.Interfaces
{
    /// <summary>
    /// Service interface for notification management operations.
    /// </summary>
    public interface INotificationService
    {
        /// <summary>
        /// Get notifications for a specific user
        /// </summary>
        Task<IEnumerable<Notification>> GetNotificationsByUserIdAsync(int userId, int take = 100);

        /// <summary>
        /// Create a new notification
        /// </summary>
        Task<Notification> CreateNotificationAsync(Notification notification);

        /// <summary>
        /// Mark a notification as read
        /// </summary>
        Task<Notification?> MarkAsReadAsync(int id, int userId);

        /// <summary>
        /// Mark all notifications for a user as read
        /// </summary>
        Task<int> MarkAllAsReadAsync(int userId);

        /// <summary>
        /// Get unread notification count for a user
        /// </summary>
        Task<int> GetUnreadCountAsync(int userId);

        /// <summary>
        /// Delete a notification
        /// </summary>
        Task DeleteNotificationAsync(int id, int userId);
    }
}
