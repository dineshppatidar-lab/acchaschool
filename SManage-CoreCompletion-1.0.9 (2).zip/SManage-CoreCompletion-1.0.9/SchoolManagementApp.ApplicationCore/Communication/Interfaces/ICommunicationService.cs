
namespace SchoolManagementApp.ApplicationCore.Communication.Interfaces
{
    public interface ICommunicationService
    {
        // Message Management
        Task<IEnumerable<Message>> GetMessagesAsync(int userId, string userType, string? messageType, string? status, string? search);
        Task<IEnumerable<Message>> GetUnreadMessagesAsync(int userId, string userType);
        Task<MessageStatsDto> GetMessageStatsAsync(int userId, string userType);
        Task<Message> SendMessageAsync(SendMessageDto request);
        Task<Message> UpdateMessageAsync(int id, SendMessageDto request);
        Task<MessageReply> ReplyToMessageAsync(int messageId, ReplyMessageDto request);
        Task MarkMessageAsReadAsync(int messageId, int userId);

        // Announcement Management
        Task<IEnumerable<Announcement>> GetAnnouncementsAsync(string? targetType, int? targetId, string currentUserType, int currentUserId);
        Task<Announcement> CreateAnnouncementAsync(CreateAnnouncementDto request, int createdBy);
        Task<Announcement> UpdateAnnouncementAsync(int id, CreateAnnouncementDto request, int updatedBy);

        // Event Management
        Task<IEnumerable<Event>> GetEventsAsync(DateTime? startDate, DateTime? endDate, int upcoming, int currentUserId, string currentUserType);
        Task<Event> GetEventDetailsAsync(int id);
        Task<Event> CreateEventAsync(CreateEventDto request, int organizedBy);
        Task<Event> UpdateEventAsync(int id, CreateEventDto request, int updatedBy);

        // Parent-Teacher Meetings
        Task<IEnumerable<ParentTeacherMeeting>> GetMeetingsAsync(string userType, int userId);
        Task<ParentTeacherMeeting> ScheduleMeetingAsync(ScheduleMeetingDto request, int createdBy);

        // Bulk Communication
        Task SendBulkNotificationAsync(BulkNotificationDto request);
        Task SendBulkEmailAsync(BulkEmailDto request);
        Task SendBulkSMSAsync(BulkSMSDto request);
    }

    // DTOs for Communication Service
    public class MessageStatsDto
    {
        public int UnreadCount { get; set; }
        public int TodayCount { get; set; }
        public int TotalCount { get; set; }
    }

    public class SendMessageDto
    {
        public string Subject { get; set; } = string.Empty;
        public string Content { get; set; } = string.Empty;
        public int SenderId { get; set; }
        public string SenderType { get; set; } = string.Empty;
        public string SenderName { get; set; } = string.Empty;
        public MessagePriority Priority { get; set; } = MessagePriority.Normal;
        public MessageType Type { get; set; } = MessageType.General;
        public string AttachmentPath { get; set; } = string.Empty;
        public bool SendEmailNotification { get; set; }
        public List<RecipientDto> Recipients { get; set; } = new List<RecipientDto>();
    }

    public class RecipientDto
    {
        public int RecipientId { get; set; }
        public string RecipientType { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
    }

    public class ReplyMessageDto
    {
        public string Content { get; set; } = string.Empty;
        public int SenderId { get; set; }
        public string SenderType { get; set; } = string.Empty;
        public string AttachmentPath { get; set; } = string.Empty;
    }

    public class CreateAnnouncementDto
    {
        public string Title { get; set; } = string.Empty;
        public string Content { get; set; } = string.Empty;
        public AnnouncementType Type { get; set; }
        public AnnouncementPriority Priority { get; set; } = AnnouncementPriority.Normal;
        public DateTime? ValidFrom { get; set; }
        public DateTime? ValidTo { get; set; }
        public string TargetAudience { get; set; } = "All";
        public string AttachmentPath { get; set; } = string.Empty;
    }

    public class CreateEventDto
    {
        public string Title { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public EventType Type { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string Location { get; set; } = string.Empty;
        public bool IsAllDay { get; set; }
        public bool IsPublic { get; set; } = true;
        public string Color { get; set; } = "#1976d2";
        public int? MaxParticipants { get; set; }
    }

    public class ScheduleMeetingDto
    {
        public int ParentId { get; set; }
        public int StaffId { get; set; }
        public int StudentId { get; set; }
        public DateTime ScheduledDate { get; set; }
        public TimeSpan StartTime { get; set; }
        public TimeSpan EndTime { get; set; }
        public string Purpose { get; set; } = string.Empty;
        public string Location { get; set; } = string.Empty;
    }

    public class BulkNotificationDto
    {
        public IEnumerable<int>? UserIds { get; set; }
        public string? GroupName { get; set; }
        public string Message { get; set; } = string.Empty;
        public string Type { get; set; } = "info";
    }

    public class BulkEmailDto
    {
        public IEnumerable<string> Recipients { get; set; } = new List<string>();
        public string Subject { get; set; } = string.Empty;
        public string Body { get; set; } = string.Empty;
        public bool IsHtml { get; set; } = true;
    }

    public class BulkSMSDto
    {
        public IEnumerable<string> PhoneNumbers { get; set; } = new List<string>();
        public string Message { get; set; } = string.Empty;
    }
}
