
namespace SchoolManagementApp.ApplicationCore.Communication.Interfaces
{
    public interface IMessageRepository : IGenericRepository<Message>
    {
        Task<IEnumerable<Message>> GetMessagesByUserAsync(int userId, string userType);
        Task<IEnumerable<Message>> GetMessagesWithFiltersAsync(int userId, string userType, string? type = null, string? status = null, string? search = null);
        Task<IEnumerable<Message>> GetSentMessagesAsync(int senderId);
        Task<Message> GetMessageWithRepliesAsync(int id);
        Task<IEnumerable<Message>> GetUnreadMessagesAsync(int userId, string userType);
        Task MarkMessageAsReadAsync(int messageId, int userId);
        Task<object> GetMessageStatsAsync(int userId, string userType);
    }

    public interface IMessageRecipientRepository : IGenericRepository<MessageRecipient>
    {
        Task<IEnumerable<MessageRecipient>> GetRecipientsByMessageAsync(int messageId);
    }

    public interface IMessageReplyRepository : IGenericRepository<MessageReply>
    {
        Task<IEnumerable<MessageReply>> GetRepliesByMessageAsync(int messageId);
    }

    public interface IAnnouncementRepository : IGenericRepository<Announcement>
    {
        Task<IEnumerable<Announcement>> GetActiveAnnouncementsAsync();
        Task<IEnumerable<Announcement>> GetAnnouncementsByTargetAsync(string targetType, int? targetId);
        Task<IEnumerable<Announcement>> GetAnnouncementsByTypeAsync(AnnouncementType type);
        Task<IEnumerable<Announcement>> GetAnnouncementsByDateRangeAsync(DateTime startDate, DateTime endDate);
    }

    public interface IEventRepository : IGenericRepository<Event>
    {
        Task<IEnumerable<Event>> GetEventsByDateRangeAsync(DateTime startDate, DateTime endDate);
        Task<IEnumerable<Event>> GetUpcomingEventsAsync(int days = 30);
        Task<Event> GetEventWithParticipantsAsync(int id);
        Task<IEnumerable<Event>> GetEventsByTypeAsync(EventType type);
        Task<IEnumerable<Event>> GetEventsByParticipantAsync(int participantId, string participantType);
    }

    public interface IParentTeacherMeetingRepository : IGenericRepository<ParentTeacherMeeting>
    {
        Task<IEnumerable<ParentTeacherMeeting>> GetMeetingsByParentAsync(int parentId);
        Task<IEnumerable<ParentTeacherMeeting>> GetMeetingsByStaffAsync(int staffId);
        Task<IEnumerable<ParentTeacherMeeting>> GetMeetingsByDateRangeAsync(DateTime startDate, DateTime endDate);
        Task<IEnumerable<ParentTeacherMeeting>> GetUpcomingMeetingsAsync();
    }

    // NOTE: ICommunicationService is defined in ICommunicationService.cs (canonical version)
    // This file only contains repository interfaces
}
