using FluentValidation;
using SchoolManagementApp.ApplicationCore.Communication.Dtos;

namespace SchoolManagementApp.ApplicationCore.Communication.Validators
{
    public class CommunicationRequestValidator : AbstractValidator<CommunicationDto>
    {
        public CommunicationRequestValidator()
        {
            RuleFor(x => x.Subject).NotEmpty().MaximumLength(200);
            RuleFor(x => x.Message).NotEmpty().MaximumLength(2000);
        }
    }
}
