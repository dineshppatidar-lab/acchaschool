using AutoMapper;
using SchoolManagementApp.ApplicationCore.Entities;
using SchoolManagementApp.ApplicationCore.Communication.Dtos;

namespace SchoolManagementApp.ApplicationCore.Communication
{
    public class CommunicationObjectMapping : Profile
    {
        public CommunicationObjectMapping()
        {
            // TODO: Communication entity not yet defined in Entities namespace
            // CreateMap<SchoolManagementApp.ApplicationCore.Entities.Communication, CommunicationDto>().ReverseMap();
        }
    }
}
