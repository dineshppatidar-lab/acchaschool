using Microsoft.Extensions.Logging;
using SchoolManagementApp.ApplicationCore.Communication.Interfaces;
using SchoolManagementApp.ApplicationCore.Entities;
using IMessageRepository = SchoolManagementApp.ApplicationCore.Communication.Interfaces.IMessageRepository;
using IMessageRecipientRepository = SchoolManagementApp.ApplicationCore.Communication.Interfaces.IMessageRecipientRepository;
using IMessageReplyRepository = SchoolManagementApp.ApplicationCore.Communication.Interfaces.IMessageReplyRepository;
using IAnnouncementRepository = SchoolManagementApp.ApplicationCore.Communication.Interfaces.IAnnouncementRepository;
using IEventRepository = SchoolManagementApp.ApplicationCore.Communication.Interfaces.IEventRepository;
using IParentTeacherMeetingRepository = SchoolManagementApp.ApplicationCore.Communication.Interfaces.IParentTeacherMeetingRepository;
using IRealtimeNotificationService = SchoolManagementApp.ApplicationCore.Communication.Interfaces.IRealtimeNotificationService;
using IEmailService = SchoolManagementApp.ApplicationCore.Communication.Interfaces.IEmailService;
using ISmsService = SchoolManagementApp.ApplicationCore.Communication.Interfaces.ISmsService;

namespace SchoolManagementApp.ApplicationCore.Communication.Services
{
    public class CommunicationService : ICommunicationAppService
    {
        private readonly IMessageRepository _messageRepository;
        private readonly IMessageRecipientRepository _messageRecipientRepository;
        private readonly IMessageReplyRepository _messageReplyRepository;
        private readonly IAnnouncementRepository _announcementRepository;
        private readonly IEventRepository _eventRepository;
        private readonly IParentTeacherMeetingRepository _meetingRepository;
        private readonly IRealtimeNotificationService _notificationService;
        private readonly IEmailService _emailService;
        private readonly ISmsService _smsService;
        private readonly ILogger<CommunicationService> _logger;

        public CommunicationService(
            IMessageRepository messageRepository,
            IMessageRecipientRepository messageRecipientRepository,
            IMessageReplyRepository messageReplyRepository,
            IAnnouncementRepository announcementRepository,
            IEventRepository eventRepository,
            IParentTeacherMeetingRepository meetingRepository,
            IRealtimeNotificationService notificationService,
            IEmailService emailService,
            ISmsService smsService,
            ILogger<CommunicationService> logger)
        {
            _messageRepository = messageRepository;
            _messageRecipientRepository = messageRecipientRepository;
            _messageReplyRepository = messageReplyRepository;
            _announcementRepository = announcementRepository;
            _eventRepository = eventRepository;
            _meetingRepository = meetingRepository;
            _notificationService = notificationService;
            _emailService = emailService;
            _smsService = smsService;
            _logger = logger;
        }

        // Message Management
        public async Task<IEnumerable<Message>> GetMessagesAsync(int userId, string userType, string? messageType, string? status, string? search)
        {
            try
            {
                _logger.LogInformation("Getting messages for user {UserId} ({UserType}) - Filter: {MessageType}/{Status}/{Search}",
                    userId, userType, messageType, status, search);

                return await _messageRepository.GetMessagesWithFiltersAsync(userId, userType, messageType, status, search);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving messages for user {UserId}", userId);
                throw;
            }
        }

        public async Task<IEnumerable<Message>> GetUnreadMessagesAsync(int userId, string userType)
        {
            try
            {
                _logger.LogInformation("Getting unread messages for user {UserId}", userId);
                return await _messageRepository.GetUnreadMessagesAsync(userId, userType);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving unread messages for user {UserId}", userId);
                throw;
            }
        }

        public async Task<MessageStatsDto> GetMessageStatsAsync(int userId, string userType)
        {
            try
            {
                var stats = await _messageRepository.GetMessageStatsAsync(userId, userType);
                
                // The repository returns object, so we need to use dynamic or reflection
                // Based on the original controller code, it accessed UnreadCount, TodayCount, TotalCount
                var statsDict = stats as IDictionary<string, object>;
                
                return new MessageStatsDto
                {
                    UnreadCount = statsDict != null && statsDict.ContainsKey("unreadCount") 
                        ? Convert.ToInt32(statsDict["unreadCount"]) 
                        : (statsDict != null && statsDict.ContainsKey("UnreadCount") 
                            ? Convert.ToInt32(statsDict["UnreadCount"]) 
                            : 0),
                    TodayCount = statsDict != null && statsDict.ContainsKey("todayCount") 
                        ? Convert.ToInt32(statsDict["todayCount"]) 
                        : (statsDict != null && statsDict.ContainsKey("TodayCount") 
                            ? Convert.ToInt32(statsDict["TodayCount"]) 
                            : 0),
                    TotalCount = statsDict != null && statsDict.ContainsKey("totalCount") 
                        ? Convert.ToInt32(statsDict["totalCount"]) 
                        : (statsDict != null && statsDict.ContainsKey("TotalCount") 
                            ? Convert.ToInt32(statsDict["TotalCount"]) 
                            : 0)
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving message stats for user {UserId}", userId);
                throw;
            }
        }

        public async Task<Message> SendMessageAsync(SendMessageDto request)
        {
            try
            {
                _logger.LogInformation("Sending message: {Subject}", request.Subject);

                var message = new Message
                {
                    Subject = request.Subject,
                    Content = request.Content,
                    SenderId = request.SenderId,
                    SenderType = request.SenderType,
                    SentDate = DateTime.UtcNow,
                    Priority = request.Priority,
                    Type = request.Type,
                    AttachmentPath = request.AttachmentPath
                };

                var result = await _messageRepository.AddAsync(message);

                // Add recipients
                var recipients = request.Recipients.Select(r => new MessageRecipient
                {
                    MessageId = result.Id,
                    RecipientId = r.RecipientId,
                    RecipientType = r.RecipientType,
                    IsRead = false,
                    TenantId = result.TenantId
                }).ToList();

                await _messageRecipientRepository.AddRangeAsync(recipients);

                // Send real-time notifications
                var recipientIds = request.Recipients.Select(r => r.RecipientId.ToString()).ToList();
                if (recipientIds.Any())
                {
                    await _notificationService.SendNotificationAsync("message", $"New message: {request.Subject}", recipientIds);
                }

                // Send email notifications if enabled
                if (request.SendEmailNotification)
                {
                    var emails = request.Recipients.Select(r => r.Email).Where(e => !string.IsNullOrEmpty(e)).ToList();
                    if (emails.Any())
                    {
                        // Email sending logic can be enabled when ready
                    }
                }

                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error sending message");
                throw;
            }
        }

        public async Task<Message> UpdateMessageAsync(int id, SendMessageDto request)
        {
            try
            {
                _logger.LogInformation("Updating message: {MessageId}", id);

                var message = await _messageRepository.GetByIdAsync(id);
                if (message == null)
                {
                    throw new KeyNotFoundException($"Message with ID {id} not found");
                }

                message.Subject = request.Subject;
                message.Content = request.Content;
                message.Priority = request.Priority;
                message.Type = request.Type;
                message.AttachmentPath = request.AttachmentPath;

                await _messageRepository.UpdateAsync(message);

                // Update recipients if provided
                if (request.Recipients != null && request.Recipients.Any())
                {
                    var existingRecipients = await _messageRecipientRepository.FindAsync(r => r.MessageId == id);
                    await _messageRecipientRepository.DeleteRangeAsync(existingRecipients);

                    var newRecipients = request.Recipients.Select(r => new MessageRecipient
                    {
                        MessageId = id,
                        RecipientId = r.RecipientId,
                        RecipientType = r.RecipientType,
                        IsRead = false,
                        TenantId = message.TenantId
                    }).ToList();

                    await _messageRecipientRepository.AddRangeAsync(newRecipients);
                }

                return message;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error updating message {MessageId}", id);
                throw;
            }
        }

        public async Task<MessageReply> ReplyToMessageAsync(int messageId, ReplyMessageDto request)
        {
            try
            {
                _logger.LogInformation("Replying to message {MessageId}", messageId);

                var reply = new MessageReply
                {
                    OriginalMessageId = messageId,
                    Content = request.Content,
                    SenderId = request.SenderId,
                    SenderType = request.SenderType,
                    SentDate = DateTime.UtcNow,
                    AttachmentPath = request.AttachmentPath
                };

                var result = await _messageReplyRepository.AddAsync(reply);

                // Notify original sender
                var originalMessage = await _messageRepository.GetByIdAsync(messageId);
                if (originalMessage != null)
                {
                    await _notificationService.SendNotificationAsync(
                        "message-reply",
                        $"Reply received for: {originalMessage.Subject}",
                        new[] { originalMessage.SenderId.ToString() });
                }

                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error replying to message {MessageId}", messageId);
                throw;
            }
        }

        public async Task MarkMessageAsReadAsync(int messageId, int userId)
        {
            try
            {
                _logger.LogInformation("Marking message {MessageId} as read for user {UserId}", messageId, userId);
                await _messageRepository.MarkMessageAsReadAsync(messageId, userId);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error marking message {MessageId} as read", messageId);
                throw;
            }
        }

        // Announcement Management
        public async Task<IEnumerable<Announcement>> GetAnnouncementsAsync(string? targetType, int? targetId, string currentUserType, int currentUserId)
        {
            try
            {
                var effectiveTargetType = targetType ?? currentUserType;
                var effectiveTargetId = targetId ?? currentUserId;

                _logger.LogInformation("Getting announcements - Target: {TargetType}/{TargetId}", effectiveTargetType, effectiveTargetId);

                if (!string.IsNullOrEmpty(effectiveTargetType))
                {
                    return await _announcementRepository.GetAnnouncementsByTargetAsync(effectiveTargetType, effectiveTargetId);
                }
                else
                {
                    return await _announcementRepository.GetActiveAnnouncementsAsync();
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving announcements");
                throw;
            }
        }

        public async Task<Announcement> CreateAnnouncementAsync(CreateAnnouncementDto request, int createdBy)
        {
            try
            {
                _logger.LogInformation("Creating announcement: {Title}", request.Title);

                var announcement = new Announcement
                {
                    Title = request.Title,
                    Content = request.Content,
                    Type = request.Type,
                    Priority = request.Priority,
                    CreatedOn = DateTime.UtcNow,
                    ValidFrom = request.ValidFrom,
                    ValidTo = request.ValidTo,
                    CreatedBy = createdBy.ToString(),
                    IsActive = true,
                    TargetAudience = request.TargetAudience,
                    AttachmentPath = request.AttachmentPath
                };

                var result = await _announcementRepository.AddAsync(announcement);

                // Send notifications based on target audience
                switch (request.TargetAudience.ToLower())
                {
                    case "all":
                        await _notificationService.SendNotificationToGroupAsync("all-users", request.Title, "announcement");
                        break;
                    case "students":
                        await _notificationService.SendNotificationToGroupAsync("students", request.Title, "announcement");
                        break;
                    case "parents":
                        await _notificationService.SendNotificationToGroupAsync("parents", request.Title, "announcement");
                        break;
                    case "staff":
                        await _notificationService.SendNotificationToGroupAsync("staff", request.Title, "announcement");
                        break;
                }

                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating announcement");
                throw;
            }
        }

        public async Task<Announcement> UpdateAnnouncementAsync(int id, CreateAnnouncementDto request, int updatedBy)
        {
            try
            {
                _logger.LogInformation("Updating announcement: {AnnouncementId}", id);

                var announcement = await _announcementRepository.GetByIdAsync(id);
                if (announcement == null)
                {
                    throw new KeyNotFoundException($"Announcement with ID {id} not found");
                }

                announcement.Title = request.Title;
                announcement.Content = request.Content;
                announcement.Type = request.Type;
                announcement.Priority = request.Priority;
                announcement.ValidFrom = request.ValidFrom;
                announcement.ValidTo = request.ValidTo;
                announcement.TargetAudience = request.TargetAudience;
                announcement.AttachmentPath = request.AttachmentPath;
                announcement.UpdatedOn = DateTime.UtcNow;
                announcement.UpdatedBy = updatedBy.ToString();

                await _announcementRepository.UpdateAsync(announcement);

                return announcement;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error updating announcement {AnnouncementId}", id);
                throw;
            }
        }

        // Event Management
        public async Task<IEnumerable<Event>> GetEventsAsync(DateTime? startDate, DateTime? endDate, int upcoming, int currentUserId, string currentUserType)
        {
            try
            {
                _logger.LogInformation("Getting events - Date range: {StartDate} to {EndDate}", startDate, endDate);

                if (startDate.HasValue || endDate.HasValue)
                {
                    var start = startDate ?? new DateTime(1900, 1, 1);
                    var end = endDate ?? new DateTime(2100, 12, 31);

                    _logger.LogInformation("Filtering events by range: {Start} to {End}", start, end);
                    var eventList = (await _eventRepository.GetEventsByDateRangeAsync(start, end)).ToList();
                    _logger.LogInformation("Retrieved {Count} events by range", eventList.Count);
                    return eventList;
                }
                else
                {
                    _logger.LogInformation("Getting upcoming events (next {Upcoming} days) for user {UserId}", upcoming, currentUserId);
                    var upcomingEvents = await _eventRepository.GetUpcomingEventsAsync(upcoming);
                    var myEvents = await _eventRepository.GetEventsByParticipantAsync(currentUserId, currentUserType);

                    var mergedEvents = upcomingEvents.UnionBy(myEvents, e => e.Id).OrderBy(e => e.StartDate).ToList();
                    _logger.LogInformation("Retrieved {Count} total events for general view", mergedEvents.Count);
                    return mergedEvents;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving events");
                throw;
            }
        }

        public async Task<Event> GetEventDetailsAsync(int id)
        {
            try
            {
                _logger.LogInformation("Getting event details for {EventId}", id);
                var eventDetails = await _eventRepository.GetEventWithParticipantsAsync(id);

                if (eventDetails == null)
                {
                    throw new KeyNotFoundException($"Event with ID {id} not found");
                }

                return eventDetails;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving event details for {EventId}", id);
                throw;
            }
        }

        public async Task<Event> CreateEventAsync(CreateEventDto request, int organizedBy)
        {
            try
            {
                _logger.LogInformation("Creating event: {Title}", request.Title);

                var eventItem = new Event
                {
                    Title = request.Title,
                    Description = request.Description,
                    Type = request.Type,
                    StartDate = request.StartDate,
                    EndDate = request.EndDate,
                    Location = request.Location,
                    OrganizedBy = organizedBy,
                    IsAllDay = request.IsAllDay,
                    IsPublic = request.IsPublic,
                    Color = request.Color,
                    Status = EventStatus.Scheduled,
                    MaxParticipants = request.MaxParticipants,
                    CreatedOn = DateTime.UtcNow
                };

                var result = await _eventRepository.AddAsync(eventItem);

                // Send notifications to relevant groups
                if (request.IsPublic)
                {
                    await _notificationService.SendNotificationToGroupAsync(
                        "all-users",
                        $"New event: {request.Title} on {request.StartDate:MMM dd}",
                        "event");
                }

                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating event");
                throw;
            }
        }

        public async Task<Event> UpdateEventAsync(int id, CreateEventDto request, int updatedBy)
        {
            try
            {
                _logger.LogInformation("Updating event: {EventId}", id);

                var eventItem = await _eventRepository.GetByIdAsync(id);
                if (eventItem == null)
                {
                    throw new KeyNotFoundException($"Event with ID {id} not found");
                }

                eventItem.Title = request.Title;
                eventItem.Description = request.Description;
                eventItem.Type = request.Type;
                eventItem.StartDate = request.StartDate;
                eventItem.EndDate = request.EndDate;
                eventItem.Location = request.Location;
                eventItem.IsAllDay = request.IsAllDay;
                eventItem.IsPublic = request.IsPublic;
                eventItem.Color = request.Color;
                eventItem.MaxParticipants = request.MaxParticipants;
                eventItem.UpdatedOn = DateTime.UtcNow;
                eventItem.UpdatedBy = updatedBy.ToString();

                await _eventRepository.UpdateAsync(eventItem);

                return eventItem;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error updating event {EventId}", id);
                throw;
            }
        }

        // Parent-Teacher Meetings
        public async Task<IEnumerable<ParentTeacherMeeting>> GetMeetingsAsync(string userType, int userId)
        {
            try
            {
                _logger.LogInformation("Getting meetings for {UserType} {UserId}", userType, userId);

                if (userType.ToLower() == "parent")
                {
                    return await _meetingRepository.GetMeetingsByParentAsync(userId);
                }
                else
                {
                    return await _meetingRepository.GetMeetingsByStaffAsync(userId);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving meetings");
                throw;
            }
        }

        public async Task<ParentTeacherMeeting> ScheduleMeetingAsync(ScheduleMeetingDto request, int createdBy)
        {
            try
            {
                _logger.LogInformation("Scheduling meeting between parent {ParentId} and staff {StaffId}", request.ParentId, request.StaffId);

                var meeting = new ParentTeacherMeeting
                {
                    ParentId = request.ParentId,
                    StaffId = request.StaffId,
                    StudentId = request.StudentId,
                    ScheduledDate = request.ScheduledDate,
                    StartTime = request.StartTime,
                    EndTime = request.EndTime,
                    Purpose = request.Purpose,
                    Status = MeetingStatus.Scheduled,
                    Location = request.Location,
                    CreatedOn = DateTime.UtcNow,
                    CreatedBy = createdBy.ToString()
                };

                var result = await _meetingRepository.AddAsync(meeting);

                // Notify both parties
                await _notificationService.SendNotificationAsync(
                    "meeting",
                    $"Meeting scheduled for {request.ScheduledDate:MMM dd} at {request.StartTime}",
                    new[] { request.ParentId.ToString() });

                await _notificationService.SendNotificationAsync(
                    "meeting",
                    $"Parent meeting scheduled for {request.ScheduledDate:MMM dd} at {request.StartTime}",
                    new[] { request.StaffId.ToString() });

                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error scheduling meeting");
                throw;
            }
        }

        // Bulk Communication
        public async Task SendBulkNotificationAsync(BulkNotificationDto request)
        {
            try
            {
                _logger.LogInformation("Sending bulk notification to {Count} users", request.UserIds?.Count() ?? 0);

                if (request.UserIds != null && request.UserIds.Any())
                {
                    await _notificationService.SendBulkNotificationAsync(
                        request.Type,
                        request.Message,
                        request.UserIds);
                }
                else
                {
                    await _notificationService.SendNotificationToGroupAsync(
                        request.GroupName ?? "all-users",
                        request.Message,
                        request.Type);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error sending bulk notification");
                throw;
            }
        }

        public async Task SendBulkEmailAsync(BulkEmailDto request)
        {
            try
            {
                _logger.LogInformation("Sending bulk email to {Count} recipients", request.Recipients?.Count() ?? 0);

                if (request.Recipients != null && request.Recipients.Any())
                {
                    await _emailService.SendBulkEmailAsync(request.Recipients, request.Subject, request.Body, request.IsHtml);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error sending bulk email");
                throw;
            }
        }

        public async Task SendBulkSMSAsync(BulkSMSDto request)
        {
            try
            {
                _logger.LogInformation("Sending bulk SMS to {Count} recipients", request.PhoneNumbers?.Count() ?? 0);

                if (request.PhoneNumbers != null && request.PhoneNumbers.Any())
                {
                    await _smsService.SendBulkSMSAsync(request.PhoneNumbers, request.Message);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error sending bulk SMS");
                throw;
            }
        }
    }
}
