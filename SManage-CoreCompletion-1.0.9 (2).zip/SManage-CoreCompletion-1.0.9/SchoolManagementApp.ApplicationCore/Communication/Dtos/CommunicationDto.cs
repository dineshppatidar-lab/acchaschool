namespace SchoolManagementApp.ApplicationCore.Communication.Dtos
{
    public class CommunicationDto
    {
        public int Id { get; set; }
        public string Subject { get; set; } = string.Empty;
        public string Message { get; set; } = string.Empty;
    }
}