using SchoolManagementApp.ApplicationCore.Entities;

namespace SchoolManagementApp.ApplicationCore.Communication.WhatsApp.Interfaces
{
    /// <summary>
    /// Result of a single send attempt against a WhatsApp provider.
    /// </summary>
    public class WhatsAppSendResult
    {
        public bool Success { get; set; }
        public string? ProviderMessageId { get; set; }
        public string? ErrorMessage { get; set; }
        /// <summary>True when the provider signalled a retryable condition (rate limit, 5xx, timeout).</summary>
        public bool IsRetryable { get; set; }

        public static WhatsAppSendResult Ok(string providerMessageId) =>
            new() { Success = true, ProviderMessageId = providerMessageId };

        public static WhatsAppSendResult Fail(string error, bool retryable = false) =>
            new() { Success = false, ErrorMessage = error, IsRetryable = retryable };
    }

    /// <summary>
    /// Configuration snapshot handed to providers — never includes other tenant data.
    /// AccessToken is the decrypted secret and must never be logged or serialized to clients.
    /// </summary>
    public class WhatsAppProviderConfig
    {
        public WhatsAppProviderType Provider { get; set; }
        public string ApiBaseUrl { get; set; } = string.Empty;
        public string ApiVersion { get; set; } = string.Empty;
        public string? PhoneNumberId { get; set; }
        public string AccessToken { get; set; } = string.Empty;
        public int RequestTimeoutSeconds { get; set; } = 30;
        public bool TestMode { get; set; }

        // Arattai-specific fields (ignored by the Meta provider).
        public string? ArattaiCompanyId { get; set; }
        public string? ArattaiBusinessNumberId { get; set; }
        /// <summary>Durable Arattai OAuth template-id mapping (from WhatsAppMessageTemplate.ProviderTemplateId).</summary>
        public string? ArattaiTemplateId { get; set; }
    }

    /// <summary>
    /// Provider abstraction (Meta Cloud API today, other providers tomorrow).
    /// Implementations must never log the access token.
    /// </summary>
    public interface IWhatsAppProvider
    {
        WhatsAppProviderType ProviderType { get; }

        /// <summary>Verifies credentials/phone number id with the provider (cheap API call).</summary>
        Task<WhatsAppSendResult> TestConnectionAsync(WhatsAppProviderConfig config, CancellationToken ct = default);

        /// <summary>
        /// Sends a message. When templateName is provided the provider template
        /// (required for business-initiated messages on Meta and Arattai) is used with the given
        /// body parameters; otherwise free-form text is sent (Meta session messages only).
        /// templateParameters keys are placeholder names; the provider adapter maps them
        /// to the provider's expected shape (positional for Meta, named for Arattai).
        /// </summary>
        Task<WhatsAppSendResult> SendMessageAsync(
            WhatsAppProviderConfig config,
            string toPhoneNumber,
            string? templateName,
            string? languageCode,
            string? templateBodyText,
            IReadOnlyDictionary<string, string>? templateParameters,
            CancellationToken ct = default);
    }

    /// <summary>
    /// Stores/protects tenant secrets (access token, webhook secrets).
    /// Production implementations should use DPAPI/Azure Key Vault; the reference
    /// implementation uses a machine-key AES encryption so plaintext never hits the DB.
    /// </summary>
    public interface ISecretProtector
    {
        string Protect(string plaintext);
        string? Unprotect(string? ciphertext);
        /// <summary>Masked hint safe for UI display, e.g. "EAAG••••4f2a".</summary>
        string Mask(string plaintext);
    }

    /// <summary>Result of resolving recipients for a reminder/bulk send.</summary>
    public class WhatsAppRecipientPreview
    {
        public int StudentId { get; set; }
        public string StudentName { get; set; } = string.Empty;
        public string ClassName { get; set; } = string.Empty;
        public string SectionName { get; set; } = string.Empty;
        public string RollNumber { get; set; } = string.Empty;

        public int? ParentId { get; set; }
        public string ParentName { get; set; } = string.Empty;
        public string? RawPhoneNumber { get; set; }
        /// <summary>Normalized number (digits only, country code prefixed) or null when invalid/missing.</summary>
        public string? NormalizedNumber { get; set; }
        public bool IsValidNumber => !string.IsNullOrWhiteSpace(NormalizedNumber);

        public string InstallmentName { get; set; } = string.Empty;
        public int? FeeInstallmentId { get; set; }
        public DateTime? DueDate { get; set; }
        public decimal OutstandingAmount { get; set; }
        public decimal TotalFee { get; set; }
        public decimal PaidAmount { get; set; }
    }

    /// <summary>Summary returned after a bulk enqueue.</summary>
    public class WhatsAppBulkSendResult
    {
        public int Requested { get; set; }
        public int Queued { get; set; }
        public int SkippedInvalidNumber { get; set; }
        public int SkippedDuplicate { get; set; }
        public List<string> SkippedReasons { get; set; } = new();
    }

    /// <summary>
    /// Core WhatsApp notification facade used by the Fees module and background worker.
    /// Keeps fee logic decoupled from any provider.
    /// </summary>
    public interface IWhatsAppService
    {
        // Configuration
        Task<WhatsAppConfiguration> GetOrCreateConfigurationAsync(int tenantId);
        Task<WhatsAppConfiguration> SaveConfigurationAsync(WhatsAppConfiguration config, string? newAccessToken, string? newWebhookVerifyToken, string? newWebhookSecret, string? newArattaiRefreshToken = null);
        Task<WhatsAppSendResult> TestConnectionAsync(int tenantId);
        Task<WhatsAppSendResult> SendTestMessageAsync(int tenantId, string toPhoneNumber);

        // Templates
        Task<List<WhatsAppMessageTemplate>> GetTemplatesAsync(int tenantId);
        Task<WhatsAppMessageTemplate> SaveTemplateAsync(WhatsAppMessageTemplate template);
        Task DeleteTemplateAsync(int templateId);

        // Reminder rules
        Task<List<WhatsAppReminderRule>> GetReminderRulesAsync(int tenantId);
        Task<WhatsAppReminderRule> SaveReminderRuleAsync(WhatsAppReminderRule rule);
        Task DeleteReminderRuleAsync(int ruleId);

        // Rendering
        /// <summary>Renders a template body with the given placeholder values. Unknown placeholders are left as-is.</summary>
        string RenderTemplate(string bodyText, IReadOnlyDictionary<string, string> values);

        // Recipients & sending
        Task<List<WhatsAppRecipientPreview>> GetOutstandingFeeRecipientsAsync(
            int tenantId,
            int? academicYearId = null,
            int? classId = null,
            int? sectionId = null,
            int? studentId = null,
            string? overdueStatus = null,
            decimal? minOutstanding = null,
            int? installmentId = null,
            CancellationToken ct = default);

        Task<WhatsAppBulkSendResult> EnqueueBulkFeeRemindersAsync(
            int tenantId,
            List<int> studentIds,
            int templateId,
            string trigger,
            string triggeredBy,
            int? reminderRuleId = null,
            CancellationToken ct = default);

        /// <summary>
        /// Event-driven payment receipt: enqueues one PaymentReceived message to the
        /// paying student's primary contact when an installment FeePayment completes.
        /// Uses the tenant's PaymentReceived template (MessageType = PaymentReceived,
        /// active) when one exists; without a template or a disabled config this is a
        /// safe no-op — payment processing must never fail because of messaging.
        /// Returns the message-log id when queued, null when skipped (with reason).
        /// </summary>
        Task<(int? MessageLogId, string? SkipReason)> EnqueuePaymentConfirmationAsync(
            int tenantId,
            int studentId,
            int feePaymentId,
            CancellationToken ct = default);

        /// <summary>Processes queued messages (rate-limited). Called by the background worker.</summary>
        Task<int> ProcessQueueAsync(int maxMessages, CancellationToken ct);

        /// <summary>Runs all enabled automated reminder rules for all tenants. Returns number of messages enqueued.</summary>
        Task<int> RunAutomatedRemindersAsync(CancellationToken ct);

        /// <summary>Handles provider webhook payloads (status updates: sent/delivered/read/failed).</summary>
        Task HandleStatusCallbackAsync(string providerMessageId, string status, string? failureReason);

        /// <summary>
        /// Re-enqueues a single failed message for a fresh send attempt (admin retry).
        /// Only Failed/Cancelled logs with a valid tenant config can be retried; the
        /// returned result states why when a retry is not possible. Never retries
        /// messages that were accepted by the provider (Sent/Delivered/Read).
        /// </summary>
        Task<WhatsAppSendResult> RetryFailedMessageAsync(int tenantId, int messageLogId, string retriedBy);

        /// <summary>
        /// Tenant-scoped, composable history query for paged/filtered reads by the API layer.
        /// </summary>
        IQueryable<WhatsAppMessageLog> GetHistoryQuery(int tenantId);
    }
}
