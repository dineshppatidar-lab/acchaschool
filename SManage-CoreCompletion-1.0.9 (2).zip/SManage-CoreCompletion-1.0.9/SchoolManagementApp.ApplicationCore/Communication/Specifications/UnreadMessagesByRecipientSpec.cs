using Ardalis.Specification;
using SchoolManagementApp.ApplicationCore.Entities;

namespace SchoolManagementApp.ApplicationCore.Communication.Specifications
{
    public class UnreadMessagesByRecipientSpec : Specification<Message>
    {
        public UnreadMessagesByRecipientSpec(int recipientId, string recipientType)
        {
            Query.Where(m => m.Recipients.Any(r => r.RecipientId == recipientId && r.RecipientType == recipientType && !r.IsRead))
                 .OrderByDescending(m => m.SentDate);
        }
    }
}
