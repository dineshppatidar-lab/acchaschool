using Ardalis.Specification;
using SchoolManagementApp.ApplicationCore.Entities;

namespace SchoolManagementApp.ApplicationCore.Communication.Specifications
{
    public class ActiveAnnouncementsSpec : Specification<Announcement>
    {
        public ActiveAnnouncementsSpec()
        {
            Query.Where(a => a.IsActive && a.ValidFrom <= DateTime.UtcNow && a.ValidTo >= DateTime.UtcNow)
                 .OrderByDescending(a => a.CreatedOn);
        }
    }
}
