using Ardalis.Specification;
using SchoolManagementApp.ApplicationCore.Entities;

namespace SchoolManagementApp.ApplicationCore.Communication.Specifications
{
    public class UpcomingEventsSpec : Specification<Event>
    {
        public UpcomingEventsSpec()
        {
            Query.Where(e => e.StartDate >= DateTime.UtcNow)
                 .OrderBy(e => e.StartDate)
                 .Include(e => e.Participants);
        }
    }
}
