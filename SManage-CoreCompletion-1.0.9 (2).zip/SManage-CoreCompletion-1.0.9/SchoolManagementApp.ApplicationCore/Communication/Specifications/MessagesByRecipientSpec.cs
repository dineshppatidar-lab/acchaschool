using Ardalis.Specification;
using SchoolManagementApp.ApplicationCore.Entities;

namespace SchoolManagementApp.ApplicationCore.Communication.Specifications
{
    /// <summary>
    /// Specification to filter messages by recipient.
    /// </summary>
    public class MessagesByRecipientSpec : Specification<Message>
    {
        public MessagesByRecipientSpec(int recipientId, string recipientType)
        {
            Query.Where(m => m.Recipients.Any(r => r.RecipientId == recipientId && r.RecipientType == recipientType))
                 .OrderByDescending(m => m.SentDate);
        }
    }
}
