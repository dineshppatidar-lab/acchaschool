using System;
using System.ComponentModel;

namespace SchoolManagementApp.ApplicationCore.Interfaces
{
    //[Obsolete("Use SchoolManagementApp.ApplicationCore.Academic.Interfaces.IAcademicRepository")]
    //[EditorBrowsable(EditorBrowsableState.Never)]
    //public interface IAcademicRepository : SchoolManagementApp.ApplicationCore.Academic.Interfaces.IAcademicRepository
    //{
    //    Task<(IEnumerable<Class>, int)> GetClassesAsync(int page, int pageSize, string sort, string order, string search);
    //    Task<IEnumerable<Class>> GetClassesByAcademicYearAsync(int academicYearId);
    //    Task<Class> GetClassByIdAsync(int id);
    //    Task<Class> CreateClassAsync(Class class_);
    //    Task UpdateClassAsync(Class class_);
    //    Task DeleteClassAsync(int id);

    //    Task<(IEnumerable<Section>, int)> GetSectionsAsync(int page, int pageSize, string sort, string order, string search);
    //    Task<IEnumerable<Section>> GetSectionsByClassAsync(int classId);
    //    Task<Section> GetSectionByIdAsync(int id);
    //    Task<Section> CreateSectionAsync(Section section);
    //    Task UpdateSectionAsync(Section section);
    //    Task DeleteSectionAsync(int id);
    //}

    //public interface IFeesRepository
    //{
    //    Task<(IEnumerable<Fee>, int)> GetFeesAsync(int page, int pageSize, string sort, string order, string search);
    //    Task<Fee> GetFeeByIdAsync(int id);
    //    Task<Fee> CreateFeeAsync(Fee fee);
    //    Task UpdateFeeAsync(Fee fee);
    //    Task DeleteFeeAsync(int id);
    //}

    //[Obsolete("Use SchoolManagementApp.ApplicationCore.Hostel.Interfaces.IHostelRepository")]
    //[EditorBrowsable(EditorBrowsableState.Never)]
    //public interface IHostelRepository : SchoolManagementApp.ApplicationCore.Hostel.Interfaces.IHostelRepository
    //{
    //    Task<(IEnumerable<Entities.Hostel>, int)> GetHostelsAsync(int page, int pageSize, string sort, string order, string search);
    //    Task<Entities.Hostel> GetHostelByIdAsync(int id);
    //    Task<Entities.Hostel> CreateHostelAsync(Entities.Hostel hostel);
    //    Task UpdateHostelAsync(Entities.Hostel hostel);
    //    Task DeleteHostelAsync(int id);
    //}

    //[Obsolete("Use SchoolManagementApp.ApplicationCore.Transport.Interfaces.ITransportRepository")]
    //[EditorBrowsable(EditorBrowsableState.Never)]
    //public interface ITransportRepository : SchoolManagementApp.ApplicationCore.Transport.Interfaces.ITransportRepository
    //{
    //    Task<(IEnumerable<BusRoute>, int)> GetTransportsAsync(int page, int pageSize, string sort = "RouteName", string order = "asc", string search = "");
    //    Task<BusRoute?> GetTransportByIdAsync(int id);
    //    Task<BusRoute> CreateTransportAsync(BusRoute transport);
    //    Task UpdateTransportAsync(BusRoute transport);
    //    Task DeleteTransportAsync(int id);
    //    Task<bool> IsVehicleAssignedToAnotherRouteAsync(int vehicleId, int? excludeRouteId = null);

    //    // Vehicles
    //    Task<(IEnumerable<Vehicle>, int)> GetVehiclesAsync(int page, int pageSize, string sort = "VehicleNumber", string order = "asc", string search = "");
    //    Task<Vehicle?> GetVehicleByIdAsync(int id);
    //    Task<Vehicle> CreateVehicleAsync(Vehicle vehicle);
    //    Task UpdateVehicleAsync(Vehicle vehicle);
    //    Task DeleteVehicleAsync(int id);

    //    // Route stops
    //    Task<IEnumerable<RouteStop>> GetRouteStopsAsync(int routeId);
    //    Task<RouteStop> AddRouteStopAsync(RouteStop stop);
    //    Task UpdateRouteStopAsync(RouteStop stop);
    //    Task DeleteRouteStopAsync(int id);
    //    Task ReorderRouteStopsAsync(int routeId, IEnumerable<(int StopId, int SequenceNumber)> newOrder);

    //    // Student assignments
    //    Task AssignStudentToRouteAsync(int studentId, int routeId);
    //    Task UnassignStudentFromRouteAsync(int studentId);
    //    Task<IEnumerable<Student>> GetRouteStudentsAsync(int routeId);

    //    // Attendance
    //    Task<BusAttendance> MarkBusAttendanceAsync(BusAttendance attendance);
    //    Task<IEnumerable<BusAttendance>> GetBusAttendanceAsync(int routeId, DateTime date);

    //    // Fees
    //    Task<IEnumerable<TransportFee>> GetTransportFeesAsync();

    //    // Analytics
    //    Task<Dictionary<int, int>> GetStudentCountByRouteAsync();
    //    Task<Dictionary<int, int>> GetAttendanceCountByRouteAndDateRangeAsync(DateTime startDate, DateTime endDate);
    //}

    //[Obsolete("Use SchoolManagementApp.ApplicationCore.Students.Interfaces.IStudentRepository")]
    //[EditorBrowsable(EditorBrowsableState.Never)]
    //public interface IStudentRepository : SchoolManagementApp.ApplicationCore.Students.Interfaces.IStudentRepository
    //{
    //    Task<IEnumerable<Student>> GetAllAsync();
    //    IQueryable<Student> GetAllQueryable();
    //    Task<Student?> GetByIdAsync(int id);
    //    Task<Student> CreateAsync(Student student);
    //    Task UpdateAsync(Student student);
    //    Task DeleteAsync(int id);
    //    Task<IEnumerable<Student>> GetByClassAsync(int classId);
    //    Task<IEnumerable<Student>> GetBySectionAsync(int sectionId);
    //}

    //[Obsolete("Use SchoolManagementApp.ApplicationCore.Staff.Interfaces.IStaffRepository")]
    //[EditorBrowsable(EditorBrowsableState.Never)]
    //public interface IStaffRepository : SchoolManagementApp.ApplicationCore.Staff.Interfaces.IStaffRepository
    //{
    //    Task<IEnumerable<Entities.Staff>> GetAllAsync();
    //    Task<Entities.Staff?> GetByIdAsync(int id);
    //    Task<Entities.Staff> CreateAsync(Entities.Staff staff);
    //    Task UpdateAsync(Entities.Staff staff);
    //    Task DeleteAsync(int id);
    //    Task<IEnumerable<Entities.Staff>> GetByRoleAsync(string role);
    //}

    public interface IAttendanceRepository
    {
        Task<IEnumerable<Attendance>> GetStudentAttendanceAsync(int studentId, DateTime startDate, DateTime endDate);
        Task<IEnumerable<Attendance>> GetStaffAttendanceAsync(int staffId, DateTime startDate, DateTime endDate);
        Task<Attendance> MarkAttendanceAsync(Attendance attendance);
    }

    public interface IDocumentRepository
    {
        Task<IEnumerable<Document>> GetStudentDocumentsAsync(int studentId);
        Task<Document> UploadDocumentAsync(Document document);
        Task DeleteDocumentAsync(int id);
    }

    //public interface IParentRepository
    //{
    //    Task<IEnumerable<Parent>> GetAllParentsAsync();
    //    Task<Parent?> GetParentByIdAsync(int id);
    //    Task<Parent> CreateParentAsync(Parent parent);
    //    Task UpdateParentAsync(Parent parent);
    //    Task DeleteParentAsync(int id);
    //}
}
