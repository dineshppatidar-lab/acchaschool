using System;
using System.ComponentModel;

namespace SchoolManagementApp.ApplicationCore.Interfaces
{
    //[Obsolete("Use SchoolManagementApp.ApplicationCore.Payroll.Interfaces.IPayrollService")]
    //[EditorBrowsable(EditorBrowsableState.Never)]
    //public interface IPayrollService : SchoolManagementApp.ApplicationCore.Payroll.Interfaces.IPayrollService
    //{
    //    /// <summary>
    //    /// Retrieves the active salary template for a staff member.
    //    /// </summary>
    //    Task<SalaryStructure?> GetSalaryStructureAsync(int staffId);

    //    /// <summary>
    //    /// Assigns or updates base pay and dynamic components for an employee.
    //    /// </summary>
    //    Task<SalaryStructure> UpsertSalaryStructureAsync(int staffId, SalaryStructure structure);

    //    /// <summary>
    //    /// Generates a draft payslip taking into account attendance, LWP, and deductions.
    //    /// </summary>
    //    Task<Payslip?> GeneratePayslipAsync(int staffId, int month, int year);

    //    /// <summary>
    //    /// Batch generation for an entire school.
    //    /// </summary>
    //    Task<IEnumerable<Payslip>> GenerateBatchPayslipsAsync(int month, int year);

    //    Task<IEnumerable<PayrollRun>> GetPayrollRunsAsync();

    //    Task<PayrollRun?> GetPayrollRunDetailsAsync(int id);

    //    Task<PayrollRun> ProcessPayrollAsync(int year, int month, int processedByUserId);

    //    /// <summary>
    //    /// Marks a payslip as paid and potentially integrates with the global Finance module.
    //    /// </summary>
    //    Task<Payslip?> MarkPayslipAsPaidAsync(int payslipId, string transactionId);
    //}
}
