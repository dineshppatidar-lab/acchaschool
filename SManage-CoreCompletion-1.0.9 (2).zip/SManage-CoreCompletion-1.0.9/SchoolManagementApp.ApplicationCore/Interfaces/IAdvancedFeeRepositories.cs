using SchoolManagementApp.ApplicationCore.Fees.Dtos;

namespace SchoolManagementApp.ApplicationCore.Interfaces
{
    ///// <summary>
    ///// Repository for StudentFeeAdjustment operations
    ///// Manages fee waivers and discounts per student
    ///// </summary>
    //[Obsolete("Use SchoolManagementApp.ApplicationCore.Fees.Interfaces.IStudentFeeAdjustmentRepository instead. This interface will be removed in Phase 2.")]
    //public interface IStudentFeeAdjustmentRepository : SchoolManagementApp.ApplicationCore.Fees.Interfaces.IStudentFeeAdjustmentRepository { }

    /// <summary>
    /// Repository for GroupPayment operations
    /// Orchestrates multi-student payments
    ///// </summary>
    //[Obsolete("Use SchoolManagementApp.ApplicationCore.Fees.Interfaces.IGroupPaymentRepository instead. This interface will be removed in Phase 2.")]
    //public interface IGroupPaymentRepository : SchoolManagementApp.ApplicationCore.Fees.Interfaces.IGroupPaymentRepository { }

    ///// <summary>
    ///// Repository for GroupPaymentAllocation operations
    ///// Tracks individual allocations within group payments
    ///// </summary>
    //[Obsolete("Use SchoolManagementApp.ApplicationCore.Fees.Interfaces.IGroupPaymentAllocationRepository instead. This interface will be removed in Phase 2.")]
    //public interface IGroupPaymentAllocationRepository : SchoolManagementApp.ApplicationCore.Fees.Interfaces.IGroupPaymentAllocationRepository { }

    ///// <summary>
    ///// High-level service for advanced fee calculations
    ///// Orchestrates StudentFeeAdjustments, GroupPayments, and base fees
    ///// </summary>
    //// NOTE: IAdvancedFeeCalculationService canonical definition is in Communication/Interfaces/IAdvancedFeeCalculationService.cs
    //[Obsolete("Use SchoolManagementApp.ApplicationCore.Communication.Interfaces.IAdvancedFeeCalculationService instead. This interface will be removed in Phase 2.")]
    //public interface IAdvancedFeeCalculationService : SchoolManagementApp.ApplicationCore.Communication.Interfaces.IAdvancedFeeCalculationService { }
}
