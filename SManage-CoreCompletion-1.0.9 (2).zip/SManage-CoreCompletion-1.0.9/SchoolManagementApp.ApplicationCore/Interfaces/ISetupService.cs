using System;
using System.ComponentModel;
using SchoolManagementApp.ApplicationCore.Setup.Dtos;

namespace SchoolManagementApp.ApplicationCore.Interfaces
{
    /// <summary>
    /// Interface for setup wizard business logic
    /// Handles validation, tracking, and completion of initial school setup
    /// </summary>
    [Obsolete("Use SchoolManagementApp.ApplicationCore.Setup.Interfaces.ISetupService")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public interface ISetupService : SchoolManagementApp.ApplicationCore.Setup.Interfaces.ISetupService
    {
        // --- Setup Operations ---
        
        Task<AcademicYear> CreateAcademicYearAsync(int tenantId, CreateAcademicYearRequest request);
        Task<AcademicYear> UpdateAcademicYearAsync(int tenantId, int id, CreateAcademicYearRequest request);
        Task<List<AcademicYear>> GetAcademicYearsAsync(int tenantId);
        
        Task<List<Class>> CreateClassesAsync(int tenantId, CreateClassesRequest request);
        Task<List<Class>> GetClassesByYearAsync(int tenantId, int academicYearId);
        Task<List<Section>> CreateSectionsAsync(int tenantId, CreateSectionsRequest request);
        Task<List<Section>> GetSectionsByClassAsync(int tenantId, int classId);
        Task<List<Subject>> CreateSubjectsAsync(int tenantId, CreateSubjectsRequest request);
        Task<List<Subject>> GetSubjectsByClassAsync(int tenantId, int classId);
        
        Task<Entities.Staff> CreateStaffAsync(int tenantId, CreateStaffRequest request);
        Task<bool> CreateStaffStructureAsync(int tenantId, CreateStaffStructureRequest request);
        
        Task<FeeStructure> CreateFeeStructureAsync(int tenantId, CreateFeeStructureRequest request);
        Task<FeeInstallmentsResponse> CreateFeeInstallmentsAsync(int tenantId, CreateFeeInstallmentsRequest request);
        
        Task<List<PaymentMethod>> CreatePaymentMethodsAsync(int tenantId, CreatePaymentMethodsRequest request);
        Task<List<PaymentMethod>> GetPaymentMethodsAsync();

        // --- Wizard State Management ---

        /// <summary>
        /// Validates current setup progress for a tenant
        /// </summary>
        Task<SetupValidationResult> ValidateSetupAsync(int tenantId);

        /// <summary>
        /// Gets the setup checklist with progress information
        /// </summary>
        Task<SetupChecklistResult> GetSetupChecklistAsync(int tenantId);

        /// <summary>
        /// Determines if setup can be marked as complete
        /// </summary>
        Task<bool> CanCompleteSetupAsync(int tenantId);

        /// <summary>
        /// Marks setup as complete and records completion details
        /// </summary>
        Task<SetupStatus> MarkSetupCompleteAsync(int tenantId, int userId, string? notes = null);

        /// <summary>
        /// Gets current setup status for a tenant
        /// </summary>
        Task<SetupStatus?> GetSetupStatusAsync(int tenantId);

        /// <summary>
        /// Initializes setup status tracking for a new tenant
        /// </summary>
        Task<SetupStatus> InitializeSetupStatusAsync(int tenantId);

        /// <summary>
        /// Updates component completion status
        /// </summary>
        Task UpdateComponentStatusAsync(int tenantId, string componentName, bool isCompleted);
    }

    // Response classes for Setup - kept here for backward compatibility
    public class SetupValidationResult
    {
        public bool AcademicYearCreated { get; set; }
        public bool ClassesCreated { get; set; }
        public bool SubjectsCreated { get; set; }
        public bool StaffCreated { get; set; }
        public bool FeeStructureCreated { get; set; }
        public bool PaymentMethodsCreated { get; set; }
        public bool CanCompleteSetup { get; set; }
        public List<string> MissingComponents { get; set; } = new();
    }

    public class SetupChecklistResult
    {
        public List<SetupStep> Steps { get; set; } = new();
        public int CompletedSteps { get; set; }
        public int TotalSteps { get; set; }
        public double ProgressPercentage { get; set; }
    }

    public class SetupStep
    {
        public int StepNumber { get; set; }
        public string? Title { get; set; }
        public bool Completed { get; set; }
        public string? Description { get; set; }
        public bool IsRequired { get; set; } = true;
    }
}
