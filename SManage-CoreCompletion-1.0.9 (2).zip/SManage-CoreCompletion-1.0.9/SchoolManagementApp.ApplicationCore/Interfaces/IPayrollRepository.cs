
namespace SchoolManagementApp.ApplicationCore.Interfaces
{
    //public interface IPayrollRepository
    //{
    //    Task<SalaryStructure?> GetSalaryStructureAsync(int staffId);

    //    Task<SalaryStructure> UpsertSalaryStructureAsync(SalaryStructure structure);

    //    Task<IEnumerable<PayrollRun>> GetPayrollRunsAsync();

    //    Task<PayrollRun?> GetPayrollRunDetailsAsync(int id);

    //    Task<PayrollRun> CreatePayrollRunAsync(PayrollRun run);

    //    Task<Payslip> CreatePayslipAsync(Payslip payslip);

    //    Task<IEnumerable<Payslip>> CreateBatchPayslipsAsync(IEnumerable<Payslip> payslips);

    //    Task<Payslip?> GetPayslipAsync(int id);

    //    Task<Payslip> UpdatePayslipAsync(Payslip payslip);
    //}
}
