using Microsoft.AspNetCore.Http;
using System.Linq.Expressions;
using SchoolManagementApp.ApplicationCore.Communication.Interfaces;

namespace SchoolManagementApp.ApplicationCore.Interfaces
{
    //[Obsolete("Use SchoolManagementApp.ApplicationCore._Interfaces.IRepository<T> instead. This interface will be removed in Phase 2.")]
    public interface IGenericRepository<T> where T : class
    {
        Task<IEnumerable<T>> GetAllAsync();
        Task<T> GetByIdAsync(int id);
        Task<T> AddAsync(T entity);
        Task UpdateAsync(T entity);
        Task DeleteAsync(int id);
        Task<IEnumerable<T>> FindAsync(Expression<Func<T, bool>> predicate);
        Task<T> FirstOrDefaultAsync(Expression<Func<T, bool>> predicate);
        Task<bool> ExistsAsync(Expression<Func<T, bool>> predicate);
        Task<int> CountAsync(Expression<Func<T, bool>>? predicate = null);
        Task<IEnumerable<T>> GetPagedAsync(int page, int pageSize, Expression<Func<T, bool>>? predicate = null);
        Task AddRangeAsync(IEnumerable<T> entities);
        Task UpdateRangeAsync(IEnumerable<T> entities);
        Task DeleteRangeAsync(IEnumerable<T> entities);
    }

    // Advanced Academic Repositories
    //[Obsolete("Use Academic.Interfaces.ITimeTableRepository instead.")]
    //public interface ITimeTableRepository : SchoolManagementApp.ApplicationCore.Academic.Interfaces.ITimeTableRepository { }

    //[Obsolete("Use Academic.Interfaces.IExaminationRepository instead.")]
    //public interface IExaminationRepository : SchoolManagementApp.ApplicationCore.Academic.Interfaces.IExaminationRepository { }

    //[Obsolete("Use Academic.Interfaces.IExaminationTypeRepository instead.")]
    //public interface IExaminationTypeRepository : SchoolManagementApp.ApplicationCore.Academic.Interfaces.IExaminationTypeRepository { }

    //[Obsolete("Use Academic.Interfaces.IExamScheduleRepository instead.")]
    //public interface IExamScheduleRepository : SchoolManagementApp.ApplicationCore.Academic.Interfaces.IExamScheduleRepository { }

    //[Obsolete("Use Academic.Interfaces.IAcademicYearRepository instead.")]
    //public interface IAcademicYearRepository : SchoolManagementApp.ApplicationCore.Academic.Interfaces.IAcademicYearRepository { }

    //[Obsolete("Use Academic.Interfaces.IStudentPromotionRepository instead.")]
    //public interface IStudentPromotionRepository : SchoolManagementApp.ApplicationCore.Academic.Interfaces.IStudentPromotionRepository { }

    //[Obsolete("Use Academic.Interfaces.IGradingSchemeRepository instead.")]
    //public interface IGradingSchemeRepository : SchoolManagementApp.ApplicationCore.Academic.Interfaces.IGradingSchemeRepository { }

    //[Obsolete("Use Academic.Interfaces.IAssignmentRepository instead.")]
    //public interface IAssignmentRepository : SchoolManagementApp.ApplicationCore.Academic.Interfaces.IAssignmentRepository { }

    //[Obsolete("Use Academic.Interfaces.IAssignmentSubmissionRepository instead.")]
    //public interface IAssignmentSubmissionRepository : SchoolManagementApp.ApplicationCore.Academic.Interfaces.IAssignmentSubmissionRepository { }

    //[Obsolete("Use Academic.Interfaces.IExamResultRepository instead.")]
    //public interface IExamResultRepository : SchoolManagementApp.ApplicationCore.Academic.Interfaces.IExamResultRepository { }

    //// Communication Repositories - [Obsolete] with inheritance from canonical versions
    //[Obsolete("Use Communication.Interfaces.IMessageRepository instead.")]
    //public interface IMessageRepository : Communication.Interfaces.IMessageRepository { }

    //[Obsolete("Use Communication.Interfaces.IMessageRecipientRepository instead.")]
    //public interface IMessageRecipientRepository : Communication.Interfaces.IMessageRecipientRepository { }

    //[Obsolete("Use Communication.Interfaces.IMessageReplyRepository instead.")]
    //public interface IMessageReplyRepository : Communication.Interfaces.IMessageReplyRepository { }

    //[Obsolete("Use Communication.Interfaces.IAnnouncementRepository instead.")]
    //public interface IAnnouncementRepository : Communication.Interfaces.IAnnouncementRepository { }

    //[Obsolete("Use Communication.Interfaces.IEventRepository instead.")]
    //public interface IEventRepository : Communication.Interfaces.IEventRepository { }

    //[Obsolete("Use Communication.Interfaces.IParentTeacherMeetingRepository instead.")]
    //public interface IParentTeacherMeetingRepository : Communication.Interfaces.IParentTeacherMeetingRepository { }

    //// Financial Repositories
    //[Obsolete("Use Fees.Interfaces.IFeeStructureRepository instead.")]
    //public interface IFeeStructureRepository : SchoolManagementApp.ApplicationCore.Fees.Interfaces.IFeeStructureRepository { }

    //[Obsolete("Use Fees.Interfaces.IFeeInstallmentRepository instead.")]
    //public interface IFeeInstallmentRepository : SchoolManagementApp.ApplicationCore.Fees.Interfaces.IFeeInstallmentRepository { }

    //[Obsolete("Use Fees.Interfaces.IFeePaymentRepository instead.")]
    //public interface IFeePaymentRepository : SchoolManagementApp.ApplicationCore.Fees.Interfaces.IFeePaymentRepository { }

    //[Obsolete("Use Fees.Interfaces.IFeeRefundRepository instead.")]
    //public interface IFeeRefundRepository : SchoolManagementApp.ApplicationCore.Fees.Interfaces.IFeeRefundRepository { }

    //[Obsolete("Use Fees.Interfaces.IScholarshipRepository instead.")]
    //public interface IScholarshipRepository : SchoolManagementApp.ApplicationCore.Fees.Interfaces.IScholarshipRepository { }

    //[Obsolete("Use Fees.Interfaces.IScholarshipApplicationRepository instead.")]
    //public interface IScholarshipApplicationRepository : SchoolManagementApp.ApplicationCore.Fees.Interfaces.IScholarshipApplicationRepository { }

    //[Obsolete("Use Fees.Interfaces.IExpenseRepository instead.")]
    //public interface IExpenseRepository : SchoolManagementApp.ApplicationCore.Fees.Interfaces.IExpenseRepository { }

    //[Obsolete("Use Fees.Interfaces.IBudgetRepository instead.")]
    //public interface IBudgetRepository : SchoolManagementApp.ApplicationCore.Fees.Interfaces.IBudgetRepository { }

    //[Obsolete("Use Fees.Interfaces.IInvoiceRepository instead.")]
    //public interface IInvoiceRepository : SchoolManagementApp.ApplicationCore.Fees.Interfaces.IInvoiceRepository { }

    //[Obsolete("Use Fees.Interfaces.IFeeRuleRepository instead.")]
    //public interface IFeeRuleRepository : SchoolManagementApp.ApplicationCore.Fees.Interfaces.IFeeRuleRepository { }

    ////[Obsolete("Use Fees.Interfaces.IStudentLedgerRepository instead.")]
    ////public interface IStudentLedgerRepository : SchoolManagementApp.ApplicationCore.Fees.Interfaces.IStudentLedgerRepository { }

    //[Obsolete("Use Fees.Interfaces.IFeeNotificationLogRepository instead.")]
    //public interface IFeeNotificationLogRepository : SchoolManagementApp.ApplicationCore.Fees.Interfaces.IFeeNotificationLogRepository { }

    //[Obsolete("Use Fees.Interfaces.IMultiInstallmentPaymentRepository instead.")]
    //public interface IMultiInstallmentPaymentRepository : SchoolManagementApp.ApplicationCore.Fees.Interfaces.IMultiInstallmentPaymentRepository { }

    //[Obsolete("Use Fees.Interfaces.IFinanceAuditLogRepository instead.")]
    //public interface IFinanceAuditLogRepository : SchoolManagementApp.ApplicationCore.Fees.Interfaces.IFinanceAuditLogRepository { }

    //// Service Interfaces - [Obsolete] with inheritance from Communication.Interfaces
    //[Obsolete("Use Communication.Interfaces.IRealtimeNotificationService instead.")]
    //public interface IRealtimeNotificationService : Communication.Interfaces.IRealtimeNotificationService { }

    //[Obsolete("Use Communication.Interfaces.IEmailService instead.")]
    //public interface IEmailService : Communication.Interfaces.IEmailService { }

    //[Obsolete("Use Communication.Interfaces.ISmsService instead.")]
    //public interface ISmsService : Communication.Interfaces.ISmsService { }

    //[Obsolete("Use Communication.Interfaces.IFileStorageService instead.")]
    //public interface IFileStorageService : Communication.Interfaces.IFileStorageService { }

    //[Obsolete("Use Communication.Interfaces.IPaymentGatewayService instead.")]
    //public interface IPaymentGatewayService : Communication.Interfaces.IPaymentGatewayService { }

    //[Obsolete("Use Communication.Interfaces.IBackupService instead.")]
    //public interface IBackupService : Communication.Interfaces.IBackupService { }

    // Library Repositories (non-duplicate, keep as-is)
    public interface IBookRepository : IGenericRepository<Book>
    {
        Task<IEnumerable<Book>> SearchBooksAsync(string searchTerm);
        Task<IEnumerable<Book>> GetBooksByCategoryAsync(string category);
        Task<IEnumerable<Book>> GetAvailableBooksAsync();
        Task<Book> GetBookWithIssuesAsync(int id);
        Task<IEnumerable<Book>> GetPopularBooksAsync(int count = 10);
        Task<(IEnumerable<Book> books, int totalCount)> GetBooksAsync(string? search, string? category, string? status, int page, int pageSize);
        Task<int> GetBooksCountAsync(string? search, string? category, string? status);
        Task<int> GetIssuedBooksCountAsync(int studentId);
        Task<IEnumerable<Book>> GetOverdueBooksAsync();
        Task<object> GetLibraryUsageReportAsync(DateTime startDate, DateTime endDate);
    }

    public interface IBookIssueRepository : IGenericRepository<BookIssue>
    {
        Task<IEnumerable<BookIssue>> GetIssuesByMemberAsync(int memberId, string memberType);
        Task<IEnumerable<BookIssue>> GetOverdueIssuesAsync();
        Task<IEnumerable<BookIssue>> GetActiveIssuesAsync();
        Task<IEnumerable<BookIssue>> GetIssueHistoryByBookAsync(int bookId);
    }

    public interface IBookReservationRepository : IGenericRepository<BookReservation>
    {
        Task<IEnumerable<BookReservation>> GetReservationsByMemberAsync(int memberId, string memberType);
        Task<IEnumerable<BookReservation>> GetActiveReservationsAsync();
        Task<IEnumerable<BookReservation>> GetReservationsByBookAsync(int bookId);
    }

    public interface ILibraryMemberRepository : IGenericRepository<LibraryMember>
    {
        Task<LibraryMember> GetMemberByUserIdAsync(int userId, string userType);
        Task<IEnumerable<LibraryMember>> GetActiveMembersAsync();
        Task<IEnumerable<LibraryMember>> GetExpiringMembershipsAsync(int days = 30);
    }

    // Inventory Repositories
    public interface IInventoryCategoryRepository : IGenericRepository<InventoryCategory>
    {
        Task<IEnumerable<InventoryCategory>> GetActiveCategoriesAsync();
    }

    public interface IInventoryItemRepository : IGenericRepository<InventoryItem>
    {
        Task<IEnumerable<InventoryItem>> GetItemsByCategoryAsync(int categoryId);
        Task<IEnumerable<InventoryItem>> GetLowStockItemsAsync();
        Task<InventoryItem> GetItemWithTransactionsAsync(int id);
        Task<IEnumerable<InventoryItem>> SearchItemsAsync(string searchTerm);
        Task<(IEnumerable<InventoryItem> items, int totalCount)> GetInventoryAsync(string? search, string? category, int page, int pageSize);
        Task<int> GetInventoryCountAsync(string? search, string? category);
        Task AddTransactionAsync(InventoryTransaction transaction);
    }

    public interface IInventoryTransactionRepository : IGenericRepository<InventoryTransaction>
    {
        Task<IEnumerable<InventoryTransaction>> GetTransactionsByItemAsync(int itemId);
        Task<IEnumerable<InventoryTransaction>> GetTransactionsByTypeAsync(TransactionType type);
        Task<IEnumerable<InventoryTransaction>> GetPendingReturnsAsync();
    }

    public interface IMaintenanceRecordRepository : IGenericRepository<MaintenanceRecord>
    {
        Task<IEnumerable<MaintenanceRecord>> GetMaintenanceByItemAsync(int itemId);
        Task<IEnumerable<MaintenanceRecord>> GetScheduledMaintenanceAsync();
        Task<IEnumerable<MaintenanceRecord>> GetOverdueMaintenanceAsync();
    }

    public interface IAssetRepository : IGenericRepository<Asset>
    {
        Task<IEnumerable<Asset>> GetAssetsByCategoryAsync(AssetCategory category);
        Task<IEnumerable<Asset>> GetAssetsAssignedToUserAsync(int userId, string userType);
        Task<Asset> GetAssetWithTransfersAsync(int id);
        Task<IEnumerable<Asset>> GetAssetsNeedingMaintenanceAsync();
        Task<(IEnumerable<Asset> assets, int totalCount)> GetAssetsAsync(string? search, string? type, string? status, int page, int pageSize);
        Task<int> GetAssetsCountAsync(string? search, string? type, string? status);
        Task AddTransferAsync(AssetTransfer transfer);
    }

    public interface IAssetTransferRepository : IGenericRepository<AssetTransfer>
    {
        Task<IEnumerable<AssetTransfer>> GetTransfersByAssetAsync(int assetId);
        Task<IEnumerable<AssetTransfer>> GetTransfersByUserAsync(int userId, string userType);
    }

    // Analytics Repositories
    public interface IReportRepository : IGenericRepository<Report>
    {
        Task<IEnumerable<Report>> GetReportsByCategoryAsync(string category);
        Task<IEnumerable<Report>> GetSystemGeneratedReportsAsync();
        Task<Report> GetReportWithSchedulesAsync(int id);
        Task<IEnumerable<Report>> GetActiveReportsAsync();
    }

    public interface IReportScheduleRepository : IGenericRepository<ReportSchedule>
    {
        Task<IEnumerable<ReportSchedule>> GetSchedulesByReportAsync(int reportId);
        Task<IEnumerable<ReportSchedule>> GetActiveSchedulesAsync();
        Task<IEnumerable<ReportSchedule>> GetSchedulesDueForExecutionAsync();
    }

    public interface IReportExecutionRepository : IGenericRepository<ReportExecution>
    {
        Task<IEnumerable<ReportExecution>> GetExecutionsByReportAsync(int reportId);
        Task<IEnumerable<ReportExecution>> GetExecutionsByDateRangeAsync(DateTime startDate, DateTime endDate);
        Task<IEnumerable<ReportExecution>> GetFailedExecutionsAsync();
    }

    public interface IDashboardRepository : IGenericRepository<Dashboard>
    {
        Task<IEnumerable<Dashboard>> GetDashboardsByUserAsync(int userId, string userType);
        Task<Dashboard> GetDashboardWithWidgetsAsync(int id);
        Task<IEnumerable<Dashboard>> GetPublicDashboardsAsync();
        Task<IEnumerable<Dashboard>> GetDashboardsByTypeAsync(DashboardType type);
    }

    public interface IDashboardWidgetRepository : IGenericRepository<DashboardWidget>
    {
        Task<IEnumerable<DashboardWidget>> GetWidgetsByDashboardAsync(int dashboardId);
        Task<IEnumerable<DashboardWidget>> GetVisibleWidgetsAsync(int dashboardId);
    }

    public interface IAttendanceAnalyticsRepository : IGenericRepository<AttendanceAnalytics>
    {
        Task<IEnumerable<AttendanceAnalytics>> GetAnalyticsByStudentAsync(int studentId, int academicYearId);
        Task<IEnumerable<AttendanceAnalytics>> GetAnalyticsByClassAsync(int classId, int academicYearId);
        Task<IEnumerable<AttendanceAnalytics>> GetLowAttendanceStudentsAsync(decimal threshold = 75);
    }

    public interface IAcademicPerformanceRepository : IGenericRepository<AcademicPerformance>
    {
        Task<IEnumerable<AcademicPerformance>> GetPerformanceByStudentAsync(int studentId);
        Task<IEnumerable<AcademicPerformance>> GetPerformanceByExaminationAsync(int examinationId);
        Task<IEnumerable<AcademicPerformance>> GetTopPerformersAsync(int subjectId, int examinationId, int count = 10);
    }

    public interface IFinancialSummaryRepository : IGenericRepository<FinancialSummary>
    {
        Task<IEnumerable<FinancialSummary>> GetSummaryByAcademicYearAsync(int academicYearId);
        Task<FinancialSummary> GetSummaryByMonthAsync(int month, int year);
        Task<IEnumerable<FinancialSummary>> GetSummaryByDateRangeAsync(DateTime startDate, DateTime endDate);
    }

    public interface ISystemMetricsRepository : IGenericRepository<SystemMetrics>
    {
        Task<IEnumerable<SystemMetrics>> GetMetricsByDateRangeAsync(DateTime startDate, DateTime endDate);
        Task<SystemMetrics> GetLatestMetricsAsync();
        Task<IEnumerable<SystemMetrics>> GetMetricsTrendAsync(int days = 30);
    }

    //public interface IStudentFeeAssignmentRepository
    //{
    //    Task<IEnumerable<StudentFeeAssignment>> GetAssignmentsByStudentAsync(int studentId);
    //    Task<IEnumerable<StudentFeeAssignment>> GetAssignmentsByFeeStructureAsync(int feeStructureId);
    //    Task<StudentFeeAssignment?> GetCurrentAssignmentAsync(int studentId, int feeStructureId);
    //    Task<StudentFeeAssignment?> GetAssignmentsByStudentAndYearAsync(int studentId, int academicYearId);
    //    Task<StudentFeeAssignment> CreateAssignmentAsync(StudentFeeAssignment assignment);
    //    Task UpdateAssignmentAsync(StudentFeeAssignment assignment);
    //    Task DeactivateAssignmentAsync(int assignmentId);
    //    Task<StudentFeeAssignment?> GetByIdAsync(int id);
    //    Task<IEnumerable<StudentFeeAssignment>> GetAllAsync();
    //    IQueryable<StudentFeeAssignment> GetAllQueryable();
    //}
}
