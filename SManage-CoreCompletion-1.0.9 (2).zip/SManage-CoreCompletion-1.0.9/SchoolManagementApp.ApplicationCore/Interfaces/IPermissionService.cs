using System;
using System.ComponentModel;
using System.Security.Claims;

namespace SchoolManagementApp.ApplicationCore.Interfaces
{
    [Obsolete("Use SchoolManagementApp.ApplicationCore.Permissions.Interfaces.IPermissionService")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public interface IPermissionService : SchoolManagementApp.ApplicationCore.Permissions.Interfaces.IPermissionService
    {
        Task<bool> HasPermissionAsync(int userId, Permission permission);
        Task<bool> CanReadAsync(int userId, Permission permission);
        Task<bool> CanWriteAsync(int userId, Permission permission);
        Task<bool> CanDeleteAsync(int userId, Permission permission);
        Task<List<Permission>> GetUserPermissionsAsync(int userId);
        Task<Dictionary<Permission, PermissionLevel>> GetUserPermissionLevelsAsync(int userId);
        Task<bool> AssignRolePermissionAsync(UserRole role, Permission permission, bool canRead, bool canWrite, bool canDelete);
        Task<bool> GrantUserPermissionAsync(int userId, Permission permission, bool canRead, bool canWrite, bool canDelete);
        Task<bool> RevokeUserPermissionAsync(int userId, Permission permission);
        Task<List<RolePermission>> GetRolePermissionsAsync(UserRole role);
        Task<Dictionary<Permission, (bool CanRead, bool CanWrite, bool CanDelete)>> GetDefaultRolePermissionsAsync(UserRole role);
    }

    public class PermissionLevel
    {
        public bool CanRead { get; set; }
        public bool CanWrite { get; set; }
        public bool CanDelete { get; set; }

        public bool HasAnyAccess => CanRead || CanWrite || CanDelete;
    }
}
