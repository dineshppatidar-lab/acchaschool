using SchoolManagementApp.ApplicationCore.Entities;

namespace SchoolManagementApp.ApplicationCore.Audit
{
    /// <summary>
    /// Read-side query service for the security audit trail (AuditLog).
    /// Naming note: <c>IAuditService</c> (Common.Services) is the WRITE side;
    /// this interface is the tenant-scoped read side extracted from AuditLogController
    /// (docs/critical-issues/09-controller-service-refactoring.md, risk priority #3 —
    /// the audit trail must be tamper-resistant and tenant-isolated).
    /// </summary>
    public interface IAuditLogQueryService
    {
        /// <summary>Paged, filterable audit rows for the current tenant, newest first.</summary>
        Task<AuditLogPage> SearchAsync(AuditLogQuery query);

        /// <summary>Distinct filter dropdown values (actions, entities, users) for the current tenant.</summary>
        Task<AuditLogFacets> GetFacetsAsync();
    }

    /// <summary>Filter + paging parameters for <see cref="IAuditLogQueryService.SearchAsync"/>.</summary>
    public class AuditLogQuery
    {
        public int Page { get; init; } = 1;
        public int PageSize { get; init; } = 20;
        public string? Search { get; init; }
        public string? Action { get; init; }
        public string? Entity { get; init; }
        public string? User { get; init; }
        public DateTime? From { get; init; }
        public DateTime? To { get; init; }
    }

    /// <summary>One page of audit rows plus pagination metadata.</summary>
    public class AuditLogPage
    {
        public IReadOnlyList<AuditLog> Items { get; init; } = Array.Empty<AuditLog>();
        public int Page { get; init; }
        public int PageSize { get; init; }
        public int TotalRecords { get; init; }
        public int TotalPages { get; init; }
    }

    /// <summary>Distinct dropdown values for the audit log filter bar.</summary>
    public class AuditLogFacets
    {
        public IReadOnlyList<string> Actions { get; init; } = Array.Empty<string>();
        public IReadOnlyList<string> Entities { get; init; } = Array.Empty<string>();
        public IReadOnlyList<string> Users { get; init; } = Array.Empty<string>();
    }
}
