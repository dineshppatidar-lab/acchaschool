using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using SchoolManagementApp.ApplicationCore._Interfaces;

namespace SchoolManagementApp.ApplicationCore.Audit
{
    /// <summary>
    /// Tenant-scoped read side of the security audit trail (AuditLogController extraction,
    /// docs/critical-issues/09-controller-service-refactoring.md risk priority #3).
    ///
    /// Tenant guards: every query filters on TenantId explicitly AND relies on the EF
    /// global query filter (AuditLog is an ITenantEntity) — belt and suspenders, matching
    /// the pattern used by PermissionAdminService and SetupService. The service resolves
    /// the tenant itself from ITenantProvider; callers cannot pass a tenant id, so a
    /// forged tenant is impossible by construction.
    /// </summary>
    public class AuditLogQueryService : IAuditLogQueryService
    {
        private const int MaxPageSize = 100;
        private const int MaxFacets = 50;
        private const int MaxUserFacets = 100;

        private readonly IAppDbContext _context;
        private readonly ITenantProvider _tenantProvider;
        private readonly ILogger<AuditLogQueryService> _logger;

        public AuditLogQueryService(
            IAppDbContext context,
            ITenantProvider tenantProvider,
            ILogger<AuditLogQueryService> logger)
        {
            _context = context;
            _tenantProvider = tenantProvider;
            _logger = logger;
        }

        private int CurrentTenantId => _tenantProvider.TenantId > 0
            ? _tenantProvider.TenantId
            : 1; // mirrors ApplicationDbContext.CurrentTenantId fallback

        public Task<AuditLogPage> SearchAsync(AuditLogQuery query)
            => SearchAsyncInternal(Normalize(query));

        public Task<AuditLogFacets> GetFacetsAsync()
        {
            var tenantId = CurrentTenantId;

            async Task<AuditLogFacets> Impl()
            {
                var actions = await _context.Set<AuditLog>()
                    .AsNoTracking()
                    .Where(l => l.TenantId == tenantId)
                    .Select(l => l.Action)
                    .Distinct()
                    .OrderBy(a => a)
                    .Take(MaxFacets)
                    .ToListAsync();

                var entities = await _context.Set<AuditLog>()
                    .AsNoTracking()
                    .Where(l => l.TenantId == tenantId && !string.IsNullOrEmpty(l.Entity))
                    .Select(l => l.Entity)
                    .Distinct()
                    .OrderBy(e => e)
                    .Take(MaxFacets)
                    .ToListAsync();

                var users = await _context.Set<AuditLog>()
                    .AsNoTracking()
                    .Where(l => l.TenantId == tenantId && !string.IsNullOrEmpty(l.UserName))
                    .Select(l => l.UserName)
                    .Distinct()
                    .OrderBy(u => u)
                    .Take(MaxUserFacets)
                    .ToListAsync();

                return new AuditLogFacets { Actions = actions, Entities = entities, Users = users };
            }

            return Impl();
        }

        private async Task<AuditLogPage> SearchAsyncInternal(AuditLogQuery q)
        {
            var tenantId = CurrentTenantId;
            var query = _context.Set<AuditLog>()
                .AsNoTracking()
                .Where(l => l.TenantId == tenantId);

            if (!string.IsNullOrWhiteSpace(q.Search))
            {
                var term = q.Search.Trim();
                query = query.Where(l =>
                    EF.Functions.Like(l.UserName, $"%{term}%") ||
                    EF.Functions.Like(l.Action, $"%{term}%") ||
                    EF.Functions.Like(l.Entity, $"%{term}%") ||
                    EF.Functions.Like(l.EntityId, $"%{term}%") ||
                    EF.Functions.Like(l.Details, $"%{term}%"));
            }
            if (!string.IsNullOrWhiteSpace(q.Action))
                query = query.Where(l => l.Action == q.Action);
            if (!string.IsNullOrWhiteSpace(q.Entity))
                query = query.Where(l => l.Entity == q.Entity);
            if (!string.IsNullOrWhiteSpace(q.User))
                query = query.Where(l => l.UserName == q.User);
            if (q.From.HasValue)
                query = query.Where(l => l.Timestamp >= q.From.Value);
            if (q.To.HasValue)
                query = query.Where(l => l.Timestamp < q.To.Value.Date.AddDays(1));

            var total = await query.CountAsync();

            var items = await query
                .OrderByDescending(l => l.Timestamp)
                .ThenByDescending(l => l.Id)
                .Skip((q.Page - 1) * q.PageSize)
                .Take(q.PageSize)
                .ToListAsync();

            return new AuditLogPage
            {
                Items = items,
                Page = q.Page,
                PageSize = q.PageSize,
                TotalRecords = total,
                TotalPages = (int)Math.Ceiling(total / (double)q.PageSize)
            };
        }

        private static AuditLogQuery Normalize(AuditLogQuery? query)
        {
            var pageSize = query?.PageSize ?? 20;
            return new AuditLogQuery
            {
                Page = Math.Max(1, query?.Page ?? 1),
                PageSize = Math.Clamp(pageSize < 1 ? 20 : pageSize, 1, MaxPageSize),
                Search = query?.Search,
                Action = query?.Action,
                Entity = query?.Entity,
                User = query?.User,
                From = query?.From,
                To = query?.To
            };
        }
    }
}
