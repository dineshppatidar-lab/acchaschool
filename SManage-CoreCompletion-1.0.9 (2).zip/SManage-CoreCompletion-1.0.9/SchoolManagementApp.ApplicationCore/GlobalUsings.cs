// Global using directives for SchoolManagementApp.ApplicationCore
// These namespaces are used frequently across the project

global using System;
global using System.Collections.Generic;
global using System.ComponentModel;
global using System.ComponentModel.DataAnnotations;
global using System.Linq;
global using System.Reflection;
global using System.Text.Json.Serialization;
global using System.Threading.Tasks;

// Core namespaces (following CorporateFleet pattern)
global using SchoolManagementApp.ApplicationCore._Entities;
global using SchoolManagementApp.ApplicationCore._Interfaces;
global using SchoolManagementApp.ApplicationCore.Common.Constants;
global using SchoolManagementApp.ApplicationCore.Common.Exceptions;
global using SchoolManagementApp.ApplicationCore.Common.Enums;
global using SchoolManagementApp.ApplicationCore.Common.Models;

// Base entity namespace — safe, no naming conflicts
global using SchoolManagementApp.ApplicationCore.Entities;
global using SchoolManagementApp.ApplicationCore.Interfaces;
