using FluentValidation;
using SchoolManagementApp.ApplicationCore.Library.Dtos;

namespace SchoolManagementApp.ApplicationCore.Library.Validators
{
    public class LibraryRequestValidator : AbstractValidator<LibraryInventoryDto>
    {
        public LibraryRequestValidator()
        {
            RuleFor(x => x.Title).NotEmpty().MaximumLength(200);
            RuleFor(x => x.Author).NotEmpty().MaximumLength(100);
        }
    }
}
