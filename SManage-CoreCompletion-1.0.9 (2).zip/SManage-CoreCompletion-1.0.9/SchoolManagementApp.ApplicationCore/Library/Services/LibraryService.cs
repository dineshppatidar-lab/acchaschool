using Microsoft.Extensions.Logging;
using SchoolManagementApp.ApplicationCore.Library.Interfaces;
using SchoolManagementApp.ApplicationCore.Entities;
using IBookRepository = SchoolManagementApp.ApplicationCore.Library.Interfaces.IBookRepository;
using IAssetRepository = SchoolManagementApp.ApplicationCore.Library.Interfaces.IAssetRepository;
using IInventoryItemRepository = SchoolManagementApp.ApplicationCore.Library.Interfaces.IInventoryItemRepository;
using IMaintenanceRecordRepository = SchoolManagementApp.ApplicationCore.Library.Interfaces.IMaintenanceRecordRepository;
using IRealtimeNotificationService = SchoolManagementApp.ApplicationCore.Communication.Interfaces.IRealtimeNotificationService;

namespace SchoolManagementApp.ApplicationCore.Library.Services
{
    /// <summary>
    /// Service implementation for Library and Inventory operations
    /// </summary>
    public class LibraryService : ILibraryAppService
    {
        private readonly IBookRepository _bookRepository;
        private readonly IAssetRepository _assetRepository;
        private readonly IInventoryItemRepository _inventoryRepository;
        private readonly IMaintenanceRecordRepository _maintenanceRepository;
        private readonly IRealtimeNotificationService _notificationService;
        private readonly ILogger<LibraryService> _logger;

        public LibraryService(
            IBookRepository bookRepository,
            IAssetRepository assetRepository,
            IInventoryItemRepository inventoryRepository,
            IMaintenanceRecordRepository maintenanceRepository,
            IRealtimeNotificationService notificationService,
            ILogger<LibraryService> logger)
        {
            _bookRepository = bookRepository;
            _assetRepository = assetRepository;
            _inventoryRepository = inventoryRepository;
            _maintenanceRepository = maintenanceRepository;
            _notificationService = notificationService;
            _logger = logger;
        }

        // ==================== Book Operations ====================

        public async Task<(IEnumerable<Book> Books, int Total)> GetBooksAsync(
            string search, string category, string? status, int page, int pageSize)
        {
            return await _bookRepository.GetBooksAsync(search, category, status, page, pageSize);
        }

        public async Task<Book?> GetBookByIdAsync(int id)
        {
            return await _bookRepository.GetByIdAsync(id);
        }

        public async Task<Book> CreateBookAsync(Book book, string? createdByUserId)
        {
            book.CreatedOn = DateTime.UtcNow;
            book.Status = BookStatus.Available;
            book.CreatedBy = createdByUserId;

            var createdBook = await _bookRepository.AddAsync(book);

            await _notificationService.SendNotificationAsync(
                "Library",
                $"New book '{book.Title}' added to library",
                new[] { "Librarian", "Staff" });

            return createdBook;
        }

        public async Task<Book> UpdateBookAsync(int id, Book book)
        {
            var existingBook = await _bookRepository.GetByIdAsync(id);
            if (existingBook == null)
                throw new InvalidOperationException($"Book with ID {id} not found");

            await _bookRepository.UpdateAsync(book);
            return book;
        }

        public async Task<Book> IssueBookAsync(int bookId, int studentId, int? issuePeriodDays, string? staffUserId)
        {
            var book = await _bookRepository.GetByIdAsync(bookId);
            if (book == null)
                throw new InvalidOperationException($"Book with ID {bookId} not found");

            if (book.Status != BookStatus.Available)
                throw new InvalidOperationException("Book is not available for issue");

            var issuedCount = await _bookRepository.GetIssuedBooksCountAsync(studentId);
            if (issuedCount >= 5)
                throw new InvalidOperationException("Student has reached maximum book issue limit");

            book.Status = BookStatus.Issued;
            book.IssuedToStudentId = studentId;
            book.IssueDate = DateTime.UtcNow;
            book.DueDate = DateTime.UtcNow.AddDays(issuePeriodDays ?? 14);

            if (int.TryParse(staffUserId, out int userId))
            {
                book.IssuedByStaffId = userId;
            }

            await _bookRepository.UpdateAsync(book);

            await _notificationService.SendNotificationAsync(
                "Library",
                $"Book '{book.Title}' issued. Due date: {book.DueDate:yyyy-MM-dd}",
                new[] { studentId.ToString() });

            return book;
        }

        public async Task<(Book Book, decimal FineAmount, bool IsOverdue, int OverdueDays)> ReturnBookAsync(
            int bookId, BookCondition condition, string? notes)
        {
            var book = await _bookRepository.GetByIdAsync(bookId);
            if (book == null)
                throw new InvalidOperationException($"Book with ID {bookId} not found");

            if (book.Status != BookStatus.Issued)
                throw new InvalidOperationException("Book is not currently issued");

            var returnDate = DateTime.UtcNow;
            var fineAmount = 0m;

            if (returnDate > book.DueDate)
            {
                var overdueDays = (returnDate - book.DueDate.Value).Days;
                fineAmount = overdueDays * 2m; // ₹2 per day fine
            }

            book.Status = BookStatus.Available;
            book.ReturnDate = returnDate;
            book.FineAmount = fineAmount;
            book.BookCondition = condition.ToString();
            book.ReturnNotes = notes;

            book.IssuedToStudentId = null;
            book.IssueDate = null;
            book.DueDate = null;

            await _bookRepository.UpdateAsync(book);

            var isOverdue = returnDate > book.DueDate;
            var overdueDaysResult = isOverdue ? (returnDate - book.DueDate.Value).Days : 0;

            return (book, fineAmount, isOverdue, overdueDaysResult);
        }

        public async Task<IEnumerable<Book>> GetOverdueBooksAsync()
        {
            return await _bookRepository.GetOverdueBooksAsync();
        }

        // ==================== Asset Operations ====================

        public async Task<(IEnumerable<Asset> Assets, int Total)> GetAssetsAsync(
            string search, string? type, string? status, int page, int pageSize)
        {
            return await _assetRepository.GetAssetsAsync(search, type, status, page, pageSize);
        }

        public async Task<Asset?> GetAssetByIdAsync(int id)
        {
            return await _assetRepository.GetByIdAsync(id);
        }

        public async Task<Asset> CreateAssetAsync(Asset asset)
        {
            asset.PurchaseDate = DateTime.UtcNow;
            asset.Status = AssetStatus.Available;
            return await _assetRepository.AddAsync(asset);
        }

        public async Task<AssetTransfer> TransferAssetAsync(int assetId, AssetTransferRequest request, string? staffUserId)
        {
            var asset = await _assetRepository.GetByIdAsync(assetId);
            if (asset == null)
                throw new InvalidOperationException($"Asset with ID {assetId} not found");

            var transfer = new AssetTransfer
            {
                AssetId = assetId,
                FromDepartment = asset.AssignedDepartment,
                ToDepartment = request.ToDepartment,
                TransferDate = DateTime.UtcNow,
                TransferReason = request.Reason,
                Notes = request.Notes
            };

            if (int.TryParse(staffUserId, out int userId))
            {
                transfer.ApprovedBy = userId;
            }

            asset.AssignedDepartment = request.ToDepartment;
            asset.Location = request.NewLocation;

            await _assetRepository.UpdateAsync(asset);
            await _assetRepository.AddTransferAsync(transfer);

            return transfer;
        }

        // ==================== Inventory Operations ====================

        public async Task<(IEnumerable<InventoryItem> Items, int Total)> GetInventoryAsync(
            string search, string? category, int page, int pageSize)
        {
            return await _inventoryRepository.GetInventoryAsync(search, category, page, pageSize);
        }

        public async Task<InventoryItem?> GetInventoryItemByIdAsync(int id)
        {
            return await _inventoryRepository.GetByIdAsync(id);
        }

        public async Task<InventoryTransaction> CreateInventoryTransactionAsync(
            int itemId, InventoryTransactionRequest request, string? staffUserId)
        {
            var item = await _inventoryRepository.GetByIdAsync(itemId);
            if (item == null)
                throw new InvalidOperationException($"Inventory item with ID {itemId} not found");

            if (request.TransactionType == InventoryTransactionType.Out &&
                request.Quantity > item.AvailableQuantity)
                throw new InvalidOperationException("Insufficient stock for outward transaction");

            var transaction = new InventoryTransaction
            {
                ItemId = itemId,
                Type = (TransactionType)request.TransactionType,
                Quantity = request.Quantity,
                TransactionDate = DateTime.UtcNow,
                Purpose = request.Purpose,
                Remarks = request.Notes
            };

            if (int.TryParse(staffUserId, out int userId))
            {
                transaction.ProcessedBy = userId;
            }

            if (request.TransactionType == InventoryTransactionType.In)
                item.AvailableQuantity += request.Quantity;
            else
                item.AvailableQuantity -= request.Quantity;

            item.UpdatedOn = DateTime.UtcNow;

            await _inventoryRepository.UpdateAsync(item);
            await _inventoryRepository.AddTransactionAsync(transaction);

            if (item.AvailableQuantity <= item.ReorderLevel)
            {
                await _notificationService.SendNotificationAsync(
                    "Inventory Alert",
                    $"Low stock alert: {item.Name} (Current: {item.AvailableQuantity}, Minimum: {item.ReorderLevel})",
                    new[] { "Admin", "Staff" });
            }

            return transaction;
        }

        public async Task<IEnumerable<InventoryItem>> GetLowStockItemsAsync()
        {
            return await _inventoryRepository.GetLowStockItemsAsync();
        }

        // ==================== Maintenance Operations ====================

        public async Task<MaintenanceRecord> ScheduleMaintenanceAsync(
            int assetId, MaintenanceScheduleRequest request, string? staffUserId)
        {
            var asset = await _assetRepository.GetByIdAsync(assetId);
            if (asset == null)
                throw new InvalidOperationException($"Asset with ID {assetId} not found");

            var maintenance = new MaintenanceRecord
            {
                AssetId = assetId,
                Type = request.MaintenanceType,
                ScheduledDate = request.ScheduledDate,
                Description = request.Description,
                Priority = request.Priority.ToString(),
                Status = MaintenanceStatus.Scheduled,
                EstimatedCost = request.EstimatedCost,
                CreatedOn = DateTime.UtcNow
            };

            if (int.TryParse(staffUserId, out int userId))
            {
                maintenance.RequestedBy = userId;
            }

            var createdMaintenance = await _maintenanceRepository.AddAsync(maintenance);

            if (request.Priority == MaintenancePriority.Critical)
            {
                asset.Status = AssetStatus.UnderMaintenance;
                await _assetRepository.UpdateAsync(asset);
            }

            return createdMaintenance;
        }

        public async Task<MaintenanceRecord> CompleteMaintenanceAsync(
            int maintenanceId, MaintenanceCompletionRequest request, string? staffUserId)
        {
            var maintenance = await _maintenanceRepository.GetByIdAsync(maintenanceId);
            if (maintenance == null)
                throw new InvalidOperationException($"Maintenance record with ID {maintenanceId} not found");

            maintenance.Status = MaintenanceStatus.Completed;
            maintenance.CompletedDate = DateTime.UtcNow;
            maintenance.ActualCost = request.ActualCost;
            maintenance.CompletionNotes = request.CompletionNotes;

            if (int.TryParse(staffUserId, out int userId))
            {
                maintenance.CompletedBy = userId;
            }

            await _maintenanceRepository.UpdateAsync(maintenance);

            if (maintenance.AssetId.HasValue)
            {
                var asset = await _assetRepository.GetByIdAsync(maintenance.AssetId.Value);
                if (asset != null)
                {
                    asset.Status = AssetStatus.Available;
                    asset.LastMaintenanceDate = DateTime.UtcNow;
                    await _assetRepository.UpdateAsync(asset);
                }
            }

            return maintenance;
        }

        // ==================== Reports ====================

        public async Task<object> GetLibraryUsageReportAsync(DateTime startDate, DateTime endDate)
        {
            return await _bookRepository.GetLibraryUsageReportAsync(startDate, endDate);
        }
    }
}
