namespace SchoolManagementApp.ApplicationCore.Library.Dtos
{
    public class LibraryInventoryDto
    {
        public int Id { get; set; }
        public string Title { get; set; } = string.Empty;
        public string Author { get; set; } = string.Empty;
    }
}