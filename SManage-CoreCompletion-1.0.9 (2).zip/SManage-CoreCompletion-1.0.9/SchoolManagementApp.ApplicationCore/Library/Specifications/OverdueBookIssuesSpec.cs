using Ardalis.Specification;
using SchoolManagementApp.ApplicationCore.Entities;

namespace SchoolManagementApp.ApplicationCore.Library.Specifications
{
    public class OverdueBookIssuesSpec : Specification<BookIssue>
    {
        public OverdueBookIssuesSpec()
        {
            Query.Where(bi => bi.ReturnDate == null && bi.DueDate < DateTime.UtcNow)
                 .OrderBy(bi => bi.DueDate)
                 .Include(bi => bi.Book)
                 .Include(bi => bi.Student);
        }
    }
}
