using Ardalis.Specification;
using SchoolManagementApp.ApplicationCore.Entities;

namespace SchoolManagementApp.ApplicationCore.Library.Specifications
{
    /// <summary>
    /// Specification to filter books by category.
    /// </summary>
    public class BooksByCategorySpec : Specification<Book>
    {
        public BooksByCategorySpec(string category)
        {
            Query.Where(b => b.Category == category)
                 .OrderBy(b => b.Title);
        }
    }
}
