using Ardalis.Specification;
using SchoolManagementApp.ApplicationCore.Entities;

namespace SchoolManagementApp.ApplicationCore.Library.Specifications
{
    public class AvailableBooksSpec : Specification<Book>
    {
        public AvailableBooksSpec()
        {
            Query.Where(b => b.AvailableCopies > 0 && b.Status == BookStatus.Available)
                 .OrderBy(b => b.Title);
        }
    }
}
