using Ardalis.Specification;
using SchoolManagementApp.ApplicationCore.Entities;

namespace SchoolManagementApp.ApplicationCore.Library.Specifications
{
    public class BookIssuesByStudentSpec : Specification<BookIssue>
    {
        public BookIssuesByStudentSpec(int studentId)
        {
            Query.Where(bi => bi.StudentId == studentId)
                 .OrderByDescending(bi => bi.IssueDate)
                 .Include(bi => bi.Book);
        }
    }
}
