namespace SchoolManagementApp.ApplicationCore.Library.Interfaces
{
    /// <summary>
    /// Service interface for Library and Inventory operations
    /// Moved from Students/Interfaces/ per CorporateFleet module pattern.
    /// </summary>
    public interface ILibraryAppService
    {
        // Book Operations
        Task<(IEnumerable<Book> Books, int Total)> GetBooksAsync(
            string search, string category, string? status, int page, int pageSize);
        Task<Book?> GetBookByIdAsync(int id);
        Task<Book> CreateBookAsync(Book book, string? createdByUserId);
        Task<Book> UpdateBookAsync(int id, Book book);
        Task<Book> IssueBookAsync(int bookId, int studentId, int? issuePeriodDays, string? staffUserId);
        Task<(Book Book, decimal FineAmount, bool IsOverdue, int OverdueDays)> ReturnBookAsync(
            int bookId, BookCondition condition, string? notes);
        Task<IEnumerable<Book>> GetOverdueBooksAsync();

        // Asset Operations
        Task<(IEnumerable<Asset> Assets, int Total)> GetAssetsAsync(
            string search, string? type, string? status, int page, int pageSize);
        Task<Asset?> GetAssetByIdAsync(int id);
        Task<Asset> CreateAssetAsync(Asset asset);
        Task<AssetTransfer> TransferAssetAsync(int assetId, AssetTransferRequest request, string? staffUserId);

        // Inventory Operations
        Task<(IEnumerable<InventoryItem> Items, int Total)> GetInventoryAsync(
            string search, string? category, int page, int pageSize);
        Task<InventoryItem?> GetInventoryItemByIdAsync(int id);
        Task<InventoryTransaction> CreateInventoryTransactionAsync(
            int itemId, InventoryTransactionRequest request, string? staffUserId);
        Task<IEnumerable<InventoryItem>> GetLowStockItemsAsync();

        // Maintenance Operations
        Task<MaintenanceRecord> ScheduleMaintenanceAsync(
            int assetId, MaintenanceScheduleRequest request, string? staffUserId);
        Task<MaintenanceRecord> CompleteMaintenanceAsync(
            int maintenanceId, MaintenanceCompletionRequest request, string? staffUserId);

        // Reports
        Task<object> GetLibraryUsageReportAsync(DateTime startDate, DateTime endDate);
    }

    // Request DTOs for Library Service
    public class AssetTransferRequest
    {
        public string ToDepartment { get; set; } = string.Empty;
        public string NewLocation { get; set; } = string.Empty;
        public string Reason { get; set; } = string.Empty;
        public string Notes { get; set; } = string.Empty;
    }

    public class InventoryTransactionRequest
    {
        public InventoryTransactionType TransactionType { get; set; }
        public int Quantity { get; set; }
        public string Purpose { get; set; } = string.Empty;
        public string Notes { get; set; } = string.Empty;
    }

    public class MaintenanceScheduleRequest
    {
        public MaintenanceType MaintenanceType { get; set; }
        public DateTime ScheduledDate { get; set; }
        public string Description { get; set; } = string.Empty;
        public MaintenancePriority Priority { get; set; }
        public decimal? EstimatedCost { get; set; }
    }

    public class MaintenanceCompletionRequest
    {
        public decimal? ActualCost { get; set; }
        public string CompletionNotes { get; set; } = string.Empty;
    }
}
