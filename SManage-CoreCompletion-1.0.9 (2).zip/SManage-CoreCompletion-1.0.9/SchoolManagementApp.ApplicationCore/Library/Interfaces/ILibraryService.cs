
namespace SchoolManagementApp.ApplicationCore.Library.Interfaces
{
    /// <summary>
    /// Service interface for Library and Inventory operations
    /// </summary>
    [Obsolete("Use ILibraryAppService instead. This interface will be removed in Phase 2.")]
    public interface ILibraryService : ILibraryAppService { }

    // Request DTOs moved to ILibraryAppService.cs (canonical location)
}
