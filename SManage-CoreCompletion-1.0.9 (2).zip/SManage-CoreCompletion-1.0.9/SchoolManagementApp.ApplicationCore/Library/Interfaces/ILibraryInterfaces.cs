
namespace SchoolManagementApp.ApplicationCore.Library.Interfaces
{
    public interface IBookRepository : IGenericRepository<Book>
    {
        Task<IEnumerable<Book>> SearchBooksAsync(string searchTerm);
        Task<IEnumerable<Book>> GetBooksByCategoryAsync(string category);
        Task<IEnumerable<Book>> GetAvailableBooksAsync();
        Task<Book> GetBookWithIssuesAsync(int id);
        Task<IEnumerable<Book>> GetPopularBooksAsync(int count = 10);
        Task<(IEnumerable<Book> books, int totalCount)> GetBooksAsync(string? search, string? category, string? status, int page, int pageSize);
        Task<int> GetBooksCountAsync(string? search, string? category, string? status);
        Task<int> GetIssuedBooksCountAsync(int studentId);
        Task<IEnumerable<Book>> GetOverdueBooksAsync();
        Task<object> GetLibraryUsageReportAsync(DateTime startDate, DateTime endDate);
    }

    public interface IBookIssueRepository : IGenericRepository<BookIssue>
    {
        Task<IEnumerable<BookIssue>> GetIssuesByMemberAsync(int memberId, string memberType);
        Task<IEnumerable<BookIssue>> GetOverdueIssuesAsync();
        Task<IEnumerable<BookIssue>> GetActiveIssuesAsync();
        Task<IEnumerable<BookIssue>> GetIssueHistoryByBookAsync(int bookId);
    }

    public interface IBookReservationRepository : IGenericRepository<BookReservation>
    {
        Task<IEnumerable<BookReservation>> GetReservationsByMemberAsync(int memberId, string memberType);
        Task<IEnumerable<BookReservation>> GetActiveReservationsAsync();
        Task<IEnumerable<BookReservation>> GetReservationsByBookAsync(int bookId);
    }

    public interface ILibraryMemberRepository : IGenericRepository<LibraryMember>
    {
        Task<LibraryMember> GetMemberByUserIdAsync(int userId, string userType);
        Task<IEnumerable<LibraryMember>> GetActiveMembersAsync();
        Task<IEnumerable<LibraryMember>> GetExpiringMembershipsAsync(int days = 30);
    }

    public interface IInventoryCategoryRepository : IGenericRepository<InventoryCategory>
    {
        Task<IEnumerable<InventoryCategory>> GetActiveCategoriesAsync();
    }

    public interface IInventoryItemRepository : IGenericRepository<InventoryItem>
    {
        Task<IEnumerable<InventoryItem>> GetItemsByCategoryAsync(int categoryId);
        Task<IEnumerable<InventoryItem>> GetLowStockItemsAsync();
        Task<InventoryItem> GetItemWithTransactionsAsync(int id);
        Task<IEnumerable<InventoryItem>> SearchItemsAsync(string searchTerm);
        Task<(IEnumerable<InventoryItem> items, int totalCount)> GetInventoryAsync(string? search, string? category, int page, int pageSize);
        Task<int> GetInventoryCountAsync(string? search, string? category);
        Task AddTransactionAsync(InventoryTransaction transaction);
    }

    public interface IInventoryTransactionRepository : IGenericRepository<InventoryTransaction>
    {
        Task<IEnumerable<InventoryTransaction>> GetTransactionsByItemAsync(int itemId);
        Task<IEnumerable<InventoryTransaction>> GetTransactionsByTypeAsync(TransactionType type);
        Task<IEnumerable<InventoryTransaction>> GetPendingReturnsAsync();
    }

    public interface IMaintenanceRecordRepository : IGenericRepository<MaintenanceRecord>
    {
        Task<IEnumerable<MaintenanceRecord>> GetMaintenanceByItemAsync(int itemId);
        Task<IEnumerable<MaintenanceRecord>> GetScheduledMaintenanceAsync();
        Task<IEnumerable<MaintenanceRecord>> GetOverdueMaintenanceAsync();
    }

    public interface IAssetRepository : IGenericRepository<Asset>
    {
        Task<IEnumerable<Asset>> GetAssetsByCategoryAsync(AssetCategory category);
        Task<IEnumerable<Asset>> GetAssetsAssignedToUserAsync(int userId, string userType);
        Task<Asset> GetAssetWithTransfersAsync(int id);
        Task<IEnumerable<Asset>> GetAssetsNeedingMaintenanceAsync();
        Task<(IEnumerable<Asset> assets, int totalCount)> GetAssetsAsync(string? search, string? type, string? status, int page, int pageSize);
        Task<int> GetAssetsCountAsync(string? search, string? type, string? status);
        Task AddTransferAsync(AssetTransfer transfer);
    }

    public interface IAssetTransferRepository : IGenericRepository<AssetTransfer>
    {
        Task<IEnumerable<AssetTransfer>> GetTransfersByAssetAsync(int assetId);
        Task<IEnumerable<AssetTransfer>> GetTransfersByUserAsync(int userId, string userType);
    }
}
