using AutoMapper;
using SchoolManagementApp.ApplicationCore.Entities;
using SchoolManagementApp.ApplicationCore.Library.Dtos;

namespace SchoolManagementApp.ApplicationCore.Library
{
    public class LibraryObjectMapping : Profile
    {
        public LibraryObjectMapping()
        {
            CreateMap<Entities.Book, LibraryInventoryDto>().ReverseMap();
        }
    }
}
