using Microsoft.AspNetCore.Http;
using SchoolManagementApp.ApplicationCore.Staff.Interfaces;
using IPayrollRepository = SchoolManagementApp.ApplicationCore.Payroll.Interfaces.IPayrollRepository;
using IPayrollService = SchoolManagementApp.ApplicationCore.Payroll.Interfaces.IPayrollService;

namespace SchoolManagementApp.ApplicationCore.Payroll.Services
{
    public class PayrollService : IPayrollService
    {
        private readonly IPayrollRepository _payrollRepository;
        private readonly IStaffRepository _staffRepository;
        private readonly IHttpContextAccessor _httpContextAccessor;

        public PayrollService(IPayrollRepository payrollRepository, IStaffRepository staffRepository, IHttpContextAccessor httpContextAccessor)
        {
            _payrollRepository = payrollRepository;
            _staffRepository = staffRepository;
            _httpContextAccessor = httpContextAccessor;
        }
        
        protected int GetCurrentTenantId()
        {
            if (_httpContextAccessor?.HttpContext?.Items["TenantId"] is int tenantId)
            {
                return tenantId;
            }
            return 1; 
        }

        public async Task<SalaryStructure?> GetSalaryStructureAsync(int staffId)
        {
            return await _payrollRepository.GetSalaryStructureAsync(staffId);
        }

        public async Task<SalaryStructure> UpsertSalaryStructureAsync(int staffId, SalaryStructure structure)
        {
            structure.StaffId = staffId;
            structure.TenantId = GetCurrentTenantId();
            return await _payrollRepository.UpsertSalaryStructureAsync(structure);
        }

        public async Task<IEnumerable<PayrollRun>> GetPayrollRunsAsync()
        {
            return await _payrollRepository.GetPayrollRunsAsync();
        }

        public async Task<PayrollRun?> GetPayrollRunDetailsAsync(int id)
        {
            return await _payrollRepository.GetPayrollRunDetailsAsync(id);
        }

        public async Task<PayrollRun> ProcessPayrollAsync(int year, int month, int processedByUserId)
        {
            var tenantId = GetCurrentTenantId();
            var activeStaff = await _staffRepository.GetAllAsync(); // For best practice, ensure this queries only active staff

            var run = new PayrollRun
            {
                TenantId = tenantId,
                Year = year,
                Month = month,
                ProcessedDate = DateTime.UtcNow,
                ProcessedBy = processedByUserId,
                Status = "Processed",
                TotalAmount = 0
            };

            run = await _payrollRepository.CreatePayrollRunAsync(run);

            var payslips = new List<Payslip>();
            decimal totalAmount = 0;

            foreach (var staff in activeStaff)
            {
                var structure = await _payrollRepository.GetSalaryStructureAsync(staff.Id);
                
                decimal basicSalary = structure?.BasicSalary ?? 0m;
                decimal allowances = 0m;
                decimal deductions = 0m;
                
                if (structure != null && structure.Components != null)
                {
                    allowances = structure.Components.Where(c => c.Type == ComponentType.Allowance).Sum(c => c.IsPercentage ? basicSalary * (c.Amount / 100) : c.Amount);
                    deductions = structure.Components.Where(c => c.Type == ComponentType.Deduction).Sum(c => c.IsPercentage ? basicSalary * (c.Amount / 100) : c.Amount);
                }
                
                decimal netPay = (basicSalary + allowances) - deductions;

                var payslip = new Payslip
                {
                    TenantId = tenantId,
                    StaffId = staff.Id,
                    Month = month,
                    Year = year,
                    BasicSalary = basicSalary,
                    TotalAllowances = allowances,
                    TotalDeductions = deductions,
                    LwpDeduction = 0,
                    NetPay = netPay,
                    Status = PayslipStatus.Draft,
                    PayrollRunId = run.Id
                };

                payslips.Add(payslip);
                totalAmount += netPay;
            }

            await _payrollRepository.CreateBatchPayslipsAsync(payslips);

            run.TotalAmount = totalAmount;
            // Optionally save context changes for run updates if they aren't explicitly tracked automatically by EF context scopes
            return run;
        }

        public async Task<Payslip?> GeneratePayslipAsync(int staffId, int month, int year)
        {
            var tenantId = GetCurrentTenantId();
            var structure = await _payrollRepository.GetSalaryStructureAsync(staffId);
            
            decimal basicSalary = structure?.BasicSalary ?? 0m;
            decimal allowances = 0m;
            decimal deductions = 0m;
            
            if (structure != null && structure.Components != null)
            {
                allowances = structure.Components.Where(c => c.Type == ComponentType.Allowance).Sum(c => c.IsPercentage ? basicSalary * (c.Amount / 100) : c.Amount);
                deductions = structure.Components.Where(c => c.Type == ComponentType.Deduction).Sum(c => c.IsPercentage ? basicSalary * (c.Amount / 100) : c.Amount);
            }
            
            decimal netPay = (basicSalary + allowances) - deductions;

            var payslip = new Payslip
            {
                TenantId = tenantId,
                StaffId = staffId,
                Month = month,
                Year = year,
                BasicSalary = basicSalary,
                TotalAllowances = allowances,
                TotalDeductions = deductions,
                LwpDeduction = 0,
                NetPay = netPay,
                Status = PayslipStatus.Draft
            };

            return await _payrollRepository.CreatePayslipAsync(payslip);
        }

        public async Task<IEnumerable<Payslip>> GenerateBatchPayslipsAsync(int month, int year)
        {
            // This safely wraps the individual batch logic we already wrote
            var run = await ProcessPayrollAsync(year, month, 1);
            return run.Payslips;
        }

        public async Task<Payslip?> MarkPayslipAsPaidAsync(int payslipId, string transactionId)
        {
            var payslip = await _payrollRepository.GetPayslipAsync(payslipId);
            if (payslip != null)
            {
                payslip.Status = PayslipStatus.Paid;
                payslip.TransactionId = transactionId;
                payslip.PaymentDate = DateTime.UtcNow;
                await _payrollRepository.UpdatePayslipAsync(payslip);
            }
            return payslip;
        }
    }
}