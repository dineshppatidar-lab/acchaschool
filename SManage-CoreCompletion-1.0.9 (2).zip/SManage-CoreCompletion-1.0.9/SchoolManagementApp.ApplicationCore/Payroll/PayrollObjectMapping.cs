using AutoMapper;
using SchoolManagementApp.ApplicationCore.Entities;
using SchoolManagementApp.ApplicationCore.Payroll.Dtos;

namespace SchoolManagementApp.ApplicationCore.Payroll
{
    public class PayrollObjectMapping : Profile
    {
        public PayrollObjectMapping()
        {
            CreateMap<Entities.SalaryStructure, PayrollDto>().ReverseMap();
        }
    }
}
