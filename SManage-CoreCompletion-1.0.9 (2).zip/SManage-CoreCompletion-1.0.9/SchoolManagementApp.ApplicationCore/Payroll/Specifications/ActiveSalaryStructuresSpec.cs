using Ardalis.Specification;
using SchoolManagementApp.ApplicationCore.Entities;

namespace SchoolManagementApp.ApplicationCore.Payroll.Specifications
{
    /// <summary>
    /// Specification to filter active salary structures.
    /// </summary>
    public class ActiveSalaryStructuresSpec : Specification<SalaryStructure>
    {
        public ActiveSalaryStructuresSpec()
        {
            Query.Where(ss => ss.IsActive)
                 .OrderBy(ss => ss.BasicSalary)
                 .Include(ss => ss.Components)
                 .Include(ss => ss.Staff);
        }
    }
}
