using Ardalis.Specification;
using SchoolManagementApp.ApplicationCore.Entities;

namespace SchoolManagementApp.ApplicationCore.Payroll.Specifications
{
    public class PayrollRunByMonthYearSpec : Specification<PayrollRun>
    {
        public PayrollRunByMonthYearSpec(int month, int year)
        {
            Query.Where(pr => pr.Month == month && pr.Year == year)
                 .Include(pr => pr.Payslips);
        }
    }
}
