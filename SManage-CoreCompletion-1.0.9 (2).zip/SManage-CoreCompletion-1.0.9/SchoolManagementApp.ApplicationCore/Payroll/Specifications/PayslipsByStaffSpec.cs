using Ardalis.Specification;
using SchoolManagementApp.ApplicationCore.Entities;

namespace SchoolManagementApp.ApplicationCore.Payroll.Specifications
{
    public class PayslipsByStaffSpec : Specification<Payslip>
    {
        public PayslipsByStaffSpec(int staffId)
        {
            Query.Where(p => p.StaffId == staffId)
                 .OrderByDescending(p => p.PaymentDate)
                 .Include(p => p.PayrollRun);
        }
    }
}
