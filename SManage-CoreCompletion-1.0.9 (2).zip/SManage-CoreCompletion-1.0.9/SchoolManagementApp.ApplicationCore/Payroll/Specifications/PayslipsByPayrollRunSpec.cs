using Ardalis.Specification;
using SchoolManagementApp.ApplicationCore.Entities;

namespace SchoolManagementApp.ApplicationCore.Payroll.Specifications
{
    public class PayslipsByPayrollRunSpec : Specification<Payslip>
    {
        public PayslipsByPayrollRunSpec(int payrollRunId)
        {
            Query.Where(p => p.PayrollRunId == payrollRunId)
                 .OrderBy(p => p.Staff.LastName)
                 .Include(p => p.Staff);
        }
    }
}
