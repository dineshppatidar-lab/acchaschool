using FluentValidation;
using SchoolManagementApp.ApplicationCore.Payroll.Dtos;

namespace SchoolManagementApp.ApplicationCore.Payroll.Validators
{
    public class PayrollRequestValidator : AbstractValidator<PayrollDto>
    {
        public PayrollRequestValidator()
        {
            RuleFor(x => x.Amount).GreaterThan(0);
            RuleFor(x => x.Status).NotEmpty();
        }
    }
}
