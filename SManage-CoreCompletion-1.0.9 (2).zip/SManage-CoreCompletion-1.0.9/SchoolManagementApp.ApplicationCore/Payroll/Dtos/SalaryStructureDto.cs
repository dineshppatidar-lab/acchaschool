
namespace SchoolManagementApp.ApplicationCore.Payroll.Dtos
{
    public class SalaryStructureDto
    {
        public int Id { get; set; }
        public int StaffId { get; set; }
        public decimal BasicSalary { get; set; }
        public DateTime EffectiveDate { get; set; }
        public bool IsActive { get; set; }

        public List<SalaryComponentDto> Components { get; set; } = new List<SalaryComponentDto>();
    }

    public class SalaryComponentDto
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public ComponentType Type { get; set; }
        public decimal Amount { get; set; }
        public bool IsPercentage { get; set; }
    }
}
