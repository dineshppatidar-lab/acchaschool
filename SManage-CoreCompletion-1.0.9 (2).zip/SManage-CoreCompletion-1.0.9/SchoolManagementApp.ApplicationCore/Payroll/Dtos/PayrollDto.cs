namespace SchoolManagementApp.ApplicationCore.Payroll.Dtos
{
    public class PayrollDto
    {
        public int Id { get; set; }
        public decimal Amount { get; set; }
        public string Status { get; set; } = string.Empty;
    }
}