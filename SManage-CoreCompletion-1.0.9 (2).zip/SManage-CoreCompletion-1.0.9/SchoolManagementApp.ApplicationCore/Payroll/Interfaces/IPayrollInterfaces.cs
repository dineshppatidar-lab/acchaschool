
namespace SchoolManagementApp.ApplicationCore.Payroll.Interfaces
{
    public interface IPayrollRepository
    {
        Task<SalaryStructure?> GetSalaryStructureAsync(int staffId);
        Task<SalaryStructure> UpsertSalaryStructureAsync(SalaryStructure structure);
        Task<IEnumerable<PayrollRun>> GetPayrollRunsAsync();
        Task<PayrollRun?> GetPayrollRunDetailsAsync(int id);
        Task<PayrollRun> CreatePayrollRunAsync(PayrollRun run);
        Task<Payslip> CreatePayslipAsync(Payslip payslip);
        Task<IEnumerable<Payslip>> CreateBatchPayslipsAsync(IEnumerable<Payslip> payslips);
        Task<Payslip?> GetPayslipAsync(int id);
        Task<Payslip> UpdatePayslipAsync(Payslip payslip);
    }

    public interface IPayrollService
    {
        Task<SalaryStructure?> GetSalaryStructureAsync(int staffId);
        Task<SalaryStructure> UpsertSalaryStructureAsync(int staffId, SalaryStructure structure);
        Task<Payslip?> GeneratePayslipAsync(int staffId, int month, int year);
        Task<IEnumerable<Payslip>> GenerateBatchPayslipsAsync(int month, int year);
        Task<IEnumerable<PayrollRun>> GetPayrollRunsAsync();
        Task<PayrollRun?> GetPayrollRunDetailsAsync(int id);
        Task<PayrollRun> ProcessPayrollAsync(int year, int month, int processedByUserId);
        Task<Payslip?> MarkPayslipAsPaidAsync(int payslipId, string transactionId);
    }
}
