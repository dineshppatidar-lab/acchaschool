namespace SchoolManagementApp.ApplicationCore.Entities
{
    /// <summary>
    /// A tenant-scoped, DB-backed lookup value (designations, departments, qualifications, etc.).
    /// Replaces the hardcoded string arrays previously served by LookupService.
    /// </summary>
    public class LookupValue : BaseTenantEntity
    {
        /// <summary>Lookup category, e.g. "staff-positions", "staff-departments".</summary>
        public string LookupType { get; set; } = string.Empty;

        /// <summary>The display label, e.g. "Vice Principal".</summary>
        public string Label { get; set; } = string.Empty;

        /// <summary>Optional sort order for display.</summary>
        public int SortOrder { get; set; }

        /// <summary>Optional icon name (Material icon).</summary>
        public string? Icon { get; set; }
    }
}
