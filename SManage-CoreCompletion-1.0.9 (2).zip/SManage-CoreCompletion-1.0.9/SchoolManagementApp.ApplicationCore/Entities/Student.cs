
namespace SchoolManagementApp.ApplicationCore.Entities
{
    public class Student : BaseTenantEntity
    {
        public bool IsActive { get; set; } = true;
        public string Status { get; set; } = "Active";
        public string FirstName { get; set; } = string.Empty;
        public string LastName { get; set; } = string.Empty;
        public DateTime DateOfBirth { get; set; }
        public string Gender { get; set; } = string.Empty;
        public string Address { get; set; } = string.Empty;
        public string ContactNumber { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public DateTime AdmissionDate { get; set; }
        public int? AcademicYearId { get; set; }
        public int ClassId { get; set; }
        public int SectionId { get; set; }
        public int? ParentId { get; set; }
        public virtual Parent? Parent { get; set; }
        public int? BusRouteId { get; set; }
        public virtual BusRoute? BusRoute { get; set; }
        public string RollNumber { get; set; } = string.Empty;
        public string ScholarNumber { get; set; } = string.Empty;
        public string? PhotoPath { get; set; }
        public string? CasteCategory { get; set; }
        public string? Religion { get; set; }
        public string EnrollmentStatus { get; set; } = "Active";
        public virtual Class Class { get; set; } = null!;
        public virtual Section Section { get; set; } = null!;
        public virtual ICollection<Attendance> Attendances { get; set; } = new List<Attendance>();
        public virtual ICollection<Document> Documents { get; set; } = new List<Document>();
        public virtual ICollection<ExamResult> ExamResults { get; set; } = new List<ExamResult>();
        public virtual ICollection<Fee> Fees { get; set; } = new List<Fee>();
        public virtual ICollection<HostelAllocation> HostelAllocations { get; set; } = new List<HostelAllocation>();
        public virtual ICollection<HostelLeave> HostelLeaves { get; set; } = new List<HostelLeave>();
        public virtual ICollection<BusAttendance> BusAttendances { get; set; } = new List<BusAttendance>();
        public virtual ICollection<StudentFeeAdjustment> FeeAdjustments { get; set; } = new List<StudentFeeAdjustment>();
        public virtual ICollection<GroupPaymentAllocation> GroupPaymentAllocations { get; set; } = new List<GroupPaymentAllocation>();
        public virtual StudentAddressInfo? AddressInfo { get; set; }
        public virtual StudentAcademicHistory? AcademicHistory { get; set; }
        public virtual ICollection<StudentSecondaryParent> SecondaryParents { get; set; } = new List<StudentSecondaryParent>();
        public virtual StudentEmergencyContact? EmergencyContact { get; set; }
        public virtual StudentMedicalInfo? MedicalInfo { get; set; }
        public virtual StudentDocumentInfo? DocumentInfo { get; set; }
        public virtual StudentSpecialNeeds? SpecialNeeds { get; set; }
        public virtual StudentHostelInfo? HostelInfo { get; set; }
        public virtual StudentScholarshipInfo? ScholarshipInfo { get; set; }
        public virtual StudentBehavioralInfo? BehavioralInfo { get; set; }
        public virtual StudentSystemInfo? SystemInfo { get; set; }
    }
}
