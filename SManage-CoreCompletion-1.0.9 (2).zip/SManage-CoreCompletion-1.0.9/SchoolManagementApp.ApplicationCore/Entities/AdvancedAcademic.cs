
namespace SchoolManagementApp.ApplicationCore.Entities
{
    public class TimeTable : BaseTenantEntity
    {
        public int ClassId { get; set; }
        public int SectionId { get; set; }
        public int SubjectId { get; set; }
        public int StaffId { get; set; }
        public DayOfWeek DayOfWeek { get; set; }
        public TimeSpan StartTime { get; set; }
        public TimeSpan EndTime { get; set; }
        public string RoomNumber { get; set; } = string.Empty;
        public bool IsActive { get; set; } = true;
        [JsonIgnore] public virtual Class? Class { get; set; }
        [JsonIgnore] public virtual Section? Section { get; set; }
        [JsonIgnore] public virtual Subject? Subject { get; set; }
        [JsonIgnore] public virtual Staff? Staff { get; set; }
    }

    public class ExaminationType : BaseTenantEntity
    {
        public string Name { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public decimal WeightagePercentage { get; set; }
        public bool IsActive { get; set; } = true;
        [JsonIgnore] public virtual ICollection<Examination> Examinations { get; set; } = new List<Examination>();
    }

    public class Examination : BaseTenantEntity
    {
        public string Title { get; set; } = string.Empty;
        public int ExaminationTypeId { get; set; }
        public int AcademicYearId { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string Instructions { get; set; } = string.Empty;
        public bool IsPublished { get; set; }
        [JsonIgnore] public virtual ExaminationType? ExaminationType { get; set; }
        [JsonIgnore] public virtual AcademicYear? AcademicYear { get; set; }
        [JsonIgnore] public virtual ICollection<ExamSchedule> ExamSchedules { get; set; } = new List<ExamSchedule>();
        [JsonIgnore] public virtual ICollection<ExamResult> ExamResults { get; set; } = new List<ExamResult>();
    }

    public class ExamSchedule : BaseTenantEntity
    {
        public int ExaminationId { get; set; }
        public int SubjectId { get; set; }
        public int ClassId { get; set; }
        public DateTime ExamDate { get; set; }
        public TimeSpan StartTime { get; set; }
        public TimeSpan EndTime { get; set; }
        public string RoomNumber { get; set; } = string.Empty;
        public decimal MaxMarks { get; set; }
        public decimal PassingMarks { get; set; }
        public string Instructions { get; set; } = string.Empty;
        [JsonIgnore] public virtual Examination? Examination { get; set; }
        [JsonIgnore] public virtual Subject? Subject { get; set; }
        [JsonIgnore] public virtual Class? Class { get; set; }
    }

    public class AcademicYear : BaseTenantEntity
    {
        public string Name { get; set; } = string.Empty;
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public bool IsActive { get; set; } = true;
        public bool IsCurrent { get; set; }
        [JsonIgnore] public virtual ICollection<Class> Classes { get; set; } = new List<Class>();
        [JsonIgnore] public virtual ICollection<Examination> Examinations { get; set; } = new List<Examination>();
        [JsonIgnore] public virtual ICollection<StudentPromotion> StudentPromotions { get; set; } = new List<StudentPromotion>();
    }

    public class StudentPromotion : BaseTenantEntity
    {
        public int StudentId { get; set; }
        public int FromClassId { get; set; }
        public int ToClassId { get; set; }
        public int AcademicYearId { get; set; }
        public DateTime PromotionDate { get; set; }
        public string Status { get; set; } = string.Empty;
        public decimal TotalMarks { get; set; }
        public decimal Percentage { get; set; }
        public string Remarks { get; set; } = string.Empty;
        public virtual Student Student { get; set; } = null!;
        public virtual Class FromClass { get; set; } = null!;
        public virtual Class ToClass { get; set; } = null!;
        public virtual AcademicYear AcademicYear { get; set; } = null!;
    }

    public class GradingScheme : BaseTenantEntity
    {
        public string Grade { get; set; } = string.Empty;
        public decimal MinMarks { get; set; }
        public decimal MaxMarks { get; set; }
        public decimal GradePoint { get; set; }
        public string Description { get; set; } = string.Empty;
        public bool IsActive { get; set; } = true;
    }

    public class Assignment : BaseTenantEntity
    {
        public string Title { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public int SubjectId { get; set; }
        public int ClassId { get; set; }
        public int SectionId { get; set; }
        public int AssignedBy { get; set; }
        public DateTime AssignedDate { get; set; }
        public DateTime DueDate { get; set; }
        public decimal MaxMarks { get; set; }
        public string AttachmentPath { get; set; } = string.Empty;
        public bool IsActive { get; set; } = true;
        // Nullable navigations (matching TimeTable): clients never post them, and
        // non-nullable reference types make MVC's [ApiController] add implicit
        // [Required] rules that reject every create/update with "The Class field
        // is required." etc. FK nullability (ClassId int) is unaffected.
        public virtual Subject? Subject { get; set; }
        public virtual Class? Class { get; set; }
        public virtual Section? Section { get; set; }
        public virtual Staff? AssignedByStaff { get; set; }
        public virtual ICollection<AssignmentSubmission> Submissions { get; set; } = new List<AssignmentSubmission>();
    }

    public class AssignmentSubmission : BaseTenantEntity
    {
        public int AssignmentId { get; set; }
        public int StudentId { get; set; }
        public DateTime SubmittedDate { get; set; }
        public string SubmissionPath { get; set; } = string.Empty;
        public string Content { get; set; } = string.Empty;
        public decimal? MarksObtained { get; set; }
        public string FeedBack { get; set; } = string.Empty;
        public DateTime? GradedDate { get; set; }
        public int? GradedBy { get; set; }
        public string Status { get; set; } = "Submitted";
        public virtual Assignment Assignment { get; set; } = null!;
        public virtual Student Student { get; set; } = null!;
        public virtual Staff? GradedByStaff { get; set; }
    }
}
