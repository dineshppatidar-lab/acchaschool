using SchoolManagementApp.ApplicationCore._Entities;

namespace SchoolManagementApp.ApplicationCore.Entities
{
    /// <summary>
    /// A pre-admission enquiry captured from the Student Enquiry page.
    /// Purely informational — has NO relation to the admission flow or the
    /// Students table. Only StudentName and ContactNo are mandatory; every
    /// other field is optional.
    /// </summary>
    [System.ComponentModel.DataAnnotations.Schema.Table("StudentEnquiries")]
    public class StudentEnquiry : BaseTenantEntity
    {
        // ── Mandatory ──
        public string StudentName { get; set; } = string.Empty;
        public string ContactNo { get; set; } = string.Empty;

        // ── Optional ──
        public string? Email { get; set; }
        public string? ClassInterestedIn { get; set; }
        public string? Source { get; set; }          // Walk-in, Phone, Website, Reference…
        public string? Notes { get; set; }
        public DateTime? EnquiryDate { get; set; }   // defaults to today on the UI/API side

        // ── Follow-up tracking (informational) ──
        public string? Status { get; set; }          // New, Contacted, Converted, Closed
    }
}
