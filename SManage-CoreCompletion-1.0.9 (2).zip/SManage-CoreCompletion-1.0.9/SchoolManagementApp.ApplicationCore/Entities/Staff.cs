
namespace SchoolManagementApp.ApplicationCore.Entities
{
    public class Staff : BaseTenantEntity
    {
        public string FirstName { get; set; } = string.Empty;
        public string LastName { get; set; } = string.Empty;
        public DateTime DateOfBirth { get; set; }
        public string Gender { get; set; } = string.Empty;
        public string Address { get; set; } = string.Empty;
        public string City { get; set; } = string.Empty;
        public string State { get; set; } = string.Empty;
        public string ZipCode { get; set; } = string.Empty;
        public string PhoneNumber { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public DateTime HireDate { get; set; }
        public string Position { get; set; } = string.Empty;
        public decimal Salary { get; set; }
        public string Role { get; set; } = string.Empty;
        public string Qualification { get; set; } = string.Empty;
        public string Specialization { get; set; } = string.Empty;

        [JsonIgnore]
        public virtual ICollection<Attendance> Attendances { get; set; } = new List<Attendance>();
        [JsonIgnore]
        public virtual ICollection<Subject> SubjectsTeaching { get; set; } = new List<Subject>();
        [JsonIgnore]
        public virtual ICollection<Class> ClassesHandling { get; set; } = new List<Class>();
    }
}
