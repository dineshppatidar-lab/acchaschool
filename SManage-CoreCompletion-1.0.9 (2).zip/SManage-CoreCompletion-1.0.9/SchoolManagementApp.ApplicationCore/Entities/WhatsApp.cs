using SchoolManagementApp.ApplicationCore._Entities;

namespace SchoolManagementApp.ApplicationCore.Entities
{
    // ── Enums ────────────────────────────────────────────────────────────

    /// <summary>Supported WhatsApp providers. The abstraction keeps business logic provider-agnostic.</summary>
    public enum WhatsAppProviderType
    {
        MetaCloudApi = 0,

        /// <summary>Arattai Business Platform (Zoho-style OAuth 2.0, template-only business-initiated messaging).</summary>
        Arattai = 1
    }

    /// <summary>Full message status lifecycle.</summary>
    public enum WhatsAppMessageStatus
    {
        Pending = 0,
        Queued = 1,
        Sending = 2,
        Sent = 3,
        Delivered = 4,
        Read = 5,
        Failed = 6,
        Cancelled = 7
    }

    /// <summary>What triggered the message.</summary>
    public enum WhatsAppTriggerType
    {
        Manual = 0,
        Automated = 1
    }

    /// <summary>Notification categories — new notification types plug in here without new WhatsApp plumbing.</summary>
    public enum WhatsAppMessageType
    {
        FeeReminder = 0,
        AttendanceAlert = 1,
        ExamResult = 2,
        Announcement = 3,
        TransportNotification = 4,
        General = 5,
        /// <summary>Payment receipt/confirmation sent when a fee installment payment completes (event-driven, not scheduled).</summary>
        PaymentReceived = 6
    }

    /// <summary>When an automated reminder fires relative to the installment due date.</summary>
    public enum WhatsAppReminderOffsetType
    {
        BeforeDueDate = 0,
        OnDueDate = 1,
        AfterDueDate = 2
    }

    /// <summary>Queue item lifecycle (processing state; delivery state lives on the log).</summary>
    public enum WhatsAppQueueStatus
    {
        Queued = 0,
        Processing = 1,
        Completed = 2,
        Failed = 3,
        Cancelled = 4
    }

    // ── Entities ─────────────────────────────────────────────────────────

    /// <summary>
    /// Per-tenant WhatsApp provider configuration. Sensitive values (access token,
    /// webhook secrets) are stored encrypted via ISecretProtector and are never
    /// returned to clients — only a masked hint is exposed.
    /// </summary>
    public class WhatsAppConfiguration : BaseTenantEntity
    {
        public bool IsEnabled { get; set; }
        public WhatsAppProviderType Provider { get; set; } = WhatsAppProviderType.MetaCloudApi;

        // Connection
        public string ApiBaseUrl { get; set; } = "https://graph.facebook.com";
        public string ApiVersion { get; set; } = "v21.0";
        public string? BusinessAccountId { get; set; }
        public string? PhoneNumberId { get; set; }
        public string? AccessTokenEncrypted { get; set; }
        /// <summary>Masked, non-sensitive hint for the UI (e.g. "EAAG••••4f2a"). Never contains the secret.</summary>
        public string? AccessTokenMask { get; set; }
        public string? SenderNumber { get; set; }

        // Webhooks
        public string? WebhookVerifyTokenEncrypted { get; set; }
        public string? WebhookSecretEncrypted { get; set; }

        // Arattai (Business Platform) configuration — only used when Provider == Arattai.
        // OAuth: the Client ID/Secret alone cannot send messages; a one-time browser
        // consent (authorization-code grant, offline access) produces the refresh token
        // stored here. Access tokens are short-lived (1h) and refreshed automatically.
        public string? ArattaiOauthRedirectUri { get; set; }
        public string? ArattaiCompanyId { get; set; }
        public string? ArattaiBusinessNumberId { get; set; }
        /// <summary>OAuth refresh token (encrypted). Required to send via Arattai.</summary>
        public string? ArattaiRefreshTokenEncrypted { get; set; }
        /// <summary>Masked hint for the UI. Never contains the token.</summary>
        public string? ArattaiRefreshTokenMask { get; set; }
        /// <summary>Decrypted-at-runtime access token cache (never persisted, never returned to clients).</summary>
        [System.Text.Json.Serialization.JsonIgnore]
        [System.ComponentModel.DataAnnotations.Schema.NotMapped]
        public string? ArattaiAccessToken { get; set; }
        [System.Text.Json.Serialization.JsonIgnore]
        [System.ComponentModel.DataAnnotations.Schema.NotMapped]
        public DateTime? ArattaiAccessTokenExpiresOn { get; set; }

        // Messaging defaults
        public string DefaultLanguageCode { get; set; } = "en";
        public string DefaultCountryCode { get; set; } = "91";

        // Resilience
        public int RequestTimeoutSeconds { get; set; } = 30;
        public int MaxRetryAttempts { get; set; } = 3;
        public int RetryDelayMinutes { get; set; } = 5;
        public int RateLimitPerMinute { get; set; } = 30;

        // Operations
        public bool EnableLogging { get; set; } = true;
        public bool TestMode { get; set; }
        public string? PaymentLinkBaseUrl { get; set; }

        // Tenant-level sender identity used in templates (falls back to Tenant.Name)
        public string? SchoolNameOverride { get; set; }
        public string? SchoolPhone { get; set; }
        public string? SchoolEmail { get; set; }

        // Last test-connection outcome
        public DateTime? LastTestedOn { get; set; }
        public string? LastTestStatus { get; set; }
        public string? LastTestMessage { get; set; }
    }

    /// <summary>
    /// Reusable message template with dynamic placeholders. For WhatsApp Business
    /// Platform, ProviderTemplateName maps to the Meta-approved template name.
    /// </summary>
    public class WhatsAppMessageTemplate : BaseTenantEntity
    {
        public string Name { get; set; } = string.Empty;
        public WhatsAppMessageType MessageType { get; set; } = WhatsAppMessageType.FeeReminder;
        public string LanguageCode { get; set; } = "en";
        /// <summary>Provider-side (Meta) approved template name, when the provider requires approved templates.</summary>
        public string? ProviderTemplateName { get; set; }
        /// <summary>
        /// Arattai: template ID as created in the Arattai Business Platform
        /// (Arattai sends by ID, not name). Null for Meta sends.
        /// </summary>
        public string? ProviderTemplateId { get; set; }
        /// <summary>Body with {{Placeholder}} tokens.</summary>
        public string BodyText { get; set; } = string.Empty;
        /// <summary>Administrator marks this once the template is approved on the provider side.</summary>
        public bool IsApproved { get; set; }
        public bool IsActive { get; set; } = true;
        public string? Description { get; set; }
    }

    /// <summary>
    /// Configurable automated reminder rule (e.g. "7 days before due date").
    /// Evaluated daily by the background scheduler per tenant.
    /// </summary>
    public class WhatsAppReminderRule : BaseTenantEntity
    {
        public string Name { get; set; } = string.Empty;
        public int TemplateId { get; set; }
        public bool IsEnabled { get; set; } = true;

        public WhatsAppReminderOffsetType OffsetType { get; set; } = WhatsAppReminderOffsetType.BeforeDueDate;
        public int OffsetDays { get; set; }

        /// <summary>Local time-of-day the rule prefers to run (scheduler hint).</summary>
        public TimeSpan SendTime { get; set; } = new TimeSpan(9, 0, 0);

        // Optional targeting filters (null = all)
        public int? TargetAcademicYearId { get; set; }
        public int? TargetClassId { get; set; }
        public int? TargetSectionId { get; set; }
        public decimal MinOutstandingAmount { get; set; }

        public DateTime? LastRunOn { get; set; }

        public virtual WhatsAppMessageTemplate? Template { get; set; }
    }

    /// <summary>
    /// Audit/history record for every WhatsApp message attempted (manual or automated).
    /// Doubles as the duplicate-prevention ledger for automated reminders via the
    /// unique filtered index on (TenantId, StudentId, FeeInstallmentId, ReminderRuleId, ReminderDate).
    /// </summary>
    public class WhatsAppMessageLog : BaseTenantEntity
    {
        public int StudentId { get; set; }
        /// <summary>Denormalized so history survives student edits/deletes.</summary>
        public string StudentName { get; set; } = string.Empty;

        public int? ParentId { get; set; }
        public string RecipientName { get; set; } = string.Empty;
        /// <summary>Normalized E.164-ish number without the leading '+' (Meta format).</summary>
        public string RecipientNumber { get; set; } = string.Empty;

        public WhatsAppMessageType MessageType { get; set; } = WhatsAppMessageType.FeeReminder;
        public int? TemplateId { get; set; }
        public string? TemplateName { get; set; }
        public string? LanguageCode { get; set; }

        public WhatsAppTriggerType TriggerType { get; set; } = WhatsAppTriggerType.Manual;
        /// <summary>Provider actually used for this send (Meta or Arattai) — resolved from the tenant config at queue-processing time.</summary>
        public WhatsAppProviderType Provider { get; set; } = WhatsAppProviderType.MetaCloudApi;

        // Payment-receipt context (null for reminder/alert message types).
        /// <summary>The completed FeePayment this receipt acknowledges (PaymentReceived sends only).</summary>
        public int? FeePaymentId { get; set; }
        /// <summary>Amount paid in that payment (denormalized for rendering/history when the payment row is later edited or refunded).</summary>
        public decimal? PaidAmount { get; set; }

        // Fee context (null for non-fee message types)
        public int? FeeInstallmentId { get; set; }
        public int? FeeStructureId { get; set; }
        public string? InstallmentName { get; set; }
        public DateTime? DueDate { get; set; }
        public decimal? OutstandingAmount { get; set; }
        public int? ReminderRuleId { get; set; }
        /// <summary>The target reminder date (due date ± offset) used for duplicate prevention.</summary>
        public DateTime? ReminderDate { get; set; }

        public WhatsAppMessageStatus Status { get; set; } = WhatsAppMessageStatus.Pending;
        public string? FailureReason { get; set; }
        public string? ProviderMessageId { get; set; }
        public int RetryCount { get; set; }
        public DateTime? SentAt { get; set; }
        public DateTime? DeliveredAt { get; set; }
        public DateTime? ReadAt { get; set; }
        /// <summary>Rendered body (subject to EnableLogging — cleared when logging disabled).</summary>
        public string? RenderedMessage { get; set; }
        public bool IsTestMode { get; set; }
    }

    /// <summary>
    /// Durable send queue. The scheduler enqueues automated reminders here; the
    /// background processor drains it with rate limiting, retries and duplicate checks.
    /// Manual bulk sends are enqueued as well so both flows share one pipeline.
    /// </summary>
    public class WhatsAppMessageQueue : BaseTenantEntity
    {
        public int MessageLogId { get; set; }
        public virtual WhatsAppMessageLog MessageLog { get; set; } = null!;

        public WhatsAppQueueStatus Status { get; set; } = WhatsAppQueueStatus.Queued;
        public DateTime ScheduledFor { get; set; } = DateTime.UtcNow;
        public int AttemptCount { get; set; }
        public DateTime NextAttemptAt { get; set; } = DateTime.UtcNow;
        public string? LastError { get; set; }
        public DateTime? ProcessedAt { get; set; }
    }
}
