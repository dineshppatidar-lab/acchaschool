
namespace SchoolManagementApp.ApplicationCore.Entities
{
    [System.ComponentModel.DataAnnotations.Schema.Table("MenuItems")]
    public class MenuItem : BaseTenantEntity
    {
        public string Label { get; set; } = string.Empty;
        public string Icon { get; set; } = string.Empty;
        public string Route { get; set; } = string.Empty;
        public string RequiredPermission { get; set; } = string.Empty;
        public int? ParentId { get; set; }
        public int DisplayOrder { get; set; }
        public bool IsActive { get; set; } = true;
        public string Category { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public string Badge { get; set; } = string.Empty;
        public string ExternalUrl { get; set; } = string.Empty;
        public bool OpenInNewTab { get; set; } = false;
        public virtual ICollection<MenuItem> Children { get; set; } = new List<MenuItem>();
        public virtual MenuItem Parent { get; set; } = null!;
    }

    public class RoleMenuPermission : BaseTenantEntity
    {
        public Common.Enums.UserRole Role { get; set; }
        public int MenuItemId { get; set; }
        public bool CanView { get; set; } = true;
        public virtual MenuItem MenuItem { get; set; } = null!;
    }

    public class MenuItemDto
    {
        public int Id { get; set; }
        public string Label { get; set; } = string.Empty;
        public string Icon { get; set; } = string.Empty;
        public string Route { get; set; } = string.Empty;
        public string RequiredPermission { get; set; } = string.Empty;
        public int DisplayOrder { get; set; }
        public string Category { get; set; } = string.Empty;
        public string Badge { get; set; } = string.Empty;
        public string ExternalUrl { get; set; } = string.Empty;
        public bool OpenInNewTab { get; set; }
        public List<MenuItemDto> Children { get; set; } = new List<MenuItemDto>();
        public bool HasPermission { get; set; } = true;
    }
}
