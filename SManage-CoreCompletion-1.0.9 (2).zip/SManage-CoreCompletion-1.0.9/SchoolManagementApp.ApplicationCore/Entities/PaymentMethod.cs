namespace SchoolManagementApp.ApplicationCore.Entities
{
    public class PaymentMethod : BaseTenantEntity
    {
        public string Name { get; set; } = string.Empty;
        public bool IsActive { get; set; } = true;
        public string? Configuration { get; set; }
    }
}
