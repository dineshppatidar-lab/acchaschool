
namespace SchoolManagementApp.ApplicationCore.Entities
{
    public class Class : BaseTenantEntity
    {
        public string Name { get; set; } = string.Empty;
        public string Code { get; set; } = string.Empty;
        public int AcademicYearId { get; set; }
        public int Capacity { get; set; }

        public virtual AcademicYear AcademicYear { get; set; } = null!;
        public virtual ICollection<Section> Sections { get; set; } = new List<Section>();
        public virtual ICollection<Subject> Subjects { get; set; } = new List<Subject>();
        public virtual ICollection<Student> Students { get; set; } = new List<Student>();
        public virtual ICollection<Staff> Teachers { get; set; } = new List<Staff>();
    }

    public class Section : BaseTenantEntity
    {
        public string Name { get; set; } = string.Empty;
        public int ClassId { get; set; }
        public virtual Class Class { get; set; } = null!;
        public virtual ICollection<Student> Students { get; set; } = new List<Student>();
    }

    public class Subject : BaseTenantEntity
    {
        public string Name { get; set; } = string.Empty;
        public string Code { get; set; } = string.Empty;
        public int ClassId { get; set; }
        public int CreditHours { get; set; }
        public virtual Class Class { get; set; } = null!;
        public virtual ICollection<Staff> Teachers { get; set; } = new List<Staff>();
        public virtual ICollection<ExamResult> ExamResults { get; set; } = new List<ExamResult>();
    }
}
