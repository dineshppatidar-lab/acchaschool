using SchoolManagementApp.ApplicationCore._Entities;

namespace SchoolManagementApp.ApplicationCore.Entities
{
    // ── Website CMS enums ────────────────────────────────────────────────────
    public enum WebsiteCampaignStatus { Draft = 0, Scheduled = 1, Published = 2, Expired = 3, Unpublished = 4 }
    public enum WebsiteCampaignPosition { Homepage = 0, Admissions = 1, Events = 2, Contact = 3, Sidebar = 4 }
    public enum WebsiteEnquiryStatus { New = 0, Contacted = 1, Converted = 2, Closed = 3 }

    /// <summary>
    /// Per-tenant public website settings (branding, contact, SEO, homepage sections,
    /// publication status). One row per tenant. Bounded content blocks (About/Admissions…)
    /// are stored as sanitized HTML strings; section list/order lives in HomepageSectionsJson.
    /// </summary>
    [System.ComponentModel.DataAnnotations.Schema.Table("SchoolWebsiteSettings")]
    public class SchoolWebsiteSettings : BaseTenantEntity
    {
        public string? Tagline { get; set; }
        public string? FaviconUrl { get; set; }
        public string? PrimaryColor { get; set; }
        public string? SecondaryColor { get; set; }
        public string? WebsiteTitle { get; set; }
        public string? MetaDescription { get; set; }
        public string? SocialShareImageUrl { get; set; }

        public string? Address { get; set; }
        public string? ContactPhone { get; set; }
        public string? ContactEmail { get; set; }
        public string? MapEmbedUrl { get; set; }

        public string? AboutHtml { get; set; }
        public string? VisionMissionHtml { get; set; }
        public string? AcademicsHtml { get; set; }
        public string? FacilitiesHtml { get; set; }
        public string? AdmissionsHtml { get; set; }

        public string? PrincipalName { get; set; }
        public string? PrincipalTitle { get; set; }
        public string? PrincipalPhotoUrl { get; set; }
        public string? PrincipalMessageHtml { get; set; }

        public string? SocialLinksJson { get; set; }

        /// <summary>JSON: [{ "key":"hero", "enabled":true, "order":0 }, …] — homepage section toggles/order.</summary>
        public string? HomepageSectionsJson { get; set; }

        /// <summary>Public website publication switch (unpublished website shows a holding page).</summary>
        public bool IsPublished { get; set; } = true;

        /// <summary>Whether the public admission enquiry form is enabled.</summary>
        public bool EnquiriesEnabled { get; set; } = true;
    }

    /// <summary>
    /// Tenant-owned uploaded media (images/documents). Unlike the legacy
    /// IFileStorageService metadata (which is stubbed), this is persisted:
    /// uploaded files land under wwwroot/uploads/… with unguessable GUID file names,
    /// and this row records captions/alt text and acts as the CMS media library.
    /// </summary>
    [System.ComponentModel.DataAnnotations.Schema.Table("SchoolMediaAssets")]
    public class SchoolMediaAsset : BaseTenantEntity
    {
        /// <summary>Static path segment exposed under the app root, e.g. "uploads/website/2026/..."</summary>
        public string FilePath { get; set; } = string.Empty;
        public string? ThumbnailFilePath { get; set; }
        public string OriginalFileName { get; set; } = string.Empty;
        public string ContentType { get; set; } = string.Empty;
        public long SizeBytes { get; set; }
        public string Category { get; set; } = "website";
        public string? Caption { get; set; }
        public string? AltText { get; set; }
        public bool IsActive { get; set; } = true;
    }

    [System.ComponentModel.DataAnnotations.Schema.Table("SchoolWebsiteEvents")]
    public class SchoolWebsiteEvent : BaseTenantEntity
    {
        public string Title { get; set; } = string.Empty;
        public string Slug { get; set; } = string.Empty;
        public string? Excerpt { get; set; }
        public string? DescriptionHtml { get; set; }
        public DateTime EventDate { get; set; }
        public DateTime? EndDate { get; set; }
        public string? Location { get; set; }
        public string? CoverImageUrl { get; set; }

        /// <summary>Optional photo album shown on the public event page.</summary>
        public int? GalleryAlbumId { get; set; }

        public bool IsPublished { get; set; }
        public int DisplayOrder { get; set; }
        public DateTime? PublishedOn { get; set; }
    }

    [System.ComponentModel.DataAnnotations.Schema.Table("SchoolGalleryAlbums")]
    public class SchoolGalleryAlbum : BaseTenantEntity
    {
        public string Title { get; set; } = string.Empty;
        public string Slug { get; set; } = string.Empty;
        public string? DescriptionHtml { get; set; }

        /// <summary>Free-text event category (Annual Function, Sports Day, …) set by the school.</summary>
        public string Category { get; set; } = string.Empty;
        public DateTime? EventDate { get; set; }
        public string? CoverImageUrl { get; set; }

        /// <summary>
        /// Administrator's confirmation that student photography has the required
        /// parental/institutional authorization. Publishing is blocked without it.
        /// </summary>
        public bool StudentPhotoConsentConfirmed { get; set; }

        public bool IsPublished { get; set; }
        public bool IsFeatured { get; set; }
        public int DisplayOrder { get; set; }
        public DateTime? PublishedOn { get; set; }
    }

    [System.ComponentModel.DataAnnotations.Schema.Table("SchoolGalleryMedia")]
    public class SchoolGalleryMedia : BaseTenantEntity
    {
        public int AlbumId { get; set; }
        public int? MediaAssetId { get; set; }
        public string FilePath { get; set; } = string.Empty;
        public string? ThumbnailPath { get; set; }
        public string? Caption { get; set; }
        public string? AltText { get; set; }
        public string? VideoUrl { get; set; }
        public int DisplayOrder { get; set; }
    }

    [System.ComponentModel.DataAnnotations.Schema.Table("SchoolWebsiteAchievements")]
    public class SchoolWebsiteAchievement : BaseTenantEntity
    {
        public string Title { get; set; } = string.Empty;
        public string? DescriptionHtml { get; set; }

        /// <summary>Free-text category (Academic, Sports, Competition, Teacher, Institutional, …).</summary>
        public string Category { get; set; } = string.Empty;
        public DateTime? AchievementDate { get; set; }
        public string? ImageUrl { get; set; }
        public string? DocumentUrlsJson { get; set; }

        /// <summary>Administrator-entered, verified performance figure cards (JSON: [{label,value,subtitle},…]).</summary>
        public string? StatsJson { get; set; }

        /// <summary>True only when the school marks the figures as actual/verified — never fabricated.</summary>
        public bool IsVerified { get; set; }

        public bool IsPublished { get; set; }
        public bool ShowOnHomepage { get; set; }
        public int DisplayOrder { get; set; }
    }

    [System.ComponentModel.DataAnnotations.Schema.Table("SchoolWebsiteArticles")]
    public class SchoolWebsiteArticle : BaseTenantEntity
    {
        public string Title { get; set; } = string.Empty;
        public string Slug { get; set; } = string.Empty;
        public string? Excerpt { get; set; }
        public string BodyHtml { get; set; } = string.Empty;
        public string? CoverImageUrl { get; set; }
        public string? Category { get; set; }
        public string? TagsCsv { get; set; }

        public bool IsPublished { get; set; }
        public bool IsFeatured { get; set; }

        /// <summary>When set, content becomes public ONLY at/after this instant (scheduled publishing).</summary>
        public DateTime? ScheduledForUtc { get; set; }
        public DateTime? PublishedOnUtc { get; set; }

        public string? SeoTitle { get; set; }
        public string? SeoDescription { get; set; }
    }

    /// <summary>School-managed promotional banner (NOT an external ad network).</summary>
    [System.ComponentModel.DataAnnotations.Schema.Table("SchoolPromoCampaigns")]
    public class SchoolPromoCampaign : BaseTenantEntity
    {
        public string Title { get; set; } = string.Empty;
        public string? Description { get; set; }
        public string? BannerImagePath { get; set; }
        public string? MobileBannerImagePath { get; set; }
        public string? CtaText { get; set; }
        public string? CtaUrl { get; set; }

        public WebsiteCampaignPosition DisplayPosition { get; set; } = WebsiteCampaignPosition.Homepage;

        /// <summary>Display window (UTC). Outside the window the campaign is simply not shown.</summary>
        public DateTime StartUtc { get; set; }
        public DateTime? EndUtc { get; set; }

        /// <summary>Higher priority wins when several campaigns share a position.</summary>
        public int Priority { get; set; }

        public WebsiteCampaignStatus Status { get; set; } = WebsiteCampaignStatus.Draft;
    }

    /// <summary>Admission enquiry submitted from the school's public website (tenant-scoped).</summary>
    [System.ComponentModel.DataAnnotations.Schema.Table("SchoolWebsiteEnquiries")]
    public class SchoolWebsiteEnquiry : BaseTenantEntity
    {
        public string ParentName { get; set; } = string.Empty;
        public string Phone { get; set; } = string.Empty;
        public string? Email { get; set; }
        public string? Message { get; set; }
        public string? ClassOfInterest { get; set; }
        public string? SourcePath { get; set; }

        public WebsiteEnquiryStatus Status { get; set; } = WebsiteEnquiryStatus.New;

        /// <summary>When converted, points at the existing StudentEnquiry produced.</summary>
        public int? ConvertedStudentEnquiryId { get; set; }
        public DateTime? ConvertedOnUtc { get; set; }
        public string? Notes { get; set; }
        public string? StaffNote { get; set; }
    }
}
