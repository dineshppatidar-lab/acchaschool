
namespace SchoolManagementApp.ApplicationCore.Entities
{
    public class Hostel : BaseTenantEntity
    {
        public string Name { get; set; } = string.Empty;
        public string Type { get; set; } = string.Empty;
        public string Address { get; set; } = string.Empty;
        public int Capacity { get; set; }
        public virtual ICollection<HostelRoom> Rooms { get; set; } = new List<HostelRoom>();
        public virtual ICollection<Staff> Wardens { get; set; } = new List<Staff>();
    }

    public class HostelRoom : BaseTenantEntity
    {
        public int HostelId { get; set; }
        public string RoomNumber { get; set; } = string.Empty;
        public int Capacity { get; set; }
        public int Occupied { get; set; }
        public bool IsOccupied => Occupied >= Capacity;
        public bool IsActive { get; set; } = true;
        public string RoomType { get; set; } = string.Empty;
        public string Status { get; set; } = string.Empty;
        public decimal MonthlyFee { get; set; }
        public virtual Hostel Hostel { get; set; } = null!;
        public virtual ICollection<HostelAllocation> Allocations { get; set; } = new List<HostelAllocation>();
    }

    public class HostelAllocation : BaseTenantEntity
    {
        public int HostelId { get; set; }
        public int StudentId { get; set; }
        public int RoomId { get; set; }
        public bool IsActive { get; set; } = true;
        public DateTime AllocationDate { get; set; }
        public DateTime? ReleaseDate { get; set; }
        public string BedNumber { get; set; } = string.Empty;
        public string MealPlan { get; set; } = string.Empty;
        public virtual Student Student { get; set; } = null!;
        public virtual HostelRoom Room { get; set; } = null!;
    }

    public class HostelLeave : BaseTenantEntity
    {
        public int StudentId { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string Reason { get; set; } = string.Empty;
        public string Status { get; set; } = string.Empty;
        public int? ApprovedById { get; set; }
        public virtual Student Student { get; set; } = null!;
        public virtual Staff ApprovedBy { get; set; } = null!;
    }
}
