
namespace SchoolManagementApp.ApplicationCore.Entities
{
    public class Message : BaseTenantEntity
    {
        public string Subject { get; set; } = string.Empty;
        public string Content { get; set; } = string.Empty;
        public int SenderId { get; set; }
        public string SenderType { get; set; } = string.Empty;
        public DateTime SentDate { get; set; }
        public MessagePriority Priority { get; set; } = MessagePriority.Normal;
        public MessageType Type { get; set; } = MessageType.General;
        public bool IsRead { get; set; }
        public string AttachmentPath { get; set; } = string.Empty;
        public virtual ICollection<MessageRecipient> Recipients { get; set; } = new List<MessageRecipient>();
        public virtual ICollection<MessageReply> Replies { get; set; } = new List<MessageReply>();
    }

    public class MessageRecipient : BaseTenantEntity
    {
        public int MessageId { get; set; }
        public int RecipientId { get; set; }
        public string RecipientType { get; set; } = string.Empty;
        public bool IsRead { get; set; }
        public DateTime? ReadDate { get; set; }
        public virtual Message Message { get; set; } = null!;
    }

    public class MessageReply : BaseTenantEntity
    {
        public int OriginalMessageId { get; set; }
        public string Content { get; set; } = string.Empty;
        public int SenderId { get; set; }
        public string SenderType { get; set; } = string.Empty;
        public DateTime SentDate { get; set; }
        public string AttachmentPath { get; set; } = string.Empty;
        public virtual Message OriginalMessage { get; set; } = null!;
    }

    public class Announcement : BaseTenantEntity
    {
        public string Title { get; set; } = string.Empty;
        public string Content { get; set; } = string.Empty;
        public AnnouncementType Type { get; set; }
        public AnnouncementPriority Priority { get; set; } = AnnouncementPriority.Normal;
        public DateTime? ValidFrom { get; set; }
        public DateTime? ValidTo { get; set; }
        public bool IsActive { get; set; } = true;
        public string TargetAudience { get; set; } = string.Empty;
        public string AttachmentPath { get; set; } = string.Empty;
        public virtual ICollection<AnnouncementTarget> Targets { get; set; } = new List<AnnouncementTarget>();
    }

    public class AnnouncementTarget : BaseTenantEntity
    {
        public int AnnouncementId { get; set; }
        public string TargetType { get; set; } = string.Empty;
        public int? TargetId { get; set; }
        public bool IsRead { get; set; }
        public DateTime? ReadDate { get; set; }
        public virtual Announcement Announcement { get; set; } = null!;
    }

    public class Event : BaseTenantEntity
    {
        public string Title { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public EventType Type { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string Location { get; set; } = string.Empty;
        public int OrganizedBy { get; set; }
        public bool IsAllDay { get; set; }
        public bool IsPublic { get; set; } = true;
        public string Color { get; set; } = "#1976d2";
        public EventStatus Status { get; set; } = EventStatus.Scheduled;
        public int? MaxParticipants { get; set; }
        public virtual ICollection<EventParticipant> Participants { get; set; } = new List<EventParticipant>();
        public virtual ICollection<EventReminder> Reminders { get; set; } = new List<EventReminder>();
    }

    public class EventParticipant : BaseTenantEntity
    {
        public int EventId { get; set; }
        public int ParticipantId { get; set; }
        public string ParticipantType { get; set; } = string.Empty;
        public ParticipantStatus Status { get; set; } = ParticipantStatus.Invited;
        public DateTime? ResponseDate { get; set; }
        public string Notes { get; set; } = string.Empty;
        public virtual Event Event { get; set; } = null!;
    }

    public class EventReminder : BaseTenantEntity
    {
        public int EventId { get; set; }
        public int ReminderMinutes { get; set; }
        public ReminderType Type { get; set; }
        public bool IsSent { get; set; }
        public DateTime? SentDate { get; set; }
        public virtual Event Event { get; set; } = null!;
    }

    public class ParentTeacherMeeting : BaseTenantEntity
    {
        public int ParentId { get; set; }
        public int StaffId { get; set; }
        public int StudentId { get; set; }
        public DateTime ScheduledDate { get; set; }
        public TimeSpan StartTime { get; set; }
        public TimeSpan EndTime { get; set; }
        public string Purpose { get; set; } = string.Empty;
        public MeetingStatus Status { get; set; } = MeetingStatus.Scheduled;
        public string Notes { get; set; } = string.Empty;
        public string Location { get; set; } = string.Empty;
        public virtual Parent Parent { get; set; } = null!;
        public virtual Staff Staff { get; set; } = null!;
        public virtual Student Student { get; set; } = null!;
    }

    public enum MessagePriority { Low = 1, Normal = 2, High = 3, Urgent = 4 }
    public enum MessageType { General = 1, Academic = 2, Administrative = 3, Emergency = 4, Disciplinary = 5 }
    public enum AnnouncementType { General = 1, Academic = 2, Event = 3, Holiday = 4, Emergency = 5, Exam = 6, Fee = 7 }
    public enum AnnouncementPriority { Low = 1, Normal = 2, High = 3, Critical = 4 }
    public enum EventType { Academic = 1, Sports = 2, Cultural = 3, Meeting = 4, Exam = 5, Holiday = 6, Training = 7, Other = 8 }
    public enum EventStatus { Scheduled = 1, InProgress = 2, Completed = 3, Cancelled = 4, Postponed = 5 }
    public enum ParticipantStatus { Invited = 1, Accepted = 2, Declined = 3, Maybe = 4, Attended = 5, NoShow = 6 }
    public enum ReminderType { Email = 1, SMS = 2, Push = 3, InApp = 4 }
    public enum MeetingStatus { Scheduled = 1, Confirmed = 2, Completed = 3, Cancelled = 4, Rescheduled = 5 }
}
