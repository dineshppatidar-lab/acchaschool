
namespace SchoolManagementApp.ApplicationCore.Entities
{
    public class SalaryStructure : BaseTenantEntity
    {
        public int StaffId { get; set; }
        public decimal BasicSalary { get; set; }
        public DateTime EffectiveDate { get; set; }
        public bool IsActive { get; set; } = true;
        public virtual Staff Staff { get; set; } = null!;
        public virtual ICollection<SalaryComponent> Components { get; set; } = new List<SalaryComponent>();
    }

    public class SalaryComponent : BaseTenantEntity
    {
        public int SalaryStructureId { get; set; }
        public string Name { get; set; } = string.Empty;
        public Common.Enums.ComponentType Type { get; set; }
        public decimal Amount { get; set; }
        public bool IsPercentage { get; set; }
        public virtual SalaryStructure SalaryStructure { get; set; } = null!;
    }

    public class PayrollRun : BaseTenantEntity
    {
        public int Month { get; set; }
        public int Year { get; set; }
        public DateTime ProcessedDate { get; set; }
        public int ProcessedBy { get; set; }
        public string Status { get; set; } = string.Empty;
        public decimal TotalAmount { get; set; }
        public DateTime? PayDate { get; set; }
        public virtual ICollection<Payslip> Payslips { get; set; } = new List<Payslip>();
    }

    public class Payslip : BaseTenantEntity
    {
        public int PayrollRunId { get; set; }
        public int StaffId { get; set; }
        public int Month { get; set; }
        public int Year { get; set; }
        public decimal BasicSalary { get; set; }
        public decimal TotalAllowances { get; set; }
        public decimal TotalDeductions { get; set; }
        public decimal LwpDeduction { get; set; }
        public decimal NetPay { get; set; }
        public Common.Enums.PayslipStatus Status { get; set; }
        public DateTime? PaymentDate { get; set; }
        public string? PaymentMethod { get; set; }
        public string? TransactionId { get; set; }
        public virtual PayrollRun PayrollRun { get; set; } = null!;
        public virtual Staff Staff { get; set; } = null!;
    }
}
