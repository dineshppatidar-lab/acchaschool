
namespace SchoolManagementApp.ApplicationCore.Entities
{
    /// <summary>
    /// Security audit trail (logins, lockouts, permission denials — Issue 13).
    /// Tenant-scoped via ITenantEntity: rows are tenant-stamped on write and hidden
    /// from other tenants by the global query filter (docs/critical-issues/09 —
    /// AuditLogController previously served every tenant's audit rows to any
    /// SystemAuditLogs holder because this entity had no TenantId at all).
    /// </summary>
    public class AuditLog : BaseTenantEntity
    {
        public string UserName { get; set; } = string.Empty;
        public string Action { get; set; } = string.Empty;
        public string Entity { get; set; } = string.Empty;
        public string EntityId { get; set; } = string.Empty;
        public DateTime Timestamp { get; set; } = DateTime.UtcNow;
        public string Details { get; set; } = string.Empty;
        public string IpAddress { get; set; } = string.Empty;
    }
}
