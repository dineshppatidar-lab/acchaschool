
namespace SchoolManagementApp.ApplicationCore.Entities
{
    // Library Management Entities
    public class Book : BaseTenantEntity
    {
        public int BookId => Id;
        public string Title { get; set; } = string.Empty;
        public string Author { get; set; } = string.Empty;
        public string ISBN { get; set; } = string.Empty;
        public string? Publisher { get; set; }
        public DateTime? PublishDate { get; set; }
        public string Category { get; set; } = string.Empty;
        public string? Subject { get; set; }
        public string? Language { get; set; }
        public string? Edition { get; set; }
        public int? Pages { get; set; }
        public int TotalCopies { get; set; }
        public int AvailableCopies { get; set; }
        public decimal Price { get; set; }
        public string? Location { get; set; }
        public string? Description { get; set; }
        public string? CoverImagePath { get; set; }
        public BookStatus Status { get; set; } = BookStatus.Available;
        public int? IssuedToStudentId { get; set; }
        public DateTime? IssueDate { get; set; }
        public DateTime? DueDate { get; set; }
        public int? IssuedByStaffId { get; set; }
        public DateTime? ReturnDate { get; set; }
        public decimal? FineAmount { get; set; }
        public string? BookCondition { get; set; }
        public string? ReturnNotes { get; set; }
        public virtual Student? IssuedToStudent { get; set; }
        public virtual Staff? IssuedByStaff { get; set; }
        public virtual ICollection<BookIssue> BookIssues { get; set; } = new List<BookIssue>();
        public virtual ICollection<BookReservation> Reservations { get; set; } = new List<BookReservation>();
    }

    public class BookIssue : BaseTenantEntity
    {
        public int BookId { get; set; }
        public int MemberId { get; set; }
        public string MemberType { get; set; } = string.Empty;
        public int StudentId { get; set; }
        public DateTime IssueDate { get; set; }
        public DateTime DueDate { get; set; }
        public DateTime? ReturnDate { get; set; }
        public IssueStatus Status { get; set; } = IssueStatus.Issued;
        public decimal? FineAmount { get; set; }
        public bool FinePaid { get; set; }
        public string Remarks { get; set; } = string.Empty;
        public int IssuedBy { get; set; }
        public int? ReceivedBy { get; set; }
        public virtual Book Book { get; set; } = null!;
        public virtual Student Student { get; set; } = null!;
        public virtual Staff IssuedByStaff { get; set; } = null!;
        public virtual Staff? ReceivedByStaff { get; set; }
    }

    public class BookReservation : BaseTenantEntity
    {
        public int BookId { get; set; }
        public int MemberId { get; set; }
        public string MemberType { get; set; } = string.Empty;
        public DateTime ReservationDate { get; set; }
        public DateTime ExpiryDate { get; set; }
        public ReservationStatus Status { get; set; } = ReservationStatus.Active;
        public string Remarks { get; set; } = string.Empty;
        public virtual Book Book { get; set; } = null!;
    }

    public class LibraryMember : BaseTenantEntity
    {
        public string MembershipNumber { get; set; } = string.Empty;
        public int UserId { get; set; }
        public string UserType { get; set; } = string.Empty;
        public DateTime MembershipDate { get; set; }
        public DateTime ExpiryDate { get; set; }
        public MembershipStatus Status { get; set; } = MembershipStatus.Active;
        public int MaxBooksAllowed { get; set; } = 3;
        public decimal SecurityDeposit { get; set; }
        public bool IsDepositPaid { get; set; }
        public string Remarks { get; set; } = string.Empty;
    }

    // Inventory Management Entities
    public class InventoryCategory : BaseTenantEntity
    {
        public string Name { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public string Code { get; set; } = string.Empty;
        public bool IsActive { get; set; } = true;
        public virtual ICollection<InventoryItem> Items { get; set; } = new List<InventoryItem>();
    }

    public class InventoryItem : BaseTenantEntity
    {
        public string Name { get; set; } = string.Empty;
        public string ItemName { get => Name; set => Name = value; }
        public string Description { get; set; } = string.Empty;
        public string ItemCode { get; set; } = string.Empty;
        public int CategoryId { get; set; }
        public string Brand { get; set; } = string.Empty;
        public string Model { get; set; } = string.Empty;
        public int TotalQuantity { get; set; }
        public int AvailableQuantity { get; set; }
        public int CurrentStock { get => AvailableQuantity; set => AvailableQuantity = value; }
        public int ReorderLevel { get; set; }
        public int MinimumStock { get => ReorderLevel; set => ReorderLevel = value; }
        public decimal UnitPrice { get; set; }
        public string Unit { get; set; } = string.Empty;
        public string Location { get; set; } = string.Empty;
        public ItemCondition Condition { get; set; } = ItemCondition.New;
        public bool IsActive { get; set; } = true;
        public virtual InventoryCategory Category { get; set; } = null!;
        public virtual Staff AddedByStaff { get; set; } = null!;
        public virtual ICollection<InventoryTransaction> Transactions { get; set; } = new List<InventoryTransaction>();
        public virtual ICollection<MaintenanceRecord> MaintenanceRecords { get; set; } = new List<MaintenanceRecord>();
    }

    public class InventoryTransaction : BaseTenantEntity
    {
        public int ItemId { get; set; }
        public int InventoryItemId { get => ItemId; set => ItemId = value; }
        public TransactionType Type { get; set; }
        public TransactionType TransactionType { get => Type; set => Type = value; }
        public int Quantity { get; set; }
        public string Purpose { get; set; } = string.Empty;
        public int? IssuedTo { get; set; }
        public string IssuedToType { get; set; } = string.Empty;
        public DateTime TransactionDate { get; set; }
        public DateTime? ReturnDate { get; set; }
        public DateTime? ExpectedReturnDate { get; set; }
        public InventoryTransactionStatus Status { get; set; } = InventoryTransactionStatus.Completed;
        public string Remarks { get; set; } = string.Empty;
        public string? Notes { get => Remarks; set => Remarks = value ?? string.Empty; }
        public int ProcessedBy { get; set; }
        public int? RequestedByStaffId { get => ProcessedBy; set { if (value.HasValue) ProcessedBy = value.Value; } }
        public virtual InventoryItem Item { get; set; } = null!;
        public virtual Staff ProcessedByStaff { get; set; } = null!;
    }

    public class MaintenanceRecord : BaseTenantEntity
    {
        public int ItemId { get; set; }
        public int? AssetId { get; set; }
        public MaintenanceType Type { get; set; }
        public MaintenanceType MaintenanceType { get => Type; set => Type = value; }
        public string Description { get; set; } = string.Empty;
        public DateTime ScheduledDate { get; set; }
        public DateTime? CompletedDate { get; set; }
        public decimal Cost { get; set; }
        public decimal? EstimatedCost { get; set; }
        public decimal? ActualCost { get; set; }
        public string VendorName { get; set; } = string.Empty;
        public MaintenanceStatus Status { get; set; } = MaintenanceStatus.Scheduled;
        public string Remarks { get; set; } = string.Empty;
        public int RequestedBy { get; set; }
        public int? ScheduledByStaffId { get => RequestedBy; set { if (value.HasValue) RequestedBy = value.Value; } }
        public int? CompletedBy { get; set; }
        public int? CompletedByStaffId { get => CompletedBy; set => CompletedBy = value; }
        public string? CompletionNotes { get; set; }
        public string? Priority { get; set; }
        public virtual InventoryItem? Item { get; set; }
        public virtual Asset? Asset { get; set; }
        public virtual Staff RequestedByStaff { get; set; } = null!;
        public virtual Staff? CompletedByStaff { get; set; }
    }

    public class Asset : BaseTenantEntity
    {
        public string Name { get; set; } = string.Empty;
        public string AssetTag { get; set; } = string.Empty;
        public AssetCategory Category { get; set; }
        public string Brand { get; set; } = string.Empty;
        public string Model { get; set; } = string.Empty;
        public string SerialNumber { get; set; } = string.Empty;
        public DateTime PurchaseDate { get; set; }
        public DateTime AcquisitionDate { get => PurchaseDate; set => PurchaseDate = value; }
        public decimal PurchasePrice { get; set; }
        public decimal CurrentValue { get; set; }
        public string Location { get; set; } = string.Empty;
        public int? AssignedTo { get; set; }
        public string AssignedToType { get; set; } = string.Empty;
        public string? AssignedDepartment { get; set; }
        public AssetCondition Condition { get; set; } = AssetCondition.New;
        public AssetStatus Status { get; set; } = AssetStatus.Available;
        public DateTime? WarrantyExpiry { get; set; }
        public string InsuranceNumber { get; set; } = string.Empty;
        public DateTime? InsuranceExpiry { get; set; }
        public DateTime? LastMaintenanceDate { get; set; }
        public string Remarks { get; set; } = string.Empty;
        public virtual ICollection<AssetTransfer> Transfers { get; set; } = new List<AssetTransfer>();
    }

    public class AssetTransfer : BaseTenantEntity
    {
        public int AssetId { get; set; }
        public int? FromUserId { get; set; }
        public string FromUserType { get; set; } = string.Empty;
        public int ToUserId { get; set; }
        public string ToUserType { get; set; } = string.Empty;
        public DateTime TransferDate { get; set; }
        public string Reason { get; set; } = string.Empty;
        public string Condition { get; set; } = string.Empty;
        public string Remarks { get; set; } = string.Empty;
        public int ApprovedBy { get; set; }
        public string? FromDepartment { get; set; }
        public string? ToDepartment { get; set; }
        public string? TransferReason { get => Reason; set => Reason = value ?? string.Empty; }
        public int? TransferredByStaffId { get => ApprovedBy; set { if (value.HasValue) ApprovedBy = value.Value; } }
        public string? Notes { get => Remarks; set => Remarks = value ?? string.Empty; }
        public virtual Asset Asset { get; set; } = null!;
        public virtual Staff ApprovedByStaff { get; set; } = null!;
    }

    // Library/Inventory Enums
    public enum BookStatus { Available = 1, Issued = 2, Reserved = 3, Lost = 4, Damaged = 5, OutOfCirculation = 6 }
    public enum BookCondition { New = 1, Excellent = 2, Good = 3, Fair = 4, Poor = 5, Damaged = 6 }
    public enum AssetType { Furniture = 1, Electronics = 2, Computers = 3, Vehicles = 4, Laboratory = 5, Sports = 6, Books = 7, Other = 8 }
    public enum InventoryTransactionType { In = 1, Out = 2, Transfer = 3, Adjustment = 4 }
    public enum MaintenancePriority { Low = 1, Medium = 2, High = 3, Critical = 4, Emergency = 5 }
    public enum IssueStatus { Issued = 1, Returned = 2, Overdue = 3, Lost = 4, Renewed = 5 }
    public enum ReservationStatus { Active = 1, Fulfilled = 2, Expired = 3, Cancelled = 4 }
    public enum MembershipStatus { Active = 1, Suspended = 2, Expired = 3, Cancelled = 4 }
    public enum ItemCondition { New = 1, Good = 2, Fair = 3, Poor = 4, Damaged = 5 }
    public enum TransactionType { Issue = 1, Return = 2, Purchase = 3, Disposal = 4, Transfer = 5, Maintenance = 6 }
    public enum InventoryTransactionStatus { Pending = 1, Completed = 2, Cancelled = 3, Overdue = 4 }
    public enum MaintenanceType { Preventive = 1, Corrective = 2, Emergency = 3, Upgrade = 4 }
    public enum MaintenanceStatus { Scheduled = 1, InProgress = 2, Completed = 3, Cancelled = 4, Overdue = 5 }
    public enum AssetCategory { Furniture = 1, Electronics = 2, Computers = 3, Vehicles = 4, Laboratory = 5, Sports = 6, Books = 7, Other = 8 }
    public enum AssetCondition { New = 1, Excellent = 2, Good = 3, Fair = 4, Poor = 5, Damaged = 6 }
    public enum AssetStatus { Available = 1, Assigned = 2, UnderMaintenance = 3, Disposed = 4, Lost = 5, Stolen = 6 }
}
