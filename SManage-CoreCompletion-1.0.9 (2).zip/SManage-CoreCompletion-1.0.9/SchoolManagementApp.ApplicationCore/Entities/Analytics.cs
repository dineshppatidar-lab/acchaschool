
namespace SchoolManagementApp.ApplicationCore.Entities
{
    public class Report : BaseTenantEntity
    {
        public string Name { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public ReportType Type { get; set; }
        public string QueryTemplate { get; set; } = string.Empty;
        public string Parameters { get; set; } = string.Empty;
        public bool IsSystemGenerated { get; set; }
        public bool IsActive { get; set; } = true;
        public string Category { get; set; } = string.Empty;
        public ReportFormat DefaultFormat { get; set; } = ReportFormat.PDF;
        public virtual ICollection<ReportSchedule> Schedules { get; set; } = new List<ReportSchedule>();
        public virtual ICollection<ReportExecution> Executions { get; set; } = new List<ReportExecution>();
    }

    public class ReportSchedule : BaseTenantEntity
    {
        public int ReportId { get; set; }
        public string Name { get; set; } = string.Empty;
        public ScheduleFrequency Frequency { get; set; }
        public DateTime NextRunDate { get; set; }
        public string Recipients { get; set; } = string.Empty;
        public string Parameters { get; set; } = string.Empty;
        public ReportFormat Format { get; set; } = ReportFormat.PDF;
        public bool IsActive { get; set; } = true;
        public virtual Report Report { get; set; } = null!;
        public virtual Staff CreatedByStaff { get; set; } = null!;
    }

    public class ReportExecution : BaseTenantEntity
    {
        public int ReportId { get; set; }
        public DateTime ExecutionDate { get; set; }
        public string Parameters { get; set; } = string.Empty;
        public ReportFormat Format { get; set; }
        public ExecutionStatus Status { get; set; }
        public string FilePath { get; set; } = string.Empty;
        public long FileSizeBytes { get; set; }
        public string ErrorMessage { get; set; } = string.Empty;
        public TimeSpan ExecutionTime { get; set; }
        public int ExecutedBy { get; set; }
        public virtual Report Report { get; set; } = null!;
        public virtual Staff ExecutedByStaff { get; set; } = null!;
    }

    public class Dashboard : BaseTenantEntity
    {
        public string Name { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public DashboardType Type { get; set; }
        public string Layout { get; set; } = string.Empty;
        public bool IsDefault { get; set; }
        public bool IsPublic { get; set; }
        public bool IsActive { get; set; } = true;
        public virtual Staff CreatedByStaff { get; set; } = null!;
        public virtual ICollection<DashboardWidget> Widgets { get; set; } = new List<DashboardWidget>();
        public virtual ICollection<DashboardPermission> Permissions { get; set; } = new List<DashboardPermission>();
    }

    public class DashboardWidget : BaseTenantEntity
    {
        public int DashboardId { get; set; }
        public string Title { get; set; } = string.Empty;
        public WidgetType Type { get; set; }
        public string DataSource { get; set; } = string.Empty;
        public string Configuration { get; set; } = string.Empty;
        public int Position { get; set; }
        public int Width { get; set; } = 6;
        public int Height { get; set; } = 4;
        public string Color { get; set; } = "#1976d2";
        public bool IsVisible { get; set; } = true;
        public virtual Dashboard Dashboard { get; set; } = null!;
    }

    public class DashboardPermission : BaseTenantEntity
    {
        public int DashboardId { get; set; }
        public int UserId { get; set; }
        public string UserType { get; set; } = string.Empty;
        public DashboardPermissionLevel Permission { get; set; }
        public DateTime GrantedDate { get; set; }
        public int GrantedBy { get; set; }
        public virtual Dashboard Dashboard { get; set; } = null!;
        public virtual Staff GrantedByStaff { get; set; } = null!;
    }

    public class AttendanceAnalytics : BaseTenantEntity
    {
        public int StudentId { get; set; }
        public int ClassId { get; set; }
        public int AcademicYearId { get; set; }
        public int Month { get; set; }
        public int Year { get; set; }
        public int TotalDays { get; set; }
        public int PresentDays { get; set; }
        public int AbsentDays { get; set; }
        public int LateDays { get; set; }
        public decimal AttendancePercentage { get; set; }
        public virtual Student Student { get; set; } = null!;
        public virtual Class Class { get; set; } = null!;
        public virtual AcademicYear AcademicYear { get; set; } = null!;
    }

    public class AcademicPerformance : BaseTenantEntity
    {
        public int StudentId { get; set; }
        public int SubjectId { get; set; }
        public int ExaminationId { get; set; }
        public decimal MarksObtained { get; set; }
        public decimal TotalMarks { get; set; }
        public decimal Percentage { get; set; }
        public string Grade { get; set; } = string.Empty;
        public decimal GradePoint { get; set; }
        public int Rank { get; set; }
        public int ClassRank { get; set; }
        public decimal ClassAverage { get; set; }
        public string Remarks { get; set; } = string.Empty;
        public virtual Student Student { get; set; } = null!;
        public virtual Subject Subject { get; set; } = null!;
        public virtual Examination Examination { get; set; } = null!;
    }

    public class FinancialSummary : BaseTenantEntity
    {
        public int AcademicYearId { get; set; }
        public int Month { get; set; }
        public int Year { get; set; }
        public decimal TotalFeesCollected { get; set; }
        public decimal PendingFees { get; set; }
        public decimal TotalExpenses { get; set; }
        public decimal TotalRevenue { get; set; }
        public decimal NetIncome { get; set; }
        public int TotalStudents { get; set; }
        public decimal FeesCollectionPercentage { get; set; }
        public virtual AcademicYear AcademicYear { get; set; } = null!;
    }

    public class SystemMetrics : BaseTenantEntity
    {
        public DateTime RecordDate { get; set; }
        public int TotalUsers { get; set; }
        public int ActiveUsers { get; set; }
        public int TotalStudents { get; set; }
        public int TotalStaff { get; set; }
        public int TotalParents { get; set; }
        public long DatabaseSize { get; set; }
        public decimal SystemLoad { get; set; }
        public int ApiRequestsCount { get; set; }
        public decimal AverageResponseTime { get; set; }
        public int ErrorsCount { get; set; }
    }

    // Analytics Enums
    public enum ReportType { Academic = 1, Financial = 2, Attendance = 3, Staff = 4, Student = 5, Parent = 6, Administrative = 7, Custom = 8 }
    public enum ReportFormat { PDF = 1, Excel = 2, CSV = 3, Word = 4, HTML = 5 }
    public enum ScheduleFrequency { Daily = 1, Weekly = 2, Monthly = 3, Quarterly = 4, Yearly = 5, Custom = 6 }
    public enum ExecutionStatus { Pending = 1, Running = 2, Completed = 3, Failed = 4, Cancelled = 5 }
    public enum DashboardType { Executive = 1, Academic = 2, Financial = 3, Administrative = 4, Student = 5, Teacher = 6, Parent = 7, Custom = 8 }
    public enum WidgetType { Chart = 1, Table = 2, Counter = 3, Progress = 4, Calendar = 5, Map = 6, List = 7, Custom = 8 }
    public enum DashboardPermissionLevel { View = 1, Edit = 2, Full = 3 }
}
