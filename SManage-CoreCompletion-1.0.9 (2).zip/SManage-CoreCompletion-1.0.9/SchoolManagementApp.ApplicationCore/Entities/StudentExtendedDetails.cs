
namespace SchoolManagementApp.ApplicationCore.Entities
{
    public class StudentAddressInfo : BaseTenantEntity
    {
        public int StudentId { get; set; }
        public string CurrentHouseNumber { get; set; } = string.Empty;
        public string CurrentStreetName { get; set; } = string.Empty;
        public string CurrentCity { get; set; } = string.Empty;
        public string CurrentState { get; set; } = string.Empty;
        public string CurrentPostalCode { get; set; } = string.Empty;
        public string CurrentCountry { get; set; } = "India";
        public bool SameAsPermanent { get; set; } = false;
        public string PermanentHouseNumber { get; set; } = string.Empty;
        public string PermanentStreetName { get; set; } = string.Empty;
        public string PermanentCity { get; set; } = string.Empty;
        public string PermanentState { get; set; } = string.Empty;
        public string PermanentPostalCode { get; set; } = string.Empty;
        public string PermanentCountry { get; set; } = "India";
        public virtual Student Student { get; set; } = null!;
    }

    public class StudentAcademicHistory : BaseTenantEntity
    {
        public int StudentId { get; set; }
        public string PreviousSchoolName { get; set; } = string.Empty;
        public string PreviousSchoolBoard { get; set; } = string.Empty;
        public string PreviousSchoolAddress { get; set; } = string.Empty;
        public int? YearPassedFrom { get; set; }
        public string LastGradeAttended { get; set; } = string.Empty;
        public decimal? AcademicPercentage { get; set; }
        public string TransferCertificateNumber { get; set; } = string.Empty;
        public string ReasonForTransfer { get; set; } = string.Empty;
        public virtual Student Student { get; set; } = null!;
    }

    public class StudentSecondaryParent : BaseTenantEntity
    {
        public int StudentId { get; set; }
        public string FirstName { get; set; } = string.Empty;
        public string LastName { get; set; } = string.Empty;
        public string Relationship { get; set; } = string.Empty;
        public string ContactNumber { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string Occupation { get; set; } = string.Empty;
        public virtual Student Student { get; set; } = null!;
    }

    public class StudentEmergencyContact : BaseTenantEntity
    {
        public int StudentId { get; set; }
        public string ContactName { get; set; } = string.Empty;
        public string Relationship { get; set; } = string.Empty;
        public string PrimaryPhone { get; set; } = string.Empty;
        public string SecondaryPhone { get; set; } = string.Empty;
        public string Address { get; set; } = string.Empty;
        public string PreferredContactOrder { get; set; } = "Parent";
        public virtual Student Student { get; set; } = null!;
    }

    public class StudentMedicalInfo : BaseTenantEntity
    {
        public int StudentId { get; set; }
        public string BloodGroup { get; set; } = string.Empty;
        public DateTime? LastHealthCheckDate { get; set; }
        public string KnownAllergies { get; set; } = string.Empty;
        public bool HasAsthma { get; set; }
        public bool HasDiabetes { get; set; }
        public bool HasHeartCondition { get; set; }
        public bool HasEpilepsy { get; set; }
        public string OtherMedicalConditions { get; set; } = string.Empty;
        public bool IsVaccinatedPolio { get; set; }
        public bool IsVaccinatedMeasles { get; set; }
        public bool IsVaccinatedBCG { get; set; }
        public bool IsVaccinatedTCV { get; set; }
        public string PhysicalDisability { get; set; } = string.Empty;
        public string CurrentMedicines { get; set; } = string.Empty;
        public virtual Student Student { get; set; } = null!;
    }

    public class StudentDocumentInfo : BaseTenantEntity
    {
        public int StudentId { get; set; }
        public string IdProofType { get; set; } = string.Empty;
        public string IdProofNumber { get; set; } = string.Empty;
        public DateTime? IdExpiryDate { get; set; }
        public string PassportNumber { get; set; } = string.Empty;
        public string BirthCertificateNumber { get; set; } = string.Empty;
        public string DocumentVerificationStatus { get; set; } = "Pending";
        public string VerifiedBy { get; set; } = string.Empty;
        public DateTime? VerificationDate { get; set; }
        public string DocumentNotes { get; set; } = string.Empty;
        public virtual Student Student { get; set; } = null!;
    }

    public class StudentSpecialNeeds : BaseTenantEntity
    {
        public int StudentId { get; set; }
        public bool HasSpecialNeeds { get; set; }
        public string DisabilityType { get; set; } = string.Empty;
        public string DisabilitySeverity { get; set; } = string.Empty;
        public string AuxiliaryAidsRequired { get; set; } = string.Empty;
        public string SpecialResourcesNeeded { get; set; } = string.Empty;
        public string IEPDocumentPath { get; set; } = string.Empty;
        public bool ParentConsentForSnE { get; set; }
        public virtual Student Student { get; set; } = null!;
    }

    public class StudentHostelInfo : BaseTenantEntity
    {
        public int StudentId { get; set; }
        public bool HostelRequired { get; set; }
        public string PreferredHostel { get; set; } = string.Empty;
        public string RoomType { get; set; } = string.Empty;
        public string TravelMode { get; set; } = string.Empty;
        public decimal? DistanceFromHome { get; set; }
        public string HostelGuardianName { get; set; } = string.Empty;
        public string HostelGuardianContact { get; set; } = string.Empty;
        public DateTime? HostelAllocationDate { get; set; }
        public virtual Student Student { get; set; } = null!;
    }

    public class StudentScholarshipInfo : BaseTenantEntity
    {
        public int StudentId { get; set; }
        public bool EligibleForScholarship { get; set; }
        public string ScholarshipType { get; set; } = string.Empty;
        public decimal? ScholarshipPercentage { get; set; }
        public DateTime? ScholarshipApplicationDate { get; set; }
        public DateTime? ScholarshipApprovalDate { get; set; }
        public string ConcessionType { get; set; } = "None";
        public decimal? ConcessionAmount { get; set; }
        public string ConcessionApprovedBy { get; set; } = string.Empty;
        public virtual Student Student { get; set; } = null!;
    }

    public class StudentBehavioralInfo : BaseTenantEntity
    {
        public int StudentId { get; set; }
        public string BehaviorRecord { get; set; } = "Excellent";
        public int CounselingSessionCount { get; set; }
        public string DisciplinaryHistory { get; set; } = string.Empty;
        public DateTime? LastDisciplinaryActionDate { get; set; }
        public int? ParentTeacherMeetingAttendance { get; set; }
        public string BehavioralConcerns { get; set; } = string.Empty;
        public string TeacherNotes { get; set; } = string.Empty;
        public virtual Student Student { get; set; } = null!;
    }

    public class StudentSystemInfo : BaseTenantEntity
    {
        public int StudentId { get; set; }
        public string StudentUniqueId { get; set; } = string.Empty;
        public string StudentPortalUsername { get; set; } = string.Empty;
        public string StudentStatus { get; set; } = "Active";
        public virtual Student Student { get; set; } = null!;
    }
}
