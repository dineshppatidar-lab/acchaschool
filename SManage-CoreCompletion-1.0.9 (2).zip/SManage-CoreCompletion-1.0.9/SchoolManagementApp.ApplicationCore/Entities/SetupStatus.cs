
namespace SchoolManagementApp.ApplicationCore.Entities
{
    public class SetupStatus : BaseTenantEntity
    {
        public bool AcademicYearCreated { get; set; }
        public bool ClassesCreated { get; set; }
        public bool SubjectsCreated { get; set; }
        public bool StaffCreated { get; set; }
        public bool FeeStructureCreated { get; set; }
        public bool PaymentMethodsCreated { get; set; }
        public bool IsComplete { get; set; }
        public DateTime? SetupCompletedOn { get; set; }
        public string? SetupCompletedBy { get; set; }
        public string? CompletionNotes { get; set; }
        public string? SetupConfigurationJson { get; set; }

        public double GetProgressPercentage()
        {
            int completedCount = 0;
            if (AcademicYearCreated) completedCount++;
            if (ClassesCreated) completedCount++;
            if (SubjectsCreated) completedCount++;
            if (StaffCreated) completedCount++;
            if (FeeStructureCreated) completedCount++;
            if (PaymentMethodsCreated) completedCount++;
            return (completedCount * 100.0) / 6;
        }

        public bool CanCompleteSetup()
        {
            return AcademicYearCreated && ClassesCreated && SubjectsCreated && FeeStructureCreated;
        }

        public List<string> GetMissingComponents()
        {
            var missing = new List<string>();
            if (!AcademicYearCreated) missing.Add("Academic Year");
            if (!ClassesCreated) missing.Add("Classes");
            if (!SubjectsCreated) missing.Add("Subjects");
            if (!FeeStructureCreated) missing.Add("Fee Structure");
            return missing;
        }
    }
}
