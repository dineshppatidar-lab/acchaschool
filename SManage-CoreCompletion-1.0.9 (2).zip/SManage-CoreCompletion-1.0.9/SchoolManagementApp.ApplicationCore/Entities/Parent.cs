
namespace SchoolManagementApp.ApplicationCore.Entities
{
    public class Parent : BaseTenantEntity
    {
        public string FirstName { get; set; } = string.Empty;
        public string LastName { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string PhoneNumber { get; set; } = string.Empty;
        public string Occupation { get; set; } = string.Empty;
        public string Address { get; set; } = string.Empty;
        public string Relationship { get; set; } = string.Empty;
        public bool IsEmergencyContact { get; set; }
        public virtual ICollection<Student> Students { get; set; } = new List<Student>();
    }
}
