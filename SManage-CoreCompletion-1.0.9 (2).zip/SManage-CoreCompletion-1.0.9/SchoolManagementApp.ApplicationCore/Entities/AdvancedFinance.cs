
namespace SchoolManagementApp.ApplicationCore.Entities
{
    public class FeeStructure : BaseTenantEntity
    {
        public string Name { get; set; } = string.Empty;
        public int ClassId { get; set; }
        public int AcademicYearId { get; set; }
        public decimal AnnualFee { get; set; }
        public decimal RegistrationFee { get; set; }
        public decimal TransportFee { get; set; }
        public decimal UniformFee { get; set; }
        public decimal ExaminationFee { get; set; }
        public decimal LibraryFee { get; set; }
        public decimal ComputerFee { get; set; }
        public decimal LaboratoryFee { get; set; }
        public decimal SportsFee { get; set; }
        public decimal MiscellaneousFee { get; set; }
        public bool IsActive { get; set; } = true;
        public DateTime? EffectiveDate { get; set; }
        public virtual Class Class { get; set; } = null!;
        public virtual AcademicYear AcademicYear { get; set; } = null!;
        public virtual ICollection<FeeInstallment> Installments { get; set; } = new List<FeeInstallment>();
    }

    public class FeeInstallment : BaseTenantEntity
    {
        public int FeeStructureId { get; set; }
        public int? StudentFeeAssignmentId { get; set; }
        public string Name { get; set; } = string.Empty;
        public decimal Amount { get; set; }
        public DateTime DueDate { get; set; }
        public decimal? LateFee { get; set; }
        public int GracePeriodDays { get; set; }
        public bool IsActive { get; set; } = true;
        public virtual FeeStructure FeeStructure { get; set; } = null!;
        public virtual ICollection<FeePayment> Payments { get; set; } = new List<FeePayment>();
    }

    public class FeePayment : BaseTenantEntity
    {
        public int StudentId { get; set; }
        public int FeeInstallmentId { get; set; }
        public decimal AmountPaid { get; set; }
        public decimal? LateFeeAmount { get; set; }
        public decimal? DiscountAmount { get; set; }
        public DateTime PaymentDate { get; set; }
        public PaymentMethodType PaymentMethod { get; set; }
        public string TransactionId { get; set; } = string.Empty;
        public string ReceiptNumber { get; set; } = string.Empty;
        public PaymentStatus Status { get; set; } = PaymentStatus.Completed;
        public string Remarks { get; set; } = string.Empty;
        public int? CollectedByStaffId { get; set; }
        public int? GroupPaymentAllocationId { get; set; }
        public virtual Student Student { get; set; } = null!;
        public virtual FeeInstallment FeeInstallment { get; set; } = null!;
        public virtual Staff? CollectedByStaff { get; set; }
        public virtual GroupPaymentAllocation? GroupPaymentAllocation { get; set; }
        public virtual ICollection<FeeRefund> Refunds { get; set; } = new List<FeeRefund>();
    }

    public class FeeRefund : BaseTenantEntity
    {
        public int PaymentId { get; set; }
        public int StudentId { get; set; }
        public decimal RefundAmount { get; set; }
        public DateTime RefundDate { get; set; } = DateTime.UtcNow;
        public PaymentMethodType RefundMode { get; set; }
        public string RefundReason { get; set; } = string.Empty;
        public string ReferenceNumber { get; set; } = string.Empty;
        public string Remarks { get; set; } = string.Empty;
        public RefundStatus Status { get; set; } = RefundStatus.Completed;
        public virtual FeePayment Payment { get; set; } = null!;
        public virtual Student Student { get; set; } = null!;
    }

    public class StudentFeeAssignment : BaseTenantEntity
    {
        public int StudentId { get; set; }
        public int FeeStructureId { get; set; }
        public DateTime AssignmentDate { get; set; }
        public DateTime? UnassignmentDate { get; set; }
        public bool IsActive { get; set; } = true;
        public string Remarks { get; set; } = string.Empty;
        public virtual Student Student { get; set; } = null!;
        public virtual FeeStructure FeeStructure { get; set; } = null!;
    }

    public class FamilyGroup : BaseTenantEntity
    {
        public string FamilyName { get; set; } = string.Empty;
        public string PrimaryContactNumber { get; set; } = string.Empty;
        public string Remarks { get; set; } = string.Empty;
        public bool IsActive { get; set; } = true;
        public virtual ICollection<FamilyGroupMember> Members { get; set; } = new List<FamilyGroupMember>();
        public virtual ICollection<GroupPayment> GroupPayments { get; set; } = new List<GroupPayment>();
    }

    public class FamilyGroupMember : BaseTenantEntity
    {
        public int FamilyGroupId { get; set; }
        public int StudentId { get; set; }
        public string Relationship { get; set; } = "Sibling";
        public bool IsPrimaryMember { get; set; }
        public virtual FamilyGroup FamilyGroup { get; set; } = null!;
        public virtual Student Student { get; set; } = null!;
    }

    public class StudentFeeAdjustment : BaseTenantEntity
    {
        public int StudentId { get; set; }
        public int AcademicYearId { get; set; }
        public FeeAdjustmentType AdjustmentType { get; set; }
        public bool IsPercentage { get; set; }
        public decimal? DiscountPercentage { get; set; }
        public decimal? DiscountAmount { get; set; }
        public decimal? MaximumCap { get; set; }
        public DateTime EffectiveDate { get; set; }
        public DateTime? ExpiryDate { get; set; }
        public bool IsFullWaiver { get; set; }
        public string WaiverCategory { get; set; } = "";
        public FeeAdjustmentStatus Status { get; set; } = FeeAdjustmentStatus.Active;
        public string? ApprovedBy { get; set; }
        public DateTime? ApprovedDate { get; set; }
        public string ApprovalRemarks { get; set; } = "";
        public string Remarks { get; set; } = "";
        public int? SpecificInstallmentId { get; set; }
        public int? FeeComponentCategory { get; set; }
        public virtual Student Student { get; set; } = null!;
        public virtual AcademicYear AcademicYear { get; set; } = null!;
    }

    public class GroupPayment : BaseTenantEntity
    {
        public int? FamilyGroupId { get; set; }
        public string PaymentGroupName { get; set; } = "";
        public decimal TotalAmountPaid { get; set; }
        public PaymentMethodType PaymentMethod { get; set; }
        public string TransactionId { get; set; } = "";
        public string ReceiptNumber { get; set; } = "";
        public DateTime PaymentDate { get; set; } = DateTime.UtcNow;
        public PaymentAllocationStrategy AllocationStrategy { get; set; }
        public int? ProcessedByStaffId { get; set; }
        public GroupPaymentStatus Status { get; set; } = GroupPaymentStatus.Completed;
        public string Remarks { get; set; } = "";
        public virtual FamilyGroup? FamilyGroup { get; set; }
        public virtual ICollection<GroupPaymentAllocation> Allocations { get; set; } = new List<GroupPaymentAllocation>();
    }

    public class GroupPaymentAllocation : BaseTenantEntity
    {
        public int GroupPaymentId { get; set; }
        public int StudentId { get; set; }
        public int FeeInstallmentId { get; set; }
        public decimal AllocatedAmount { get; set; }
        public decimal ActualAmountApplied { get; set; }
        public decimal? DiscountApplied { get; set; }
        public int? CreatedFeePaymentId { get; set; }
        public GroupPaymentAllocationStatus AllocationStatus { get; set; } = GroupPaymentAllocationStatus.Allocated;
        public virtual GroupPayment GroupPayment { get; set; } = null!;
        public virtual Student Student { get; set; } = null!;
        public virtual FeeInstallment FeeInstallment { get; set; } = null!;
        public virtual FeePayment? CreatedFeePayment { get; set; }
    }

    public class Scholarship : BaseTenantEntity
    {
        public string Name { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public ScholarshipType Type { get; set; }
        public decimal Amount { get; set; }
        public bool IsPercentage { get; set; }
        public string Criteria { get; set; } = string.Empty;
        public DateTime ApplicationStartDate { get; set; }
        public DateTime ApplicationEndDate { get; set; }
        public int MaxBeneficiaries { get; set; }
        public bool IsActive { get; set; } = true;
        public virtual ICollection<ScholarshipApplication> Applications { get; set; } = new List<ScholarshipApplication>();
    }

    public class ScholarshipApplication : BaseTenantEntity
    {
        public int ScholarshipId { get; set; }
        public int StudentId { get; set; }
        public DateTime ApplicationDate { get; set; }
        public string ApplicationData { get; set; } = string.Empty;
        public string DocumentsPath { get; set; } = string.Empty;
        public ScholarshipStatus Status { get; set; } = ScholarshipStatus.Applied;
        public decimal? ApprovedAmount { get; set; }
        public string Remarks { get; set; } = string.Empty;
        public DateTime? ReviewDate { get; set; }
        public string? ReviewedBy { get; set; }
        public virtual Scholarship Scholarship { get; set; } = null!;
        public virtual Student Student { get; set; } = null!;
        public virtual Staff? ReviewedByStaff { get; set; }
    }

    public class Expense : BaseTenantEntity
    {
        public string Title { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public ExpenseCategory Category { get; set; }
        public decimal Amount { get; set; }
        public DateTime ExpenseDate { get; set; }
        public string VoucherNumber { get; set; } = string.Empty;
        public string VendorName { get; set; } = string.Empty;
        public ExpenseStatus Status { get; set; } = ExpenseStatus.Pending;
        public string ReceiptPath { get; set; } = string.Empty;
        public string RequestedBy { get; set; } = string.Empty;
        public DateTime RequestDate { get; set; }
        public string? ApprovedBy { get; set; }
        public DateTime? ApprovalDate { get; set; }
        public string ApprovalRemarks { get; set; } = string.Empty;
        public virtual Staff? RequestedByStaff { get; set; }
        public virtual Staff? ApprovedByStaff { get; set; }
    }

    public class Budget : BaseTenantEntity
    {
        public string Name { get; set; } = string.Empty;
        public int AcademicYearId { get; set; }
        public ExpenseCategory Category { get; set; }
        public decimal AllocatedAmount { get; set; }
        public decimal UtilizedAmount { get; set; }
        public decimal RemainingAmount => AllocatedAmount - UtilizedAmount;
        public BudgetStatus Status { get; set; } = BudgetStatus.Active;
        public virtual AcademicYear AcademicYear { get; set; } = null!;
        public virtual Staff? CreatedByStaff { get; set; }
        public virtual ICollection<Expense> Expenses { get; set; } = new List<Expense>();
    }

    public class Invoice : BaseTenantEntity
    {
        public string InvoiceNumber { get; set; } = string.Empty;
        public int? StudentId { get; set; }
        public string CustomerName { get; set; } = string.Empty;
        public string CustomerAddress { get; set; } = string.Empty;
        public string CustomerPhone { get; set; } = string.Empty;
        public string CustomerEmail { get; set; } = string.Empty;
        public DateTime InvoiceDate { get; set; }
        public DateTime DueDate { get; set; }
        public decimal SubTotal { get; set; }
        public decimal TaxAmount { get; set; }
        public decimal DiscountAmount { get; set; }
        public decimal TotalAmount { get; set; }
        public InvoiceStatus Status { get; set; } = InvoiceStatus.Draft;
        public string Notes { get; set; } = string.Empty;
        public virtual Student? Student { get; set; }
        public virtual Staff? CreatedByStaff { get; set; }
        public virtual ICollection<InvoiceItem> Items { get; set; } = new List<InvoiceItem>();
    }

    /// <summary>
    /// Tenant entity so its query filter matches Invoice's — EF warns (10622)
    /// when a filtered required parent has an unfiltered required child.
    /// </summary>
    public class InvoiceItem : BaseTenantEntity
    {
        public int InvoiceId { get; set; }
        public string Description { get; set; } = string.Empty;
        public int Quantity { get; set; }
        public decimal UnitPrice { get; set; }
        public decimal Amount => Quantity * UnitPrice;
        public virtual Invoice Invoice { get; set; } = null!;
    }

    public class FeeRule : BaseTenantEntity
    {
        public string Name { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public FeeRuleType RuleType { get; set; }
        public FeeRuleCondition Condition { get; set; }
        public decimal ConditionValue { get; set; }
        public decimal ActionValue { get; set; }
        public bool IsPercentage { get; set; }
        public int Priority { get; set; } = 1;
        public bool IsActive { get; set; } = true;
        public int? AcademicYearId { get; set; }
        public int? ClassId { get; set; }
    }

    public class StudentLedger : BaseTenantEntity
    {
        public int StudentId { get; set; }
        public LedgerEntryType EntryType { get; set; }
        public decimal Amount { get; set; }
        public decimal RunningBalance { get; set; }
        public string Description { get; set; } = string.Empty;
        public string ReferenceType { get; set; } = string.Empty;
        public int? ReferenceId { get; set; }
        public DateTime TransactionDate { get; set; } = DateTime.UtcNow;
        public string Remarks { get; set; } = string.Empty;
        public virtual Student Student { get; set; } = null!;
    }

    public class FeeNotificationLog : BaseTenantEntity
    {
        public int StudentId { get; set; }
        public FeeNotificationType NotificationType { get; set; }
        public string Channel { get; set; } = "Email";
        public string Recipient { get; set; } = string.Empty;
        public string Subject { get; set; } = string.Empty;
        public string Message { get; set; } = string.Empty;
        public bool IsSent { get; set; }
        public DateTime? SentAt { get; set; }
        public string? ErrorMessage { get; set; }
        public int? RelatedInstallmentId { get; set; }
        public int? RelatedPaymentId { get; set; }
        public virtual Student Student { get; set; } = null!;
    }

    public class MultiInstallmentPayment : BaseTenantEntity
    {
        public int StudentId { get; set; }
        public decimal TotalAmountPaid { get; set; }
        public PaymentMethodType PaymentMethod { get; set; }
        public string TransactionId { get; set; } = string.Empty;
        public string ReceiptNumber { get; set; } = string.Empty;
        public DateTime PaymentDate { get; set; } = DateTime.UtcNow;
        public int? CollectedByStaffId { get; set; }
        public string Remarks { get; set; } = string.Empty;
        public PaymentStatus Status { get; set; } = PaymentStatus.Completed;
        public virtual Student Student { get; set; } = null!;
        public virtual ICollection<FeePayment> Payments { get; set; } = new List<FeePayment>();
    }

    public class FinanceAuditLog : BaseTenantEntity
    {
        public string EntityType { get; set; } = string.Empty;
        public int? EntityId { get; set; }
        public string Action { get; set; } = string.Empty;
        public string OldValues { get; set; } = string.Empty;
        public string NewValues { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public string IpAddress { get; set; } = string.Empty;
    }

    // Finance Enums
    public enum PaymentMethodType { Cash = 1, Cheque = 2, CreditCard = 3, DebitCard = 4, OnlineTransfer = 5, UPI = 6, NetBanking = 7, EMI = 8 }
    public enum PaymentStatus { Pending = 1, Completed = 2, Failed = 3, Refunded = 4, Cancelled = 5 }
    public enum RefundStatus { Pending = 1, Completed = 2, Cancelled = 3 }
    public enum ScholarshipType { Merit = 1, NeedBased = 2, Sports = 3, Cultural = 4, Minority = 5, Disability = 6, Other = 7 }
    public enum ScholarshipStatus { Applied = 1, UnderReview = 2, Approved = 3, Rejected = 4, Cancelled = 5 }
    public enum ExpenseCategory { Salaries = 1, Infrastructure = 2, Utilities = 3, Supplies = 4, Equipment = 5, Maintenance = 6, Transport = 7, Events = 8, Marketing = 9, Legal = 10, Other = 11 }
    public enum ExpenseStatus { Pending = 1, Approved = 2, Rejected = 3, Paid = 4 }
    public enum BudgetStatus { Active = 1, Inactive = 2, Exceeded = 3, Completed = 4 }
    public enum InvoiceStatus { Draft = 1, Sent = 2, Paid = 3, Overdue = 4, Cancelled = 5 }
    public enum FeeRuleType { LateFee = 1, SiblingDiscount = 2, ScholarshipDiscount = 3, EarlyPaymentDiscount = 4, WaiverDiscount = 5, OverdueFine = 6 }
    public enum FeeRuleCondition { Always = 0, DaysOverdue = 1, SiblingCount = 2, PercentageScoreAbove = 3, DaysEarlyPayment = 4 }
    public enum LedgerEntryType { Debit = 1, Credit = 2 }
    public enum FeeNotificationType { DueReminder = 1, OverdueAlert = 2, PaymentConfirmation = 3, ScholarshipGranted = 4, BulkFeesAssigned = 5, ReceiptGenerated = 6 }
    public enum FeeAdjustmentType { Waiver = 1, Discount = 2 }
    public enum FeeAdjustmentStatus { Active = 1, Inactive = 2, Expired = 3, PendingApproval = 4, Rejected = 5 }
    public enum PaymentAllocationStrategy { Proportional = 1, EqualSplit = 2, Custom = 3, ByWeight = 4 }
    public enum GroupPaymentStatus { Pending = 1, Completed = 2, PartiallyApplied = 3, Failed = 4, Cancelled = 5 }
    public enum GroupPaymentAllocationStatus { Allocated = 1, Applied = 2, Reversed = 3, Adjustment = 4 }
}
