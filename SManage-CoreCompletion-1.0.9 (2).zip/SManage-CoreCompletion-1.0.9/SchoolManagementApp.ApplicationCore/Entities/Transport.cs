
namespace SchoolManagementApp.ApplicationCore.Entities
{
    public class BusRoute : BaseTenantEntity
    {
        public string RouteName { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public TimeSpan StartTime { get; set; }
        public TimeSpan EndTime { get; set; }
        public int VehicleId { get; set; }
        // Nullable: a route may exist before a driver is assigned. Non-nullable int forced
        // the UI to send 0 ("none"), which violated FK_BusRoutes_Staff_DriverId on insert.
        public int? DriverId { get; set; }
        [JsonIgnore]
        public virtual Vehicle? Vehicle { get; set; }
        [JsonIgnore]
        public virtual Staff? Driver { get; set; }
        public virtual ICollection<RouteStop> Stops { get; set; } = new List<RouteStop>();
        public virtual ICollection<Student> Students { get; set; } = new List<Student>();
    }

    public class Vehicle : BaseTenantEntity
    {
        public string VehicleNumber { get; set; } = string.Empty;
        public string Model { get; set; } = string.Empty;
        public int Capacity { get; set; }
        public string Status { get; set; } = string.Empty;
        public string? VehicleType { get; set; }
        public string? Manufacturer { get; set; }
        public string? DriverName { get; set; }
        public string? DriverContact { get; set; }
        public string? DriverLicense { get; set; }
        public string? FuelType { get; set; }
        public DateTime? PurchaseDate { get; set; }
        public DateTime? InsuranceExpiry { get; set; }
        public DateTime? FitnessExpiry { get; set; }
        public string? Description { get; set; }
        [System.ComponentModel.DataAnnotations.Schema.NotMapped]
        public int? RouteId { get; set; }
        [JsonIgnore]
        public virtual BusRoute? Route { get; set; }
    }

    public class RouteStop : BaseTenantEntity
    {
        public int RouteId { get; set; }
        public string StopName { get; set; } = string.Empty;
        public TimeSpan ArrivalTime { get; set; }
        public decimal Latitude { get; set; }
        public decimal Longitude { get; set; }
        public int SequenceNumber { get; set; }
        [JsonIgnore]
        public virtual BusRoute? Route { get; set; }
    }

    public class TransportFee : BaseTenantEntity
    {
        public string ZoneName { get; set; } = string.Empty;
        public decimal MonthlyFee { get; set; }
        public decimal QuarterlyFee { get; set; }
        public virtual ICollection<RouteStop> Stops { get; set; } = new List<RouteStop>();
    }

    public class BusAttendance : BaseTenantEntity
    {
        public int StudentId { get; set; }
        public int RouteId { get; set; }
        public DateTime Date { get; set; }
        public bool IsPresent { get; set; }
        public string MarkingMethod { get; set; } = string.Empty;
        [JsonIgnore]
        public virtual Student? Student { get; set; }
        [JsonIgnore]
        public virtual BusRoute? Route { get; set; }
    }
}
