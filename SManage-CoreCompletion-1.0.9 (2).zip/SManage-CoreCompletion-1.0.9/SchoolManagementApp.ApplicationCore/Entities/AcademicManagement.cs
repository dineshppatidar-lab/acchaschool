
namespace SchoolManagementApp.ApplicationCore.Entities
{
    public class Attendance : BaseTenantEntity
    {
        public DateTime Date { get; set; }
        public bool IsPresent { get; set; }
        public string Remarks { get; set; } = string.Empty;

        public int? StudentId { get; set; }
        public virtual Student Student { get; set; } = null!;

        public int? StaffId { get; set; }
        public virtual Staff Staff { get; set; } = null!;
    }

    public class ExamResult : BaseTenantEntity
    {
        public int StudentId { get; set; }
        public int SubjectId { get; set; }
        public string ExamType { get; set; } = string.Empty;
        public DateTime ExamDate { get; set; }
        public decimal MarksObtained { get; set; }
        public decimal TotalMarks { get; set; }
        public string Grade { get; set; } = string.Empty;
        public string Remarks { get; set; } = string.Empty;
        public virtual Student Student { get; set; } = null!;
        public virtual Subject Subject { get; set; } = null!;
    }

    public class Document : BaseTenantEntity
    {
        public int StudentId { get; set; }
        public string DocumentType { get; set; } = string.Empty;
        public string FileName { get; set; } = string.Empty;
        public string FilePath { get; set; } = string.Empty;
        public byte[]? FileContent { get; set; }
        public long FileSize { get; set; }
        public DateTime UploadDate { get; set; } = DateTime.UtcNow;
        public virtual Student Student { get; set; } = null!;
    }
}
