
namespace SchoolManagementApp.ApplicationCore.Entities
{
    public class Fee : BaseTenantEntity
    {
        public int StudentId { get; set; }
        public string FeeType { get; set; } = string.Empty;
        public decimal Amount { get; set; }
        public DateTime DueDate { get; set; }
        public string Status { get; set; } = string.Empty;
        public virtual Student? Student { get; set; }
        public virtual ICollection<Payment>? Payments { get; set; }
    }

    public class Payment : BaseTenantEntity
    {
        public int FeeId { get; set; }
        public decimal Amount { get; set; }
        public DateTime PaymentDate { get; set; }
        public string PaymentMethod { get; set; } = string.Empty;
        public string TransactionId { get; set; } = string.Empty;
        public string Status { get; set; } = string.Empty;
        public string ReceiptNumber { get; set; } = string.Empty;
        public virtual Fee? Fee { get; set; }
    }
}
