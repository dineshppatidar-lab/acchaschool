using SchoolManagementApp.ApplicationCore._Entities;

namespace SchoolManagementApp.ApplicationCore.Entities
{
    /// <summary>
    /// A persisted, per-user notification shown in the header notification bell.
    /// Created by RealtimeNotificationService whenever it pushes an event, so the
    /// bell has history even for users who were offline at push time.
    /// </summary>
    public class Notification : BaseTenantEntity
    {
        public string Title { get; set; } = string.Empty;
        public string Message { get; set; } = string.Empty;
        public string Type { get; set; } = string.Empty;
        public bool IsRead { get; set; }

        /// <summary>Recipient user. 0 = tenant-wide broadcast (visible to every user of the tenant).</summary>
        public int UserId { get; set; }

        /// <summary>Optional frontend route the notification navigates to when clicked (e.g. /app/fees).</summary>
        public string? Link { get; set; }

        /// <summary>Optional JSON payload with extra context (ids, etc.).</summary>
        public string? Data { get; set; }

        public virtual User User { get; set; } = null!;
    }
}
