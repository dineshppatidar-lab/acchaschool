
namespace SchoolManagementApp.ApplicationCore.Analytics.Interfaces
{
    public interface IReportRepository : IGenericRepository<Report>
    {
        Task<IEnumerable<Report>> GetReportsByCategoryAsync(string category);
        Task<IEnumerable<Report>> GetSystemGeneratedReportsAsync();
        Task<Report> GetReportWithSchedulesAsync(int id);
        Task<IEnumerable<Report>> GetActiveReportsAsync();
    }

    public interface IReportScheduleRepository : IGenericRepository<ReportSchedule>
    {
        Task<IEnumerable<ReportSchedule>> GetSchedulesByReportAsync(int reportId);
        Task<IEnumerable<ReportSchedule>> GetActiveSchedulesAsync();
        Task<IEnumerable<ReportSchedule>> GetSchedulesDueForExecutionAsync();
    }

    public interface IReportExecutionRepository : IGenericRepository<ReportExecution>
    {
        Task<IEnumerable<ReportExecution>> GetExecutionsByReportAsync(int reportId);
        Task<IEnumerable<ReportExecution>> GetExecutionsByDateRangeAsync(DateTime startDate, DateTime endDate);
        Task<IEnumerable<ReportExecution>> GetFailedExecutionsAsync();
    }

    public interface IDashboardRepository : IGenericRepository<Dashboard>
    {
        Task<IEnumerable<Dashboard>> GetDashboardsByUserAsync(int userId, string userType);
        Task<Dashboard> GetDashboardWithWidgetsAsync(int id);
        Task<IEnumerable<Dashboard>> GetPublicDashboardsAsync();
        Task<IEnumerable<Dashboard>> GetDashboardsByTypeAsync(DashboardType type);
    }

    public interface IDashboardWidgetRepository : IGenericRepository<DashboardWidget>
    {
        Task<IEnumerable<DashboardWidget>> GetWidgetsByDashboardAsync(int dashboardId);
        Task<IEnumerable<DashboardWidget>> GetVisibleWidgetsAsync(int dashboardId);
    }

    public interface IAttendanceAnalyticsRepository : IGenericRepository<AttendanceAnalytics>
    {
        Task<IEnumerable<AttendanceAnalytics>> GetAnalyticsByStudentAsync(int studentId, int academicYearId);
        Task<IEnumerable<AttendanceAnalytics>> GetAnalyticsByClassAsync(int classId, int academicYearId);
        Task<IEnumerable<AttendanceAnalytics>> GetLowAttendanceStudentsAsync(decimal threshold = 75);
    }

    public interface IAcademicPerformanceRepository : IGenericRepository<AcademicPerformance>
    {
        Task<IEnumerable<AcademicPerformance>> GetPerformanceByStudentAsync(int studentId);
        Task<IEnumerable<AcademicPerformance>> GetPerformanceByExaminationAsync(int examinationId);
        Task<IEnumerable<AcademicPerformance>> GetTopPerformersAsync(int subjectId, int examinationId, int count = 10);
    }

    public interface IFinancialSummaryRepository : IGenericRepository<FinancialSummary>
    {
        Task<IEnumerable<FinancialSummary>> GetSummaryByAcademicYearAsync(int academicYearId);
        Task<FinancialSummary> GetSummaryByMonthAsync(int month, int year);
        Task<IEnumerable<FinancialSummary>> GetSummaryByDateRangeAsync(DateTime startDate, DateTime endDate);
    }

    public interface ISystemMetricsRepository : IGenericRepository<SystemMetrics>
    {
        Task<IEnumerable<SystemMetrics>> GetMetricsByDateRangeAsync(DateTime startDate, DateTime endDate);
        Task<SystemMetrics> GetLatestMetricsAsync();
        Task<IEnumerable<SystemMetrics>> GetMetricsTrendAsync(int days = 30);
    }
}
