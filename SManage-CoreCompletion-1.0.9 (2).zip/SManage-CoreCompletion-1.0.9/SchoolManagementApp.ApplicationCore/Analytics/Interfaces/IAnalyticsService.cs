namespace SchoolManagementApp.ApplicationCore.Analytics.Interfaces
{
    /// <summary>
    /// Service interface for analytics and reporting operations.
    /// </summary>
    public interface IAnalyticsService
    {
        // Dashboard Analytics
        Task<object> GetDashboardOverviewAsync();

        // Performance Trends
        Task<object> GetPerformanceTrendsAsync(int? classId, int months);

        // Attendance Analytics
        Task<object> GetAttendanceAnalyticsAsync(int? classId, int? studentId);

        // Financial Analytics
        Task<object> GetFinancialAnalyticsAsync(int months);

        // Student Performance Distribution
        Task<object> GetStudentPerformanceDistributionAsync(int? classId);

        // Staff Performance
        Task<object> GetStaffPerformanceAsync();

        // Absenteeism Risk
        Task<object> GetAbsenteeismRiskAsync();

        // Predictive Insights
        Task<object> GetPredictiveInsightsAsync();
    }
}
