using System.Collections.Concurrent;

namespace SchoolManagementApp.ApplicationCore.Common
{
    /// <summary>
    /// Tracks failed login attempts and enforces lockouts (docs/critical-issues/04-legacy-passwords-and-lockout-dos.md):
    ///  - Per (tenant, username): <see cref="LoginAttemptTracker.MaxAttempts"/> failures → <see cref="LoginAttemptTracker.LockoutWindow"/> lock.
    ///  - Per IP: <see cref="LoginAttemptTracker.IpMaxAttempts"/> failures across any username → <see cref="LoginAttemptTracker.IpLockoutWindow"/> lock.
    /// Successful logins reset the per-user counter (the per-IP counter only decays via window expiry,
    /// so an attacker cannot recycle one IP across many victim usernames).
    /// Thread-safe, in-memory (per server instance).
    /// </summary>
    public interface ILoginAttemptTracker
    {
        /// <summary>Returns true when the given identity is currently locked out (per-user OR per-IP).</summary>
        bool IsLockedOut(string tenantCode, string username, string? ipAddress = null);

        /// <summary>Seconds remaining in the current lockout window (0 when not locked). Reports the longer of user/IP lockouts.</summary>
        int GetRemainingLockoutSeconds(string tenantCode, string username, string? ipAddress = null);

        /// <summary>Number of consecutive failed attempts since the last success (0 when locked out).</summary>
        int GetFailureCount(string tenantCode, string username);

        /// <summary>Records a failed attempt. Returns true when this failure triggered a lockout (user or IP).</summary>
        bool RecordFailure(string tenantCode, string username, string? ipAddress = null);

        /// <summary>Clears the per-user counter after a successful login.</summary>
        void RecordSuccess(string tenantCode, string username);
    }

    public class LoginAttemptTracker : ILoginAttemptTracker
    {
        public const int MaxAttempts = 5;
        public static readonly TimeSpan LockoutWindow = TimeSpan.FromMinutes(1);

        public const int IpMaxAttempts = 30;
        public static readonly TimeSpan IpLockoutWindow = TimeSpan.FromMinutes(5);

        private sealed record Entry(int Failures, DateTimeOffset LockedUntilUtc)
        {
            public bool IsLocked(DateTimeOffset now) => LockedUntilUtc > now;
        }

        private readonly ConcurrentDictionary<string, Entry> _attempts = new();
        private readonly ConcurrentDictionary<string, Entry> _ipAttempts = new();

        private static string Key(string tenantCode, string username) =>
            $"{tenantCode?.Trim().ToUpperInvariant()}:{username?.Trim().ToLowerInvariant()}";

        private static string IpKey(string? ipAddress) =>
            (string.IsNullOrWhiteSpace(ipAddress) ? "unknown" : ipAddress.Trim()).ToUpperInvariant();

        public bool IsLockedOut(string tenantCode, string username, string? ipAddress = null)
            => GetRemainingLockoutSeconds(tenantCode, username, ipAddress) > 0;

        public int GetRemainingLockoutSeconds(string tenantCode, string username, string? ipAddress = null)
        {
            var now = DateTimeOffset.UtcNow;

            var userRemaining = 0;
            if (_attempts.TryGetValue(Key(tenantCode, username), out var userEntry))
                userRemaining = Math.Max(0, (int)Math.Ceiling((userEntry.LockedUntilUtc - now).TotalSeconds));

            var ipRemaining = 0;
            if (!string.IsNullOrWhiteSpace(ipAddress) && _ipAttempts.TryGetValue(IpKey(ipAddress), out var ipEntry))
                ipRemaining = Math.Max(0, (int)Math.Ceiling((ipEntry.LockedUntilUtc - now).TotalSeconds));

            return Math.Max(userRemaining, ipRemaining);
        }

        public int GetFailureCount(string tenantCode, string username)
        {
            if (!_attempts.TryGetValue(Key(tenantCode, username), out var entry))
                return 0;

            // While locked the counter is meaningless for messaging purposes.
            return entry.IsLocked(DateTimeOffset.UtcNow) ? 0 : entry.Failures;
        }

        public bool RecordFailure(string tenantCode, string username, string? ipAddress = null)
        {
            var now = DateTimeOffset.UtcNow;
            var triggeredLockout = RecordUserFailure(tenantCode, username, now);
            var triggeredIpLockout = RecordIpFailure(ipAddress, now);

            return triggeredLockout || triggeredIpLockout;
        }

        private bool RecordUserFailure(string tenantCode, string username, DateTimeOffset now)
        {
            var triggeredLockout = false;
            var key = Key(tenantCode, username);

            _attempts.AddOrUpdate(
                key,
                _ => new Entry(1, DateTimeOffset.MinValue),
                (_, existing) =>
                {
                    // While locked, keep extending nothing: the lockout runs its fixed window.
                    if (existing.IsLocked(now))
                        return existing;

                    int failures = existing.Failures + 1;
                    if (failures >= MaxAttempts)
                    {
                        triggeredLockout = true;
                        return new Entry(failures, now.Add(LockoutWindow));
                    }
                    return new Entry(failures, DateTimeOffset.MinValue);
                });

            return triggeredLockout;
        }

        private bool RecordIpFailure(string? ipAddress, DateTimeOffset now)
        {
            if (string.IsNullOrWhiteSpace(ipAddress))
                return false;

            var triggeredIpLockout = false;
            var key = IpKey(ipAddress);

            _ipAttempts.AddOrUpdate(
                key,
                _ => new Entry(1, DateTimeOffset.MinValue),
                (_, existing) =>
                {
                    if (existing.IsLocked(now))
                        return existing;

                    int failures = existing.Failures + 1;
                    if (failures >= IpMaxAttempts)
                    {
                        triggeredIpLockout = true;
                        return new Entry(failures, now.Add(IpLockoutWindow));
                    }
                    return new Entry(failures, DateTimeOffset.MinValue);
                });

            return triggeredIpLockout;
        }

        public void RecordSuccess(string tenantCode, string username)
        {
            _attempts.TryRemove(Key(tenantCode, username), out _);
        }
    }
}
