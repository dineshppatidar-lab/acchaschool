namespace SchoolManagementApp.ApplicationCore.Common
{
    /// <summary>
    /// Pure (no DB, no DI) helpers for tenant-host handling, shared by TenantService writes
    /// (bound-domain validation) and by tests. Kept static so resolution rules are identical
    /// everywhere — AuthService.LoginAsync's in-memory matcher must agree with these rules.
    /// </summary>
    public static class DomainValidator
    {
        private static readonly System.Text.RegularExpressions.Regex HostnamePattern =
            new(@"^([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)(\.[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)+$",
                System.Text.RegularExpressions.RegexOptions.Compiled);

        /// <summary>
        /// Lower-cases a host and strips scheme, port and path so a stored value like
        /// "https://MySchool.Example.com:443/" matches the request host "myschool.example.com".
        /// </summary>
        public static string NormalizeHost(string? domain)
        {
            var d = (domain ?? string.Empty).Trim().ToLowerInvariant();
            var schemeIdx = d.IndexOf("://", StringComparison.Ordinal);
            if (schemeIdx >= 0) d = d[(schemeIdx + 3)..];
            var slashIdx = d.IndexOf('/');
            if (slashIdx >= 0) d = d[..slashIdx];
            var portIdx = d.IndexOf(':');
            if (portIdx >= 0) d = d[..portIdx];
            return d;
        }

        /// <summary>True when the normalized value is a plausible public hostname (≥2 labels).</summary>
        public static bool IsWellFormedHost(string normalized)
            => normalized.Length > 0
                && normalized.Length <= 253
                && !normalized.StartsWith(".") && !normalized.EndsWith(".")
                && HostnamePattern.IsMatch(normalized);

        /// <summary>First dot-separated label of a normalized hostname ("greenvalley" from greenvalley.acchaschool.com).</summary>
        public static string FirstLabel(string normalized)
            => normalized.Length == 0 ? string.Empty : normalized.Split('.')[0];

        /// <summary>
        /// True when the given subdomain label may not be registered by a school
        /// (platform hostnames such as www / api / admin / login).
        /// </summary>
        public static bool IsReservedSubdomain(string subdomain, IEnumerable<string> reserved)
        {
            foreach (var r in reserved)
            {
                if (string.Equals(r?.Trim(), subdomain, StringComparison.OrdinalIgnoreCase)) return true;
            }
            return false;
        }
    }
}
