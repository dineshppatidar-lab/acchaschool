namespace SchoolManagementApp.ApplicationCore.Common.Constants
{
    /// <summary>
    /// Standardized response codes for the application.
    /// Follows CorporateFleet's ResponseCode pattern.
    /// </summary>
    public static class ResponseCodes
    {
        // Success Codes
        public const string Success = "SUCCESS";
        public const string Created = "CREATED";
        public const string Updated = "UPDATED";
        public const string Deleted = "DELETED";

        // Client Error Codes
        public const string BadRequest = "BAD_REQUEST";
        public const string ValidationFailed = "VALIDATION_FAILED";
        public const string Unauthorized = "UNAUTHORIZED";
        public const string Forbidden = "FORBIDDEN";
        public const string NotFound = "NOT_FOUND";
        public const string Conflict = "CONFLICT";
        public const string UnprocessableEntity = "UNPROCESSABLE_ENTITY";

        // Server Error Codes
        public const string InternalServerError = "INTERNAL_SERVER_ERROR";
        public const string ServiceUnavailable = "SERVICE_UNAVAILABLE";
        public const string GatewayTimeout = "GATEWAY_TIMEOUT";

        // Business Logic Codes
        public const string DuplicateEntry = "DUPLICATE_ENTRY";
        public const string ForeignKeyViolation = "FOREIGN_KEY_VIOLATION";
        public const string InsufficientFunds = "INSUFFICIENT_FUNDS";
        public const string OperationNotAllowed = "OPERATION_NOT_ALLOWED";
    }
}
