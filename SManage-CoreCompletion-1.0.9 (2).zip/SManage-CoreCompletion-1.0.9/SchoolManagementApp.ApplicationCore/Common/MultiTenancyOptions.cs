namespace SchoolManagementApp.ApplicationCore.Common
{
    /// <summary>
    /// Platform-level heartbeat config that applies to everyone, unlike a tenant's own settings.
    ///
    ///  - <see cref="BaseDomain"/>: root domain every school lives under — the value schools
    ///    see in the subdomain field of the registration flow (e.g. greenfield.acchaschool.com).
    ///  - <see cref="ReservedSubdomains"/>: first labels a school must never claim (www/api/admin/login…),
    ///    enforced by TenantService on every Tenant.Domain write.
    /// </summary>
    public class MultiTenancyOptions
    {
        public const string SectionName = "MultiTenancy";

        public string? BaseDomain { get; set; }

        public List<string> ReservedSubdomains { get; set; } = new();
    }
}
