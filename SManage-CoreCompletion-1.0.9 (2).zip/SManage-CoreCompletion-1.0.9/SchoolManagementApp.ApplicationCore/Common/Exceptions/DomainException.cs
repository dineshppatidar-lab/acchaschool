namespace SchoolManagementApp.ApplicationCore.Common.Exceptions
{
    /// <summary>
    /// Base exception for domain-level errors.
    /// Follows CorporateFleet's exception handling pattern.
    /// </summary>
    public class DomainException : Exception
    {
        public string ErrorCode { get; }

        public DomainException(string message, string errorCode = "DOMAIN_ERROR")
            : base(message)
        {
            ErrorCode = errorCode;
        }

        public DomainException(string message, Exception innerException, string errorCode = "DOMAIN_ERROR")
            : base(message, innerException)
        {
            ErrorCode = errorCode;
        }
    }

    /// <summary>
    /// Thrown when a uniqueness rule is violated (e.g. a username or email that
    /// already exists in the tenant). Maps to HTTP 409 Conflict.
    /// </summary>
    public class DuplicateException : DomainException
    {
        public DuplicateException(string field, string value)
            : base($"A user with {field} '{value}' already exists.", "DUPLICATE")
        {
        }

        public DuplicateException(string message)
            : base(message, "DUPLICATE")
        {
        }
    }

    /// <summary>
    /// Thrown when input fails domain validation (missing fields, invalid
    /// values). Maps to HTTP 400 Bad Request.
    /// </summary>
    public class ValidationException : DomainException
    {
        public ValidationException(string message)
            : base(message, "VALIDATION")
        {
        }
    }
}
