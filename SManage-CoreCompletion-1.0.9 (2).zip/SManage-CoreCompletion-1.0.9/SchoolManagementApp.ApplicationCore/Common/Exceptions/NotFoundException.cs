namespace SchoolManagementApp.ApplicationCore.Common.Exceptions
{
    /// <summary>
    /// Exception thrown when a requested entity is not found.
    /// Follows CorporateFleet's exception handling pattern.
    /// </summary>
    public class NotFoundException : DomainException
    {
        public NotFoundException(string entityName, object key)
            : base($"{entityName} with key '{key}' was not found.", "NOT_FOUND")
        {
        }

        public NotFoundException(string entityName, string message)
            : base($"{entityName}: {message}", "NOT_FOUND")
        {
        }
    }
}
