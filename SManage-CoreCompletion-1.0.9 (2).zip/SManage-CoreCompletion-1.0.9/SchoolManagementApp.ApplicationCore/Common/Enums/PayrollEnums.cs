namespace SchoolManagementApp.ApplicationCore.Common.Enums
{
    public enum ComponentType
    {
        Allowance = 1,
        Deduction = 2
    }

    public enum PayslipStatus
    {
        Draft = 1,
        Approved = 2,
        Paid = 3,
        Cancelled = 4
    }
}
