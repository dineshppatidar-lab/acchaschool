
namespace SchoolManagementApp.ApplicationCore.Common.Enums
{
    public enum UserRole
    {
        [Description("Super Administrator")]
        SuperAdmin = 1,

        [Description("Administrator")]
        Administrator = 2,

        [Description("Principal")]
        Principal = 3,

        [Description("Vice Principal")]
        VicePrincipal = 4,

        [Description("Teacher")]
        Teacher = 5,

        [Description("Staff")]
        Staff = 6,

        [Description("Student")]
        Student = 7,

        [Description("Parent")]
        Parent = 8,

        [Description("Librarian")]
        Librarian = 9,

        [Description("Accountant")]
        Accountant = 10,

        [Description("Receptionist")]
        Receptionist = 11
    }
}
