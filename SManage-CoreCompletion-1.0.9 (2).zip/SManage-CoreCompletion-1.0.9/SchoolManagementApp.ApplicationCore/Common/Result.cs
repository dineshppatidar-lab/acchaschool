namespace SchoolManagementApp.ApplicationCore.Common
{
    /// <summary>
    /// Category of a failed service outcome — controllers map these to HTTP status
    /// codes without understanding the failure details.
    /// </summary>
    public enum ResultErrorType
    {
        NotFound,
        Validation,
        Conflict,
        Forbidden,
        Internal
    }

    /// <summary>
    /// Service-layer outcome (docs/critical-issues/09-controller-service-refactoring.md §3):
    /// services report success/failure explicitly instead of throwing or returning null,
    /// so controllers stay thin mappers (Result → HTTP status) and callers can branch
    /// without try/catch.
    /// </summary>
    public class Result
    {
        protected Result(bool isSuccess, string? error, ResultErrorType errorType)
        {
            IsSuccess = isSuccess;
            Error = error;
            ErrorType = errorType;
        }

        public bool IsSuccess { get; }
        public bool IsFailure => !IsSuccess;
        public string? Error { get; }
        public ResultErrorType ErrorType { get; }

        public static Result Success() => new(true, null, default);
        public static Result Failure(string error, ResultErrorType errorType = ResultErrorType.Internal) =>
            new(false, error, errorType);
    }

    public class Result<T> : Result
    {
        private readonly T? _value;

        private Result(bool isSuccess, T? value, string? error, ResultErrorType errorType)
            : base(isSuccess, error, errorType)
        {
            _value = value;
        }

        /// <summary>Unwrapped payload. Only valid when IsSuccess.</summary>
        public T Value => IsSuccess
            ? _value!
            : throw new InvalidOperationException("Cannot access Value on a failed Result.");

        public static Result<T> Success(T value) => new(true, value, null, default);
        public static new Result<T> Failure(string error, ResultErrorType errorType = ResultErrorType.Internal) =>
            new(false, default, error, errorType);
    }
}
