namespace SchoolManagementApp.ApplicationCore.Common.Models
{
    // SMS Service Models
    public class SmsDeliveryStatus
    {
        public string MessageId { get; set; } = string.Empty;
        public string Status { get; set; } = string.Empty; // Sent, Delivered, Failed, Pending
        public DateTime? DeliveredAt { get; set; }
        public string? FailureReason { get; set; }
    }

    // File Storage Service Models
    public class FileMetadata
    {
        public Guid Id { get; set; }
        public string OriginalFileName { get; set; } = string.Empty;
        public string StoredFileName { get; set; } = string.Empty;
        public string FilePath { get; set; } = string.Empty;
        public string? ThumbnailPath { get; set; }
        public long FileSize { get; set; }
        public string ContentType { get; set; } = string.Empty;
        public string Category { get; set; } = string.Empty;
        public int? UploadedBy { get; set; }
        public DateTime UploadedAt { get; set; }
        public string FileHash { get; set; } = string.Empty;
        public bool IsActive { get; set; } = true;
    }

    public class FileUploadResult
    {
        public bool IsSuccess { get; set; }
        public Guid FileId { get; set; }
        public string? FileName { get; set; }
        public string? FilePath { get; set; }
        public string? ThumbnailPath { get; set; }
        public long FileSize { get; set; }
        public string? ContentType { get; set; }
        public string? FileUrl { get; set; }
        public string? Message { get; set; }
        public string? ErrorMessage { get; set; }
        public List<FileUploadResult>? UploadResults { get; set; }
    }

    public class FileDownloadResult
    {
        public bool IsSuccess { get; set; }
        public byte[]? FileBytes { get; set; }
        public string? FileName { get; set; }
        public string? ContentType { get; set; }
        public long FileSize { get; set; }
        public string? ErrorMessage { get; set; }
    }

    public class StorageStats
    {
        public int TotalFiles { get; set; }
        public long TotalSizeBytes { get; set; }
        public Dictionary<string, CategoryStats> CategoryStats { get; set; } = new();
    }

    public class CategoryStats
    {
        public int FileCount { get; set; }
        public long TotalSizeBytes { get; set; }
    }

    // Payment Gateway Service Models
    public class PaymentRequest
    {
        public int StudentId { get; set; }
        public decimal Amount { get; set; }
        public string FeeType { get; set; } = string.Empty;
        public string AcademicYear { get; set; } = string.Empty;
        public string StudentName { get; set; } = string.Empty;
        public string StudentEmail { get; set; } = string.Empty;
        public string StudentPhone { get; set; } = string.Empty;
        public Dictionary<string, string> AdditionalInfo { get; set; } = new();
    }

    public class PaymentResponse
    {
        public bool IsSuccess { get; set; }
        public string OrderId { get; set; } = string.Empty;
        public decimal Amount { get; set; }
        public string Currency { get; set; } = string.Empty;
        public string KeyId { get; set; } = string.Empty;
        public int StudentId { get; set; }
        public string FeeType { get; set; } = string.Empty;
        public string CallbackUrl { get; set; } = string.Empty;
        public string Message { get; set; } = string.Empty;
        public string ErrorCode { get; set; } = string.Empty;
    }

    public class PaymentVerificationRequest
    {
        public string PaymentId { get; set; } = string.Empty;
        public string OrderId { get; set; } = string.Empty;
        public string Signature { get; set; } = string.Empty;
    }

    public class PaymentVerificationResult
    {
        public bool IsSuccess { get; set; }
        public string Status { get; set; } = string.Empty;
        public string PaymentId { get; set; } = string.Empty;
        public string OrderId { get; set; } = string.Empty;
        public decimal Amount { get; set; }
        public string Method { get; set; } = string.Empty;
        public DateTime TransactionDate { get; set; }
        public string Message { get; set; } = string.Empty;
    }

    public class RefundRequest
    {
        public string PaymentId { get; set; } = string.Empty;
        public decimal Amount { get; set; }
        public string Reason { get; set; } = string.Empty;
        public string RequestedBy { get; set; } = string.Empty;
        public int? StudentId { get; set; }
        public string? Speed { get; set; } = "normal"; // normal, optimum
    }

    public class RefundResponse
    {
        public bool IsSuccess { get; set; }
        public string RefundId { get; set; } = string.Empty;
        public string PaymentId { get; set; } = string.Empty;
        public decimal Amount { get; set; }
        public string Status { get; set; } = string.Empty;
        public string Message { get; set; } = string.Empty;
        public string ErrorCode { get; set; } = string.Empty;
    }

    public class PaymentStatusResult
    {
        public bool IsSuccess { get; set; }
        public string PaymentId { get; set; } = string.Empty;
        public string Status { get; set; } = string.Empty;
        public decimal Amount { get; set; }
        public string Method { get; set; } = string.Empty;
        public DateTime CreatedAt { get; set; }
        public string Message { get; set; } = string.Empty;
    }

    public class PaymentHistoryItem
    {
        public string PaymentId { get; set; } = string.Empty;
        public string OrderId { get; set; } = string.Empty;
        public decimal Amount { get; set; }
        public string Status { get; set; } = string.Empty;
        public string Method { get; set; } = string.Empty;
        public string FeeType { get; set; } = string.Empty;
        public DateTime TransactionDate { get; set; }
        public string Description { get; set; } = string.Empty;
    }

    // Backup Service Models
    public class BackupInfo
    {
        public Guid Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public BackupType Type { get; set; }
        public BackupStatus Status { get; set; }
        public string FilePath { get; set; } = string.Empty;
        public long SizeBytes { get; set; }
        public DateTime StartTime { get; set; }
        public DateTime? EndTime { get; set; }
        public string CreatedBy { get; set; } = string.Empty;
        public string? ErrorMessage { get; set; }
        public TimeSpan? Duration => EndTime - StartTime;
    }

    public class BackupResult
    {
        public bool IsSuccess { get; set; }
        public Guid BackupId { get; set; }
        public string? BackupPath { get; set; }
        public long SizeBytes { get; set; }
        public TimeSpan? Duration { get; set; }
        public string? Message { get; set; }
        public string? ErrorMessage { get; set; }
    }

    public class RestoreResult
    {
        public bool IsSuccess { get; set; }
        public Guid RestoreId { get; set; }
        public string? Message { get; set; }
        public string? ErrorMessage { get; set; }
        public List<string> RestoredComponents { get; set; } = new();
    }

    public class RestoreOptions
    {
        public bool RestoreDatabase { get; set; } = true;
        public bool RestoreFiles { get; set; } = true;
        public bool RestoreConfiguration { get; set; } = false;
        public bool BackupExisting { get; set; } = true;
        public bool ContinueOnError { get; set; } = false;
        public string? RestoreToPath { get; set; }
    }

    public class BackupValidationResult
    {
        public bool IsValid { get; set; }
        public List<string> ValidationIssues { get; set; } = new();
        public long BackupSize { get; set; }
        public string? ErrorMessage { get; set; }
    }

    // Backup Enums
    public enum BackupType
    {
        Full,
        Database,
        Files,
        Configuration
    }

    public enum BackupStatus
    {
        Scheduled,
        InProgress,
        Completed,
        Failed,
        Cancelled
    }
}
