namespace SchoolManagementApp.ApplicationCore.Common
{
    /// <summary>
    /// Ambient execution context for non-HTTP flows (background workers, webhooks).
    /// The Api TenantProvider reads this when there is no HTTP context, and the
    /// background worker sets it while processing each tenant, giving multi-tenant
    /// isolation without hardcoded TenantIds anywhere.
    ///
    /// ActorUserId/CorrelationId flow into audit records (AuditEntry.ActorUserId and
    /// AuditEntry.CorrelationId) so automated changes are attributable to the job or
    /// webhook that performed them instead of the anonymous "System"
    /// (docs/critical-issues/13-audit-trail-gaps.md).
    /// </summary>
    public static class AmbientTenantContext
    {
        private static readonly AsyncLocal<int?> _tenantId = new();
        private static readonly AsyncLocal<string?> _actorUserId = new();
        private static readonly AsyncLocal<string?> _correlationId = new();

        /// <summary>Non-zero when an ambient scope is active.</summary>
        public static int? TenantId => _tenantId.Value;

        /// <summary>Actor (job name, webhook identity, user id) for the current ambient scope.</summary>
        public static string? ActorUserId => _actorUserId.Value;

        /// <summary>Correlation id linking all audit rows of this execution.</summary>
        public static string? CorrelationId => _correlationId.Value;

        /// <summary>Begins a tenant scope. Disposing restores the previous values.</summary>
        public static IDisposable BeginScope(int tenantId, string? actorUserId = null, string? correlationId = null)
        {
            var previousTenant = _tenantId.Value;
            var previousActor = _actorUserId.Value;
            var previousCorrelation = _correlationId.Value;

            _tenantId.Value = tenantId;
            if (!string.IsNullOrEmpty(actorUserId)) _actorUserId.Value = actorUserId;
            if (!string.IsNullOrEmpty(correlationId)) _correlationId.Value = correlationId;

            return new Scope(previousTenant, previousActor, previousCorrelation);
        }

        /// <summary>Sets/overrides the actor within the current scope (e.g. per-job identification).</summary>
        public static void SetActor(string actorUserId, string? correlationId = null)
        {
            _actorUserId.Value = actorUserId;
            if (correlationId != null) _correlationId.Value = correlationId;
        }

        /// <summary>
        /// Sets the correlation id for the current async flow without touching the actor
        /// (used by the HTTP correlation middleware — a request seed, not an identity).
        /// </summary>
        public static void SetCorrelation(string correlationId)
        {
            _correlationId.Value = correlationId;
        }

        private sealed class Scope : IDisposable
        {
            private readonly int? _previousTenant;
            private readonly string? _previousActor;
            private readonly string? _previousCorrelation;

            public Scope(int? previousTenant, string? previousActor, string? previousCorrelation)
            {
                _previousTenant = previousTenant;
                _previousActor = previousActor;
                _previousCorrelation = previousCorrelation;
            }

            public void Dispose()
            {
                _tenantId.Value = _previousTenant;
                _actorUserId.Value = _previousActor;
                _correlationId.Value = _previousCorrelation;
            }
        }
    }
}
