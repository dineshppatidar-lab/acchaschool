using Microsoft.AspNetCore.Http;
using SchoolManagementApp.ApplicationCore.Entities;
using SchoolManagementApp.ApplicationCore._Interfaces;

namespace SchoolManagementApp.ApplicationCore.Common.Services
{
    public interface IAuditService
    {
        void Log(string action, string entity, string entityId, string? details = null);
    }

    public class AuditService : IAuditService
    {
        private readonly IAppDbContext _context;
        private readonly IHttpContextAccessor _httpContextAccessor;
        public AuditService(IAppDbContext context, IHttpContextAccessor httpContextAccessor)
        {
            _context = context;
            _httpContextAccessor = httpContextAccessor;
        }
        public void Log(string action, string entity, string entityId, string? details = null)
        {
            var user = _httpContextAccessor.HttpContext?.User?.Identity?.Name ?? "Anonymous";
            var ip = _httpContextAccessor.HttpContext?.Connection?.RemoteIpAddress?.ToString() ?? string.Empty;
            var log = new AuditLog
            {
                UserName = user,
                Action = action,
                Entity = entity,
                EntityId = entityId,
                Details = details ?? string.Empty,
                IpAddress = ip
            };
            _context.Set<AuditLog>().Add(log);
            _context.SaveChangesAsync().GetAwaiter().GetResult();
        }
    }
}
