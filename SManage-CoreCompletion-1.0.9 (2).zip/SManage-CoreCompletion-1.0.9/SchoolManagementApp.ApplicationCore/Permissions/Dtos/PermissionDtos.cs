using SchoolManagementApp.ApplicationCore._Entities;

namespace SchoolManagementApp.ApplicationCore.Permissions.Dtos
{
    // ──────────────────────────────────────────────────────
    // Permission admin DTOs (moved from PermissionController
    // as part of docs/critical-issues/09 — JSON wire shapes unchanged).
    // ──────────────────────────────────────────────────────

    public class RoleSummaryDto
    {
        public UserRole Role { get; set; }
        public string RoleName { get; set; } = string.Empty;
        public List<RolePermissionDto> RolePermissions { get; set; } = new();
        public List<MenuVisibilityDto> MenuVisibility { get; set; } = new();
        public List<ModulePermissionSummaryDto> ModulePermissions { get; set; } = new();
        public int TotalPermissions { get; set; }
        public int VisibleMenuItems { get; set; }
        public int TotalMenuItems { get; set; }
    }

    public class RolePermissionDto
    {
        public Permission Permission { get; set; }
        public string PermissionName { get; set; } = string.Empty;
        public bool CanRead { get; set; }
        public bool CanWrite { get; set; }
        public bool CanDelete { get; set; }
    }

    public class MenuVisibilityDto
    {
        public int MenuItemId { get; set; }
        public string Label { get; set; } = string.Empty;
        public string Route { get; set; } = string.Empty;
        public string Icon { get; set; } = string.Empty;
        public int? ParentId { get; set; }
        public string Category { get; set; } = string.Empty;
        public int DisplayOrder { get; set; }
        public string RequiredPermission { get; set; } = string.Empty;
        public bool IsVisible { get; set; }
        public bool HasExplicitOverride { get; set; }
        public bool PermissionAllows { get; set; }
    }

    public class ModulePermissionSummaryDto
    {
        public string ModuleName { get; set; } = string.Empty;
        public string Icon { get; set; } = string.Empty;
        public string Category { get; set; } = string.Empty;
        public List<RolePermissionDto> Permissions { get; set; } = new();
        public bool MenuVisible { get; set; }
        public bool HasAnyWrite { get; set; }
        public bool HasAnyDelete { get; set; }
    }

    public class UpdateRolePermissionRequest
    {
        public bool CanRead { get; set; }
        public bool CanWrite { get; set; }
        public bool CanDelete { get; set; }
    }

    public class GrantUserPermissionRequest
    {
        public Permission Permission { get; set; }
        public bool CanRead { get; set; }
        public bool CanWrite { get; set; }
        public bool CanDelete { get; set; }
    }

    public class RevokeUserPermissionRequest
    {
        public Permission Permission { get; set; }
    }

    public class ResetModuleRequest
    {
        public Permission[] Permissions { get; set; } = Array.Empty<Permission>();
    }

    public class BulkUpdatePermissionRequest
    {
        public Permission Permission { get; set; }
        public bool CanRead { get; set; }
        public bool CanWrite { get; set; }
        public bool CanDelete { get; set; }
    }
}
