using Microsoft.Extensions.Logging;
using SchoolManagementApp.ApplicationCore.Hostel.Interfaces;
using IHostelRepository = SchoolManagementApp.ApplicationCore.Hostel.Interfaces.IHostelRepository;

namespace SchoolManagementApp.ApplicationCore.Hostel.Services
{
    /// <summary>
    /// Service implementation for Hostel operations
    /// </summary>
    public class HostelService : IHostelAppService
    {
        private readonly IHostelRepository _hostelRepository;
        private readonly ILogger<HostelService> _logger;

        public HostelService(IHostelRepository hostelRepository, ILogger<HostelService> logger)
        {
            _hostelRepository = hostelRepository;
            _logger = logger;
        }

        public async Task<(IEnumerable<Entities.Hostel> Hostels, int Total)> GetHostelsAsync(
            int page, int pageSize, string sort, string order, string search)
        {
            return await _hostelRepository.GetHostelsAsync(page, pageSize, sort, order, search);
        }

        public async Task<Entities.Hostel?> GetHostelByIdAsync(int id)
        {
            return await _hostelRepository.GetHostelByIdAsync(id);
        }

        public async Task<Entities.Hostel> CreateHostelAsync(Entities.Hostel hostel)
        {
            return await _hostelRepository.CreateHostelAsync(hostel);
        }

        public async Task UpdateHostelAsync(Entities.Hostel hostel)
        {
            await _hostelRepository.UpdateHostelAsync(hostel);
        }

        public async Task DeleteHostelAsync(int id)
        {
            await _hostelRepository.DeleteHostelAsync(id);
        }
    }
}
