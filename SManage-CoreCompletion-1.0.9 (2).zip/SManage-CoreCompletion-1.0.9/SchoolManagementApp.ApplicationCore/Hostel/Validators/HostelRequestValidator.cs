using FluentValidation;
using SchoolManagementApp.ApplicationCore.Hostel.Dtos;

namespace SchoolManagementApp.ApplicationCore.Hostel.Validators
{
    public class HostelRequestValidator : AbstractValidator<HostelDto>
    {
        public HostelRequestValidator()
        {
            RuleFor(x => x.Name).NotEmpty().MaximumLength(200);
            RuleFor(x => x.Capacity).GreaterThan(0);
        }
    }
}
