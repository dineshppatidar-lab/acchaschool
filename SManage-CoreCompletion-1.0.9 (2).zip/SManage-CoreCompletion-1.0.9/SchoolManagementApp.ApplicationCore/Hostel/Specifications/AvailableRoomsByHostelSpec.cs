using Ardalis.Specification;
using SchoolManagementApp.ApplicationCore.Entities;

namespace SchoolManagementApp.ApplicationCore.Hostel.Specifications
{
    public class AvailableRoomsByHostelSpec : Specification<HostelRoom>
    {
        public AvailableRoomsByHostelSpec(int hostelId)
        {
            Query.Where(r => r.HostelId == hostelId && !r.IsOccupied)
                 .OrderBy(r => r.RoomNumber);
        }
    }
}
