using Ardalis.Specification;
using HostelEntity = SchoolManagementApp.ApplicationCore.Entities.Hostel;

namespace SchoolManagementApp.ApplicationCore.Hostel.Specifications
{
    /// <summary>
    /// Specification to filter hostels with available rooms.
    /// </summary>
    public class HostelsWithAvailableRoomsSpec : Specification<HostelEntity>
    {
        public HostelsWithAvailableRoomsSpec()
        {
            Query.Where(h => h.Rooms.Any(r => !r.IsOccupied))
                 .Include(h => h.Rooms)
                 .OrderBy(h => h.Name);
        }
    }
}
