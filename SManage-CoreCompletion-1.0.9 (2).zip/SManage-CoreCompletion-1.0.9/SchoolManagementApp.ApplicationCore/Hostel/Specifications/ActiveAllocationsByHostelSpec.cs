using Ardalis.Specification;
using SchoolManagementApp.ApplicationCore.Entities;

namespace SchoolManagementApp.ApplicationCore.Hostel.Specifications
{
    public class ActiveAllocationsByHostelSpec : Specification<HostelAllocation>
    {
        public ActiveAllocationsByHostelSpec(int hostelId)
        {
            Query.Where(a => a.HostelId == hostelId && a.IsActive)
                 .OrderBy(a => a.AllocationDate)
                 .Include(a => a.Student)
                 .Include(a => a.Room);
        }
    }
}
