using Entities = SchoolManagementApp.ApplicationCore.Entities;

namespace SchoolManagementApp.ApplicationCore.Hostel.Interfaces
{
    public interface IHostelRepository
    {
        Task<(IEnumerable<Entities.Hostel>, int)> GetHostelsAsync(int page, int pageSize, string sort, string order, string search);
        Task<Entities.Hostel> GetHostelByIdAsync(int id);
        Task<Entities.Hostel> CreateHostelAsync(Entities.Hostel hostel);
        Task UpdateHostelAsync(Entities.Hostel hostel);
        Task DeleteHostelAsync(int id);
    }
}
