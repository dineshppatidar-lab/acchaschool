namespace SchoolManagementApp.ApplicationCore.Hostel.Interfaces
{
    /// <summary>
    /// Service interface for Hostel operations
    /// Moved from Students/Interfaces/ per CorporateFleet module pattern.
    /// </summary>
    public interface IHostelAppService
    {
        // CRUD Operations
        Task<(IEnumerable<Entities.Hostel> Hostels, int Total)> GetHostelsAsync(
            int page, int pageSize, string sort, string order, string search);
        Task<Entities.Hostel?> GetHostelByIdAsync(int id);
        Task<Entities.Hostel> CreateHostelAsync(Entities.Hostel hostel);
        Task UpdateHostelAsync(Entities.Hostel hostel);
        Task DeleteHostelAsync(int id);
    }
}
