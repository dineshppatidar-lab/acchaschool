using HostelEntity = SchoolManagementApp.ApplicationCore.Entities.Hostel;

namespace SchoolManagementApp.ApplicationCore.Hostel.Interfaces
{
    /// <summary>
    /// Service interface for Hostel operations
    /// </summary>
    public interface IHostelService
    {
        // CRUD Operations
        Task<(IEnumerable<HostelEntity> Hostels, int Total)> GetHostelsAsync(
            int page, int pageSize, string sort, string order, string search);
        Task<HostelEntity?> GetHostelByIdAsync(int id);
        Task<HostelEntity> CreateHostelAsync(HostelEntity hostel);
        Task UpdateHostelAsync(HostelEntity hostel);
        Task DeleteHostelAsync(int id);
    }
}
