using AutoMapper;
using SchoolManagementApp.ApplicationCore.Entities;
using SchoolManagementApp.ApplicationCore.Hostel.Dtos;

namespace SchoolManagementApp.ApplicationCore.Hostel
{
    public class HostelObjectMapping : Profile
    {
        public HostelObjectMapping()
        {
            CreateMap<Entities.Hostel, HostelDto>().ReverseMap();
        }
    }
}
