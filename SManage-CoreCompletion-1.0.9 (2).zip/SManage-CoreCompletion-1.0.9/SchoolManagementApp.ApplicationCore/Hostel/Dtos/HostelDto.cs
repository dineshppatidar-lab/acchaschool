namespace SchoolManagementApp.ApplicationCore.Hostel.Dtos
{
    public class HostelDto
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public int Capacity { get; set; }
    }
}