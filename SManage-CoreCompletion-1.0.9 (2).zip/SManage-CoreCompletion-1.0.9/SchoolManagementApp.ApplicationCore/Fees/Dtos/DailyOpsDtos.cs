
namespace SchoolManagementApp.ApplicationCore.Fees.Dtos
{
    public class DailySummaryDto
    {
        public DateTime Date { get; set; }
        public int TotalStudents { get; set; }
        public int PresentStudents { get; set; }
        public int AbsentStudents { get; set; }
        public int StaffPresent { get; set; }
        public int StaffAbsent { get; set; }
        public int FeesDueToday { get; set; }
        public int FeesOverdue { get; set; }
        public int BusesRunning { get; set; }
        public int BusesOnTime { get; set; }
        public List<DailyAnnouncementDto> Announcements { get; set; } = new();
        public List<UpcomingEventDto> Events { get; set; } = new();
    }

    public class DailyAnnouncementDto
    {
        public int Id { get; set; }
        public string Title { get; set; } = string.Empty;
        public string Type { get; set; } = string.Empty;
        public string Priority { get; set; } = string.Empty;
        public DateTime CreatedOn { get; set; }
    }

    public class UpcomingEventDto
    {
        public int Id { get; set; }
        public string Title { get; set; } = string.Empty;
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string Location { get; set; } = string.Empty;
    }

    public class QuickMarkRequest
    {
        public int ClassId { get; set; }
        public int SectionId { get; set; }
        public DateTime Date { get; set; }
        public List<int> PresentStudentIds { get; set; } = new();
    }

    public class FeeReminderRequest
    {
        public List<int> StudentIds { get; set; } = new();
        public string Channel { get; set; } = "SMS";
        public string Message { get; set; } = string.Empty;
    }

    public class AttendanceHistoryDto
    {
        public DateTime Date { get; set; }
        public int StudentId { get; set; }
        public string StudentName { get; set; } = string.Empty;
        public string RollNumber { get; set; } = string.Empty;
        public int ClassId { get; set; }
        public string ClassName { get; set; } = string.Empty;
        public int SectionId { get; set; }
        public string SectionName { get; set; } = string.Empty;
        public bool IsPresent { get; set; }
        public string Remarks { get; set; } = string.Empty;
    }

    public class AttendanceHistoryResponseDto
    {
        public List<AttendanceHistoryDto> Records { get; set; } = new();
        public int TotalRecords { get; set; }
        public int PresentCount { get; set; }
        public int AbsentCount { get; set; }
        public decimal AttendancePercentage { get; set; }
    }

    public class PaymentProcessRequest
    {
        public int FeeInstallmentId { get; set; }
        public decimal AmountPaid { get; set; }
        public decimal? LateFeeAmount { get; set; }
        public decimal? DiscountAmount { get; set; }
        public string? PaymentMethod { get; set; }
        public string? TransactionId { get; set; }
        public string? Remarks { get; set; }
    }

    public class FinancialSummaryDto
    {
        public decimal TotalRevenue { get; set; }
        public decimal TotalExpenses { get; set; }
        public decimal NetIncome { get; set; }
        public decimal ProfitMargin { get; set; }
    }

    public class CreateInstallmentRequest
    {
        public string Name { get; set; } = string.Empty;
        public decimal Amount { get; set; }
        public DateTime DueDate { get; set; }
        public decimal? LateFee { get; set; }
        public int GracePeriodDays { get; set; }
    }

    public class ProcessPaymentRequest
    {
        public int StudentId { get; set; }
        public string StudentName { get; set; } = string.Empty;
        public string StudentEmail { get; set; } = string.Empty;
        public int FeeInstallmentId { get; set; }
        public string FeeType { get; set; } = string.Empty;
        public decimal Amount { get; set; }
        public decimal AmountPaid { get; set; }
        public decimal? LateFeeAmount { get; set; }
        public decimal? DiscountAmount { get; set; }
        public PaymentMethodType PaymentMethod { get; set; }
        public string? TransactionId { get; set; }
        public string? Remarks { get; set; }
    }

    public class CreateScholarshipRequest
    {
        public string Name { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public ScholarshipType Type { get; set; }
        public decimal Amount { get; set; }
        public bool IsPercentage { get; set; }
        public string Criteria { get; set; } = string.Empty;
        public DateTime ApplicationStartDate { get; set; }
        public DateTime ApplicationEndDate { get; set; }
        public int MaxBeneficiaries { get; set; }
    }

    public class ApplyScholarshipRequest
    {
        public int StudentId { get; set; }
        public string ApplicationData { get; set; } = string.Empty;
        public string DocumentsPath { get; set; } = string.Empty;
        public string Remarks { get; set; } = string.Empty;
    }

    public class CreateExpenseRequest
    {
        public string Title { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public ExpenseCategory Category { get; set; }
        public decimal Amount { get; set; }
        public DateTime ExpenseDate { get; set; }
        public string VoucherNumber { get; set; } = string.Empty;
        public string VendorName { get; set; } = string.Empty;
        public string ReceiptPath { get; set; } = string.Empty;
    }

    public class ApproveExpenseRequest
    {
        public string Remarks { get; set; } = string.Empty;
    }

    public class CreateBudgetRequest
    {
        public string Name { get; set; } = string.Empty;
        public int AcademicYearId { get; set; }
        public ExpenseCategory Category { get; set; }
        public decimal AllocatedAmount { get; set; }
    }

    public class AssignFeeStructureRequest
    {
        public int FeeStructureId { get; set; }
        public string? Remarks { get; set; }
    }

    public class OutstandingFeesDto
    {
        public int StudentId { get; set; }
        public bool HasAssignedFees { get; set; }
        public decimal TotalFees { get; set; }
        public decimal PaidAmount { get; set; }
        public decimal OutstandingAmount { get; set; }
        public List<DueInstallmentDto> DueInstallments { get; set; } = new();
    }

    public class DueInstallmentDto
    {
        public int InstallmentId { get; set; }
        public string Name { get; set; } = string.Empty;
        public decimal Amount { get; set; }
        public decimal PaidAmount { get; set; } = 0;
        public DateTime DueDate { get; set; }
        public string Status { get; set; } = "Pending";
        public int DaysOverdue { get; set; }
    }

    public class FeeInstallmentDto
    {
        public int Id { get; set; }
        public int InstallmentId { get; set; }
        public string Name { get; set; } = string.Empty;
        public decimal Amount { get; set; }
        public decimal DiscountApplied { get; set; }
        public decimal AdjustedAmount { get; set; }
        public DateTime DueDate { get; set; }
        public decimal LateFee { get; set; }
        public bool IsActive { get; set; }
        public int GracePeriodDays { get; set; }
        public decimal Paid { get; set; }
        public decimal Balance { get; set; }
        public string Status { get; set; } = "pending";
    }
}
