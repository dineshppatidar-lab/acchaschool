using SchoolManagementApp.ApplicationCore.Entities;

namespace SchoolManagementApp.ApplicationCore.Fees.Dtos
{
    /// <summary>
    /// DTOs for Advanced Finance Service operations.
    /// Canonical DTOs (CreateWaiverRequest, CreateDiscountRequest, etc.) are in FeeDto.cs.
    /// This file contains additional DTOs specific to the advanced finance workflow.
    /// </summary>

    public class InstallmentDetailDto
    {
        public int InstallmentId { get; set; }
        public string InstallmentName { get; set; } = "";
        public decimal BaseAmount { get; set; }
        public decimal DiscountApplied { get; set; }
        public decimal FinalAmount { get; set; }
        public DateTime DueDate { get; set; }
        public decimal PaidAmount { get; set; }
        public decimal Outstanding { get; set; }
        public bool IsWaived { get; set; }
    }

    public class CustomAllocationDto
    {
        public int StudentId { get; set; }
        public int FeeInstallmentId { get; set; }
        public decimal AllocatedAmount { get; set; }
    }

    public class AllocationResultDto
    {
        public int StudentId { get; set; }
        public string StudentName { get; set; } = "";
        public int FeeInstallmentId { get; set; }
        public string InstallmentName { get; set; } = "";
        public decimal AllocatedAmount { get; set; }
        public decimal DiscountApplied { get; set; }
        public decimal AmountApplied { get; set; }
        public decimal ActualAmountApplied { get; set; }
        public int? CreatedFeePaymentId { get; set; }
        public string Status { get; set; } = "Success";
    }

    public class FamilyMemberFeeDto
    {
        public int StudentId { get; set; }
        public string StudentName { get; set; } = "";
        public string Relationship { get; set; } = "";
        public decimal BaseFees { get; set; }
        public decimal AfterAdjustments { get; set; }
        public decimal Paid { get; set; }
        public decimal Outstanding { get; set; }
        public bool HasWaiver { get; set; }
        public decimal TotalDiscount { get; set; }
    }

    public class GroupPaymentHistoryDto
    {
        public int GroupPaymentId { get; set; }
        public string ReceiptNumber { get; set; } = "";
        public DateTime PaymentDate { get; set; }
        public decimal TransactionAmount { get; set; }
        public int AllocationCount { get; set; }
        public string AllocationStrategy { get; set; } = "";
        public PaymentMethodType PaymentMethod { get; set; }
    }

    public class ApproveAdjustmentRequest
    {
        public int AdjustmentId { get; set; }
        public string ApprovedBy { get; set; } = "";
        public string ApprovalRemarks { get; set; } = "";
        public bool IsApproved { get; set; } = true;
    }

    public class RevokeAdjustmentRequest
    {
        public int AdjustmentId { get; set; }
        public string RevokedBy { get; set; } = "";
        public string RevocationReason { get; set; } = "";
    }

    /// <summary>
    /// Overdue-installment row returned by IFeeInstallmentRepository.GetOverdueInstallmentRowsAsync
    /// (join of FeeInstallment → StudentFeeAssignment → Student → Class).
    /// </summary>
    public class DefaulterRowDto
    {
        public int InstallmentId { get; set; }
        public string InstallmentName { get; set; } = string.Empty;
        public decimal Amount { get; set; }
        public decimal? LateFee { get; set; }
        public DateTime DueDate { get; set; }
        public int StudentId { get; set; }
        public string StudentName { get; set; } = string.Empty;
        public string RollNumber { get; set; } = string.Empty;
        public string ClassName { get; set; } = string.Empty;
    }

    /// <summary>
    /// Due-reminder target returned by IFeeNotificationLogRepository.GetDueReminderTargetsAsync
    /// (join of FeeInstallment → StudentFeeAssignment → Student).
    /// </summary>
    public class DueReminderTargetDto
    {
        public int InstallmentId { get; set; }
        public string InstallmentName { get; set; } = string.Empty;
        public decimal Amount { get; set; }
        public DateTime DueDate { get; set; }
        public int StudentId { get; set; }
        public string StudentEmail { get; set; } = string.Empty;
    }
}
