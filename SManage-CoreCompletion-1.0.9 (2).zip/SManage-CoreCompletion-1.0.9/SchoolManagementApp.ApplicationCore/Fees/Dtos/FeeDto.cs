namespace SchoolManagementApp.ApplicationCore.Fees.Dtos
{
    /// <summary>
    /// DTO for Fee entity — matches Entities.Fee structure.
    /// </summary>
    public class FeeDto
    {
        public int Id { get; set; }
        public int StudentId { get; set; }
        public string StudentName { get; set; } = string.Empty;
        public string FeeType { get; set; } = string.Empty;
        public decimal Amount { get; set; }
        public decimal AmountPaid { get; set; }
        public decimal OutstandingAmount => Amount - AmountPaid;
        public DateTime DueDate { get; set; }
        public string Status { get; set; } = string.Empty;
        public int TenantId { get; set; }
    }

    /// <summary>
    /// DTO for PaymentMethod entity.
    /// </summary>
    public class PaymentMethodDto
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public bool IsActive { get; set; }
    }

    /// <summary>
    /// DTO for creating a waiver request.
    /// </summary>
    public class CreateWaiverRequest
    {
        public int StudentId { get; set; }
        public int AcademicYearId { get; set; }
        public string? WaiverCategory { get; set; }
        public DateTime EffectiveDate { get; set; }
        public DateTime? ExpiryDate { get; set; }
        public string? ApprovedBy { get; set; }
        public string? Remarks { get; set; }
        public int SpecificInstallmentId { get; set; }
    }

    /// <summary>
    /// DTO for creating a discount request.
    /// </summary>
    public class CreateDiscountRequest
    {
        public int StudentId { get; set; }
        public int AcademicYearId { get; set; }
        public bool IsPercentage { get; set; }
        public decimal DiscountValue { get; set; }
        public decimal? MaximumCap { get; set; }
        public DateTime EffectiveDate { get; set; }
        public DateTime? ExpiryDate { get; set; }
        public string? CreatedBy { get; set; }
        public string? Remarks { get; set; }
        public int SpecificInstallmentId { get; set; }
    }

    /// <summary>
    /// DTO for StudentFeeAdjustment.
    /// </summary>
    public class StudentFeeAdjustmentDto
    {
        public int Id { get; set; }
        public int StudentId { get; set; }
        // Resolved student display name (from the Student navigation) so list pages
        // don't have to make a second lookup per row.
        public string StudentName { get; set; } = string.Empty;
        public int AcademicYearId { get; set; }
        public FeeAdjustmentType AdjustmentType { get; set; }
        public bool IsPercentage { get; set; }
        public decimal? DiscountPercentage { get; set; }
        public decimal? DiscountAmount { get; set; }
        public decimal? MaximumCap { get; set; }
        public DateTime EffectiveDate { get; set; }
        public DateTime? ExpiryDate { get; set; }
        public bool IsFullWaiver { get; set; }
        public string WaiverCategory { get; set; } = string.Empty;
        public FeeAdjustmentStatus Status { get; set; }
        public string? ApprovedBy { get; set; }
        public DateTime? ApprovedDate { get; set; }
        public string ApprovalRemarks { get; set; } = string.Empty;
        public string? Remarks { get; set; }
        public int? SpecificInstallmentId { get; set; }
    }

    /// <summary>
    /// DTO for final student fee calculation.
    /// </summary>
    public class StudentFinalFeeDto
    {
        public int StudentId { get; set; }
        public string StudentName { get; set; } = string.Empty;
        public int AcademicYearId { get; set; }
        public decimal BaseFeeAmount { get; set; }
        public StudentFeeAdjustmentDto? ActiveWaiver { get; set; }
        public List<StudentFeeAdjustmentDto> ActiveDiscounts { get; set; } = new();
        public decimal TotalDiscountAmount { get; set; }
        public decimal FinalFeeAmount { get; set; }
        public string? AdjustmentSummary { get; set; }
        public List<InstallmentDetailDto> Installments { get; set; } = new();
    }

    // NOTE: InstallmentDetailDto is defined in AdvancedFeesDTOs.cs (canonical version)
    // Use that version instead of this one

    // NOTE: FeeInstallmentDto is defined in DailyOpsDtos.cs (canonical version)
    // Use that version instead of this one

    // NOTE: OutstandingFeesDto is defined in DailyOpsDtos.cs (canonical version)
    // Use that version instead of this one

    // NOTE: FinancialSummaryDto is defined in DailyOpsDtos.cs (canonical version)
    // Use that version instead of this one

    public class FeeCollectionByType
    {
        public string FeeType { get; set; } = string.Empty;
        public decimal Amount { get; set; }
        public int Count { get; set; }
    }

    /// <summary>
    /// DTO for initiating a group payment.
    /// </summary>
    public class InitiateGroupPaymentRequest
    {
        public int FamilyGroupId { get; set; }
        public int AcademicYearId { get; set; }
        public List<int> StudentIds { get; set; } = new();
        public string PaymentGroupName { get; set; } = string.Empty;
        public PaymentAllocationStrategy AllocationStrategy { get; set; } = PaymentAllocationStrategy.Proportional;
    }

    /// <summary>
    /// DTO for processing a group payment.
    /// </summary>
    public class ProcessGroupPaymentRequest
    {
        public int GroupPaymentId { get; set; }
        public int FamilyGroupId { get; set; }
        public int AcademicYearId { get; set; }
        public decimal TotalAmount { get; set; }
        public decimal TotalAmountPaid { get; set; }
        // PaymentMethodType enum (not string): the frontend sends the numeric enum value
        // (e.g. 1 = Cash). JsonStringEnumConverter binds both numbers and names; a plain
        // string property caused a fatal 400 model-binding error on numeric input.
        public PaymentMethodType PaymentMethod { get; set; } = PaymentMethodType.Cash;
        public int ProcessedByStaffId { get; set; }
        public string? TransactionId { get; set; }
        public string? Remarks { get; set; }
        public List<GroupPaymentAllocationRequest> Allocations { get; set; } = new();
        public List<CustomAllocationRequest> CustomAllocations { get; set; } = new();
    }

    public class CustomAllocationRequest
    {
        public int StudentId { get; set; }
        public int FeeInstallmentId { get; set; }
        public decimal AllocatedAmount { get; set; }
    }

    public class GroupPaymentAllocationRequest
    {
        public int StudentId { get; set; }
        public decimal Amount { get; set; }
        public int? FeePaymentId { get; set; }
    }

    /// <summary>
    /// Result of processing a group payment.
    /// </summary>
    public class GroupPaymentProcessResult
    {
        public bool Success { get; set; }
        public int GroupPaymentId { get; set; }
        public string Message { get; set; } = string.Empty;
        public decimal TotalApplied { get; set; }
        public List<PaymentAllocationResult> AllocationResults { get; set; } = new();
    }

    public class PaymentAllocationResult
    {
        public int StudentId { get; set; }
        public decimal AmountAllocated { get; set; }
        public bool Success { get; set; }
        public string? Error { get; set; }
    }

    /// <summary>
    /// DTO for family payment summary.
    /// </summary>
    public class FamilyPaymentSummaryDto
    {
        public int FamilyGroupId { get; set; }
        public string FamilyGroupName { get; set; } = string.Empty;
        public List<StudentFeeSummary> Students { get; set; } = new();
        public decimal TotalFamilyFee { get; set; }
        public decimal TotalFamilyPaid { get; set; }
        public decimal TotalFamilyOutstanding { get; set; }
    }

    public class StudentFeeSummary
    {
        public int StudentId { get; set; }
        public string StudentName { get; set; } = string.Empty;
        public decimal TotalFee { get; set; }
        public decimal AmountPaid { get; set; }
        public decimal OutstandingAmount { get; set; }
        /// <summary>Active waiver/discount total applied to this student's installments.</summary>
        public decimal DiscountAmount { get; set; }
    }

    /// <summary>
    /// DTO for group payment receipt.
    /// </summary>
    public class GroupPaymentReceiptDto
    {
        public int GroupPaymentId { get; set; }
        public string ReceiptNumber { get; set; } = string.Empty;
        public decimal TotalAmount { get; set; }
        public decimal TotalAmountPaid { get; set; }
        public DateTime PaymentDate { get; set; }
        public string PaymentMethod { get; set; } = string.Empty;
        public string TransactionId { get; set; } = string.Empty;
        public int? ProcessedByStaffId { get; set; }
        public string ProcessedByStaffName { get; set; } = string.Empty;
        public string Remarks { get; set; } = string.Empty;
        public List<AllocationResultDto> Allocations { get; set; } = new();
        public List<StudentFeeSummary> StudentAllocations { get; set; } = new();
    }

    /// <summary>
    /// DTO for group payment allocation receipt.
    /// </summary>
    public class GroupPaymentAllocationReceiptDto
    {
        public int StudentId { get; set; }
        public string StudentName { get; set; } = string.Empty;
        public int FeeInstallmentId { get; set; }
        public string InstallmentName { get; set; } = string.Empty;
        public decimal AllocatedAmount { get; set; }
        public decimal ActualAmountApplied { get; set; }
        public decimal? DiscountApplied { get; set; }
        public int? CreatedFeePaymentId { get; set; }
    }
}
