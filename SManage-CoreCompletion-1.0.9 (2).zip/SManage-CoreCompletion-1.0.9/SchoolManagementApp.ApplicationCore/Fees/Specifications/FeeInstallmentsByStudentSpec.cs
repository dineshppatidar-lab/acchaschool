using Ardalis.Specification;
using SchoolManagementApp.ApplicationCore.Entities;

namespace SchoolManagementApp.ApplicationCore.Fees.Specifications
{
    public class FeeInstallmentsByStudentSpec : Specification<FeeInstallment>
    {
        public FeeInstallmentsByStudentSpec(int studentFeeAssignmentId)
        {
            Query.Where(fi => fi.StudentFeeAssignmentId == studentFeeAssignmentId)
                 .OrderBy(fi => fi.DueDate);
        }
    }
}
