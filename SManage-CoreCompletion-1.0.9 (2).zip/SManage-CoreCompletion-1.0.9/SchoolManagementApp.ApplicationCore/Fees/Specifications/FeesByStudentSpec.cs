using Ardalis.Specification;
using SchoolManagementApp.ApplicationCore.Entities;

namespace SchoolManagementApp.ApplicationCore.Fees.Specifications
{
    /// <summary>
    /// Specification to filter fees by student.
    /// </summary>
    public class FeesByStudentSpec : Specification<Fee>
    {
        public FeesByStudentSpec(int studentId)
        {
            Query.Where(f => f.StudentId == studentId)
                 .OrderByDescending(f => f.DueDate)
                 .Include(f => f.Student);
        }
    }
}
