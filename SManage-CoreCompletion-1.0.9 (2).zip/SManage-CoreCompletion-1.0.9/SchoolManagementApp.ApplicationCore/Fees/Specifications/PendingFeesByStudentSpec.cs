using Ardalis.Specification;
using SchoolManagementApp.ApplicationCore.Entities;

namespace SchoolManagementApp.ApplicationCore.Fees.Specifications
{
    public class PendingFeesByStudentSpec : Specification<Fee>
    {
        public PendingFeesByStudentSpec(int studentId)
        {
            Query.Where(f => f.StudentId == studentId && f.Status != "Paid")
                 .OrderBy(f => f.DueDate)
                 .Include(f => f.Payments);
        }
    }
}
