using SchoolManagementApp.ApplicationCore.Fees.Dtos;
using SchoolManagementApp.ApplicationCore.Common.Models;
using SchoolManagementApp.ApplicationCore.Setup.Dtos;
using SchoolManagementApp.ApplicationCore.Setup.Interfaces;
using SchoolManagementApp.ApplicationCore.Entities;
using SchoolManagementApp.ApplicationCore.Common;
using SchoolManagementApp.ApplicationCore.Communication.Interfaces;
using SchoolManagementApp.ApplicationCore.Communication.WhatsApp.Interfaces;
using SchoolManagementApp.ApplicationCore.Interfaces;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using SchoolManagementApp.ApplicationCore.Students.Interfaces;
using SchoolManagementApp.ApplicationCore.Fees.Interfaces;

namespace SchoolManagementApp.ApplicationCore.Fees.Services
{
    /// <summary>
    /// Advanced Fee Calculation Service
    /// 
    /// KEY RULES:
    /// 1. PRIORITY: Full Waiver (100%) > Discounts > Base Fee
    /// 2. Base fee structure is NEVER modified
    /// 3. All adjustments are non-destructive and reversible
    /// 4. Calculations are performed on-demand (no storage of calculated amounts)
    /// 5. Supports dynamic application of multiple discounts
    /// </summary>
    public class AdvancedFeeCalculationService : Communication.Interfaces.IAdvancedFeeCalculationService
    {
        private readonly IStudentFeeAssignmentRepository _studentFeeAssignmentRepository;
        private readonly IFeeStructureRepository _feeStructureRepository;
        private readonly IFeeInstallmentRepository _feeInstallmentRepository;
        private readonly IFeePaymentRepository _feePaymentRepository;
        private readonly IStudentFeeAdjustmentRepository _feeAdjustmentRepository;
        private readonly IGroupPaymentRepository _groupPaymentRepository;
        private readonly IGroupPaymentAllocationRepository _groupPaymentAllocationRepository;
        private readonly IStudentRepository _studentRepository;
        private readonly IFinanceAuditLogRepository _auditLogRepository;
        /// <summary>Optional: enqueues PaymentReceived receipts per allocation. Null-safe DI default.</summary>
        private readonly IWhatsAppService? _whatsAppService;
        private readonly Microsoft.Extensions.Logging.ILogger<AdvancedFeeCalculationService>? _logger;

        public AdvancedFeeCalculationService(
            IStudentFeeAssignmentRepository studentFeeAssignmentRepository,
            IFeeStructureRepository feeStructureRepository,
            IFeeInstallmentRepository feeInstallmentRepository,
            IFeePaymentRepository feePaymentRepository,
            IStudentFeeAdjustmentRepository feeAdjustmentRepository,
            IGroupPaymentRepository groupPaymentRepository,
            IGroupPaymentAllocationRepository groupPaymentAllocationRepository,
            IStudentRepository studentRepository,
            IFinanceAuditLogRepository auditLogRepository,
            IWhatsAppService? whatsAppService = null,
            Microsoft.Extensions.Logging.ILogger<AdvancedFeeCalculationService>? logger = null)
        {
            _whatsAppService = whatsAppService;
            _logger = logger;
            _studentFeeAssignmentRepository = studentFeeAssignmentRepository;
            _feeStructureRepository = feeStructureRepository;
            _feeInstallmentRepository = feeInstallmentRepository;
            _feePaymentRepository = feePaymentRepository;
            _feeAdjustmentRepository = feeAdjustmentRepository;
            _groupPaymentRepository = groupPaymentRepository;
            _groupPaymentAllocationRepository = groupPaymentAllocationRepository;
            _studentRepository = studentRepository;
            _auditLogRepository = auditLogRepository;
        }

        // ==================== CORE CALCULATION METHODS ====================

        public async Task<StudentFinalFeeDto> CalculateFinalStudentFeesAsync(int studentId, int academicYearId)
        {
            var student = await _studentRepository.GetByIdAsync(studentId);
            if (student == null)
                throw new InvalidOperationException($"Student {studentId} not found");

            var assignment = await _studentFeeAssignmentRepository.GetAssignmentsByStudentAndYearAsync(studentId, academicYearId);
            if (assignment == null)
            {
                return new StudentFinalFeeDto { 
                    StudentId = studentId, StudentName = student.FirstName + " " + student.LastName, 
                    AcademicYearId = academicYearId, Installments = new() 
                };
            }

            var feeStructure = assignment.FeeStructure;
            var baseFeeAmount = CalculateBaseFeeAmount(feeStructure);

            // Check for full waiver
            var activeWaiver = await _feeAdjustmentRepository.GetActiveWaiverAsync(studentId, academicYearId);
            if (activeWaiver != null && (activeWaiver.SpecificInstallmentId == null || activeWaiver.SpecificInstallmentId == 0))
            {
                return new StudentFinalFeeDto
                {
                    StudentId = studentId,
                    StudentName = student.FirstName + " " + student.LastName,
                    AcademicYearId = academicYearId,
                    BaseFeeAmount = baseFeeAmount,
                    ActiveWaiver = MapToAdjustmentDto(activeWaiver),
                    TotalDiscountAmount = baseFeeAmount,
                    FinalFeeAmount = 0m,
                    AdjustmentSummary = "100% Academic Year Waiver applied",
                    Installments = await CalculateWaivedInstallmentsAsync(feeStructure, studentId)
                };
            }

            // Calculate per-installment details
            var activeDiscounts = await _feeAdjustmentRepository.GetActiveDiscountsAsync(studentId, academicYearId);
            var installments = await CalculateInstallmentDetailsAsync(feeStructure, studentId, academicYearId, activeDiscounts.ToList());

            var finalFeeAmount = installments.Sum(i => i.FinalAmount);
            var totalDiscountAmount = baseFeeAmount - finalFeeAmount;

            return new StudentFinalFeeDto
            {
                StudentId = studentId,
                StudentName = student.FirstName + " " + student.LastName,
                AcademicYearId = academicYearId,
                BaseFeeAmount = baseFeeAmount,
                ActiveDiscounts = activeDiscounts.Select(MapToAdjustmentDto).ToList(),
                TotalDiscountAmount = totalDiscountAmount,
                FinalFeeAmount = finalFeeAmount,
                Installments = installments,
                AdjustmentSummary = totalDiscountAmount > 0 ? $"Aggregated discounts: ₹{totalDiscountAmount:F2}" : "No discounts applied"
            };
        }

        public async Task<decimal> CalculateInstallmentAmountAfterAdjustmentsAsync(int studentId, int installmentId)
        {
            var installment = await _feeInstallmentRepository.GetByIdAsync(installmentId);
            if (installment == null) return 0;

            // Ensure FeeStructure navigation is available. Generic GetById may not include navigation properties.
            int academicYearId;
            if (installment.FeeStructure != null)
            {
                academicYearId = installment.FeeStructure.AcademicYearId;
            }
            else
            {
                var fs = await _feeStructureRepository.GetByIdAsync(installment.FeeStructureId);
                academicYearId = fs != null ? fs.AcademicYearId : 0;
            }

            // 1. Check Waiver
            var waiver = await _feeAdjustmentRepository.GetActiveWaiverAsync(studentId, academicYearId);
            if (waiver != null && (waiver.SpecificInstallmentId == null || waiver.SpecificInstallmentId == 0 || waiver.SpecificInstallmentId == installmentId))
                return 0m;

            // 2. Apply Discounts
            var discounts = await _feeAdjustmentRepository.GetActiveDiscountsAsync(studentId, academicYearId);
            decimal totalDiscount = 0;
            foreach (var d in discounts.Where(d => d.SpecificInstallmentId == null || d.SpecificInstallmentId == 0 || d.SpecificInstallmentId == installmentId))
            {
                decimal amt = d.IsPercentage ? (installment.Amount * (d.DiscountPercentage ?? 0)) / 100m : (d.DiscountAmount ?? 0);
                if (d.MaximumCap.HasValue) amt = Math.Min(amt, d.MaximumCap.Value);
                totalDiscount += amt;
            }

            return Math.Max(0, installment.Amount - totalDiscount);
        }

        public async Task<decimal> CalculateOutstandingBalanceAsync(int studentId, int academicYearId)
        {
            var finalFees = await CalculateFinalStudentFeesAsync(studentId, academicYearId);
            return finalFees.Installments.Sum(i => i.Outstanding);
        }

        // ==================== WAIVER & DISCOUNT MANAGEMENT ====================

        public async Task<StudentFeeAdjustment> CreateOrUpdateWaiverAsync(CreateWaiverRequest request)
        {
            var existing = await _feeAdjustmentRepository.GetActiveWaiverAsync(request.StudentId, request.AcademicYearId);
            if (existing != null)
            {
                existing.WaiverCategory = request.WaiverCategory;
                existing.Remarks = request.Remarks;
                existing.ApprovedBy = request.ApprovedBy;
                existing.ApprovedDate = DateTime.UtcNow;
                await _feeAdjustmentRepository.UpdateAsync(existing);
                return existing;
            }

            return await _feeAdjustmentRepository.AddAsync(new StudentFeeAdjustment {
                StudentId = request.StudentId, AcademicYearId = request.AcademicYearId, AdjustmentType = FeeAdjustmentType.Waiver,
                IsFullWaiver = true, WaiverCategory = request.WaiverCategory, EffectiveDate = request.EffectiveDate,
                ExpiryDate = request.ExpiryDate, SpecificInstallmentId = request.SpecificInstallmentId == 0 ? null : request.SpecificInstallmentId,
                Status = FeeAdjustmentStatus.Active, Remarks = request.Remarks, ApprovedBy = request.ApprovedBy.ToString(),
                ApprovedDate = DateTime.UtcNow
            });
        }

        public async Task<StudentFeeAdjustment> CreateOrUpdateDiscountAsync(CreateDiscountRequest request)
        {
            return await _feeAdjustmentRepository.AddAsync(new StudentFeeAdjustment {
                StudentId = request.StudentId, AcademicYearId = request.AcademicYearId, AdjustmentType = FeeAdjustmentType.Discount,
                IsPercentage = request.IsPercentage, DiscountPercentage = request.IsPercentage ? request.DiscountValue : null,
                DiscountAmount = !request.IsPercentage ? request.DiscountValue : null, MaximumCap = request.MaximumCap,
                EffectiveDate = request.EffectiveDate, ExpiryDate = request.ExpiryDate,
                SpecificInstallmentId = request.SpecificInstallmentId == 0 ? null : request.SpecificInstallmentId,
                Status = FeeAdjustmentStatus.Active, Remarks = request.Remarks, CreatedBy = request.CreatedBy.ToString()
            });
        }

        public async Task<bool> RevokeAdjustmentAsync(int adjustmentId)
        {
            var adj = await _feeAdjustmentRepository.GetByIdAsync(adjustmentId);
            if (adj == null) return false;
            adj.Status = FeeAdjustmentStatus.Inactive;
            await _feeAdjustmentRepository.UpdateAsync(adj);
            return true;
        }

        public async Task<IEnumerable<StudentFeeAdjustment>> GetStudentAdjustmentsAsync(int studentId, int academicYearId)
        {
            return await _feeAdjustmentRepository.GetByStudentAsync(studentId, academicYearId);
        }

        // ==================== GROUP PAYMENTS ====================

        public async Task<GroupPayment> InitiateGroupPaymentAsync(InitiateGroupPaymentRequest request)
        {
            return await _groupPaymentRepository.AddAsync(new GroupPayment {
                FamilyGroupId = request.FamilyGroupId, PaymentGroupName = request.PaymentGroupName,
                AllocationStrategy = request.AllocationStrategy, Status = GroupPaymentStatus.Pending
            });
        }

        public async Task<GroupPaymentProcessResult> ProcessGroupPaymentAsync(ProcessGroupPaymentRequest request)
        {
            var gp = await _groupPaymentRepository.GetByIdAsync(request.GroupPaymentId);
            if (gp == null) throw new Exception("Group payment not found");

            var result = new GroupPaymentProcessResult { GroupPaymentId = request.GroupPaymentId, TotalApplied = request.TotalAmountPaid, AllocationResults = new() };
            var allocations = await _groupPaymentAllocationRepository.GetByGroupPaymentAsync(request.GroupPaymentId);

            // If no allocations exist in DB but the client sent custom allocations, persist them first
            if ((allocations == null || !allocations.Any()) && request.CustomAllocations != null && request.CustomAllocations.Any())
            {
                foreach (var ca in request.CustomAllocations)
                {
                    // Skip allocations with invalid FeeInstallmentId (e.g. 0 or negative)
                    if (ca.FeeInstallmentId <= 0)
                        continue;

                    // Verify the installment actually exists in the database
                    var installmentExists = await _feeInstallmentRepository.GetByIdAsync(ca.FeeInstallmentId);
                    if (installmentExists == null)
                        continue;

                    var newAlloc = new GroupPaymentAllocation
                    {
                        TenantId = gp.TenantId > 0 ? gp.TenantId : 1,
                        GroupPaymentId = gp.Id,
                        StudentId = ca.StudentId,
                        FeeInstallmentId = ca.FeeInstallmentId,
                        AllocatedAmount = ca.AllocatedAmount,
                        ActualAmountApplied = 0m,
                        AllocationStatus = GroupPaymentAllocationStatus.Allocated
                    };

                    await _groupPaymentAllocationRepository.AddAsync(newAlloc);
                }

                // reload allocations from DB after persisting
                allocations = await _groupPaymentAllocationRepository.GetByGroupPaymentAsync(request.GroupPaymentId);
            }

            // Fail loudly when nothing can be applied (all allocations skipped as invalid,
            // or none sent). Otherwise the payment would be marked Completed with ₹0 applied,
            // silently losing the family's money record.
            if (allocations == null || !allocations.Any())
            {
                result.Success = false;
                result.Message = "No valid fee installments found for the selected students. Ensure fees are assigned and installments exist before processing a family payment.";
                return result;
            }

            decimal totalApplied = 0;
            foreach (var alloc in allocations)
            {
                // Skip allocations with invalid FeeInstallmentId to prevent FK violations
                if (alloc.FeeInstallmentId <= 0)
                    continue;
                
                var adjustedAmount = await CalculateInstallmentAmountAfterAdjustmentsAsync(alloc.StudentId, alloc.FeeInstallmentId);
                
                // Get existing payments for this student/installment
                var payments = await _feePaymentRepository.GetPaymentsByInstallmentAsync(alloc.FeeInstallmentId);
                var alreadyPaid = payments.Where(p => p.StudentId == alloc.StudentId && p.Status == PaymentStatus.Completed).Sum(p => p.AmountPaid + (p.DiscountAmount ?? 0));
                
                var remaining = Math.Max(0, adjustedAmount - alreadyPaid);
                decimal amountToApply = Math.Min(alloc.AllocatedAmount, remaining);

                alloc.ActualAmountApplied = amountToApply;
                alloc.AllocationStatus = GroupPaymentAllocationStatus.Applied;
                
                var receiptNumber = $"GRP-{gp.Id}-{alloc.StudentId}-{alloc.FeeInstallmentId}-{DateTime.UtcNow:yyyyMMddHHmmss}";
                var pRec = await _feePaymentRepository.AddAsync(new FeePayment {
                    StudentId = alloc.StudentId, FeeInstallmentId = alloc.FeeInstallmentId, AmountPaid = amountToApply,
                    PaymentDate = DateTime.UtcNow,
                    PaymentMethod = request.PaymentMethod,
                    ReceiptNumber = receiptNumber,
                    Remarks = $"Group: {gp.PaymentGroupName}. {request.Remarks}".Trim(),
                    // 0 is not a valid Staff Id — store null instead of forcing an FK violation
                    CollectedByStaffId = request.ProcessedByStaffId > 0 ? request.ProcessedByStaffId : (int?)null
                });

                alloc.CreatedFeePaymentId = pRec.Id;
                await _groupPaymentAllocationRepository.UpdateAsync(alloc);
                totalApplied += amountToApply;
                result.AllocationResults.Add(new PaymentAllocationResult { StudentId = alloc.StudentId, Success = true, AmountAllocated = amountToApply });

                // Event-driven payment receipt per allocation (best-effort; messaging
                // failures must never roll back or fail the group payment).
                try
                {
                    var tenantId = pRec.TenantId != 0 ? pRec.TenantId : AmbientTenantContext.TenantId ?? 0;
                    if (_whatsAppService != null && tenantId > 0 && amountToApply > 0)
                    {
                        var (messageLogId, skipReason) = await _whatsAppService.EnqueuePaymentConfirmationAsync(tenantId, alloc.StudentId, pRec.Id);
                        if (messageLogId == null && !string.IsNullOrEmpty(skipReason) && _logger != null)
                            _logger.LogDebug("Payment receipt skipped for student {StudentId} (group payment {GroupPaymentId}): {Reason}", alloc.StudentId, gp.Id, skipReason);
                    }
                }
                catch (Exception ex)
                {
                    _logger?.LogWarning(ex, "Failed to enqueue payment receipt for student {StudentId} in group payment {GroupPaymentId}", alloc.StudentId, gp.Id);
                }
            }

            gp.TotalAmountPaid = totalApplied;
            gp.PaymentMethod = request.PaymentMethod;
            gp.Status = GroupPaymentStatus.Completed;
            await _groupPaymentRepository.UpdateAsync(gp);
            result.Success = true; result.TotalApplied = totalApplied;
            return result;
        }

        public async Task<FamilyPaymentSummaryDto> GetFamilyPaymentSummaryAsync(int familyGroupId, int academicYearId)
        {
            return new FamilyPaymentSummaryDto { FamilyGroupId = familyGroupId }; // Minimal implementation
        }

        // ==================== HELPERS ====================

        private decimal CalculateBaseFeeAmount(FeeStructure fs)
        {
            return fs.AnnualFee + fs.RegistrationFee + fs.TransportFee + fs.UniformFee + fs.ExaminationFee + 
                   fs.LibraryFee + fs.ComputerFee + fs.LaboratoryFee + fs.SportsFee + fs.MiscellaneousFee;
        }

        private async Task<List<InstallmentDetailDto>> CalculateInstallmentDetailsAsync(FeeStructure fs, int sid, int ayid, List<StudentFeeAdjustment> adjs)
        {
            var details = new List<InstallmentDetailDto>();
            var payments = await _feePaymentRepository.GetPaymentsByStudentAsync(sid);

            foreach (var inst in fs.Installments.Where(i => i.IsActive))
            {
                var finalInstallmentAmount = await CalculateInstallmentAmountAfterAdjustmentsAsync(sid, inst.Id);
                
                var instPayments = payments.Where(p => p.FeeInstallmentId == inst.Id && p.Status == PaymentStatus.Completed).ToList();
                var paid = instPayments.Sum(p => p.AmountPaid);
                var transDisc = instPayments.Sum(p => p.DiscountAmount ?? 0);
                
                details.Add(new InstallmentDetailDto {
                    InstallmentId = inst.Id, InstallmentName = inst.Name, BaseAmount = inst.Amount,
                    DiscountApplied = inst.Amount - finalInstallmentAmount, FinalAmount = finalInstallmentAmount,
                    DueDate = inst.DueDate, PaidAmount = paid, Outstanding = Math.Max(0, finalInstallmentAmount - paid - transDisc)
                });
            }
            return details;
        }

        private async Task<List<InstallmentDetailDto>> CalculateWaivedInstallmentsAsync(FeeStructure fs, int sid)
        {
            return fs.Installments.Where(i => i.IsActive).Select(inst => new InstallmentDetailDto {
                InstallmentId = inst.Id, InstallmentName = inst.Name, BaseAmount = inst.Amount,
                DiscountApplied = inst.Amount, FinalAmount = 0, DueDate = inst.DueDate, IsWaived = true
            }).ToList();
        }

        private StudentFeeAdjustmentDto MapToAdjustmentDto(StudentFeeAdjustment a)
        {
            return new StudentFeeAdjustmentDto {
                Id = a.Id, StudentId = a.StudentId, AdjustmentType = a.AdjustmentType, IsPercentage = a.IsPercentage,
                DiscountPercentage = a.DiscountPercentage, DiscountAmount = a.DiscountAmount, MaximumCap = a.MaximumCap,
                IsFullWaiver = a.IsFullWaiver, WaiverCategory = a.WaiverCategory, EffectiveDate = a.EffectiveDate,
                ExpiryDate = a.ExpiryDate, Status = a.Status, Remarks = a.Remarks
            };
        }
    }
}