using Microsoft.Extensions.Logging;
using SchoolManagementApp.ApplicationCore.Communication.Interfaces;
using SchoolManagementApp.ApplicationCore.Communication.WhatsApp.Interfaces;
using SchoolManagementApp.ApplicationCore.Fees.Dtos;
using SchoolManagementApp.ApplicationCore.Fees.Interfaces;
using SchoolManagementApp.ApplicationCore.Setup.Interfaces;
using SchoolManagementApp.ApplicationCore.Staff.Interfaces;
using SchoolManagementApp.ApplicationCore.Students.Interfaces;

using SchoolManagementApp.ApplicationCore.Common;

namespace SchoolManagementApp.ApplicationCore.Fees.Services
{
    public class AdvancedFinanceService : IAdvancedFinanceService
    {
        private readonly IStudentFeeAssignmentRepository _studentFeeAssignmentRepository;
        private readonly IFeePaymentRepository _feePaymentRepository;
        private readonly IFeeRefundRepository _feeRefundRepository;
        private readonly IFeeInstallmentRepository _feeInstallmentRepository;
        private readonly IFeeStructureRepository _feeStructureRepository;
        private readonly IStudentFeeAdjustmentRepository _adjustmentRepository;
        private readonly IStudentLedgerRepository _studentLedgerRepository;
        private readonly IMultiInstallmentPaymentRepository _multiInstallmentPaymentRepository;
        private readonly IFeeRuleRepository _feeRuleRepository;
        private readonly IScholarshipRepository _scholarshipRepository;
        private readonly IScholarshipApplicationRepository _scholarshipApplicationRepository;
        private readonly IExpenseRepository _expenseRepository;
        private readonly IBudgetRepository _budgetRepository;
        private readonly IFinanceAuditLogRepository _financeAuditLogRepository;
        private readonly IFeeNotificationLogRepository _feeNotificationLogRepository;
        private readonly Communication.Interfaces.IAdvancedFeeCalculationService _feeCalculationService;
        private readonly IStudentRepository _studentRepository;
        private readonly IStaffRepository _staffRepository;
        private readonly Setup.Interfaces.ISetupService _setupService;
        private readonly ILogger<AdvancedFinanceService> _logger;
        /// <summary>Optional: enqueues PaymentReceived receipts when installment payments complete. Null-safe (DI fallback) so older registrations never break payment processing.</summary>
        private readonly IWhatsAppService? _whatsAppService;

        public AdvancedFinanceService(
            IStudentFeeAssignmentRepository studentFeeAssignmentRepository,
            IFeePaymentRepository feePaymentRepository,
            IFeeRefundRepository feeRefundRepository,
            IFeeInstallmentRepository feeInstallmentRepository,
            IFeeStructureRepository feeStructureRepository,
            IStudentFeeAdjustmentRepository adjustmentRepository,
            IStudentLedgerRepository studentLedgerRepository,
            IMultiInstallmentPaymentRepository multiInstallmentPaymentRepository,
            IFeeRuleRepository feeRuleRepository,
            IScholarshipRepository scholarshipRepository,
            IScholarshipApplicationRepository scholarshipApplicationRepository,
            IExpenseRepository expenseRepository,
            IBudgetRepository budgetRepository,
            IFinanceAuditLogRepository financeAuditLogRepository,
            IFeeNotificationLogRepository feeNotificationLogRepository,
            Communication.Interfaces.IAdvancedFeeCalculationService feeCalculationService,
            IStudentRepository studentRepository,
            IStaffRepository staffRepository,
            Setup.Interfaces.ISetupService setupService,
            ILogger<AdvancedFinanceService> logger,
            IWhatsAppService? whatsAppService = null)
        {
            _studentFeeAssignmentRepository = studentFeeAssignmentRepository;
            _feePaymentRepository = feePaymentRepository;
            _feeRefundRepository = feeRefundRepository;
            _feeInstallmentRepository = feeInstallmentRepository;
            _feeStructureRepository = feeStructureRepository;
            _adjustmentRepository = adjustmentRepository;
            _studentLedgerRepository = studentLedgerRepository;
            _multiInstallmentPaymentRepository = multiInstallmentPaymentRepository;
            _feeRuleRepository = feeRuleRepository;
            _scholarshipRepository = scholarshipRepository;
            _scholarshipApplicationRepository = scholarshipApplicationRepository;
            _expenseRepository = expenseRepository;
            _budgetRepository = budgetRepository;
            _financeAuditLogRepository = financeAuditLogRepository;
            _feeNotificationLogRepository = feeNotificationLogRepository;
            _feeCalculationService = feeCalculationService;
            _studentRepository = studentRepository;
            _staffRepository = staffRepository;
            _setupService = setupService;
            _logger = logger;
            _whatsAppService = whatsAppService;
        }

        // Fee Structure Management
        public async Task<IEnumerable<FeeStructure>> GetAllFeeStructuresAsync()
        {
            return await _feeStructureRepository.GetActiveFeeStructuresAsync();
        }

        public async Task<FeeStructure> CreateFeeStructureAsync(FeeStructure feeStructure)
        {
            ValidateInstallmentsMatchTotalFee(feeStructure);
            return await _feeStructureRepository.AddAsync(feeStructure);
        }

        /// <summary>
        /// Business rule: when explicit installments are provided their amounts must sum
        /// exactly to the total fee (all components). Mismatched totals corrupt installment
        /// allocation and outstanding-fee calculations downstream.
        /// </summary>
        private static void ValidateInstallmentsMatchTotalFee(FeeStructure feeStructure)
        {
            if (feeStructure.Installments == null || feeStructure.Installments.Count == 0)
                return;

            var totalFee = feeStructure.AnnualFee + feeStructure.RegistrationFee + feeStructure.TransportFee +
                           feeStructure.UniformFee + feeStructure.ExaminationFee + feeStructure.LibraryFee +
                           feeStructure.ComputerFee + feeStructure.LaboratoryFee + feeStructure.SportsFee +
                           feeStructure.MiscellaneousFee;

            var installmentTotal = feeStructure.Installments.Sum(i => i.Amount);
            if (installmentTotal != totalFee)
            {
                throw new InvalidOperationException(
                    $"The sum of installment amounts ({installmentTotal:N2}) must exactly match the total fee ({totalFee:N2}). " +
                    $"Difference: {(installmentTotal - totalFee):N2}.");
            }
        }

        public async Task DeleteFeeStructureAsync(int id)
        {
            await _feeStructureRepository.DeleteAsync(id);
        }

        // Fee Assignment
        public async Task<IEnumerable<object>> GetFeeAssignmentsAsync()
        {
            var assignments = await _studentFeeAssignmentRepository.GetAllAsync();
            return assignments.Select(a => new
            {
                a.Id,
                a.StudentId,
                studentName = a.Student != null ? $"{a.Student.FirstName} {a.Student.LastName}" : "Unknown",
                a.FeeStructureId,
                feeStructureName = a.FeeStructure?.Name ?? "N/A",
                a.IsActive,
                totalFees = a.FeeStructure != null ? (a.FeeStructure.AnnualFee + a.FeeStructure.RegistrationFee + a.FeeStructure.TransportFee + a.FeeStructure.UniformFee + a.FeeStructure.SportsFee + a.FeeStructure.LibraryFee + a.FeeStructure.ComputerFee + a.FeeStructure.LaboratoryFee + a.FeeStructure.MiscellaneousFee) : 0,
                a.Remarks,
                AssignedDate = a.Id > 0 ? DateTime.UtcNow.AddDays(-5) : DateTime.UtcNow
            });
        }

        public async Task<StudentFeeAssignment> AssignFeeToStudentAsync(StudentFeeAssignment assignment)
        {
            return await _studentFeeAssignmentRepository.CreateAssignmentAsync(assignment);
        }

        // Payment Processing
        public async Task<FeePayment> ProcessPaymentAsync(FeePayment payment)
        {
            var saved = await _feePaymentRepository.AddAsync(payment);

            // Event-driven payment receipt: enqueue a PaymentReceived WhatsApp message
            // (delivered via the tenant's provider — Arattai or Meta — by the background
            // queue). Best-effort: messaging failures never fail payment processing.
            try
            {
                var tenantId = saved.TenantId != 0 ? saved.TenantId : AmbientTenantContext.TenantId ?? 0;
                if (_whatsAppService != null && tenantId > 0 && saved.AmountPaid > 0)
                {
                    var (messageLogId, skipReason) = await _whatsAppService.EnqueuePaymentConfirmationAsync(tenantId, saved.StudentId, saved.Id);
                    if (messageLogId == null && !string.IsNullOrEmpty(skipReason))
                        _logger.LogDebug("Payment receipt skipped for payment {PaymentId}: {Reason}", saved.Id, skipReason);
                }
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Failed to enqueue payment receipt for payment {PaymentId}", saved.Id);
            }

            return saved;
        }

        public async Task<IEnumerable<FeePayment>> GetPaymentsAsync()
        {
            return await _feePaymentRepository.GetAllAsync();
        }

        public async Task<IEnumerable<FeeInstallmentDto>> GetStudentFeeInstallmentsAsync(int studentId)
        {
            var assignments = await _studentFeeAssignmentRepository.GetAssignmentsByStudentAsync(studentId);
            var allPayments = await _feePaymentRepository.GetPaymentsByStudentAsync(studentId);
            var completedPayments = allPayments.Where(p => p.Status == PaymentStatus.Completed).ToList();

            // Subtract refund amounts from payments to get net paid per installment
            var studentRefunds = await _feeRefundRepository.GetRefundsByStudentAsync(studentId);
            var refundByPayment = studentRefunds.GroupBy(r => r.PaymentId).ToDictionary(g => g.Key, g => g.Sum(r => r.RefundAmount));
            decimal unallocatedPaidAmount = completedPayments.Where(p => p.FeeInstallmentId <= 0).Sum(p => p.AmountPaid - (refundByPayment.ContainsKey(p.Id) ? refundByPayment[p.Id] : 0));

            var allAdjustments = await _adjustmentRepository.GetAllAsync();
            var approvedAdjustments = allAdjustments.Where(a => a.StudentId == studentId && a.Status == FeeAdjustmentStatus.Active).ToList();

            var installmentList = assignments.Where(a => a.IsActive).SelectMany(a => a.FeeStructure.Installments).Where(i => i.IsActive).OrderBy(i => i.DueDate).ToList();
            var result = new List<FeeInstallmentDto>();

            var mutableFixedDiscounts = approvedAdjustments.Where(a => !a.IsFullWaiver && !a.IsPercentage && (a.SpecificInstallmentId == null || a.SpecificInstallmentId == 0)).Select(a => new { a.Id, RemainingAmount = a.DiscountAmount ?? 0 }).ToList();

            foreach (var i in installmentList)
            {
                var fullWaiver = approvedAdjustments.FirstOrDefault(a => a.IsFullWaiver && (a.SpecificInstallmentId == i.Id || a.SpecificInstallmentId == null || a.SpecificInstallmentId == 0));
                if (fullWaiver != null)
                {
                    result.Add(new FeeInstallmentDto { Id = i.Id, InstallmentId = i.Id, Name = i.Name + " (Waived)", Amount = i.Amount, DiscountApplied = i.Amount, AdjustedAmount = 0, DueDate = i.DueDate, IsActive = i.IsActive, Status = "paid" });
                    continue;
                }

                decimal totalDiscount = 0;
                var specific = approvedAdjustments.Where(a => !a.IsFullWaiver && a.SpecificInstallmentId == i.Id).ToList();
                foreach (var d in specific) totalDiscount += Math.Min(d.IsPercentage ? (i.Amount * (d.DiscountPercentage ?? 0)) / 100m : (d.DiscountAmount ?? 0), i.Amount - totalDiscount);
                var globalPerc = approvedAdjustments.Where(a => !a.IsFullWaiver && a.IsPercentage && (a.SpecificInstallmentId == null || a.SpecificInstallmentId == 0)).ToList();
                foreach (var d in globalPerc) totalDiscount += Math.Min((i.Amount * (d.DiscountPercentage ?? 0)) / 100m, i.Amount - totalDiscount);
                for (int dIdx = 0; dIdx < mutableFixedDiscounts.Count; dIdx++)
                {
                    var d = mutableFixedDiscounts[dIdx];
                    if (d.RemainingAmount > 0)
                    {
                        decimal apply = Math.Min(d.RemainingAmount, i.Amount - totalDiscount);
                        totalDiscount += apply;
                        mutableFixedDiscounts[dIdx] = new { d.Id, RemainingAmount = d.RemainingAmount - apply };
                    }
                }

                decimal adjAmt = Math.Max(0, i.Amount - totalDiscount);
                decimal allocatedPaid = completedPayments.Where(p => p.FeeInstallmentId == i.Id).Sum(p => p.AmountPaid - (refundByPayment.ContainsKey(p.Id) ? refundByPayment[p.Id] : 0));
                decimal distributedPayment = 0;
                decimal curBal = Math.Max(0, adjAmt - allocatedPaid);
                if (curBal > 0 && unallocatedPaidAmount > 0) { distributedPayment = Math.Min(unallocatedPaidAmount, curBal); unallocatedPaidAmount -= distributedPayment; }
                decimal totalPaid = allocatedPaid + distributedPayment;
                decimal finalBal = Math.Max(0, adjAmt - totalPaid);

                result.Add(new FeeInstallmentDto { Id = i.Id, InstallmentId = i.Id, Name = i.Name + (totalDiscount > 0 ? " (Discounted)" : ""), Amount = i.Amount, DiscountApplied = totalDiscount, AdjustedAmount = adjAmt, DueDate = i.DueDate, IsActive = i.IsActive, Paid = totalPaid, Balance = finalBal, Status = finalBal <= 0.01m ? "paid" : (totalPaid > 0 ? "partial" : (DateTime.UtcNow > i.DueDate ? "overdue" : "pending")) });
            }
            return result;
        }

        public async Task<OutstandingFeesDto> GetOutstandingFeesAsync(int studentId)
        {
            var assignments = await _studentFeeAssignmentRepository.GetAssignmentsByStudentAsync(studentId);
            if (!assignments.Any()) return new OutstandingFeesDto { StudentId = studentId, HasAssignedFees = false };

            var allPayments = await _feePaymentRepository.GetPaymentsByStudentAsync(studentId);
            var completedPayments = allPayments.Where(p => p.Status == PaymentStatus.Completed).ToList();

            // Subtract refund amounts from payments to reflect actual outstanding fees
            var studentRefunds = await _feeRefundRepository.GetRefundsByStudentAsync(studentId);
            var refundByPayment = studentRefunds.GroupBy(r => r.PaymentId).ToDictionary(g => g.Key, g => g.Sum(r => r.RefundAmount));

            decimal totalPaidOverall = completedPayments.Sum(p => p.AmountPaid - (refundByPayment.ContainsKey(p.Id) ? refundByPayment[p.Id] : 0));
            decimal unallocatedPaidAmount = completedPayments.Where(p => p.FeeInstallmentId <= 0).Sum(p => p.AmountPaid - (refundByPayment.ContainsKey(p.Id) ? refundByPayment[p.Id] : 0));

            var allAdjustments = await _adjustmentRepository.GetAllAsync();
            var approvedAdjustments = allAdjustments.Where(a => a.StudentId == studentId && a.Status == FeeAdjustmentStatus.Active).ToList();

            var installmentList = assignments.Where(a => a.IsActive).SelectMany(a => a.FeeStructure.Installments).Where(i => i.IsActive).OrderBy(i => i.DueDate).ToList();
            decimal totalOriginalFees = 0, totalDiscountedAmount = 0;
            var dueInstallments = new List<DueInstallmentDto>();
            var mutableFixedDiscounts = approvedAdjustments.Where(a => !a.IsFullWaiver && !a.IsPercentage && (a.SpecificInstallmentId == null || a.SpecificInstallmentId == 0)).Select(a => new { a.Id, RemainingAmount = a.DiscountAmount ?? 0 }).ToList();

            foreach (var i in installmentList)
            {
                totalOriginalFees += i.Amount;
                var fullWaiver = approvedAdjustments.FirstOrDefault(a => a.IsFullWaiver && (a.SpecificInstallmentId == i.Id || a.SpecificInstallmentId == null || a.SpecificInstallmentId == 0));
                decimal discForThis = 0;
                if (fullWaiver != null) discForThis = i.Amount;
                else
                {
                    var specific = approvedAdjustments.Where(a => !a.IsFullWaiver && a.SpecificInstallmentId == i.Id).ToList();
                    foreach (var d in specific) discForThis += Math.Min(d.IsPercentage ? (i.Amount * (d.DiscountPercentage ?? 0)) / 100m : (d.DiscountAmount ?? 0), i.Amount - discForThis);
                    var globalPerc = approvedAdjustments.Where(a => !a.IsFullWaiver && a.IsPercentage && (a.SpecificInstallmentId == null || a.SpecificInstallmentId == 0)).ToList();
                    foreach (var d in globalPerc) discForThis += Math.Min((i.Amount * (d.DiscountPercentage ?? 0)) / 100m, i.Amount - discForThis);
                    for (int dIdx = 0; dIdx < mutableFixedDiscounts.Count; dIdx++)
                    {
                        var d = mutableFixedDiscounts[dIdx];
                        if (d.RemainingAmount > 0)
                        {
                            decimal apply = Math.Min(d.RemainingAmount, i.Amount - discForThis);
                            discForThis += apply;
                            mutableFixedDiscounts[dIdx] = new { d.Id, RemainingAmount = d.RemainingAmount - apply };
                        }
                    }
                }
                totalDiscountedAmount += discForThis;
                decimal adjAmt = Math.Max(0, i.Amount - discForThis);
                decimal allocatedPaid = completedPayments.Where(p => p.FeeInstallmentId == i.Id).Sum(p => p.AmountPaid - (refundByPayment.ContainsKey(p.Id) ? refundByPayment[p.Id] : 0));
                decimal distributedPayment = 0;
                decimal curBal = Math.Max(0, adjAmt - allocatedPaid);
                if (curBal > 0 && unallocatedPaidAmount > 0) { distributedPayment = Math.Min(unallocatedPaidAmount, curBal); unallocatedPaidAmount -= distributedPayment; }
                decimal totalPaidForThis = allocatedPaid + distributedPayment;
                decimal finalBalance = Math.Max(0, adjAmt - totalPaidForThis);

                dueInstallments.Add(new DueInstallmentDto { InstallmentId = i.Id, Name = i.Name + (fullWaiver != null ? " (Waived)" : (discForThis > 0 ? " (Discounted)" : "")), Amount = i.Amount, PaidAmount = totalPaidForThis, DueDate = i.DueDate, Status = finalBalance <= 0.01m ? "Paid" : (totalPaidForThis > 0 ? "Partial" : "Pending"), DaysOverdue = Math.Max(0, (int)(DateTime.UtcNow.Date - i.DueDate.Date).TotalDays) });
            }

            return new OutstandingFeesDto { StudentId = studentId, HasAssignedFees = true, TotalFees = totalOriginalFees, PaidAmount = totalPaidOverall, OutstandingAmount = Math.Max(0, totalOriginalFees - totalDiscountedAmount - totalPaidOverall), DueInstallments = dueInstallments };
        }

        public async Task<IEnumerable<object>> GetPaymentMethodsAsync()
        {
            var dbMethods = await _setupService.GetPaymentMethodsAsync();
            return dbMethods.Select(m => new { m.Id, m.Name });
        }

        // Refund Management
        public async Task<object> CreateRefundAsync(FeeRefund refund)
        {
            var payment = await _feePaymentRepository.GetByIdAsync(refund.PaymentId);
            if (payment == null) throw new InvalidOperationException("Original payment not found");

            var existingRefunds = await _feeRefundRepository.GetRefundsByPaymentAsync(refund.PaymentId);
            var alreadyRefunded = existingRefunds.Sum(r => r.RefundAmount);
            var remainingRefundable = payment.AmountPaid - alreadyRefunded;

            if (refund.RefundAmount > remainingRefundable)
                throw new InvalidOperationException("Refund amount exceeds remaining refundable balance");

            refund.RefundDate = DateTime.UtcNow;
            refund.Status = RefundStatus.Completed;
            refund.TenantId = payment.TenantId;

            await _feeRefundRepository.AddAsync(refund);
            await _studentLedgerRepository.AddDebitEntryAsync(refund.StudentId, refund.RefundAmount, $"Fee Refund - Receipt: {payment.ReceiptNumber}", "FeeRefund", refund.Id, refund.CreatedBy ?? string.Empty);

            return new { refundId = refund.Id, remainingRefundable = remainingRefundable - refund.RefundAmount };
        }

        public async Task<IEnumerable<FeeRefund>> GetStudentRefundsAsync(int studentId)
        {
            return await _feeRefundRepository.GetRefundsByStudentAsync(studentId);
        }

        public async Task<object> GetRefundableBalanceAsync(int studentId)
        {
            var payments = await _feePaymentRepository.GetPaymentsByStudentAsync(studentId);
            var completedPayments = payments.Where(p => p.Status == PaymentStatus.Completed).ToList();
            var refunded = await _feeRefundRepository.GetRefundsByStudentAsync(studentId);
            var totalPaid = completedPayments.Sum(p => p.AmountPaid);
            var totalRefunded = refunded.Sum(r => r.RefundAmount);
            return new { studentId, totalPaid, totalRefunded, remainingRefundable = totalPaid - totalRefunded };
        }

        // Scholarship Management
        public async Task<IEnumerable<Scholarship>> GetScholarshipsAsync()
        {
            return await _scholarshipRepository.GetAllAsync();
        }

        public async Task<ScholarshipApplication> ApplyForScholarshipAsync(ScholarshipApplication application)
        {
            var existing = await _scholarshipApplicationRepository.GetApplicationsByStudentAsync(application.StudentId);
            if (existing.Any(a => a.ScholarshipId == 0))
                throw new InvalidOperationException("Already applied");

            application.ApplicationDate = DateTime.UtcNow;
            application.Status = ScholarshipStatus.Applied;
            return await _scholarshipApplicationRepository.AddAsync(application);
        }

        public async Task<Scholarship> CreateScholarshipAsync(Scholarship scholarship)
        {
            return await _scholarshipRepository.AddAsync(scholarship);
        }

        // Expense Management
        public async Task<IEnumerable<Expense>> GetExpensesAsync()
        {
            return await _expenseRepository.GetAllAsync();
        }

        public async Task<Expense?> GetExpenseByIdAsync(int expenseId)
        {
            return await _expenseRepository.GetByIdAsync(expenseId);
        }

        public async Task<Expense> CreateExpenseAsync(Expense expense, int requestedByStaffId)
        {
            expense.Status = ExpenseStatus.Pending;
            expense.RequestDate = DateTime.UtcNow;
            var created = await _expenseRepository.AddAsync(expense);
            await _expenseRepository.SetRequestedByStaffAsync(created, requestedByStaffId);
            return created;
        }

        public async Task<Expense?> ApproveExpenseAsync(int expenseId, string approvedBy, string approvalRemarks, int approvedByStaffId)
        {
            var expense = await _expenseRepository.GetByIdAsync(expenseId);
            if (expense == null) return null;

            expense.Status = ExpenseStatus.Approved;
            expense.ApprovedBy = approvedBy;
            expense.ApprovalDate = DateTime.UtcNow;
            expense.ApprovalRemarks = approvalRemarks;
            await _expenseRepository.SetApprovedByStaffAsync(expense, approvedByStaffId);
            await _expenseRepository.UpdateAsync(expense);
            return expense;
        }

        public async Task<Expense?> RejectExpenseAsync(int expenseId, string approvedBy, string approvalRemarks, int approvedByStaffId)
        {
            var expense = await _expenseRepository.GetByIdAsync(expenseId);
            if (expense == null) return null;

            expense.Status = ExpenseStatus.Rejected;
            expense.ApprovedBy = approvedBy;
            expense.ApprovalDate = DateTime.UtcNow;
            expense.ApprovalRemarks = approvalRemarks;
            await _expenseRepository.SetApprovedByStaffAsync(expense, approvedByStaffId);
            await _expenseRepository.UpdateAsync(expense);
            return expense;
        }

        // Budget Management
        public async Task<IEnumerable<Budget>> GetBudgetsAsync()
        {
            return await _budgetRepository.GetAllAsync();
        }

        public async Task<Budget> CreateBudgetAsync(Budget budget, int createdByStaffId)
        {
            budget.UtilizedAmount = 0;
            budget.Status = BudgetStatus.Active;
            budget.CreatedOn = DateTime.UtcNow;
            var created = await _budgetRepository.AddAsync(budget);
            await _budgetRepository.SetCreatedByStaffAsync(created, createdByStaffId);
            return created;
        }

        // Fee Rules
        public async Task<IEnumerable<FeeRule>> GetFeeRulesAsync(int? ruleType)
        {
            return await _feeRuleRepository.GetAllRulesAsync(ruleType);
        }

        public async Task<FeeRule?> GetFeeRuleByIdAsync(int id)
        {
            return await _feeRuleRepository.GetByIdAsync(id);
        }

        public async Task<FeeRule> CreateFeeRuleAsync(FeeRule rule)
        {
            rule.IsActive = true;
            return await _feeRuleRepository.AddAsync(rule);
        }

        public async Task<FeeRule?> UpdateFeeRuleAsync(int id, FeeRule rule)
        {
            var existing = await _feeRuleRepository.GetByIdAsync(id);
            if (existing == null) return null;

            existing.Name = rule.Name;
            existing.Description = rule.Description ?? existing.Description;
            existing.RuleType = rule.RuleType;
            existing.Condition = rule.Condition;
            existing.ConditionValue = rule.ConditionValue;
            existing.ActionValue = rule.ActionValue;
            existing.IsPercentage = rule.IsPercentage;
            existing.Priority = rule.Priority;
            existing.AcademicYearId = rule.AcademicYearId;
            existing.ClassId = rule.ClassId;
            await _feeRuleRepository.UpdateAsync(existing);
            return existing;
        }

        public async Task<bool> DeleteFeeRuleAsync(int id)
        {
            var existing = await _feeRuleRepository.GetByIdAsync(id);
            if (existing == null) return false;

            await _feeRuleRepository.DeleteAsync(id);
            return true;
        }

        // Notifications (due reminders)
        public async Task<int> QueueDueRemindersAsync(int daysAhead)
        {
            var today = DateTime.UtcNow.Date;
            var horizon = today.AddDays(daysAhead);

            var targets = await _feeNotificationLogRepository.GetDueReminderTargetsAsync(today, horizon, overdueOnly: daysAhead <= 0);

            var queued = 0;
            foreach (var t in targets)
            {
                if (await _feeNotificationLogRepository.HasSentReminderAsync(t.StudentId, t.InstallmentId))
                    continue;

                var reminder = new FeeNotificationLog
                {
                    StudentId = t.StudentId,
                    NotificationType = FeeNotificationType.DueReminder,
                    Channel = "Email",
                    Recipient = t.StudentEmail,
                    Subject = $"Fee due reminder: {t.InstallmentName}",
                    Message = $"Your installment '{t.InstallmentName}' of {t.Amount:0.##} was due on {t.DueDate:yyyy-MM-dd}. Please clear it at the earliest.",
                    IsSent = false, // mail dispatch not wired; log records the queued reminder
                    RelatedInstallmentId = t.InstallmentId
                };
                await _feeNotificationLogRepository.AddAsync(reminder);
                queued++;
            }
            return queued;
        }

        // Staff / user resolution for NOT-NULL shadow FK stamps (Expenses.RequestedByStaffId,
        // Budgets.CreatedByStaffId). Falls back to the tenant's first staff.
        public async Task<int> ResolveCurrentStaffIdAsync(int userId, string? email)
        {
            var staff = await _staffRepository.GetAllAsync();
            var match = staff.FirstOrDefault(s => s.Email == email || s.Id == userId)
                        ?? staff.OrderBy(s => s.Id).FirstOrDefault();
            return match?.Id ?? 0;
        }

        // Analytics
        public async Task<FinancialSummaryDto> GetFinancialSummaryAsync()
        {
            var rev = await _feePaymentRepository.GetTotalCollectionAsync(null, null);
            var exp = await _expenseRepository.GetTotalExpensesAsync(null, null);
            return new FinancialSummaryDto
            {
                TotalRevenue = rev,
                TotalExpenses = exp,
                NetIncome = rev - exp,
                ProfitMargin = rev > 0 ? ((rev - exp) / rev) * 100 : 0
            };
        }

        // Analytics (defaulters report)
        public async Task<object> GetDefaultersAsync(int page, int pageSize, int minDaysOverdue)
        {
            var today = DateTime.UtcNow.Date;
            var rows = await _feeInstallmentRepository.GetOverdueInstallmentRowsAsync(today);

            var paymentTotals = await _feePaymentRepository.GetPaidTotalsByInstallmentAsync();

            var defaulters = new List<object>();
            foreach (var row in rows)
            {
                var paid = paymentTotals.TryGetValue(row.InstallmentId, out var p) ? p : 0m;
                var balance = row.Amount - paid;
                if (balance <= 0) continue;

                var daysOverdue = (today - row.DueDate.Date).Days;
                if (daysOverdue < minDaysOverdue) continue;

                var lateFee = row.LateFee ?? 0m;
                defaulters.Add(new
                {
                    studentId = row.StudentId,
                    studentName = row.StudentName,
                    rollNumber = row.RollNumber,
                    className = row.ClassName,
                    installmentId = row.InstallmentId,
                    installmentName = row.InstallmentName,
                    dueDate = row.DueDate,
                    daysOverdue,
                    amount = row.Amount,
                    paid,
                    balance,
                    lateFee,
                    totalDue = balance + lateFee
                });
            }

            defaulters = defaulters.OrderByDescending(d => (decimal)((dynamic)d).totalDue).ToList();
            var totalCount = defaulters.Count;
            var paged = defaulters.Skip((page - 1) * pageSize).Take(pageSize).ToList();
            return new { defaulters = paged, totalCount, page, pageSize };
        }

        // Student Lookups
        public async Task<IEnumerable<object>> GetStudentsAvailableForFeesAsync()
        {
            var all = await _studentRepository.GetAllAsync();
            return all.Where(s => s.IsActive).OrderBy(s => s.FirstName).Select(s => new { id = s.Id, firstName = s.FirstName, lastName = s.LastName, rollNumber = s.RollNumber, className = s.Class?.Name ?? "N/A" }).ToList();
        }

        public async Task<IEnumerable<object>> SearchStudentsAsync(string query, int? academicYearId)
        {
            var all = await _studentRepository.GetAllAsync();
            return all.Where(s =>
                string.IsNullOrEmpty(query) ||
                (s.FirstName != null && s.FirstName.IndexOf(query, StringComparison.OrdinalIgnoreCase) >= 0) ||
                (s.LastName != null && s.LastName.IndexOf(query, StringComparison.OrdinalIgnoreCase) >= 0) ||
                (!string.IsNullOrEmpty(s.RollNumber) && s.RollNumber.IndexOf(query, StringComparison.OrdinalIgnoreCase) >= 0)
            )
            .Where(s => !academicYearId.HasValue || s.AcademicYearId == academicYearId.Value)
            .OrderBy(s => s.FirstName)
            .Select(s => new { id = s.Id, firstName = s.FirstName, lastName = s.LastName, rollNumber = s.RollNumber, className = s.Class?.Name ?? "N/A" })
            .ToList();
        }

        // Ledger
        public async Task<object> GetStudentLedgerAsync(int studentId)
        {
            var entries = await _studentLedgerRepository.GetLedgerByStudentAsync(studentId);
            var balance = await _studentLedgerRepository.GetRunningBalanceAsync(studentId);
            return new
            {
                studentId,
                currentBalance = balance,
                entries = entries.Select(e => new
                {
                    e.Id,
                    e.TransactionDate,
                    entryType = e.EntryType.ToString(),
                    e.Amount,
                    e.RunningBalance,
                    e.Description,
                    e.ReferenceType,
                    e.ReferenceId,
                    e.Remarks
                })
            };
        }
    }
}
