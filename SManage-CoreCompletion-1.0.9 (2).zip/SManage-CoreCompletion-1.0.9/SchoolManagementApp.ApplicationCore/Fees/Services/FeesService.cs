using System.Text;
using SchoolManagementApp.ApplicationCore.Fees.Dtos;
using Microsoft.Extensions.Logging;
//using IFeesRepository = SchoolManagementApp.ApplicationCore.Interfaces.IFeesRepository;
//using IStudentFeeAdjustmentRepository = SchoolManagementApp.ApplicationCore.Interfaces.IStudentFeeAdjustmentRepository;
//using IGroupPaymentRepository = SchoolManagementApp.ApplicationCore.Interfaces.IGroupPaymentRepository;
using ITenantProvider = SchoolManagementApp.ApplicationCore._Interfaces.ITenantProvider;
using CreateWaiverRequest = SchoolManagementApp.ApplicationCore.Fees.Dtos.CreateWaiverRequest;
using CreateDiscountRequest = SchoolManagementApp.ApplicationCore.Fees.Dtos.CreateDiscountRequest;
using FamilyPaymentSummaryDto = SchoolManagementApp.ApplicationCore.Fees.Dtos.FamilyPaymentSummaryDto;
using ProcessGroupPaymentRequest = SchoolManagementApp.ApplicationCore.Fees.Dtos.ProcessGroupPaymentRequest;
using GroupPaymentProcessResult = SchoolManagementApp.ApplicationCore.Fees.Dtos.GroupPaymentProcessResult;
using SchoolManagementApp.ApplicationCore.Fees.Interfaces;

namespace SchoolManagementApp.ApplicationCore.Fees.Services
{
    /// <summary>
    /// Service implementation for Fees operations
    /// </summary>
    public class FeesService : IFeesService
    {
        private readonly IFeesRepository _feesRepository;
        private readonly IStudentFeeAdjustmentRepository _adjustmentRepository;
        private readonly IGroupPaymentRepository _groupPaymentRepository;
        private readonly ITenantProvider _tenantProvider;
        private readonly ILogger<FeesService> _logger;

        public FeesService(
            IFeesRepository feesRepository,
            IStudentFeeAdjustmentRepository adjustmentRepository,
            IGroupPaymentRepository groupPaymentRepository,
            ITenantProvider tenantProvider,
            ILogger<FeesService> logger)
        {
            _feesRepository = feesRepository;
            _adjustmentRepository = adjustmentRepository;
            _groupPaymentRepository = groupPaymentRepository;
            _tenantProvider = tenantProvider;
            _logger = logger;
        }

        // ==================== Fee CRUD Operations ====================

        public async Task<(IEnumerable<Fee> Fees, int Total)> GetFeesAsync(
            int page, int pageSize, string sort, string order, string search)
        {
            return await _feesRepository.GetFeesAsync(page, pageSize, sort, order, search);
        }

        public async Task<Fee?> GetFeeByIdAsync(int id)
        {
            return await _feesRepository.GetFeeByIdAsync(id);
        }

        public async Task<Fee> CreateFeeAsync(Fee fee)
        {
            var createdFee = await _feesRepository.CreateFeeAsync(fee);
            _logger.LogInformation("Fee created for tenant {TenantId} and student {StudentId}", 
                _tenantProvider.TenantId, fee.StudentId);
            return createdFee;
        }

        public async Task UpdateFeeAsync(Fee fee)
        {
            await _feesRepository.UpdateFeeAsync(fee);
        }

        public async Task DeleteFeeAsync(int id)
        {
            await _feesRepository.DeleteFeeAsync(id);
        }

        // ==================== Waiver Operations ====================

        public async Task<IEnumerable<StudentFeeAdjustment>> GetWaiversAsync(
            int? studentId = null, int? academicYearId = null, string status = "all")
        {
            var waivers = await _adjustmentRepository.GetWaiversAsync();

            if (studentId.HasValue)
                waivers = waivers.Where(w => w.StudentId == studentId.Value);

            if (academicYearId.HasValue)
                waivers = waivers.Where(w => w.AcademicYearId == academicYearId.Value);

            if (status != "all")
            {
                if (Enum.TryParse<FeeAdjustmentStatus>(status, ignoreCase: true, out var statusEnum))
                    waivers = waivers.Where(w => w.Status == statusEnum);
            }

            return waivers;
        }

        public async Task<StudentFeeAdjustment> CreateWaiverAsync(CreateWaiverRequest request)
        {
            var waiver = new StudentFeeAdjustment
            {
                TenantId = _tenantProvider.TenantId,
                StudentId = request.StudentId,
                AcademicYearId = request.AcademicYearId,
                AdjustmentType = FeeAdjustmentType.Waiver,
                IsFullWaiver = true,
                WaiverCategory = request.WaiverCategory,
                EffectiveDate = request.EffectiveDate,
                ExpiryDate = request.ExpiryDate,
                Status = FeeAdjustmentStatus.PendingApproval,
                CreatedBy = "0",
                CreatedOn = DateTime.UtcNow,
                ApprovedBy = !string.IsNullOrEmpty(request.ApprovedBy) ? request.ApprovedBy : null,
                ApprovedDate = !string.IsNullOrEmpty(request.ApprovedBy) ? (DateTime?)DateTime.UtcNow : null,
                Remarks = request.Remarks,
                SpecificInstallmentId = request.SpecificInstallmentId > 0 ? (int?)request.SpecificInstallmentId : null
            };

            var createdWaiver = await _adjustmentRepository.AddAsync(waiver);
            _logger.LogInformation("Waiver created for student {StudentId}", request.StudentId);
            return createdWaiver;
        }

        public async Task<StudentFeeAdjustment?> GetWaiverByIdAsync(int id)
        {
            return await _adjustmentRepository.GetByIdAsync(id);
        }

        public async Task UpdateWaiverAsync(int id, StudentFeeAdjustmentDto dto)
        {
            var waiver = await _adjustmentRepository.GetByIdAsync(id);
            if (waiver == null)
                throw new InvalidOperationException("Waiver not found");

            waiver.Status = dto.Status;
            waiver.Remarks = dto.Remarks;

            await _adjustmentRepository.UpdateAsync(waiver);
        }

        public async Task DeleteWaiverAsync(int id)
        {
            await _adjustmentRepository.DeleteAsync(id);
        }

        // ==================== Discount Operations ====================

        public async Task<IEnumerable<StudentFeeAdjustment>> GetDiscountsAsync(
            int? studentId = null, int? academicYearId = null, string status = "all")
        {
            var discounts = await _adjustmentRepository.GetDiscountsAsync();

            if (studentId.HasValue)
                discounts = discounts.Where(d => d.StudentId == studentId.Value);

            if (academicYearId.HasValue)
                discounts = discounts.Where(d => d.AcademicYearId == academicYearId.Value);

            if (status != "all")
            {
                if (Enum.TryParse<FeeAdjustmentStatus>(status, ignoreCase: true, out var statusEnum))
                    discounts = discounts.Where(d => d.Status == statusEnum);
            }

            return discounts;
        }

        public async Task<StudentFeeAdjustment> CreateDiscountAsync(CreateDiscountRequest request)
        {
            var discount = new StudentFeeAdjustment
            {
                TenantId = _tenantProvider.TenantId,
                StudentId = request.StudentId,
                AcademicYearId = request.AcademicYearId,
                AdjustmentType = FeeAdjustmentType.Discount,
                IsPercentage = request.IsPercentage,
                DiscountPercentage = request.IsPercentage ? request.DiscountValue : null,
                DiscountAmount = !request.IsPercentage ? request.DiscountValue : null,
                MaximumCap = request.MaximumCap,
                EffectiveDate = request.EffectiveDate,
                ExpiryDate = request.ExpiryDate,
                Status = FeeAdjustmentStatus.Active,
                CreatedBy = request.CreatedBy,
                CreatedOn = DateTime.UtcNow,
                Remarks = request.Remarks,
                SpecificInstallmentId = request.SpecificInstallmentId > 0 ? request.SpecificInstallmentId : null
            };

            var createdDiscount = await _adjustmentRepository.AddAsync(discount);
            _logger.LogInformation("Discount created for student {StudentId}", request.StudentId);
            return createdDiscount;
        }

        public async Task<StudentFeeAdjustment?> GetDiscountByIdAsync(int id)
        {
            return await _adjustmentRepository.GetByIdAsync(id);
        }

        public async Task UpdateDiscountAsync(int id, CreateDiscountRequest request)
        {
            var discount = await _adjustmentRepository.GetByIdAsync(id);
            if (discount == null)
                throw new InvalidOperationException("Discount not found");

            discount.AcademicYearId = request.AcademicYearId;
            discount.IsPercentage = request.IsPercentage;
            discount.DiscountPercentage = request.IsPercentage ? request.DiscountValue : null;
            discount.DiscountAmount = !request.IsPercentage ? request.DiscountValue : null;
            discount.MaximumCap = request.MaximumCap;
            discount.EffectiveDate = request.EffectiveDate;
            discount.ExpiryDate = request.ExpiryDate;
            discount.Remarks = request.Remarks;

            await _adjustmentRepository.UpdateAsync(discount);
        }

        public async Task DeleteDiscountAsync(int id)
        {
            await _adjustmentRepository.DeleteAsync(id);
        }

        // ==================== Family Payment Operations ====================

        public async Task<FamilyPaymentSummaryDto?> GetFamilyMembersFeesAsync(int familyId)
        {
            _logger.LogInformation("GetFamilyMembersFees called with familyId: {FamilyId}", familyId);
            var summary = await _groupPaymentRepository.GetFamilyPaymentSummaryAsync(familyId, 0);
            _logger.LogInformation("GetFamilyMembersFees returning summary for familyGroupId: {FamilyGroupId}", 
                summary?.FamilyGroupId);
            return summary;
        }

        public async Task<GroupPaymentProcessResult> ProcessFamilyPaymentAsync(ProcessGroupPaymentRequest request)
        {
            var gp = await _groupPaymentRepository.GetByIdAsync(request.GroupPaymentId);
            if (gp == null)
                throw new InvalidOperationException("Group payment not found");
            GroupPaymentProcessResult result = new GroupPaymentProcessResult { Success = false };
            // TODO: Implement full processing logic

            if (result.Success)
            {
                _logger.LogInformation("Family payment processed. GroupPaymentId: {GroupPaymentId}", 
                    result.GroupPaymentId);
            }

            return result;
        }

        // ==================== Receipt Generation ====================

        public string GenerateReceiptHtml(Fee fee)
        {
            var studentName = fee.Student != null
                ? System.Net.WebUtility.HtmlEncode($"{fee.Student.FirstName} {fee.Student.LastName}")
                : $"Student #{fee.StudentId}";

            var rollNumber = fee.Student?.RollNumber ?? "N/A";
            var scholarNumber = fee.Student?.ScholarNumber ?? "N/A";
            var className = fee.Student?.Class?.Name ?? "N/A";
            var sectionName = fee.Student?.Section?.Name ?? "N/A";
            var contactNumber = fee.Student?.ContactNumber ?? "N/A";
            var email = fee.Student?.Email ?? "N/A";

            var payments = fee.Payments?.ToList() ?? new List<Payment>();
            var totalPaid = payments.Where(p => p.Status == "Success").Sum(p => p.Amount);
            var remaining = fee.Amount - totalPaid;

            var sb = new StringBuilder();
            sb.AppendLine("<!DOCTYPE html>");
            sb.AppendLine("<html lang=\"en\">");
            sb.AppendLine("<head><meta charset=\"utf-8\"/>");
            sb.AppendLine("<title>Fee Receipt</title>");
            sb.AppendLine("<style>");
            sb.AppendLine("body { font-family: 'Segoe UI', Arial, Helvetica, sans-serif; color: #1a1a2e; background: #f0f2f5; margin: 0; padding: 20px; }");
            sb.AppendLine(".receipt-container { max-width: 700px; margin: 0 auto; background: white; border-radius: 12px; box-shadow: 0 2px 12px rgba(0,0,0,0.08); overflow: hidden; }");
            sb.AppendLine(".receipt-header { background: linear-gradient(135deg, #1a237e, #283593); color: white; padding: 32px; text-align: center; }");
            sb.AppendLine(".receipt-header h1 { margin: 0 0 4px; font-size: 22px; font-weight: 700; letter-spacing: 1px; }");
            sb.AppendLine(".receipt-header .school-name { font-size: 14px; opacity: 0.9; margin-bottom: 16px; }");
            sb.AppendLine(".receipt-header .receipt-badge { display: inline-block; background: rgba(255,255,255,0.2); border-radius: 20px; padding: 6px 20px; font-size: 13px; font-weight: 600; }");
            sb.AppendLine(".receipt-body { padding: 28px 32px; }");
            sb.AppendLine(".section-title { font-size: 13px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.08em; color: #5c6bc0; margin: 20px 0 12px; padding-bottom: 6px; border-bottom: 2px solid #e8eaf6; }");
            sb.AppendLine(".info-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px 24px; }");
            sb.AppendLine(".info-item { display: flex; flex-direction: column; }");
            sb.AppendLine(".info-label { font-size: 11px; font-weight: 600; color: #78909c; text-transform: uppercase; letter-spacing: 0.05em; margin-bottom: 2px; }");
            sb.AppendLine(".info-value { font-size: 14px; font-weight: 500; color: #263238; }");
            sb.AppendLine(".amount-box { background: #f5f7ff; border: 1px solid #e0e4f5; border-radius: 8px; padding: 20px; margin: 20px 0; text-align: center; }");
            sb.AppendLine(".amount-box .label { font-size: 12px; color: #5c6bc0; font-weight: 600; text-transform: uppercase; letter-spacing: 0.05em; }");
            sb.AppendLine(".amount-box .amount { font-size: 36px; font-weight: 800; color: #1a237e; margin: 4px 0; }");
            sb.AppendLine(".amount-box .status { font-size: 13px; font-weight: 600; margin-top: 4px; }");
            sb.AppendLine(".status-paid { color: #2e7d32; }");
            sb.AppendLine(".status-pending { color: #e65100; }");
            sb.AppendLine(".status-overdue { color: #c62828; }");
            sb.AppendLine(".payment-table { width: 100%; border-collapse: collapse; margin-top: 12px; }");
            sb.AppendLine(".payment-table th { background: #f5f7ff; padding: 10px 12px; text-align: left; font-size: 11px; font-weight: 700; text-transform: uppercase; color: #5c6bc0; border-bottom: 2px solid #e8eaf6; }");
            sb.AppendLine(".payment-table td { padding: 10px 12px; font-size: 13px; border-bottom: 1px solid #f0f0f0; color: #37474f; }");
            sb.AppendLine(".summary-row { display: flex; justify-content: space-between; padding: 10px 0; font-size: 14px; }");
            sb.AppendLine(".summary-row.total { border-top: 2px solid #e8eaf6; font-weight: 700; font-size: 16px; color: #1a237e; padding-top: 12px; }");
            sb.AppendLine(".receipt-footer { background: #f8f9fc; padding: 20px 32px; text-align: center; border-top: 1px solid #e8eaf6; }");
            sb.AppendLine(".receipt-footer p { margin: 4px 0; font-size: 12px; color: #78909c; }");
            sb.AppendLine("</style></head><body>");

            sb.AppendLine("<div class=\"receipt-container\">");

            // Header
            sb.AppendLine("<div class=\"receipt-header\">");
            sb.AppendLine("<h1>FEE RECEIPT</h1>");
            sb.AppendLine("<div class=\"school-name\">School Management System</div>");
            sb.AppendLine($"<div class=\"receipt-badge\">Fee Record #{fee.Id}</div>");
            sb.AppendLine("</div>");

            // Body
            sb.AppendLine("<div class=\"receipt-body\">");

            // Student Info
            sb.AppendLine("<div class=\"section-title\">Student Information</div>");
            sb.AppendLine("<div class=\"info-grid\">");
            sb.AppendLine($"<div class=\"info-item\"><span class=\"info-label\">Student Name</span><span class=\"info-value\">{studentName}</span></div>");
            sb.AppendLine($"<div class=\"info-item\"><span class=\"info-label\">Roll Number</span><span class=\"info-value\">{System.Net.WebUtility.HtmlEncode(rollNumber)}</span></div>");
            sb.AppendLine($"<div class=\"info-item\"><span class=\"info-label\">Scholar Number</span><span class=\"info-value\">{System.Net.WebUtility.HtmlEncode(scholarNumber)}</span></div>");
            sb.AppendLine($"<div class=\"info-item\"><span class=\"info-label\">Class / Section</span><span class=\"info-value\">{System.Net.WebUtility.HtmlEncode(className)} / {System.Net.WebUtility.HtmlEncode(sectionName)}</span></div>");
            sb.AppendLine($"<div class=\"info-item\"><span class=\"info-label\">Contact</span><span class=\"info-value\">{System.Net.WebUtility.HtmlEncode(contactNumber)}</span></div>");
            sb.AppendLine($"<div class=\"info-item\"><span class=\"info-label\">Email</span><span class=\"info-value\">{System.Net.WebUtility.HtmlEncode(email)}</span></div>");
            sb.AppendLine("</div>");

            // Fee Details
            sb.AppendLine("<div class=\"section-title\">Fee Details</div>");
            sb.AppendLine("<div class=\"info-grid\">");
            sb.AppendLine($"<div class=\"info-item\"><span class=\"info-label\">Fee Type</span><span class=\"info-value\">{System.Net.WebUtility.HtmlEncode(fee.FeeType)}</span></div>");
            sb.AppendLine($"<div class=\"info-item\"><span class=\"info-label\">Due Date</span><span class=\"info-value\">{fee.DueDate:dd MMM yyyy}</span></div>");
            sb.AppendLine($"<div class=\"info-item\"><span class=\"info-label\">Status</span><span class=\"info-value\">{fee.Status}</span></div>");
            sb.AppendLine("</div>");

            // Amount Box
            var statusClass = fee.Status?.ToLower() switch
            {
                "paid" => "status-paid",
                "overdue" => "status-overdue",
                _ => "status-pending"
            };
            var statusLabel = fee.Status?.ToLower() switch
            {
                "paid" => "PAID IN FULL",
                "overdue" => "OVERDUE",
                _ => "PENDING"
            };
            sb.AppendLine("<div class=\"amount-box\">");
            sb.AppendLine("<div class=\"label\">Total Fee Amount</div>");
            sb.AppendLine($"<div class=\"amount\">{fee.Amount:N2}</div>");
            sb.AppendLine($"<div class=\"status {statusClass}\">{statusLabel}</div>");
            sb.AppendLine("</div>");

            // Payment History
            if (payments.Any())
            {
                sb.AppendLine("<div class=\"section-title\">Payment History</div>");
                sb.AppendLine("<table class=\"payment-table\">");
                sb.AppendLine("<thead><tr><th>Date</th><th>Method</th><th>Receipt #</th><th>Amount</th><th>Status</th></tr></thead>");
                sb.AppendLine("<tbody>");
                foreach (var p in payments.OrderByDescending(p => p.PaymentDate))
                {
                    sb.AppendLine("<tr>");
                    sb.AppendLine($"<td>{p.PaymentDate:dd MMM yyyy}</td>");
                    sb.AppendLine($"<td>{System.Net.WebUtility.HtmlEncode(p.PaymentMethod)}</td>");
                    sb.AppendLine($"<td>{System.Net.WebUtility.HtmlEncode(p.ReceiptNumber)}</td>");
                    sb.AppendLine($"<td>{p.Amount:N2}</td>");
                    sb.AppendLine($"<td>{p.Status}</td>");
                    sb.AppendLine("</tr>");
                }
                sb.AppendLine("</tbody></table>");
            }

            // Summary
            sb.AppendLine("<div class=\"section-title\">Summary</div>");
            sb.AppendLine($"<div class=\"summary-row\"><span>Total Fee</span><span>{fee.Amount:N2}</span></div>");
            sb.AppendLine($"<div class=\"summary-row\"><span>Amount Paid</span><span style=\"color:#2e7d32\">{totalPaid:N2}</span></div>");
            if (remaining > 0)
            {
                sb.AppendLine($"<div class=\"summary-row total\"><span>Remaining Balance</span><span style=\"color:#c62828\">{remaining:N2}</span></div>");
            }
            else
            {
                sb.AppendLine("<div class=\"summary-row total\"><span>Balance</span><span style=\"color:#2e7d32\">0.00</span></div>");
            }

            sb.AppendLine("</div>"); // receipt-body

            // Footer
            sb.AppendLine("<div class=\"receipt-footer\">");
            sb.AppendLine($"<p>Generated on {DateTime.Now:dd MMM yyyy 'at' hh:mm tt}</p>");
            sb.AppendLine("<p>This is a system-generated receipt. For queries, please contact the accounts department.</p>");
            sb.AppendLine("</div>");

            sb.AppendLine("</div>"); // receipt-container
            sb.AppendLine("</body></html>");

            return sb.ToString();
        }
    }
}
