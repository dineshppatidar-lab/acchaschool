using Microsoft.Extensions.Logging;
using SchoolManagementApp.ApplicationCore.Fees.Dtos;
using SchoolManagementApp.ApplicationCore.Fees.Interfaces;
using System.Text;
using FamilyPaymentSummaryDto = SchoolManagementApp.ApplicationCore.Fees.Dtos.FamilyPaymentSummaryDto;
using GroupPaymentProcessResult = SchoolManagementApp.ApplicationCore.Fees.Dtos.GroupPaymentProcessResult;
using IAdvancedFeeCalculationService = SchoolManagementApp.ApplicationCore.Communication.Interfaces.IAdvancedFeeCalculationService;
using InitiateGroupPaymentRequest = SchoolManagementApp.ApplicationCore.Fees.Dtos.InitiateGroupPaymentRequest;
using IStaffRepository = SchoolManagementApp.ApplicationCore.Staff.Interfaces.IStaffRepository;
using ProcessGroupPaymentRequest = SchoolManagementApp.ApplicationCore.Fees.Dtos.ProcessGroupPaymentRequest;

namespace SchoolManagementApp.ApplicationCore.Fees.Services
{
    /// <summary>
    /// Service implementation for Group Payment operations
    /// </summary>
    public class GroupPaymentService : IGroupPaymentService
    {
        private readonly IAdvancedFeeCalculationService _feeCalculationService;
        private readonly IGroupPaymentRepository _groupPaymentRepository;
        private readonly IStaffRepository _staffRepository;
        private readonly ILogger<GroupPaymentService> _logger;

        public GroupPaymentService(
            IAdvancedFeeCalculationService feeCalculationService,
            IGroupPaymentRepository groupPaymentRepository,
            IStaffRepository staffRepository,
            ILogger<GroupPaymentService> logger)
        {
            _feeCalculationService = feeCalculationService;
            _groupPaymentRepository = groupPaymentRepository;
            _staffRepository = staffRepository;
            _logger = logger;
        }

        public async Task<GroupPayment> InitiateGroupPaymentAsync(InitiateGroupPaymentRequest request)
        {
            return await _feeCalculationService.InitiateGroupPaymentAsync(request);
        }

        public async Task<GroupPaymentProcessResult> ProcessGroupPaymentAsync(ProcessGroupPaymentRequest request)
        {
            return await _feeCalculationService.ProcessGroupPaymentAsync(request);
        }

        public async Task<GroupPaymentReceiptDto?> GetGroupPaymentReceiptAsync(int groupPaymentId)
        {
            var gp = await _groupPaymentRepository.GetWithAllocationsByIdAsync(groupPaymentId);
            if (gp == null)
                return null;

            var dto = new GroupPaymentReceiptDto
            {
                GroupPaymentId = gp.Id,
                ReceiptNumber = gp.ReceiptNumber,
                PaymentDate = gp.PaymentDate,
                TotalAmountPaid = gp.TotalAmountPaid,
                PaymentMethod = gp.PaymentMethod.ToString(),
                TransactionId = gp.TransactionId,
                ProcessedByStaffId = gp.ProcessedByStaffId,
                Remarks = gp.Remarks
            };

            if (gp.ProcessedByStaffId.HasValue)
            {
                var staff = await _staffRepository.GetByIdAsync(gp.ProcessedByStaffId.Value);
                if (staff != null)
                    dto.ProcessedByStaffName = $"{staff.FirstName} {staff.LastName}".Trim();
            }

            foreach (var a in gp.Allocations)
            {
                dto.Allocations.Add(new AllocationResultDto
                {
                    StudentId = a.StudentId,
                    StudentName = a.Student != null ? $"{a.Student.FirstName} {a.Student.LastName}".Trim() : "",
                    FeeInstallmentId = a.FeeInstallmentId,
                    InstallmentName = a.FeeInstallment?.Name ?? "",
                    AllocatedAmount = a.AllocatedAmount,
                    ActualAmountApplied = a.ActualAmountApplied,
                    DiscountApplied = a.DiscountApplied ?? 0m,
                    CreatedFeePaymentId = a.CreatedFeePaymentId
                });
            }

            return dto;
        }

        public async Task<FamilyPaymentSummaryDto?> GetFamilyPaymentSummaryAsync(int familyGroupId, int academicYearId)
        {
            return await _feeCalculationService.GetFamilyPaymentSummaryAsync(familyGroupId, academicYearId);
        }

        public string GenerateReceiptHtml(GroupPayment gp)
        {
            var sb = new StringBuilder();
            sb.AppendLine("<html><head><meta charset=\"utf-8\"/><title>Receipt</title>");
            sb.AppendLine("<style>body{font-family:Arial,Helvetica,sans-serif}table{width:100%;border-collapse:collapse}th,td{padding:8px;border:1px solid #ddd}</style>");
            sb.AppendLine("</head><body>");
            sb.AppendLine($"<h2>Receipt: {System.Net.WebUtility.HtmlEncode(gp.ReceiptNumber)}</h2>");
            sb.AppendLine($"<p><strong>Date:</strong> {gp.PaymentDate:yyyy-MM-dd HH:mm}</p>");
            sb.AppendLine($"<p><strong>Total Paid:</strong> {gp.TotalAmountPaid:C}</p>");
            sb.AppendLine($"<p><strong>Payment Method:</strong> {gp.PaymentMethod}</p>");
            sb.AppendLine($"<p><strong>Transaction Id:</strong> {System.Net.WebUtility.HtmlEncode(gp.TransactionId)}</p>");

            sb.AppendLine("<h3>Allocations</h3>");
            sb.AppendLine("<table><thead><tr><th>Student</th><th>Installment</th><th>Allocated</th><th>Applied</th><th>Created Payment Id</th></tr></thead><tbody>");
            foreach (var a in gp.Allocations)
            {
                var studentName = a.Student != null ? System.Net.WebUtility.HtmlEncode(a.Student.FirstName + " " + a.Student.LastName) : "";
                var installmentName = a.FeeInstallment != null ? System.Net.WebUtility.HtmlEncode(a.FeeInstallment.Name) : "";
                sb.AppendLine($"<tr><td>{studentName}</td><td>{installmentName}</td><td>{a.AllocatedAmount:C}</td><td>{a.ActualAmountApplied:C}</td><td>{a.CreatedFeePaymentId?.ToString() ?? ""}</td></tr>");
            }
            sb.AppendLine("</tbody></table>");

            sb.AppendLine($"<p><em>Remarks: {System.Net.WebUtility.HtmlEncode(gp.Remarks)}</em></p>");
            sb.AppendLine("</body></html>");

            return sb.ToString();
        }
    }
}
