using SchoolManagementApp.ApplicationCore.Fees.Dtos;
using SchoolManagementApp.ApplicationCore.Fees.Interfaces;
using SchoolManagementApp.ApplicationCore.Communication.Interfaces;
using SchoolManagementApp.ApplicationCore.Entities;
using Microsoft.Extensions.Logging;

namespace SchoolManagementApp.ApplicationCore.Fees.Services
{
    /// <summary>
    /// Service implementation for Fee Adjustment operations
    /// </summary>
    public class FeeAdjustmentService : Fees.Interfaces.IFeeAdjustmentService
    {
        private readonly Communication.Interfaces.IAdvancedFeeCalculationService _feeCalculationService;
        private readonly Fees.Interfaces.IStudentFeeAdjustmentRepository _adjustmentRepository;
        private readonly ILogger<FeeAdjustmentService> _logger;

        public FeeAdjustmentService(
            Communication.Interfaces.IAdvancedFeeCalculationService feeCalculationService,
            Fees.Interfaces.IStudentFeeAdjustmentRepository adjustmentRepository,
            ILogger<FeeAdjustmentService> logger)
        {
            _feeCalculationService = feeCalculationService;
            _adjustmentRepository = adjustmentRepository;
            _logger = logger;
        }

        public async Task<StudentFeeAdjustment> CreateOrUpdateWaiverAsync(CreateWaiverRequest request)
        {
            return await _feeCalculationService.CreateOrUpdateWaiverAsync(request);
        }

        public async Task<StudentFeeAdjustment?> GetActiveWaiverAsync(int studentId, int academicYearId)
        {
            return await _adjustmentRepository.GetActiveWaiverAsync(studentId, academicYearId);
        }

        public async Task<StudentFeeAdjustment> CreateOrUpdateDiscountAsync(CreateDiscountRequest request)
        {
            return await _feeCalculationService.CreateOrUpdateDiscountAsync(request);
        }

        public async Task<IEnumerable<StudentFeeAdjustment>> GetActiveDiscountsAsync(int studentId, int academicYearId)
        {
            return await _adjustmentRepository.GetActiveDiscountsAsync(studentId, academicYearId);
        }

        public async Task<StudentFinalFeeDto> CalculateFinalStudentFeesAsync(int studentId, int academicYearId)
        {
            return await _feeCalculationService.CalculateFinalStudentFeesAsync(studentId, academicYearId);
        }

        public async Task<decimal> CalculateOutstandingBalanceAsync(int studentId, int academicYearId)
        {
            return await _feeCalculationService.CalculateOutstandingBalanceAsync(studentId, academicYearId);
        }

        public async Task<bool> RevokeAdjustmentAsync(int adjustmentId)
        {
            return await _feeCalculationService.RevokeAdjustmentAsync(adjustmentId);
        }

        public async Task<IEnumerable<StudentFeeAdjustment>> GetStudentAdjustmentsAsync(int studentId, int academicYearId)
        {
            return await _feeCalculationService.GetStudentAdjustmentsAsync(studentId, academicYearId);
        }
    }
}
