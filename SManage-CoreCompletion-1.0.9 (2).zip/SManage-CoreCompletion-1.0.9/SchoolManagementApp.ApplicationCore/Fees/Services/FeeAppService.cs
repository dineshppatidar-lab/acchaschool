using IFeePaymentRepository = SchoolManagementApp.ApplicationCore.Fees.Interfaces.IFeePaymentRepository;
using IFeeInstallmentRepository = SchoolManagementApp.ApplicationCore.Fees.Interfaces.IFeeInstallmentRepository;
using IFeeStructureRepository = SchoolManagementApp.ApplicationCore.Fees.Interfaces.IFeeStructureRepository;
using IFeeRefundRepository = SchoolManagementApp.ApplicationCore.Fees.Interfaces.IFeeRefundRepository;
using SchoolManagementApp.ApplicationCore.Students.Interfaces;

namespace SchoolManagementApp.ApplicationCore.Fees.Services
{
    /// <summary>
    /// DTO for fee overview data
    /// </summary>
    public class StudentFeeOverviewDto
    {
        public int StudentId { get; set; }
        public string StudentName { get; set; } = string.Empty;
        public decimal TotalFeesDue { get; set; }
        public decimal TotalPaid { get; set; }
        public decimal OutstandingBalance { get; set; }
        public decimal OverdueFees { get; set; }
        public List<FeeInstallmentStatusDto> Installments { get; set; } = new();
    }

    /// <summary>
    /// DTO for individual installment status
    /// </summary>
    public class FeeInstallmentStatusDto
    {
        public int InstallmentId { get; set; }
        public string InstallmentName { get; set; } = string.Empty;
        public DateTime DueDate { get; set; }
        public decimal Amount { get; set; }
        public decimal Paid { get; set; }
        public decimal Outstanding { get; set; }
        public decimal? LateFee { get; set; }
        public bool IsOverdue { get; set; }
        public bool IsPaid { get; set; }
    }

    /// <summary>
    /// DTO for payment calculation
    /// </summary>
    public class PaymentCalculationDto
    {
        public decimal BaseAmount { get; set; }
        public decimal LateFeeAmount { get; set; }
        public decimal DiscountAmount { get; set; }
        public decimal TotalPayableAmount { get; set; }
        public string CalculationNotes { get; set; } = string.Empty;
    }

    /// <summary>
    /// Data transfer object for payment information
    /// </summary>
    public class PaymentData
    {
        public decimal AmountPaid { get; set; }
        public string PaymentMethod { get; set; } = string.Empty;
        public string TransactionId { get; set; } = string.Empty;
        public string Remarks { get; set; } = string.Empty;
        public int CollectedByStaffId { get; set; }
        public decimal? DiscountAmount { get; set; }
        public decimal? LateFeeAmount { get; set; }
    }

    /// <summary>
    /// Service interface for comprehensive fee operations
    /// Handles fee structure assignments, calculations, and payment processing
    /// </summary>
    public interface IFeeAppService
    {
        // Fee Structure & Assignment Operations
        Task<StudentFeeOverviewDto> GetStudentFeeOverviewAsync(int studentId);
        Task AssignFeeStructureToStudentAsync(int studentId, int feeStructureId, string remarks = "");
        Task DeactivateStudentFeeAssignmentAsync(int assignmentId);
        Task<IEnumerable<Entities.FeeStructure>> GetActiveFeeStructuresAsync();
        Task<Entities.FeeStructure?> GetFeeStructureByIdAsync(int feeStructureId);

        // Fee Calculation Operations
        Task<PaymentCalculationDto> CalculatePaymentAmountAsync(int installmentId, decimal amountToPayAmount = 0);
        Task<decimal> CalculateLateFeeAsync(int installmentId, DateTime asOfDate);
        Task<decimal> GetOutstandingBalanceAsync(int studentId);
        Task<decimal> GetPaidAmountAsync(int studentId);
        Task<decimal> GetTotalFeeDueAsync(int studentId);

        // Payment Operations
        Task<Entities.FeePayment> ProcessPaymentAsync(int studentId, int feeInstallmentId, PaymentData paymentData);
        Task<IEnumerable<Entities.FeePayment>> GetStudentPaymentsAsync(int studentId);
        Task<Entities.FeePayment?> GetPaymentByIdAsync(int paymentId);
        Task ApplyDiscountAsync(int paymentId, decimal discountAmount, string reason = "");
        Task ApplyLateFeeAsync(int installmentId, decimal lateFeeAmount);

        // Receipt Operations
        Task<string> GenerateReceiptNumberAsync();
        Task<string> GenerateReceiptPdfAsync(int paymentId);

        // Overdue Fee Management
        Task<IEnumerable<FeeInstallmentStatusDto>> GetOverdueInstallmentsAsync(int studentId);
        Task<IEnumerable<int>> GetStudentsWithOverdueFeesAsync();
    }

    /// <summary>
    /// Implementation of fee service
    /// Moved from Infrastructure/Services/ per CorporateFleet module pattern.
    /// </summary>
    public class FeeAppService : IFeeAppService
    {
        private readonly IStudentFeeAssignmentRepository _assignmentRepository;
        private readonly IFeePaymentRepository _paymentRepository;
        private readonly IFeeInstallmentRepository _installmentRepository;
        private readonly IFeeStructureRepository _feeStructureRepository;
        private readonly IFeeRefundRepository _refundRepository;

        public FeeAppService(
            IStudentFeeAssignmentRepository assignmentRepository,
            IFeePaymentRepository paymentRepository,
            IFeeInstallmentRepository installmentRepository,
            IFeeStructureRepository feeStructureRepository,
            IFeeRefundRepository refundRepository)
        {
            _assignmentRepository = assignmentRepository;
            _paymentRepository = paymentRepository;
            _installmentRepository = installmentRepository;
            _feeStructureRepository = feeStructureRepository;
            _refundRepository = refundRepository;
        }

        /// <summary>
        /// Gets comprehensive fee overview for a student
        /// </summary>
        public async Task<StudentFeeOverviewDto> GetStudentFeeOverviewAsync(int studentId)
        {
            var assignments = await _assignmentRepository.GetAssignmentsByStudentAsync(studentId);
            
            if (!assignments.Any())
            {
                return new StudentFeeOverviewDto { StudentId = studentId };
            }

            var overview = new StudentFeeOverviewDto { StudentId = studentId };

            var allRefunds = await _refundRepository.GetRefundsByStudentAsync(studentId);
            var refundByPaymentId = allRefunds.ToDictionary(r => r.PaymentId, r => r.RefundAmount);

            foreach (var assignment in assignments)
            {
                foreach (var installment in assignment.FeeStructure.Installments)
                {
                    overview.TotalFeesDue += installment.Amount;

                    var payments = await _paymentRepository.GetPaymentsByInstallmentAsync(installment.Id);
                    var paidAmount = payments.Sum(p => p.AmountPaid);
                    overview.TotalPaid += paidAmount;

                    var refundForInstallment = payments.Where(p => refundByPaymentId.ContainsKey(p.Id)).Sum(p => refundByPaymentId[p.Id]);
                    var netPaid = paidAmount - refundForInstallment;

                    var outstanding = installment.Amount - netPaid;
                    var isOverdue = installment.DueDate < DateTime.UtcNow && outstanding > 0;
                    
                    if (isOverdue)
                    {
                        overview.OverdueFees += outstanding;
                    }

                    overview.Installments.Add(new FeeInstallmentStatusDto
                    {
                        InstallmentId = installment.Id,
                        InstallmentName = installment.Name,
                        DueDate = installment.DueDate,
                        Amount = installment.Amount,
                        Paid = netPaid,
                        Outstanding = outstanding,
                        LateFee = installment.LateFee,
                        IsOverdue = isOverdue,
                        IsPaid = outstanding == 0
                    });
                }
            }

            var totalRefunds = allRefunds.Sum(r => r.RefundAmount);
            overview.TotalPaid -= totalRefunds;
            overview.OutstandingBalance = overview.TotalFeesDue - overview.TotalPaid;
            return overview;
        }

        /// <summary>
        /// Assigns a fee structure to a student
        /// </summary>
        public async Task AssignFeeStructureToStudentAsync(int studentId, int feeStructureId, string remarks = "")
        {
            var assignment = new Entities.StudentFeeAssignment
            {
                StudentId = studentId,
                FeeStructureId = feeStructureId,
                Remarks = remarks
            };

            await _assignmentRepository.CreateAssignmentAsync(assignment);
        }

        /// <summary>
        /// Deactivates a fee structure assignment
        /// </summary>
        public async Task DeactivateStudentFeeAssignmentAsync(int assignmentId)
        {
            await _assignmentRepository.DeactivateAssignmentAsync(assignmentId);
        }

        /// <summary>
        /// Gets all active fee structures
        /// </summary>
        public async Task<IEnumerable<Entities.FeeStructure>> GetActiveFeeStructuresAsync()
        {
            return await _feeStructureRepository.GetActiveFeeStructuresAsync();
        }

        /// <summary>
        /// Gets a specific fee structure
        /// </summary>
        public async Task<Entities.FeeStructure?> GetFeeStructureByIdAsync(int feeStructureId)
        {
            return await _feeStructureRepository.GetByIdAsync(feeStructureId);
        }

        /// <summary>
        /// Calculates the payment amount considering base, late fees, and discounts
        /// </summary>
        public async Task<PaymentCalculationDto> CalculatePaymentAmountAsync(int installmentId, decimal amountToPay = 0)
        {
            var installment = await _installmentRepository.GetByIdAsync(installmentId);
            if (installment == null)
                throw new InvalidOperationException($"Installment {installmentId} not found");

            var calculation = new PaymentCalculationDto
            {
                BaseAmount = amountToPay > 0 ? amountToPay : installment.Amount
            };

            if (installment.DueDate < DateTime.UtcNow && installment.LateFee.HasValue && installment.LateFee > 0)
            {
                calculation.LateFeeAmount = installment.LateFee.Value;
                calculation.CalculationNotes += "Late fee applicable due to overdue payment. ";
            }

            calculation.TotalPayableAmount = calculation.BaseAmount + calculation.LateFeeAmount - calculation.DiscountAmount;

            return calculation;
        }

        /// <summary>
        /// Calculates late fee for an installment
        /// </summary>
        public async Task<decimal> CalculateLateFeeAsync(int installmentId, DateTime asOfDate)
        {
            var installment = await _installmentRepository.GetByIdAsync(installmentId);
            if (installment == null || !installment.LateFee.HasValue)
                return 0;

            var gracePeriodEnd = installment.DueDate.AddDays(installment.GracePeriodDays);
            if (asOfDate > gracePeriodEnd)
            {
                return installment.LateFee.Value;
            }

            return 0;
        }

        /// <summary>
        /// Gets outstanding balance for a student
        /// </summary>
        public async Task<decimal> GetOutstandingBalanceAsync(int studentId)
        {
            var overview = await GetStudentFeeOverviewAsync(studentId);
            return overview.OutstandingBalance;
        }

        /// <summary>
        /// Gets total paid amount for a student
        /// </summary>
        public async Task<decimal> GetPaidAmountAsync(int studentId)
        {
            var overview = await GetStudentFeeOverviewAsync(studentId);
            return overview.TotalPaid;
        }

        /// <summary>
        /// Gets total fee due for a student
        /// </summary>
        public async Task<decimal> GetTotalFeeDueAsync(int studentId)
        {
            var overview = await GetStudentFeeOverviewAsync(studentId);
            return overview.TotalFeesDue;
        }

        /// <summary>
        /// Processes a payment for a fee installment
        /// </summary>
        public async Task<Entities.FeePayment> ProcessPaymentAsync(int studentId, int feeInstallmentId, PaymentData paymentData)
        {
            var payment = new Entities.FeePayment
            {
                StudentId = studentId,
                FeeInstallmentId = feeInstallmentId,
                AmountPaid = paymentData.AmountPaid,
                LateFeeAmount = paymentData.LateFeeAmount ?? 0,
                DiscountAmount = paymentData.DiscountAmount ?? 0,
                PaymentDate = DateTime.UtcNow,
                PaymentMethod = Enum.TryParse<Entities.PaymentMethodType>(paymentData.PaymentMethod, true, out var pmType) ? pmType : Entities.PaymentMethodType.Cash,
                TransactionId = paymentData.TransactionId,
                ReceiptNumber = await GenerateReceiptNumberAsync(),
                Status = Entities.PaymentStatus.Completed,
                Remarks = paymentData.Remarks,
                CollectedByStaffId = paymentData.CollectedByStaffId
            };

            return await _paymentRepository.AddAsync(payment);
        }

        /// <summary>
        /// Gets all payments for a student
        /// </summary>
        public async Task<IEnumerable<Entities.FeePayment>> GetStudentPaymentsAsync(int studentId)
        {
            return await _paymentRepository.GetPaymentsByStudentAsync(studentId);
        }

        /// <summary>
        /// Gets a specific payment
        /// </summary>
        public async Task<Entities.FeePayment?> GetPaymentByIdAsync(int paymentId)
        {
            return await _paymentRepository.GetByIdAsync(paymentId);
        }

        /// <summary>
        /// Applies a discount to a payment
        /// </summary>
        public async Task ApplyDiscountAsync(int paymentId, decimal discountAmount, string reason = "")
        {
            var payment = await _paymentRepository.GetByIdAsync(paymentId);
            if (payment == null)
                throw new InvalidOperationException($"Payment {paymentId} not found");

            payment.DiscountAmount = (payment.DiscountAmount ?? 0) + discountAmount;
            payment.Remarks += $" | Discount applied: {discountAmount} ({reason})";

            await _paymentRepository.UpdateAsync(payment);
        }

        /// <summary>
        /// Applies late fee to an installment
        /// </summary>
        public async Task ApplyLateFeeAsync(int installmentId, decimal lateFeeAmount)
        {
            var installment = await _installmentRepository.GetByIdAsync(installmentId);
            if (installment == null)
                throw new InvalidOperationException($"Installment {installmentId} not found");

            installment.LateFee = lateFeeAmount;
            await _installmentRepository.UpdateAsync(installment);
        }

        /// <summary>
        /// Generates a unique receipt number
        /// </summary>
        public async Task<string> GenerateReceiptNumberAsync()
        {
            return $"RCP{DateTime.UtcNow:yyyyMMddHHmmss}{Guid.NewGuid().ToString().Substring(0, 4).ToUpper()}";
        }

        /// <summary>
        /// Generates a PDF receipt for a payment (placeholder)
        /// </summary>
        public async Task<string> GenerateReceiptPdfAsync(int paymentId)
        {
            return $"Receipt_{paymentId}_{DateTime.UtcNow:yyyyMMdd}.pdf";
        }

        /// <summary>
        /// Gets all overdue installments for a student
        /// </summary>
        public async Task<IEnumerable<FeeInstallmentStatusDto>> GetOverdueInstallmentsAsync(int studentId)
        {
            var overview = await GetStudentFeeOverviewAsync(studentId);
            return overview.Installments.Where(i => i.IsOverdue);
        }

        /// <summary>
        /// Gets list of all students with overdue fees
        /// </summary>
        public async Task<IEnumerable<int>> GetStudentsWithOverdueFeesAsync()
        {
            return await Task.FromResult(Enumerable.Empty<int>());
        }
    }
}
