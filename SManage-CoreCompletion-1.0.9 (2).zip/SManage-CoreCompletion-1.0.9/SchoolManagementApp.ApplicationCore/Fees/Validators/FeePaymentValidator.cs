using FluentValidation;
using SchoolManagementApp.ApplicationCore.Fees.Dtos;

namespace SchoolManagementApp.ApplicationCore.Fees.Validators
{
    /// <summary>
    /// Deprecated - use FeesRequestValidators.ProcessPaymentRequestValidator instead
    /// </summary>
    [Obsolete("Use FeesRequestValidators.ProcessPaymentRequestValidator instead. This class will be removed in Phase 2.")]
    public class LegacyProcessPaymentValidator : AbstractValidator<ProcessPaymentRequest>
    {
        public LegacyProcessPaymentValidator()
        {
            RuleFor(x => x.StudentId).GreaterThan(0);
            RuleFor(x => x.Amount).GreaterThan(0);
            RuleFor(x => x.FeeType).NotEmpty();
        }
    }
}
