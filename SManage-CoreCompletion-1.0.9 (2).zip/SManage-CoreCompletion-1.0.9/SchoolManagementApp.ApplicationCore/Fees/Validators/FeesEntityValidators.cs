using FluentValidation;
using SchoolManagementApp.ApplicationCore.Entities;
using SchoolManagementApp.ApplicationCore.Fees.Dtos;

namespace SchoolManagementApp.ApplicationCore.Fees.Validators
{
    /// <summary>
    /// Validator for Fee entity
    /// </summary>
    public class FeeValidator : AbstractValidator<Fee>
    {
        public FeeValidator()
        {
            RuleFor(f => f.StudentId)
                .GreaterThan(0)
                .WithMessage("Student ID must be a valid positive number");

            RuleFor(f => f.FeeType)
                .NotEmpty()
                .MaximumLength(50)
                .WithMessage("Fee type is required and must be 50 characters or less");

            RuleFor(f => f.Amount)
                .GreaterThan(0)
                .WithMessage("Amount must be greater than 0");

            RuleFor(f => f.DueDate)
                .NotEmpty()
                .Must(d => d.Date >= DateTime.UtcNow.Date.AddDays(-1))
                .WithMessage("Due date must be today or in the future");

            RuleFor(f => f.Status)
                .NotEmpty()
                .MaximumLength(20)
                .WithMessage("Status is required");
        }
    }

    /// <summary>
    /// Validator for Payment entity
    /// </summary>
    public class PaymentValidator : AbstractValidator<Payment>
    {
        public PaymentValidator()
        {
            RuleFor(p => p.FeeId)
                .GreaterThan(0)
                .WithMessage("Fee ID must be a valid positive number");

            RuleFor(p => p.Amount)
                .GreaterThan(0)
                .WithMessage("Payment amount must be greater than 0");

            RuleFor(p => p.PaymentDate)
                .NotEmpty()
                .LessThanOrEqualTo(DateTime.UtcNow)
                .WithMessage("Payment date cannot be in the future");

            RuleFor(p => p.PaymentMethod)
                .NotEmpty()
                .MaximumLength(20)
                .WithMessage("Payment method is required");

            RuleFor(p => p.Status)
                .NotEmpty()
                .MaximumLength(20)
                .WithMessage("Status is required");

            RuleFor(p => p.ReceiptNumber)
                .NotEmpty()
                .MaximumLength(50)
                .WithMessage("Receipt number is required and must be 50 characters or less");

            When(p => !string.IsNullOrEmpty(p.TransactionId), () =>
            {
                RuleFor(p => p.TransactionId)
                    .MaximumLength(100)
                    .WithMessage("Transaction ID must be 100 characters or less");
            });
        }
    }

    /// <summary>
    /// Validator for FeePayment entity
    /// </summary>
    public class FeePaymentValidator : AbstractValidator<FeePayment>
    {
        public FeePaymentValidator()
        {
            RuleFor(fp => fp.StudentId)
                .GreaterThan(0)
                .WithMessage("Student ID must be a valid positive number");

            RuleFor(fp => fp.FeeInstallmentId)
                .GreaterThan(0)
                .WithMessage("Fee installment ID must be a valid positive number");

            RuleFor(fp => fp.AmountPaid)
                .GreaterThan(0)
                .WithMessage("Amount paid must be greater than 0");

            RuleFor(fp => fp.LateFeeAmount)
                .GreaterThanOrEqualTo(0)
                .WithMessage("Late fee amount must be non-negative");

            RuleFor(fp => fp.DiscountAmount)
                .GreaterThanOrEqualTo(0)
                .WithMessage("Discount amount must be non-negative");

            RuleFor(fp => fp.PaymentDate)
                .NotEmpty()
                .LessThanOrEqualTo(DateTime.UtcNow)
                .WithMessage("Payment date cannot be in the future");

            RuleFor(fp => fp.PaymentMethod)
                .IsInEnum()
                .WithMessage("Invalid payment method");

            RuleFor(fp => fp.ReceiptNumber)
                .NotEmpty()
                .MaximumLength(50)
                .WithMessage("Receipt number is required and must be 50 characters or less");

            RuleFor(fp => fp.Status)
                .IsInEnum()
                .WithMessage("Invalid payment status");

            When(fp => !string.IsNullOrEmpty(fp.TransactionId), () =>
            {
                RuleFor(fp => fp.TransactionId)
                    .MaximumLength(100)
                    .WithMessage("Transaction ID must be 100 characters or less");
            });

            When(fp => !string.IsNullOrEmpty(fp.Remarks), () =>
            {
                RuleFor(fp => fp.Remarks)
                    .MaximumLength(500)
                    .WithMessage("Remarks must be 500 characters or less");
            });
        }
    }
}