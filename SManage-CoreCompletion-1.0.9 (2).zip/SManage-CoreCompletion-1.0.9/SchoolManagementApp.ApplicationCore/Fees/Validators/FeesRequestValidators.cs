using FluentValidation;
using SchoolManagementApp.ApplicationCore.Entities;
using SchoolManagementApp.ApplicationCore.Fees.Dtos;
using SchoolManagementApp.ApplicationCore.Setup.Dtos;
using System.Linq;

namespace SchoolManagementApp.ApplicationCore.Fees.Validators
{
    /// <summary>
    /// Validator for CreateFeeStructureRequest
    /// </summary>
    public class CreateFeeStructureRequestValidator : AbstractValidator<CreateFeeStructureRequest>
    {
        public CreateFeeStructureRequestValidator()
        {
            RuleFor(f => f.Name)
                .NotEmpty()
                .MaximumLength(100)
                .WithMessage("Fee structure name is required and must be 100 characters or less");

            RuleFor(f => f.ClassId)
                .GreaterThan(0)
                .WithMessage("Valid class ID is required");

            RuleFor(f => f.AcademicYearId)
                .GreaterThan(0)
                .WithMessage("Valid academic year ID is required");

            RuleFor(f => f.AnnualFee)
                .GreaterThanOrEqualTo(0)
                .WithMessage("Annual fee must be a non-negative amount");

            RuleFor(f => f.RegistrationFee)
                .GreaterThanOrEqualTo(0)
                .WithMessage("Registration fee must be a non-negative amount");

            RuleFor(f => f.TransportFee)
                .GreaterThanOrEqualTo(0)
                .WithMessage("Transport fee must be a non-negative amount");

            RuleFor(f => f.UniformFee)
                .GreaterThanOrEqualTo(0)
                .WithMessage("Uniform fee must be a non-negative amount");

            RuleFor(f => f.ExaminationFee)
                .GreaterThanOrEqualTo(0)
                .WithMessage("Examination fee must be a non-negative amount");

            RuleFor(f => f.LibraryFee)
                .GreaterThanOrEqualTo(0)
                .WithMessage("Library fee must be a non-negative amount");

            RuleFor(f => f.ComputerFee)
                .GreaterThanOrEqualTo(0)
                .WithMessage("Computer fee must be a non-negative amount");

            RuleFor(f => f.LaboratoryFee)
                .GreaterThanOrEqualTo(0)
                .WithMessage("Laboratory fee must be a non-negative amount");

            RuleFor(f => f.SportsFee)
                .GreaterThanOrEqualTo(0)
                .WithMessage("Sports fee must be a non-negative amount");

            RuleFor(f => f.MiscellaneousFee)
                .GreaterThanOrEqualTo(0)
                .WithMessage("Miscellaneous fee must be a non-negative amount");

            // Total fee must have at least one component
            RuleFor(f => f)
                .Must(f => f.AnnualFee + f.RegistrationFee + f.TransportFee + f.UniformFee + f.ExaminationFee + f.LibraryFee + 
                          f.ComputerFee + f.LaboratoryFee + f.SportsFee + f.MiscellaneousFee > 0)
                .WithMessage("At least one fee component must be greater than 0");

            // Installment amounts must exactly match the total fee (mismatch breaks
            // fee assignment and installment payment calculations downstream)
            RuleFor(f => f)
                .Must(f =>
                {
                    var totalFee = f.AnnualFee + f.RegistrationFee + f.TransportFee + f.UniformFee + f.ExaminationFee +
                                   f.LibraryFee + f.ComputerFee + f.LaboratoryFee + f.SportsFee + f.MiscellaneousFee;

                    // No installments supplied: allowed here (service generates an even split)
                    if (f.Installments == null || f.Installments.Count == 0)
                        return true;

                    var installmentTotal = f.Installments.Sum(i => i.Amount);
                    return installmentTotal == totalFee;
                })
                .WithMessage(f =>
                {
                    var totalFee = f.AnnualFee + f.RegistrationFee + f.TransportFee + f.UniformFee + f.ExaminationFee +
                                   f.LibraryFee + f.ComputerFee + f.LaboratoryFee + f.SportsFee + f.MiscellaneousFee;
                    var installmentTotal = f.Installments?.Sum(i => i.Amount) ?? 0m;
                    var diff = installmentTotal - totalFee;
                    return diff > 0
                        ? $"The sum of installment amounts ({installmentTotal:N2}) exceeds the total fee ({totalFee:N2}). Installments must total exactly {totalFee:N2}."
                        : $"The sum of installment amounts ({installmentTotal:N2}) is less than the total fee ({totalFee:N2}). Installments must total exactly {totalFee:N2}.";
                });
        }
    }

    /// <summary>
    /// Validator for CreateInstallmentRequest
    /// </summary>
    public class CreateInstallmentRequestValidator : AbstractValidator<CreateInstallmentRequest>
    {
        public CreateInstallmentRequestValidator()
        {
            RuleFor(i => i.Name)
                .NotEmpty()
                .MaximumLength(100)
                .WithMessage("Installment name is required and must be 100 characters or less");

            RuleFor(i => i.Amount)
                .GreaterThan(0)
                .WithMessage("Installment amount must be greater than 0");

            RuleFor(i => i.DueDate)
                .NotEmpty()
                .GreaterThanOrEqualTo(DateTime.UtcNow.Date)
                .WithMessage("Due date must be today or in the future");

            RuleFor(i => i.LateFee)
                .GreaterThanOrEqualTo(0)
                .WithMessage("Late fee must be a non-negative amount");

            RuleFor(i => i.GracePeriodDays)
                .GreaterThanOrEqualTo(0)
                .LessThanOrEqualTo(365)
                .WithMessage("Grace period days must be between 0 and 365");
        }
    }

    /// <summary>
    /// Validator for ProcessPaymentRequest
    /// </summary>
    public class ProcessPaymentRequestValidator : AbstractValidator<ProcessPaymentRequest>
    {
        public ProcessPaymentRequestValidator()
        {
            RuleFor(p => p.StudentId)
                .GreaterThan(0)
                .WithMessage("Valid student ID is required");

            RuleFor(p => p.FeeInstallmentId)
                .GreaterThan(0)
                .WithMessage("Valid fee installment ID is required");

            RuleFor(p => p.AmountPaid)
                .GreaterThan(0)
                .WithMessage("Payment amount must be greater than 0")
                .LessThanOrEqualTo(999999.99m)
                .WithMessage("Payment amount cannot exceed ₹999,999.99");

            RuleFor(p => p.LateFeeAmount)
                .GreaterThanOrEqualTo(0)
                .WithMessage("Late fee amount must be non-negative");

            RuleFor(p => p.DiscountAmount)
                .GreaterThanOrEqualTo(0)
                .WithMessage("Discount amount must be non-negative");

            RuleFor(p => p.PaymentMethod)
                .IsInEnum()
                .WithMessage("Invalid payment method");

            // Transaction ID is required for online payments
            When(p => p.PaymentMethod != PaymentMethodType.Cash && p.PaymentMethod != PaymentMethodType.Cheque, () =>
            {
                RuleFor(p => p.TransactionId)
                    .NotEmpty()
                    .WithMessage("Transaction ID is required for online payments");
            });

            When(p => !string.IsNullOrEmpty(p.TransactionId), () =>
            {
                RuleFor(p => p.TransactionId)
                    .MaximumLength(100)
                    .WithMessage("Transaction ID must be 100 characters or less");
            });

            When(p => !string.IsNullOrEmpty(p.Remarks), () =>
            {
                RuleFor(p => p.Remarks)
                    .MaximumLength(500)
                    .WithMessage("Remarks must be 500 characters or less");
            });

            // Total payment should be reasonable (handle null fee/discount amounts)
            RuleFor(p => p)
                .Must(p => p.AmountPaid >= ((p.LateFeeAmount ?? 0) + (p.DiscountAmount ?? 0)))
                .WithMessage("Amount paid must be greater than or equal to late fee and discount amounts");
        }
    }

    /// <summary>
    /// Validator for CreateScholarshipRequest
    /// </summary>
    public class CreateScholarshipRequestValidator : AbstractValidator<CreateScholarshipRequest>
    {
        public CreateScholarshipRequestValidator()
        {
            RuleFor(s => s.Name)
                .NotEmpty()
                .MaximumLength(100)
                .WithMessage("Scholarship name is required and must be 100 characters or less");

            RuleFor(s => s.Amount)
                .GreaterThan(0)
                .WithMessage("Scholarship amount must be greater than 0");

            When(s => !s.IsPercentage, () =>
            {
                RuleFor(s => s.Amount)
                    .LessThanOrEqualTo(999999.99m)
                    .WithMessage("Scholarship amount cannot exceed ₹999,999.99");
            });

            When(s => s.IsPercentage, () =>
            {
                RuleFor(s => s.Amount)
                    .LessThanOrEqualTo(100)
                    .WithMessage("Percentage scholarship cannot exceed 100%");
            });

            RuleFor(s => s.ApplicationStartDate)
                .NotEmpty()
                .GreaterThanOrEqualTo(DateTime.UtcNow.Date)
                .WithMessage("Application start date must be today or in the future");

            RuleFor(s => s.ApplicationEndDate)
                .NotEmpty()
                .GreaterThan(s => s.ApplicationStartDate)
                .WithMessage("Application end date must be after start date");

            RuleFor(s => s.MaxBeneficiaries)
                .GreaterThan(0)
                .WithMessage("Max beneficiaries must be greater than 0");
        }
    }

    /// <summary>
    /// Validator for CreateExpenseRequest
    /// </summary>
    public class CreateExpenseRequestValidator : AbstractValidator<CreateExpenseRequest>
    {
        public CreateExpenseRequestValidator()
        {
            RuleFor(e => e.Title)
                .NotEmpty()
                .MaximumLength(100)
                .WithMessage("Expense title is required and must be 100 characters or less");

            RuleFor(e => e.Amount)
                .GreaterThan(0)
                .WithMessage("Expense amount must be greater than 0");

            RuleFor(e => e.Category)
                .IsInEnum()
                .WithMessage("Invalid expense category");

            RuleFor(e => e.ExpenseDate)
                .NotEmpty()
                .LessThanOrEqualTo(DateTime.UtcNow)
                .WithMessage("Expense date cannot be in the future");

            RuleFor(e => e.VoucherNumber)
                .MaximumLength(50)
                .WithMessage("Voucher number must be 50 characters or less");

            RuleFor(e => e.VendorName)
                .NotEmpty()
                .MaximumLength(100)
                .WithMessage("Vendor name is required and must be 100 characters or less");
        }
    }

    /// <summary>
    /// Validator for CreateBudgetRequest
    /// </summary>
    public class CreateBudgetRequestValidator : AbstractValidator<CreateBudgetRequest>
    {
        public CreateBudgetRequestValidator()
        {
            RuleFor(b => b.Name)
                .NotEmpty()
                .MaximumLength(100)
                .WithMessage("Budget name is required and must be 100 characters or less");

            RuleFor(b => b.AcademicYearId)
                .GreaterThan(0)
                .WithMessage("Valid academic year ID is required");

            RuleFor(b => b.AllocatedAmount)
                .GreaterThan(0)
                .WithMessage("Allocated amount must be greater than 0");

            RuleFor(b => b.Category)
                .NotEmpty()
                .IsInEnum()
                .WithMessage("Budget category must be a valid expense category");
        }
    }
}