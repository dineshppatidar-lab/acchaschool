using SchoolManagementApp.ApplicationCore.Fees.Dtos;
using SchoolManagementApp.ApplicationCore.Entities;

namespace SchoolManagementApp.ApplicationCore.Fees.Interfaces
{
    /// <summary>
    /// Canonical Advanced Finance App Service interface (new pattern)
    /// </summary>
    public interface IAdvancedFinanceService
    {
        // Fee Structure Management
        Task<IEnumerable<FeeStructure>> GetAllFeeStructuresAsync();
        Task<FeeStructure> CreateFeeStructureAsync(FeeStructure feeStructure);
        Task DeleteFeeStructureAsync(int id);

        // Fee Assignment
        Task<IEnumerable<object>> GetFeeAssignmentsAsync();
        Task<StudentFeeAssignment> AssignFeeToStudentAsync(StudentFeeAssignment assignment);

        // Payment Processing
        Task<FeePayment> ProcessPaymentAsync(FeePayment payment);
        Task<IEnumerable<FeePayment>> GetPaymentsAsync();
        Task<IEnumerable<FeeInstallmentDto>> GetStudentFeeInstallmentsAsync(int studentId);
        Task<OutstandingFeesDto> GetOutstandingFeesAsync(int studentId);
        Task<IEnumerable<object>> GetPaymentMethodsAsync();

        // Refund Management
        Task<object> CreateRefundAsync(FeeRefund refund);
        Task<IEnumerable<FeeRefund>> GetStudentRefundsAsync(int studentId);
        Task<object> GetRefundableBalanceAsync(int studentId);

        // Scholarship Management
        Task<IEnumerable<Scholarship>> GetScholarshipsAsync();
        Task<Scholarship> CreateScholarshipAsync(Scholarship scholarship);
        Task<ScholarshipApplication> ApplyForScholarshipAsync(ScholarshipApplication application);

        // Expense Management
        Task<IEnumerable<Expense>> GetExpensesAsync();
        Task<Expense?> GetExpenseByIdAsync(int expenseId);
        Task<Expense> CreateExpenseAsync(Expense expense, int requestedByStaffId);
        Task<Expense?> ApproveExpenseAsync(int expenseId, string approvedBy, string approvalRemarks, int approvedByStaffId);
        Task<Expense?> RejectExpenseAsync(int expenseId, string approvedBy, string approvalRemarks, int approvedByStaffId);

        // Budget Management
        Task<IEnumerable<Budget>> GetBudgetsAsync();
        Task<Budget> CreateBudgetAsync(Budget budget, int createdByStaffId);

        // Fee Rules
        Task<IEnumerable<FeeRule>> GetFeeRulesAsync(int? ruleType);
        Task<FeeRule?> GetFeeRuleByIdAsync(int id);
        Task<FeeRule> CreateFeeRuleAsync(FeeRule rule);
        Task<FeeRule?> UpdateFeeRuleAsync(int id, FeeRule rule);
        Task<bool> DeleteFeeRuleAsync(int id);

        // Notifications (due reminders)
        Task<int> QueueDueRemindersAsync(int daysAhead);

        // Analytics
        Task<FinancialSummaryDto> GetFinancialSummaryAsync();
        Task<object> GetDefaultersAsync(int page, int pageSize, int minDaysOverdue);

        // Staff / user resolution (shadow FK stamps for Expenses/Budgets)
        Task<int> ResolveCurrentStaffIdAsync(int userId, string? email);

        // Student Lookups
        Task<IEnumerable<object>> GetStudentsAvailableForFeesAsync();
        Task<IEnumerable<object>> SearchStudentsAsync(string query, int? academicYearId);

        // Ledger
        Task<object> GetStudentLedgerAsync(int studentId);
    }

    ///// <summary>
    ///// Deprecated - use IAdvancedFinanceAppService instead
    ///// </summary>
    //[Obsolete("Use IAdvancedFinanceAppService instead. This interface will be removed in Phase 2.")]
    //public interface IAdvancedFinanceService : IAdvancedFinanceAppService { }
}
