using SchoolManagementApp.ApplicationCore.Entities;
using SchoolManagementApp.ApplicationCore.Fees.Dtos;

namespace SchoolManagementApp.ApplicationCore.Fees.Interfaces
{
    /// <summary>
    /// Canonical Group Payment App Service interface (new pattern)
    /// </summary>
    public interface IGroupPaymentService
    {
        Task<GroupPayment> InitiateGroupPaymentAsync(InitiateGroupPaymentRequest request);
        Task<GroupPaymentProcessResult> ProcessGroupPaymentAsync(ProcessGroupPaymentRequest request);
        Task<GroupPaymentReceiptDto?> GetGroupPaymentReceiptAsync(int groupPaymentId);
        Task<FamilyPaymentSummaryDto?> GetFamilyPaymentSummaryAsync(int familyGroupId, int academicYearId);
        string GenerateReceiptHtml(GroupPayment gp);
    }

    ///// <summary>
    ///// Deprecated - use IGroupPaymentAppService instead
    ///// </summary>
    //[Obsolete("Use IGroupPaymentAppService instead. This interface will be removed in Phase 2.")]
    //public interface IGroupPaymentService : IGroupPaymentAppService { }
}
