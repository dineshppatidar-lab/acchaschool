using SchoolManagementApp.ApplicationCore.Fees.Dtos;

namespace SchoolManagementApp.ApplicationCore.Fees.Interfaces
{
    /// <summary>
    /// Service interface for Fee Adjustment operations (waivers, discounts, calculations)
    /// Moved from Students/Interfaces/ per CorporateFleet module pattern.
    /// </summary>
    public interface IFeeAdjustmentAppService
    {
        // Waiver Operations
        Task<StudentFeeAdjustment> CreateOrUpdateWaiverAsync(CreateWaiverRequest request);
        Task<StudentFeeAdjustment?> GetActiveWaiverAsync(int studentId, int academicYearId);

        // Discount Operations
        Task<StudentFeeAdjustment> CreateOrUpdateDiscountAsync(CreateDiscountRequest request);
        Task<IEnumerable<StudentFeeAdjustment>> GetActiveDiscountsAsync(int studentId, int academicYearId);

        // Calculation Operations
        Task<StudentFinalFeeDto> CalculateFinalStudentFeesAsync(int studentId, int academicYearId);
        Task<decimal> CalculateOutstandingBalanceAsync(int studentId, int academicYearId);

        // Adjustment Management
        Task<bool> RevokeAdjustmentAsync(int adjustmentId);
        Task<IEnumerable<StudentFeeAdjustment>> GetStudentAdjustmentsAsync(int studentId, int academicYearId);
    }
}
