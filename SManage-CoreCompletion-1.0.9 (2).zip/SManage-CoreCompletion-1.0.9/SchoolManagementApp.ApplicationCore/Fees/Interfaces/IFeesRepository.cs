using SchoolManagementApp.ApplicationCore.Fees.Dtos;

namespace SchoolManagementApp.ApplicationCore.Fees.Interfaces
{
    public interface IFeesRepository
    {
        Task<(IEnumerable<Fee>, int)> GetFeesAsync(int page, int pageSize, string sort, string order, string search);
        Task<Fee> GetFeeByIdAsync(int id);
        Task<Fee> CreateFeeAsync(Fee fee);
        Task UpdateFeeAsync(Fee fee);
        Task DeleteFeeAsync(int id);
    }

    public interface IFeeStructureRepository : IGenericRepository<FeeStructure>
    {
        Task<FeeStructure> GetFeeStructureByClassAndYearAsync(int classId, int academicYearId);
        Task<(IEnumerable<FeeStructure>, int)> GetFeeStructuresByAcademicYearAsync(int academicYearId, int page = 1, int pageSize = 1000);
        Task<IEnumerable<FeeStructure>> GetActiveFeeStructuresAsync();
    }

    public interface IFeeInstallmentRepository : IGenericRepository<FeeInstallment>
    {
        Task<IEnumerable<FeeInstallment>> GetInstallmentsByFeeStructureAsync(int feeStructureId);
        Task<IEnumerable<FeeInstallment>> GetDueInstallmentsAsync();
        Task<IEnumerable<FeeInstallment>> GetOverdueInstallmentsAsync();

        /// <summary>
        /// Overdue installments (due date + grace period before <paramref name="today"/>)
        /// joined with the assigned active student and class — used by the defaulters report.
        /// </summary>
        Task<IEnumerable<DefaulterRowDto>> GetOverdueInstallmentRowsAsync(DateTime today);
    }

    public interface IFeePaymentRepository : IGenericRepository<FeePayment>
    {
        /// <summary>
        /// Successful payments in a date range (tenant-scoped) with the data
        /// needed by the fee report (student + installment included).
        /// </summary>
        Task<IEnumerable<FeePayment>> GetSuccessfulPaymentsWithDetailsAsync(DateTime startDate, DateTime endDate);
        Task<IEnumerable<FeePayment>> GetPaymentsByStudentAsync(int studentId);
        Task<(IEnumerable<FeePayment>, int)> GetPaymentsByDateRangeAsync(DateTime startDate, DateTime endDate, int page = 1, int pageSize = 10);
        Task<IEnumerable<FeePayment>> GetPaymentsByInstallmentAsync(int installmentId);
        Task<decimal> GetTotalCollectionAsync(DateTime? startDate = null, DateTime? endDate = null);
        Task<IEnumerable<FeePayment>> GetPaymentsByMethodAsync(PaymentMethodType method);

        /// <summary>Sum of completed payments per installment for the current tenant.</summary>
        Task<Dictionary<int, decimal>> GetPaidTotalsByInstallmentAsync();
    }

    public interface IFeeRefundRepository : IGenericRepository<FeeRefund>
    {
        Task<IEnumerable<FeeRefund>> GetRefundsByStudentAsync(int studentId);
        Task<IEnumerable<FeeRefund>> GetRefundsByPaymentAsync(int paymentId);
        Task<decimal> GetTotalRefundsAsync(DateTime? startDate = null, DateTime? endDate = null);
    }

    public interface IScholarshipRepository : IGenericRepository<Scholarship>
    {
        Task<IEnumerable<Scholarship>> GetActiveScholarshipsAsync();
        Task<IEnumerable<Scholarship>> GetScholarshipsByTypeAsync(ScholarshipType type);
    }

    public interface IScholarshipApplicationRepository : IGenericRepository<ScholarshipApplication>
    {
        Task<IEnumerable<ScholarshipApplication>> GetApplicationsByScholarshipAsync(int scholarshipId);
        Task<IEnumerable<ScholarshipApplication>> GetApplicationsByStudentAsync(int studentId);
        Task<IEnumerable<ScholarshipApplication>> GetPendingApplicationsAsync();
    }

    public interface IExpenseRepository : IGenericRepository<Expense>
    {
        Task<IEnumerable<Expense>> GetExpensesByDateRangeAsync(DateTime startDate, DateTime endDate);
        Task<IEnumerable<Expense>> GetExpensesByCategoryAsync(ExpenseCategory category);
        Task<decimal> GetTotalExpensesAsync(DateTime? startDate = null, DateTime? endDate = null);
        Task<IEnumerable<Expense>> GetPendingExpensesAsync();

        /// <summary>Stamps the shadow FK Expenses.RequestedByStaffId (NOT-NULL FK to Staff).</summary>
        Task SetRequestedByStaffAsync(Expense expense, int staffId);

        /// <summary>Stamps the shadow FK Expenses.ApprovedByStaffId.</summary>
        Task SetApprovedByStaffAsync(Expense expense, int staffId);
    }

    public interface IBudgetRepository : IGenericRepository<Budget>
    {
        Task<IEnumerable<Budget>> GetBudgetsByAcademicYearAsync(int academicYearId);
        Task<Budget> GetBudgetByCategoryAsync(int academicYearId, ExpenseCategory category);
        Task<IEnumerable<Budget>> GetActiveBudgetsAsync();

        /// <summary>Stamps the shadow FK Budgets.CreatedByStaffId (NOT-NULL FK to Staff).</summary>
        Task SetCreatedByStaffAsync(Budget budget, int staffId);
    }

    public interface IInvoiceRepository : IGenericRepository<Invoice>
    {
        Task<IEnumerable<Invoice>> GetInvoicesByStudentAsync(int studentId);
        Task<IEnumerable<Invoice>> GetInvoicesByStatusAsync(InvoiceStatus status);
        Task<IEnumerable<Invoice>> GetOverdueInvoicesAsync();
        Task<Invoice> GetInvoiceWithItemsAsync(int id);
    }

    public interface IFeeRuleRepository : IGenericRepository<FeeRule>
    {
        /// <summary>All rules (including inactive ones), optionally filtered by type, ordered by priority.</summary>
        Task<IEnumerable<FeeRule>> GetAllRulesAsync(int? ruleType = null);
        Task<IEnumerable<FeeRule>> GetActiveRulesAsync();
        Task<IEnumerable<FeeRule>> GetRulesByTypeAsync(FeeRuleType ruleType);
        Task<IEnumerable<FeeRule>> GetApplicableRulesAsync(int? classId, int? academicYearId);
        Task<decimal> ApplyLateFeesAsync(int installmentId, int daysOverdue);
    }

    public interface IStudentLedgerRepository : IGenericRepository<StudentLedger>
    {
        Task<IEnumerable<StudentLedger>> GetLedgerByStudentAsync(int studentId);
        Task<IEnumerable<StudentLedger>> GetLedgerByDateRangeAsync(int studentId, DateTime startDate, DateTime endDate);
        Task<decimal> GetRunningBalanceAsync(int studentId);
        Task<StudentLedger> AddDebitEntryAsync(int studentId, decimal amount, string description, string refType, int? refId, string createdBy);
        Task<StudentLedger> AddCreditEntryAsync(int studentId, decimal amount, string description, string refType, int? refId, string createdBy);
    }

    public interface IFeeNotificationLogRepository : IGenericRepository<FeeNotificationLog>
    {
        Task<IEnumerable<FeeNotificationLog>> GetNotificationsByStudentAsync(int studentId);
        Task<IEnumerable<FeeNotificationLog>> GetPendingNotificationsAsync();
        Task<IEnumerable<FeeNotificationLog>> GetByTypeAsync(FeeNotificationType type);

        /// <summary>
        /// Active installment/student pairs due within [today, horizon], or overdue
        /// (due before today) when <paramref name="overdueOnly"/> is set — reminder targets.
        /// </summary>
        Task<IEnumerable<DueReminderTargetDto>> GetDueReminderTargetsAsync(DateTime today, DateTime horizon, bool overdueOnly);

        /// <summary>Whether a sent DueReminder already exists for the student + installment pair.</summary>
        Task<bool> HasSentReminderAsync(int studentId, int installmentId);
    }

    public interface IMultiInstallmentPaymentRepository : IGenericRepository<MultiInstallmentPayment>
    {
        Task<IEnumerable<MultiInstallmentPayment>> GetByStudentAsync(int studentId);
    }

    public interface IFinanceAuditLogRepository : IGenericRepository<FinanceAuditLog>
    {
        Task<IEnumerable<FinanceAuditLog>> GetByEntityAsync(string entityType, int entityId);
        Task<IEnumerable<FinanceAuditLog>> GetRecentActionsAsync(int count = 50);
    }

    public interface IStudentFeeAdjustmentRepository : IGenericRepository<StudentFeeAdjustment>
    {
        Task<IEnumerable<StudentFeeAdjustment>> GetByStudentAsync(int studentId, int academicYearId);
        Task<StudentFeeAdjustment?> GetActiveWaiverAsync(int studentId, int academicYearId);
        Task<IEnumerable<StudentFeeAdjustment>> GetActiveDiscountsAsync(int studentId, int academicYearId);
        Task<IEnumerable<StudentFeeAdjustment>> GetExpiredAdjustmentsAsync();
        Task<IEnumerable<StudentFeeAdjustment>> GetPendingApprovalAsync();
        Task<decimal> GetTotalActiveDiscountAsync(int studentId, int academicYearId, decimal baseAmount);
        Task<IEnumerable<StudentFeeAdjustment>> GetWaiversAsync();
        Task<IEnumerable<StudentFeeAdjustment>> GetDiscountsAsync();
    }

    public interface IGroupPaymentRepository : IGenericRepository<GroupPayment>
    {
        Task<IEnumerable<GroupPayment>> GetByFamilyGroupAsync(int familyGroupId);
        Task<IEnumerable<GroupPayment>> GetByDateRangeAsync(DateTime startDate, DateTime endDate);
        Task<decimal> GetTotalGroupPaymentsAsync(int familyGroupId);
        Task<GroupPayment?> GetWithAllocationsByIdAsync(int id);
        Task<GroupPayment?> ProcessGroupPaymentAsync(GroupPayment groupPayment);
        Task<FamilyPaymentSummaryDto> GetFamilyPaymentSummaryAsync(int familyGroupId, int academicYearId);
    }

    public interface IGroupPaymentAllocationRepository : IGenericRepository<GroupPaymentAllocation>
    {
        Task<IEnumerable<GroupPaymentAllocation>> GetByGroupPaymentAsync(int groupPaymentId);
        Task<IEnumerable<GroupPaymentAllocation>> GetByStudentAsync(int studentId);
        Task<GroupPaymentAllocation?> GetByFeePaymentAsync(int feePaymentId);
        Task<decimal> GetTotalAllocatedToStudentAsync(int studentId, int academicYearId);
    }
}
