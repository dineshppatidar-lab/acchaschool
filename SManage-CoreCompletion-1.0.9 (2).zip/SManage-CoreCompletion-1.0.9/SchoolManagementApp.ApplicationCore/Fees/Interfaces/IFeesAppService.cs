using SchoolManagementApp.ApplicationCore.Fees.Dtos;
using SchoolManagementApp.ApplicationCore.Entities;

namespace SchoolManagementApp.ApplicationCore.Fees.Interfaces
{
    /// <summary>
    /// Service interface for Fees operations
    /// Moved from Students/Interfaces/ per CorporateFleet module pattern.
    /// </summary>
    public interface IFeesAppService
    {
        // Fee CRUD Operations
        Task<(IEnumerable<Fee> Fees, int Total)> GetFeesAsync(
            int page, int pageSize, string sort, string order, string search);
        Task<Fee?> GetFeeByIdAsync(int id);
        Task<Fee> CreateFeeAsync(Fee fee);
        Task UpdateFeeAsync(Fee fee);
        Task DeleteFeeAsync(int id);

        // Waiver Operations
        Task<IEnumerable<StudentFeeAdjustment>> GetWaiversAsync(
            int? studentId = null, int? academicYearId = null, string status = "all");
        Task<StudentFeeAdjustment> CreateWaiverAsync(CreateWaiverRequest request);
        Task<StudentFeeAdjustment?> GetWaiverByIdAsync(int id);
        Task UpdateWaiverAsync(int id, StudentFeeAdjustmentDto dto);
        Task DeleteWaiverAsync(int id);

        // Discount Operations
        Task<IEnumerable<StudentFeeAdjustment>> GetDiscountsAsync(
            int? studentId = null, int? academicYearId = null, string status = "all");
        Task<StudentFeeAdjustment> CreateDiscountAsync(CreateDiscountRequest request);
        Task<StudentFeeAdjustment?> GetDiscountByIdAsync(int id);
        Task UpdateDiscountAsync(int id, CreateDiscountRequest request);
        Task DeleteDiscountAsync(int id);

        // Family Payment Operations
        Task<FamilyPaymentSummaryDto?> GetFamilyMembersFeesAsync(int familyId);
        Task<GroupPaymentProcessResult> ProcessFamilyPaymentAsync(ProcessGroupPaymentRequest request);

        // Receipt Generation
        string GenerateReceiptHtml(Fee fee);
    }
}
