using AutoMapper;
using SchoolManagementApp.ApplicationCore.Entities;
using SchoolManagementApp.ApplicationCore.Fees.Dtos;

namespace SchoolManagementApp.ApplicationCore.Fees
{
    public class FeesObjectMapping : Profile
    {
        public FeesObjectMapping()
        {
            CreateMap<FeeStructure, FeeDto>().ReverseMap();
            CreateMap<PaymentMethod, PaymentMethodDto>().ReverseMap();
        }
    }
}
