#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';

const root = 'src/app/features';
function walk(d) {
  return fs.readdirSync(d, { withFileTypes: true }).flatMap(e =>
    e.isDirectory() ? walk(path.join(d, e.name)) : [path.join(d, e.name)]);
}

let repaired = 0, files = 0;
const still = [];

for (const f of walk(root).filter(x => x.endsWith('.html'))) {
  const ts = f.replace(/\.html$/, '.ts');
  if (!fs.existsSync(ts)) continue;
  const tss = fs.readFileSync(ts, 'utf8');
  const sigProps = [...tss.matchAll(/(?:^|\s)(?:readonly\s+)?(\w+)\s*(?::[^=;]+)?=\s*signal\s*[<(]/g)].map(m => m[1]);
  if (!sigProps.length) continue;

  let s = fs.readFileSync(f, 'utf8');
  let changed = false;

  const out = s.replace(/([@#*]?[\w-]+)="([^"]*)"/g, (m, name, val) => {
    if (/^[\[@#*]/.test(name)) return m; // bindings/structural = template code
    const parts = val.split(/(\{\{[^}]*\}\})/);
    let touched = false;
    for (let i = 0; i < parts.length; i++) {
      if (parts[i].includes('{{')) continue;
      let seg = parts[i];
      for (const p of sigProps) {
        const r = new RegExp('(?<![\\w$.])' + p + '\\(\\)', 'g');
        if (r.test(seg)) { seg = seg.replace(r, p); touched = true; }
      }
      parts[i] = seg;
    }
    if (touched) { repaired++; return name + '="' + parts.join('') + '"'; }
    return m;
  });

  if (changed || out !== s) { fs.writeFileSync(f, out); files++; }

  // verify pass
  const v = fs.readFileSync(f, 'utf8');
  for (const m of v.matchAll(/([@#*]?[\w-]+)="([^"]*)"/g)) {
    const name = m[1], val = m[2];
    if (/^[\[@#*]/.test(name)) continue;
    const segs = val.includes('{{') ? val.split(/\{\{[^}]*\}\}/).filter(x => !x.includes('{{')) : [val];
    for (const seg of segs) for (const p of sigProps) {
      if (new RegExp('(?<![\\w$.])' + p + '\\(\\)').test(seg)) still.push(f + ': ' + name + '="' + val.slice(0, 50) + '"');
    }
  }
}

console.log('attr repairs:', repaired, '| files touched:', files);
console.log(still.length ? 'STILL DAMAGED:\n' + [...new Set(still)].join('\n') : 'VERIFIED CLEAN');
