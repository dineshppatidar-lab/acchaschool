#!/usr/bin/env node
/**
 * Codemod: convert plain-property async state to Angular signals.
 *
 * Scope per file: properties written inside async callbacks
 * (subscribe/then/catch/finally/afterClosed/setTimeout/setInterval/
 * queueMicrotask/valueChanges) plus a flag-name whitelist, provided they are
 * declared as class fields and are not @Input/@Output/@ViewChild/getters/
 * observables (trailing $).
 *
 * Transforms:
 *  - TS: decl -> signal(init), writes -> .set(), compound ops -> .update(),
 *    array in-place methods -> .update(arr => {...}), reads this.x -> this.x(),
 *    optional chains this.x?. -> this.x()?.  (string/comment/template aware)
 *  - HTML (standalone files + inline `template:` literals): reads inside
 *    bindings and interpolations -> x(), event-handler writes -> x.set(...),
 *    [(ngModel)] split. Skips props shadowed by template aliases.
 *
 * Idempotence guard: declarations already initialised with signal( are skipped.
 * Usage: node scripts/signals-codemod.mjs <fileOrDir...>
 */
import fs from 'node:fs';
import path from 'node:path';

const ROOT = process.cwd();
const report = [];

const FLAG_RE = /^(loading|isLoading|isFetching|isProcessing|isSaving|saving|isSubmitting|submitting|deleting|isDeleting|isSearching|error|errorMessage|success|successMessage|showPasswordStrength|passwordStrength|passwordStrengthLabel|passwordStrengthColor|isEditMode|showForm|showModal|showDialog)$|^isLoading[A-Z]\w*$|^loading[A-Z]\w*$|^is[A-Z]\w*(Loading|Saving|Submitting|Processing)$/;
const TRIGGER_RE = /\.(subscribe|then|catch|finally)\(|afterClosed\(|setTimeout\(|setInterval\(|queueMicrotask\(|valueChanges\.(pipe|subscribe)\b/;
const ASYNC_WINDOW = 40;
const ARRAY_METHODS = 'push|unshift|splice|sort|reverse|fill|shift|pop';

function walkFiles(targets, ext, out) {
  for (const t of targets) {
    const abs = path.resolve(ROOT, t);
    const st = fs.statSync(abs);
    if (st.isDirectory()) {
      walkFiles(fs.readdirSync(abs).map(f => path.join(t, f)), ext, out);
    } else if (abs.endsWith(ext)) out.push(abs);
  }
  return out;
}

/* ---------- char-walker: identify strings / comments / template-literals ---------- */
function scanRegions(src) {
  const strings = [], comments = [], tplCode = [], inlineTemplates = [];
  const stack = []; // open ${ inside template literals: {braceDepth}
  let state = 'code', strStart = -1, braceDepth = 0;
  let tplIsInlineHtml = false, lastSig = '';
  let i = 0;
  const n = src.length;
  while (i < n) {
    const c = src[i], c2 = src.substr(i, 2);
    if (state === 'code') {
      if (c2 === '//') { const e = src.indexOf('\n', i); const end = e === -1 ? n : e; comments.push([i, end]); i = end; continue; }
      if (c2 === '/*') { const e = src.indexOf('*/', i); const end = e === -1 ? n : e + 2; comments.push([i, end]); i = end; continue; }
      if (c === "'") { state = 'sq'; strStart = i; tplIsInlineHtml = false; i++; continue; }
      if (c === '"') { state = 'dq'; strStart = i; tplIsInlineHtml = false; i++; continue; }
      if (c === '`') { state = 'tpl'; strStart = i; tplIsInlineHtml = /template\s*:\s*$/.test(lastSig); i++; continue; }
      if (c === '{') { braceDepth++; lastSig = (lastSig + c).slice(-24); i++; continue; }
      if (c === '}') {
        // entering ${ pushed the pre-increment depth, so the interpolation's
        // closing } is at pushed+1 (nested braces inside balance out)
        if (stack.length && stack[stack.length - 1] === braceDepth - 1) {
          tplCode.push([strStart, i]); // strStart currently holds ${-code start
          stack.pop(); braceDepth--; state = 'tpl'; i++; continue;
        }
        braceDepth = Math.max(0, braceDepth - 1);
        lastSig = (lastSig + c).slice(-24); i++; continue;
      }
      if (!/\s/.test(c)) lastSig = (lastSig + c).slice(-24);
      i++; continue;
    }
    if (state === 'sq' || state === 'dq') {
      if (c === '\\') { i += 2; continue; }
      if ((state === 'sq' && c === "'") || (state === 'dq' && c === '"')) { strings.push([strStart, i + 1]); state = 'code'; i++; continue; }
      i++; continue;
    }
    if (state === 'tpl') {
      if (c === '\\') { i += 2; continue; }
      if (c === '`') {
        strings.push([strStart, i + 1]);
        if (tplIsInlineHtml) inlineTemplates.push([strStart, i + 1]);
        tplIsInlineHtml = false; state = 'code'; i++; continue;
      }
      if (c2 === '${') { stack.push(braceDepth); braceDepth++; strStart = i + 2; state = 'code'; i += 2; continue; }
      i++; continue;
    }
  }
  return { strings, comments, tplCode, inlineTemplates };
}

/* ---------- discovery ---------- */
function discoverAsyncProps(src) {
  const lines = src.split('\n');
  const props = new Set();
  for (let i = 0; i < lines.length; i++) {
    if (!TRIGGER_RE.test(lines[i])) continue;
    for (let j = i; j < Math.min(lines.length, i + 1 + ASYNC_WINDOW); j++) {
      const L = lines[j];
      if (j > i && (/^  (public|private|protected|async)\b|^  [A-Za-z_$][\w$]*\s*\(|^  \}\)/.test(L) || /^  \}$/.test(L))) break;
      for (const w of L.matchAll(/this\.(\w+)\s*(\?\.)?\s*=(?![=>])/g)) props.add(w[1]);
      for (const w of L.matchAll(new RegExp(`this\\.(\\w+)\\.(${ARRAY_METHODS})\\(`, 'g'))) props.add(w[1]);
      // already-converted writes (idempotence / html pass after ts pass)
      for (const w of L.matchAll(/this\.(\w+)\.(?:set|update)\(/g)) props.add(w[1]);
    }
  }
  return props;
}

function findSignalDeclaredProps(src) {
  const props = new Set();
  for (const m of src.matchAll(/(?:^|\s)(?:readonly\s+)?(\w+)\s*(?::[^=;]+)?=\s*signal\s*[<(]/gm)) props.add(m[1]);
  return props;
}

function scanClass(src) {
  const lines = src.split('\n');
  const info = { declared: new Map(), decorated: new Set(), accessor: new Set(), inClass: new Set() };
  let inClass = false, classIndent = 0;
  for (let i = 0; i < lines.length; i++) {
    const L = lines[i];
    if (!inClass) {
      if (/^\s*(?:export\s+)?(?:abstract\s+)?class\s+\w+/.test(L)) { inClass = true; classIndent = L.match(/^\s*/)[0].length; }
      continue;
    }
    const indent = L.match(/^\s*/)[0].length;
    if (indent <= classIndent && /^\}/.test(L.trim())) { inClass = false; continue; }
    const prev = (lines[i - 1] || '');
    const dm = L.match(/^(\s*)(?:public\s+|private\s+|protected\s+|readonly\s+|static\s+)*(\w+)(\??)!?\s*(?::\s*([^=;]+?))?\s*(?:=\s*([^;]+?))?\s*;\s*$/);
    if (dm) {
      const name = dm[2];
      if (/@(Input|Output|ViewChild|ContentChild|HostBinding)\b/.test(prev) || /@(Input|Output|ViewChild|ContentChild|HostBinding)\(/.test(L)) { info.decorated.add(name); continue; }
      info.declared.set(name, { lineNo: i, indent: dm[1], type: (dm[4] || '').trim(), init: dm[5] ? dm[5].trim() : null });
      info.inClass.add(name);
    }
    const gm = L.match(/^\s*(?:public\s+|private\s+|protected\s+)?\s*(?:get|set)\s+(\w+)\s*\(/);
    if (gm) info.accessor.add(gm[1]);
  }
  return info;
}

/* ---------- helpers ---------- */
function rhsEnd(src, from) {
  // index of the char terminating the rhs expression started at `from`
  let depth = 0, i = from;
  const n = src.length;
  while (i < n) {
    const c = src[i];
    if (c === '"' || c === "'" || c === '`') {
      const q = c; i++;
      while (i < n) {
        if (src[i] === '\\') { i += 2; continue; }
        if (q === '`' && src.substr(i, 2) === '${') {
          let d = 1; i += 2;
          while (i < n && d > 0) { if (src[i] === '{') d++; else if (src[i] === '}') d--; i++; }
          continue;
        }
        if (src[i] === q) { i++; break; }
        i++;
      }
      continue;
    }
    if (c === '(' || c === '[' || c === '{') { depth++; i++; continue; }
    if (c === ')' || c === ']' || c === '}') { if (depth === 0) return i; depth--; i++; continue; }
    if (depth === 0 && (c === ';' || c === '\n' || c === ',' || c === ')')) {
      if (c === '\n') {
        // continue if the expression visibly continues on the next line
        const rest = src.slice(i + 1).replace(/^\s+/, '');
        const before = src.slice(from, i).trimEnd();
        if (/[&&||?:+\-*,(\[]$/.test(before) || /^[.?:)&|+\-*,\]]/.test(rest) || rest.startsWith('.')) { i++; continue; }
      }
      return i;
    }
    i++;
  }
  return n;
}

function applyEdits(src, edits) {
  edits.sort((a, b) => b.start - a.start);
  for (const e of edits) src = src.slice(0, e.start) + e.text + src.slice(e.end);
  return src;
}

/* ---------- TS conversion for one prop ---------- */
function convertPropTs(src, p, log) {
  // ---- 1. declaration ----
  const lines = src.split('\n');
  let done = false;
  let alreadySignal = false;
  for (let i = 0; i < lines.length; i++) {
    const L = lines[i];
    if (new RegExp(`\\b(?:get|set)\\s+${p}\\s*\\(`).test(L)) { log.push(`${p}: accessor, skipped`); return src; }
    const m = L.match(/^(\s*(?:public\s+|private\s+|protected\s+|readonly\s+|static\s+)*)(\w+)(\??)!?\s*(?::\s*([^=;]+?))?\s*=\s*([^;]+?)\s*;\s*$/);
    if (m && m[2] === p) {
      const init = m[5].trim();
      if (/^signal\s*[<(]/.test(init)) { alreadySignal = true; break; }
      let sigInit;
      if (/^(new\s|function\b|\(\)\s*=>|.*=>\s*\{|@)/.test(init)) { log.push(`${p}: complex init, skipped`); return src; }
      if (init === '[]') sigInit = `signal<any[]>([])`;
      else if (init === 'null' || init === 'undefined') sigInit = `signal<any>(${init})`;
      else sigInit = `signal(${init})`;
      lines[i] = `${m[1]}${p} = ${sigInit};`;
      done = true; break;
    }
    const m2 = L.match(/^(\s*(?:public\s+|private\s+|protected\s+|readonly\s+|static\s+)*)(\w+)(\??)!?\s*:\s*([^=;]+?)\s*=\s*([^;]+?)\s*;\s*$/);
    if (m2 && m2[2] === p) {
      const type = m2[4].trim(), init = m2[5].trim();
      if (/^signal\s*[<(]/.test(init)) { alreadySignal = true; break; }
      if (/^(new\s|function\b|\(\)\s*=>|.*=>\s*\{|@)/.test(init)) { log.push(`${p}: complex init, skipped`); return src; }
      const sigInit = init === '[]' ? `signal<${type}>([])`
        : (init === 'null' || init === 'undefined') ? `signal<${type} | null>(${init})`
        : `signal(${init})`;
      lines[i] = `${m2[1]}${p} = ${sigInit};`;
      done = true; break;
    }
    // typed declaration without initializer (e.g. "filters!: AuditLogFilters;") —
    // can't invent an init, but downstream reads/writes may still need completing
    const m3 = L.match(/^(\s*(?:public\s+|private\s+|protected\s+|readonly\s+|static\s+)*)(\w+)(\??)!\s*:\s*([^=;]+?)\s*;\s*$/);
    if (m3 && m3[2] === p) { alreadySignal = true; break; } // treat as pre-existing signal-ish; passes below still run
  }
  if (!done && !alreadySignal) { log.push(`${p}: no convertible declaration, skipped`); return src; }
  if (done) src = lines.join('\n');
  if (alreadySignal) log.push(`${p}: signal decl present, completing reads/writes`);

  /* subsequent passes re-scan regions each time (offsets shift) */
  const pass = (fn) => { src = fn(src); };

  // ---- 2. array in-place methods ----
  pass(s => {
    const regions = scanRegions(s);
    const edits = [];
    const re = new RegExp(`this\\.${p}\\.(${ARRAY_METHODS})\\s*\\(`, 'g');
    let m;
    while ((m = re.exec(s))) {
      const inStr = regions.strings.some(([a, b]) => m.index >= a && m.index < b);
      if (inStr) continue;
      const open = s.indexOf('(', m.index);
      let d = 0, j = open;
      for (; j < s.length; j++) { if (s[j] === '(') d++; else if (s[j] === ')') { d--; if (d === 0) break; } }
      const inner = s.slice(open + 1, j);
      edits.push({ start: m.index, end: j + 1, text: `this.${p}.update(arr => { arr.${m[1]}(${inner}); return arr; })` });
    }
    return applyEdits(s, edits);
  });

  // ---- 3. optional-chain reads ----
  pass(s => {
    const regions = scanRegions(s);
    const edits = [];
    const re = new RegExp(`this\\.${p}\\s*\\?\\.(?!\\s*[=(+\\-])`, 'g');
    let m;
    while ((m = re.exec(s))) {
      const inStr = regions.strings.some(([a, b]) => m.index >= a && m.index < b) && !regions.tplCode.some(([a, b]) => m.index >= a && m.index < b);
      if (inStr) continue;
      edits.push({ start: m.index, end: m.index + m[0].length, text: `this.${p}()?.` });
    }
    return applyEdits(s, edits);
  });

  // ---- 4. writes: this.P = rhs -> this.P.set(rhs)   (terminator untouched) ----
  pass(s => {
    const regions = scanRegions(s);
    const edits = [];
    const re = new RegExp(`this\\.${p}\\s*=(?![=>])`, 'g');
    let m;
    while ((m = re.exec(s))) {
      const inStr = regions.strings.some(([a, b]) => m.index >= a && m.index < b) && !regions.tplCode.some(([a, b]) => m.index >= a && m.index < b);
      const inCmt = regions.comments.some(([a, b]) => m.index >= a && m.index < b);
      if (inStr || inCmt) continue;
      const rhsStart = m.index + m[0].length;
      const end = rhsEnd(s, rhsStart);
      let rhs = s.slice(rhsStart, end).trim();
      if (!rhs) continue;
      edits.push({ start: m.index, end, text: `this.${p}.set(${rhs})` });
    }
    return applyEdits(s, edits);
  });

  // ---- 5. compound ops ----
  pass(s => s.replace(new RegExp(`this\\.${p}\\s*\\+\\+`, 'g'), `this.${p}.update(v => v + 1)`))
  pass(s => s.replace(new RegExp(`this\\.${p}\\s*--`, 'g'), `this.${p}.update(v => v - 1)`))
  pass(s => s.replace(new RegExp(`this\\.${p}\\s*\\+=\\s*([^;\\n]+)`, 'g'), `this.${p}.update(v => v + ($1))`))
  pass(s => s.replace(new RegExp(`this\\.${p}\\s*-=\\s*([^;\\n]+)`, 'g'), `this.${p}.update(v => v - ($1))`));

  // ---- 6. remaining reads ----
  pass(s => {
    const regions = scanRegions(s);
    const edits = [];
    const re = new RegExp(`this\\.${p}\\b(?<!\\$)(?!\\$)(?!\\s*(?:=(?![=>])|\\+\\+|--|\\+=|-=|\\(|\\.set\\(|\\.update\\())`, 'g');
    let m;
    while ((m = re.exec(s))) {
      const inStr = regions.strings.some(([a, b]) => m.index >= a && m.index < b) && !regions.tplCode.some(([a, b]) => m.index >= a && m.index < b);
      const inCmt = regions.comments.some(([a, b]) => m.index >= a && m.index < b);
      if (inStr || inCmt) continue;
      edits.push({ start: m.index, end: m.index + m[0].length, text: `this.${p}()` });
    }
    return applyEdits(s, edits);
  });

  return src;
}

/* ---------- ensure `signal` imported from @angular/core ---------- */
function ensureSignalImport(src, log) {
  if (!/\bsignal\s*\(/.test(src) && !/\bsignal</.test(src)) return src;
  if (/import\s*\{[^}]*\bsignal\b[^}]*\}\s*from\s*['"]@angular\/core['"];?/.test(src)) return src;
  // multi-line import from @angular/core?
  const ml = src.match(/import\s*\{([^}]*)\}\s*from\s*['"]@angular\/core['"];?/s);
  if (ml) {
    const names = ml[1].split(',').map(s => s.trim()).filter(Boolean);
    if (!names.includes('signal')) names.push('signal');
    names.sort();
    return src.replace(ml[0], `import { ${names.join(', ')} } from '@angular/core';`);
  }
  // no @angular/core import at all: insert after the last import line
  const importRe = /^import\s.+;\s*$/gm;
  let last = -1, m;
  while ((m = importRe.exec(src))) last = m.index + m[0].length;
  const line = `import { signal } from '@angular/core';\n`;
  if (last >= 0) return src.slice(0, last) + '\n' + line + src.slice(last);
  return line + src;
}
function convertPropHtml(html, p, log) {
  if (new RegExp(`\\blet\\s+${p}\\b|\\bas\\s+${p}\\b|;\\s*let\\s+${p}\\b|@for\\s*\\(\\s*${p}\\b`).test(html)) { log.push(`${p}: template alias shadowing, skipped`); return html; }
  const commentRanges = [];
  { let re = /<!--[\s\S]*?-->/g, m; while ((m = re.exec(html))) commentRanges.push([m.index, m.index + m[0].length]); }
  const inComment = idx => commentRanges.some(([s, e]) => idx >= s && idx < e);

  const readConvert = s => s.replace(
    new RegExp(`(?<![\\w$.])${p}\\b(?!\\$)(?!\\s*(?:=(?![=>])|\\+\\+|--|\\+=|-=|\\(|\\.set\\(|\\.update\\())`, 'g'),
    `${p}()`
  );

  // generic two-way binding [(x)]="p" or [(x)]="p()" -> [x]="p()" (xChange)="p.set($event)"
  const splitTwoWay = (_m, attr) => `[${attr}]="${p}()" (${attr}Change)="${p}.set($event)"`;
  html = html.replace(new RegExp(`\\[\\((\\w+)\\)\\]\\s*=\\s*"${p}\\(\\)"`, 'g'), splitTwoWay);
  html = html.replace(new RegExp(`\\[\\((\\w+)\\)\\]\\s*=\\s*"${p}"`, 'g'), splitTwoWay);

  // 1. banana-in-a-box ngModel
  html = html.replace(new RegExp(`\\[\\(ngModel\\)\\]\\s*=\\s*"${p}"`, 'g'),
    `[ngModel]="${p}()" (ngModelChange)="${p}.set($event)"`);

  // 2. attribute values
  let edits = [];
  const attrRe = /([\w\-@.\[\]()#:*]+)\s*=\s*"([^"]*)"/g;
  let m;
  while ((m = attrRe.exec(html))) {
    if (inComment(m.index)) continue;
    const name = m[1], val = m[2];
    const isBinding = /[\[(*@]/.test(name[0]) || name.startsWith('bind-') || name.startsWith('on-');
    let newVal = val;
    if (isBinding) {
      // event-handler writes: P = expr   (=== / == / <= / >= are NOT writes)
      const wRe = new RegExp(`(^|[;&\\s(])${p}\\s*=(?![=>])\\s*([^;&"]+)`, 'g');
      let w; const wEdits = [];
      while ((w = wRe.exec(newVal))) {
        wEdits.push({ from: w[0], to: `${w[1]}${p}.set(${readConvert(w[2].trim())})` });
      }
      for (const e of wEdits) newVal = newVal.split(e.from).join(e.to);
      newVal = newVal.replace(new RegExp(`\\b${p}\\s*\\?\\.(?!\\s*[=(+\\-])`, 'g'), `${p}()?.`);
      // reads in binding expressions (whole expression is template code)
      newVal = readConvert(newVal);
    } else {
      // static attribute: only {{interpolation}} content is template code —
      // a bare value like name="input" or class="loading" must stay untouched
      newVal = newVal.replace(/\{\{([^}]*)\}\}/g, (_mm, inner) => `{{${readConvert(inner)}}}`);
    }
    if (newVal !== val) {
      // locate the quoted value precisely — indexOf(val) alone could match
      // the same name inside the attribute NAME (e.g. [class.loading])
      const q = m[0].indexOf(`"${val}"`);
      if (q !== -1) {
        const start = m.index + q + 1;
        edits.push({ start, end: start + val.length, text: newVal });
      }
    }
  }
  html = applyEdits(html, edits);

  // 3. text-node interpolations
  edits = [];
  const intRe = /\{\{([^}]*)\}\}/g;
  while ((m = intRe.exec(html))) {
    if (inComment(m.index)) continue;
    const nv = readConvert(m[1]);
    if (nv !== m[1]) edits.push({ start: m.index + 2, end: m.index + 2 + m[1].length, text: nv });
  }
  html = applyEdits(html, edits);

  // 4. control-flow block headers: @if (expr) / @else if (expr) / @switch (expr)
  //    and @for (item of expr; track expr) — bare expressions outside attrs/interpolations
  edits = [];
  const hdrRe = /@(?:if|else\s+if|switch)\s*\(([^)]*)\)|@for\s*\(([^)]*)\)/g;
  while ((m = hdrRe.exec(html))) {
    if (inComment(m.index)) continue;
    const full = m[0];
    let converted;
    if (m[1] !== undefined) {
      converted = full.replace(m[1], readConvert(m[1]));
    } else {
      // @for header: convert only the `of <expr>` part, never the item/alias names
      const ofM = full.match(/^(.*?\bof\s+)([^;]+?)(\s*(?:;|$).*)$/s);
      if (ofM) converted = ofM[1] + readConvert(ofM[2]) + ofM[3];
      const trM = converted !== undefined ? converted.match(/^(.*;\s*track\s+)([^;)]+)(.*)$/s) : null;
      if (trM) converted = trM[1] + readConvert(trM[2]) + trM[3];
      if (converted === undefined) converted = full;
    }
    if (converted !== full) edits.push({ start: m.index, end: m.index + full.length, text: converted });
  }
  return applyEdits(html, edits);
}

function convertInlineTemplates(src, p, log) {
  const re = /template\s*:\s*`([\s\S]*?)`/g;
  let m; const edits = [];
  while ((m = re.exec(src))) {
    const body = m[1];
    const converted = convertPropHtml(body, p, log);
    if (converted !== body) {
      const off = m.index + m[0].indexOf(body);
      edits.push({ start: off, end: off + body.length, text: converted });
    }
  }
  return applyEdits(src, edits);
}

/* ---------- main ---------- */
const targets = process.argv.slice(2);
if (!targets.length) { console.error('usage: node scripts/signals-codemod.mjs <paths...>'); process.exit(1); }

const tsFiles = walkFiles(targets, '.ts', []);
for (const file of tsFiles) {
  const src0 = fs.readFileSync(file, 'utf8');
  const asyncProps = discoverAsyncProps(src0);
  const info = scanClass(src0);
  const log = [];
  const props = [...asyncProps].filter(p => {
    if (!info.inClass.has(p)) return false;
    if (info.decorated.has(p)) { log.push(`${p}: @decorated, skipped`); return false; }
    if (info.accessor.has(p)) { log.push(`${p}: accessor, skipped`); return false; }
    if (p.endsWith('$')) { log.push(`${p}: observable, skipped`); return false; }
    return true;
  });
  for (const p of info.inClass) {
    if (props.includes(p) || info.decorated.has(p) || info.accessor.has(p) || p.endsWith('$')) continue;
    if (!FLAG_RE.test(p)) continue;
    // plain write OR already-converted signal declaration (idempotence)
    const isWritten = new RegExp(`this\\.${p}\\s*=(?![=>])`).test(src0);
    const isSignalDecl = new RegExp(`\\b${p}\\s*(?::[^=;]+)?=\\s*signal\\(`).test(src0);
    if (!isWritten && !isSignalDecl) continue;
    props.push(p);
  }
  // third source: ALL signal-declared props (completes stragglers + HTML fixes;
  // convertPropTs is a no-op when the declaration is already a signal)
  for (const p of findSignalDeclaredProps(src0)) {
    if (props.includes(p) || info.decorated.has(p) || info.accessor.has(p)) continue;
    props.push(p);
  }
  if (!props.length) { console.log(`${file}: nothing to convert`); continue; }
  let out = src0;
  for (const p of props) {
    out = convertPropTs(out, p, log);
    out = convertInlineTemplates(out, p, log);
  }
  out = ensureSignalImport(out, log);
  fs.writeFileSync(file, out);
  console.log(`${file}: converted [${props.join(', ')}]${log.length ? '\n    skipped: ' + log.join('; ') : ''}`);
}

for (const file of walkFiles(targets, '.html', [])) {
  const tsSibling = file.replace(/\.html$/, '.ts');
  if (!fs.existsSync(tsSibling)) continue;
  const src0 = fs.readFileSync(tsSibling, 'utf8');
  const asyncProps = discoverAsyncProps(src0);
  const info = scanClass(src0);
  const props = [...asyncProps].filter(p => info.inClass.has(p) && !info.decorated.has(p) && !info.accessor.has(p) && !p.endsWith('$'));
  for (const p of info.inClass) {
    if (props.includes(p) || info.decorated.has(p) || info.accessor.has(p) || p.endsWith('$')) continue;
    if (!FLAG_RE.test(p)) continue;
    const isWritten = new RegExp(`this\\.${p}\\s*=(?![=>])`).test(src0);
    const isSignalDecl = new RegExp(`\\b${p}\\s*(?::[^=;]+)?=\\s*signal\\(`).test(src0);
    if (!isWritten && !isSignalDecl) continue;
    props.push(p);
  }
  for (const p of findSignalDeclaredProps(src0)) {
    if (props.includes(p) || info.decorated.has(p) || info.accessor.has(p)) continue;
    props.push(p);
  }
  if (!props.length) continue;
  const html0 = fs.readFileSync(file, 'utf8');
  const log = [];
  let out = html0;
  for (const p of props) out = convertPropHtml(out, p, log);
  if (out !== html0) { fs.writeFileSync(file, out); console.log(`${file}: html converted [${props.join(', ')}]${log.length ? '\n    skipped: ' + log.join('; ') : ''}`); }
}

console.log('\nDone.');
