#!/usr/bin/env node
/** Add missing `import { DialogUtils } from '../../shared/dialog-utils';`
 *  after the last top-of-file import line. Idempotent. */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const APP = path.join(root, 'src', 'app', 'features');

const FILES = [
  'communication/events.component.ts',
  'communication/announcements.component.ts',
  'library/library.component.ts',
  'payroll/payroll.component.ts',
  'parents/parents.component.ts',
  'organization/department-list.component.ts',
  'staff/designation-list.component.ts',
  'examinations/results-view.component.ts',
  'whatsapp/whatsapp-fee-reminders.component.ts',
  'student-full-details/student-full-details.component.ts',
];

for (const rel of FILES) {
  const file = path.join(APP, rel);
  let src = fs.readFileSync(file, 'utf8');
  if (src.includes('shared/dialog-utils')) {
    console.log(`SKIP: ${rel}`);
    continue;
  }
  const lines = src.split('\n');
  let last = 0;
  for (let i = 0; i < Math.min(lines.length, 60); i++) {
    if (/^import /.test(lines[i])) last = i;
  }
  lines.splice(last + 1, 0, "import { DialogUtils } from '../../shared/dialog-utils';");
  fs.writeFileSync(file, lines.join('\n'), 'utf8');
  console.log(`OK: ${rel}`);
}
