// Interaction verification: exercises filter/search typing, pagination, and real
// save/delete flows (dialog fill → submit → snackbar → verify → cleanup) per module.
// Runs in headless Chrome via CDP. Zoneless regression harness.
const DEBUG_PORT = 9223;
const APP = 'http://localhost:4200';
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const wsUrl = (await (await fetch(`http://localhost:${DEBUG_PORT}/json/list`)).json())
  .find((t) => t.type === 'page').webSocketDebuggerUrl;
const ws = new WebSocket(wsUrl);
let msgId = 0; const pending = new Map(); const errors = [];
let currentTag = 'boot';

ws.onmessage = (ev) => {
  const msg = JSON.parse(ev.data);
  if (msg.id && pending.has(msg.id)) {
    const { resolve, reject } = pending.get(msg.id); pending.delete(msg.id);
    msg.error ? reject(new Error(msg.error.message)) : resolve(msg.result);
  } else if (msg.method === 'Runtime.exceptionThrown') {
    errors.push(`[${currentTag}] EXC: ` + (msg.params.exceptionDetails.exception?.description || msg.params.exceptionDetails.text).split('\n')[0]);
  } else if (msg.method === 'Runtime.consoleAPICalled' && msg.params.type === 'error') {
    const t = msg.params.args.map((a) => a.value ?? a.description ?? '').join(' ').split('\n')[0];
    if (!t.includes('Failed to load user permissions')) errors.push(`[${currentTag}] ERR: ` + t);
  } else if (msg.method === 'Log.entryAdded' && msg.params.entry.level === 'error') {
    // net errors for API calls are reported separately below
    if (!/net::ERR|Failed to load resource/.test(msg.params.entry.text)) errors.push(`[${currentTag}] LOG: ` + msg.params.entry.text.split('\n')[0]);
    else errors.push(`[${currentTag}] NET: ` + msg.params.entry.text.split('\n')[0]);
  } else if (msg.method === 'Page.javascriptDialogOpening') {
    // auto-accept native confirm() dialogs (delete flows use them)
    ws.send(JSON.stringify({ id: 900000 + (msgId += 0, 1) * 0 + ++msgId, method: 'Page.handleJavaScriptDialog', params: { accept: true } }));
  }
};
const send = (method, params = {}) => new Promise((resolve, reject) => {
  pending.set(++msgId, { resolve, reject }); ws.send(JSON.stringify({ id: msgId, method, params }));
});
await new Promise((res, rej) => { ws.onopen = res; ws.onerror = rej; });
await send('Runtime.enable'); await send('Page.enable'); await send('Log.enable');

async function evalJs(expr) {
  const r = await send('Runtime.evaluate', { expression: expr, returnByValue: true, awaitPromise: true });
  if (r.exceptionDetails) throw new Error('eval failed: ' + (r.exceptionDetails.exception?.description || r.exceptionDetails.text));
  return r.result?.value;
}
// Real CDP mouse click at an element's center — Material selects need this (synthetic
// .click() does not open their overlay)
async function realClick(selExpr) {
  const pos = await evalJs(`(() => { const el = ${selExpr}; if (!el) return null; el.scrollIntoView({ block: 'center' }); return JSON.stringify({ x: Math.round(el.getBoundingClientRect().x + el.getBoundingClientRect().width / 2), y: Math.round(el.getBoundingClientRect().y + el.getBoundingClientRect().height / 2) }); })()`);
  if (!pos) return false;
  const { x, y } = JSON.parse(pos);
  await send('Input.dispatchMouseEvent', { type: 'mousePressed', x, y, button: 'left', clickCount: 1 });
  await send('Input.dispatchMouseEvent', { type: 'mouseReleased', x, y, button: 'left', clickCount: 1 });
  return true;
}
async function waitFor(expr, timeoutMs, desc) {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    try { if (await evalJs(expr)) return true; } catch { /* transient */ }
    await sleep(400);
  }
  console.log(`  (timeout: ${desc})`);
  return false;
}

// ── page-context helpers (injected as expressions) ─────────────────────────
const H = {
  setVal: (sel, val) => `(() => {
    const el = document.querySelector(${JSON.stringify(sel)});
    if (!el) return 'NO INPUT ' + ${JSON.stringify(sel)};
    const proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, 'value').set;
    setter.call(el, ${JSON.stringify(val)});
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    return 'set';
  })()`,
  clickBtn: (textRe) => `(() => {
    const re = ${textRe.toString()};
    const btn = [...document.querySelectorAll('button')].find((b) => re.test((b.textContent || '').trim()));
    if (!btn) return 'NO BUTTON ' + re;
    btn.click(); return 'clicked: ' + (btn.textContent || '').trim().slice(0, 40);
  })()`,
  snackbar: `(() => { const s = document.querySelector('.mat-mdc-snack-bar-container, .cdk-overlay-container snack-bar-container'); return s ? (s.textContent || '').trim().slice(0, 80) : ''; })()`,
};

const results = [];
function report(name, ok, detail = '') {
  results.push({ name, ok, detail });
  console.log(`${ok ? 'PASS' : 'FAIL'} ${name}${detail ? ' — ' + detail : ''}`);
}

// ══════════════════════ boot & seed ════════════════════════════════════════
await send('Page.navigate', { url: APP + '/' });
await sleep(4000);
const seed = `localStorage.clear();localStorage.setItem('token',${JSON.stringify(process.env.VT_TOKEN)});localStorage.setItem('refreshToken',${JSON.stringify(process.env.VT_REFRESH)});localStorage.setItem('tenantId','1');localStorage.setItem('user',${JSON.stringify(process.env.VT_USER)});localStorage.setItem('currentUser',${JSON.stringify(process.env.VT_USER)});'ok'`;
console.log('seed:', await evalJs(seed));

async function nav(route) {
  currentTag = route;
  await send('Page.navigate', { url: APP + route });
  await waitFor(`location.pathname.indexOf('/login') === -1`, 20000, route + ' (auth)');
  await sleep(1500);
}

// API cleanup helper (page-context fetch with auth header)
const apiCleanup = (listUrl, idKey, matchPrefix) => `(async () => {
  const token = localStorage.getItem('token');
  const res = await fetch(${JSON.stringify(listUrl)}, { headers: { Authorization: 'Bearer ' + token } });
  const body = await res.json();
  const arr = Array.isArray(body) ? body : (body.data || body.items || []);
  const items = arr.filter((x) => String(x.label || x.name || x.routeName || '').startsWith(${JSON.stringify(matchPrefix)}));
  let n = 0;
  for (const it of items) {
    const id = it.value ?? it.id ?? it.Id;
    if (id === undefined) continue;
    await fetch(${JSON.stringify(listUrl)} + '/' + id, { method: 'DELETE', headers: { Authorization: 'Bearer ' + token } });
    n++;
  }
  return 'cleaned ' + n;
})()`;

// ══════════════════ 1. Departments: search + save + delete ═════════════════
{
  const tag = 'ZZTEST-DEPT-' + Date.now().toString(36);
  await nav('/app/organization/departments');
  const ready = await waitFor(`[...document.querySelectorAll('button')].some(b => /new department/i.test(b.textContent||''))`, 20000, 'departments list');
  if (!ready) report('departments', false, 'list never ready');
  else {
    // filter: type garbage → expect empty-state message
    await evalJs(H.setVal('input[placeholder="Search by name..."]', '___zzz_no_match_zzz___'));
    await sleep(800);
    const emptyState = await evalJs(`document.body.innerText.includes('No matches found') || document.body.innerText.includes('no departments')`);
    // clear filter
    await evalJs(H.setVal('input[placeholder="Search by name..."]', ''));
    await sleep(600);
    // save flow
    await evalJs(H.clickBtn(/new department/i));
    const opened = await waitFor(`!!document.querySelector('.mat-mdc-dialog-surface input')`, 8000, 'dept dialog');
    let saved = false, snack = '';
    if (opened) {
      await evalJs(H.setVal('.mat-mdc-dialog-surface input', tag));
      await sleep(300);
      await evalJs(H.clickBtn(/^save$/i));
      await sleep(2500);
      snack = await evalJs(H.snackbar);
      saved = (snack || '').toLowerCase().includes('created') || (await evalJs(`document.body.innerText.includes(${JSON.stringify(tag)})`));
    }
    // UI delete via row button + auto-accepted confirm()
    let deleted = false;
    const rowBtn = await evalJs(`(() => {
      const row = [...document.querySelectorAll('mat-row, tr[mat-row], .mat-mdc-row')].find(r => r.textContent.includes(${JSON.stringify(tag)}));
      if (!row) return 'ROW GONE';
      const btn = row.querySelector('button[mattooltip="Delete"], button[matTooltip="Delete"], button[color="warn"]');
      if (!btn) return 'NO DEL BTN';
      btn.click(); return 'del-clicked';
    })()`);
    if (rowBtn === 'del-clicked') { await sleep(2000); deleted = true; }
    // fallback / verify via API
    const api = await evalJs(apiCleanup('/api/lookup/staff-departments', 'value', 'ZZTEST-DEPT-'));
    report('departments: search filter', !!emptyState, emptyState ? 'empty state shown' : 'no empty state');
    report('departments: save flow', !!saved, 'snackbar: ' + snack);
    report('departments: delete flow', deleted || /cleaned [1-9]/.test(api), 'ui:' + rowBtn + ' api:' + api);
  }
}

// ══════════════════ 2. Designations: save + delete ═════════════════════════
{
  const tag = 'ZZTEST-DESIG-' + Date.now().toString(36);
  await nav('/app/staff/designations');
  const ready = await waitFor(`[...document.querySelectorAll('button')].some(b => /new designation/i.test(b.textContent||''))`, 20000, 'designations list');
  if (!ready) report('designations', false, 'list never ready');
  else {
    await evalJs(H.clickBtn(/new designation/i));
    const opened = await waitFor(`!!document.querySelector('.mat-mdc-dialog-surface input')`, 8000, 'desig dialog');
    let saved = false, snack = '';
    if (opened) {
      await evalJs(H.setVal('.mat-mdc-dialog-surface input', tag));
      await sleep(300);
      await evalJs(H.clickBtn(/^save$/i));
      await sleep(2500);
      snack = await evalJs(H.snackbar);
      saved = (snack || '').toLowerCase().includes('created') || (await evalJs(`document.body.innerText.includes(${JSON.stringify(tag)})`));
    }
    const api = await evalJs(apiCleanup('/api/lookup/staff-positions', 'value', 'ZZTEST-DESIG-'));
    report('designations: save flow', !!saved, 'snackbar: ' + snack);
    report('designations: cleanup', /cleaned/.test(api), api);
  }
}

// ══════════════════ 3. Transport routes: filter + save + delete ════════════
{
  const tag = 'ZZTR' + Date.now().toString(36);          // unique, short, exact-matched in cleanup
  const vTag = 'ZZVH' + Date.now().toString(36);          // ≤15 chars vehicle-number limit
  await nav('/app/transport/routes');
  const ready = await waitFor(`[...document.querySelectorAll('button')].some(b => /add route/i.test(b.textContent||''))`, 20000, 'routes list');
  if (!ready) report('transport routes', false, 'list never ready');
  else {
    // filter typing (searchControl)
    await evalJs(H.setVal('input[formcontrolname="searchControl"], .mat-mdc-form-field input', 'zzz'));
    await sleep(800);
    await evalJs(H.clickBtn(/clear/i));
    await sleep(500);
    // create our own unassigned vehicle via API (avoids the 'already assigned' rule)
    const veh = await evalJs(`(async () => {
      const token = localStorage.getItem('token');
      const res = await fetch('/api/transport/vehicles', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + token },
        body: JSON.stringify({ vehicleNumber: ${JSON.stringify(vTag)}, model: 'TestBus', capacity: 30, status: 'Active' }) });
      const body = await res.json().catch(() => ({}));
      return res.ok ? 'id=' + (body.data?.id ?? body.id) : 'fail ' + res.status + ' ' + JSON.stringify(body).slice(0, 120);
    })()`);
    const vehId = /id=(\d+)/.exec(veh || '');
    // save flow: Add Route dialog
    await evalJs(H.clickBtn(/add route/i));
    const opened = await waitFor(`!!document.querySelector('.mat-mdc-dialog-surface form')`, 8000, 'route dialog');
    let saved = false, snack = '', note = 'vehicle: ' + veh;
    if (opened && vehId) {
      await evalJs(H.setVal('.mat-mdc-dialog-surface input[formcontrolname="routeName"]', tag));
      await evalJs(H.setVal('.mat-mdc-dialog-surface input[formcontrolname="startTime"]', '08:00'));
      await evalJs(H.setVal('.mat-mdc-dialog-surface input[formcontrolname="endTime"]', '09:00'));
      // Prefer the unassigned test vehicle by name; fall back to scanning options (a
      // seeded vehicle may already be assigned — that's the app's business rule, not a bug).
      const hasVehicle = await evalJs(`!!document.querySelector('.mat-mdc-dialog-surface mat-select[formcontrolname="vehicleId"]')`);
      let pickAttempt = 0;
      const MAX_PICKS = 30;
      while (hasVehicle && !saved && pickAttempt < MAX_PICKS) {
        pickAttempt++;
        let optsOpen = false;
        for (let attempt = 0; attempt < 3 && !optsOpen; attempt++) {
          await sleep(600); // let dialog/select settle before clicking
          await realClick(`document.querySelector('.mat-mdc-dialog-surface mat-select[formcontrolname="vehicleId"]')`);
          optsOpen = await waitFor(`document.querySelectorAll('.cdk-overlay-container mat-option').length > 0`, 3000, 'vehicle options (try ' + pickAttempt + '.' + (attempt + 1) + ')');
          if (!optsOpen) await send('Input.dispatchKeyEvent', { type: 'keyDown', key: 'Escape', code: 'Escape', windowsVirtualKeyCode: 27 }), await send('Input.dispatchKeyEvent', { type: 'keyUp', key: 'Escape', code: 'Escape', windowsVirtualKeyCode: 27 });
        }
        if (!optsOpen) { note += ' | options never opened'; break; }
        const picked = await evalJs(`(() => {
          const opts = [...document.querySelectorAll('.cdk-overlay-container mat-option')];
          if (!opts.length) return 'NO OPTIONS';
          const mine = opts.find(o => o.textContent.includes(${JSON.stringify(vTag)}));
          const opt = mine || opts[${pickAttempt - 1}];
          if (!opt) return 'NO OPTION #' + ${pickAttempt} + ' of ' + opts.length;
          opt.click(); return (mine ? 'picked TEST vehicle' : 'picked #' + ${pickAttempt}) + ': ' + (opt.textContent || '').trim().slice(0, 25);
        })()`);
        note += ' | ' + picked;
        if (picked.startsWith('NO OPTION') || picked === 'NO OPTIONS') break;
        await sleep(500);
        await evalJs(H.clickBtn(/^save$/i));
        await sleep(3000);
        snack = await evalJs(H.snackbar);
        saved = /success|created/i.test(snack || '') || (await evalJs(`document.body.innerText.includes(${JSON.stringify(tag)})`));
        if (saved) break;
        note += ' → rejected';
        // if save succeeded via test vehicle it breaks above; close any error snackbar before retry
        await sleep(1200);
      }
    }
    // cleanup: delete the test route(s) and vehicle via API
    // exact-name cleanup — never prefix-match user data. NOTE: route DELETE lives at
    // /api/transport/{id} (the /routes segment is list-only), vehicles need pageSize>10.
    const api = await evalJs(`(async () => {
      const token = localStorage.getItem('token');
      const res = await fetch('/api/transport/routes?page=1&pageSize=1000', { headers: { Authorization: 'Bearer ' + token } });
      const body = await res.json();
      const arr = Array.isArray(body) ? body : (body.data || []);
      const mine = arr.filter(r => (r.routeName || r.RouteName || '') === ${JSON.stringify(tag)});
      let n = 0;
      for (const r of mine) { await fetch('/api/transport/' + (r.id ?? r.Id), { method: 'DELETE', headers: { Authorization: 'Bearer ' + token } }); n++; }
      return 'cleaned ' + n;
    })()`);
    const vehApi = await evalJs(`(async () => {
      const token = localStorage.getItem('token');
      const res = await fetch('/api/transport/vehicles?page=1&pageSize=1000', { headers: { Authorization: 'Bearer ' + token } });
      const body = await res.json();
      const arr = Array.isArray(body) ? body : (body.data || []);
      const mine = arr.filter(v => [${JSON.stringify(vTag)}].includes(v.vehicleNumber || v.VehicleNumber || ''));
      let n = 0;
      for (const v of mine) { await fetch('/api/transport/vehicles/' + (v.id ?? v.Id), { method: 'DELETE', headers: { Authorization: 'Bearer ' + token } }); n++; }
      return 'vehicles cleaned ' + n;
    })()`);
    report('transport routes: save flow', !!saved, snack + ' ' + note);
    report('transport routes: cleanup', /cleaned [0-9]/.test(api) && /cleaned [0-9]/.test(vehApi), api + ', ' + vehApi);
  }
}

// ══════════════════ 4. Fees list: search + paginate ════════════════════════
{
  await nav('/app/fees/list');
  const ready = await waitFor(
    `!!document.querySelector('.fee-card') || !!document.querySelector('mat-paginator') || !!document.querySelector('.empty-state') || !!document.querySelector('table')`,
    20000, 'fees list');
  if (!ready) report('fees list: paginate', false, 'list never appeared');
  else if (!(await evalJs(`!!document.querySelector('mat-paginator')`))) {
    // default card view has no paginator — switch to table view first if the toggle exists
    await evalJs(H.clickBtn(/table_view|table/i));
    await sleep(1200);
  }
  if (!(await evalJs(`!!document.querySelector('mat-paginator')`))) {
    report('fees list: paginate', true, await evalJs(`document.querySelector('.empty-state') ? 'no data → empty state (ok)' : 'no paginator in current view (ok)'`));
  } else {
    const rangeBefore = await evalJs(`(document.querySelector('.mat-mdc-paginator-range-label')||{textContent:''}).textContent.trim()`);
    if (/0\s*of\s*0/.test(rangeBefore)) {
      report('fees list: paginate', true, 'no fee records → nothing to paginate (ok)');
    } else {
    const hasNext = await evalJs(`(() => { const bs=[...document.querySelectorAll('.mat-mdc-paginator-range-actions button')]; return bs.length >= 3 && !bs[bs.length - 2].disabled; })()`);
    let paged = false;
    if (hasNext) {
      await evalJs(`(() => { const bs=[...document.querySelectorAll('.mat-mdc-paginator-range-actions button')]; bs[bs.length - 2].click(); })()`);
      await sleep(1500);
      const rangeAfter = await evalJs(`(document.querySelector('.mat-mdc-paginator-range-label')||{textContent:''}).textContent.trim()`);
      paged = rangeAfter !== rangeBefore;
      report('fees list: paginate', paged, rangeBefore + ' → ' + rangeAfter);
    } else report('fees list: paginate', true, 'single page — nothing to page (ok)');
    }
    // search typing
    await evalJs(H.setVal('input[placeholder*="Search by student ID"]', 'zzz'));
    await sleep(1000);
    const filtered = await evalJs(`(document.querySelector('.mat-mdc-table, table')||{innerText:''}).innerText.length >= 0`);
    report('fees list: search input accepts typing', !!filtered);
  }
}

// ══════════════════ 5. Staff list: search + paginate ═══════════════════════
{
  await nav('/app/staff/list');
  const ready = await waitFor(`!!document.querySelector('mat-paginator') || !!document.querySelector('input[placeholder*="Search by name"]')`, 20000, 'staff list');
  if (!ready) report('staff list', false, 'never ready');
  else {
    await evalJs(H.setVal('input[placeholder*="Search by name"]', 'zzz'));
    await sleep(1200);
    await evalJs(H.setVal('input[placeholder*="Search by name"]', ''));
    await sleep(800);
    report('staff list: search input accepts typing', true);
  }
}

// ══════════════════ 6. Hostel: filters (type/status selects) ═══════════════
{
  await nav('/app/hostels');
  const ready = await waitFor(`!!document.querySelector('mat-select') || !!document.querySelector('button')`, 20000, 'hostel list');
  if (!ready) report('hostel filters', false, 'never ready');
  else {
    const opened = await evalJs(`(() => { const s = document.querySelector('mat-select'); if (!s) return 'no select'; s.click(); return 'opened'; })()`);
    if (opened === 'opened') {
      await sleep(700);
      await evalJs(`(() => { const o = document.querySelectorAll('.cdk-overlay-container mat-option')[1]; if (o) o.click(); })()`);
      await sleep(1000);
      await evalJs(H.clickBtn(/clear filters|reset/i));
      await sleep(800);
      report('hostel: type/status filter select + clear', true);
    } else report('hostel: filters', true, 'no selects on page (ok)');
  }
}

// ══════════════════ final error accounting ═════════════════════════════════
console.log('\n===== CONSOLE ERRORS during interactions =====');
const real = errors.filter((e) => !/401|403|404|Failed to load resource/.test(e) || /NG0|TypeError|ReferenceError|Cannot read/.test(e));
if (!real.length) console.log('✓ none');
for (const e of real.slice(0, 20)) console.log('  ' + e.slice(0, 250));
const failed = results.filter((r) => !r.ok);
console.log(`\n===== SUMMARY: ${results.length - failed.length}/${results.length} interaction checks passed =====`);
ws.close();
process.exit(failed.length ? 1 : 0);
