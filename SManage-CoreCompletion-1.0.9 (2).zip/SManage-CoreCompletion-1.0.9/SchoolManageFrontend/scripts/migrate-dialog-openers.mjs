#!/usr/bin/env node
/**
 * One-shot codemod: migrate every remaining raw `dialog.open(..., { width: ... })`
 * config to DialogUtils.getMobileConfig(...) — the app's utility that renders
 * full-screen sheets on phones and preserves the original width on desktop.
 *
 * Files already migrated (DialogUtils present) are skipped.
 * Run once from repo root:  node scripts/migrate-dialog-openers.mjs
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const APP = path.join(root, 'src', 'app', 'features');

const FILES = [
  'communication/events.component.ts',
  'communication/announcements.component.ts',
  'library/library.component.ts',
  'payroll/payroll.component.ts',
  'transport/routes-list.component.ts',
  'parents/parents.component.ts',
  'organization/department-list.component.ts',
  'staff/designation-list.component.ts',
  'examinations/results-view.component.ts',
  'whatsapp/whatsapp-fee-reminders.component.ts',
  'student-full-details/student-full-details.component.ts',
  'student-enquiry/student-enquiry-list.component.ts',
];

// Match a `dialog.open(Comp, { <width-ish props> ` and rewrite the props block.
// We replace only the config object's leading width props, keeping `data:` etc.
const WIDTH_PROPS = /(\{\s*)(width:\s*'[^']+',\s*)(?:maxWidth:\s*'[^']+',\s*)?(?:maxHeight:\s*'[^']+',\s*)?/g;

let totalRewrites = 0;

for (const rel of FILES) {
  const file = path.join(APP, rel);
  if (!fs.existsSync(file)) {
    console.warn(`SKIP (missing): ${rel}`);
    continue;
  }
  let src = fs.readFileSync(file, 'utf8');

  if (/dialogUtils\.getMobileConfig/.test(src)) {
    console.log(`SKIP (already migrated): ${rel}`);
    continue;
  }

  let count = 0;

  // 1. Rewrite dialog.open config objects that declare width first.
  src = src.replace(
    /this\.dialog\.open\(([^,]+),\s*\{\s*\n?(\s*width:\s*'[^']+',?)([^\n]*\n?)?([^\n]*\n?)?/g,
    (match, comp, widthPart, rest1, rest2) => {
      count++;
      // Preserve any maxWidth/maxHeight overrides found in the original props.
      const merged = [widthPart.trim().replace(/,$/, ''), rest1?.trim().replace(/,$/, ''), rest2?.trim().replace(/,$/, '')]
        .filter(Boolean)
        .join(', ');
      return `this.dialog.open(${comp}, {\n        ...this.dialogUtils.getMobileConfig({ ${merged} }),\n        `;
    }
  );

  // 2. Inject the DialogUtils import after the last existing import.
  if (count > 0) {
    const importLine = "import { DialogUtils } from '../../shared/dialog-utils';";
    if (!src.includes("shared/dialog-utils")) {
      const importRe = /^import .*?;$/m;
      let lastIdx = -1;
      src.replace(/^import .*?;\s*$/gm, (m, idx) => { lastIdx = idx; return m; });
      // insert after the final import line
      const lines = src.split('\n');
      let insertAt = 0;
      for (let i = 0; i < lines.length; i++) {
        if (/^import /.test(lines[i])) insertAt = i + 1;
      }
      src = lines.join('\n');
    }

    // 3. Inject `private dialogUtils: DialogUtils,` after `private dialog: MatDialog,`
    const ctorRe = /(private\s+dialog\s*:\s*MatDialog\s*,?\s*\n)/;
    if (ctorRe.test(src) && !src.includes('dialogUtils: DialogUtils')) {
      src = src.replace(ctorRe, (m) => {
        const needsComma = !m.trim().endsWith(',');
        return `${m.trimEnd()}${needsComma ? ',' : ''}\n    private dialogUtils: DialogUtils,\n`;
      });
    } else {
      console.warn(`WARN: could not find constructor injection point for ${rel} — add 'private dialogUtils: DialogUtils' manually.`);
    }

    fs.writeFileSync(file, src, 'utf8');
    totalRewrites += count;
    console.log(`OK: ${rel} — ${count} dialog.open(s) migrated`);
  } else {
    console.log(`OK (no width configs matched): ${rel}`);
  }
}

console.log(`\nDone. ${totalRewrites} dialog opener(s) migrated.`);
