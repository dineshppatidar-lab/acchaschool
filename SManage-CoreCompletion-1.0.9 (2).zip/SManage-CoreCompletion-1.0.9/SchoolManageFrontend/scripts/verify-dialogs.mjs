// Interaction pass: open/close the Add/New dialogs that previously threw NG0100 on open/close.
// Uses polling (not fixed sleeps) to survive dev-server boot races.
const DEBUG_PORT = 9223;
const APP = 'http://localhost:4200';
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const wsUrl = (await (await fetch(`http://localhost:${DEBUG_PORT}/json/list`)).json())
  .find((t) => t.type === 'page').webSocketDebuggerUrl;
const ws = new WebSocket(wsUrl);
let msgId = 0; const pending = new Map(); const errors = [];
ws.onmessage = (ev) => {
  const msg = JSON.parse(ev.data);
  if (msg.id && pending.has(msg.id)) {
    const { resolve, reject } = pending.get(msg.id); pending.delete(msg.id);
    msg.error ? reject(new Error(msg.error.message)) : resolve(msg.result);
  } else if (msg.method === 'Runtime.exceptionThrown') {
    errors.push('EXC: ' + (msg.params.exceptionDetails.exception?.description || msg.params.exceptionDetails.text).split('\n')[0]);
  } else if (msg.method === 'Runtime.consoleAPICalled' && msg.params.type === 'error') {
    errors.push('ERR: ' + msg.params.args.map((a) => a.value ?? a.description ?? '').join(' ').split('\n')[0]);
  } else if (msg.method === 'Log.entryAdded' && msg.params.entry.level === 'error') {
    errors.push('LOG: ' + msg.params.entry.text.split('\n')[0]);
  }
};
const send = (method, params = {}) => new Promise((resolve, reject) => {
  pending.set(++msgId, { resolve, reject }); ws.send(JSON.stringify({ id: msgId, method, params }));
});
await new Promise((res, rej) => { ws.onopen = res; ws.onerror = rej; });
await send('Runtime.enable'); await send('Page.enable'); await send('Log.enable');

async function evalJs(expr) {
  const r = await send('Runtime.evaluate', { expression: expr, returnByValue: true, awaitPromise: true });
  return r.result?.value;
}
async function waitFor(expr, timeoutMs, desc) {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    const v = await evalJs(expr);
    if (v) return true;
    await sleep(400);
  }
  console.log(`  (timeout waiting for ${desc})`);
  return false;
}

// 1) Boot once, seed auth exactly as the login flow does
await send('Page.navigate', { url: APP + '/' });
await sleep(4000);
const seed = `localStorage.clear();localStorage.setItem('token',${JSON.stringify(process.env.VT_TOKEN)});localStorage.setItem('refreshToken',${JSON.stringify(process.env.VT_REFRESH)});localStorage.setItem('tenantId','1');localStorage.setItem('user',${JSON.stringify(process.env.VT_USER)});localStorage.setItem('currentUser',${JSON.stringify(process.env.VT_USER)});'ok'`;
console.log('seed:', await evalJs(seed));

// 2) Navigate straight to each route — Page.navigate is a full reload, so the app
// boots with credentials already in localStorage (avoids the /login logout-cleanup
// race that wipes a fresh seed). Re-seed + retry once if we still bounce to /login.
const reseed = async () => { await evalJs(seed); await sleep(300); };

const clickNew = `(() => {
  const btn = [...document.querySelectorAll('button')].find((b) => /new|add/i.test(b.textContent || ''));
  if (btn) { btn.click(); return 'clicked: ' + (btn.textContent || '').trim().slice(0, 40); }
  return 'NO BUTTON FOUND (path=' + location.pathname + ')';
})()`;

for (const [name, route] of [['Departments', '/app/organization/departments'], ['Designations', '/app/staff/designations']]) {
  const before = errors.length;
  await send('Page.navigate', { url: APP + route });
  let ready = await waitFor(
    `[...document.querySelectorAll('button')].some((b) => /new|add/i.test(b.textContent || '')) && location.pathname === ${JSON.stringify(route)}`,
    20000, `${name} list ready`);
  if (!ready && (await evalJs('location.pathname')) === '/login') {
    await reseed();
    await send('Page.navigate', { url: APP + route });
    ready = await waitFor(
      `[...document.querySelectorAll('button')].some((b) => /new|add/i.test(b.textContent || '')) && location.pathname === ${JSON.stringify(route)}`,
      20000, `${name} list ready (retry)`);
  }
  if (!ready) {
    console.log(`${name}: ✗ list page never became ready (path=${await evalJs('location.pathname')})`);
    continue;
  }
  console.log(`${name}: ${await evalJs(clickNew)}`);

  // Wait for the Material dialog surface to appear
  const opened = await waitFor(
    `!!document.querySelector('.mat-mdc-dialog-surface, .cdk-overlay-container mat-dialog-container')`,
    8000, 'dialog open');
  await sleep(1000); // let the dialog's own change detection run — previously NG0100 territory

  // Close: click Cancel if present, else Escape
  const closed = await evalJs(`(() => {
    const b = [...document.querySelectorAll('.cdk-overlay-container button')].find(x => /^cancel$/i.test((x.textContent||'').trim()));
    if (b) { b.click(); return 'cancel clicked'; }
    return 'no cancel button';
  })()`);
  if (closed === 'no cancel button') {
    await send('Input.dispatchKeyEvent', { type: 'keyDown', key: 'Escape', code: 'Escape', windowsVirtualKeyCode: 27 });
    await send('Input.dispatchKeyEvent', { type: 'keyUp', key: 'Escape', code: 'Escape', windowsVirtualKeyCode: 27 });
  }
  const detached = await waitFor(
    `!document.querySelector('.mat-mdc-dialog-surface')`,
    8000, 'dialog close');
  await sleep(1000); // and the close → reload tick — the other NG0100 territory

  const mine = errors.slice(before);
  const verdict = ready && opened && detached && mine.length === 0 ? '✓ open/close clean' : '✗';
  console.log(`${name}: dialog ${opened ? 'opened' : 'DID NOT OPEN'}, ${detached ? 'closed' : 'DID NOT CLOSE'} → ${verdict}`);
  for (const e of mine) console.log('   ' + e.slice(0, 250));
}
ws.close(); process.exit(0);
