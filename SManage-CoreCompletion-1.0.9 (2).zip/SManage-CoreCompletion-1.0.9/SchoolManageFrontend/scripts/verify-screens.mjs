// Headless Chrome (CDP) screen verification for the signal-migration regression check.
// Usage: node scripts/verify-screens.mjs <routes-file or default list>
const DEBUG_PORT = 9223;
const APP = 'http://localhost:4200';

const ROUTES = process.argv[2]
  ? JSON.parse(process.argv[2])
  : [
      // Core previously-failing screens
      '/app/examinations/results',
      '/app/examinations/results/enter',
      '/app/organization/departments',
      '/app/staff/designations',
      '/app/advanced-academic',
      '/app/advanced-academic/timetable',
      '/app/parents',
      // Fees
      '/app/fees',
      '/app/fees/list',
      '/app/fees/dashboard',
      '/app/fees/waivers',
      '/app/fees/discounts',
      '/app/fees/family-payments',
      // Transport
      '/app/transport',
      '/app/transport/routes',
      '/app/transport/form',
      // Hostel
      '/app/hostels',
      '/app/hostels/rooms',
      // Staff / Students
      '/app/staff',
      '/app/students',
      '/app/students/enquiry-list',
    ];

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function getPageTargetWs() {
  for (let i = 0; i < 30; i++) {
    try {
      const list = await (await fetch(`http://localhost:${DEBUG_PORT}/json/list`)).json();
      const page = list.find((t) => t.type === 'page' && t.webSocketDebuggerUrl);
      if (page) return page.webSocketDebuggerUrl;
    } catch { /* chrome not ready yet */ }
    await sleep(500);
  }
  throw new Error('Could not connect to Chrome debug port');
}

function connect(wsUrl) {
  const ws = new WebSocket(wsUrl);
  let msgId = 0;
  const pending = new Map();
  const listeners = [];
  ws.onmessage = (ev) => {
    const msg = JSON.parse(ev.data);
    if (msg.id && pending.has(msg.id)) {
      const { resolve, reject } = pending.get(msg.id);
      pending.delete(msg.id);
      if (msg.error) reject(new Error(msg.error.message));
      else resolve(msg.result);
    } else if (msg.method) {
      for (const l of listeners) l(msg);
    }
  };
  const send = (method, params = {}) =>
    new Promise((resolve, reject) => {
      const id = ++msgId;
      pending.set(id, { resolve, reject });
      ws.send(JSON.stringify({ id, method, params }));
    });
  const onEvent = (fn) => listeners.push(fn);
  const ready = new Promise((res, rej) => { ws.onopen = res; ws.onerror = rej; });
  return { send, onEvent, ready, close: () => ws.close() };
}

function argToText(a) {
  if (!a) return '';
  if (a.value !== undefined) return typeof a.value === 'string' ? a.value : JSON.stringify(a.value);
  if (a.description) return a.description;
  return JSON.stringify(a);
}

const report = [];
let currentTag = 'startup';
const errors = [];

function record(kind, text, location) {
  const line = `[${kind}] ${text}${location ? ' @ ' + location : ''}`;
  // Keep noise low: real errors only
  if (line.length > 600) report.push(line.slice(0, 600) + '…');
  else report.push(line);
}

const wsUrl = await getPageTargetWs();
const cdp = connect(wsUrl);
await cdp.ready;

cdp.onEvent((msg) => {
  if (msg.method === 'Runtime.consoleAPICalled') {
    const { type, args, stackTrace } = msg.params;
    if (type === 'error' || type === 'assert') {
      const text = args.map(argToText).join(' ');
      const loc = stackTrace?.callFrames?.[0]
        ? `${stackTrace.callFrames[0].url.split('/').pop()}:${stackTrace.callFrames[0].lineNumber + 1}`
        : '';
      record('console.' + type, text, loc);
    }
  } else if (msg.method === 'Runtime.exceptionThrown') {
    const d = msg.params.exceptionDetails;
    const text = d.exception?.description || d.text;
    const loc = d.url ? `${d.url.split('/').pop()}:${d.lineNumber + 1}` : '';
    record('exception', text, loc);
  } else if (msg.method === 'Log.entryAdded') {
    const e = msg.params.entry;
    if (e.level === 'error') record('log.' + e.level, e.text, e.url?.split('/').pop());
  }
});

await cdp.send('Runtime.enable');
await cdp.send('Page.enable');
await cdp.send('Log.enable');

// 1) Load the origin once, seed localStorage exactly like the login flow does
await cdp.send('Page.navigate', { url: APP + '/' });
await sleep(4000);

const seed = {
  token: process.env.VT_TOKEN,
  refreshToken: process.env.VT_REFRESH,
  tenantId: '1',
  user: JSON.stringify({
    id: 1,
    username: 'admin',
    roles: 'Admin',
    email: 'admin@school.com',
    tenantId: 1,
    permissions: JSON.parse(process.env.VT_PERMISSIONS || '[]'),
  }),
};
const seedExpr =
  'localStorage.clear();' +
  Object.entries(seed)
    .map(([k, v]) => `localStorage.setItem(${JSON.stringify(k)}, ${JSON.stringify(v)});`)
    .join('') +
  `localStorage.setItem('currentUser', localStorage.getItem('user'));` +
  `'seeded:' + localStorage.getItem('token').slice(0, 12)`;

const seeded = await cdp.send('Runtime.evaluate', { expression: seedExpr, returnByValue: true });
console.log('SEED:', seeded.result?.value ?? JSON.stringify(seeded.result));

// 2) Visit each route, collect errors
for (const route of ROUTES) {
  currentTag = route;
  const before = report.length;
  await cdp.send('Page.navigate', { url: APP + route });
  await sleep(7000); // let initial HTTP + cascades settle

  const where = await cdp.send('Runtime.evaluate', {
    expression: 'location.pathname',
    returnByValue: true,
  });
  const finalPath = where.result?.value || '?';
  const routeErrors = report.slice(before);
  report.splice(before, 0, `ROUTE ${route} → landed on ${finalPath}`);

  const hasNg0100 = routeErrors.some((e) => e.includes('NG0100'));
  const hasHttp = routeErrors.some((e) => /Http failure|401|404|500|ERR_|Failed to fetch/i.test(e));
  console.log(`\n=== ${route} (landed: ${finalPath}) — ${routeErrors.length} issue(s)${hasNg0100 ? ' ⚠ NG0100' : ''}${hasHttp ? ' ⚠ HTTP' : ''}`);
  for (const e of routeErrors) console.log('  ' + e.split('\n')[0]);
  if (!routeErrors.length) console.log('  ✓ clean');
  errors.push({ route, finalPath, count: routeErrors.length, hasNg0100, hasHttp });
}

console.log('\n===== SUMMARY =====');
for (const e of errors) {
  console.log(`${e.count === 0 ? 'PASS' : 'FAIL'} ${e.route}${e.finalPath !== e.route ? ' (landed ' + e.finalPath + ')' : ''} — ${e.count} issue(s)`);
}
cdp.close();
process.exit(0);
