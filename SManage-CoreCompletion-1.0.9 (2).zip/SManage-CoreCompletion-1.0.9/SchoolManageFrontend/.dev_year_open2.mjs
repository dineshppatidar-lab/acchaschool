// Inspect overlays to locate the year select panel.
const list = await (await fetch('http://127.0.0.1:9229/json/list')).json();
const t = list.find(x => x.type === 'page' && x.url.includes('localhost:4210'));
const ws = new WebSocket(t.webSocketDebuggerUrl);
await new Promise((r, j) => { ws.onopen = r; ws.onerror = j; });
let id = 0; const pend = new Map();
ws.onmessage = ev => { const m = JSON.parse(ev.data); if (m.id && pend.has(m.id)) { pend.get(m.id)(m); pend.delete(m.id); } };
const rp = (m, p) => new Promise(r => { const i = ++id; pend.set(i, r); ws.send(JSON.stringify({ id: i, method: m, params: p || {} })); });
const ev = async e => { const r = await rp('Runtime.evaluate', { expression: e, returnByValue: true, awaitPromise: true }); return r.result?.result?.value; };
await rp('Runtime.enable');

const out = await ev(`(function(){
  const panes=[...document.querySelectorAll('.cdk-overlay-pane')].map(p=>({
    cls:p.className, text:p.textContent.trim().slice(0,120), h:p.offsetHeight,
    options:p.querySelectorAll('.mat-mdc-option').length
  }));
  const panels=[...document.querySelectorAll('.mat-mdc-select-panel')].map(p=>({
    text:p.textContent.trim().slice(0,120), options:p.querySelectorAll('.mat-mdc-option').length,
    bg:getComputedStyle(p).backgroundColor
  }));
  const trigger=document.querySelector('.app-header .academic-year-chip mat-select');
  return JSON.stringify({panes, panels, triggerFocused:document.activeElement===trigger?.querySelector('input')||document.activeElement===trigger, value:trigger?.textContent.trim()});
})()`);
console.log(out);
ws.close(); process.exit(0);
