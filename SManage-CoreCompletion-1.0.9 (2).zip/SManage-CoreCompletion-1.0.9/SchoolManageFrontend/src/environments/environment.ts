export const environment = {
  production: false,
  // Use relative path by default to work in any environment
  apiUrl: '',
  version: '1.0.0',
  // Root domain under which schools get subdomains (e.g. <school>.acchaschool.com).
  // Empty in dev: localhost has no subdomains, everything is treated as the platform.
  // MUST be updated in environment.prod.ts to the real production domain.
  baseDomain: 'acchaschool.com',
  features: {
    analytics: true,
    communication: true,
    finance: true,
    library: true,
    realTimeNotifications: true
  }
};