export const environment = {
  production: true,
  apiUrl: '',
  version: '1.0.0',
  // Root domain under which every school gets its own subdomain.
  // TODO: replace with the actual purchased production domain (must match
  // MultiTenancy__BaseDomain on the API and the wildcard DNS/HTTPS config).
  baseDomain: 'acchaschool.com',
  features: {
    analytics: true,
    communication: true,
    finance: true,
    library: true,
    realTimeNotifications: true
  }
};
