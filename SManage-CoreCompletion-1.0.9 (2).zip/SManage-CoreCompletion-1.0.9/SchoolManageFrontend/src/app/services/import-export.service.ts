import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class ImportExportService {
  constructor(private http: HttpClient) {}

  /** Downloads the Excel admission import template (.xlsx) as a Blob. */
  downloadAdmissionTemplate(): Observable<Blob> {
    return this.http.get('/api/importexport/students/admission-template', {
      responseType: 'blob'
    });
  }

  /** Uploads a filled .xlsx admission template. Returns per-row results/errors. */
  importStudents(file: File): Observable<StudentImportResult> {
    const formData = new FormData();
    formData.append('file', file);
    return this.http.post<StudentImportResult>('/api/importexport/students/import', formData);
  }

  exportStudents(): Observable<Blob> {
    return this.http.get('/api/importexport/students/export', { responseType: 'blob' });
  }
}

export interface StudentImportRowError {
  rowNumber: number;
  studentName: string;
  errors: string[];
}

export interface StudentImportResult {
  success?: boolean;
  importedCount: number;
  imported: string[];
  failedCount: number;
  failedRows: StudentImportRowError[];
  errors: string[];
}
