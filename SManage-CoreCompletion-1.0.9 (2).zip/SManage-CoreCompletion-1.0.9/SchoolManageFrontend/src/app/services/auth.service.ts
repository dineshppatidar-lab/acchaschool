import { Injectable, Injector } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { BehaviorSubject, Observable } from 'rxjs';
import { shareReplay, tap } from 'rxjs/operators';
import { environment } from '../../environments/environment';
import { AcademicYearContextService } from '../shared/services/academic-year-context.service';
import { RealtimeHubService } from './realtime-hub.service';
import { NotificationStreamService } from './notification-stream.service';
import { GlobalLoadingService } from './global-loading.service';

/**
 * Authentication service (docs/critical-issues/05-jwt-lifecycle.md, 16-jwt-in-localstorage.md).
 *
 * Token model:
 *  - Short-lived ACCESS token (30 min): kept in memory and in localStorage for
 *    same-tab restores. It expires quickly, which bounds the XSS exposure window.
 *  - Rotating REFRESH token: single-use; on use it is exchanged for a new pair.
 *    Replaying a used refresh token revokes the whole session family server-side.
 *  - The refresh token is also stored so a page reload can silently re-authenticate.
 */
@Injectable({ providedIn: 'root' })
export class AuthService {
  private userSubject = new BehaviorSubject<any>(null);
  public user$ = this.userSubject.asObservable();
  // Compatibility alias used by some services/guards
  public currentUser$ = this.user$;
  private apiUrl = `${environment.apiUrl}/api/auth`;

  // Lazy-resolved to break the AuthService ⇄ RealtimeHubService constructor cycle
  // (NG0200 at bootstrap — both are providedIn: 'root' and each constructor-injects
  // the other; resolving on first use instead of construction breaks the loop).
  private realtimeInstance?: RealtimeHubService;

  // Same lazy pattern for the notification stream (AuthService → NotificationStreamService
  // would also cycle via RealtimeHubService). Cleared on logout to drop the stale badge
  // and per-user wiring that otherwise caused 401 'unread-count' toasts after logout.
  private notificationStreamInstance?: { reset(): void };
  private get notificationStream(): { reset(): void } | undefined {
    if (!this.notificationStreamInstance) {
      try {
        this.notificationStreamInstance = this.injector.get(NotificationStreamService);
      } catch {
        return undefined; // not creatable in this context (e.g. SSR) — degrade gracefully
      }
    }
    return this.notificationStreamInstance;
  }

  constructor(private http: HttpClient, private router: Router, private yearContext: AcademicYearContextService, private injector: Injector) {
    if (typeof window !== 'undefined' && window.localStorage) {
      const user = localStorage.getItem('user');
      if (user) {
        try {
          this.userSubject.next(JSON.parse(user));
        } catch {
          // Self-heal poisoned values (e.g. the literal string "undefined" left by
          // a refresh response routed through handleAuthResponse before the fix).
          localStorage.removeItem('user');
        }
      }
    }
  }

  private get realtime(): RealtimeHubService | undefined {
    if (!this.realtimeInstance) {
      try {
        this.realtimeInstance = this.injector.get(RealtimeHubService);
      } catch {
        return undefined; // not creatable in this context (e.g. SSR) — degrade gracefully
      }
    }
    return this.realtimeInstance;
  }

  private globalLoadingInstance?: { reset(): void };
  private get globalLoading(): { reset(): void } | undefined {
    if (!this.globalLoadingInstance) {
      try {
        this.globalLoadingInstance = this.injector.get(GlobalLoadingService);
      } catch {
        return undefined; // not creatable in this context (e.g. SSR) — degrade gracefully
      }
    }
    return this.globalLoadingInstance;
  }

  login(username: string, password: string, tenantCode: string): Observable<any> {
    if (!environment.production) {
      console.debug('[AuthService] login called with username:', username, 'tenantCode:', tenantCode);
      console.debug('[AuthService] API URL:', `${this.apiUrl}/login`);
    }

    return this.http.post<any>(`${this.apiUrl}/login`,
      { username, password, tenantCode }
    ).pipe(
      tap(res => {
        if (!environment.production) {
          console.debug('[AuthService] login response received', res);
        }
        this.handleAuthResponse(res);
        // Refresh academic years so the topbar and all modules have fresh data
        this.yearContext.loadAcademicYears().subscribe();
        // Start the authenticated realtime (SignalR) connection for this session.
        void this.realtime?.ensureStarted();
      })
    );
  }

  /** Shared handling of login/refresh responses: persists tokens + user. */
  private handleAuthResponse(res: any): void {
    if (typeof window !== 'undefined' && window.localStorage) {
      const accessToken = res?.token ?? res?.accessToken ?? res?.jwt ?? res?.data?.token ?? res?.data?.accessToken;
      if (accessToken) {
        localStorage.setItem('token', accessToken);
      }
      const refreshToken = res?.refreshToken ?? res?.data?.refreshToken;
      if (refreshToken) {
        localStorage.setItem('refreshToken', refreshToken);
      }
      // Only persist a user object when the response actually contains one.
      // The /refresh endpoint returns { token, refreshToken } with NO user —
      // JSON.stringify(undefined) would store the literal string "undefined",
      // which then crashes JSON.parse on every subsequent boot.
      const user = res.user ?? res.data?.user ?? res.currentUser;
      if (user) {
        localStorage.setItem('user', JSON.stringify(user));
      }
      if (res?.user?.tenantId ?? res?.data?.user?.tenantId ?? res?.currentUser?.tenantId) {
        localStorage.setItem('tenantId', String(res.user?.tenantId ?? res.data?.user?.tenantId ?? res.currentUser?.tenantId));
      }
    }
    this.userSubject.next(res?.user ?? res?.data?.user ?? res?.currentUser);
  }

  /**
   * Exchanges the current refresh token for a fresh access + refresh pair.
   * Emits null when no refresh token exists or the server rejects it.
   *
   * Single-flight at the service level: the refresh token is single-use, so two
   * concurrent refresh() calls would make the loser's token already-revoked → 401
   * → spurious logout. All callers share one in-flight request.
   */
  private refreshInProgress$: Observable<any> | null = null;

  refresh(): Observable<any> {
    const refreshToken = typeof window !== 'undefined' && window.localStorage
      ? localStorage.getItem('refreshToken')
      : null;

    if (!refreshToken) {
      return new Observable<null>(subscriber => {
        subscriber.next(null);
        subscriber.complete();
      });
    }

    if (this.refreshInProgress$) {
      return this.refreshInProgress$;
    }

    this.refreshInProgress$ = this.http.post<any>(`${this.apiUrl}/refresh`, { refreshToken }).pipe(
      tap(res => {
        if (res?.token) {
          this.handleAuthResponse(res);
        }
      }),
      shareReplay({ bufferSize: 1, refCount: true })
    );

    // Clear the slot when the flight lands (success or failure) so the NEXT
    // expiry gets a fresh call instead of the stale cached result.
    this.refreshInProgress$.subscribe({
      error: () => { this.refreshInProgress$ = null; },
      complete: () => { this.refreshInProgress$ = null; }
    });

    return this.refreshInProgress$;
  }

  logout() {
    // Best-effort server-side revocation of the refresh token.
    const refreshToken = typeof window !== 'undefined' && window.localStorage
      ? localStorage.getItem('refreshToken')
      : null;

    // Clear local state FIRST so in-flight/subsequent calls (notification bell,
    // routers, guards) see the logged-out state and skip authorized requests,
    // instead of firing /unread-count etc. with a dead token (401 toasts).
    if (typeof window !== 'undefined' && window.localStorage) {
      localStorage.removeItem('token');
      localStorage.removeItem('refreshToken');
      localStorage.removeItem('user');
      localStorage.removeItem('currentUser');
    }
    this.userSubject.next(null);

    // Reset session-scoped singletons so they hold no stale authed state.
    this.notificationStream?.reset();

    // Global loading safety valve: a forced logout (expired session, silent
    // refresh failure) must never leave the global loading overlay stuck over
    // the login screen. Counters are zeroed here instead of waiting for every
    // in-flight request's finalize() to fire during the redirect.
    this.globalLoading?.reset();

    if (refreshToken) {
      this.http.post(`${this.apiUrl}/logout`, { refreshToken }).subscribe({
        error: () => { /* token may already be invalid — ignore */ }
      });
    }

    // Stop the realtime connection — no anonymous connections allowed server-side.
    void this.realtime?.stop();
    this.router.navigate(['/']);
  }

  // Synchronous accessor for current user (used by PermissionService)
  getCurrentUser(): any {
    const value = this.userSubject.value;
    if (value) return value;
    try {
      const fromStorage = (typeof window !== 'undefined' && window.localStorage)
        ? localStorage.getItem('user')
        : null;
      return fromStorage ? JSON.parse(fromStorage) : null;
    } catch {
      return null;
    }
  }

  register(registerData: any, tenantId: number = 1): Observable<any> {
    if (!environment.production) {
      console.debug('[AuthService] register called for tenantId:', tenantId);
    }
    const headers = { 'X-Tenant-ID': String(tenantId) };
    return this.http.post<any>(`${this.apiUrl}/register`, registerData, { headers });
  }

  get token() {
    if (typeof window !== 'undefined' && window.localStorage) {
      return localStorage.getItem('token');
    }
    return null;
  }

  get refreshToken() {
    if (typeof window !== 'undefined' && window.localStorage) {
      return localStorage.getItem('refreshToken');
    }
    return null;
  }

  get user() {
    return this.userSubject.value;
  }

  isAuthenticated(): boolean {
    return !!this.user && !!this.token;
  }

  hasRole(role: string): boolean {
    return this.user && this.user.role === role;
  }
}
