import { HttpEvent, HttpInterceptorFn, HttpResponse, HttpErrorResponse } from '@angular/common/http';
import { inject } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';

/**
 * Requests that must NEVER surface a toast. The notification bell polls these
 * endpoints in the background; when a session expires mid-poll (or a poll races
 * logout) a raw "Http failure response ... 401 Unauthorized" toast used to pop up
 * on screen — including right after clicking Login. The bell handles its own
 * errors silently, so these stay quiet here too.
 */
const SILENT_URL_FRAGMENTS = [
  '/api/notification/unread-count',
  '/api/notification/mark-read',
  '/api/notification/mark-all-read'
];

/** True when the user is logged out (no token) — 401s then need no toast because
 *  the auth-refresh interceptor already routes the user to the login screen. */
function isLoggedOut(): boolean {
  return typeof window === 'undefined' || !window.localStorage || !localStorage.getItem('token');
}

// Minimal shapes aligned with backend BaseApiController
interface PaginationMetadata {
  totalRecords: number;
  page: number;
  pageSize: number;
  totalPages: number;
}

interface ApiResponse<T = any> {
  success: boolean;
  message?: string;
  statusCode?: number;
  errors?: string[];
  data?: T;
}

interface PaginatedApiResponse<T = any> extends ApiResponse<T[]> {
  pagination: PaginationMetadata;
}

function isApiResponse(body: any): body is ApiResponse {
  return body && typeof body === 'object' && 'success' in body && ('data' in body || 'errors' in body || 'message' in body);
}

function isPaginated<T = any>(body: any): body is PaginatedApiResponse<T> {
  if (!isApiResponse(body)) return false;
  const anyBody: any = body as any;
  return (
    anyBody &&
    typeof anyBody === 'object' &&
    'pagination' in anyBody &&
    anyBody.pagination &&
    typeof (anyBody.pagination as any).totalRecords === 'number'
  );
}

/**
 * Pull the most useful message out of an ApiResponse error body.
 * Backend validation errors come as a DICTIONARY { field: [messages] } (from ModelState
 * or FluentValidation), not an array — handle both shapes.
 */
export function extractApiErrorMessage(body: any): string {
  const errors = body?.errors;
  let detail: string | null = null;
  if (Array.isArray(errors) && errors.length > 0) {
    detail = errors.filter(Boolean).join('; ');
  } else if (errors && typeof errors === 'object') {
    const msgs = Object.values(errors as Record<string, any>)
      .flat()
      .filter((m): m is string => typeof m === 'string' && m.length > 0);
    if (msgs.length > 0) detail = msgs.join('; ');
  }
  // Prefer the specific validation detail; fall back to the generic envelope message.
  return detail || body?.message || 'Request failed';
}

export const apiResponseInterceptor: HttpInterceptorFn = (req, next): Observable<HttpEvent<any>> => {
  const snack = inject(MatSnackBar);
  return next(req).pipe(
    map((event: HttpEvent<any>) => {
      if (event instanceof HttpResponse) {
        const body = event.body;
        if (isApiResponse(body)) {
          // Success unwrapping
          if (body.success !== false) {
            if (isPaginated(body)) {
              const unwrapped = {
                data: body.data ?? [],
                total: body.pagination.totalRecords,
                pagination: body.pagination,
                message: body.message
              };
              return event.clone({ body: unwrapped });
            }
            // Non-paginated: return the inner data directly when present, else keep original body
            const unwrapped = (body.data !== undefined ? body.data : body);
            return event.clone({ body: unwrapped });
          }
          // For explicit failure responses (success === false), surface message/errors
          const errorMsg = extractApiErrorMessage(body);
          snack.open(errorMsg, 'Close', { duration: 5000 });
          // Rewrap into HttpErrorResponse-like flow so subscribers can handle it if needed
          throw new HttpErrorResponse({
            status: body.statusCode ?? 400,
            statusText: 'Error',
            url: event.url ?? undefined,
            error: body
          });
        }
      }
      return event;
    }),
    catchError((err: any) => {
      // Handle transport-level or non-standard errors
      if (err instanceof HttpErrorResponse) {
        const silent = SILENT_URL_FRAGMENTS.some(f => req.url.includes(f));

        // 401 after logout / expired session: the auth-refresh interceptor has
        // already redirected to login — toasting "Http failure response ... 401"
        // on the login screen adds noise, not information.
        if (err.status === 401 && (silent || isLoggedOut())) {
          return throwError(() => err);
        }

        // Rate limited (docs/critical-issues/06-rate-limiting-gaps.md):
        // show a friendly wait message instead of a generic failure.
        if (err.status === 429) {
          if (silent) { return throwError(() => err); }
          const retryAfter = err.headers?.get?.('Retry-After');
          const waitHint = retryAfter
            ? `Please wait ~${retryAfter}s and try again.`
            : 'Please wait a moment and try again.';
          snack.open(`Too many requests. ${waitHint}`, 'Close', { duration: 6000 });
          return throwError(() => err);
        }

        if (silent) { return throwError(() => err); }

        const resp = err.error;
        const message = isApiResponse(resp)
          ? extractApiErrorMessage(resp)
          : err.message || 'Network error';
        snack.open(String(message), 'Close', { duration: 5000 });
      } else {
        snack.open('An unexpected error occurred.', 'Close', { duration: 5000 });
      }
      return throwError(() => err);
    })
  );
};
