import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, map } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MasterDataService {
  private apiUrl = '/api'; // Base URL for your API. Lookup is at /api/lookup

  constructor(private http: HttpClient) { }

  getClasses(): Observable<any> {
    return this.http.get(`${this.apiUrl}/Academic`);
  }

  getSections(): Observable<any> {
    return this.http.get(`${this.apiUrl}/Academic/sections`);
  }

  getParents(): Observable<any> {
    return this.http.get(`${this.apiUrl}/Parents`);
  }

  getBusRoutes(): Observable<any> {
    return this.http.get(`${this.apiUrl}/Transport`);
  }

  // Staff Lookups
  // Lookup endpoints are DB-backed and return [{value, label}]; map to plain label
  // strings for the staff-form dropdown / filter consumers.
  private toLabels = (rows: any): string[] =>
    Array.isArray(rows) ? rows.map((r: any) => (typeof r === 'string' ? r : r?.label ?? String(r))) : [];

  getStaffPositions = (): Observable<string[]> =>
    this.http.get<any[]>(`${this.apiUrl}/lookup/staff-positions`).pipe(map(this.toLabels));

  getStaffDepartments = (): Observable<string[]> =>
    this.http.get<any[]>(`${this.apiUrl}/lookup/staff-departments`).pipe(map(this.toLabels));

  getStaffQualifications = (): Observable<string[]> =>
    this.http.get<any[]>(`${this.apiUrl}/lookup/staff-qualifications`).pipe(map(this.toLabels));

  // Fees Lookups
  getFeeTypes = (): Observable<any[]> => this.http.get<any[]>(`${this.apiUrl}/lookup/fee-types`);
  getFeeStatuses = (): Observable<any[]> => this.http.get<any[]>(`${this.apiUrl}/lookup/fee-statuses`);
  getPaymentMethods = (): Observable<any[]> => this.http.get<any[]>(`${this.apiUrl}/setup/payment-methods`);

  // Finance Lookups
  getExpenseCategories = (): Observable<any[]> => this.http.get<any[]>(`${this.apiUrl}/lookup/expense-categories`);

  // User Lookups
  getUserRoles = (): Observable<any[]> => this.http.get<any[]>(`${this.apiUrl}/lookup/user-roles`);

  // ---------------------------------------------------------
  // Generic CRUD operations for Admin Lookups Management
  // ---------------------------------------------------------
  getLookupData(lookupType: string): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/lookup/${lookupType}`);
  }

  createLookupData(lookupType: string, payload: { value: number; label: string }): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/lookup/${lookupType}`, payload);
  }

  updateLookupData(lookupType: string, id: number, payload: { value: number; label: string }): Observable<any> {
    return this.http.put<any>(`${this.apiUrl}/lookup/${lookupType}/${id}`, payload);
  }

  deleteLookupData(lookupType: string, id: number): Observable<any> {
    return this.http.delete<any>(`${this.apiUrl}/lookup/${lookupType}/${id}`);
  }
}