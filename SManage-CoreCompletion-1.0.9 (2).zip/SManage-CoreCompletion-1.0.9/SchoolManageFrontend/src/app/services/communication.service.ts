import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { delay, map } from 'rxjs/operators';
import { environment } from '../../environments/environment';

export interface Message {
  id: number;
  senderId: number;
  senderType: string;
  subject: string;
  content: string;
  sentDate: Date;
  isRead: boolean;
  priority: string;
  type: string;
  attachmentPath?: string;
  senderName?: string;
  recipientCount?: number;
}

export interface Announcement {
  id: number;
  title: string;
  content: string;
  validFrom: Date;
  validTo?: Date;
  targetAudience: string;
  priority: string;
  type: string;
  isActive: boolean;
  status: string;
  createdBy: string;
  attachmentPath?: string;
  attachments?: any[];
}

export interface Event {
  id: number;
  title: string;
  description: string;
  startDate: string | Date;
  endDate: string | Date;
  startTime: string;
  endTime: string;
  location: string;
  type: string;
  maxParticipants?: number;
  registrationDeadline?: string | Date;
  status: string;
  organizedBy: number;
  organizer?: string;
  participants?: any[];
  participantCount?: number;
  isPublic?: boolean;
  isAllDay?: boolean;
  color?: string;
}

export interface MessageStats {
  unreadCount: number;
  todayCount: number;
  totalCount: number;
  sentCount: number;
  deliveredCount: number;
  readCount: number;
}

@Injectable({
  providedIn: 'root'
})
export class CommunicationService {
  private readonly apiUrl = `${environment.apiUrl}/api/communication`;

  constructor(private http: HttpClient) {}

  private lookupUrl = `${environment.apiUrl}/api/lookup`;

  private mapResponse<T>(response: any): T {
    if (response?.data !== undefined) return response.data;
    if (response?.Data !== undefined) return response.Data;
    return response;
  }

  private mapArrayResponse<T>(response: any): T[] {
    if (Array.isArray(response)) return response;
    const data = response?.data !== undefined ? response.data : response?.Data;
    return data || [];
  }

  // Lookup data
  getMessagePriorities(): Observable<any[]> {
    return this.http.get<any>(`${this.lookupUrl}/message-priorities`).pipe(
      map(response => this.mapArrayResponse<any>(response))
    );
  }

  getMessageTypes(): Observable<any[]> {
    return this.http.get<any>(`${this.lookupUrl}/message-types`).pipe(
      map(response => this.mapArrayResponse<any>(response))
    );
  }

  // Message Management
  getMessages(
    messageType?: string, 
    status?: string, 
    search?: string, 
    page: number = 1, 
    pageSize: number = 20
  ): Observable<Message[]> {
    let params = new HttpParams()
      .set('page', page.toString())
      .set('pageSize', pageSize.toString());
    
    if (messageType) params = params.set('messageType', messageType);
    if (status) params = params.set('status', status);
    if (search) params = params.set('search', search);

    return this.http.get<any>(`${this.apiUrl}/messages`, { params }).pipe(
      map(response => this.mapArrayResponse<Message>(response))
    );
  }

  getMessageById(messageId: number): Observable<Message> {
    return this.http.get<any>(`${this.apiUrl}/messages/${messageId}`).pipe(
      map(response => this.mapResponse<Message>(response))
    );
  }

  sendMessage(message: Partial<Message>): Observable<Message> {
    return this.http.post<any>(`${this.apiUrl}/messages`, message).pipe(
      map(response => this.mapResponse<Message>(response))
    );
  }

  updateMessage(messageId: number, message: Partial<Message>): Observable<Message> {
    return this.http.put<any>(`${this.apiUrl}/messages/${messageId}`, message).pipe(
      map(response => this.mapResponse<Message>(response))
    );
  }

  sendBulkMessage(message: any): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/messages/bulk-send`, message).pipe(
      map(response => this.mapResponse<any>(response))
    );
  }

  replyToMessage(messageId: number, reply: any): Observable<Message> {
    return this.http.post<any>(`${this.apiUrl}/messages/${messageId}/reply`, reply).pipe(
      map(response => this.mapResponse<Message>(response))
    );
  }

  forwardMessage(messageId: number, forward: any): Observable<Message> {
    return this.http.post<any>(`${this.apiUrl}/messages/${messageId}/forward`, forward).pipe(
      map(response => this.mapResponse<Message>(response))
    );
  }

  markMessageAsRead(messageId: number): Observable<void> {
    return this.http.put<void>(`${this.apiUrl}/messages/${messageId}/mark-read`, {});
  }

  markAllMessagesAsRead(): Observable<void> {
    return this.http.put<void>(`${this.apiUrl}/messages/mark-all-read`, {});
  }

  deleteMessage(messageId: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/messages/${messageId}`);
  }

  getMessageStats(): Observable<MessageStats> {
    return this.http.get<any>(`${this.apiUrl}/messages/stats`).pipe(
      map(response => this.mapResponse<MessageStats>(response))
    );
  }

  searchMessages(query: string): Observable<Message[]> {
    const params = new HttpParams().set('q', query);
    return this.http.get<any>(`${this.apiUrl}/messages/search`, { params }).pipe(
      map(response => this.mapArrayResponse<Message>(response))
    );
  }

  // Announcement Management
  getAnnouncements(
    targetAudience?: string,
    status?: string,
    page: number = 1,
    pageSize: number = 20
  ): Observable<Announcement[]> {
    let params = new HttpParams()
      .set('page', page.toString())
      .set('pageSize', pageSize.toString());
    
    if (targetAudience) params = params.set('targetType', targetAudience);
    if (status) params = params.set('status', status);

    return this.http.get<any>(`${this.apiUrl}/announcements`, { params }).pipe(
      map(response => this.mapArrayResponse<Announcement>(response))
    );
  }

  getAnnouncementById(announcementId: number): Observable<Announcement> {
    return this.http.get<any>(`${this.apiUrl}/announcements/${announcementId}`).pipe(
      map(response => this.mapResponse<Announcement>(response))
    );
  }

  createAnnouncement(announcement: Partial<Announcement>): Observable<Announcement> {
    return this.http.post<any>(`${this.apiUrl}/announcements`, announcement).pipe(
      map(response => this.mapResponse<Announcement>(response))
    );
  }

  updateAnnouncement(announcementId: number, announcement: Partial<Announcement>): Observable<Announcement> {
    return this.http.put<any>(`${this.apiUrl}/announcements/${announcementId}`, announcement).pipe(
      map(response => this.mapResponse<Announcement>(response))
    );
  }

  publishAnnouncement(announcementId: number): Observable<void> {
    return this.http.put<void>(`${this.apiUrl}/announcements/${announcementId}/publish`, {});
  }

  scheduleAnnouncement(announcementId: number, publishDate: Date): Observable<void> {
    return this.http.put<void>(`${this.apiUrl}/announcements/${announcementId}/schedule`, { publishDate });
  }

  publishAllDrafts(): Observable<void> {
    return this.http.put<void>(`${this.apiUrl}/announcements/publish-all-drafts`, {});
  }

  deleteAnnouncement(announcementId: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/announcements/${announcementId}`);
  }

  duplicateAnnouncement(announcementId: number): Observable<Announcement> {
    return this.http.post<any>(`${this.apiUrl}/announcements/${announcementId}/duplicate`, {}).pipe(
      map(response => this.mapResponse<Announcement>(response))
    );
  }

  getAnnouncementViews(announcementId: number): Observable<any[]> {
    return this.http.get<any>(`${this.apiUrl}/announcements/${announcementId}/views`).pipe(
      map(response => this.mapArrayResponse<any>(response))
    );
  }

  // Event Management
  getEvents(
    startDate?: Date,
    endDate?: Date,
    upcoming: number = 30
  ): Observable<Event[]> {
    let params = new HttpParams().set('upcoming', upcoming.toString());
    
    if (startDate) params = params.set('startDate', startDate.toISOString());
    if (endDate) params = params.set('endDate', endDate.toISOString());
    
    return this.http.get<any>(`${this.apiUrl}/events`, { params }).pipe(
      map(response => {
        console.log('API Response for getEvents:', response);
        return this.mapArrayResponse<Event>(response);
      })
    );
  }

  getEventById(eventId: number): Observable<Event> {
    return this.http.get<any>(`${this.apiUrl}/events/${eventId}`).pipe(
      map(response => this.mapResponse<Event>(response))
    );
  }

  createEvent(event: Partial<Event>): Observable<Event> {
    return this.http.post<any>(`${this.apiUrl}/events`, event).pipe(
      map(response => this.mapResponse<Event>(response))
    );
  }

  updateEvent(eventId: number, event: Partial<Event>): Observable<Event> {
    return this.http.put<any>(`${this.apiUrl}/events/${eventId}`, event).pipe(
      map(response => this.mapResponse<Event>(response))
    );
  }

  cancelEvent(eventId: number): Observable<void> {
    return this.http.put<void>(`${this.apiUrl}/events/${eventId}/cancel`, {});
  }

  deleteEvent(eventId: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/events/${eventId}`);
  }

  // Event Participation Management
  registerForEvent(eventId: number, participantData: any): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/events/${eventId}/register`, participantData).pipe(
      map(response => this.mapResponse<any>(response))
    );
  }

  getEventParticipants(eventId: number): Observable<any[]> {
    return this.http.get<any>(`${this.apiUrl}/events/${eventId}/participants`).pipe(
      map(response => this.mapArrayResponse<any>(response))
    );
  }

  updateParticipantStatus(eventId: number, participantId: number, status: string): Observable<void> {
    return this.http.put<void>(`${this.apiUrl}/events/${eventId}/participants/${participantId}/status`, { status });
  }

  bulkUpdateParticipants(eventId: number, updates: any[]): Observable<void> {
    return this.http.put<void>(`${this.apiUrl}/events/${eventId}/participants/bulk-update`, updates);
  }

  sendEventReminder(eventId: number): Observable<void> {
    return this.http.post<void>(`${this.apiUrl}/events/${eventId}/send-reminder`, {});
  }

  // Parent-Teacher Meeting Management
  getParentTeacherMeetings(
    classId?: number,
    staffId?: number,
    status?: string,
    page: number = 1,
    pageSize: number = 20
  ): Observable<any[]> {
    let params = new HttpParams()
      .set('page', page.toString())
      .set('pageSize', pageSize.toString());
    
    if (classId) params = params.set('classId', classId.toString());
    if (staffId) params = params.set('staffId', staffId.toString());
    if (status) params = params.set('status', status);
    
    return this.http.get<any>(`${this.apiUrl}/parent-teacher-meetings`, { params }).pipe(
      map(response => this.mapArrayResponse<any>(response))
    );
  }

  schedulePTMeeting(meeting: any): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/parent-teacher-meetings`, meeting).pipe(
      map(response => this.mapResponse<any>(response))
    );
  }

  updatePTMeeting(meetingId: number, meeting: any): Observable<any> {
    return this.http.put<any>(`${this.apiUrl}/parent-teacher-meetings/${meetingId}`, meeting).pipe(
      map(response => this.mapResponse<any>(response))
    );
  }

  cancelPTMeeting(meetingId: number): Observable<void> {
    return this.http.put<void>(`${this.apiUrl}/parent-teacher-meetings/${meetingId}/cancel`, {});
  }

  confirmPTMeeting(meetingId: number): Observable<void> {
    return this.http.put<void>(`${this.apiUrl}/parent-teacher-meetings/${meetingId}/confirm`, {});
  }

  rescheduldePTMeeting(meetingId: number, newDateTime: Date): Observable<any> {
    return this.http.put<any>(`${this.apiUrl}/parent-teacher-meetings/${meetingId}/reschedule`, { newDateTime }).pipe(
      map(response => this.mapResponse<any>(response))
    );
  }

  // Communication Analytics
  getMessageAnalytics(startDate?: Date, endDate?: Date): Observable<any> {
    let params = new HttpParams();
    if (startDate) params = params.set('startDate', startDate.toISOString());
    if (endDate) params = params.set('endDate', endDate.toISOString());
    
    return this.http.get<any>(`${this.apiUrl}/analytics/messages`, { params }).pipe(
      map(response => this.mapResponse<any>(response))
    );
  }

  getAnnouncementAnalytics(startDate?: Date, endDate?: Date): Observable<any> {
    let params = new HttpParams();
    if (startDate) params = params.set('startDate', startDate.toISOString());
    if (endDate) params = params.set('endDate', endDate.toISOString());
    
    return this.http.get<any>(`${this.apiUrl}/analytics/announcements`, { params }).pipe(
      map(response => this.mapResponse<any>(response))
    );
  }

  getEventAnalytics(startDate?: Date, endDate?: Date): Observable<any> {
    let params = new HttpParams();
    if (startDate) params = params.set('startDate', startDate.toISOString());
    if (endDate) params = params.set('endDate', endDate.toISOString());
    
    return this.http.get<any>(`${this.apiUrl}/analytics/events`, { params }).pipe(
      map(response => this.mapResponse<any>(response))
    );
  }

  getParentEngagementReport(): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/analytics/parent-engagement`).pipe(
      map(response => this.mapResponse<any>(response))
    );
  }

  getCommunicationTrends(): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/analytics/communication-trends`).pipe(
      map(response => this.mapResponse<any>(response))
    );
  }

  // File and Attachment Management
  uploadAttachment(file: File): Observable<any> {
    const formData = new FormData();
    formData.append('file', file);
    return this.http.post<any>(`${this.apiUrl}/attachments/upload`, formData).pipe(
      map(response => this.mapResponse<any>(response))
    );
  }

  deleteAttachment(attachmentId: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/attachments/${attachmentId}`);
  }

  downloadAttachment(attachmentId: number): Observable<Blob> {
    return this.http.get(`${this.apiUrl}/attachments/${attachmentId}/download`, { responseType: 'blob' });
  }

  // Export Functions
  exportMessages(format: 'pdf' | 'excel' | 'csv' = 'excel'): Observable<Blob> {
    const params = new HttpParams().set('format', format);
    return this.http.get(`${this.apiUrl}/messages/export`, { 
      params, 
      responseType: 'blob' 
    });
  }

  exportAnnouncements(format: 'pdf' | 'excel' | 'csv' = 'excel'): Observable<Blob> {
    const params = new HttpParams().set('format', format);
    return this.http.get(`${this.apiUrl}/announcements/export`, { 
      params, 
      responseType: 'blob' 
    });
  }

  exportEvents(format: 'pdf' | 'excel' | 'ics' = 'ics'): Observable<Blob> {
    const params = new HttpParams().set('format', format);
    return this.http.get(`${this.apiUrl}/events/export`, { 
      params, 
      responseType: 'blob' 
    });
  }

  exportEventCalendar(startDate: Date, endDate: Date): Observable<Blob> {
    const params = new HttpParams()
      .set('startDate', startDate.toISOString())
      .set('endDate', endDate.toISOString());
    return this.http.get(`${this.apiUrl}/events/export-calendar`, { 
      params, 
      responseType: 'blob' 
    });
  }

  // Template Management
  getMessageTemplates(): Observable<any[]> {
    return this.http.get<any>(`${this.apiUrl}/templates/messages`).pipe(
      map(response => this.mapArrayResponse<any>(response))
    );
  }

  getAnnouncementTemplates(): Observable<any[]> {
    return this.http.get<any>(`${this.apiUrl}/templates/announcements`).pipe(
      map(response => this.mapArrayResponse<any>(response))
    );
  }

  createMessageTemplate(template: any): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/templates/messages`, template).pipe(
      map(response => this.mapResponse<any>(response))
    );
  }

  createAnnouncementTemplate(template: any): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/templates/announcements`, template).pipe(
      map(response => this.mapResponse<any>(response))
    );
  }

  updateTemplate(templateId: number, template: any): Observable<any> {
    return this.http.put<any>(`${this.apiUrl}/templates/${templateId}`, template).pipe(
      map(response => this.mapResponse<any>(response))
    );
  }

  deleteTemplate(templateId: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/templates/${templateId}`);
  }

  // Notification Management
  getNotificationSettings(): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/notifications/settings`).pipe(
      map(response => this.mapResponse<any>(response))
    );
  }

  updateNotificationSettings(settings: any): Observable<any> {
    return this.http.put<any>(`${this.apiUrl}/notifications/settings`, settings).pipe(
      map(response => this.mapResponse<any>(response))
    );
  }

  sendTestNotification(type: string, recipient: string): Observable<void> {
    return this.http.post<void>(`${this.apiUrl}/notifications/test`, { type, recipient });
  }
}
