import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { RealtimeHubService } from './realtime-hub.service';

export interface Vehicle {
  id?: number;
  vehicleNumber: string;
  model: string;
  capacity: number;
  status: string;
  vehicleType?: string;
  manufacturer?: string;
  driverName?: string;
  driverContact?: string;
  driverLicense?: string;
  fuelType?: string;
  purchaseDate?: string | Date;
  insuranceExpiry?: string | Date;
  fitnessExpiry?: string | Date;
  description?: string;
  routeId?: number;
}

export interface BusRoute {
  id: number;
  routeName: string;
  description?: string;
  startTime?: string; // HH:mm
  endTime?: string;   // HH:mm
  vehicleId?: number;
  driverId?: number;
}

export interface RouteStop {
  id: number;
  routeId: number;
  stopName: string;
  arrivalTime?: string; // HH:mm
  latitude?: number;
  longitude?: number;
  sequenceNumber: number;
}

@Injectable({ providedIn: 'root' })
export class TransportService {
  private baseUrl = '/api/transport';

  constructor(private http: HttpClient, private realtime: RealtimeHubService) {
    void realtime.ensureStarted();
  }

  // Vehicles APIs
  getVehicles(params?: { page?: number; pageSize?: number; sort?: string; order?: 'asc'|'desc'; search?: string }): Observable<Vehicle[]> {
    let httpParams = new HttpParams();
    if (params) {
      Object.entries(params).forEach(([k, v]) => {
        if (v !== undefined && v !== null && v !== '') httpParams = httpParams.set(k, String(v));
      });
    }
    return this.http.get<{ data: Vehicle[]; total: number }>(`${this.baseUrl}/vehicles`, { params: httpParams }).pipe(
      map((response) => response?.data || [])
    );
  }

  getVehicleById(id: number): Observable<Vehicle> {
    return this.http.get<Vehicle>(`${this.baseUrl}/vehicles/${id}`);
  }

  /** Real assigned-student count per vehicle id — issue #7 */
  getVehicleStatistics(): Observable<Record<number, number>> {
    return this.http.get<any>(`${this.baseUrl}/vehicles/statistics`).pipe(
      map((response: any) => {
        // Interceptor unwraps ApiResponse -> data (Dictionary<int,int> serialized as object map).
        // Fall back to .data defensively in case the unwrapping changes.
        const raw = (response && typeof response === 'object' && !Array.isArray(response)
          && Object.values(response).every(v => typeof v === 'number'))
          ? response
          : response?.data;
        const map: Record<number, number> = {};
        if (raw && typeof raw === 'object') {
          for (const [key, value] of Object.entries(raw)) {
            const id = Number(key);
            if (!Number.isNaN(id)) map[id] = Number(value) || 0;
          }
        }
        return map;
      })
    );
  }

  create(data: Vehicle): Observable<Vehicle> {
    return this.http.post<Vehicle>(`${this.baseUrl}/vehicles`, data);
  }

  update(id: number, data: Vehicle): Observable<void> {
    return this.http.put<void>(`${this.baseUrl}/vehicles/${id}`, data);
  }

  delete(id: number): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/vehicles/${id}`);
  }

  exportVehicles(params?: { format?: 'csv' }): Observable<Blob> {
    const httpParams = new HttpParams({ fromObject: { ...(params || {}) } });
    return this.http.get(`${this.baseUrl}/vehicles/export`, { params: httpParams, responseType: 'blob' });
  }

  exportRouteManifest(routeId: number): Observable<Blob> {
    return this.http.get(`${this.baseUrl}/routes/${routeId}/manifest/export`, { responseType: 'blob' });
  }

  // Routes APIs (list routes are at base endpoint)
  getRoutes(params?: { page?: number; pageSize?: number; sort?: string; order?: 'asc'|'desc'; search?: string }): Observable<BusRoute[]> {
    let httpParams = new HttpParams();
    if (params) {
      Object.entries(params).forEach(([k, v]) => {
        if (v !== undefined && v !== null && v !== '') httpParams = httpParams.set(k, String(v));
      });
    }
    return this.http.get<any>(`${this.baseUrl}`, { params: httpParams }).pipe(
      map((response) => {
        if (Array.isArray(response)) return response;
        return response?.data || response?.items || [];
      })
    );
  }

  getRouteById(id: number): Observable<BusRoute> {
    return this.http.get<BusRoute>(`${this.baseUrl}/${id}`);
  }

  createRoute(route: Partial<BusRoute>): Observable<BusRoute> {
    return this.http.post<BusRoute>(`${this.baseUrl}`, route);
  }

  updateRoute(id: number, route: Partial<BusRoute>): Observable<void> {
    return this.http.put<void>(`${this.baseUrl}/${id}`, route);
  }

  deleteRoute(id: number): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/${id}`);
  }

  // Route Stops APIs
  getRouteStops(routeId: number): Observable<RouteStop[]> {
    return this.http.get<RouteStop[]>(`${this.baseUrl}/routes/${routeId}/stops`);
    }

  addRouteStop(routeId: number, stop: Partial<RouteStop>): Observable<RouteStop> {
    return this.http.post<RouteStop>(`${this.baseUrl}/routes/${routeId}/stops`, stop);
  }

  updateRouteStop(routeId: number, stop: RouteStop): Observable<void> {
    return this.http.put<void>(`${this.baseUrl}/routes/${routeId}/stops/${stop.id}`, stop);
  }

  deleteRouteStop(routeId: number, stopId: number): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/routes/${routeId}/stops/${stopId}`);
  }

  reorderRouteStops(routeId: number, order: { stopId: number; sequenceNumber: number }[]): Observable<void> {
    return this.http.post<void>(`${this.baseUrl}/routes/${routeId}/stops/reorder`, order);
  }

  // Route student assignment
  getRouteStudents(routeId: number): Observable<any[]> {
    return this.http.get<any[]>(`${this.baseUrl}/routes/${routeId}/students`);
  }

  assignStudentToRoute(studentId: number, routeId: number): Observable<any> {
    return this.http.post<any>(`${this.baseUrl}/assign-student`, { studentId, routeId });
  }

  unassignStudentFromRoute(studentId: number): Observable<any> {
    return this.http.post<any>(`${this.baseUrl}/unassign-student/${studentId}`, {});
  }

  onTransportChanged(callback: (data: any) => void) {
    this.realtime.on('TransportChanged', callback);
  }
  // TODO: Integrate NotificationService and AuditLogService for notifications and audit logs
}