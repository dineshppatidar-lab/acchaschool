import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface PayrollRun {
  id: number;
  month: number;
  year: number;
  payDate: string;
  status: string;
  totalAmount: number;
  processedDate: string;
  payslips: Payslip[];
}

export interface Payslip {
  id: number;
  staffId: number;
  basicSalary: number;
  allowances: number;
  deductions: number;
  netSalary: number;
  status: string;
  remarks: string;
  staff?: {
    firstName: string;
    lastName: string;
    position: string;
  };
}

@Injectable({
  providedIn: 'root'
})
export class PayrollService {
  private baseUrl = '/api/payroll';

  constructor(private http: HttpClient) {}

  getPayrollRuns(): Observable<PayrollRun[]> {
    return this.http.get<PayrollRun[]>(`${this.baseUrl}/runs`);
  }

  getPayrollRunDetails(id: number): Observable<PayrollRun> {
    return this.http.get<PayrollRun>(`${this.baseUrl}/runs/${id}`);
  }

  processPayroll(year: number, month: number): Observable<any> {
    return this.http.post(`${this.baseUrl}/process/${year}/${month}`, {});
  }
}