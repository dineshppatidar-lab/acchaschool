import { HttpRequest, HttpResponse, HttpEvent, HttpHandlerFn } from '@angular/common/http';
import { of, Observable } from 'rxjs';

import { baseUrlInterceptor } from './base-url-interceptor';

/**
 * baseUrlInterceptor is an HttpInterceptorFn (functional interceptor).
 * Invoke it directly with a capturing handler instead of TestBed.inject —
 * functional interceptors are plain functions, not DI tokens.
 */
describe('baseUrlInterceptor', () => {
  /** URL observed by the handler, i.e. the request the interceptor forwarded. */
  let seenUrl: string | undefined;

  const next: HttpHandlerFn = (req: HttpRequest<unknown>): Observable<HttpEvent<unknown>> => {
    seenUrl = req.url;
    return of(new HttpResponse<unknown>({ body: null, url: req.url }));
  };

  const invoke = (url: string) =>
    baseUrlInterceptor(new HttpRequest('GET', url), next).toPromise();

  it('is defined as a function', () => {
    expect(typeof baseUrlInterceptor).toBe('function');
  });

  it('leaves absolute URLs untouched', async () => {
    await invoke('https://api.example.com/students');
    expect(seenUrl).toBe('https://api.example.com/students');
  });

  it('keeps relative URLs base-relative when environment.apiUrl is empty', async () => {
    await invoke('/api/students');
    // environment.apiUrl is '' (same-origin): no scheme is prepended.
    expect(seenUrl).toBe('/api/students');
  });

  it('normalizes a relative URL without a leading slash', async () => {
    await invoke('students/1');
    expect(seenUrl?.startsWith('/students/1')).toBe(true);
  });
});
