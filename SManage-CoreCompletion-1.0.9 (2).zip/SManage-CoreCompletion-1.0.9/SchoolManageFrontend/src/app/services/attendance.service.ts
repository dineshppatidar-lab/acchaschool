import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';

// ── DTOs ──

export interface AttendanceRecord {
  id: number;
  date: string;
  studentId: number;
  studentName: string;
  classId: number;
  className: string;
  sectionId: number;
  sectionName: string;
  isPresent: boolean;
  remarks: string;
}

export interface AttendanceSummaryResponse {
  date: string;
  totalStudents: number;
  presentStudents: number;
  absentStudents: number;
  percentage: number;
}

export interface AttendanceHistoryResponse {
  records: AttendanceRecord[];
  summary: AttendanceSummaryResponse;
  dateRange: { from: string; to: string };
}

export interface AttendanceAnalyticsResponse {
  overall: { totalDays: number; presentDays: number; absentDays: number; percentage: number };
  monthly: { month: string; percentage: number; present: number; absent: number }[];
  classWise: { className: string; percentage: number }[];
  lowAttendance: { studentId: number; name: string; className: string; percentage: number; absentDays: number }[];
}

export interface StudentForAttendance {
  id: number;
  firstName: string;
  lastName: string;
  rollNumber: string;
  isPresent: boolean;
  remarks: string;
}

export interface ClassOption {
  id: number;
  name: string;
}

export interface SectionOption {
  id: number;
  name: string;
}

@Injectable({ providedIn: 'root' })
export class AttendanceService {
  private baseUrl = '/api';
  private dailyOpsUrl = `${this.baseUrl}/dailyops`;

  constructor(private http: HttpClient) {}

  /** Get daily summary for a date */
  getDailySummary(date: string): Observable<any> {
    return this.http.get(`${this.dailyOpsUrl}/summary`, { params: { date } });
  }

  /** Get attendance records for a date range */
  getAttendanceHistory(classId?: number, sectionId?: number, fromDate?: string, toDate?: string): Observable<any> {
    let params = new HttpParams();
    if (classId) params = params.set('classId', classId.toString());
    if (sectionId) params = params.set('sectionId', sectionId.toString());
    if (fromDate) params = params.set('fromDate', fromDate);
    if (toDate) params = params.set('toDate', toDate);
    return this.http.get(`${this.dailyOpsUrl}/attendance/history`, { params });
  }

  /** Quick mark attendance (existing backend endpoint) */
  quickMarkAttendance(payload: { classId: number; sectionId: number; date: string; presentStudentIds: number[] }): Observable<any> {
    return this.http.post(`${this.dailyOpsUrl}/attendance/quick-mark`, payload);
  }

  /** Get attendance analytics */
  getAttendanceAnalytics(classId?: number, studentId?: number): Observable<any> {
    let params = new HttpParams();
    if (classId) params = params.set('classId', classId.toString());
    if (studentId) params = params.set('studentId', studentId.toString());
    return this.http.get(`${this.baseUrl}/analytics/attendance/analytics`, { params });
  }

  /**
   * Students of ONE class/section for attendance marking.
   *
   * Root-cause fix: this used to call GET /students/full-details, which is a
   * paginated whole-tenant listing (default page size 20) that IGNORES the
   * classId/sectionId query params — so the Mark Attendance tab silently
   * showed the first 20 students of the school regardless of the selected
   * class/section, and only those 20 were ever saved. The scoped section
   * endpoint returns exactly the students of the chosen section (tenant-
   * scoped server-side via the global query filter).
   */
  getStudents(classId?: number, sectionId?: number): Observable<any> {
    if (sectionId) {
      return this.http.get(`${this.baseUrl}/students/section/${sectionId}`);
    }
    // Fallback when only a class is chosen (shouldn't happen from the UI,
    // which always selects a section first, but keeps the service generic).
    // Uses the class-scoped endpoint — NOT /students/full-details, which
    // ignores classId and returns a paginated whole-tenant list.
    let params = new HttpParams();
    if (classId) return this.http.get(`${this.baseUrl}/students/class/${classId}`);
    return this.http.get(`${this.baseUrl}/students/full-details`, { params });
  }

  /** Get all classes */
  getClasses(): Observable<ClassOption[]> {
    return this.http.get<ClassOption[]>(`${this.baseUrl}/academic/all`);
  }

  /** Get classes for a specific academic year (avoids same-name classes from other years) */
  getClassesByAcademicYear(academicYearId: number): Observable<ClassOption[]> {
    return this.http.get<ClassOption[]>(`${this.baseUrl}/academic/year/${academicYearId}`);
  }

  /** Get sections for a specific class */
  getSectionsByClass(classId: number): Observable<SectionOption[]> {
    return this.http.get<SectionOption[]>(`${this.baseUrl}/academic/class/${classId}/sections`);
  }
}
