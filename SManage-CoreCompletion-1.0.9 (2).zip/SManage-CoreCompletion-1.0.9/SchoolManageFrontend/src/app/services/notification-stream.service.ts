import { Injectable, OnDestroy, computed, inject, signal } from '@angular/core';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';
import { Router, NavigationEnd } from '@angular/router';
import { filter } from 'rxjs/operators';

import { RealtimeHubService } from './realtime-hub.service';
import { AuthService } from './auth.service';

/**
 * A notification row as served by GET /api/notification (envelope already
 * unwrapped by apiResponseInterceptor).
 */
export interface AppNotification {
  id: number;
  title: string;
  message: string;
  type: string;
  isRead: boolean;
  link?: string | null;
  data?: string | null;
  userId: number;
  createdOn: string;
}

/**
 * Single source of truth for the header notification bell.
 *
 * State is held in SIGNALS (the app runs zoneless — BehaviorSubject + async
 * pipe does not schedule change detection, signals do):
 *  - initial + refresh loads from GET /api/notification
 *  - live additions pushed over the shared ActivityHub connection
 *    (ReceiveNotification) — no extra socket of its own
 *  - click-through marks read and navigates to the notification's Link
 */
@Injectable({ providedIn: 'root' })
export class NotificationStreamService implements OnDestroy {
  private http = inject(HttpClient);
  private realtime = inject(RealtimeHubService);
  private auth = inject(AuthService);
  private router = inject(Router);

  private readonly destroy$ = new Subject<void>();
  private readonly notificationsSignal = signal<AppNotification[]>([]);
  private wired = false;
  private startedForUserId: number | null = null;

  /** All loaded notifications (newest first). */
  readonly notifications = this.notificationsSignal.asReadonly();
  /** Unread badge count for the bell. */
  readonly unreadCount = computed(() => this.notificationsSignal().filter(n => !n.isRead).length);
  /** Emits each notification that arrives live over SignalR (for toasts). */
  readonly liveArrival$ = new Subject<AppNotification>();

  /** Idempotent — wire hub handlers and load the first page once per login. */
  start(): void {
    const userId: number | null = this.auth.user?.id ?? null;
    if (!this.auth.token) { return; }
    if (this.wired && this.startedForUserId === userId) { return; }
    this.wired = true;
    this.startedForUserId = userId;

    void this.realtime.ensureStarted();

    // Live push from the hub (broadcasts + targeted sends both use this method).
    this.realtime.on('ReceiveNotification', (payload: any) => {
      this.onLiveNotification(payload);
    });

    this.refresh();

    // Refresh the badge when navigating — but ONLY while still authenticated.
    // Without this guard the subscription kept firing /unread-count after logout
    // (401 Unauthorized toast on the login screen) because the service is a
    // root-level singleton that outlives the session.
    this.router.events
      .pipe(
        filter((e): e is NavigationEnd => e instanceof NavigationEnd),
        takeUntil(this.destroy$)
      )
      .subscribe(() => {
        if (!this.auth.token) { return; }
        this.refreshUnreadCount();
      });
  }

  /**
   * Clears cached notifications and per-user wiring (called on logout). Prevents
   * a stale badge / leaked subscription firing authenticated calls with no token
   * (the 401 'unread-count' error previously seen right after logout and on the
   * login screen).
   */
  reset(): void {
    this.notificationsSignal.set([]);
    this.wired = false;
    this.startedForUserId = null;
  }

  /** Latest list from the API (100 most recent). */
  refresh(): void {
    if (!this.auth.token) { return; } // logged out — never call an authorized endpoint
    this.http.get<AppNotification[]>('/api/notification')
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: list => {
          const rows = Array.isArray(list) ? list : [];
          this.notificationsSignal.set(rows);
        },
        error: () => { /* bell degrades silently */ }
      });
  }

  private refreshUnreadCount(): void {
    if (!this.auth.token) { return; } // logged out — never call an authorized endpoint
    this.http.get<{ count: number }>('/api/notification/unread-count')
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: r => {
          // If the server disagrees with our local view, re-fetch the list;
          // otherwise the authoritative server count wins via refresh anyway.
          if ((r?.count ?? 0) !== this.unreadCount()) { this.refresh(); }
        },
        error: () => { /* silent */ }
      });
  }

  private onLiveNotification(payload: any): void {
    // The hub payload is ephemeral — the server persists the real row just
    // before/after broadcasting, so reconcile by refreshing the list.
    const type = String(payload?.Type ?? payload?.type ?? '');
    const message = String(payload?.Message ?? payload?.message ?? '');
    if (!type && !message) { return; }
    this.liveArrival$.next({
      id: 0,
      title: type.split(/[_\-\s]/).filter(Boolean).map((w: string) => w[0].toUpperCase() + w.slice(1)).join(' '),
      message,
      type,
      isRead: false,
      link: null,
      data: null,
      userId: 0,
      createdOn: new Date().toISOString()
    });
    // Small delay so the server's persist completes before we read it back.
    setTimeout(() => this.refresh(), 600);
  }

  /** Marks one notification read (optimistic) and navigates to its link. */
  open(n: AppNotification): void {
    if (!n.isRead && n.id > 0) {
      this.notificationsSignal.set(this.notificationsSignal().map(x => x.id === n.id ? { ...x, isRead: true } : x));
      this.http.post(`/api/notification/mark-read/${n.id}`, {})
        .pipe(takeUntil(this.destroy$))
        .subscribe({ error: () => this.refresh() });
    }
    if (n.link) {
      this.router.navigateByUrl(n.link);
    }
  }

  markAllRead(): void {
    this.notificationsSignal.set(this.notificationsSignal().map(n => ({ ...n, isRead: true })));
    this.http.post('/api/notification/mark-all-read', {})
      .pipe(takeUntil(this.destroy$))
      .subscribe({ error: () => this.refresh() });
  }

  remove(n: AppNotification): void {
    this.notificationsSignal.set(this.notificationsSignal().filter(x => x.id !== n.id));
    this.http.delete(`/api/notification/${n.id}`)
      .pipe(takeUntil(this.destroy$))
      .subscribe({ error: () => this.refresh() });
  }

  ngOnDestroy(): void {
    this.realtime.off('ReceiveNotification');
    this.destroy$.next();
    this.destroy$.complete();
  }
}
