import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class AssistantService {
  constructor(private http: HttpClient) {}

  ask(question: string): Observable<string> {
    // For demo, use simple keyword-based responses. Replace with real AI backend as needed.
    if (question.toLowerCase().includes('absent')) return of('There are 5 students absent today.');
    if (question.toLowerCase().includes('import students')) return of('Go to Students > Import/Export to import students from a CSV file.');
    if (question.toLowerCase().includes('help')) return of('You can ask me about attendance, importing data, or how to use any feature!');
    return of('Sorry, I do not have an answer for that yet.');
  }
}
