import { HttpInterceptorFn } from '@angular/common/http';

/**
 * Attaches the bearer token. The token lives under the single 'token' key
 * (legacy duplicate keys are cleaned up below once).
 */
export const authInterceptor: HttpInterceptorFn = (req, next) => {
  if (typeof window !== 'undefined' && window.localStorage) {
    // One-time cleanup of the legacy duplicate token keys (Issue 16).
    if (localStorage.getItem('authToken') || localStorage.getItem('accessToken')) {
      if (!localStorage.getItem('token') && localStorage.getItem('accessToken')) {
        localStorage.setItem('token', localStorage.getItem('accessToken')!);
      }
      localStorage.removeItem('authToken');
      localStorage.removeItem('accessToken');
    }

    const token = localStorage.getItem('token');

    if (token) {
      const authReq = req.clone({
        headers: req.headers.set('Authorization', `Bearer ${token}`)
      });
      return next(authReq);
    }
  }

  return next(req);
};
