import { HttpInterceptorFn } from '@angular/common/http';

/**
 * Anonymous endpoints that may legitimately use the X-Tenant-ID header
 * (pre-auth flows where the JWT does not exist yet).
 * Authenticated requests get their tenant from the JWT tenant_id claim —
 * the backend REJECTS header overrides for authenticated users
 * (see SchoolManagementApp.Api/Middleware/TenantResolutionMiddleware.cs).
 */
const ANONYMOUS_TENANT_HEADER_ENDPOINTS = [
  '/api/auth/login',
  '/api/auth/register',
  '/api/tenants/register',
  '/api/tenants/register-client',
  '/api/auth/forgot-password',
  '/api/auth/reset-password'
];

export const tenantInterceptor: HttpInterceptorFn = (req, next) => {
  if (typeof window !== 'undefined' && window.localStorage) {
    const tenantId = localStorage.getItem('tenantId')?.trim();

    // Only set header on anonymous (pre-auth) endpoints.
    if (tenantId && tenantId !== '0' && ANONYMOUS_TENANT_HEADER_ENDPOINTS.some(e => req.url.includes(e))) {
      const headers = req.headers.set('X-Tenant-ID', tenantId);
      req = req.clone({ headers });
    }
  }
  return next(req);
};
