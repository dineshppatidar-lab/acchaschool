import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class AnalyticsService {
  constructor(private http: HttpClient) {}

  getPerformanceTrends(): Observable<any> {
    return this.http.get('/api/analytics/performance-trends');
  }

  getAbsenteeismRisk(): Observable<any> {
    return this.http.get('/api/analytics/absenteeism-risk');
  }
}
