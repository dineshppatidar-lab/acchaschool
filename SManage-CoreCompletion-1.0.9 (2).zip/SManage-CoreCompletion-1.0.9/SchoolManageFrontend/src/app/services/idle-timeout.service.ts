import { Injectable, OnDestroy, inject } from '@angular/core';
import { Router } from '@angular/router';
import { Subject, fromEvent } from 'rxjs';
import { auditTime, takeUntil } from 'rxjs/operators';
import { AuthService } from './auth.service';

/**
 * Idle timeout (docs/critical-issues/16-jwt-in-localstorage.md, Option 2.5):
 * auto-logout after N minutes without user interaction. Limits the kiosk/shared-
 * machine exposure of a persisted token.
 *
 * Idle timeout is intentionally LONGER than the 30-minute access-token lifetime:
 * an active user is kept signed in by the refresh flow; a truly idle session dies.
 */
@Injectable({ providedIn: 'root' })
export class IdleTimeoutService implements OnDestroy {
  private static readonly IDLE_TIMEOUT_MS = 30 * 60 * 1000; // 30 minutes
  private static readonly THROTTLE_MS = 1000;

  private readonly auth = inject(AuthService);
  private readonly router = inject(Router);

  private readonly destroy$ = new Subject<void>();
  private timerId: ReturnType<typeof setTimeout> | null = null;
  private started = false;

  /** Call once at app start. Safe to call multiple times. */
  start(): void {
    if (this.started || typeof window === 'undefined') {
      return;
    }
    this.started = true;

    // Activity events must not trigger change detection (only the timeout callback,
    // which logs the user out, needs a CD pass — and logout's state updates are
    // signal-based/explicit, so they schedule their own pass under zoneless CD).
    (() => {
      const activity$ = new Subject<void>();

      const events = ['click', 'keydown', 'mousemove', 'wheel', 'touchstart', 'visibilitychange'] as const;
      for (const name of events) {
        fromEvent(window, name)
          .pipe(auditTime(IdleTimeoutService.THROTTLE_MS), takeUntil(this.destroy$))
          .subscribe(() => activity$.next());
      }

      activity$.pipe(takeUntil(this.destroy$)).subscribe(() => this.resetTimer());

      // Wrap-up warning at 25 min could be added here if desired.
      this.resetTimer();
    })();
  }

  /** Stops watching and cancels the pending timer (e.g. on logout). */
  stop(): void {
    this.destroy$.next();
    if (this.timerId !== null) {
      clearTimeout(this.timerId);
      this.timerId = null;
    }
    this.started = false;
  }

  private resetTimer(): void {
    if (this.timerId !== null) {
      clearTimeout(this.timerId);
    }
    this.timerId = setTimeout(() => this.onIdle(), IdleTimeoutService.IDLE_TIMEOUT_MS);
  }

  private onIdle(): void {
    // Anonymous visitors (login page) simply restart the timer — nothing to expire.
    if (!this.auth.isAuthenticated()) {
      this.resetTimer();
      return;
    }

    // Server-side revocation of the refresh token, storage cleanup, redirect.
    // (State mutations inside are signal-based/explicit — they schedule their own
    // change-detection pass; no zone wrapper needed under zoneless CD.)
    this.auth.logout();
    this.router.navigate(['/'], {
      queryParams: { session: 'expired' },
    });
  }

  ngOnDestroy(): void {
    this.stop();
  }
}
