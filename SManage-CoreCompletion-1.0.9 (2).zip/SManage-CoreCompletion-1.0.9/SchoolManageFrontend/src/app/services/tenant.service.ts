import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { catchError, tap } from 'rxjs/operators';

export interface TenantDto {
  id: number;
  name: string;
  domain?: string;
  logoUrl?: string;
  isActive: boolean;
}

@Injectable({ providedIn: 'root' })
export class TenantService {
  private tenantsSubject = new BehaviorSubject<TenantDto[]>([]);
  tenants$ = this.tenantsSubject.asObservable();

  // Start with 0 so we can resolve from API data after it loads
  private selectedTenantSubject = new BehaviorSubject<number>(0);
  selectedTenant$ = this.selectedTenantSubject.asObservable();

  // Fallback tenant used when API is unreachable
  private readonly DEFAULT_TENANTS: TenantDto[] = [
    { id: 1, name: 'Default School', isActive: true }
  ];

  constructor(private http: HttpClient) {
    const stored = (typeof window !== 'undefined' && window.localStorage)
      ? localStorage.getItem('tenantId')
      : null;
    const initialId = stored && !isNaN(+stored) ? +stored : 0;
    this.selectedTenantSubject.next(initialId);
  }

  loadTenants(): Observable<any> {
    // Public tenant list is disabled for security.
    // Data is now loaded only after authentication via specific admin endpoints or derived from user token.
    //
    // IMPORTANT: Do NOT override the selected tenant here.
    // The selected tenant is set during login from the JWT token's tenant_id claim.
    // Overwriting it here with the default would break multi-tenant resolution.
    this.tenantsSubject.next(this.DEFAULT_TENANTS);

    // Only set default tenant if no tenant is currently selected
    if (this.selectedTenantSubject.value === 0) {
      this.selectedTenantSubject.next(this.DEFAULT_TENANTS[0].id);
      if (typeof window !== 'undefined' && window.localStorage) {
        localStorage.setItem('tenantId', String(this.DEFAULT_TENANTS[0].id));
      }
    }
    return of(this.DEFAULT_TENANTS);
  }

  registerClient(payload: {
    tenantName: string;
    domain?: string;
    adminUsername: string;
    adminEmail: string;
    password: string;
    confirmPassword: string;
    acceptedTerms: boolean;
  }) {
    return this.http.post<any>('/api/tenants/register-client', payload);
  }

  // Admin endpoints
  getAllTenants() {
    return this.http.get<any>('/api/tenants');
  }

  createTenant(payload: { name: string; domain?: string | null; isActive: boolean; logoUrl?: string | null; welcomeText?: string | null }) {
    return this.http.post<any>('/api/tenants', payload);
  }

  updateTenant(id: number, payload: { name: string; domain?: string | null; isActive: boolean; logoUrl?: string | null; welcomeText?: string | null }) {
    return this.http.put<any>(`/api/tenants/${id}`, payload);
  }

  /** Resolves which school a host is bound to. Omit `host` to probe the current browser host.
   *  Passing an explicit host is SuperAdmin-only (used by the tenant admin "Test binding"). */
  resolveDomain(host?: string) {
    const params = host ? { host } : undefined;
    return this.http.get<any>('/api/auth/resolve-domain', { params });
  }

  getTenantsSnapshot(): TenantDto[] {
    return this.tenantsSubject.value;
  }

  setSelectedTenant(id: number) {
    this.selectedTenantSubject.next(id);
    if (typeof window !== 'undefined' && window.localStorage) {
      localStorage.setItem('tenantId', String(id));
    }
  }
}
