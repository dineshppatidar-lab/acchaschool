// Academic domain models centralized in shared/models
import { Class, Section, Subject } from '../shared/models/academic.models';

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { RealtimeHubService } from './realtime-hub.service';
// Re-export common academic types for backward compatibility
export type { Class, Section, Subject } from '../shared/models/academic.models';

@Injectable({ providedIn: 'root' })
export class AcademicService {
  private baseUrl = '/api/academic';

  constructor(private http: HttpClient, private realtime: RealtimeHubService) {
    void realtime.ensureStarted();
  }

  getAll(params?: any): Observable<Class[]> {
    return this.http.get<{data: Class[], total: number}>(this.baseUrl, { params }).pipe(
      map((response: any) => response.data || [])
    );
  }
  /** All classes, unpaginated (GET /api/academic/all) */
  getAllClasses(): Observable<Class[]> {
    // NOTE: the global apiResponseInterceptor already unwraps ApiResponse -> data.
    // By the time this map runs, `response` IS the array — accessing .data again
    // would always yield undefined (double-unwrap bug).
    return this.http.get<any>(`${this.baseUrl}/all`).pipe(
      map((response: any) => {
        const data = Array.isArray(response) ? response : Array.isArray(response?.data) ? response.data : [];
        return data;
      })
    );
  }
  /** Classes belonging to a specific academic year (GET /api/academic/year/{id}) */
  getClassesByAcademicYear(academicYearId: number): Observable<Class[]> {
    // Same as getAllClasses: interceptor already unwrapped ApiResponse -> data.
    return this.http.get<any>(`${this.baseUrl}/year/${academicYearId}`).pipe(
      map((response: any) => {
        const data = Array.isArray(response) ? response : Array.isArray(response?.data) ? response.data : [];
        return data;
      })
    );
  }
  getById(id: number): Observable<Class> {
    return this.http.get<Class>(`${this.baseUrl}/${id}`);
  }
  /** Real per-class aggregates (active students, sections, subjects) — issue #7 */
  getStatistics(): Observable<Record<number, { studentCount: number; sectionCount: number; subjectCount: number }>> {
    return this.http.get<any>(`${this.baseUrl}/statistics`).pipe(
      map((response: any) => {
        // Interceptor unwraps ApiResponse -> data (array of ClassStatisticsDto)
        const rows: any[] = Array.isArray(response) ? response : Array.isArray(response?.data) ? response.data : [];
        const map: Record<number, { studentCount: number; sectionCount: number; subjectCount: number }> = {};
        for (const row of rows) {
          if (row && typeof row.classId === 'number') {
            map[row.classId] = {
              studentCount: row.studentCount || 0,
              sectionCount: row.sectionCount || 0,
              subjectCount: row.subjectCount || 0
            };
          }
        }
        return map;
      })
    );
  }
  create(data: Class): Observable<Class> {
    return this.http.post<Class>(this.baseUrl, data);
  }
  update(id: number, data: Class): Observable<void> {
    return this.http.put<void>(`${this.baseUrl}/${id}`, data);
  }
  delete(id: number): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/${id}`);
  }
  import(data: FormData): Observable<any> {
    return this.http.post(`${this.baseUrl}/import`, data);
  }
  export(params?: any): Observable<Blob> {
    return this.http.get(`${this.baseUrl}/export`, { params, responseType: 'blob' });
  }
  onAcademicChanged(callback: (data: any) => void) {
    this.realtime.on('AcademicChanged', callback);
  }
  // TODO: Integrate NotificationService and AuditLogService for notifications and audit logs
}