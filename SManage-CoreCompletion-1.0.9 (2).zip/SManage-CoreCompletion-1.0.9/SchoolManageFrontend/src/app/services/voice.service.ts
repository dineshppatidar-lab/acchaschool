import { Injectable } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class VoiceService {
  private recognition: any;
  constructor() {
    if (typeof window !== 'undefined') {
      const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      if (SpeechRecognition) {
        this.recognition = new SpeechRecognition();
        this.recognition.continuous = false;
        this.recognition.lang = 'en-US';
      }
    }
  }
  listen(callback: (command: string) => void) {
    if (!this.recognition) return;
    this.recognition.onresult = (event: any) => {
      const command = event.results[0][0].transcript;
      // Zoneless: the callback's state must be signal-based to schedule its own CD.
      callback(command);
    };
    this.recognition.start();
  }
}
