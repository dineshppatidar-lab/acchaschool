import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

/**
 * Service to trigger payment list refresh across components
 * Used to update the payment list after a successful payment operation
 */
@Injectable({
  providedIn: 'root'
})
export class PaymentRefreshService {
  private refreshPaymentsList$ = new Subject<void>();
  
  /**
   * Observable that emits when payments list should be refreshed
   */
  onPaymentProcessed$ = this.refreshPaymentsList$.asObservable();
  
  /**
   * Trigger a refresh of the payments list
   * Call this after successful payment processing
   */
  triggerRefresh(): void {
    this.refreshPaymentsList$.next();
  }
}
