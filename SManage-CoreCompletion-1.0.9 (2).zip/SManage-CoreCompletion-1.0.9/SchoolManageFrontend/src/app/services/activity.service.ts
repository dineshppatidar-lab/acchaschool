import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { RealtimeHubService } from './realtime-hub.service';

/**
 * Real-time activity feed. Uses the app-wide authenticated RealtimeHubService
 * (one SignalR connection, JWT-authenticated, tenant-scoped server-side).
 */
@Injectable({ providedIn: 'root' })
export class ActivityService {
  private activitySubject = new BehaviorSubject<any>(null);
  public activity$ = this.activitySubject.asObservable();

  private readonly handler = (user: any, action: string, details: any) => {
    this.activitySubject.next({ user, action, details, timestamp: new Date() });
  };

  constructor(realtime: RealtimeHubService) {
    realtime.on('ReceiveActivity', this.handler);
    void realtime.ensureStarted();
  }
}
