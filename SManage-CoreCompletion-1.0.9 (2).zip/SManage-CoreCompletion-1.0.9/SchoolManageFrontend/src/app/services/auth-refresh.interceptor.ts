import { HttpErrorResponse, HttpInterceptorFn, HttpRequest } from '@angular/common/http';
import { inject } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { catchError, switchMap, take, finalize, shareReplay } from 'rxjs/operators';
import { AuthService } from './auth.service';

/**
 * 401 handling with single-flight silent refresh
 * (docs/critical-issues/05-jwt-lifecycle.md).
 *
 * - On a 401 from any endpoint except the auth endpoints themselves, attempt ONE
 *   silent refresh; concurrent 401s share the same refresh call (single-flight).
 * - After a successful refresh, queued requests are retried with the new token.
 * - If refresh fails, the user is logged out exactly once.
 */

// Endpoints that must never trigger a refresh (they are auth themselves,
// or anonymous by design) — prevents infinite refresh loops.
const REFRESH_EXCLUDED_URLS = ['/api/auth/login', '/api/auth/refresh', '/api/auth/logout', '/api/auth/register'];

let refreshInProgress$: Observable<boolean> | null = null;

export const authRefreshInterceptor: HttpInterceptorFn = (req, next) => {
  const authService = inject(AuthService);
  const isBrowser = typeof window !== 'undefined' && window.localStorage;

  const isExcluded = REFRESH_EXCLUDED_URLS.some(u => req.url.includes(u));

  if (!isBrowser || isExcluded) {
    return next(req);
  }

  return next(req).pipe(
    catchError((error: unknown) => {
      if (!(error instanceof HttpErrorResponse) || error.status !== 401) {
        return throwError(() => error);
      }

      // No refresh token available → straight to logout.
      const refreshToken = localStorage.getItem('refreshToken');
      if (!refreshToken) {
        authService.logout();
        return throwError(() => error);
      }

      // ── Single-flight refresh ────────────────────────────────────────
      // First 401 creates the shared refresh call; concurrent 401s reuse it.
      if (!refreshInProgress$) {
        refreshInProgress$ = new Observable<boolean>(subscriber => {
          authService.refresh().subscribe({
            next: (res: any) => {
              subscriber.next(!!res?.token);
              subscriber.complete();
            },
            error: () => {
              subscriber.next(false);
              subscriber.complete();
            }
          });
        }).pipe(
          shareReplay({ bufferSize: 1, refCount: false }),
          finalize(() => { refreshInProgress$ = null; })
        );
      }

      return refreshInProgress$.pipe(
        take(1),
        switchMap(success => {
          if (success) {
            // Retry the original request with the fresh token.
            const token = localStorage.getItem('token');
            const retried: HttpRequest<any> = token
              ? req.clone({ headers: req.headers.set('Authorization', `Bearer ${token}`) })
              : req;
            return next(retried);
          }
          authService.logout();
          return throwError(() => error);
        })
      );
    })
  );
};
