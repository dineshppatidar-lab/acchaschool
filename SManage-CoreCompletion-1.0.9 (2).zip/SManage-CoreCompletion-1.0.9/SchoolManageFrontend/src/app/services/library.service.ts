import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';

export interface PaginatedResult<T> {
  success: boolean;
  message: string;
  data: T[];
  pagination: {
    totalRecords: number;
    page: number;
    pageSize: number;
    totalPages: number;
  };
}

export interface Book {
  bookId: number;
  title: string;
  author: string;
  isbn: string;
  publisher?: string;
  publishDate?: Date;
  edition?: string;
  pages?: number;
  category: string;
  subject?: string;
  language?: string;
  totalCopies?: number;
  availableCopies?: number;
  price?: number;
  location?: string;
  status: string;
  addedDate: Date;
  issuedToStudentId?: number;
  issueDate?: Date;
  dueDate?: Date;
  returnDate?: Date;
}

export interface Asset {
  assetId: number;
  name: string;
  type: string;
  status: string;
  acquisitionDate: Date;
  location: string;
  condition: string;
  maintenanceSchedule?: Date;
  assignedDepartment?: string;
}

export interface InventoryItem {
  itemId: number;
  name: string;
  category: string;
  quantity: number;
  minStockLevel: number;
  unit: string;
  supplier?: string;
  lastUpdated: Date;
}

@Injectable({
  providedIn: 'root'
})
export class LibraryService {
  private apiUrl = `${environment.apiUrl}/api/LibraryInventory`;

  constructor(private http: HttpClient) { }

  // Books
  getBooks(page = 1, pageSize = 20, search = '', category = '', status = ''): Observable<PaginatedResult<Book>> {
    let params = new HttpParams()
      .set('page', page.toString())
      .set('pageSize', pageSize.toString());

    if (search) params = params.set('search', search);
    if (category) params = params.set('category', category);
    if (status) params = params.set('status', status);

    return this.http.get<PaginatedResult<Book>>(`${this.apiUrl}/books`, { params });
  }

  createBook(book: Partial<Book>): Observable<any> {
    // Remove bookId if it's 0 or undefined for a new book
    const { bookId, ...payload } = book;
    console.log('Creating book with payload:', payload);
    return this.http.post(`${this.apiUrl}/books`, payload);
  }

  updateBook(id: number, book: Partial<Book>): Observable<any> {
    return this.http.put(`${this.apiUrl}/books/${id}`, book);
  }

  issueBook(bookId: number, studentId: number, days = 14): Observable<any> {
    return this.http.post(`${this.apiUrl}/books/${bookId}/issue`, { studentId, issuePeriodDays: days });
  }

  returnBook(bookId: number, condition: string, notes: string): Observable<any> {
    return this.http.post(`${this.apiUrl}/books/${bookId}/return`, { bookCondition: condition, notes });
  }

  getOverdueBooks(): Observable<Book[]> {
    return this.http.get<Book[]>(`${this.apiUrl}/books/overdue`);
  }

  // Assets
  getAssets(page = 1, pageSize = 20, search = '', type = '', status = ''): Observable<PaginatedResult<Asset>> {
    let params = new HttpParams()
      .set('page', page.toString())
      .set('pageSize', pageSize.toString());

    if (search) params = params.set('search', search);
    if (type) params = params.set('type', type);
    if (status) params = params.set('status', status);

    return this.http.get<PaginatedResult<Asset>>(`${this.apiUrl}/assets`, { params });
  }

  createAsset(asset: Partial<Asset>): Observable<any> {
    return this.http.post(`${this.apiUrl}/assets`, asset);
  }

  transferAsset(assetId: number, toDepartment: string, newLocation: string, reason: string, notes: string): Observable<any> {
    return this.http.post(`${this.apiUrl}/assets/${assetId}/transfer`, { toDepartment, newLocation, reason, notes });
  }

  // Inventory
  getInventory(page = 1, pageSize = 20, search = '', category = ''): Observable<PaginatedResult<InventoryItem>> {
    let params = new HttpParams()
      .set('page', page.toString())
      .set('pageSize', pageSize.toString());

    if (search) params = params.set('search', search);
    if (category) params = params.set('category', category);

    return this.http.get<PaginatedResult<InventoryItem>>(`${this.apiUrl}/inventory`, { params });
  }

  createInventoryTransaction(itemId: number, type: number, quantity: number, purpose: string, notes: string): Observable<any> {
    return this.http.post(`${this.apiUrl}/inventory/${itemId}/transaction`, { transactionType: type, quantity, purpose, notes });
  }

  getLowStockItems(): Observable<InventoryItem[]> {
    return this.http.get<InventoryItem[]>(`${this.apiUrl}/inventory/low-stock`);
  }

  // Maintenance
  scheduleMaintenance(assetId: number, type: number, date: Date, description: string, priority: number, estimatedCost?: number): Observable<any> {
    return this.http.post(`${this.apiUrl}/assets/${assetId}/maintenance`, { 
      maintenanceType: type, 
      scheduledDate: date, 
      description, 
      priority, 
      estimatedCost 
    });
  }

  completeMaintenance(maintenanceId: number, actualCost: number, notes: string): Observable<any> {
    return this.http.put(`${this.apiUrl}/maintenance/${maintenanceId}/complete`, { actualCost, completionNotes: notes });
  }

  getLibraryUsageReport(startDate?: Date, endDate?: Date): Observable<any> {
    let params = new HttpParams();
    if (startDate) params = params.set('startDate', startDate.toISOString());
    if (endDate) params = params.set('endDate', endDate.toISOString());

    return this.http.get(`${this.apiUrl}/reports/library-usage`, { params });
  }
}
