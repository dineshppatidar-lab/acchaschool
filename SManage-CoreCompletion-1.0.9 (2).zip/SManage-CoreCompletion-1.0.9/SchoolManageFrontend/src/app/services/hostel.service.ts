import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { tap, catchError, map } from 'rxjs/operators';
import { RealtimeHubService } from './realtime-hub.service';

export interface Hostel {
  id?: number;
  name: string;
  type: string;
  address: string;
  capacity: number;
}

@Injectable({ providedIn: 'root' })
export class HostelService {
  private baseUrl = '/api/hostel';

  constructor(private http: HttpClient, private realtime: RealtimeHubService) {
    void realtime.ensureStarted();
  }

  getAll(params?: any): Observable<Hostel[]> {
    console.log('🏠 HostelService.getAll() called');
    console.log('🏠 Base URL:', this.baseUrl);
    console.log('🏠 Params:', params);
    
    return this.http.get<{data: Hostel[], total: number}>(this.baseUrl, { params }).pipe(
      tap((response: any) => console.log('🏠 Raw HTTP response:', response)),
      map((response: any) => {
        console.log('🏠 Extracting data from response:', response.data);
        return response.data || [];
      }),
      catchError((err: any) => {
        console.error('🏠 HTTP Error in HostelService:', err);
        return throwError(() => err);
      })
    );
  }
  getById(id: number): Observable<Hostel> {
    return this.http.get<Hostel>(`${this.baseUrl}/${id}`);
  }
  create(data: Hostel): Observable<Hostel> {
    return this.http.post<Hostel>(this.baseUrl, data);
  }
  update(id: number, data: Hostel): Observable<void> {
    return this.http.put<void>(`${this.baseUrl}/${id}`, data);
  }
  delete(id: number): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/${id}`);
  }
  import(data: FormData): Observable<any> {
    return this.http.post(`${this.baseUrl}/import`, data);
  }
  export(params?: any): Observable<Blob> {
    return this.http.get(`${this.baseUrl}/export`, { params, responseType: 'blob' });
  }
  onHostelChanged(callback: (data: any) => void) {
    this.realtime.on('HostelChanged', callback);
  }
  // TODO: Integrate NotificationService and AuditLogService for notifications and audit logs
}