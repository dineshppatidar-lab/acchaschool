import { inject, Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { Observable } from 'rxjs';

export interface Student {
  id?: number;
  firstName: string;
  lastName: string;
  dateOfBirth: string;
  gender: string;
  address: string;
  contactNumber: string;
  email: string;
  admissionDate: string;
  classId: number;
  sectionId: number;
  rollNumber: string;
  scholarNumber?: string;
  photoPath?: string;
  casteCategory?: string;
  religion?: string;
  parentId?: number;
  busRouteId?: number;
}

@Injectable({
  providedIn: 'root'
})
export class StudentService {
  private http = inject(HttpClient);
  private apiUrl = '/api/students';

 // constructor(private http: HttpClient) {}

  getAll(page: number = 1, pageSize: number = 20, search?: string, sortBy?: string, sortDirection?: 'asc' | 'desc'): Observable<Student[]> { 
    let params = new HttpParams()
      .set('page', page.toString())
      .set('pageSize', pageSize.toString());
    
    if (search) params = params.set('search', search);
    if (sortBy) params = params.set('sortBy', sortBy);
    if (sortDirection) params = params.set('sortDirection', sortDirection);
    
    return this.http.get<any>(this.apiUrl, { params }).pipe(
      map((response: any) => {
        if (Array.isArray(response)) {
          return response as Student[];
        }
        if (response?.data && Array.isArray(response.data)) {
          return response.data as Student[];
        }
        if (response?.items && Array.isArray(response.items)) {
          return response.items as Student[];
        }
        return [] as Student[];
      })
    );
  }

  getById(id: number): Observable<Student> {
    return this.http.get<Student>(`${this.apiUrl}/${id}`);
  }

  create(student: Student): Observable<Student> {
    return this.http.post<Student>(this.apiUrl, student);
  }

  update(id: number, student: Student): Observable<void> {
    return this.http.put<void>(`${this.apiUrl}/${id}`, student);
  }

  delete(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`);
  }
}
