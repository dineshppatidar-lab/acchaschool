import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { CreatePaymentRequest, FeePaymentDto } from '../shared/models/finance.models';
// Re-export for backward compatibility
export type { CreatePaymentRequest, FeePaymentDto } from '../shared/models/finance.models';

@Injectable({ providedIn: 'root' })
export class AdvancedFinanceService {
  private baseUrl = '/api/advancedfinance';

  constructor(private http: HttpClient) {}

  // Payments
  getPayments(params?: any): Observable<any> {
    return this.http.get(`${this.baseUrl}/payments`, { params });
  }

  getPaymentMethods(): Observable<any> {
    return this.http.get('/api/setup/payment-methods');
  }

  getStudentFeeInstallments(studentId: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/students/${studentId}/fee-installments`);
  }

  processPayment(body: CreatePaymentRequest): Observable<any> {
    return this.http.post(`${this.baseUrl}/payments`, body);
  }

  // Scholarships
  getScholarships(): Observable<any> {
    return this.http.get(`${this.baseUrl}/scholarships`);
  }
  createScholarship(body: any): Observable<any> {
    return this.http.post(`${this.baseUrl}/scholarships`, body);
  }
  applyForScholarship(scholarshipId: number, body: any): Observable<any> {
    return this.http.post(`${this.baseUrl}/scholarships/${scholarshipId}/apply`, body);
  }

  // Analytics
  getFinancialSummary(params?: any): Observable<any> {
    return this.http.get(`${this.baseUrl}/analytics/summary`, { params });
  }

  // Expenses
  getExpenses(params?: any): Observable<any> {
    return this.http.get(`${this.baseUrl}/expenses`, { params });
  }
  createExpense(body: any): Observable<any> {
    return this.http.post(`${this.baseUrl}/expenses`, body);
  }
  approveExpense(expenseId: number, body: any): Observable<any> {
    return this.http.put(`${this.baseUrl}/expenses/${expenseId}/approve`, body);
  }

  // Budgets
  getBudgets(params?: any): Observable<any> {
    return this.http.get(`${this.baseUrl}/budgets`, { params });
  }
  createBudget(body: any): Observable<any> {
    return this.http.post(`${this.baseUrl}/budgets`, body);
  }

  // Reports
  getCollectionReport(params?: any): Observable<any> {
    return this.http.get(`${this.baseUrl}/payments/collection-report`, { params });
  }

  getFeeAssignments(): Observable<any> {
    return this.http.get(`${this.baseUrl}/fee-assignments`);
  }
}
