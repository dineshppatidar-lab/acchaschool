import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { environment } from '../../environments/environment';
import { UserRole } from '../core/models/permission.model';

export interface RoleMenuPermissionItem {
  menuItemId: number;
  menuItemLabel: string;
  menuItemRoute: string;
  parentId: number | null;
  displayOrder: number;
  category: string;
  hasOverride: boolean;
  canView: boolean;
  /** Global (all-roles) switch — inactive menus are hidden for every role. */
  isActive?: boolean;
}

/**
 * Global (all-roles) on/off switch for a menu item.
 * Deactivated menus are hidden for every role regardless of overrides.
 */
export interface SetMenuItemActiveRequest {
  isActive: boolean;
}

export interface SetRoleMenuPermissionRequest {
  menuItemId: number;
  canView: boolean;
}

@Injectable({ providedIn: 'root' })
export class RoleMenuPermissionsService {
  private readonly apiUrl = `${environment.apiUrl}/api/role-menu-permissions`;

  constructor(private http: HttpClient) {}

  /** Get all menu permissions for a role */
  getRoleMenuPermissions(role: UserRole): Observable<RoleMenuPermissionItem[]> {
    return this.http.get<RoleMenuPermissionItem[]>(`${this.apiUrl}/${role}`).pipe(
      catchError(error => {
        console.error('Failed to load role menu permissions', error);
        return throwError(() => error);
      })
    );
  }

  /** Get only the explicit overrides for a role */
  getRoleMenuPermissionOverrides(role: UserRole): Observable<RoleMenuPermissionItem[]> {
    return this.http.get<RoleMenuPermissionItem[]>(`${this.apiUrl}/${role}/overrides`).pipe(
      catchError(error => {
        console.error('Failed to load role menu permission overrides', error);
        return throwError(() => error);
      })
    );
  }

  /** Set a single menu permission for a role */
  setRoleMenuPermission(role: UserRole, menuItemId: number, canView: boolean): Observable<any> {
    return this.http.post(`${this.apiUrl}/${role}`, { menuItemId, canView } as SetRoleMenuPermissionRequest).pipe(
      catchError(error => {
        console.error('Failed to set role menu permission', error);
        return throwError(() => error);
      })
    );
  }

  /** Bulk-set menu permissions for a role */
  bulkSetRoleMenuPermissions(role: UserRole, permissions: SetRoleMenuPermissionRequest[]): Observable<any> {
    return this.http.post(`${this.apiUrl}/${role}/bulk`, { permissions }).pipe(
      catchError(error => {
        console.error('Failed to bulk set role menu permissions', error);
        return throwError(() => error);
      })
    );
  }

  /** Delete a single menu permission override for a role */
  deleteRoleMenuPermission(role: UserRole, menuItemId: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/${role}/${menuItemId}`).pipe(
      catchError(error => {
        console.error('Failed to delete role menu permission', error);
        return throwError(() => error);
      })
    );
  }

  /** Reset all menu permissions for a role to default */
  resetRoleMenuPermissions(role: UserRole): Observable<any> {
    return this.http.post(`${this.apiUrl}/${role}/reset`, {}).pipe(
      catchError(error => {
        console.error('Failed to reset role menu permissions', error);
        return throwError(() => error);
      })
    );
  }

  /** Global on/off switch for a menu item (all roles). */
  setMenuItemActive(menuItemId: number, isActive: boolean): Observable<any> {
    return this.http.post(`${this.apiUrl}/menu-item/${menuItemId}/active`, { isActive } as SetMenuItemActiveRequest).pipe(
      catchError(error => {
        console.error('Failed to set menu item active state', error);
        return throwError(() => error);
      })
    );
  }

  /** Preview what menus a role would see */
  previewMenuForRole(role: UserRole, category?: string): Observable<any[]> {
    let url = `${this.apiUrl}/${role}/preview`;
    if (category) {
      url += `?category=${encodeURIComponent(category)}`;
    }
    return this.http.get<any[]>(url).pipe(
      catchError(error => {
        console.error('Failed to preview menu for role', error);
        return throwError(() => error);
      })
    );
  }
}
