import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable, of, throwError } from 'rxjs';
import { catchError, shareReplay, tap, map } from 'rxjs/operators';
import { environment } from '../../environments/environment';
import { AuthService } from './auth.service';

/**
 * Menu item model matching backend MenuItemDto
 */
export interface MenuItem {
  id: number;
  label: string;
  icon: string;
  route?: string;
  requiredPermission?: string;
  displayOrder: number;
  category: string;
  description?: string;
  badge?: string;
  externalUrl?: string;
  openInNewTab?: boolean;
  isActive?: boolean;
  disabled?: boolean;
  children?: MenuItem[];
  hasPermission?: boolean;
}

@Injectable({
  providedIn: 'root'
})
export class DynamicMenuService {
  private readonly apiUrl = `${environment.apiUrl}/api/menu`;

  // Cache subjects for different menu types
  private mainMenuSubject = new BehaviorSubject<MenuItem[]>([]);
  private academicMenuSubject = new BehaviorSubject<MenuItem[]>([]);
  private categoryMenuSubject = new BehaviorSubject<Map<string, MenuItem[]>>(new Map());

  // Observable streams
  public mainMenu$ = this.mainMenuSubject.asObservable();
  public academicMenu$ = this.academicMenuSubject.asObservable();

  // Loading states
  private loadingSubject = new BehaviorSubject<boolean>(false);
  public loading$ = this.loadingSubject.asObservable();

  // Error handling
  private errorSubject = new BehaviorSubject<string | null>(null);
  public error$ = this.errorSubject.asObservable();

  // Cache to avoid multiple API calls
  private cache: Map<string, { data: MenuItem[]; timestamp: number }> = new Map();
  private cacheTimeout = 5 * 60 * 1000; // 5 minutes

  constructor(private http: HttpClient, private authService: AuthService) {
    // User-aware caching: menus are permission-filtered per user, so cached
    // results from one account must never serve another. Whenever the
    // authenticated user changes (login, logout, switch), drop every cached
    // menu and the reactive state so the next consumer reloads fresh data.
    let lastUserId: number | null | undefined = undefined;
    this.authService.user$.subscribe(user => {
      const currentUserId = user?.id ?? null;
      if (lastUserId !== undefined && currentUserId !== lastUserId) {
        this.clearCache();
        this.mainMenuSubject.next([]);
        this.academicMenuSubject.next([]);
        this.categoryMenuSubject.next(new Map());
        this.errorSubject.next(null);
      }
      lastUserId = currentUserId;
    });
  }

  /**
   * Load main menu items (all top-level categories)
   * Caches results for performance
   */
  loadMainMenu(): Observable<MenuItem[]> {
    const cacheKey = 'main-menu';

    // Check if cached and still valid
    if (this.isCacheValid(cacheKey)) {
      return this.getCachedMenu(cacheKey);
    }

    this.loadingSubject.next(true);
    this.errorSubject.next(null);

    // Be tolerant of different API response shapes (array or { data: [] }) and add logging
    return this.http.get<any>(`${this.apiUrl}/main`).pipe(
      map((resp: any) => Array.isArray(resp) ? resp : (resp?.data ?? resp?.Data ?? [])),
      tap((menu: MenuItem[]) => {
        if (!menu || menu.length === 0) {
          console.warn('[DynamicMenuService] Main menu response contained no items');
        }
        console.log('[DynamicMenuService] Menu loaded', menu?.length ?? 0);
        this.mainMenuSubject.next(menu);
        this.setCacheMenu(cacheKey, menu);
        this.loadingSubject.next(false);
      }),
      catchError(error => {
        this.handleError('Failed to load main menu', error);
        this.loadingSubject.next(false);
        return throwError(() => error);
      }),
      shareReplay(1)
    );
  }

  /**
   * Load Academic menu specifically
   * Includes all sub-items under Academic category
   */
  loadAcademicMenu(): Observable<MenuItem[]> {
    const cacheKey = 'academic-menu';

    if (this.isCacheValid(cacheKey)) {
      return this.getCachedMenu(cacheKey);
    }

    this.loadingSubject.next(true);
    this.errorSubject.next(null);

    return this.http.get<MenuItem[]>(`${this.apiUrl}/academic`).pipe(
      tap(menu => {
        this.academicMenuSubject.next(menu);
        this.setCacheMenu(cacheKey, menu);
        this.loadingSubject.next(false);
      }),
      catchError(error => {
        this.handleError('Failed to load academic menu', error);
        this.loadingSubject.next(false);
        return throwError(() => error);
      }),
      shareReplay(1)
    );
  }

  /**
   * Load menu items for a specific category
   */
  loadCategoryMenu(category: string): Observable<MenuItem[]> {
    const cacheKey = `category-${category}`;

    if (this.isCacheValid(cacheKey)) {
      return this.getCachedMenu(cacheKey);
    }

    this.loadingSubject.next(true);
    this.errorSubject.next(null);

    return this.http
      .get<MenuItem[]>(`${this.apiUrl}/category/${category}`)
      .pipe(
        tap(menu => {
          const categoryMap = this.categoryMenuSubject.getValue();
          categoryMap.set(category, menu);
          this.categoryMenuSubject.next(categoryMap);
          this.setCacheMenu(cacheKey, menu);
          this.loadingSubject.next(false);
        }),
        catchError(error => {
          this.handleError(`Failed to load ${category} menu`, error);
          this.loadingSubject.next(false);
          return throwError(() => error);
        }),
        shareReplay(1)
      );
  }

  /**
   * Get main menu synchronously (from current subject value)
   * Use only if you know menu has been loaded
   */
  getMainMenuSync(): MenuItem[] {
    return this.mainMenuSubject.value;
  }

  /**
   * Get academic menu synchronously
   */
  getAcademicMenuSync(): MenuItem[] {
    return this.academicMenuSubject.value;
  }

  /**
   * Find a menu item by route
   */
  findMenuItemByRoute(route: string, menu?: MenuItem[]): MenuItem | undefined {
    const items = menu || this.mainMenuSubject.value;

    for (const item of items) {
      if (item.route === route) {
        return item;
      }

      if (item.children && item.children.length > 0) {
        const found = this.findMenuItemByRoute(route, item.children);
        if (found) {
          return found;
        }
      }
    }

    return undefined;
  }

  /**
   * Find a menu item by ID
   */
  findMenuItemById(id: number, menu?: MenuItem[]): MenuItem | undefined {
    const items = menu || this.mainMenuSubject.value;

    for (const item of items) {
      if (item.id === id) {
        return item;
      }

      if (item.children && item.children.length > 0) {
        const found = this.findMenuItemById(id, item.children);
        if (found) {
          return found;
        }
      }
    }

    return undefined;
  }

  /**
   * Get breadcrumb navigation from route
   */
  getBreadcrumbs(route: string): MenuItem[] {
    const breadcrumbs: MenuItem[] = [];
    const item = this.findMenuItemByRoute(route);

    if (item) {
      breadcrumbs.push(item);
    }

    return breadcrumbs;
  }

  /**
   * Check if user has permission for a menu item
   */
  hasPermission(menuItem: MenuItem): boolean {
    return menuItem.hasPermission !== false;
  }

  /**
   * Flatten menu hierarchy for easier access
   */
  flattenMenu(menu: MenuItem[]): MenuItem[] {
    const flattened: MenuItem[] = [];

    const flatten = (items: MenuItem[]) => {
      for (const item of items) {
        flattened.push(item);
        if (item.children && item.children.length > 0) {
          flatten(item.children);
        }
      }
    };

    flatten(menu);
    return flattened;
  }

  /**
   * Clear cache
   */
  clearCache(): void {
    this.cache.clear();
  }

  /**
   * Refresh menu data (bypasses cache)
   */
  refreshMenu(): Observable<MenuItem[]> {
    this.clearCache();
    return this.loadMainMenu();
  }

  /**
   * Invalidate the backend menu cache and force a full local reload.
   * Call this after any permission or role-menu-permission changes.
   * 1. Fires POST /api/menu/invalidate-cache (fire-and-forget)
   * 2. Clears all local cache and reactive state
   * 3. Reloads the main menu from the server
   */
  invalidateAndReload(): Observable<MenuItem[]> {
    // Notify backend (fire-and-forget — don't block on failure)
    this.http.post(`${this.apiUrl}/invalidate-cache`, {}).pipe(
      catchError(error => {
        console.warn('[DynamicMenuService] Backend cache invalidation failed (non-blocking)', error);
        return of(null);
      })
    ).subscribe();

    // Clear local cache and reactive state
    this.clearCache();
    this.mainMenuSubject.next([]);
    this.academicMenuSubject.next([]);
    this.categoryMenuSubject.next(new Map());

    // Reload fresh menu from server
    return this.loadMainMenu();
  }

  /**
   * Get all menu items (admin endpoint)
   */
  getAllMenuItems(): Observable<MenuItem[]> {
    return this.http.get<MenuItem[]>(`${this.apiUrl}/all`).pipe(
      catchError(error => {
        this.handleError('Failed to load menu items', error);
        return throwError(() => error);
      })
    );
  }

  // ============ Admin Methods ============

  /**
   * Create new menu item
   */
  createMenuItem(request: CreateMenuItemRequest): Observable<MenuItem> {
    return this.http.post<MenuItem>(`${this.apiUrl}`, request).pipe(
      tap(() => this.clearCache()),
      catchError(error => {
        this.handleError('Failed to create menu item', error);
        return throwError(() => error);
      })
    );
  }

  /**
   * Update existing menu item
   */
  updateMenuItem(id: number, request: UpdateMenuItemRequest): Observable<MenuItem> {
    return this.http.put<MenuItem>(`${this.apiUrl}/${id}`, request).pipe(
      tap(() => this.clearCache()),
      catchError(error => {
        this.handleError('Failed to update menu item', error);
        return throwError(() => error);
      })
    );
  }

  /**
   * Delete menu item
   */
  deleteMenuItem(id: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/${id}`).pipe(
      tap(() => this.clearCache()),
      catchError(error => {
        this.handleError('Failed to delete menu item', error);
        return throwError(() => error);
      })
    );
  }

  // ============ Private Helper Methods ============

  /**
   * Check if cached data is still valid
   */
  private isCacheValid(key: string): boolean {
    const cached = this.cache.get(key);
    if (!cached) return false;

    const isValid = Date.now() - cached.timestamp < this.cacheTimeout;
    if (!isValid) {
      this.cache.delete(key);
    }

    return isValid;
  }

  /**
   * Get cached menu items
   */
  private getCachedMenu(key: string): Observable<MenuItem[]> {
    const cached = this.cache.get(key);
    return new Observable(observer => {
      if (cached) {
        observer.next(cached.data);
        observer.complete();
      }
    });
  }

  /**
   * Set menu in cache
   */
  private setCacheMenu(key: string, data: MenuItem[]): void {
    this.cache.set(key, {
      data,
      timestamp: Date.now()
    });
  }

  /**
   * Handle and log errors
   */
  private handleError(message: string, error: any): void {
    console.error(message, error);
    this.errorSubject.next(message);
  }
}

/**
 * Request DTOs for admin operations
 */
export interface CreateMenuItemRequest {
  label: string;
  icon: string;
  route?: string;
  requiredPermission?: string;
  parentId?: number;
  displayOrder: number;
  category: string;
  description?: string;
  isActive?: boolean;
  tenantId?: number;
  externalUrl?: string;
  openInNewTab?: boolean;
}

export interface UpdateMenuItemRequest {
  label?: string;
  icon?: string;
  route?: string;
  requiredPermission?: string;
  displayOrder?: number;
  category?: string;
  isActive?: boolean;
}
