import { Injectable } from '@angular/core';
import { Subject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserNotificationService {
  private userModifiedSubject = new Subject<void>();

  userModified$: Observable<void> = this.userModifiedSubject.asObservable();

  notifyUserModified(): void {
    this.userModifiedSubject.next();
  }
}
