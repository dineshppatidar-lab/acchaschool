import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { Observable } from 'rxjs';

export interface Staff {
  id?: number;
  firstName: string;
  lastName: string;
  dateOfBirth: string;
  gender: string;
  address: string;
  city: string;
  state: string;
  zipCode: string;
  phoneNumber: string;
  email: string;
  hireDate: string;
  position: string;
  salary: number;
  role: string;
  qualification: string;
  specialization: string;
}

@Injectable({
  providedIn: 'root'
})
export class StaffService {
  private apiUrl = '/api/staff';

  constructor(private http: HttpClient) {}

  getAll(page: number = 1, pageSize: number = 20, search?: string, sort?: string, order?: 'asc' | 'desc'): Observable<Staff[]> {
    let params = new HttpParams()
      .set('page', page.toString())
      .set('pageSize', pageSize.toString());
    
    if (search) params = params.set('search', search);
    if (sort) params = params.set('sort', sort);
    if (order) params = params.set('order', order);
    
    console.log('👥 StaffService.getAll() called with params:', { page, pageSize, search, sort, order });
    return this.http.get<any>(this.apiUrl, { params }).pipe(
      map((response: any) => {
        console.log('👥 Raw staff response:', response);
        if (Array.isArray(response)) {
          return response as Staff[];
        }
        if (response?.data && Array.isArray(response.data)) {
          return response.data as Staff[];
        }
        if (response?.items && Array.isArray(response.items)) {
          return response.items as Staff[];
        }
        return [] as Staff[];
      })
    );
  }

  getById(id: number): Observable<Staff> {
    return this.http.get<Staff>(`${this.apiUrl}/${id}`);
  }

  create(staff: Staff): Observable<Staff> {
    return this.http.post<Staff>(this.apiUrl, staff);
  }

  update(id: number, staff: Staff): Observable<void> {
    return this.http.put<void>(`${this.apiUrl}/${id}`, staff);
  }

  delete(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`);
  }

  getByRole(role: string): Observable<Staff[]> {
    return this.http.get<Staff[]>(`${this.apiUrl}/role/${role}`);
  }
}
