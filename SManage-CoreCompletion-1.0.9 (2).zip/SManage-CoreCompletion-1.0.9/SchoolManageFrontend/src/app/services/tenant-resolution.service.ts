import { Injectable, computed, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import { environment } from '../../environments/environment';

/**
 * Shape returned by GET /api/auth/resolve-domain (anonymous; scoped to the current host).
 * Kept tolerant of missing fields so a slightly older backend cannot crash the app.
 */
export interface SchoolBranding {
  matched: boolean;
  active: boolean;
  tenantCode: string | null;
  tenantName: string | null;
  logoUrl: string | null;
  welcomeText: string | null;
  baseDomain: string | null;
}

/**
 * What the browser host actually represents. Decided ONLY after the backend
 * (which owns Tenant.Domain) answers — the frontend never guesses a tenant:
 *  - loading:          resolution still in flight; tenant-dependent UI must stay neutral.
 *  - platform:         main domain / localhost dev / unclassifiable foreign host.
 *  - school:           explicitly bound, active school — render its branding.
 *  - school-inactive:  bound but suspended — show the suspended state, not the login form.
 *  - school-not-found: <subdomain>.<baseDomain> that no school has bound yet.
 */
export type SiteKind = 'loading' | 'platform' | 'school' | 'school-inactive' | 'school-not-found';

const PLATFORM_FALLBACK_NAME = 'AcchaSchool';

@Injectable({ providedIn: 'root' })
export class TenantResolutionService {
  readonly siteKind = signal<SiteKind>('loading');
  readonly branding = signal<SchoolBranding | null>(null);

  /** Convenience signals for templates (never hardcoded — always from the backend). */
  readonly schoolName = computed(() => this.branding()?.tenantName ?? null);
  readonly schoolCode = computed(() => this.branding()?.tenantCode ?? null);
  readonly logoUrl = computed(() => this.branding()?.logoUrl ?? null);
  readonly welcomeText = computed(() => this.branding()?.welcomeText ?? null);
  readonly isSchool = computed(() => this.siteKind() === 'school');

  /** The login form only renders for the platform, active schools, or while resolving. */
  readonly showLoginForm = computed(() => {
    const kind = this.siteKind();
    return kind === 'platform' || kind === 'school' || kind === 'loading';
  });

  private resolvePromise: Promise<void> | null = null;

  constructor(private http: HttpClient) {}

  /**
   * Resolves the tenant for the current browser host. Idempotent: the first call
   * wins, concurrent/later callers await the same resolution. Must complete before
   * any tenant-dependent chrome renders (login branding, public website, titles).
   */
  initialize(): Promise<void> {
    if (!this.resolvePromise) {
      this.resolvePromise = this.resolve();
    }
    return this.resolvePromise;
  }

  /** Display name: resolved school name when on a school subdomain, else platform brand. */
  displayName(fallback: string = PLATFORM_FALLBACK_NAME): string {
    return this.isSchool() ? (this.schoolName() || fallback) : fallback;
  }

  private async resolve(): Promise<void> {
    let res: Partial<SchoolBranding> | null = null;
    try {
      res = await firstValueFrom(
        this.http.get<Partial<SchoolBranding>>('/api/auth/resolve-domain')
      );
    } catch {
      // Backend unreachable: keep the form usable (components fall back to
      // platform branding; school code can still be typed manually). The real
      // tenant decision re-happens server-side on every authenticated request.
      this.siteKind.set('platform');
      this.branding.set(null);
      return;
    }

    const branding: SchoolBranding = {
      matched: !!res?.matched,
      active: res?.active !== false,
      tenantCode: res?.tenantCode ?? null,
      tenantName: res?.tenantName ?? null,
      logoUrl: res?.logoUrl ?? null,
      welcomeText: res?.welcomeText ?? null,
      baseDomain: res?.baseDomain ?? environment.baseDomain ?? null
    };
    this.branding.set(branding);
    this.siteKind.set(this.classify(branding));
  }

  private classify(b: SchoolBranding): SiteKind {
    if (b.matched) return b.active ? 'school' : 'school-inactive';

    const host = (typeof window !== 'undefined' ? window.location.hostname : '').toLowerCase();
    const base = (b.baseDomain || environment.baseDomain || '').toLowerCase();

    // No base domain configured (e.g. dev): every host is treated as the platform
    // — we cannot distinguish "school subdomain" from "main domain" reliably.
    const isLocal = !host || host === 'localhost' || !host.includes('.') || /^\d{1,3}(\.\d{1,3}){3}$/.test(host);
    if (!base || isLocal) return 'platform';

    // Exact platform host (with or without www): the platform website.
    if (host === base || host === `www.${base}`) return 'platform';

    // A subdomain under the platform domain that no school bound → unknown school.
    if (host.endsWith(`.${base}`)) return 'school-not-found';

    // Any other host (custom domains etc.): treat as platform until custom-domain
    // support lands; the school-not-found rule only applies to platform subdomains.
    return 'platform';
  }
}
