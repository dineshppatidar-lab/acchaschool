import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';

export interface EmailHealth {
  transport: 'Smtp' | 'HostingerApi';
  fromEmail: string;
  fromName: string;
  smtpHost: string;
  smtpPort: number;
  smtpUsernameConfigured: boolean;
  smtpPasswordConfigured: boolean;
  apiBaseUrl: string;
  apiTokenConfigured: boolean;
  apiMailboxResourceId: string;
}

export interface EmailTestResult {
  success: boolean;
  transport: string;
  sentTo: string;
  sentAtUtc: string;
  error?: string;
}

/**
 * Admin-only email diagnostics (SystemManage permission required).
 */
@Injectable({ providedIn: 'root' })
export class EmailAdminService {
  private readonly apiUrl = `${environment.apiUrl}/api/email-admin`;

  constructor(private http: HttpClient) {}

  getHealth(): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/health`);
  }

  sendTestEmail(toEmail: string): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/send-test`, { toEmail });
  }
}
