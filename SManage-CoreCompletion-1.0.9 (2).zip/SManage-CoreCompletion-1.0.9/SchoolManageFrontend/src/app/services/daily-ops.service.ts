import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface DailySummaryDto {
  date: string;
  totalStudents: number;
  presentStudents: number;
  absentStudents: number;
  staffPresent: number;
  staffAbsent: number;
  feesDueToday: number;
  feesOverdue: number;
  busesRunning: number;
  busesOnTime: number;
  announcements: { id: number; title: string; type: string; priority: string; CreatedOn: string; }[];
  events: { id: number; title: string; startDate: string; endDate: string; location: string; }[];
}

export interface QuickMarkRequest {
  classId: number;
  sectionId: number;
  date: string; // ISO
  presentStudentIds: number[];
}

export interface FeeReminderRequest {
  studentIds: number[];
  channel: 'SMS' | 'Email' | 'Push';
  message: string;
}

@Injectable({ providedIn: 'root' })
export class DailyOpsService {
  private baseUrl = '/api/dailyops';
  constructor(private http: HttpClient) {}

  getSummary(date?: string, academicYearId?: number | null): Observable<DailySummaryDto> {
    let params = new HttpParams();
    if (date) params = params.set('date', date);
    if (academicYearId) params = params.set('academicYearId', String(academicYearId));
    return this.http.get<DailySummaryDto>(`${this.baseUrl}/summary`, { params });
  }

  quickMarkAttendance(payload: QuickMarkRequest): Observable<any> {
    return this.http.post(`${this.baseUrl}/attendance/quick-mark`, payload);
  }

  sendFeeReminders(payload: FeeReminderRequest): Observable<any> {
    return this.http.post(`${this.baseUrl}/fees/remind`, payload);
  }

  getClasses(): Observable<any[]> {
    return this.http.get<any[]>('/api/academic/all');
  }

  getClassesByAcademicYear(academicYearId: number): Observable<any[]> {
    return this.http.get<any[]>(`/api/academic/year/${academicYearId}`);
  }

  getSectionsByClass(classId: number): Observable<any[]> {
    return this.http.get<any[]>(`/api/academic/class/${classId}/sections`);
  }
}
