import { Injectable, computed, signal } from '@angular/core';

/**
 * Central loading-state manager for the whole application (zoneless build —
 * async state is signals-only; see app.config.ts).
 *
 * Design:
 *  - A raw counter of in-flight tracked operations (`activeCount`). Overlays
 *    hide only when it returns to 0, so concurrent requests never hide the
 *    indicator prematurely and it can never go negative.
 *  - The indicator is displayed after a small delay (`SHOW_DELAY_MS`) so very
 *    fast requests never cause spinner flicker, and — once shown — stays
 *    visible for at least `MIN_VISIBLE_MS` so it never blinks off.
 *  - Mutating operations (POST/PUT/PATCH/DELETE) are counted separately so the
 *    overlay can block interaction only while a submission is in flight;
 *    read-only loading stays non-blocking.
 *  - `reset()` exists as a safety valve for force-counters to zero (e.g. after
 *    a forced logout) so the overlay can never get permanently stuck.
 *
 * HTTP traffic is tracked automatically by GlobalLoadingInterceptor. Manual
 * use is available for non-HTTP async work via begin()/end()/track().
 */
@Injectable({ providedIn: 'root' })
export class GlobalLoadingService {
  /** Delay before showing the indicator (skips flicker on fast requests). */
  static readonly SHOW_DELAY_MS = 350;
  /** Once visible, stays on screen at least this long (visual consistency). */
  static readonly MIN_VISIBLE_MS = 500;

  private readonly activeCountSignal = signal(0);
  private readonly mutatingCountSignal = signal(0);
  private readonly visibleSignal = signal(false);
  private readonly messageSignal = signal('Loading');

  /** Number of tracked operations currently in flight (0..n, never negative). */
  readonly activeCount = this.activeCountSignal.asReadonly();
  /** Whether the global overlay is currently displayed. */
  readonly visible = this.visibleSignal.asReadonly();
  /** Short message shown inside the overlay ("Loading", or a caller-provided label via GLOBAL_LOADING_MESSAGE). */
  readonly message = this.messageSignal.asReadonly();
  /** True while at least one mutating (POST/PUT/PATCH/DELETE) op is in flight. */
  readonly hasMutating = computed(() => this.mutatingCountSignal() > 0);

  // ── Timer handles (single show-delay timer + single hide timer) ───────────
  private showTimer: ReturnType<typeof setTimeout> | null = null;
  private hideTimer: ReturnType<typeof setTimeout> | null = null;
  private firstActiveAt = 0;

  /**
   * Register the start of a tracked operation. Counter-safe: ordering with
   * end() is guarded, counts never go negative (see end()).
   * Returns nothing; pair every begin() with exactly one end()/track().
   */
  begin(message?: string): void {
    // New activity cancels any pending/running hide transition.
    this.clearHideTimer();

    this.activeCountSignal.update(c => c + 1);

    if (message) { this.messageSignal.set(message); }

    if (this.activeCountSignal() === 1) {
      this.firstActiveAt = Date.now();
      // Only schedule the delayed reveal when nothing is visible yet.
      if (!this.visibleSignal()) {
        this.clearShowTimer();
        this.showTimer = setTimeout(() => {
          this.showTimer = null;
          if (this.activeCountSignal() > 0) { this.visibleSignal.set(true); }
        }, GlobalLoadingService.SHOW_DELAY_MS);
      }
    }
  }

  /**
   * Mark the operation type as mutating while it runs; released automatically
   * via the returned function (use in finalize/finally). Kept separate from
   * begin/end so read-only requests never block the UI.
   */
  markMutating(): void {
    this.mutatingCountSignal.update(c => c + 1);
  }

  releaseMutating(): void {
    // Guard against double-release; never below zero.
    this.mutatingCountSignal.update(c => Math.max(0, c - 1));
  }

  /** Register the end of a tracked operation (success, error or cancel). */
  end(): void {
    // Honest counter: may transiently hit -1 if end() races begin() (e.g. HTTP
    // cancel during hot navigation); clamp so it can never stick on one side.
    if (this.activeCountSignal() === 0) { return; }
    this.activeCountSignal.update(c => Math.max(0, c - 1));

    if (this.activeCountSignal() === 0) {
      this.clearShowTimer();
      if (this.visibleSignal()) {
        // Respect minimum-visible duration to avoid a blink when the overlay
        // has just appeared; otherwise hide immediately.
        const elapsed = Date.now() - this.firstActiveAt;
        const remaining = Math.max(0, GlobalLoadingService.MIN_VISIBLE_MS - elapsed);
        this.clearHideTimer();
        this.hideTimer = setTimeout(() => {
          this.hideTimer = null;
          this.visibleSignal.set(false);
        }, remaining);
      }
    }
  }

  /**
   * Run `work` under tracking — auto-releases on success, error and teardown
   * (cancellation). Use for non-HTTP async tasks.
   */
  track<T>(work: () => T, message?: string): T {
    this.begin(message);
    try {
      return work();
    } finally {
      this.end();
    }
  }

  /**
   * Force the overlay off and zero the counters — safety valve, e.g. after a
   * forced logout, so navigation to the login screen can never leave a stuck
   * overlay behind. Does not affect metrics beyond the counters.
   */
  reset(): void {
    this.clearShowTimer();
    this.clearHideTimer();
    this.visibleSignal.set(false);
    this.activeCountSignal.set(0);
    this.mutatingCountSignal.set(0);
  }

  private clearShowTimer(): void {
    if (this.showTimer !== null) { clearTimeout(this.showTimer); this.showTimer = null; }
  }

  private clearHideTimer(): void {
    if (this.hideTimer !== null) { clearTimeout(this.hideTimer); this.hideTimer = null; }
  }
}
