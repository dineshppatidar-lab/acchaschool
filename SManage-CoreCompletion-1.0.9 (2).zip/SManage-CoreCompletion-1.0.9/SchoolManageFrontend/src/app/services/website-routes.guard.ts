import { inject } from '@angular/core';
import { CanActivateFn, Router, UrlTree } from '@angular/router';
import { TenantResolutionService } from './tenant-resolution.service';

/**
 * Resolves the tenant for the current host, then:
 *  - Site routes (…/site/**): only for a bound ACTIVE school host — everyone
 *    else (platform, inactive/not-found/foreign hosts) bounces to the platform root.
 *  - Platform root ('' / 'landing'): on a bound active school host it should
 *    show the school's website, so school traffic is redirected to /site.
 */
export const SchoolSiteGuard: CanActivateFn = async (): Promise<boolean | UrlTree> => {
  const resolution = inject(TenantResolutionService);
  const router = inject(Router);

  await resolution.initialize();
  return resolution.siteKind() === 'school' ? true : router.parseUrl('');
};

export const PlatformRootGuard: CanActivateFn = async (): Promise<boolean | UrlTree> => {
  const resolution = inject(TenantResolutionService);
  const router = inject(Router);

  await resolution.initialize();
  return resolution.siteKind() === 'school' ? router.parseUrl('/site') : true;
};
