import { Injectable, ErrorHandler } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';

@Injectable({ providedIn: 'root' })
export class GlobalErrorHandler implements ErrorHandler {
  constructor(private snackBar: MatSnackBar) {}
  handleError(error: any): void {
    // Schedule snackbar to next tick to avoid ExpressionChangedAfterItHasBeenCheckedError in dev
    setTimeout(() => {
      const msg = this.extractMessage(error) || 'An unexpected error occurred.';
      this.snackBar.open(msg, 'Close', { duration: 5000 });
    }, 0);
    console.error(error);
  }

  private extractMessage(err: any): string | undefined {
    if (!err) return undefined;
    // Angular HttpErrorResponse has 'message' and nested error.message
    return err?.error?.message || err?.message;
  }
}
