import { Injectable } from '@angular/core';
import {
  CanActivate,
  ActivatedRouteSnapshot,
  RouterStateSnapshot,
  Router
} from '@angular/router';
import { AuthService } from './auth.service';

@Injectable({ providedIn: 'root' })
export class AuthGuard implements CanActivate {
  constructor(private auth: AuthService, private router: Router) {}

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
    const user = this.auth.user;
    console.log('AuthGuard: Checking access for:', state.url, 'User:', user);
    
    if (!user) {
      console.log('AuthGuard: No user, redirecting to login');
      this.router.navigate(['/login']);
      return false;
    }
    
    const roles = route.data['roles'] as string[];
    if (roles) {
      const userRole = user.role || user.roles;
      console.log('AuthGuard: Required roles:', roles, 'User role:', userRole);
      if (!roles.includes(userRole)) {
        console.log('AuthGuard: Access denied, redirecting to unauthorized');
        this.router.navigate(['/unauthorized']);
        return false;
      }
    }
    
    console.log('AuthGuard: Access granted');
    return true;
  }
}
