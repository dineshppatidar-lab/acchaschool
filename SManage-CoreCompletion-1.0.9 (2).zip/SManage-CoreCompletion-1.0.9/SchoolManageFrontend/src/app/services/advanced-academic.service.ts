import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { environment } from '../../environments/environment';
import { TimeTableEntry, Examination, ExaminationType, Assignment, Class, AcademicYear, Section, Subject, Teacher, ExamResult } from '../shared/models/academic.models';

@Injectable({
  providedIn: 'root'
})
export class AdvancedAcademicService {
  // Match backend route [Route("api/[controller]")] => /api/AdvancedAcademic
  private readonly apiUrl = `${environment.apiUrl}/api/AdvancedAcademic`;
  private readonly typeUrl = `${environment.apiUrl}/api/ExaminationType`;

  constructor(private http: HttpClient) {}

  // Timetable Management
  getTimetables(page: number = 1, pageSize: number = 20): Observable<TimeTableEntry[]> {
    const params = new HttpParams()
      .set('page', page.toString())
      .set('pageSize', pageSize.toString());
    
    return this.http.get<TimeTableEntry[]>(`${this.apiUrl}/timetables`, { params });
  }

  getTimetableByClass(classId: number): Observable<TimeTableEntry[]> {
    return this.http.get<TimeTableEntry[]>(`${this.apiUrl}/timetables/class/${classId}`);
  }

  createTimetableEntry(entry: Partial<TimeTableEntry>): Observable<TimeTableEntry> {
    const payload = this.prepareTimetablePayload(entry);
    return this.http.post<TimeTableEntry>(`${this.apiUrl}/timetables`, payload);
  }

  private prepareTimetablePayload(entry: Partial<TimeTableEntry>): any {
    const payload: any = { ...entry };
    
    // Map room -> roomNumber
    if (entry.room && !payload.roomNumber) {
      payload.roomNumber = entry.room;
    }

    // The dialog binds the teacher dropdown to `teacherId`; the entity's column
    // is StaffId. Without this mapping the entry is stored with StaffId=0 and
    // the grid can never resolve a teacher name for it.
    if (payload.teacherId != null && payload.teacherId !== '') {
      payload.staffId = Number(payload.teacherId);
    }
    delete payload.teacherId;
    if (payload.staffId != null) payload.staffId = Number(payload.staffId);
    if (payload.subjectId != null) payload.subjectId = Number(payload.subjectId);
    if (payload.classId != null) payload.classId = Number(payload.classId);
    if (payload.sectionId != null) payload.sectionId = Number(payload.sectionId);
    
    // Convert dayOfWeek string to enum (Monday -> 1, Tuesday -> 2, etc.)
    if (entry.dayOfWeek) {
      const dayMap: { [key: string]: number } = {
        'Sunday': 0, 'Monday': 1, 'Tuesday': 2, 'Wednesday': 3,
        'Thursday': 4, 'Friday': 5, 'Saturday': 6
      };
      payload.dayOfWeek = dayMap[entry.dayOfWeek] ?? entry.dayOfWeek;
    }
    if (payload.dayOfWeek != null) payload.dayOfWeek = Number(payload.dayOfWeek);
    
    // Convert time strings to TimeSpan format (HH:mm -> HH:mm:ss)
    if (entry.startTime && typeof entry.startTime === 'string') {
      payload.startTime = entry.startTime.includes(':') && !entry.startTime.split(':')[2]
        ? `${entry.startTime}:00` 
        : entry.startTime;
    }
    if (entry.endTime && typeof entry.endTime === 'string') {
      payload.endTime = entry.endTime.includes(':') && !entry.endTime.split(':')[2]
        ? `${entry.endTime}:00`
        : entry.endTime;
    }

    // Strip client-only/display fields the backend entity doesn't have —
    // extra members are ignored, but names confuse the API error messages.
    delete payload.room;
    delete payload.subjectName;
    delete payload.teacherName;
    delete payload.sectionName;
    delete payload.dayKey;

    return payload;
  }

  updateTimetableEntry(id: number, entry: Partial<TimeTableEntry>): Observable<TimeTableEntry> {
    const payload = this.prepareTimetablePayload(entry);
    return this.http.put<TimeTableEntry>(`${this.apiUrl}/timetables/${id}`, payload);
  }

  deleteTimetableEntry(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/timetables/${id}`);
  }

  validateTimetableEntry(entry: Partial<TimeTableEntry>): Observable<any> {
    return this.http.post(`${this.apiUrl}/timetables/validate`, entry);
  }

  generateTimetable(classId: number, preferences?: any): Observable<TimeTableEntry[]> {
    return this.http.post<TimeTableEntry[]>(`${this.apiUrl}/timetables/generate/${classId}`, preferences);
  }

  // Examination Management
  getExaminations(page: number = 1, pageSize: number = 20): Observable<Examination[]> {
    const params = new HttpParams()
      .set('page', page.toString())
      .set('pageSize', pageSize.toString());
    
    return this.http.get<Examination[]>(`${this.apiUrl}/examinations`, { params }).pipe(
      map((res: any) => res.data || res)
    );
  }

  getExaminationTypes(): Observable<ExaminationType[]> {
    return this.http.get<ExaminationType[]>(`${this.typeUrl}`).pipe(
      map((res: any) => res.data || res)
    );
  }

  getExaminationTypeById(id: number): Observable<ExaminationType> {
    return this.http.get<ExaminationType>(`${this.typeUrl}/${id}`).pipe(
      map((res: any) => res.data || res)
    );
  }

  createExaminationType(type: Partial<ExaminationType>): Observable<ExaminationType> {
    return this.http.post<ExaminationType>(`${this.typeUrl}`, type);
  }

  updateExaminationType(id: number, type: Partial<ExaminationType>): Observable<ExaminationType> {
    return this.http.put<ExaminationType>(`${this.typeUrl}/${id}`, type);
  }

  deleteExaminationType(id: number): Observable<void> {
    return this.http.delete<void>(`${this.typeUrl}/${id}`);
  }

  createExamination(exam: Partial<Examination>): Observable<Examination> {
    const payload = this.prepareExaminationPayload(exam);
    return this.http.post<Examination>(`${this.apiUrl}/examinations`, payload);
  }

  private prepareExaminationPayload(exam: Partial<Examination>): any {
    const payload: any = { ...exam };
    
    // Ensure ID is mapped correctly for updates
    if (exam.id) {
      payload.id = exam.id;
    } else if (exam.examId) {
      payload.id = exam.examId;
    }

    // Map legacy field names to backend model
    if (exam.examName) payload.title = exam.examName;
    if (exam.description) payload.instructions = exam.description;
    
    // If examinationTypeId is missing but examType string is present, try to map
    if (!payload.examinationTypeId && exam.examType) {
       if (String(exam.examType).match(/^\d+$/)) {
         payload.examinationTypeId = Number(exam.examType);
       }
    }

    // Map status -> isPublished
    if (exam.status) {
      payload.isPublished = exam.status.toLowerCase() === 'published';
    }
    
    // Dates: the datepicker yields local-midnight Date objects, which
    // JSON.stringify turns into UTC (local 10/23 IST → 2026-10-22T18:30Z).
    // The backend stores that raw instant, returns it without a Z suffix,
    // and the frontend re-parses it as LOCAL — the calendar date shifts
    // back a day. Send local date-only strings so the stored/returned
    // value is calendar midnight and round-trips unchanged.
    const toLocalDateOnly = (d: any) => {
      if (!(d instanceof Date)) return d;
      const mm = String(d.getMonth() + 1).padStart(2, '0');
      const dd = String(d.getDate()).padStart(2, '0');
      return `${d.getFullYear()}-${mm}-${dd}`;
    };
    if (exam.startDate) payload.startDate = toLocalDateOnly(exam.startDate);
    if (exam.endDate) payload.endDate = toLocalDateOnly(exam.endDate);
    
    // Clean up frontend-only helper fields or legacy fields that shouldn't be in the body
    delete payload.examId;
    delete payload.examName;
    delete payload.examType;
    delete payload.description;
    delete payload.status;
    delete payload.examinationType;
    
    return payload;
  }

  updateExamination(id: number, exam: Partial<Examination>): Observable<Examination> {
    // Ensure the ID is part of the object so prepareExaminationPayload can map it
    const examWithId = { ...exam, id: id };
    const payload = this.prepareExaminationPayload(examWithId);
    return this.http.put<Examination>(`${this.apiUrl}/examinations/${id}`, payload);
  }

  deleteExamination(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/examinations/${id}`);
  }

  getExamSchedules(examId: number): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/examinations/${examId}/schedules`);
  }

  createExamSchedule(examId: number, schedule: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/examinations/${examId}/schedules`, schedule);
  }

  generateExamTimetable(examId: number): Observable<any> {
    return this.http.post(`${this.apiUrl}/examinations/${examId}/generate-timetable`, {});
  }

  // Assignment Management
  getAssignments(classId?: number, subjectId?: number, status?: 'active' | 'inactive', page: number = 1, pageSize: number = 20): Observable<Assignment[]> {
    let params = new HttpParams()
      .set('page', page.toString())
      .set('pageSize', pageSize.toString());
    
    if (classId) params = params.set('classId', classId.toString());
    if (subjectId) params = params.set('subjectId', subjectId.toString());
    if (status) params = params.set('status', status);
    // Backend provides a filtered listing at /assignments/filtered
    return this.http.get<Assignment[]>(`${this.apiUrl}/assignments/filtered`, { params });
  }

  createAssignment(assignment: Partial<Assignment>): Observable<Assignment> {
    const payload = this.prepareAssignmentPayload(assignment);
    return this.http.post<Assignment>(`${this.apiUrl}/assignments`, payload);
  }

  private prepareAssignmentPayload(assignment: Partial<Assignment>): any {
    const payload: any = { ...assignment };
    
    // Convert status string to IsActive boolean
    if (payload.status !== undefined) {
      payload.isActive = payload.status?.toLowerCase() !== 'inactive' && payload.status !== false;
      delete payload.status;
    }
    
    // Remove assignmentId as backend uses Id
    if (payload.assignmentId) {
      payload.id = payload.assignmentId;
      delete payload.assignmentId;
    }
    
    return payload;
  }

  updateAssignment(id: number, assignment: Partial<Assignment>): Observable<Assignment> {
    const payload = this.prepareAssignmentPayload(assignment);
    return this.http.put<Assignment>(`${this.apiUrl}/assignments/${id}`, payload);
  }

  deleteAssignment(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/assignments/${id}`);
  }

  getAssignmentSubmissions(assignmentId: number): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/assignments/${assignmentId}/submissions`);
  }

  gradeSubmission(submissionId: number, grading: any): Observable<any> {
    return this.http.put(`${this.apiUrl}/assignments/submissions/${submissionId}/grade`, grading);
  }

  bulkGradeAssignments(assignmentId: number, gradings: any[]): Observable<any> {
    return this.http.post(`${this.apiUrl}/assignments/${assignmentId}/bulk-grade`, gradings);
  }

  // Reference Data
  getClasses(): Observable<Class[]> {
    return this.http.get<Class[]>(`${environment.apiUrl}/api/academic/all`).pipe(
      map((res: any) => (Array.isArray(res) ? res : res.data || res))
    );
  }

  getClassesByAcademicYear(academicYearId: number): Observable<Class[]> {
    return this.http.get<Class[]>(`${environment.apiUrl}/api/academic/year/${academicYearId}`).pipe(
      map((res: any) => (Array.isArray(res) ? res : res.data || res))
    );
  }

  getSectionsByClass(classId: number): Observable<Section[]> {
    return this.http.get<Section[]>(`${environment.apiUrl}/api/academic/class/${classId}/sections`).pipe(
      map((res: any) => (Array.isArray(res) ? res : res.data || res))
    );
  }

  getAcademicYears(): Observable<AcademicYear[]> {
    return this.http.get<AcademicYear[]>(`${this.apiUrl}/academic-years`).pipe(
      map((res: any) => (Array.isArray(res) ? res : res.data || []))
    );
  }

  /** Subjects (optionally scoped to one class — subjects are class-scoped in the DB). */
  getSubjects(classId?: number): Observable<Subject[]> {
    const url = `${environment.apiUrl}/api/academic/subjects`;
    return this.http.get<Subject[]>(url, {
      params: classId ? new HttpParams().set('classId', String(classId)) : undefined
    }).pipe(
      map((res: any) => (Array.isArray(res) ? res : res.data || [])),
      // Defensive: some legacy endpoints return an object — never let an object reach *ngFor
      map((list: any) => (Array.isArray(list) ? list : []))
    );
  }

  /**
   * Teachers for dropdowns. /api/staff returns a paginated { total, data: [...] }
   * object (NOT an ApiResponse envelope, so the interceptor passes it through) —
   * unwrap `data` and map to { id, name }. Returns a guaranteed array (NG02200 guard).
   */
  getTeachers(): Observable<Teacher[]> {
    return this.http.get<any>(`${environment.apiUrl}/api/staff`, {
      params: new HttpParams().set('pageSize', '1000')
    }).pipe(
      map((res: any) => {
        const list: any[] = Array.isArray(res)
          ? res
          : Array.isArray(res?.data)
            ? res.data
            : [];
        return list.map((s: any) => ({
          id: s.id ?? s.staffId,
          name: (s.name && String(s.name).trim()) || `${s.firstName ?? ''} ${s.lastName ?? ''}`.trim() || `Staff #${s.id ?? s.staffId}`,
          email: s.email,
          designation: s.designation
        }));
      })
    );
  }

  // Grading Schemes
  getGradingSchemes(academicYearId?: number): Observable<any[]> {
    const params = academicYearId ? 
      new HttpParams().set('academicYearId', academicYearId.toString()) : 
      new HttpParams();
    
    return this.http.get<any[]>(`${this.apiUrl}/grading-schemes`, { params });
  }

  /** Students in a class (used by results entry) — GET /api/students/class/{id}. */
  getStudentsByClass$(classId: number): Observable<any[]> {
    return this.http.get<any[]>(`${environment.apiUrl}/api/students/class/${classId}`).pipe(
      map((res: any) => res.data || res || [])
    );
  }

  // Exam Results
  getResults(filter?: { studentId?: number; examType?: string; subjectId?: number }): Observable<ExamResult[]> {
    let params = new HttpParams();
    if (filter?.studentId != null) params = params.set('studentId', String(filter.studentId));
    if (filter?.examType) params = params.set('examType', filter.examType);
    if (filter?.subjectId != null) params = params.set('subjectId', String(filter.subjectId));
    return this.http.get<ExamResult[]>(`${this.apiUrl}/results`, { params });
  }

  createResult(result: ExamResult): Observable<ExamResult> {
    return this.http.post<ExamResult>(`${this.apiUrl}/results`, result);
  }

  updateResult(id: number, result: ExamResult): Observable<void> {
    return this.http.put<void>(`${this.apiUrl}/results/${id}`, result);
  }

  deleteResult(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/results/${id}`);
  }

  createGradingScheme(scheme: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/grading-schemes`, scheme);
  }

  updateGradingScheme(id: number, scheme: any): Observable<any> {
    return this.http.put(`${this.apiUrl}/grading-schemes/${id}`, scheme);
  }

  deleteGradingScheme(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/grading-schemes/${id}`);
  }

  // Analytics and Reports
  getTimetableConflicts(): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/timetables/conflicts`);
  }

  getTeacherWorkload(teacherId?: number): Observable<any> {
    const params = teacherId ? 
      new HttpParams().set('teacherId', teacherId.toString()) : 
      new HttpParams();
    
    return this.http.get(`${this.apiUrl}/analytics/teacher-workload`, { params });
  }

  getClassroomUtilization(): Observable<any> {
    return this.http.get(`${this.apiUrl}/analytics/classroom-utilization`);
  }

  getAssignmentStatistics(classId?: number): Observable<any> {
    const params = classId ? 
      new HttpParams().set('classId', classId.toString()) : 
      new HttpParams();
    
    return this.http.get(`${this.apiUrl}/analytics/assignment-statistics`, { params });
  }

  getExaminationReport(examId: number): Observable<any> {
    return this.http.get(`${this.apiUrl}/examinations/${examId}/report`);
  }

  // Export Functions
  exportTimetable(classId: number, format: 'pdf' | 'excel' = 'pdf'): Observable<Blob> {
    const params = new HttpParams().set('format', format);
    return this.http.get(`${this.apiUrl}/timetables/export/${classId}`, { 
      params, 
      responseType: 'blob' 
    });
  }

  exportExamSchedule(examId: number, format: 'pdf' | 'excel' = 'pdf'): Observable<Blob> {
    const params = new HttpParams().set('format', format);
    return this.http.get(`${this.apiUrl}/examinations/${examId}/export`, { 
      params, 
      responseType: 'blob' 
    });
  }

  exportAssignmentReport(assignmentId: number, format: 'pdf' | 'excel' = 'pdf'): Observable<Blob> {
    const params = new HttpParams().set('format', format);
    return this.http.get(`${this.apiUrl}/assignments/${assignmentId}/export`, { 
      params, 
      responseType: 'blob' 
    });
  }

  // Additional methods needed by the component
  generateExamSchedule(examId: number, scheduleData: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/examinations/${examId}/generate-schedule`, scheduleData);
  }

  getFilteredAssignments(filters: any): Observable<Assignment[]> {
    let params = new HttpParams();
    
    Object.keys(filters).forEach(key => {
      if (filters[key] !== null && filters[key] !== undefined && filters[key] !== '') {
        params = params.set(key, filters[key].toString());
      }
    });
    
    return this.http.get<Assignment[]>(`${this.apiUrl}/assignments/filtered`, { params });
  }

  gradeAssignment(assignmentId: number, grading: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/assignments/${assignmentId}/grade`, grading);
  }

  performBulkActions(actionData: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/bulk-actions`, actionData);
  }
}