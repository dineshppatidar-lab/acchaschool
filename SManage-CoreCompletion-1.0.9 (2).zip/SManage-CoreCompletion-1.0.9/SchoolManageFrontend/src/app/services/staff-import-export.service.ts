import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class StaffImportExportService {
  constructor(private http: HttpClient) {}

  importStaff(file: File): Observable<any> {
    const formData = new FormData();
    formData.append('file', file);
    return this.http.post('/api/staffimportexport/import', formData);
  }

  exportStaff(): Observable<Blob> {
    return this.http.get('/api/staffimportexport/export', { responseType: 'blob' });
  }
}
