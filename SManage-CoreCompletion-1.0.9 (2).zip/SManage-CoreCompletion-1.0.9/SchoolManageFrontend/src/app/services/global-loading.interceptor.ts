import { HttpEvent, HttpInterceptorFn, HttpRequest, HttpContextToken, HttpContext } from '@angular/common/http';
import { inject } from '@angular/core';
import { Observable } from 'rxjs';
import { finalize } from 'rxjs/operators';

import { GlobalLoadingService } from './global-loading.service';

/**
 * Per-request opt-OUT of the global loading overlay. Set on the request
 * HttpContext for background/telemetry/polling calls or requests that must use
 * a local indicator instead:
 *
 *   this.http.get(url, { context: skipGlobalLoadingHttpContext() })
 *
 * Excluded requests never touch the global counter at all.
 */
export const SKIP_GLOBAL_LOADING = new HttpContextToken<boolean>(() => false);

/**
 * Per-request override of the message shown in the overlay (e.g.
 * 'Collecting fee payment...'):
 *
 *   this.http.post(url, body, { context: globalLoadingMessageContext('Collecting fee payment...') })
 */
export const GLOBAL_LOADING_MESSAGE = new HttpContextToken<string | undefined>(() => undefined);

/** Convenience: an HttpContext that hides the request from the global overlay. */
export function skipGlobalLoadingHttpContext(): HttpContext {
  return new HttpContext().set(SKIP_GLOBAL_LOADING, true);
}

/**
 * GlobalLoadingInterceptor — automatic integration between HTTP traffic and
 * GlobalLoadingService. Registered FIRST in the interceptor chain
 * (outermost), so the counter window covers the whole lifetime of a call,
 * including silent token-refresh + retry performed by authRefreshInterceptor.
 *
 * Behaviour:
 *  - begin() is called synchronously when the request leaves the chain and
 *    end() via finalize() on success, error and teardown (cancellation during
 *    navigation), so the counter can never leak upward.
 *  - Mutating methods (POST/PUT/PATCH/DELETE) are additionally counted so the
 *    overlay blocks interaction only while a submission is in flight.
 *  - Requests carrying SKIP_GLOBAL_LOADING, and the auth + notification
 *    polling endpoints below, are never counted (no overlay, no counter churn).
 */
/**
 * Never show the global overlay for these — they have their own local loading
 * UI (login/register/forgot-password buttons) or are background traffic
 * (notification bell polling, consistent with SILENT_URL_FRAGMENTS in
 * api-response.interceptor).
 */
const EXCLUDED_URL_FRAGMENTS = [
  '/api/auth/',
  '/api/notification' // also matches /api/notification (bell list load + polling)
];

function isGlobalLoadingDisabled(req: HttpRequest<unknown>): boolean {
  return req.context.get(SKIP_GLOBAL_LOADING) ||
    EXCLUDED_URL_FRAGMENTS.some(f => req.url.includes(f));
}

export const globalLoadingInterceptor: HttpInterceptorFn = (req, next): Observable<HttpEvent<unknown>> => {
  const loading = inject(GlobalLoadingService);

  if (isGlobalLoadingDisabled(req)) {
    return next(req);
  }

  const isMutating = req.method !== 'GET' && req.method !== 'HEAD';
  // Overlay text is a uniform 'Loading' everywhere; GLOBAL_LOADING_MESSAGE
  // stays available for callers that genuinely want a custom label.
  const contextMessage = req.context.get(GLOBAL_LOADING_MESSAGE);
  const message = contextMessage ?? 'Loading';

  loading.begin(message);
  if (isMutating) { loading.markMutating(); }

  return next(req).pipe(
    finalize(() => {
      if (isMutating) { loading.releaseMutating(); }
      loading.end();
    })
  );
};
