import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { StudentFullDetailsDto } from '../shared/dtos/student-full-details-dto';

@Injectable({
  providedIn: 'root'
})
export class StudentFullDetailsService {
  private apiUrl = '/api/students/full-details';

  constructor(private http: HttpClient) { }

  createStudentFullDetails(student: StudentFullDetailsDto): Observable<StudentFullDetailsDto> {
    return this.http.post<StudentFullDetailsDto>(this.apiUrl, student);
  }

  getStudentFullDetails(id: number): Observable<StudentFullDetailsDto> {
    return this.http.get<StudentFullDetailsDto>(`${this.apiUrl}/${id}`);
  }

  updateStudentFullDetails(id: number, student: StudentFullDetailsDto): Observable<void> {
    return this.http.put<void>(`${this.apiUrl}/${id}`, student);
  }
}
