import { Injectable, OnDestroy } from '@angular/core';
import * as signalR from '@microsoft/signalr';
import { BehaviorSubject, Observable, Subject } from 'rxjs';
import { environment } from '../../environments/environment';
import { AuthService } from './auth.service';

/**
 * Single shared SignalR connection for the whole app
 * (docs/critical-issues/08-signalr-open-hub.md).
 *
 * Security model matching the hardened ActivityHub:
 *  - Every request carries the JWT via accessTokenFactory (negotiate + websocket
 *    query string). The backend hub is [Authorize] and rejects anonymous connections.
 *  - The server auto-joins each connection to its tenant group derived from the JWT
 *    tenant_id claim — the client cannot join other tenants' groups.
 *  - Connection starts when a user is present, stops on logout, and on reconnect
 *    the accessTokenFactory supplies the (possibly refreshed) token automatically.
 */
@Injectable({ providedIn: 'root' })
export class RealtimeHubService implements OnDestroy {
  private hubConnection: signalR.HubConnection | null = null;
  private readonly connectedSubject = new BehaviorSubject<boolean>(false);
  private readonly serverLostSubject = new Subject<void>();

  /** Emits true/false as the hub connection comes up/goes down. */
  public connected$ = this.connectedSubject.asObservable();

  constructor(private auth: AuthService) {}

  /** Ensures a started connection. Safe to call repeatedly (idempotent). */
  public async ensureStarted(): Promise<void> {
    if (!this.auth.token) {
      return; // not logged in — nothing to connect with
    }
    if (this.hubConnection && this.hubConnection.state === signalR.HubConnectionState.Connected) {
      return;
    }

    if (!this.hubConnection) {
      this.hubConnection = this.buildConnection();
    }

    if (this.hubConnection.state === signalR.HubConnectionState.Disconnected) {
      try {
        await this.hubConnection.start();
        this.connectedSubject.next(true);
      } catch (err) {
        console.error('[RealtimeHub] Connection Error:', err);
        // Continue without realtime — all features degrade gracefully.
      }
    }
  }

  /** Stops and disposes the connection (called on logout). */
  public async stop(): Promise<void> {
    if (this.hubConnection) {
      try {
        await this.hubConnection.stop();
      } catch {
        /* already stopped */
      }
      this.hubConnection = null;
      this.connectedSubject.next(false);
    }
  }

  /**
   * Subscribes to a server event. The handler fires only for messages the server
   * targets at this user's tenant scope.
   */
  public on(methodName: string, callback: (...args: any[]) => void): void {
    if (!this.hubConnection) {
      this.hubConnection = this.buildConnection();
    }
    this.hubConnection.on(methodName, callback);
  }

  public off(methodName: string, callback?: (...args: any[]) => void): void {
    if (callback) {
      this.hubConnection?.off(methodName, callback);
    } else {
      this.hubConnection?.off(methodName);
    }
  }

  private buildConnection(): signalR.HubConnection {
    const base = (environment.apiUrl || '').replace(/\/$/, '');
    const hubUrl = `${base}/activityHub`;

    const connection = new signalR.HubConnectionBuilder()
      .withUrl(hubUrl, {
        // Fresh token on every (re)connect — after an authRefreshInterceptor token
        // rotation, reconnects automatically use the new token.
        accessTokenFactory: () => this.auth.token ?? ''
      })
      .withAutomaticReconnect([0, 2000, 5000, 10000, 30000])
      .configureLogging(environment.production ? signalR.LogLevel.Warning : signalR.LogLevel.Information)
      .build();

    connection.onreconnecting(() => this.connectedSubject.next(false));
    connection.onreconnected(() => this.connectedSubject.next(true));
    connection.onclose(() => this.connectedSubject.next(false));

    return connection;
  }

  ngOnDestroy(): void {
    void this.stop();
  }
}
