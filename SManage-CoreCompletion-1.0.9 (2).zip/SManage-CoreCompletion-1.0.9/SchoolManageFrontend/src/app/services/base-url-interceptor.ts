import { HttpInterceptorFn } from '@angular/common/http';
import { environment } from '../../environments/environment';
  
export const baseUrlInterceptor: HttpInterceptorFn = (req, next) => {
  const isAbsoluteUrl = req.url.startsWith('http://') || req.url.startsWith('https://');

  if (isAbsoluteUrl) {
    return next(req);
  }
  const base = environment.apiUrl?.replace(/\/$/, '') || '';
  const path = req.url.startsWith('/') ? req.url : `/${req.url}`;
  const finalUrl = `${base}${path}`;

  // Dev debug: show URL rewrite once per request
  console.debug('[BaseUrlInterceptor] URL:', req.url, '->', finalUrl);

  const modifiedReq = req.clone({ url: finalUrl });
  return next(modifiedReq);
};