import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface AuditLogPage {
  success: boolean;
  message: string;
  data: any[];
  pagination: {
    page: number;
    pageSize: number;
    totalRecords: number;
    totalPages: number;
  };
}

export interface AuditLogFilters {
  actions: string[];
  entities: string[];
  users: string[];
}

@Injectable({ providedIn: 'root' })
export class AuditLogService {
  constructor(private http: HttpClient) {}

  getLogs(opts: {
    page?: number;
    pageSize?: number;
    search?: string;
    action?: string;
    entity?: string;
    user?: string;
    from?: string;
    to?: string;
  } = {}): Observable<AuditLogPage> {
    let params = new HttpParams()
      .set('page', String(opts.page ?? 1))
      .set('pageSize', String(opts.pageSize ?? 20));

    if (opts.search) params = params.set('search', opts.search);
    if (opts.action) params = params.set('action', opts.action);
    if (opts.entity) params = params.set('entity', opts.entity);
    if (opts.user) params = params.set('user', opts.user);
    if (opts.from) params = params.set('from', opts.from);
    if (opts.to) params = params.set('to', opts.to);

    return this.http.get<AuditLogPage>('/api/auditlog', { params });
  }

  getFilterOptions(): Observable<{ success: boolean; data: AuditLogFilters }> {
    return this.http.get<{ success: boolean; data: AuditLogFilters }>(
      '/api/auditlog/filters'
    );
  }
}
