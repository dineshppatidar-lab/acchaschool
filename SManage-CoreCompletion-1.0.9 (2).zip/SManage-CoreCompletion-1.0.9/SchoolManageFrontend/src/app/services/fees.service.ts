import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { RealtimeHubService } from './realtime-hub.service';

export interface Fee {
  id?: number;
  studentId: number;
  feeType: string;
  amount: number;
  dueDate: string;
  status: string;
}

@Injectable({ providedIn: 'root' })
export class FeesService {
  private baseUrl = '/api/fees';

  constructor(private http: HttpClient, private realtime: RealtimeHubService) {
    void realtime.ensureStarted();
  }

  getAll(params?: any): Observable<Fee[]> {
    return this.http.get<{data: Fee[], total: number}>(this.baseUrl, { params }).pipe(
      map((response: any) => response.data || [])
    );
  }
  getById(id: number): Observable<Fee> {
    return this.http.get<Fee>(`${this.baseUrl}/${id}`);
  }
  create(data: Fee): Observable<Fee> {
    return this.http.post<Fee>(this.baseUrl, data);
  }
  update(id: number, data: Fee): Observable<void> {
    return this.http.put<void>(`${this.baseUrl}/${id}`, data);
  }
  delete(id: number): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/${id}`);
  }
  import(data: FormData): Observable<any> {
    return this.http.post(`${this.baseUrl}/import`, data);
  }
  export(params?: any): Observable<Blob> {
    return this.http.get(`${this.baseUrl}/export`, { params, responseType: 'blob' });
  }

  onFeesChanged(callback: (data: any) => void) {
    this.realtime.on('FeesChanged', callback);
  }

  // TODO: Integrate NotificationService and AuditLogService for notifications and audit logs
}