import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatListModule } from '@angular/material/list';
import { MatCardModule } from '@angular/material/card';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { RouterModule } from '@angular/router';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatChipsModule } from '@angular/material/chips';
import { MatMenuModule } from '@angular/material/menu';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatDividerModule } from '@angular/material/divider';
import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSortModule } from '@angular/material/sort';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { StudentService, Student } from '../services/student.service';
import { MasterDataService } from '../services/master-data.service';
import { ImportExportService } from '../services/import-export.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Observable, combineLatest, BehaviorSubject } from 'rxjs';
import { delay, map, startWith, debounceTime, distinctUntilChanged } from 'rxjs/operators';

@Component({
  selector: 'app-student-list',
  standalone: true,
  imports: [
    CommonModule, 
    FormsModule,
    ReactiveFormsModule,
    MatListModule, 
    MatCardModule, 
    MatProgressSpinnerModule, 
    MatIconModule, 
    MatButtonModule, 
    RouterModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatChipsModule,
    MatMenuModule,
    MatTooltipModule,
    MatDividerModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule
  ],
  templateUrl: './student-list-modern.html',
  styleUrls: ['./student-list-modern.scss']
})
export class StudentListComponent implements OnInit {
  students$?: Observable<Student[]>;
  filteredStudents$?: Observable<Student[]>;
  displayedColumns: string[] = ['id', 'name', 'scholarNumber', 'rollNumber', 'class', 'contact', 'gender', 'actions'];
  
  // View controls
  viewMode: 'cards' | 'table' = 'cards';
  isLoading = true;
  exporting = false;
  
  // Filter controls
  searchTerm = '';
  selectedClass = 'all';
  selectedStatus = 'all';
  private searchSubject = new BehaviorSubject<string>('');
  private classFilterSubject = new BehaviorSubject<string>('all');
  private statusFilterSubject = new BehaviorSubject<string>('all');
  
  // Statistics
  statistics = {
    totalStudents: 0,
    activeStudents: 0,
    newStudents: 0,
    averageAge: 0
  };

  classes: { id: number; name: string }[] = [];

  constructor(private studentService: StudentService, private masterDataService: MasterDataService, private importExportService: ImportExportService, private snackBar: MatSnackBar) {}

  ngOnInit(): void {
    this.loadClasses();
    this.loadStudents();
    this.setupFilters();
  }

  loadClasses(): void {
    this.masterDataService.getClasses().subscribe({
      next: (res: any) => {
        const list = Array.isArray(res) ? res : (res?.data ?? []);
        this.classes = list.map((c: any) => ({ id: c.id, name: c.name || c.className || `Class ${c.id}` }));
      },
      error: () => { this.classes = []; }
    });
  }

  loadStudents() {
    console.log('Loading students...');
    this.isLoading = true;
    this.students$ = this.studentService.getAll().pipe(
      delay(500),
      map((students: Student[]) => {
        this.isLoading = false;
        this.updateStatistics(students);
        return students;
      })
    );
  }

  setupFilters() {
    if (this.students$) {
      this.filteredStudents$ = combineLatest([
        this.students$,
        this.searchSubject.pipe(
          debounceTime(300),
          distinctUntilChanged(),
          startWith('')
        ),
        this.classFilterSubject.pipe(
          startWith('all')
        ),
        this.statusFilterSubject.pipe(
          startWith('all')
        )
      ]).pipe(
        map(([students, searchTerm, classFilter, statusFilter]) => 
          this.filterStudents(students, searchTerm, classFilter, statusFilter)
        )
      );
    }
  }

  private filterStudents(students: Student[], searchTerm: string, classFilter: string, statusFilter: string): Student[] {
    return students.filter(student => {
      const fullName = `${student.firstName} ${student.lastName}`.toLowerCase();
      const matchesSearch = !searchTerm || 
        fullName.includes(searchTerm.toLowerCase()) ||
        student.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        student.rollNumber?.toLowerCase().includes(searchTerm.toLowerCase());
      
      const matchesClass = classFilter === 'all' || student.classId?.toString() === classFilter;
      const matchesStatus = statusFilter === 'all'; // Simplified for now since no status in interface
      
      return matchesSearch && matchesClass && matchesStatus;
    });
  }

  private updateStatistics(students: Student[]) {
    this.statistics = {
      totalStudents: students.length,
      activeStudents: students.length, // Mock all active
      newStudents: Math.floor(students.length * 0.1), // Mock 10% new
      averageAge: 16 // Mock average age
    };
  }

  onSearchChange(value: string) {
    this.searchTerm = value;
    this.searchSubject.next(value);
  }

  onClassFilterChange(value: string) {
    this.selectedClass = value;
    this.classFilterSubject.next(value);
  }

  onStatusFilterChange(value: string) {
    this.selectedStatus = value;
    this.statusFilterSubject.next(value);
  }

  toggleViewMode() {
    this.viewMode = this.viewMode === 'cards' ? 'table' : 'cards';
  }

  editStudent(id?: number) {
    if (id) {
      console.log('Edit student:', id);
    }
  }

  deleteStudent(id?: number) {
    if (id && confirm('Are you sure you want to delete this student?')) {
      // Implement delete logic
      console.log('Delete student:', id);
    }
  }

  viewDetails(id?: number) {
    if (id) {
      console.log('View student details:', id);
    }
  }

  exportStudents() {
    if (this.exporting) return;
    this.exporting = true;
    this.importExportService.exportStudents().subscribe({
      next: (blob) => {
        this.exporting = false;
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `students_${new Date().toISOString().split('T')[0]}.csv`;
        a.click();
        window.URL.revokeObjectURL(url);
      },
      error: () => {
        this.exporting = false;
        this.snackBar.open('Export failed. Please try again.', 'Close', { duration: 5000 });
      }
    });
  }

  refreshList() {
    this.loadStudents();
  }
}