import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { StudentManagementService } from '../shared/services/student-management.service';
import { StudentFullDetailsDto } from '../shared/models/student-full-details-dto';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatSelectModule } from '@angular/material/select';
import { MatCardModule } from '@angular/material/card';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatStepperModule } from '@angular/material/stepper';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatDividerModule } from '@angular/material/divider';
import { debounceTime, distinctUntilChanged, Subject, Subscription } from 'rxjs';
import { BackButtonComponent } from '../shared/components/back-button.component';

@Component({
  selector: 'app-student-form',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatAutocompleteModule,
    MatButtonModule,
    MatIconModule,
    MatSelectModule,
    MatCardModule,
    MatCheckboxModule,
    MatStepperModule,
    MatProgressSpinnerModule,
    MatTooltipModule,
    MatDividerModule,
    BackButtonComponent
  ],
  templateUrl: './student-form.html',
  styleUrls: ['./student-form.scss']
})
export class StudentFormComponent implements OnInit, OnDestroy {
  studentForm: FormGroup;
  searchControl = new FormBuilder().control('');
  searchResults: StudentFullDetailsDto[] = [];
  selectedStudent: StudentFullDetailsDto | null = null;
  success: string | null = null;
  error: string | null = null;
  isLoading = false;
  isEditMode = false;
  /** Current active step (1-based) for the progress stepper pills. */
  currentStep = 1;
  /** Completion state per step for the stepper dot colors. */
  stepStatus = [false, false, false, false, false, false];
  
  private searchSubject = new Subject<string>();
  private subscriptions: Subscription[] = [];

  constructor(private fb: FormBuilder, private studentManagementService: StudentManagementService) {
    this.studentForm = this.createForm();
  }

  ngOnInit() {
    // Setup search functionality with debounce
    const searchSub = this.searchSubject
      .pipe(debounceTime(300), distinctUntilChanged())
      .subscribe(searchTerm => {
        if (searchTerm.length >= 2) {
          this.isLoading = true;
          this.studentManagementService.getAllStudentFullDetails(searchTerm, 1, 10).subscribe({
            next: (results) => {
              this.searchResults = results || [];
              this.isLoading = false;
            },
            error: () => {
              this.searchResults = [];
              this.isLoading = false;
            }
          });
        } else {
          this.searchResults = [];
        }
      });
    
    this.subscriptions.push(searchSub);
    
    // Setup search input listener
    const searchInput = this.searchControl.valueChanges
      .subscribe(value => {
        this.searchSubject.next(value || '');
      });
    this.subscriptions.push(searchInput);
  }

  ngOnDestroy() {
    this.subscriptions.forEach(sub => sub.unsubscribe());
  }

  private createForm(): FormGroup {
    return this.fb.group({
      id: [null],
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      dateOfBirth: ['', Validators.required],
      gender: ['', Validators.required],
      address: [''],
      contactNumber: [''],
      email: ['', [Validators.required, Validators.email]],
      admissionDate: ['', Validators.required],
      classId: ['', Validators.required],
      sectionId: ['', Validators.required],
      rollNumber: ['', Validators.required],
      parentId: [null],
      busRouteId: [null],
      // Extended student details
      studentAddressInfo: this.fb.group({
        currentHouseNumber: [''],
        currentStreetName: [''],
        currentCity: [''],
        currentState: [''],
        currentPostalCode: [''],
        currentCountry: [''],
        sameAsPermanent: [false],
        permanentHouseNumber: [''],
        permanentStreetName: [''],
        permanentCity: [''],
        permanentState: [''],
        permanentPostalCode: [''],
        permanentCountry: ['']
      }),
      studentAcademicHistory: this.fb.group({
        previousSchoolName: [''],
        previousSchoolBoard: [''],
        previousSchoolAddress: [''],
        yearPassedFrom: [null],
        lastGradeAttended: [''],
        academicPercentage: [null],
        transferCertificateNumber: [''],
        reasonForTransfer: ['']
      }),
      studentMedicalInfo: this.fb.group({
        bloodGroup: [''],
        lastHealthCheckDate: [''],
        knownAllergies: [''],
        hasAsthma: [false],
        hasDiabetes: [false],
        hasHeartCondition: [false],
        hasEpilepsy: [false],
        otherMedicalConditions: [''],
        isVaccinatedPolio: [false],
        isVaccinatedMeasles: [false],
        isVaccinatedBCG: [false],
        isVaccinatedTCV: [false]
      }),
      studentDocumentInfo: this.fb.group({
        idProofType: [''],
        idProofNumber: [''],
        idExpiryDate: [''],
        passportNumber: [''],
        birthCertificateNumber: [''],
        documentVerificationStatus: ['']
      }),
      studentSpecialNeeds: this.fb.group({
        hasSpecialNeeds: [false],
        disabilityType: [''],
        disabilitySeverity: [''],
        auxiliaryAidsRequired: ['']
      }),
      studentHostelInfo: this.fb.group({
        hostelRequired: [false],
        preferredHostel: [''],
        roomType: [''],
        travelMode: [''],
        distanceFromHome: [null]
      }),
      studentScholarshipInfo: this.fb.group({
        eligibleForScholarship: [false],
        scholarshipType: [''],
        scholarshipPercentage: [null],
        concessionType: [''],
        concessionAmount: [null]
      })
    });
  }

  onSelectStudent(student: StudentFullDetailsDto) {
    this.selectedStudent = student;
    this.isEditMode = true;
    this.searchControl.setValue(student.firstName + ' ' + student.lastName);
    this.searchResults = [];
    this.loadStudentData(student);
  }

  private loadStudentData(student: StudentFullDetailsDto) {
    this.studentForm.patchValue({
      id: student.id,
      firstName: student.firstName,
      lastName: student.lastName,
      dateOfBirth: student.dateOfBirth,
      gender: student.gender,
      address: student.address,
      contactNumber: student.contactNumber,
      email: student.email,
      admissionDate: student.admissionDate,
      classId: student.classId,
      sectionId: student.sectionId,
      rollNumber: student.rollNumber,
      parentId: student.parentId,
      busRouteId: student.busRouteId
    });

    // Patch extended details if they exist
    if (student.addressInfo) {
      this.studentForm.get('studentAddressInfo')?.patchValue(student.addressInfo);
    }
    if (student.academicHistory) {
      this.studentForm.get('studentAcademicHistory')?.patchValue(student.academicHistory);
    }
    if (student.medicalInfo) {
      this.studentForm.get('studentMedicalInfo')?.patchValue(student.medicalInfo);
    }
    if (student.documentInfo) {
      this.studentForm.get('studentDocumentInfo')?.patchValue(student.documentInfo);
    }
    if (student.specialNeeds) {
      this.studentForm.get('studentSpecialNeeds')?.patchValue(student.specialNeeds);
    }
    if (student.hostelInfo) {
      this.studentForm.get('studentHostelInfo')?.patchValue(student.hostelInfo);
    }
    if (student.scholarshipInfo) {
      this.studentForm.get('studentScholarshipInfo')?.patchValue(student.scholarshipInfo);
    }
  }

  clearSearch() {
    this.searchControl.reset();
    this.selectedStudent = null;
    this.isEditMode = false;
    this.studentForm.reset();
    this.searchResults = [];
  }

  onSubmit() {
    if (this.studentForm.valid) {
      const formData = this.studentForm.value;
      
      if (this.isEditMode && formData.id) {
        // Update existing student
        this.studentManagementService.updateStudentFullDetails(formData.id, formData).subscribe({
          next: () => {
            this.success = 'Student updated successfully!';
            this.error = null;
            setTimeout(() => {
              this.clearSearch();
              this.success = null;
            }, 2000);
          },
          error: (err) => {
            this.error = 'Failed to update student: ' + (err?.error?.message || err?.message);
            this.success = null;
          }
        });
      } else {
        // Create new student
        this.studentManagementService.createStudentFullDetails(formData).subscribe({
          next: () => {
            this.success = 'Student created successfully!';
            this.error = null;
            setTimeout(() => {
              this.clearSearch();
              this.success = null;
            }, 2000);
          },
          error: (err) => {
            this.error = 'Failed to create student: ' + (err?.error?.message || err?.message);
            this.success = null;
          }
        });
      }
    } else {
      this.error = 'Please fill in all required fields';
    }
  }

  /** Scroll a section into view inside the layout's scroll container.
   *  Uses scrollIntoView (never URL fragments) so the Angular Router is not
   *  hijacked — raw href="#..." anchors navigate away from the page in an SPA. */
  scrollToSection(sectionId: string): void {
    document.getElementById(sectionId)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  getInitials(firstName: string, lastName: string): string {
    const first = firstName ? firstName.charAt(0).toUpperCase() : '';
    const last = lastName ? lastName.charAt(0).toUpperCase() : '';
    return first + last;
  }

  /** 0–7 sections completed, based on meaningful values in each group. */
  get completedSections(): number {
    const f = this.studentForm;
    if (!f) return 0;
    let n = 0;
    if (f.get('firstName')?.value && f.get('lastName')?.value) n++;
    if (f.get('email')?.valid && f.get('email')?.value) n++;
    if (f.get('admissionDate')?.value && f.get('classId')?.value) n++;
    const addr = f.get('studentAddressInfo');
    if (addr && (addr.get('currentCity')?.value || addr.get('currentStreetName')?.value)) n++;
    const med = f.get('studentMedicalInfo');
    if (med && med.get('bloodGroup')?.value) n++;
    const hostel = f.get('studentHostelInfo');
    if (hostel && (hostel.get('hostelRequired')?.value || hostel.get('travelMode')?.value)) n++;
    const docs = f.get('studentDocumentInfo');
    if (docs && docs.get('idProofNumber')?.value) n++;
    return n;
  }

  get completionPct(): number {
    return Math.round((this.completedSections / 7) * 100);
  }
}
