import { Component, OnInit, OnDestroy, HostListener, ChangeDetectorRef, effect } from '@angular/core';
import { timer } from 'rxjs';
import { CommonModule } from '@angular/common';
import { RouterModule, Router, NavigationEnd } from '@angular/router';
import { MatListModule } from '@angular/material/list';
import { MatIconModule } from '@angular/material/icon';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatButtonModule } from '@angular/material/button';
import { MatDividerModule } from '@angular/material/divider';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatRippleModule } from '@angular/material/core';
import { Subject, Subscription } from 'rxjs';
import { takeUntil, filter } from 'rxjs/operators';
import { SidebarService } from '../services/sidebar.service';
import { AuthService } from '../../services/auth.service';
import { DynamicMenuService, MenuItem } from '../../services/dynamic-menu.service';
import { SetupStatusService } from '../../core/services/setup-status.service';
import { FavoritesService, FavoriteItem } from '../services/favorites.service';
import { RecentItemsService, RecentItem } from '../services/recent-items.service';
import { ThemeService } from '../services/theme.service';

/**
 * Refactored Sidebar Component using Dynamic Menu System
 * 
 * This component replaces the hardcoded navigation with a dynamic, API-driven menu
 * that supports:
 * - Permission-based visibility
 * - Hierarchical menu items
 * - Tenant-aware configuration
 * - Menu caching with TTL
 */
@Component({
  selector: 'app-sidebar-dynamic',
  standalone: true,
  imports: [
    CommonModule,
    RouterModule,
    MatListModule,
    MatIconModule,
    MatTooltipModule,
    MatButtonModule,
    MatDividerModule,
    MatProgressSpinnerModule,
    MatRippleModule
  ],
  templateUrl: './sidebar-dynamic.component.html',
  styleUrls: ['./sidebar-dynamic.component.scss']
})
export class SidebarDynamicComponent implements OnInit, OnDestroy {

  // State management
  isSidebarOpen = true;
  isMobileViewport = false;
  user: any = null;
  avatarUrl: string = 'assets/images/default-avatar.png';

  // Dynamic menu data
  mainMenu: MenuItem[] = [];
  isLoading = false;
  error: string | null = null;
  expandedItem: string | null = null;

  // Favorites state
  favorites: FavoriteItem[] = [];
  favoritesExpanded = true;

  // Recent items state
  // Feature flag: the Recent section in the sidebar is hidden for now per
  // product decision. Flip to true to restore it.
  readonly showRecentItems = false;
  recentItems: RecentItem[] = [];
  recentExpanded = true;

  // Precomputed "time ago" labels keyed by recent item id.
  // Precomputing avoids NG0100 (ExpressionChangedAfterItHasBeenCheckedError) that occurs
  // when getRelativeTime() is called directly in the template and Date.now() shifts
  // between the change-detection pass and Angular's dev-mode verification pass.
  recentTimeLabels: { [id: number]: string } = {};

  // Theme state
  isDark = false;

  // Cleanup
  private destroy$ = new Subject<void>();
  private sidebarSubscription: Subscription | undefined;

  constructor(
    private sidebarService: SidebarService,
    private authService: AuthService,
    private menuService: DynamicMenuService,
  private setupStatus: SetupStatusService,
    private favoritesService: FavoritesService,
    private recentItemsService: RecentItemsService,
    private themeService: ThemeService,
    private router: Router,
    private cdr: ChangeDetectorRef
  ) {
    // Keep the onboarding badge live: re-apply whenever setup status changes
    // (initial load + every refresh after a wizard step completes). effect()
    // must be created in an injection context (constructor/field initializer),
    // so it lives here rather than in ngOnInit — otherwise it throws NG0203.
    effect(() => {
      const count = this.setupStatus.incompleteRequiredCount();
      this.applySetupBadge(this.mainMenu, count);
      this.cdr.markForCheck();
    });
  }

  ngOnInit(): void {
    this.checkViewport();

    // Subscribe to sidebar state
    this.sidebarSubscription = this.sidebarService.sidebarOpen$.subscribe(
      (isOpen) => {
        this.isSidebarOpen = isOpen;
        this.cdr.markForCheck();
      }
    );

    // Subscribe to theme changes
    this.themeService.theme$
      .pipe(takeUntil(this.destroy$))
      .subscribe(theme => {
        this.isDark = theme === 'dark';
        this.cdr.markForCheck();
      });

    // Get current user
    this.user = this.authService.getCurrentUser();

    // Subscribe to favorites changes
    this.favoritesService.favorites$
      .pipe(takeUntil(this.destroy$))
      .subscribe(favs => {
        this.favorites = favs;
        this.cdr.markForCheck();
      });

    // Subscribe to recent items changes
    this.recentItemsService.recent$
      .pipe(takeUntil(this.destroy$))
      .subscribe(recent => {
        this.recentItems = recent;
        this.rebuildRecentTimeLabels();
        this.cdr.markForCheck();
      });

    // Periodically refresh "time ago" labels (every 30s)
    timer(0, 30000)
      .pipe(
        takeUntil(this.destroy$)
      )
      .subscribe(() => {
        this.rebuildRecentTimeLabels();
        this.cdr.markForCheck();
      });

    // Load dynamic menu
    this.loadMainMenu();

    // Listen for route changes to mark active items and record visits
    this.router.events
      .pipe(
        filter(event => event instanceof NavigationEnd),
        takeUntil(this.destroy$)
      )
      .subscribe((event: any) => {
        const url = event.urlAfterRedirects || event.url;
        this.recordVisitByRoute(url);
        this.rebuildRecentTimeLabels();
        this.cdr.markForCheck();
      });
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
    this.sidebarSubscription?.unsubscribe();
  }

  /**
   * Apply the onboarding badge to the "Setup Wizard" menu item: the count of
   * incomplete REQUIRED setup steps. Badge is removed once setup is complete.
   */
  private applySetupBadge(items: MenuItem[], count?: number): void {
    const incomplete = count ?? this.setupStatus.incompleteRequiredCount();
    const find = (list: MenuItem[]): MenuItem | null => {
      for (const item of list) {
        if (item.route === '/app/setup') return item;
        if (item.children) {
          const hit = find(item.children);
          if (hit) return hit;
        }
      }
      return null;
    };
    const setupItem = find(items);
    if (setupItem) {
      setupItem.badge = incomplete > 0 ? String(incomplete) : undefined;
      this.cdr.markForCheck();
    }
  }

  /**
   * Load main menu from dynamic menu service
   */
  private loadMainMenu(): void {
    this.isLoading = true;
    this.error = null;

    this.menuService.loadMainMenu()
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (menu: any) => {
          console.log('[SidebarDynamicComponent] Menu payload received', menu);
          this.mainMenu = Array.isArray(menu) ? menu : (menu?.data ?? []);
          this.isLoading = false;
          this.setInitialExpansion();
          this.cdr.markForCheck();
        },
        error: (err) => {
          console.error('Failed to load main menu:', err);
          this.error = 'Failed to load menu. Please refresh the page.';
          this.isLoading = false;
          this.cdr.markForCheck();
        }
      });
  }

  /**
   * Handle menu item navigation
   */
  onMenuItemNavigate(item: MenuItem): void {
    // Close sidebar on mobile
    if (this.isMobileViewport) {
      this.toggleSidebar();
    }
  }

  onNavClick(): void {
    if (this.isMobileViewport) {
      this.toggleSidebar();
    }
  }

  toggleExpand(item: MenuItem): void {
    this.expandedItem = this.expandedItem === item.label ? null : item.label;
  }

  isExpanded(item: MenuItem): boolean {
    return this.expandedItem === item.label;
  }

  private setInitialExpansion(url?: string): void {
    const currentUrl = url || this.router.url;
    this.mainMenu.forEach(item => {
      if (item.children?.some(child => currentUrl.startsWith(child.route || ''))) {
        this.expandedItem = item.label;
      }
    });
  }

  // ── Menu display ──

  /**
   * Get the menu items to display.
   * (The left-menu search bar was removed per product decision; the menu
   * always renders the full permission-filtered tree.)
   */
  get displayMenu(): MenuItem[] {
    return this.mainMenu;
  }

  /**
   * Toggle sidebar open/closed
   */
  toggleSidebar(): void {
    this.sidebarService.toggleSidebar();
  }

  /**
   * Refresh menu (useful for permission or tenant changes)
   */
  refreshMenu(): void {
    this.menuService.refreshMenu();
    this.loadMainMenu();
  }

  /**
   * Ensure the viewport is evaluated during initialization.
   */
  private checkViewport(): void {
    if (typeof window !== 'undefined') {
      this.isMobileViewport = window.innerWidth < 768;
    }
  }

  /**
   * Check if viewport is mobile
   */
  @HostListener('window:resize', ['$event'])
  onResize(event: Event): void {
    this.isMobileViewport = window.innerWidth < 768;
  }

  /**
   * Get avatar URL with fallback
   */
  get userAvatar(): string {
    return this.user?.avatarUrl || this.avatarUrl;
  }

  /**
   * Get user display name
   */
  get userDisplayName(): string {
    return this.user?.fullName || this.user?.email || 'User';
  }

  /**
   * Check if user is authenticated
   */
  get isAuthenticated(): boolean {
    return !!this.user;
  }

  /**
   * Toggle dark mode
   */
  toggleDarkMode(): void {
    this.themeService.toggleTheme();
  }

  /**
   * Logout
   */
  logout(): void {
    this.authService.logout();
    this.router.navigate(['/login']);
  }

  // ── Favorites Methods ──

  /**
   * Toggle a menu item as favorite
   */
  toggleFavorite(event: MouseEvent, item: MenuItem): void {
    event.preventDefault();
    event.stopPropagation();

    this.favoritesService.toggleFavorite({
      id: item.id,
      label: item.label,
      icon: item.icon,
      route: item.route || ''
    });
  }

  /**
   * Check if a menu item is favorited
   */
  isFavorite(menuItem: MenuItem): boolean {
    return this.favoritesService.isFavorite(menuItem.id);
  }

  /**
   * Remove a favorite by ID
   */
  removeFavorite(event: MouseEvent, menuItemId: number): void {
    event.preventDefault();
    event.stopPropagation();
    this.favoritesService.removeFavorite(menuItemId);
  }

  /**
   * Toggle favorites section expansion
   */
  toggleFavoritesSection(): void {
    this.favoritesExpanded = !this.favoritesExpanded;
  }

  /**
   * Navigate to a favorite item
   */
  onFavoriteNavigate(fav: FavoriteItem): void {
    this.router.navigate([fav.route]);
    if (this.isMobileViewport) {
      this.toggleSidebar();
    }
  }

  // ── Recent Items Methods ──

  /**
   * Record visit by matching route against the loaded menu tree
   */
  private recordVisitByRoute(route: string): void {
    if (!route || route === '/app/dashboard') return;

    const findItem = (items: MenuItem[]): MenuItem | undefined => {
      for (const item of items) {
        // Exact match or prefix with path separator
        if (item.route && (route === item.route || route.startsWith(item.route + '/'))) {
          return item;
        }
        if (item.children) {
          const found = findItem(item.children);
          if (found) return found;
        }
      }
      return undefined;
    };

    const item = findItem(this.mainMenu);
    if (item && item.route) {
      this.recentItemsService.recordVisit({
        id: item.id,
        label: item.label,
        icon: item.icon,
        route: item.route
      });
    }
  }

  /**
   * Navigate to a recent item
   */
  onRecentNavigate(recent: RecentItem): void {
    this.router.navigate([recent.route]);
    if (this.isMobileViewport) {
      this.toggleSidebar();
    }
  }

  /**
   * Remove a recent item by ID
   */
  removeRecent(event: MouseEvent, recentId: number): void {
    event.preventDefault();
    event.stopPropagation();
    this.recentItemsService.removeRecent(recentId);
  }

  /**
   * Toggle recent section expansion
   */
  toggleRecentSection(): void {
    this.recentExpanded = !this.recentExpanded;
  }

  /**
   * Clear all recent items
   */
  clearRecent(): void {
    this.recentItemsService.clearAll();
  }

  /**
   * Precompute the "time ago" label for each recent item into component state.
   * Called from stable ticks (recent$ emissions, 30s timer, route changes) so the
   * template never evaluates a time-dependent expression during change detection.
   * This is what eliminates NG0100 (ExpressionChangedAfterItHasBeenCheckedError).
   */
  rebuildRecentTimeLabels(): void {
    const now = Date.now();
    const labels: { [id: number]: string } = {};
    for (const item of this.recentItems) {
      labels[item.id] = this.computeRelativeTime(item.visitedAt, now);
    }
    this.recentTimeLabels = labels;
  }

  /**
   * Get the precomputed relative time label for a recent item
   */
  getRelativeTime(item: RecentItem): string {
    return this.recentTimeLabels[item.id] ?? '';
  }

  /**
   * Compute relative time from a snapshot `now` so repeated calls within the same
   * change-detection cycle always return the identical string.
   */
  private computeRelativeTime(timestamp: number, now: number): string {
    const diff = now - timestamp;
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);

    if (minutes < 1) return 'Just now';
    if (minutes < 60) return `${minutes}m ago`;
    if (hours < 24) return `${hours}h ago`;
    return `${days}d ago`;
  }

  /**
   * TrackBy function for ngFor optimization
   */
  trackByMenuId(index: number, item: MenuItem): number {
    return item.id;
  }

  trackByFavId(index: number, item: FavoriteItem): number {
    return item.id;
  }

  trackByRecentId(index: number, item: RecentItem): number {
    return item.id;
  }
}
