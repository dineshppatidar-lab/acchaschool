import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';

export interface StudentEnquiry {
  id: number;
  studentName: string;
  contactNo: string;
  email?: string | null;
  classInterestedIn?: string | null;
  source?: string | null;
  notes?: string | null;
  enquiryDate?: string | Date | null;
  status?: string | null;
  createdOn: string;
  createdBy?: string | null;
}

@Injectable({ providedIn: 'root' })
export class StudentEnquiryService {
  private apiUrl = `${environment.apiUrl}/api/studentenquiries`;

  constructor(private http: HttpClient) {}

  getEnquiries(search: string = ''): Observable<any> {
    const params = search ? { params: { search } } : {};
    return this.http.get<any>(this.apiUrl, params);
  }

  getEnquiry(id: number): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/${id}`);
  }

  createEnquiry(enquiry: Partial<StudentEnquiry>): Observable<any> {
    return this.http.post<any>(this.apiUrl, enquiry);
  }

  updateEnquiry(id: number, enquiry: Partial<StudentEnquiry>): Observable<any> {
    return this.http.put<any>(`${this.apiUrl}/${id}`, enquiry);
  }

  deleteEnquiry(id: number): Observable<any> {
    return this.http.delete<any>(`${this.apiUrl}/${id}`);
  }
}
