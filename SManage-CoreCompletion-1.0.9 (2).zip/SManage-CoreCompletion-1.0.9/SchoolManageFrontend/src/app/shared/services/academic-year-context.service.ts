import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { take } from 'rxjs/operators';
import { catchError, shareReplay, tap } from 'rxjs/operators';
import { environment } from '../../../environments/environment';

export interface AcademicYearItem {
  id: number;
  name: string;
  isActive?: boolean;
  isCurrent?: boolean;
  startYear?: number;
  endYear?: number;
  /** ISO date strings – needed by edit forms (e.g. Setup Wizard Session tab) */
  startDate?: string;
  endDate?: string;
}

const STORAGE_KEY = 'selectedAcademicYearId';

/**
 * Centralized Academic Year context service.
 *
 * Provides a single source of truth for the currently selected academic year
 * across the entire application. Components subscribe to `selectedAcademicYear$`
 * instead of loading their own year lists and picking defaults.
 *
 * Mirrors the existing TenantService pattern.
 */
@Injectable({ providedIn: 'root' })
export class AcademicYearContextService {
  private readonly apiUrl = `${environment.apiUrl}/api/setup/academic-years`;

  /** All available academic years (cached after first fetch) */
  private academicYearsSubject = new BehaviorSubject<AcademicYearItem[]>([]);
  academicYears$ = this.academicYearsSubject.asObservable();

  /** The currently selected year – persisted in localStorage */
  private selectedYearSubject = new BehaviorSubject<number | null>(null);
  selectedAcademicYear$ = this.selectedYearSubject.asObservable();

  private loaded = false;

  constructor(private http: HttpClient) {
    // Restore persisted selection
    const stored = (typeof window !== 'undefined' && window.localStorage)
      ? localStorage.getItem(STORAGE_KEY)
      : null;
    if (stored && !isNaN(+stored)) {
      this.selectedYearSubject.next(+stored);
    }
  }

  /**
   * Load academic years from the API (once).
   * If a year is already selected and present in the response, keep it.
   * Otherwise auto-select the current or first active year.
   */
  loadAcademicYears(): Observable<AcademicYearItem[]> {
    if (this.loaded && this.academicYearsSubject.value.length > 0) {
      // Emit the cached years once and COMPLETE. Returning the raw
      // BehaviorSubject stream left callers waiting forever for a completion
      // that never comes — forkJoin() consumers (e.g. the Examinations page)
      // never emitted and their spinners hung indefinitely.
      return this.academicYears$.pipe(take(1));
    }

    // In-flight request sharing: without this, every component calling
    // loadAcademicYears() during the same boot fires its own HTTP request, and an
    // erroring request cleared nothing — late subscribers hung on a spinner. The
    // shared observable guarantees one request per boot, caches the result for
    // late subscribers, and resets so a real failure can be retried.
    if (!this.inFlight$) {
      this.inFlight$ = this.fetchYears().pipe(
        shareReplay({ bufferSize: 1, refCount: false }),
        tap({ error: () => { this.inFlight$ = null; } })
      );
    }
    return this.inFlight$;
  }

  private inFlight$: Observable<AcademicYearItem[]> | null = null;

  private fetchYears(): Observable<AcademicYearItem[]> {
    return this.http.get<any[]>(this.apiUrl).pipe(
      tap((response: any) => {
        const data: any[] = Array.isArray(response) ? response : (response?.data ?? []);
        const years: AcademicYearItem[] = data.map((y: any) => ({
          id: y.id ?? y.Id,
          name: y.name ?? y.Name ?? `${y.startYear ?? y.start_year}-${y.endYear ?? y.end_year}`,
          isActive: y.isActive ?? y.is_active ?? true,
          isCurrent: y.isCurrent ?? y.is_current ?? false,
          startYear: y.startYear ?? y.start_year,
          endYear: y.endYear ?? y.end_year,
          // Preserve raw dates so consumers can bind datepickers when editing.
          startDate: y.startDate ?? y.StartDate,
          endDate: y.endDate ?? y.EndDate
        }));

        this.academicYearsSubject.next(years);
        this.loaded = true;
        this.inFlight$ = null;

        // Auto-select if nothing selected yet
        const current = this.selectedYearSubject.value;
        if (!current || !years.some(y => y.id === current)) {
          const preferred = years.find(y => y.isCurrent) ?? years.find(y => y.isActive) ?? years[0];
          if (preferred) {
            this.setYear(preferred.id);
          }
        }
      }),
      catchError(err => {
        console.error('Error loading academic years:', err);
        return of([]);
      })
    );
  }

  /** Select an academic year and persist the choice */
  setYear(yearId: number): void {
    this.selectedYearSubject.next(yearId);
    if (typeof window !== 'undefined' && window.localStorage) {
      localStorage.setItem(STORAGE_KEY, String(yearId));
    }
  }

  /** Get the current year synchronously */
  get selectedYearId(): number | null {
    return this.selectedYearSubject.value;
  }

  /** Get a snapshot of all years */
  get yearsSnapshot(): AcademicYearItem[] {
    return this.academicYearsSubject.value;
  }

  /** Force re-fetch from API (e.g. after failure or explicit refresh) */
  refreshAcademicYears(): Observable<AcademicYearItem[]> {
    this.loaded = false;
    this.inFlight$ = null;
    return this.loadAcademicYears();
  }

  /** Resolve the display name for a given year ID */
  getYearName(yearId: number): string {
    const year = this.academicYearsSubject.value.find(y => y.id === yearId);
    return year?.name ?? `Year ${yearId}`;
  }
}
