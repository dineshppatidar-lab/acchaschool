import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';

/**
 * Public-side shapes returned by /api/public-website (anonymous, host-resolved).
 */
export interface PublicBranding {
  matched: boolean;
  active: boolean;
  tenantCode: string | null;
  tenantName: string | null;
  logoUrl: string | null;
  tagline: string | null;
  websiteTitle: string | null;
  metaDescription: string | null;
  primaryColor: string | null;
  secondaryColor: string | null;
  faviconUrl: string | null;
  address: string | null;
  contactPhone: string | null;
  contactEmail: string | null;
  mapEmbedUrl: string | null;
  socialLinksJson: string | null;
  aboutHtml?: string | null;
  admissionsHtml?: string | null;
  isWebsitePublished: boolean;
  isEnquiryEnabled: boolean;
}

export interface PublicEvent {
  id: number; title: string; slug: string; excerpt?: string | null; descriptionHtml?: string | null;
  eventDate: string; endDate?: string | null; location?: string | null; coverImageUrl?: string | null;
}

export interface PublicAlbum {
  id: number; title: string; slug: string; descriptionHtml?: string | null; category?: string | null;
  eventDate?: string | null; coverImageUrl?: string | null;
}

export interface PublicAlbumMedia {
  id: number; filePath: string; thumbnailPath?: string | null; caption?: string | null; videoUrl?: string | null; displayOrder: number;
}

export interface PublicCatalogItem {
  id: number; title: string; slug?: string; category?: string | null;
  descriptionHtml?: string | null; imageUrl?: string | null; bodyHtml?: string | null;
  excerpt?: string | null; publishedOnUtc?: string | null; achievementDate?: string | null;
}

/** Unwraps `{ data: … }` API responses, tolerating raw payloads. */
function unwrap<T>(payload: unknown, fallback?: T): T {
  const obj = payload as Record<string, unknown> | null;
  if (obj && 'data' in obj && obj['data'] !== undefined && obj['data'] !== null) {
    return obj['data'] as T;
  }
  if (fallback !== undefined && payload === null) return fallback;
  return payload as T;
}

/**
 * School Website CMS client.
 *  - Admin side (/api/website-content): tenant-scoped, permission-guarded server-side.
 *  - Public side (/api/public-website): anonymous, host-resolved, published content only.
 */
@Injectable({ providedIn: 'root' })
export class WebsiteContentService {
  private readonly base = '/api/website-content';

  constructor(private http: HttpClient) {}

  // ── helpers ──
  private async getRaw<T>(url: string, params?: Record<string, string | number | boolean>): Promise<T> {
    const options = params ? { params: new HttpParams({ fromObject: Object.fromEntries(Object.entries(params).map(([, v]) => [String(v), String(v)])) }) } : {};
    return firstValueFrom(this.http.get<T>(url, options));
  }
  private async getData<T>(url: string, params?: Record<string, string | number | boolean>): Promise<T> {
    return unwrap<T>(await this.getRaw<T>(url, params));
  }
  private async postData<T>(url: string, body?: unknown): Promise<T> {
    return unwrap<T>(await firstValueFrom(this.http.post<T>(url, body ?? {})));
  }
  private async putData<T>(url: string, body?: unknown): Promise<T> {
    return unwrap<T>(await firstValueFrom(this.http.put<T>(url, body ?? {})));
  }
  private async deleteVoid(url: string): Promise<void> {
    await firstValueFrom(this.http.delete<unknown>(url));
  }

  // ── Settings ──
  getSettings(): Promise<Record<string, unknown>> {
    return this.getData(`${this.base}/settings`);
  }
  saveSettings(settings: unknown): Promise<Record<string, unknown>> {
    return this.putData(`${this.base}/settings`, settings);
  }

  // ── Media library ──
  uploadMedia(file: File, caption: string | null, altText: string | null): Promise<unknown> {
    const form = new FormData();
    form.append('file', file, file.name);
    if (caption) form.append('caption', caption);
    if (altText) form.append('altText', altText);
    return this.postData(`${this.base}/media`, form);
  }
  listMedia(page = 1, pageSize = 60): Promise<Record<string, unknown>[]> {
    return this.getData(`${this.base}/media`, { page, pageSize });
  }
  deleteMedia(id: number): Promise<void> {
    return this.deleteVoid(`${this.base}/media/${id}`);
  }

  // ── Events ──
  listEvents(published?: boolean): Promise<Record<string, unknown>[]> {
    return this.getData(`${this.base}/events`, published === undefined ? {} : { published });
  }
  upsertEvent(evt: unknown): Promise<Record<string, unknown>> {
    return this.postData(`${this.base}/events`, evt);
  }
  setEventPublished(id: number, published: boolean): Promise<void> {
    return this.deleteVoid('').then(() => this.putData(`${this.base}/events/${id}/publish`, { published }) as Promise<void>);
  }
  deleteEvent(id: number): Promise<void> {
    return this.deleteVoid(`${this.base}/events/${id}`);
  }

  // ── Albums ──
  listAlbums(published?: boolean): Promise<Record<string, unknown>[]> {
    return this.getData(`${this.base}/albums`, published === undefined ? {} : { published });
  }
  async getAlbum(id: number): Promise<{ album: Record<string, unknown> | null; media: Record<string, unknown>[] }> {
    const payload = await this.getRaw<Record<string, unknown>>(`${this.base}/albums/${id}`);
    const data = unwrap<Record<string, unknown>>(payload) as Record<string, unknown>;
    return {
      album: (data['Album'] ?? data['album'] ?? null) as Record<string, unknown> | null,
      media: ((data['Media'] ?? data['media'] ?? []) as Record<string, unknown>[])
    };
  }
  upsertAlbum(album: unknown, tryPublish = false): Promise<Record<string, unknown>> {
    return this.postData(`${this.base}/albums`, { album, tryPublish });
  }
  async setAlbumPublished(id: number, published: boolean): Promise<void> {
    await this.putData(`${this.base}/albums/${id}/publish`, { published });
  }
  deleteAlbum(id: number): Promise<void> {
    return this.deleteVoid(`${this.base}/albums/${id}`);
  }
  addAlbumMedia(albumId: number, file: File, opts: { caption?: string | null; altText?: string | null; videoUrl?: string | null; displayOrder?: number; }): Promise<unknown> {
    const form = new FormData();
    form.append('file', file, file.name);
    if (opts.caption) form.append('caption', opts.caption);
    if (opts.altText) form.append('altText', opts.altText);
    if (opts.videoUrl) form.append('videoUrl', opts.videoUrl);
    form.append('displayOrder', String(opts.displayOrder ?? 0));
    return this.postData(`${this.base}/albums/${albumId}/media`, form);
  }
  async reorderAlbumMedia(albumId: number, orderedMediaIds: number[]): Promise<void> {
    await this.putData(`${this.base}/albums/${albumId}/media/reorder`, { orderedMediaIds });
  }
  async updateAlbumMediaCaption(mediaId: number, caption: string | null, altText: string | null): Promise<void> {
    await this.putData(`${this.base}/album-media/${mediaId}`, { caption, altText });
  }
  deleteAlbumMedia(mediaId: number): Promise<void> {
    return this.deleteVoid(`${this.base}/album-media/${mediaId}`);
  }

  // ── Achievements ──
  listAchievements(published?: boolean): Promise<Record<string, unknown>[]> {
    return this.getData(`${this.base}/achievements`, published === undefined ? {} : { published });
  }
  upsertAchievement(a: unknown): Promise<Record<string, unknown>> {
    return this.postData(`${this.base}/achievements`, a);
  }
  async setAchievementPublished(id: number, published: boolean): Promise<void> {
    await this.putData(`${this.base}/achievements/${id}/publish`, { published });
  }
  deleteAchievement(id: number): Promise<void> {
    return this.deleteVoid(`${this.base}/achievements/${id}`);
  }

  // ── Articles ──
  listArticles(published?: boolean, category?: string | null, search?: string | null): Promise<Record<string, unknown>[]> {
    const params: Record<string, string | number | boolean> = {};
    if (published !== undefined) params['published'] = published;
    if (category) params['category'] = category;
    if (search) params['search'] = search;
    return this.getData(`${this.base}/articles`, params);
  }
  upsertArticle(a: unknown): Promise<Record<string, unknown>> {
    return this.postData(`${this.base}/articles`, a);
  }
  async setArticlePublished(id: number, published: boolean): Promise<void> {
    await this.putData(`${this.base}/articles/${id}/publish`, { published });
  }
  deleteArticle(id: number): Promise<void> {
    return this.deleteVoid(`${this.base}/articles/${id}`);
  }

  // ── Campaigns ──
  listCampaigns(position?: string | null): Promise<Record<string, unknown>[]> {
    return this.getData(`${this.base}/campaigns`, position ? { position } : {});
  }
  upsertCampaign(c: unknown): Promise<Record<string, unknown>> {
    return this.postData(`${this.base}/campaigns`, c);
  }
  async setCampaignStatus(id: number, status: string): Promise<void> {
    await this.putData(`${this.base}/campaigns/${id}/status`, { status });
  }
  deleteCampaign(id: number): Promise<void> {
    return this.deleteVoid(`${this.base}/campaigns/${id}`);
  }

  // ── Enquiries ──
  listEnquiries(status?: string | null): Promise<Record<string, unknown>[]> {
    return this.getData(`${this.base}/enquiries`, status ? { status } : {});
  }
  async updateEnquiry(id: number, status: string | null, staffNote: string | null): Promise<void> {
    await this.putData(`${this.base}/enquiries/${id}`, { status: status ?? undefined, staffNote });
  }
  convertEnquiry(id: number): Promise<void> {
    return this.postData(`${this.base}/enquiries/${id}/convert`, {}) as Promise<void>;
  }

  // ── Summary ──
  getSummary(): Promise<Record<string, number>> {
    return this.getData(`${this.base}/summary`);
  }

  // ── Public API (anonymous, /api/public-website — raw arrays / objects) ──
  async getPublicBranding(): Promise<PublicBranding | null> {
    const v = await firstValueFrom(this.http.get<PublicBranding>('/api/public-website/branding'));
    return v && v.matched ? v : null;
  }
  getPublicEvents(take = 0): Promise<PublicEvent[]> {
    return firstValueFrom(this.http.get<PublicEvent[]>('/api/public-website/events', take ? { params: new HttpParams().set('take', take) } : {}));
  }
  getPublicEvent(slug: string): Promise<PublicEvent | null> {
    return firstValueFrom(this.http.get<PublicEvent | null>(`/api/public-website/events/${slug}`));
  }
  getPublicAlbums(take = 0): Promise<PublicAlbum[]> {
    return firstValueFrom(this.http.get<PublicAlbum[]>('/api/public-website/albums', take ? { params: new HttpParams().set('take', take) } : {}));
  }
  getPublicAlbum(slug: string): Promise<{ album: PublicAlbum | null; media: PublicAlbumMedia[] }> {
    return firstValueFrom(this.http.get<{ album: PublicAlbum | null; media: PublicAlbumMedia[] }>(`/api/public-website/albums/${slug}`));
  }
  getPublicAchievements(homepageOnly?: boolean): Promise<PublicCatalogItem[]> {
    return firstValueFrom(this.http.get<PublicCatalogItem[]>('/api/public-website/achievements',
      homepageOnly === undefined ? {} : { params: new HttpParams().set('homepageOnly', homepageOnly) }));
  }
  getPublicArticles(category?: string | null, search?: string | null, page = 1, pageSize = 10): Promise<PublicCatalogItem[]> {
    let params = new HttpParams().set('page', page).set('pageSize', pageSize);
    if (category) params = params.set('category', category);
    if (search) params = params.set('search', search);
    return firstValueFrom(this.http.get<PublicCatalogItem[]>('/api/public-website/articles', { params }));
  }
  getPublicArticle(slug: string): Promise<PublicCatalogItem | null> {
    return firstValueFrom(this.http.get<PublicCatalogItem | null>(`/api/public-website/articles/${slug}`));
  }
  getPublicCampaigns(position?: string | null) {
    return firstValueFrom(this.http.get<unknown[]>('/api/public-website/campaigns',
      position ? { params: new HttpParams().set('position', position) } : {}));
  }
  getPublicCounts(): Promise<{ publishedAlbums: number; publishedEvents: number; publishedArticles: number; achievements: number }> {
    return firstValueFrom(this.http.get<{ publishedAlbums: number; publishedEvents: number; publishedArticles: number; achievements: number }>('/api/public-website/counts'));
  }
  async isEnquiryEnabled(): Promise<boolean> {
    const v = await firstValueFrom(this.http.get<{ enabled: boolean }>('/api/public-website/enquiry-status'));
    return v.enabled === true;
  }
  submitEnquiry(payload: { parentName: string; phone: string; email?: string | null; message?: string | null; classOfInterest?: string | null; sourcePath?: string | null }): Promise<unknown> {
    return firstValueFrom(this.http.post('/api/public-website/enquiry', payload));
  }
}
