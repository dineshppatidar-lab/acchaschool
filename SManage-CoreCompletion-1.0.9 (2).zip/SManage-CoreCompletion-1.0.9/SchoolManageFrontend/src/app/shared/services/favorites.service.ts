import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

const STORAGE_KEY = 'edusphere_favorites';
const MAX_FAVORITES = 8;

export interface FavoriteItem {
  id: number;
  label: string;
  icon: string;
  route: string;
  addedAt: number;
}

@Injectable({ providedIn: 'root' })
export class FavoritesService {
  private favoritesSubject = new BehaviorSubject<FavoriteItem[]>([]);
  public favorites$ = this.favoritesSubject.asObservable();

  constructor() {
    this.loadFavorites();
  }

  private loadFavorites(): void {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      const items: FavoriteItem[] = raw ? JSON.parse(raw) : [];
      this.favoritesSubject.next(items);
    } catch {
      this.favoritesSubject.next([]);
    }
  }

  private persist(items: FavoriteItem[]): void {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
    this.favoritesSubject.next(items);
  }

  /** Get current favorites snapshot */
  getFavorites(): FavoriteItem[] {
    return this.favoritesSubject.value;
  }

  /** Check if a menu item ID is favorited */
  isFavorite(menuItemId: number): boolean {
    return this.favoritesSubject.value.some(f => f.id === menuItemId);
  }

  /** Toggle a menu item as favorite/unfavorite */
  toggleFavorite(menuItem: { id: number; label: string; icon: string; route: string }): boolean {
    const current = this.favoritesSubject.value;
    const index = current.findIndex(f => f.id === menuItem.id);

    if (index >= 0) {
      // Remove from favorites
      current.splice(index, 1);
      this.persist([...current]);
      return false;
    } else {
      // Add to favorites (respect max limit)
      if (current.length >= MAX_FAVORITES) {
        // Remove oldest to make room
        current.shift();
      }
      const newItem: FavoriteItem = {
        ...menuItem,
        addedAt: Date.now()
      };
      this.persist([...current, newItem]);
      return true;
    }
  }

  /** Remove a specific item from favorites */
  removeFavorite(menuItemId: number): void {
    const current = this.favoritesSubject.value.filter(f => f.id !== menuItemId);
    this.persist(current);
  }

  /** Clear all favorites */
  clearAll(): void {
    this.persist([]);
  }
}
