import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { tap, shareReplay } from 'rxjs/operators';

/**
 * Cache strategy for HTTP responses
 * Stores responses with configurable TTL (time-to-live)
 */
export interface CacheEntry<T> {
  data: T;
  timestamp: number;
  ttl: number; // TTL in milliseconds
}

@Injectable({
  providedIn: 'root'
})
export class ApiCacheService {
  private cache = new Map<string, CacheEntry<any>>();
  private obsCache = new Map<string, Observable<any>>();

  /**
   * Get cached value if valid, else return null
   */
  get<T>(key: string): T | null {
    const entry = this.cache.get(key);
    
    if (!entry) return null;

    const now = Date.now();
    if (now - entry.timestamp > entry.ttl) {
      // Cache expired
      this.cache.delete(key);
      this.obsCache.delete(key);
      return null;
    }

    return entry.data as T;
  }

  /**
   * Set cache value with TTL
   */
  set<T>(key: string, data: T, ttlMs: number = 5 * 60 * 1000): void {
    this.cache.set(key, {
      data,
      timestamp: Date.now(),
      ttl: ttlMs
    });
  }

  /**
   * Cache an observable - reuse if multiple subscribers
   * Great for avoiding duplicate API calls
   */
  cacheObservable<T>(key: string, source$: Observable<T>, ttlMs: number = 5 * 60 * 1000): Observable<T> {
    // Return cached observable if exists and valid
    if (this.obsCache.has(key)) {
      return this.obsCache.get(key) as Observable<T>;
    }

    // Create new cached observable
    const cached$ = source$.pipe(
      tap(data => this.set(key, data, ttlMs)),
      shareReplay(1) // Cache and share result
    );

    this.obsCache.set(key, cached$);
    return cached$;
  }

  /**
   * Clear specific cache entry
   */
  clear(key: string): void {
    this.cache.delete(key);
    this.obsCache.delete(key);
  }

  /**
   * Clear all cache
   */
  clearAll(): void {
    this.cache.clear();
    this.obsCache.clear();
  }

  /**
   * Check if cache entry exists and is valid
   */
  exists(key: string): boolean {
    const entry = this.cache.get(key);
    if (!entry) return false;

    const now = Date.now();
    if (now - entry.timestamp > entry.ttl) {
      this.cache.delete(key);
      return false;
    }

    return true;
  }

  /**
   * Get cache statistics
   */
  getStats(): { keys: string[]; size: number } {
    return {
      keys: Array.from(this.cache.keys()),
      size: this.cache.size
    };
  }
}
