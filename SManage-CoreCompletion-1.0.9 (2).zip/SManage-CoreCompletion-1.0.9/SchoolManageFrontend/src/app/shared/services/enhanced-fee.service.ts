import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, tap } from 'rxjs/operators';
import { ApiCacheService } from './api-cache.service';
import { ApiErrorHandlerService } from './api-error-handler.service';

/**
 * Enhanced Fee Management Service
 * Wraps the base FeeManagementService with:
 * - Intelligent API caching
 * - Centralized error handling
 * - Loading state management
 * - Request deduplication
 */
@Injectable({
  providedIn: 'root'
})
export class EnhancedFeeService {
  private baseUrl = '/api/advancedfinance';
  private loadingStates = new Map<string, boolean>();

  constructor(
    private http: HttpClient,
    private cacheService: ApiCacheService,
    private errorHandler: ApiErrorHandlerService
  ) {}

  /**
   * Check if a specific API call is in progress
   */
  isLoading(key: string): boolean {
    return this.loadingStates.get(key) ?? false;
  }

  /**
   * Get fee rules with caching
   * Cache duration: 10 minutes (rules don't change frequently)
   */
  getFeeRules(ruleType?: number, forceRefresh = false): Observable<any> {
    const cacheKey = `fee-rules-${ruleType || 'all'}`;

    // Return cached if available and not force refresh
    if (!forceRefresh) {
      const cached = this.cacheService.get(cacheKey);
      if (cached) return new Observable(subscriber => {
        subscriber.next(cached);
        subscriber.complete();
      });
    }

    this.loadingStates.set(cacheKey, true);
    
    let url = `${this.baseUrl}/fee-rules`;
    if (ruleType) {
      url += `?ruleType=${ruleType}`;
    }

    return this.http.get(url).pipe(
      tap(data => {
        this.cacheService.set(cacheKey, data, 10 * 60 * 1000); // 10 min TTL
        this.loadingStates.set(cacheKey, false);
      }),
      catchError(error => this.handleError(error, cacheKey))
    );
  }

  /**
   * Get student ledger with caching
   * Cache duration: 5 minutes (may change frequently)
   */
  getStudentLedger(studentId: number, startDate?: string, endDate?: string, forceRefresh = false): Observable<any> {
    const cacheKey = `ledger-${studentId}-${startDate}-${endDate}`;

    if (!forceRefresh && this.cacheService.exists(cacheKey)) {
      const cached = this.cacheService.get(cacheKey);
      if (cached) return new Observable(subscriber => {
        subscriber.next(cached);
        subscriber.complete();
      });
    }

    this.loadingStates.set(cacheKey, true);

    let url = `${this.baseUrl}/students/${studentId}/ledger`;
    const params = new URLSearchParams();
    if (startDate) params.append('startDate', startDate);
    if (endDate) params.append('endDate', endDate);

    if (params.toString()) {
      url += `?${params.toString()}`;
    }

    return this.http.get(url).pipe(
      tap(data => {
        this.cacheService.set(cacheKey, data, 5 * 60 * 1000); // 5 min TTL
        this.loadingStates.set(cacheKey, false);
      }),
      catchError(error => this.handleError(error, cacheKey))
    );
  }

  /**
   * Process multi-installment payment
   * No caching - real-time operation
   */
  processMultiInstallmentPayment(request: any): Observable<any> {
    const cacheKey = 'multi-payment-' + Date.now();
    this.loadingStates.set(cacheKey, true);

    return this.http.post(`${this.baseUrl}/payments/multi-installment`, request).pipe(
      tap(() => this.loadingStates.set(cacheKey, false)),
      catchError(error => this.handleError(error, cacheKey))
    );
  }

  /**
   * Get defaulter list with optional caching
   * Cache duration: 15 minutes (relatively stable, background-updated)
   */
  getDefaulterList(page = 1, pageSize = 20, minDaysOverdue = 1, forceRefresh = false): Observable<any> {
    const cacheKey = `defaulters-p${page}-s${pageSize}-d${minDaysOverdue}`;

    if (!forceRefresh && this.cacheService.exists(cacheKey)) {
      const cached = this.cacheService.get(cacheKey);
      if (cached) return new Observable(subscriber => {
        subscriber.next(cached);
        subscriber.complete();
      });
    }

    this.loadingStates.set(cacheKey, true);

    const url = `${this.baseUrl}/analytics/defaulters?page=${page}&pageSize=${pageSize}&minDaysOverdue=${minDaysOverdue}`;

    return this.http.get(url).pipe(
      tap(data => {
        this.cacheService.set(cacheKey, data, 15 * 60 * 1000); // 15 min TTL
        this.loadingStates.set(cacheKey, false);
      }),
      catchError(error => this.handleError(error, cacheKey))
    );
  }

  /**
   * Get collection chart data
   * Cache duration: 30 minutes (analytics data)
   */
  getCollectionChartData(startDate?: string, endDate?: string, groupBy = 'daily'): Observable<any> {
    const cacheKey = `chart-${startDate}-${endDate}-${groupBy}`;

    if (this.cacheService.exists(cacheKey)) {
      const cached = this.cacheService.get(cacheKey);
      if (cached) return new Observable(subscriber => {
        subscriber.next(cached);
        subscriber.complete();
      });
    }

    this.loadingStates.set(cacheKey, true);

    let url = `${this.baseUrl}/analytics/collection-chart?groupBy=${groupBy}`;
    if (startDate) url += `&startDate=${startDate}`;
    if (endDate) url += `&endDate=${endDate}`;

    return this.http.get(url).pipe(
      tap(data => {
        this.cacheService.set(cacheKey, data, 30 * 60 * 1000); // 30 min TTL
        this.loadingStates.set(cacheKey, false);
      }),
      catchError(error => this.handleError(error, cacheKey))
    );
  }

  /**
   * Get dashboard KPIs
   * Cache duration: 10 minutes (should be relatively fresh)
   */
  getEnhancedDashboard(period = 'month', academicYearId?: number): Observable<any> {
    const cacheKey = `dashboard-${period}-${academicYearId || 'all'}`;

    if (this.cacheService.exists(cacheKey)) {
      const cached = this.cacheService.get(cacheKey);
      if (cached) return new Observable(subscriber => {
        subscriber.next(cached);
        subscriber.complete();
      });
    }

    this.loadingStates.set(cacheKey, true);

    let url = `${this.baseUrl}/analytics/dashboard?period=${period}`;
    if (academicYearId) url += `&academicYearId=${academicYearId}`;

    return this.http.get(url).pipe(
      tap(data => {
        this.cacheService.set(cacheKey, data, 10 * 60 * 1000); // 10 min TTL
        this.loadingStates.set(cacheKey, false);
      }),
      catchError(error => this.handleError(error, cacheKey))
    );
  }

  /**
   * Get finance audit log
   * Cache duration: 5 minutes (may change frequently)
   */
  getFinanceAuditLog(count = 50): Observable<any> {
    const cacheKey = `audit-log-${count}`;

    if (this.cacheService.exists(cacheKey)) {
      const cached = this.cacheService.get(cacheKey);
      if (cached) return new Observable(subscriber => {
        subscriber.next(cached);
        subscriber.complete();
      });
    }

    this.loadingStates.set(cacheKey, true);

    return this.http.get(`${this.baseUrl}/audit/finance-log?count=${count}`).pipe(
      tap(data => {
        this.cacheService.set(cacheKey, data, 5 * 60 * 1000); // 5 min TTL
        this.loadingStates.set(cacheKey, false);
      }),
      catchError(error => this.handleError(error, cacheKey))
    );
  }

  /**
   * Create fee rule - no caching (state-changing operation)
   */
  createFeeRule(rule: any): Observable<any> {
    const cacheKey = 'create-rule-' + Date.now();
    this.loadingStates.set(cacheKey, true);

    return this.http.post(`${this.baseUrl}/fee-rules`, rule).pipe(
      tap(() => {
        // Invalidate rule cache after create
        this.cacheService.clear('fee-rules-all');
        this.loadingStates.set(cacheKey, false);
      }),
      catchError(error => this.handleError(error, cacheKey))
    );
  }

  /**
   * Send due reminders - no caching
   */
  sendDueReminders(daysAhead = 7): Observable<any> {
    const cacheKey = 'send-reminders-' + Date.now();
    this.loadingStates.set(cacheKey, true);

    return this.http.post(`${this.baseUrl}/notifications/send-due-reminders`, { daysAhead }).pipe(
      tap(() => this.loadingStates.set(cacheKey, false)),
      catchError(error => this.handleError(error, cacheKey))
    );
  }

  /**
   * Invalidate specific cache
   */
  invalidateCache(pattern: string): void {
    const stats = this.cacheService.getStats();
    stats.keys
      .filter(key => key.includes(pattern))
      .forEach(key => this.cacheService.clear(key));
  }

  /**
   * Clear all caches
   */
  clearAllCache(): void {
    this.cacheService.clearAll();
  }

  /**
   * Centralized error handling
   */
  private handleError(error: any, cacheKey: string): Observable<never> {
    this.loadingStates.set(cacheKey, false);

    if (error instanceof HttpErrorResponse) {
      const errorInfo = this.errorHandler.handleHttpError(error);
      return throwError(() => errorInfo);
    }

    return throwError(() => error);
  }
}
