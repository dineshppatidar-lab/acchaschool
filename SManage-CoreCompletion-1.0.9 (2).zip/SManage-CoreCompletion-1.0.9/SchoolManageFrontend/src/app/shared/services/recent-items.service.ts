import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

const STORAGE_KEY = 'edusphere_recent_items';
const MAX_RECENT = 8;

export interface RecentItem {
  id: number;
  label: string;
  icon: string;
  route: string;
  visitedAt: number;
}

@Injectable({ providedIn: 'root' })
export class RecentItemsService {
  private recentSubject = new BehaviorSubject<RecentItem[]>([]);
  public recent$ = this.recentSubject.asObservable();

  constructor() {
    this.loadRecent();
  }

  private loadRecent(): void {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      const items: RecentItem[] = raw ? JSON.parse(raw) : [];
      this.recentSubject.next(items);
    } catch {
      this.recentSubject.next([]);
    }
  }

  private persist(items: RecentItem[]): void {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
    this.recentSubject.next(items);
  }

  /** Get current recent items snapshot */
  getRecent(): RecentItem[] {
    return this.recentSubject.value;
  }

  /** Record a navigation visit */
  recordVisit(menuItem: { id: number; label: string; icon: string; route: string }): void {
    if (!menuItem.route) return;

    const current = this.recentSubject.value;

    // Remove if already exists (to move it to the top)
    const filtered = current.filter(item => item.id !== menuItem.id);

    // Add new item at the beginning
    const newItem: RecentItem = {
      ...menuItem,
      visitedAt: Date.now()
    };

    // Respect max limit
    const updated = [newItem, ...filtered].slice(0, MAX_RECENT);
    this.persist(updated);
  }

  /** Remove a specific item from recent */
  removeRecent(menuItemId: number): void {
    const current = this.recentSubject.value.filter(item => item.id !== menuItemId);
    this.persist(current);
  }

  /** Clear all recent items */
  clearAll(): void {
    this.persist([]);
  }
}
