import { Injectable } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';

/**
 * Error information structure
 */
export interface ErrorInfo {
  code: string;
  message: string;
  details?: string;
  statusCode: number;
  timestamp: Date;
  type: 'api' | 'network' | 'validation' | 'unknown';
}

/**
 * API Error handling service
 * Provides centralized error processing, logging, and user notifications
 */
@Injectable({
  providedIn: 'root'
})
export class ApiErrorHandlerService {
  private errorSubject$ = new BehaviorSubject<ErrorInfo | null>(null);
  public error$: Observable<ErrorInfo | null> = this.errorSubject$.asObservable();

  constructor() {}

  /**
   * Handle HTTP errors from API calls
   * Returns user-friendly error message and logs details
   */
  handleHttpError(error: HttpErrorResponse): ErrorInfo {
    let errorInfo: ErrorInfo;

    if (error.status === 0) {
      // Network error
      errorInfo = {
        code: 'NETWORK_ERROR',
        message: 'Network connection error. Please check your internet connection.',
        statusCode: 0,
        timestamp: new Date(),
        type: 'network'
      };
    } else if (error.status === 400) {
      // Bad request - validation error
      const errorData = error.error as any;
      errorInfo = {
        code: errorData?.code || 'VALIDATION_ERROR',
        message: errorData?.message || 'Invalid request. Please check your input.',
        details: errorData?.details,
        statusCode: 400,
        timestamp: new Date(),
        type: 'validation'
      };
    } else if (error.status === 401) {
      // Unauthorized
      errorInfo = {
        code: 'UNAUTHORIZED',
        message: 'Your session has expired. Please log in again.',
        statusCode: 401,
        timestamp: new Date(),
        type: 'api'
      };
    } else if (error.status === 403) {
      // Forbidden
      errorInfo = {
        code: 'FORBIDDEN',
        message: 'You do not have permission to perform this action.',
        statusCode: 403,
        timestamp: new Date(),
        type: 'api'
      };
    } else if (error.status === 404) {
      // Not found
      errorInfo = {
        code: 'NOT_FOUND',
        message: 'The requested resource was not found.',
        statusCode: 404,
        timestamp: new Date(),
        type: 'api'
      };
    } else if (error.status === 409) {
      // Conflict
      const errorData = error.error as any;
      errorInfo = {
        code: 'CONFLICT',
        message: errorData?.message || 'The request conflicts with existing data.',
        details: errorData?.details,
        statusCode: 409,
        timestamp: new Date(),
        type: 'api'
      };
    } else if (error.status === 422) {
      // Unprocessable entity
      const errorData = error.error as any;
      errorInfo = {
        code: 'UNPROCESSABLE_ENTITY',
        message: errorData?.message || 'Unable to process the request.',
        details: errorData?.details,
        statusCode: 422,
        timestamp: new Date(),
        type: 'validation'
      };
    } else if (error.status >= 500) {
      // Server error
      errorInfo = {
        code: 'SERVER_ERROR',
        message: 'Server error. Please try again later.',
        details: error.statusText,
        statusCode: error.status,
        timestamp: new Date(),
        type: 'api'
      };
    } else {
      // Unknown error
      errorInfo = {
        code: 'UNKNOWN_ERROR',
        message: 'An unexpected error occurred.',
        details: error.message,
        statusCode: error.status,
        timestamp: new Date(),
        type: 'unknown'
      };
    }

    // Log error
    this.logError(errorInfo);

    // Broadcast error
    this.errorSubject$.next(errorInfo);

    return errorInfo;
  }

  /**
   * Handle client-side validation errors
   */
  handleValidationError(message: string, details?: string): ErrorInfo {
    const errorInfo: ErrorInfo = {
      code: 'VALIDATION_ERROR',
      message,
      details,
      statusCode: 400,
      timestamp: new Date(),
      type: 'validation'
    };

    this.logError(errorInfo);
    this.errorSubject$.next(errorInfo);
    return errorInfo;
  }

  /**
   * Log error to console (in development)
   * Can be extended to send to error tracking service
   */
  private logError(error: ErrorInfo): void {
    const logMessage = `[${error.type.toUpperCase()}] ${error.code}: ${error.message}`;
    
    if (error.details) {
      console.error(logMessage, error.details);
    } else {
      console.error(logMessage);
    }

    // TODO: Send to error tracking service (Sentry, LogRocket, etc.)
    // this.errorTrackingService.captureException(error);
  }

  /**
   * Clear current error
   */
  clearError(): void {
    this.errorSubject$.next(null);
  }

  /**
   * Get user-friendly message for error code
   */
  getUserMessage(code: string): string {
    const messages: { [key: string]: string } = {
      'NETWORK_ERROR': 'Network connection error. Please check your internet and try again.',
      'UNAUTHORIZED': 'Your session has expired. Please log in again.',
      'FORBIDDEN': 'You don\'t have permission to perform this action.',
      'NOT_FOUND': 'The requested resource was not found.',
      'CONFLICT': 'This action conflicts with existing data. Please refresh and try again.',
      'VALIDATION_ERROR': 'Please check your input and try again.',
      'UNPROCESSABLE_ENTITY': 'Unable to process your request. Please verify the data.',
      'SERVER_ERROR': 'Server error. Our team has been notified. Please try again later.',
      'UNKNOWN_ERROR': 'An unexpected error occurred. Please try again.'
    };

    return messages[code] || 'An error occurred. Please try again.';
  }

  /**
   * Check if error requires user to re-authenticate
   */
  isAuthError(error: ErrorInfo): boolean {
    return error.statusCode === 401 || error.code === 'UNAUTHORIZED';
  }

  /**
   * Check if error is retryable
   */
  isRetryable(error: ErrorInfo): boolean {
    // Retry on network errors and server errors (5xx)
    return error.type === 'network' || error.statusCode >= 500;
  }
}
