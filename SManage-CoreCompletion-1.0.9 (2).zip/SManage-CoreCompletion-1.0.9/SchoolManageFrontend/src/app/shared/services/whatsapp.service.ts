import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { environment } from '../../../environments/environment';

// ── Models ───────────────────────────────────────────────────────────

export interface WhatsAppConfig {
  id: number;
  isEnabled: boolean;
  provider: string;
  apiBaseUrl: string;
  apiVersion: string;
  businessAccountId?: string;
  phoneNumberId?: string;
  accessToken?: string;        // write-only
  accessTokenMask?: string;    // read-only
  senderNumber?: string;

  // Arattai (only used when provider === 'Arattai')
  arattaiOauthRedirectUri?: string;
  arattaiCompanyId?: string;
  arattaiBusinessNumberId?: string;
  arattaiRefreshToken?: string;      // write-only
  arattaiRefreshTokenMask?: string;  // read-only

  webhookVerifyToken?: string; // write-only
  webhookVerifyTokenMask?: string;
  webhookSecret?: string;      // write-only
  webhookSecretMask?: string;
  defaultLanguageCode: string;
  defaultCountryCode: string;
  requestTimeoutSeconds: number;
  maxRetryAttempts: number;
  retryDelayMinutes: number;
  rateLimitPerMinute: number;
  enableLogging: boolean;
  testMode: boolean;
  paymentLinkBaseUrl?: string;
  schoolNameOverride?: string;
  schoolPhone?: string;
  schoolEmail?: string;
  lastTestedOn?: string;
  lastTestStatus?: string;
  lastTestMessage?: string;
}

export interface WhatsAppTemplate {
  id: number;
  name: string;
  messageType: string;
  languageCode: string;
  providerTemplateName?: string;
  providerTemplateId?: string;   // Arattai template ID (sends by ID, not name)
  bodyText: string;
  isApproved: boolean;
  isActive: boolean;
  description?: string;
}

export interface WhatsAppReminderRule {
  id: number;
  name: string;
  templateId: number;
  templateName?: string;
  isEnabled: boolean;
  offsetType: 'BeforeDueDate' | 'OnDueDate' | 'AfterDueDate';
  offsetDays: number;
  sendTime: string;
  targetAcademicYearId?: number;
  targetClassId?: number;
  targetSectionId?: number;
  minOutstandingAmount: number;
  lastRunOn?: string;
}

export interface WhatsAppRecipient {
  studentId: number;
  studentName: string;
  className: string;
  sectionName: string;
  rollNumber: string;
  parentId?: number;
  parentName: string;
  rawPhoneNumber?: string;
  normalizedNumber?: string;
  isValidNumber: boolean;
  installmentName: string;
  feeInstallmentId?: number;
  dueDate?: string;
  outstandingAmount: number;
  totalFee: number;
  paidAmount: number;
}

export interface WhatsAppBulkSendResult {
  requested: number;
  queued: number;
  skippedInvalidNumber: number;
  skippedDuplicate: number;
  skippedReasons: string[];
}

export interface WhatsAppHistoryItem {
  id: number;
  studentId: number;
  studentName: string;
  recipientName: string;
  recipientNumber: string;
  messageType: string;
  provider?: string;
  channel?: string;   // "WhatsApp" | "Arattai"
  templateName?: string;
  trigger: string;
  status: string;
  failureReason?: string;
  providerMessageId?: string;
  retryCount: number;
  outstandingAmount?: number;
  dueDate?: string;
  sentAt?: string;
  deliveredAt?: string;
  readAt?: string;
  isTestMode: boolean;
  createdOn: string;
}

interface ApiResponse<T> {
  success: boolean;
  message: string;
  data: T;
}

// ── Service ──────────────────────────────────────────────────────────

@Injectable({ providedIn: 'root' })
export class WhatsAppService {
  private readonly baseUrl = `${environment.apiUrl}/api/WhatsApp`;

  constructor(private http: HttpClient) {}

  // Configuration
  getConfig(): Observable<WhatsAppConfig> {
    return this.http.get<ApiResponse<WhatsAppConfig>>(`${this.baseUrl}/config`)
      .pipe(map(r => r.data), catchError(this.handleError));
  }

  saveConfig(config: WhatsAppConfig, accessToken?: string, webhookVerifyToken?: string, webhookSecret?: string, arattaiRefreshToken?: string): Observable<WhatsAppConfig> {
    return this.http.post<ApiResponse<WhatsAppConfig>>(`${this.baseUrl}/config`, {
      config,
      accessToken,
      webhookVerifyToken,
      webhookSecret,
      arattaiRefreshToken
    }).pipe(map(r => r.data), catchError(this.handleError));
  }

  testConnection(): Observable<{ success: boolean; errorMessage?: string }> {
    return this.http.post<ApiResponse<{ success: boolean; errorMessage?: string }>>(`${this.baseUrl}/config/test`, {})
      .pipe(map(r => r.data), catchError(this.handleError));
  }

  sendTestMessage(phoneNumber: string): Observable<{ success: boolean; errorMessage?: string }> {
    return this.http.post<ApiResponse<{ success: boolean; errorMessage?: string }>>(`${this.baseUrl}/config/test-message`, { phoneNumber })
      .pipe(map(r => r.data), catchError(this.handleError));
  }

  // Templates
  getTemplates(): Observable<WhatsAppTemplate[]> {
    return this.http.get<ApiResponse<WhatsAppTemplate[]>>(`${this.baseUrl}/templates`)
      .pipe(map(r => r.data ?? []), catchError(this.handleError));
  }

  saveTemplate(template: WhatsAppTemplate): Observable<WhatsAppTemplate> {
    return this.http.post<ApiResponse<WhatsAppTemplate>>(`${this.baseUrl}/templates`, template)
      .pipe(map(r => r.data), catchError(this.handleError));
  }

  deleteTemplate(id: number): Observable<void> {
    return this.http.delete<ApiResponse<void>>(`${this.baseUrl}/templates/${id}`)
      .pipe(map(() => undefined), catchError(this.handleError));
  }

  // Reminder rules
  getReminderRules(): Observable<WhatsAppReminderRule[]> {
    return this.http.get<ApiResponse<WhatsAppReminderRule[]>>(`${this.baseUrl}/reminder-rules`)
      .pipe(map(r => r.data ?? []), catchError(this.handleError));
  }

  saveRule(rule: WhatsAppReminderRule): Observable<WhatsAppReminderRule> {
    return this.http.post<ApiResponse<WhatsAppReminderRule>>(`${this.baseUrl}/reminder-rules`, rule)
      .pipe(map(r => r.data), catchError(this.handleError));
  }

  deleteRule(id: number): Observable<void> {
    return this.http.delete<ApiResponse<void>>(`${this.baseUrl}/reminder-rules/${id}`)
      .pipe(map(() => undefined), catchError(this.handleError));
  }

  runAutomationNow(): Observable<number> {
    return this.http.post<ApiResponse<number>>(`${this.baseUrl}/automation/run`, {})
      .pipe(map(r => r.data), catchError(this.handleError));
  }

  // Recipients / sending
  previewRecipients(filters: {
    academicYearId?: number; classId?: number; sectionId?: number; studentId?: number;
    overdueStatus?: string; minOutstanding?: number; installmentId?: number; templateId?: number;
  }): Observable<WhatsAppRecipient[]> {
    return this.http.post<ApiResponse<WhatsAppRecipient[]>>(`${this.baseUrl}/recipients/preview`, filters)
      .pipe(map(r => r.data ?? []), catchError(this.handleError));
  }

  sendBulk(studentIds: number[], templateId: number, trigger: string = 'Manual'): Observable<WhatsAppBulkSendResult> {
    return this.http.post<ApiResponse<WhatsAppBulkSendResult>>(`${this.baseUrl}/send/bulk`, {
      studentIds, templateId, trigger
    }).pipe(map(r => r.data), catchError(this.handleError));
  }

  // Retry a failed/cancelled individual message (admin action).
  retryFailed(messageId: number): Observable<{ success: boolean; errorMessage?: string }> {
    return this.http.post<ApiResponse<{ success: boolean; errorMessage?: string }>>(`${this.baseUrl}/history/${messageId}/retry`, {})
      .pipe(map(r => r.data), catchError(this.handleError));
  }

  // History
  getHistory(page = 1, pageSize = 25, filters?: { studentId?: number; status?: string; trigger?: string })
    : Observable<{ items: WhatsAppHistoryItem[]; total: number; page: number; pageSize: number }> {
    const params: any = { page, pageSize };
    if (filters?.studentId) params.studentId = filters.studentId;
    if (filters?.status) params.status = filters.status;
    if (filters?.trigger) params.trigger = filters.trigger;
    return this.http.get<ApiResponse<{ items: WhatsAppHistoryItem[]; total: number; page: number; pageSize: number }>>(
      `${this.baseUrl}/history`, { params })
      .pipe(map(r => r.data), catchError(this.handleError));
  }

  private handleError(error: HttpErrorResponse) {
    const message = error.error?.message || error.message || 'An unexpected WhatsApp service error occurred';
    return throwError(() => new Error(message));
  }
}
