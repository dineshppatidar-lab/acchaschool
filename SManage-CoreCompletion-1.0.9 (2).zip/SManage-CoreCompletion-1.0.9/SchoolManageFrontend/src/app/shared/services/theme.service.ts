import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

const STORAGE_KEY = 'edusphere_theme';
/** Legacy key written by the old Topbar toggle — migrated on first run. */
const LEGACY_STORAGE_KEY = 'theme';

export type ThemeMode = 'light' | 'dark';

@Injectable({ providedIn: 'root' })
export class ThemeService {
  private themeSubject = new BehaviorSubject<ThemeMode>(this.getInitialTheme());
  public theme$ = this.themeSubject.asObservable();

  private darkThemeColor = '#0F1115';
  private lightThemeColor = '#00288E';

  constructor() {
    this.applyTheme(this.themeSubject.value);
  }

  private getInitialTheme(): ThemeMode {
    try {
      const stored = localStorage.getItem(STORAGE_KEY) as ThemeMode | null;
      if (stored === 'dark' || stored === 'light') return stored;

      // Inherit the choice made through the legacy Topbar toggle so users
      // who already picked a theme before the keys were unified keep it.
      const legacy = localStorage.getItem(LEGACY_STORAGE_KEY) as ThemeMode | null;
      if (legacy === 'dark' || legacy === 'light') {
        localStorage.setItem(STORAGE_KEY, legacy);
        localStorage.removeItem(LEGACY_STORAGE_KEY);
        return legacy;
      }

      // Respect system preference
      if (typeof window !== 'undefined' && window.matchMedia) {
        return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
      }
    } catch { /* ignore */ }
    return 'light';
  }

  get currentTheme(): ThemeMode {
    return this.themeSubject.value;
  }

  get isDark(): boolean {
    return this.themeSubject.value === 'dark';
  }

  toggleTheme(): void {
    const next = this.themeSubject.value === 'dark' ? 'light' : 'dark';
    this.setTheme(next);
  }

  setTheme(theme: ThemeMode): void {
    const normalized: ThemeMode = theme === 'dark' ? 'dark' : 'light';
    this.themeSubject.next(normalized);
    try {
      localStorage.setItem(STORAGE_KEY, normalized);
      // Keep the legacy key in sync so any leftover readers stay correct.
      localStorage.setItem(LEGACY_STORAGE_KEY, normalized);
    } catch { /* ignore */ }
    this.applyTheme(normalized);
  }

  private applyTheme(theme: ThemeMode): void {
    if (typeof document === 'undefined') return;
    document.documentElement.setAttribute('data-theme', theme);
    document.body.classList.toggle('dark-theme', theme === 'dark');
    document.body.classList.toggle('light-theme', theme === 'light');
    this.updateThemeColorMeta(theme);
  }

  /** Keeps the browser chrome (mobile address bar) in sync with the theme. */
  private updateThemeColorMeta(theme: ThemeMode): void {
    const meta = document.querySelector<HTMLMetaElement>('meta[name="theme-color"]');
    if (meta) {
      meta.setAttribute('content', theme === 'dark' ? this.darkThemeColor : this.lightThemeColor);
    }
  }
}
