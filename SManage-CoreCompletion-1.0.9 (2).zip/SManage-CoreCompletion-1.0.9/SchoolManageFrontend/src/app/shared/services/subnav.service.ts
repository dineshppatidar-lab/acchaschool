import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import type { SubnavItem } from '../subnav/top-subnav.component';

@Injectable({ providedIn: 'root' })
export class SubnavService {
  private _visible$ = new BehaviorSubject<boolean>(false);
  private _title$ = new BehaviorSubject<string>('');
  private _items$ = new BehaviorSubject<SubnavItem[]>([]);

  visible$ = this._visible$.asObservable();
  title$ = this._title$.asObservable();
  items$ = this._items$.asObservable();

  show(title: string, items: SubnavItem[]) {
    this._title$.next(title);
    this._items$.next(items);
    this._visible$.next(true);
  }

  hide() {
    this._visible$.next(false);
  }

  setActiveByRoute(route: string) {
    const items = this._items$.value;
    if (!items || items.length === 0) {
      return;
    }
    // Normalize route (remove trailing slash, ignore query/hash)
    const clean = (r: string) => r.split('?')[0].split('#')[0].replace(/\/$/, '');
    const current = clean(route || '');

    // Pick the single best match: exact match first, else the longest prefix at segment boundary
    let bestIndex: number | null = null;
    let bestLen = -1;
    items.forEach((it, idx) => {
      if (!it.route) return;
      const r = clean(it.route);
      if (!r) return;
      const exact = current === r;
      const boundaryPrefix = current === r || current.startsWith(r + '/');
      if (exact || boundaryPrefix) {
        const len = r.length;
        if (len > bestLen) {
          bestLen = len;
          bestIndex = idx;
        }
      }
    });

    const next = items.map((it, idx) => ({ ...it, active: bestIndex !== null && idx === bestIndex }));
    this._items$.next(next);
  }
}
