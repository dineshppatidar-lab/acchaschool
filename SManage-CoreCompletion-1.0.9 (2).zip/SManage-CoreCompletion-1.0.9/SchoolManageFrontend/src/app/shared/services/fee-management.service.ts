import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';

export interface AssignFeeRequest {
  feeStructureId: number;
  remarks?: string;
}

export interface DueInstallmentDto {
  installmentId: number;
  name: string;
  amount: number;
  paidAmount: number;
  dueDate: Date;
  status: string;
  daysOverdue: number;
}

export interface OutstandingFeesDto {
  studentId: number;
  hasAssignedFees: boolean;
  totalFees: number;
  paidAmount: number;
  outstandingAmount: number;
  dueInstallments: DueInstallmentDto[];
}

export interface StudentFeeAssignment {
  id?: number;
  studentId: number;
  feeStructureId: number;
  isActive?: boolean;
  remarks?: string;
}

export interface FeeStructure {
  id?: number;
  name: string;
  classId: number;
  academicYearId: number;
  annualFee?: number;
  registrationFee?: number;
  transportFee?: number;
  uniformFee?: number;
  examinationFee?: number;
  libraryFee?: number;
  computerFee?: number;
  laboratoryFee?: number;
  sportsFee?: number;
  miscellaneousFee?: number;
  isActive?: boolean;
  installments?: FeeInstallment[];
}

export interface FeeInstallment {
  id: number;
  name: string;
  amount: number;
  dueDate: Date;
  lateFee?: number;
  gracePeriodDays?: number;
  isActive: boolean;
}

@Injectable({
  providedIn: 'root'
})
export class FeeManagementService {
  private apiUrl = `${environment.apiUrl}/api/advancedfinance`;

  constructor(private http: HttpClient) {}

  /**
   * Assign a fee structure to a student during admission (overloaded version matching workflow)
   * @param studentIdOrRequest Student ID OR Assignment request object
   * @param request Assignment request (optional if first param is request)
   * @returns Observable with assigned fee assignment
   */
  assignFeeStructureToStudent(studentIdOrRequest: number | any, request?: AssignFeeRequest): Observable<any> {
    if (typeof studentIdOrRequest === 'number' && request) {
      // Old signature: assignFeeStructureToStudent(studentId, request)
      console.log(`🔗 Assigning fee structure to student ${studentIdOrRequest}`, request);
      return this.http.post<any>(`${this.apiUrl}/students/${studentIdOrRequest}/assign-fees`, request);
    } else {
      // New signature: assignFeeStructureToStudent(request)
      const req = studentIdOrRequest;
      console.log(`🔗 Assigning fee structure`, req);
      return this.http.post<any>(`${this.apiUrl}/students/${req.studentId}/assign-fees`, req);
    }
  }

  /**
   * Get outstanding fees for a specific student
   * @param studentId Student ID
   * @returns Observable with outstanding fees details  
   */
  getOutstandingFees(studentId: number): Observable<any> {
    console.log(`💰 Fetching outstanding fees for student ${studentId}`);
    return this.http.get<any>(`${this.apiUrl}/students/${studentId}/outstanding-fees`);
  }

  /**
   * Get fee structures for a specific class
   * @param classId Class ID (optional)
   * @param academicYearId Academic Year ID (optional)
   * @returns Observable with fee structures
   */
  getFeeStructures(classId?: number, academicYearId?: number): Observable<any> {
    let url = `${this.apiUrl}/fee-structures`;
    const params: any = {};
    
    if (classId) params.classId = classId;
    if (academicYearId) params.academicYearId = academicYearId;

    console.log(`📋 Fetching fee structures`, params);
    return this.http.get<any>(url, { params });
  }

  /**
   * Get fee installments for a student with payment status
   * @param studentId Student ID
   * @param feeStructureId Fee structure ID (optional)
   * @returns Observable with fee installments including payment details
   */
  getStudentFeeInstallments(studentId: number, feeStructureId?: number): Observable<any> {
    console.log(`📅 Fetching fee installments for student ${studentId}`);
    let url = `${this.apiUrl}/students/${studentId}/fee-installments`;
    if (feeStructureId) {
      url += `?feeStructureId=${feeStructureId}`;
    }
    return this.http.get<any>(url);
  }

  /**
   * Get all fee structures (without class filter)
   * @returns Observable with all active fee structures
   */
  getAllFeeStructures(): Observable<any> {
    console.log(`📚 Fetching all fee structures`);
    return this.http.get<any>(`${this.apiUrl}/fee-structures`);
  }

  /**
   * Create a new fee structure
   * @param feeStructure Fee structure data
   * @returns Observable with newly created fee structure
   */
  createFeeStructure(feeStructure: FeeStructure): Observable<any> {
    console.log(`✅ Creating new fee structure`, feeStructure);
    return this.http.post<any>(`${this.apiUrl}/fee-structures`, feeStructure);
  }

  /**
   * Update an existing fee structure
   * @param feeStructureId Fee structure ID
   * @param feeStructure Updated fee structure data
   * @returns Observable with updated fee structure
   */
  updateFeeStructure(feeStructureId: number, feeStructure: FeeStructure): Observable<any> {
    console.log(`📝 Updating fee structure ${feeStructureId} via setup endpoint`, feeStructure);
    // Use setup service endpoint which expects a CreateFeeStructureRequest shape
    const url = `${environment.apiUrl}/api/setup/fees/structure/setup`;
    const body: any = {
      Id: feeStructureId,
      Name: feeStructure.name,
      ClassId: feeStructure.classId ?? (feeStructure as any).ClassId,
      AcademicYearId: feeStructure.academicYearId ?? (feeStructure as any).AcademicYearId,
      AnnualFee: feeStructure.annualFee ?? 0,
      RegistrationFee: feeStructure.registrationFee ?? 0,
      TransportFee: feeStructure.transportFee ?? 0,
      UniformFee: feeStructure.uniformFee ?? 0,
      ExaminationFee: feeStructure.examinationFee ?? 0,
      LibraryFee: feeStructure.libraryFee ?? 0,
      ComputerFee: feeStructure.computerFee ?? 0,
      LaboratoryFee: feeStructure.laboratoryFee ?? 0,
      SportsFee: feeStructure.sportsFee ?? 0,
      MiscellaneousFee: feeStructure.miscellaneousFee ?? 0,
      Installments: (feeStructure.installments || []).map(inst => ({
        Id: (inst as any).id ?? (inst as any).Id ?? 0,  // existing row id (0 = new)
        Name: (inst as any).name || (inst as any).Name,
        Amount: (inst as any).amount ?? (inst as any).Amount,
        DueDate: (inst as any).dueDate ?? (inst as any).DueDate,
        LateFee: (inst as any).lateFee ?? (inst as any).LateFee,
        GracePeriodDays: (inst as any).gracePeriodDays ?? (inst as any).GracePeriodDays ?? 0
      }))
    };

    return this.http.post<any>(url, body);
  }

  /**
   * Delete a fee structure
   * @param feeStructureId Fee structure ID
   * @returns Observable with deletion result
   */
  deleteFeeStructure(feeStructureId: number): Observable<any> {
    console.log(`🗑️ Deleting fee structure ${feeStructureId}`);
    return this.http.delete<any>(`${this.apiUrl}/fee-structures/${feeStructureId}`);
  }

  /**
   * Get student installments (alias for getStudentFeeInstallments)
   * @param studentId Student ID
   * @returns Observable with fee installments
   */
  getStudentInstallments(studentId: number): Observable<any> {
    return this.getStudentFeeInstallments(studentId);
  }

  /**
   * Process installment payment
   * @param paymentRequest Payment request data
   * @returns Observable with payment result
   */
  processInstallmentPayment(paymentRequest: any): Observable<any> {
    console.log(`💳 Processing installment payment`, paymentRequest);
    return this.http.post<any>(`${this.apiUrl}/payments`, paymentRequest);
  }

  /**
   * Get fee structures for workflow
   * @returns Observable with all active fee structures
   */
  getFeeStructuresForWorkflow(): Observable<any> {
    console.log(`📚 Fetching fee structures for workflow`);
    return this.http.get<any>(`${this.apiUrl}/fee-structures?isActive=true`);
  }

  /**
   * Get students for fee assignment
   * @returns Observable with list of students
   */
  getStudentsForFeeAssignment(): Observable<any> {
    console.log(`👥 Fetching students for fee assignment`);
    return this.http.get<any>(`${this.apiUrl}/students/available-for-fees`);
  }

  /**
   * Get students assigned to a specific fee structure
   * @param feeStructureId Fee structure ID
   * @returns Observable with assigned students
   */
  getStudentsAssignedToStructure(feeStructureId: number): Observable<any> {
    console.log(`👥 Fetching students assigned to structure ${feeStructureId}`);
    return this.http.get<any>(`${this.apiUrl}/fee-structures/${feeStructureId}/assigned-students`);
  }

  /**
   * Process payment for a fee installment
   * @param paymentData Payment data including amount, method, etc.
   * @returns Observable with payment result
   */
  processPayment(paymentData: any): Observable<any> {
    console.log(`💳 Processing payment`, paymentData);
    return this.http.post<any>(`${this.apiUrl}/students/${paymentData.studentId}/process-payment`, paymentData);
  }

  /**
   * Generate fee receipt PDF for student
   * @param studentId Student ID
   * @param feeStructureId Fee structure ID (optional)
   * @returns Observable with PDF blob
   */
  generateFeeReceipt(studentId: number, feeStructureId?: number): Observable<Blob> {
    console.log(`📄 Generating receipt for student ${studentId}`);
    let url = `${this.apiUrl}/students/${studentId}/generate-receipt`;
    if (feeStructureId) {
      url += `?feeStructureId=${feeStructureId}`;
    }
    return this.http.get(url, { responseType: 'blob' });
  }

  /**
   * Get student fee overview/summary
   * @param studentId Student ID
   * @returns Observable with fee overview data
   */
  getStudentFeeOverview(studentId: number): Observable<any> {
    console.log(`📊 Fetching fee overview for student ${studentId}`);
    return this.http.get<any>(`${this.apiUrl}/students/${studentId}/fee-overview`);
  }

  /**
   * Get payment history for student
   * @param studentId Student ID
   * @returns Observable with payment history
   */
  getPaymentHistory(studentId: number): Observable<any> {
    console.log(`📜 Fetching payment history for student ${studentId}`);
    return this.http.get<any>(`${this.apiUrl}/students/${studentId}/payment-history`);
  }

  /**
   * Calculate balance for an installment
   * @param studentId Student ID
   * @param installmentId Installment ID
   * @returns Observable with balance calculation
   */
  calculateInstallmentBalance(studentId: number, installmentId: number): Observable<any> {
    console.log(`🧮 Calculating balance for installment ${installmentId}`);
    return this.http.get<any>(`${this.apiUrl}/students/${studentId}/installments/${installmentId}/balance`);
  }

  /**
   * Get student by search term (for autocomplete)
   * @param searchTerm Search term (name, roll number, etc.)
   * @param academicYearId Optional academic year filter
   * @returns Observable with matching students
   */
  searchStudents(searchTerm: string, academicYearId?: number): Observable<any> {
    console.log(`🔍 Searching students: ${searchTerm}, Year: ${academicYearId}`);
    let url = `${this.apiUrl}/students/search?q=${searchTerm}`;
    if (academicYearId) {
      url += `&academicYearId=${academicYearId}`;
    }
    return this.http.get<any>(url);
  }

  // ===================== ENTERPRISE: Fee Rules =====================

  getFeeRules(ruleType?: number): Observable<any> {
    const params: any = ruleType !== undefined ? { ruleType } : {};
    return this.http.get<any>(`${this.apiUrl}/fee-rules`, { params });
  }

  createFeeRule(rule: any): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/fee-rules`, rule);
  }

  updateFeeRule(id: number, rule: any): Observable<any> {
    return this.http.put<any>(`${this.apiUrl}/fee-rules/${id}`, rule);
  }

  deleteFeeRule(id: number): Observable<any> {
    return this.http.delete<any>(`${this.apiUrl}/fee-rules/${id}`);
  }

  calculateLateFee(installmentId: number, daysOverdue: number): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/fee-rules/calculate-late-fee`, {
      params: { installmentId, daysOverdue }
    });
  }

  // ===================== ENTERPRISE: Student Ledger =====================

  getStudentLedger(studentId: number, startDate?: string, endDate?: string): Observable<any> {
    const params: any = {};
    if (startDate) params.startDate = startDate;
    if (endDate) params.endDate = endDate;
    return this.http.get<any>(`${this.apiUrl}/students/${studentId}/ledger`, { params });
  }

  getRefundableBalance(studentId: number): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/students/${studentId}/refundable-balance`);
  }

  getRefundHistory(studentId: number): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/students/${studentId}/refunds`);
  }

  createRefund(request: { paymentId: number; studentId: number; refundAmount: number; refundMode: number; refundReason: string; referenceNumber?: string; remarks?: string }): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/refunds`, request);
  }

  addLedgerEntry(studentId: number, entry: { entryType: number; amount: number; description: string; referenceType: string; referenceId?: number }): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/students/${studentId}/ledger`, entry);
  }

  // ===================== ENTERPRISE: Multi-Installment Payment =====================

  processMultiInstallmentPayment(request: {
    studentId: number;
    totalAmount: number;
    paymentMethod: number;
    transactionId?: string;
    remarks?: string;
    installmentPayments: { installmentId: number; amount: number; lateFeeAmount?: number; discountAmount?: number }[];
  }): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/payments/multi-installment`, request);
  }

  // ===================== ENTERPRISE: Defaulter List =====================

  getDefaulterList(page = 1, pageSize = 20, minDaysOverdue = 1): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/analytics/defaulters`, {
      params: { page, pageSize, minDaysOverdue }
    });
  }

  // ===================== ENTERPRISE: Collection Chart Data =====================

  getCollectionChartData(startDate?: string, endDate?: string, groupBy: 'daily' | 'monthly' = 'daily'): Observable<any> {
    const params: any = { groupBy };
    if (startDate) params.startDate = startDate;
    if (endDate) params.endDate = endDate;
    return this.http.get<any>(`${this.apiUrl}/analytics/collection-chart`, { params });
  }

  // ===================== ENTERPRISE: Enhanced Dashboard =====================

  getEnhancedDashboard(period: 'week' | 'month' | 'year' = 'month', academicYearId?: number): Observable<any> {
    const params: any = { period };
    if (academicYearId) params.academicYearId = academicYearId;
    return this.http.get<any>(`${this.apiUrl}/analytics/dashboard`, { params });
  }

  // ===================== ENTERPRISE: Bulk Operations =====================

  bulkAssignFees(request: { feeStructureId: number; studentIds: number[]; remarks?: string }): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/bulk/assign-fees`, request);
  }

  bulkImportPayments(payments: any[]): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/bulk/import-payments`, { payments });
  }

  // ===================== ENTERPRISE: Notifications =====================

  sendDueReminders(daysAhead = 7): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/notifications/send-due-reminders?daysAhead=${daysAhead}`, {});
  }

  getStudentNotifications(studentId: number): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/students/${studentId}/notifications`);
  }

  // ===================== ENTERPRISE: Finance Audit Log =====================

  getFinanceAuditLog(count = 50): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/audit/finance-log`, { params: { count } });
  }

  getEntityAuditTrail(entityType: string, entityId: number): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/audit/entity/${entityType}/${entityId}`);
  }
}
