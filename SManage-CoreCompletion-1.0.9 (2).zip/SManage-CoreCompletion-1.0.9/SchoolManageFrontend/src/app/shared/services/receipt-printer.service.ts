import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import { AuthService } from '../../core/services/auth.service';

/** One line item on the receipt (an installment, a fee component, or a student allocation). */
export interface ReceiptItem {
  description: string;
  unitPrice: number;
  total: number;
}

export interface ReceiptData {
  /** e.g. "SCHOOL FEE", "SECONDARY SCHOOL FEE" — printed as the big heading. */
  title: string;
  receiptNo: string;
  studentName: string;
  /** ISO or yyyy-MM-dd date string. */
  date: string;
  items: ReceiptItem[];
  /** e.g. "Online Transfer", "Cash", "UPI" */
  paymentMethod: string;
  /** Transaction / reference line shown under Payment Information. */
  ref?: string;
  /** Account line shown under Payment Information. */
  accountName?: string;
  /** Extra info lines (remarks etc.) under Payment Information. */
  infoLines?: string[];
  /** Tax shown on the right summary (default 0). */
  taxPercent?: number;
  /** Footer note, default enrollment-confirmation text. */
  footerNote?: string;
  /** Overrides for auto-resolved school profile. */
  schoolName?: string;
  schoolLogoUrl?: string;
  schoolEmail?: string;
  schoolAddress?: string;
  currency?: string; // default INR
  locale?: string;   // default en-IN
}

interface SchoolProfile {
  name: string;
  logoUrl?: string;
  email?: string;
  address?: string;
}

/**
 * Invoice-style receipt printing for all fee flows (single payment,
 * multi-installment payment, family/group payment).
 * School header (logo, name, email) resolves dynamically from the current
 * tenant + logged-in user, so every tenant gets its own branded receipt.
 */
@Injectable({ providedIn: 'root' })
export class ReceiptPrinterService {
  private http = inject(HttpClient);
  private auth = inject(AuthService);
  private profileCache: SchoolProfile | null | undefined;

  async print(data: ReceiptData): Promise<void> {
    // Reserve the print window during the click/tap gesture. Android Chrome
    // blocks window.open() when it happens after async profile/API work.
    const win = window.open('', '_blank');
    if (win) {
      win.document.write('<!doctype html><title>Preparing statement</title><p style="font:16px sans-serif;padding:24px">Preparing statement…</p>');
      win.document.close();
    }

    let html: string;
    try {
      html = await this.buildHtml(data);
    } catch (error) {
      win?.close();
      throw error;
    }

    // Size the popup to the device; the embedded @media (max-width: 540px)
    // rules restyle the sheet as a single-column receipt on phones.
    if (!win) {
      // Popup blocked — fall back to downloading the receipt as HTML.
      const blob = new Blob([html], { type: 'text/html' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `receipt-${data.receiptNo || Date.now()}.html`;
      a.target = '_blank';
      document.body.appendChild(a);
      a.click();
      a.remove();
      // Delay revocation so Android's download manager can consume the blob.
      setTimeout(() => URL.revokeObjectURL(url), 60_000);
      return;
    }

    win.document.open();
    win.document.write(html);
    win.document.close();
    // Let the logo image load before the print dialog grabs it.
    setTimeout(() => { try { win.focus(); win.print(); } catch { /* ignore */ } }, 350);
  }

  /** Resolves school name/logo/email/address dynamically (cached per session). */
  private async resolveProfile(): Promise<SchoolProfile> {
    if (this.profileCache !== undefined) return this.profileCache ?? this.fallback();

    const profile: SchoolProfile = { name: '' };
    try {
      // /api/tenants is scoped to the caller's tenant for non-SuperAdmins.
      const res: any = await firstValueFrom(this.http.get('/api/tenants'));
      const tenants = res?.data ?? res;
      const tenant = Array.isArray(tenants) ? tenants[0] : tenants;
      if (tenant) {
        profile.name = tenant.name || tenant.Name || '';
        profile.logoUrl = tenant.logoUrl || tenant.LogoUrl || undefined;
        const settings = tenant.settingsJson || tenant.SettingsJson;
        if (settings) {
          try {
            const s = typeof settings === 'string' ? JSON.parse(settings) : settings;
            profile.address = s.address || s.Address || undefined;
            profile.email = s.email || s.Email || profile.email;
          } catch { /* settings is free-form; ignore parse failures */ }
        }
      }
    } catch { /* unauthenticated or endpoint unavailable — fall through */ }

    // Domain-bound tenants: /api/auth/resolve-domain returns tenantName for this host.
    if (!profile.name) {
      try {
        const res: any = await firstValueFrom(this.http.get('/api/auth/resolve-domain'));
        profile.name = res?.tenantName ?? res?.data?.tenantName ?? '';
      } catch { /* ignore */ }
    }

    // Top-right contact email: current admin user.
    if (!profile.email) profile.email = this.auth.getCurrentUser()?.email || '';

    this.profileCache = profile.name ? profile : null;
    return this.profileCache ?? this.fallback();
  }

  private fallback(): SchoolProfile {
    return { name: '', email: this.auth.getCurrentUser()?.email || '' };
  }

  private async getProfile(data: ReceiptData): Promise<SchoolProfile> {
    if (data.schoolName || data.schoolLogoUrl) {
      return { name: data.schoolName || '', logoUrl: data.schoolLogoUrl, email: data.schoolEmail || this.auth.getCurrentUser()?.email || '', address: data.schoolAddress };
    }
    const resolved = await this.resolveProfile();
    return {
      name: data.schoolName || resolved.name,
      logoUrl: data.schoolLogoUrl || resolved.logoUrl,
      email: data.schoolEmail || resolved.email,
      address: data.schoolAddress || resolved.address
    };
  }

  private async buildHtml(data: ReceiptData): Promise<string> {
    const p = await this.getProfile(data);
    const locale = data.locale || 'en-IN';
    const currency = data.currency || 'INR';
    const fmt = (n: number) => new Intl.NumberFormat(locale, { style: 'currency', currency }).format(n || 0);

    const schoolName = p.name || data.schoolName || 'School Management';
    const schoolEmail = p.email || '';
    const taxPercent = data.taxPercent ?? 0;
    const subtotal = data.items.reduce((s, i) => s + (i.total ?? 0), 0);
    const tax = subtotal * taxPercent / 100;
    const totalReceived = subtotal + tax;
    const today = new Date().toISOString().slice(0, 10);
    const logoHtml = p.logoUrl
      ? `<img class="logo-img" src="${escapeHtml(p.logoUrl)}" alt="logo" onerror="this.style.display='none'">`
      : `<div class="logo-placeholder">LOGO</div>`;

    const itemsHtml = data.items.map(i => `
      <tr>
        <td>${escapeHtml(i.description)}</td>
        <td class="num">${fmt(i.unitPrice)}</td>
        <td class="num">${fmt(i.total)}</td>
      </tr>`).join('');

    const infoLinesHtml = (data.infoLines || []).map(l => `<div class="pay-info-line">${escapeHtml(l)}</div>`).join('');

    return `<!doctype html>
<html>
<head>
<meta charset="utf-8" />
<title>Receipt ${escapeHtml(data.receiptNo)} - ${escapeHtml(schoolName)}</title>
<style>
  * { box-sizing: border-box; }
  html, body { margin: 0; padding: 0; }
  body {
    font-family: -apple-system, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
    color: var(--md-on-surface); background: #f5f6f8; display: flex; justify-content: center;
  }
  .sheet {
    background: #fff; width: 700px; max-width: 100%;
    margin: 24px; padding: 44px 48px 56px;
  }
  /* ========= PHONES: stack the invoice instead of squeezing it =========
     (760px popup on a 360px phone auto-shrinks the text to unreadable;
     title collided with the receipt number cell, amounts clipped.) */
  @media (max-width: 540px) {
    .sheet { margin: 0; padding: 22px 16px 32px; }
    .hdr { flex-wrap: wrap; }
    .hdr-email { word-break: break-all; font-size: 12px; }
    .title-row { flex-direction: column; align-items: flex-start; gap: 12px; margin: 20px 0 6px; }
    .receipt-title { font-size: 21px; line-height: 1.2; }
    .meta { text-align: left; font-size: 12.5px; gap: 4px; width: 100%; }
    .meta .lbl { display: inline-block; min-width: 82px; }
    .meta b { word-break: break-word; }
    table.items td { padding: 12px 0; font-size: 13.5px; }
    table.items td.num, th.num { text-align: right; }
    .footer-area { flex-direction: column; align-items: stretch; margin-top: 22px; }
    .pay-info { max-width: 100%; }
    .pay-info-line { word-break: break-word; overflow-wrap: anywhere; }
    .summary { min-width: 0; }
    .bottom { flex-direction: column; gap: 14px; margin-top: 40px; }
    .bottom-left, .bottom-right { max-width: 100%; }
  }
  @media print {
    body { background: #fff; }
    /* A4-ish printable area with real margins; theme-color strips, toolbars
       and shard UI don't exist in this popup document but @page keeps the
       PDF clean and repeatable across browsers. */
    @page { size: A4; margin: 14mm 12mm; }
    .sheet { margin: 0; padding: 0; width: 100%; box-shadow: none; }
    /* Never paginate a line/summary row across two sheets */
    tr, .sum-row, .footer-area, .bottom { break-inside: avoid; page-break-inside: avoid; }
    .rule, .rule-light { break-after: avoid; }
  }
  /* Header */
  .hdr { display: flex; justify-content: space-between; align-items: center; gap: 16px; }
  .hdr-left { display: flex; align-items: center; gap: 10px; min-width: 0; }
  .logo-placeholder {
    border: 3px solid #111; border-radius: 8px; padding: 8px 10px;
    font-weight: 800; font-size: var(--font-size-base); letter-spacing: 1px;
  }
  .logo-img { height: 42px; max-width: 120px; object-fit: contain; }
  .school-name { font-weight: 700; font-size: var(--font-size-md); }
  .hdr-email { font-size: 13px; color: var(--md-on-surface); }
  .rule { border: 0; border-top: 2px solid #111; margin: 18px 0 0; }
  /* Title row */
  .title-row { display: flex; justify-content: space-between; align-items: flex-start; margin: 34px 0 8px; }
  .receipt-title { font-size: var(--font-size-6xl); font-weight: 800; letter-spacing: 0.5px; margin: 0; text-transform: uppercase; }
  .meta { text-align: right; font-size: 13.5px; color: #222; display: grid; gap: 8px; }
  .meta b { font-weight: 600; word-break: break-word; }
  .meta .lbl { color: #444; margin-right: 8px; }
  .rule-light { border: 0; border-top: 2px solid #111; margin: 26px 0 0; }
  /* Items */
  table.items { width: 100%; border-collapse: collapse; margin-top: 22px; }
  table.items th {
    text-align: left; font-size: 11.5px; letter-spacing: 1.2px; text-transform: uppercase;
    font-weight: 700; padding: 6px 0 14px; border-bottom: 1.5px solid #111;
  }
  table.items th.num { text-align: left; }
  table.items td { padding: 20px 0; font-size: 14px; vertical-align: top; border-bottom: 1px solid transparent; }
  table.items td.num { text-align: left; white-space: nowrap; }
  table.items td.desc { width: 55%; min-width: 0; }
  /* Footer summary */
  .footer-area { display: flex; justify-content: space-between; align-items: flex-end; gap: 24px; margin-top: 34px; }
  .pay-info { font-size: 13px; max-width: 46%; min-width: 0; }
  .pay-info-line { margin-bottom: 5px; word-break: break-word; }
  .pay-info-title { font-weight: 700; margin-bottom: 10px; }
  .summary { min-width: 42%; }
  .sum-row { display: flex; justify-content: space-between; gap: 10px; font-size: 13px; padding: 4px 0; }
  .sum-row .label { letter-spacing: 0.6px; color: #222; }
  .total-block { border-top: 1.5px solid #111; margin-top: 10px; padding-top: 12px; margin-bottom: 4px; }
  .sum-row.total { font-size: var(--font-size-base); font-weight: 700; }
  /* Bottom footer */
  .bottom { display: flex; justify-content: space-between; gap: 32px; margin-top: 84px; font-size: 12.5px; color: #222; }
  .bottom-left { max-width: 48%; line-height: 1.5; }
  .bottom-right { text-align: left; line-height: 1.5; }
</style>
</head>
<body>
  <div class="sheet">
    <div class="hdr">
      <div class="hdr-left">
        ${logoHtml}
        <span class="school-name">${escapeHtml(schoolName)}</span>
      </div>
      <div class="hdr-email">${escapeHtml(schoolEmail)}</div>
    </div>
    <hr class="rule">

    <div class="title-row">
      <h1 class="receipt-title">${escapeHtml(data.title || 'School Fee')}</h1>
      <div class="meta">
        <div><span class="lbl">Receipt No:</span><b>${escapeHtml(data.receiptNo)}</b></div>
        <div><span class="lbl">Student:</span><b>${escapeHtml(data.studentName)}</b></div>
        <div><span class="lbl">Date:</span><b>${escapeHtml(data.date || today)}</b></div>
      </div>
    </div>
    <hr class="rule-light">

    <table class="items">
      <thead>
        <tr>
          <th class="desc">Item Description</th>
          <th class="num">Unit Price</th>
          <th class="num">Total</th>
        </tr>
      </thead>
      <tbody>${itemsHtml}</tbody>
    </table>

    <div class="footer-area">
      <div class="pay-info">
        <div class="pay-info-title">Payment Information:</div>
        <div class="pay-info-line">Payment Method: ${escapeHtml(data.paymentMethod || '-')}</div>
        ${data.ref ? `<div class="pay-info-line">Ref.: ${escapeHtml(data.ref)}</div>` : ''}
        ${data.accountName ? `<div class="pay-info-line">Account: ${escapeHtml(data.accountName)}</div>` : ''}
        ${infoLinesHtml}
      </div>
      <div class="summary">
        <div class="sum-row"><span class="label">SUBTOTAL</span><span>${fmt(subtotal)}</span></div>
        <div class="sum-row"><span class="label">TAX (${taxPercent}%)</span><span>${fmt(tax)}</span></div>
        <div class="sum-row total total-block"><span class="label">TOTAL RECEIVED</span><span>${fmt(totalReceived)}</span></div>
      </div>
    </div>

    <div class="bottom">
      <div class="bottom-left">${escapeHtml(data.footerNote || 'This receipt confirms the fee payment was received successfully. Please retain it for your records.')}</div>
      <div class="bottom-right">
        <div>${escapeHtml(schoolName)}</div>
        ${p.address ? `<div>${escapeHtml(p.address)}</div>` : ''}
      </div>
    </div>
  </div>
</body>
</html>`;
  }

  /** Formats a C#/backend payment-method enum name like "BankTransfer" -> "Bank Transfer". */
  static humanizeMethod(method: unknown): string {
    if (!method) return '-';
    const s = String(method).replace(/[_-]+/g, ' ');
    if (/^[a-z0-9 ]+$/i.test(s)) return s.replace(/\b\w/g, c => c.toUpperCase());
    return s.replace(/([a-z])([A-Z])/g, '$1 $2').replace(/\b\w/g, c => c.toUpperCase());
  }
}

function escapeHtml(v: unknown): string {
  return String(v ?? '')
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}
