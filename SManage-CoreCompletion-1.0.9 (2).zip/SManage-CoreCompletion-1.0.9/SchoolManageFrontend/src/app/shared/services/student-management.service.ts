import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { StudentFullDetailsDto } from '../models/student-full-details-dto';

@Injectable({
  providedIn: 'root'
})
export class StudentManagementService {
  private apiUrl = '/api/students'; // Adjust based on your API route
  
  // Test method to check API connectivity
  testConnection(): Observable<any> {
    console.log('🧪 Testing API connection to:', this.apiUrl);
    return this.http.get(`${this.apiUrl}`).pipe(
      map((response: any) => {
        console.log('✅ API connection test successful:', response);
        return response;
      })
    );
  }

  constructor(private http: HttpClient) { }

  getAllStudentFullDetails(search: string = '', page: number = 1, pageSize: number = 20): Observable<StudentFullDetailsDto[]> {
    console.log(`👨‍🎓 StudentManagementService.getAllStudentFullDetails(search: "${search}") called`);

    let params = new HttpParams()
      .set('page', page.toString())
      .set('pageSize', pageSize.toString());

    if (search) {
      params = params.set('search', search);
    }

    return this.http.get<any>(`${this.apiUrl}/full-details`, { params }).pipe(
      map((response: any) => this.extractStudents(response)),
      catchError(() => this.getBasicStudents(search, page, pageSize))
    );
  }

  private getBasicStudents(search: string = '', page: number = 1, pageSize: number = 20): Observable<StudentFullDetailsDto[]> {
    let params = new HttpParams()
      .set('page', page.toString())
      .set('pageSize', pageSize.toString());

    if (search) {
      params = params.set('search', search);
    }

    return this.http.get<any>(this.apiUrl, { params }).pipe(
      map((response: any) => this.extractStudents(response))
    );
  }

  private extractStudents(response: any): StudentFullDetailsDto[] {
    if (Array.isArray(response)) {
      return response as StudentFullDetailsDto[];
    }

    if (Array.isArray(response?.data)) {
      return response.data as StudentFullDetailsDto[];
    }

    if (Array.isArray(response?.items)) {
      return response.items as StudentFullDetailsDto[];
    }

    if (Array.isArray(response?.results)) {
      return response.results as StudentFullDetailsDto[];
    }

    return [];
  }

  getStudentFullDetails(id: number): Observable<StudentFullDetailsDto> {
    return this.http.get<StudentFullDetailsDto>(`${this.apiUrl}/full-details/${id}`);
  }

  createStudentFullDetails(student: any): Observable<StudentFullDetailsDto> {
    console.log('🚀 Creating student with data:', student);
    console.log('📡 POST request to:', `${this.apiUrl}/full-details`);
    
    return this.http.post<StudentFullDetailsDto>(`${this.apiUrl}/full-details`, student).pipe(
      map((response: any) => {
        console.log('✅ Create student response:', response);
        return response;
      })
    );
  }

  updateStudentFullDetails(id: number, student: any): Observable<void> {
    console.log('🔄 Updating student with ID:', id);
    console.log('🚀 Update data:', student);
    console.log('📡 PUT request to:', `${this.apiUrl}/full-details/${id}`);
    
    return this.http.put<void>(`${this.apiUrl}/full-details/${id}`, student).pipe(
      map((response: any) => {
        console.log('✅ Update student response:', response);
        return response;
      })
    );
  }

  deleteStudentFullDetails(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/full-details/${id}`);
  }
}
