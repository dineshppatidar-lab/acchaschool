export interface StudentFullDetailsDto {
  id: number;
  firstName: string;
  lastName: string;
  dateOfBirth: Date;
  gender: string;
  /** Real enrollment status from backend (issue #7) */
  status?: string;
  isActive?: boolean;
  address: string;
  contactNumber: string;
  email: string;
  admissionDate: Date;
  academicYearId?: number;
  classId: number;
  className?: string;
  sectionId: number;
  sectionName?: string;
  academicYear?: string;
  parentId?: number;
  rollNumber: string;
  scholarNumber: string;
  photoPath?: string;
  casteCategory?: string;
  religion?: string;
  busRouteId?: number;
  enrollmentStatus?: string;
  newParentDetails?: ParentDto;
  secondaryParents?: ParentDto[];
  emergencyContact?: EmergencyContactDto;
  examResults?: ExamResultDto[];
  attendances?: AttendanceDto[];
  fees?: FeeDto[];
  hostelAllocation?: HostelAllocationDto;
  hostelLeaves?: HostelLeaveDto[];
  busAttendances?: BusAttendanceDto[];
  documents?: DocumentDto[];
  addressInfo?: StudentAddressInfoDto;
  academicHistory?: StudentAcademicHistoryDto;
  medicalInfo?: StudentMedicalInfoDto;
  documentInfo?: StudentDocumentInfoDto;
  specialNeeds?: StudentSpecialNeedsDto;
  hostelInfo?: StudentHostelInfoDto;
  scholarshipInfo?: StudentScholarshipInfoDto;
  behavioralInfo?: StudentBehavioralInfoDto;
  systemInfo?: StudentSystemInfoDto;
}

export interface ParentDto {
  id?: number;
  firstName: string;
  lastName: string;
  contactNumber: string;
  email: string;
  occupation: string;
  relationship?: string;
}

export interface ExamResultDto {
  id: number;
  studentId: number;
  subjectId: number;
  examType: string;
  examDate: Date;
  marksObtained: number;
  totalMarks: number;
  grade: string;
  remarks: string;
}

export interface AttendanceDto {
  id: number;
  studentId: number;
  date: Date;
  isPresent: boolean;
  remarks: string;
}

export interface FeeDto {
  id: number;
  studentId: number;
  feeType: string;
  amount: number;
  dueDate: Date;
  status: string;
}

export interface HostelAllocationDto {
  id: number;
  studentId: number;
  roomId: number;
  allocationDate: Date;
  releaseDate: Date;
  bedNumber: string;
  mealPlan: string;
}

export interface HostelLeaveDto {
  id: number;
  studentId: number;
  startDate: Date;
  endDate: Date;
  reason: string;
  status: string;
  approvedById: number;
  requestDate: Date;
}

export interface BusAttendanceDto {
  id: number;
  studentId: number;
  routeId: number;
  date: Date;
  isPresent: boolean;
  markingMethod: string;
}

export interface DocumentDto {
  id?: number;
  studentId?: number;
  documentType: string;
  fileName: string;  // Original file name
  filePath: string;
  fileContent?: string;  // Base64 encoded file content or byte array as string
  fileSize: number;  // File size in bytes
  uploadDate: Date;
}

export interface EmergencyContactDto {
  id?: number;
  studentId?: number;
  contactName: string;
  relationship: string;
  primaryPhone: string;
  secondaryPhone?: string;
  address?: string;
  preferredContactOrder?: string;
}

export interface StudentAddressInfoDto {
  id?: number;
  studentId?: number;
  currentHouseNumber: string;
  currentStreetName: string;
  currentCity: string;
  currentState: string;
  currentPostalCode: string;
  currentCountry: string;
  sameAsPermanent: boolean;
  permanentHouseNumber: string;
  permanentStreetName: string;
  permanentCity: string;
  permanentState: string;
  permanentPostalCode: string;
  permanentCountry: string;
}

export interface StudentAcademicHistoryDto {
  id?: number;
  studentId?: number;
  previousSchoolName: string;
  previousSchoolBoard: string;
  previousSchoolAddress: string;
  yearPassedFrom?: number;
  lastGradeAttended: string;
  academicPercentage?: number;
  transferCertificateNumber: string;
  reasonForTransfer: string;
}

export interface StudentMedicalInfoDto {
  id?: number;
  studentId?: number;
  bloodGroup: string;
  lastHealthCheckDate?: Date;
  knownAllergies: string;
  hasAsthma: boolean;
  hasDiabetes: boolean;
  hasHeartCondition: boolean;
  hasEpilepsy: boolean;
  otherMedicalConditions?: string;
  isVaccinatedPolio: boolean;
  isVaccinatedMeasles: boolean;
  isVaccinatedBCG: boolean;
  isVaccinatedTCV: boolean;
  physicalDisability?: string;
  currentMedicines?: string;
}

export interface StudentDocumentInfoDto {
  id?: number;
  studentId?: number;
  idProofType: string;
  idProofNumber: string;
  idExpiryDate?: Date;
  passportNumber?: string;
  birthCertificateNumber?: string;
  documentVerificationStatus?: string;
  verifiedBy?: string;
  verificationDate?: Date;
  documentNotes?: string;
}

export interface StudentSpecialNeedsDto {
  id?: number;
  studentId?: number;
  hasSpecialNeeds: boolean;
  disabilityType?: string;
  disabilitySeverity?: string;
  auxiliaryAidsRequired?: string;
  specialResourcesNeeded?: string;
  iepDocumentPath?: string;
  parentConsentForSnE?: boolean;
}

export interface StudentHostelInfoDto {
  id?: number;
  studentId?: number;
  hostelRequired: boolean;
  preferredHostel?: string;
  roomType?: string;
  travelMode?: string;
  distanceFromHome?: number;
  hostelGuardianName?: string;
  hostelGuardianContact?: string;
  hostelAllocationDate?: Date;
}

export interface StudentScholarshipInfoDto {
  id?: number;
  studentId?: number;
  eligibleForScholarship: boolean;
  scholarshipType?: string;
  scholarshipPercentage?: number;
  scholarshipApplicationDate?: Date;
  scholarshipApprovalDate?: Date;
  concessionType?: string;
  concessionAmount?: number;
  concessionApprovedBy?: string;
}

export interface StudentBehavioralInfoDto {
  id?: number;
  studentId?: number;
  behaviorRecord?: string;
  counselingSessionCount?: number;
  disciplinaryHistory?: string;
  lastDisciplinaryActionDate?: Date;
  parentTeacherMeetingAttendance?: number;
  behavioralConcerns?: string;
  teacherNotes?: string;
}

export interface StudentSystemInfoDto {
  id?: number;
  studentId?: number;
  studentUniqueId?: string;
  studentPortalUsername?: string;
  studentStatus?: string;
  CreatedOn?: Date;
  lastModifiedDate?: Date;
  createdBy?: string;
  modifiedBy?: string;
}
