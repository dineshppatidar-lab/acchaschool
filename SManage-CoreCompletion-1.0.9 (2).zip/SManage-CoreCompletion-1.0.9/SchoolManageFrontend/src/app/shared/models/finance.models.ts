// Centralized finance domain models

export interface FeePaymentDto {
  id: number;
  studentId: number;
  amountPaid: number;
  paymentDate: string;
  paymentMethod: string;
  status: string;
  receiptNumber: string;
}

export interface CreatePaymentRequest {
  studentId: number;
  studentName: string;
  studentEmail: string;
  feeInstallmentId: number;
  amountPaid: number;
  lateFeeAmount?: number | null;
  discountAmount?: number | null;
  paymentMethod: number; // PaymentMethod enum value
  transactionId?: string;
  remarks?: string;
}
