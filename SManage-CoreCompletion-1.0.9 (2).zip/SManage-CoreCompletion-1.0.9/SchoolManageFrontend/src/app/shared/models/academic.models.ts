// Centralized academic domain models

export interface TimeTableEntry {
  timeTableId: number;
  classId: number;
  sectionId?: number;
  subjectId: number;
  staffId: number;
  /** Dialogs bind the teacher dropdown to this alias; the service maps it to staffId. */
  teacherId?: number;
  dayOfWeek: string;
  startTime: string;
  endTime: string;
  // Backend uses RoomNumber; keep existing 'room' for UI and add optional compatibility
  room: string;
  roomNumber?: string;
  className?: string;
  subjectName?: string;
  teacherName?: string;
}

export interface ExaminationType {
  id: number;
  name: string;
  description?: string;
  weightagePercentage?: number;
  isActive?: boolean;
}

export interface Examination {
  id: number;
  examId?: number; // legacy compatibility
  academicYearId: number;
  title: string;
  examName?: string; // legacy compatibility
  examinationTypeId: number;
  examType?: string; // legacy compatibility
  startDate: Date | string;
  endDate: Date | string;
  instructions: string;
  description?: string; // legacy compatibility
  isPublished: boolean;
  status?: string; // legacy compatibility
  examinationType?: ExaminationType;
}

export interface Assignment {
  assignmentId: number;
  classId: number;
  subjectId: number;
  title: string;
  description: string;
  assignedDate: Date;
  dueDate: Date;
  maxMarks: number;
  // Frontend uses a simple status string; backend has IsActive flag
  status: string;
  isActive?: boolean;
  className?: string;
  subjectName?: string;
}

export interface Class {
  id: number;
  name: string;
  description?: string;
  /** Real per-class aggregates from GET /api/academic/statistics (issue #7) */
  studentCount?: number;
  sectionCount?: number;
  subjectCount?: number;
}

export interface Section {
  id: number;
  name: string;
  classId: number;
}

export interface AcademicYear {
  id: number;
  name: string;
  isActive?: boolean;
  isCurrent?: boolean;
}

export interface Subject {
  id: number;
  name: string;
  code?: string;
  classId?: number;
}

export interface Teacher {
  id: number;
  name: string;
}

export interface ExamResult {
  id?: number;
  studentId: number;
  subjectId: number;
  examType: string;
  examDate: string | Date;
  marksObtained: number;
  totalMarks: number;
  grade?: string;
  remarks?: string;
}
