/**
 * MenuItem Interface
 * Represents a single menu item with hierarchical structure
 */
export interface MenuItem {
  id: number;
  label: string;
  icon?: string;
  route?: string;
  requiredPermission?: string;
  displayOrder: number;
  isActive: boolean;
  tenantId?: number | string;
  category?: string;
  description?: string;
  badge?: string;
  externalUrl?: string;
  openInNewTab?: boolean;
  disabled?: boolean;
  parentId?: number | null;
  children?: MenuItem[];
  createdAt?: Date;
  updatedAt?: Date;
  isDeleted?: boolean;
}

/**
 * CreateMenuItemRequest
 * DTO for creating a new menu item
 */
export interface CreateMenuItemRequest {
  label: string;
  icon?: string;
  route?: string;
  requiredPermission?: string;
  displayOrder: number;
  isActive: boolean;
  category?: string;
  description?: string;
  badge?: string;
  externalUrl?: string;
  openInNewTab?: boolean;
  parentId?: number | null;
}

/**
 * UpdateMenuItemRequest
 * DTO for updating an existing menu item
 */
export interface UpdateMenuItemRequest {
  label?: string;
  icon?: string;
  route?: string;
  requiredPermission?: string;
  displayOrder?: number;
  isActive?: boolean;
  category?: string;
  description?: string;
  badge?: string;
  externalUrl?: string;
  openInNewTab?: boolean;
  parentId?: number | null;
}
