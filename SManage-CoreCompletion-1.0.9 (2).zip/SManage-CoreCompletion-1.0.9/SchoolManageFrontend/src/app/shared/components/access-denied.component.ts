import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatChipsModule } from '@angular/material/chips';
import { Router } from '@angular/router';
import { Permission, PermissionLabels, UserRole, RoleLabels } from '../../core/models/permission.model';

@Component({
  selector: 'app-access-denied',
  standalone: true,
  imports: [CommonModule, MatCardModule, MatButtonModule, MatIconModule, MatChipsModule],
  templateUrl: './access-denied.component.html',
  styleUrls: ['./access-denied.component.scss']
})
export class AccessDeniedComponent implements OnInit {
  missingPermissionLabel: string = '';
  missingPermissionKey: string = '';
  attemptedUrl: string = '';
  requiredRoles: string[] = [];
  userRole: string = '';

  constructor(private router: Router) {}

  ngOnInit(): void {
    const state = (window.history.state as any) || {};

    if (state) {
      if (state.requiredPermission !== undefined) {
        const perm = state.requiredPermission as Permission;
        this.missingPermissionLabel = PermissionLabels[perm] || `Permission #${perm}`;
        this.missingPermissionKey = Permission[perm] || `Permission_${perm}`;
      }
      if (state.attemptedUrl) {
        this.attemptedUrl = state.attemptedUrl;
      }
      if (state.requiredRoles && Array.isArray(state.requiredRoles)) {
        this.requiredRoles = state.requiredRoles.map((role: UserRole) => 
          RoleLabels[role] || `Role #${role}`
        );
      }
    }

    const currentUser = localStorage.getItem('currentUser');
    if (currentUser) {
      try {
        const user = JSON.parse(currentUser);
        this.userRole = user.role || user.roles || 'Unknown';
      } catch (e) {
        this.userRole = 'Unknown';
      }
    }
  }

  goToDashboard(): void {
    this.router.navigate(['/app/dashboard']);
  }

  goBack(): void {
    window.history.back();
  }

  requestAccess(): void {
    const subject = encodeURIComponent(`Access Request: ${this.missingPermissionLabel}`);
    const body = encodeURIComponent(
      `Hello Administrator,\n\n` +
      `I am requesting access to the following resource:\n\n` +
      `Permission Required: ${this.missingPermissionLabel} (${this.missingPermissionKey})\n` +
      `Page URL: ${this.attemptedUrl || 'N/A'}\n` +
      `My Role: ${this.userRole}\n\n` +
      `Please grant me the necessary permissions.\n\n` +
      `Thank you!`
    );
    window.open(`mailto:admin@school.com?subject=${subject}&body=${body}`, '_blank');
  }
}