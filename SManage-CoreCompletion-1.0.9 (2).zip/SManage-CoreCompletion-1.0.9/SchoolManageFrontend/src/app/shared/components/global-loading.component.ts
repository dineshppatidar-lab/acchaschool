import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';

import { GlobalLoadingService } from '../../services/global-loading.service';

/**
 * GlobalLoadingComponent — the single application-wide loading overlay,
 * rendered once at the app root (App template) so it covers every route,
 * including the auth screens, without any per-page wiring.
 *
 * Design/behaviour:
 *  - Angular Material M3 spinner on a light surface card over a subtle blind,
 *    using the app's existing MD3 tokens (--md-*), no new dependencies.
 *  - Non-blocking while only GET requests are in flight (pointer pass-through)
 *    — the user can keep scrolling/type-ahead exploring while data refreshes.
 *  - Interaction is blocked only while a mutating request (POST/PUT/PATCH/
 *    DELETE) is in flight, which also protects against duplicate submissions.
 *  - z-index 900: above page content (_TOOLBAR sidebars) but BELOW the CDK
 *    overlay plane (snackbars, dialogs — z-index 1000+), so toasts and dialogs
 *    keep priority and are never covered.
 *  - Fixed, full-viewport positioning with 100dvh height keeps it vertically
 *    centered in the Android WebView / mobile browsers in portrait and
 *    landscape without causing overflow or horizontal scrolling.
 *  - Accessibility: role="status" + aria-live announcement, aria-busy on the
 *    host, prefers-reduced-motion disables all transitions.
 */
@Component({
  selector: 'app-global-loading',
  standalone: true,
  imports: [CommonModule, MatProgressSpinnerModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="gl-backdrop"
         *ngIf="loading.visible()"
         [class.gl-blocking]="loading.hasMutating()"
         [attr.aria-hidden]="true">
    </div>

    <div class="gl-panel"
         *ngIf="loading.visible()"
         role="status"
         aria-live="polite"
         [attr.aria-busy]="true">
      <mat-spinner class="gl-spinner" diameter="44"></mat-spinner>
      <span class="gl-message">{{ loading.message() }}</span>
    </div>
  `,
  styles: [`
    :host {
      /* Tracked overlay state lives only in the signal-driven service;
         the component itself is stateless and cheap. */
      position: static;
    }

    .gl-backdrop {
      position: fixed;
      inset: 0;
      z-index: 900;
      background: rgba(240, 243, 255, 0.45);            /* subtle blind, not dark */
      backdrop-filter: blur(1.5px);
      animation: gl-fade-in var(--gl-transition-ms, 180ms) ease;
      /* pass-through unless a mutating request requires blocking */
      pointer-events: none;
    }
    .gl-backdrop.gl-blocking { pointer-events: auto; }

    .gl-panel {
      position: fixed;
      z-index: 901;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 14px;
      padding: 24px 32px;
      border-radius: var(--radius-md, 8px);
      background: var(--md-surface, #FAF8FF);
      box-shadow: 0 6px 24px rgba(0, 20, 83, 0.14), 0 1px 4px rgba(0, 20, 83, 0.10);
      color: var(--md-on-surface, #131B2E);
      animation: gl-rise-in var(--gl-transition-ms, 180ms) ease;
      /* never widen the viewport on small screens / WebView */
      max-width: calc(100vw - 48px);
      pointer-events: none;
      user-select: none;
    }

    .gl-message {
      font-size: var(--font-size-base);
      font-weight: 500;
      color: var(--md-on-surface-variant, #444653);
      text-align: center;
      line-height: 1.4;
    }

    @keyframes gl-fade-in {
      from { opacity: 0; }
      to   { opacity: 1; }
    }
    @keyframes gl-rise-in {
      from { opacity: 0; transform: translate(-50%, calc(-50% + 8px)); }
      to   { opacity: 1; transform: translate(-50%, -50%); }
    }

    @media (prefers-reduced-motion: reduce) {
      .gl-backdrop, .gl-panel { animation: none; }
    }
  `]
})
export class GlobalLoadingComponent {
  protected readonly loading = inject(GlobalLoadingService);
}
