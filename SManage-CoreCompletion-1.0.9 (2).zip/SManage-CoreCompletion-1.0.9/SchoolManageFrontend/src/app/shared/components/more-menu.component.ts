import { Component, Output, EventEmitter, OnInit, OnDestroy, HostListener } from "@angular/core";
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule, Router } from '@angular/router';
import { MatIconModule } from '@angular/material/icon';
import { MatRippleModule } from '@angular/material/core';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { AuthService } from '../../services/auth.service';
import { DynamicMenuService, MenuItem } from '../../services/dynamic-menu.service';

interface MoreMenuItem {
  icon: string;
  label: string;
  route: string;
  color: string;
  adminOnly?: boolean;
}

@Component({
  selector: 'app-more-menu',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule, MatIconModule, MatRippleModule, MatProgressSpinnerModule],
  template: `
    <div class="more-overlay" (click)="close()" role="dialog" aria-label="More modules">
      <div class="more-sheet" (click)="$event.stopPropagation()">
        <!-- Drag handle -->
        <div class="sheet-handle"></div>

        <!-- Header -->
        <div class="sheet-header">
          <h2 class="sheet-title">All Modules</h2>
          <button class="close-btn" (click)="close()" aria-label="Close">
            <mat-icon>close</mat-icon>
          </button>
        </div>

        <!-- Quick Search -->
        <div class="search-bar">
          <mat-icon class="search-icon">search</mat-icon>
          <input type="text"
                 class="search-input"
                 placeholder="Search modules..."
                 [(ngModel)]="searchTerm"
                 (ngModelChange)="filterItems()"
                 autocomplete="off"
                 spellcheck="false"
                 aria-label="Search modules">
          <button *ngIf="searchTerm" class="clear-btn" (click)="searchTerm = ''; filterItems()">
            <mat-icon>close</mat-icon>
          </button>
        </div>

        <!-- Module Grid: permission-filtered (same menu the desktop sidebar renders).
             Shows a spinner while the user's menu loads and an error + retry if the
             menu API fails — it NEVER falls back to an unfiltered module list, a
             failed permission request must not grant access to everything. -->
        @if (loading && filteredItems.length === 0) {
          <div class="grid-state loading-state">
            <mat-spinner diameter="28"></mat-spinner>
            <span>Loading your modules…</span>
          </div>
        } @else if (error && filteredItems.length === 0) {
          <div class="grid-state error-state">
            <mat-icon>cloud_off</mat-icon>
            <span>Could not load your modules.</span>
            <button class="retry-btn" (click)="retryLoadMenu()">
              <mat-icon>refresh</mat-icon> Retry
            </button>
          </div>
        } @else if (!loading && filteredItems.length === 0 && !error) {
          <div class="grid-state">
            <mat-icon>apps</mat-icon>
            <span>No modules available for your account.</span>
          </div>
        } @else {
          <div class="module-grid">
            <a *ngFor="let item of filteredItems"
               class="module-card"
               [routerLink]="item.route"
               (click)="navigateTo(item)"
               matRipple
               [matRippleCentered]="true"
               [matRippleUnbounded]="true"
               [matRippleRadius]="40"
               role="menuitem"
               [attr.aria-label]="item.label">
              <div class="module-icon" [style.background]="item.color + '18'" [style.color]="item.color">
                <mat-icon>{{ item.icon }}</mat-icon>
              </div>
              <span class="module-label">{{ item.label }}</span>
            </a>
          </div>
        }

        <!-- Profile Section -->
        <div class="profile-section">
          <div class="profile-divider"></div>
          <div class="profile-row" *ngIf="user">
            <div class="profile-avatar">
              <img [src]="avatarUrl" alt="User avatar" class="avatar-img">
              <div class="online-dot"></div>
            </div>
            <div class="profile-info">
              <span class="profile-name">{{ user.username || user.name || 'User' }}</span>
              <span class="profile-role">{{ user.role || 'Administrator' }}</span>
            </div>
            <button class="settings-btn" (click)="openSettings()" matRipple aria-label="Settings">
              <mat-icon>settings</mat-icon>
            </button>
          </div>
          <button class="logout-row" (click)="logout()" matRipple>
            <mat-icon class="logout-icon">logout</mat-icon>
            <span>Sign Out</span>
          </button>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .more-overlay {
      position: fixed;
      inset: 0;
      z-index: 500;
      background: rgba(0, 0, 0, 0.4);
      backdrop-filter: blur(4px);
      -webkit-backdrop-filter: blur(4px);
      display: flex;
      align-items: flex-end;
      justify-content: center;
      animation: fadeIn 0.2s ease;
    }

    @keyframes fadeIn {
      from { opacity: 0; }
      to { opacity: 1; }
    }

    .more-sheet {
      width: 100%;
      max-width: 480px;
      max-height: 85vh;
      background: var(--md-surface, #fff);
      border-radius: 24px 24px 0 0;
      overflow: hidden;
      display: flex;
      flex-direction: column;
      animation: slideUp 0.3s cubic-bezier(0.2, 0, 0, 1);
      box-shadow: 0 -4px 24px rgba(0, 0, 0, 0.12);
    }

    @keyframes slideUp {
      from { transform: translateY(100%); }
      to { transform: translateY(0); }
    }

    .sheet-handle {
      width: 32px;
      height: 4px;
      background: var(--md-outline-variant, #C3C7CF);
      border-radius: 2px;
      margin: 10px auto 0;
      flex-shrink: 0;
    }

    .sheet-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 12px 20px 8px;
      flex-shrink: 0;
    }

    .sheet-title {
      font-size: 18px;
      font-weight: 700;
      color: var(--md-on-surface, var(--md-on-surface));
      margin: 0;
    }

    .close-btn {
      width: 40px;
      height: 40px;
      border: none;
      background: var(--md-surface-container, #EDEEF4);
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      transition: background 0.15s;
      color: var(--md-on-surface-variant, #43474E);

      &:hover {
        background: var(--md-surface-container-high, #E7E8EE);
      }

      mat-icon { font-size: 20px; width: 20px; height: 20px; }
    }

    .search-bar {
      display: flex;
      align-items: center;
      gap: 8px;
      margin: 4px 20px 12px;
      padding: 0 14px;
      height: 44px;
      background: var(--md-surface-container-low, #F2F3F9);
      border: 1.5px solid transparent;
      border-radius: 12px;
      transition: border-color 0.2s, background 0.2s;
      flex-shrink: 0;

      &:focus-within {
        border-color: var(--md-primary, var(--md-primary));
        background: var(--md-surface, #fff);
      }
    }

    .search-icon {
      font-size: 20px;
      width: 20px;
      height: 20px;
      color: var(--md-on-surface-variant, #43474E);
      flex-shrink: 0;
    }

    .search-input {
      flex: 1;
      border: none;
      background: transparent;
      outline: none;
      font-size: 14px;
      font-family: var(--font-family);
      color: var(--md-on-surface, var(--md-on-surface));
      min-width: 0;

      &::placeholder {
        color: var(--md-on-surface-variant, #43474E);
        opacity: 0.6;
      }
    }

    .clear-btn {
      width: 28px;
      height: 28px;
      border: none;
      background: transparent;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      color: var(--md-on-surface-variant);
      flex-shrink: 0;

      mat-icon { font-size: 18px; width: 18px; height: 18px; }
      &:hover { background: var(--md-surface-container-high); }
    }

    /* ============================================
       MODULE GRID - Default (larger screens)
       ============================================ */
    /* Loading / error / empty states for the permission-filtered grid. */
    .grid-state {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      gap: 10px;
      padding: 36px 24px 28px;
      color: var(--md-on-surface-variant, var(--color-text-secondary));
      font-size: 13px;
      text-align: center;

      mat-icon { font-size: 32px; width: 32px; height: 32px; opacity: 0.5; }
    }

    .error-state mat-icon { color: var(--md-error, #BA1A1A); opacity: 1; font-size: var(--font-size-7xl); width: 36px; height: 36px; }

    .retry-btn {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      padding: 7px 16px;
      border: 1px solid rgba(0, 0, 0, 0.12);
      border-radius: 999px;
      background: transparent;
      font-size: 13px;
      font-weight: 600;
      font-family: var(--font-family);
      color: var(--md-primary, var(--md-primary));
      cursor: pointer;
      transition: background 0.15s;

      mat-icon { font-size: var(--font-size-md); width: 17px; height: 17px; opacity: 1; color: inherit; }
      &:hover { background: rgba(0, 40, 142, 0.06); }
    }

    .module-grid {
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 8px;
      padding: 4px 20px 16px;
      overflow-y: auto;
      -webkit-overflow-scrolling: touch;
    }

    .module-card {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      gap: 6px;
      padding: 10px 4px 8px;
      border-radius: 14px;
      text-decoration: none;
      color: var(--md-on-surface, var(--md-on-surface));
      transition: background 0.15s, transform 0.1s;
      min-height: 80px;

      &:active {
        transform: scale(0.94);
        transition: transform 0.08s;
      }

      &:hover {
        background: var(--md-surface-container-low, #F2F3F9);
      }
    }

    .module-icon {
      width: 46px;
      height: 46px;
      border-radius: 14px;
      display: flex;
      align-items: center;
      justify-content: center;
      flex-shrink: 0;
      transition: transform 0.2s;

      .module-card:hover & {
        transform: scale(1.08);
      }

      mat-icon {
        font-size: 24px;
        width: 24px;
        height: 24px;
      }
    }

    /* ============================================
       MODULE LABEL - Always visible, no truncation
       ============================================ */
    .module-label {
      font-size: 11px;
      font-weight: 600;
      text-align: center;
      line-height: 1.3;
      color: var(--md-on-surface, var(--md-on-surface));
      word-wrap: break-word;
      overflow-wrap: break-word;
      hyphens: auto;
      width: 100%;
      padding: 0 2px;
    }

    /* Profile Section */
    .profile-section {
      flex-shrink: 0;
      padding: 0 20px 16px;
    }

    .profile-divider {
      height: 1px;
      background: var(--md-outline-variant, #C3C7CF);
      margin-bottom: 12px;
    }

    .profile-row {
      display: flex;
      align-items: center;
      gap: 12px;
      padding: 8px 0;
    }

    .profile-avatar {
      position: relative;
      flex-shrink: 0;

      .avatar-img {
        width: 40px;
        height: 40px;
        border-radius: 50%;
        object-fit: cover;
        border: 2px solid var(--md-primary-container, #D1E4FF);
      }

      .online-dot {
        position: absolute;
        bottom: 0;
        right: 0;
        width: 10px;
        height: 10px;
        background: #22c55e;
        border: 2px solid var(--md-surface, #fff);
        border-radius: 50%;
      }
    }

    .profile-info {
      flex: 1;
      min-width: 0;
      display: flex;
      flex-direction: column;

      .profile-name {
        font-size: 14px;
        font-weight: 600;
        color: var(--md-on-surface, var(--md-on-surface));
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }

      .profile-role {
        font-size: 12px;
        color: var(--md-on-surface-variant, #43474E);
        text-transform: capitalize;
      }
    }

    .settings-btn {
      width: 40px;
      height: 40px;
      border: none;
      background: transparent;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      color: var(--md-on-surface-variant);
      transition: background 0.15s;
      flex-shrink: 0;

      mat-icon { font-size: var(--font-size-xl); width: 22px; height: 22px; }
      &:hover { background: var(--md-surface-container); }
    }

    .logout-row {
      display: flex;
      align-items: center;
      gap: 12px;
      width: 100%;
      padding: 12px;
      margin-top: 8px;
      border: none;
      background: transparent;
      border-radius: 12px;
      cursor: pointer;
      transition: background 0.15s;
      color: var(--md-error, #BA1A1A);
      font-size: 14px;
      font-weight: 500;
      font-family: var(--font-family);

      .logout-icon {
        font-size: 20px;
        width: 20px;
        height: 20px;
      }

      &:hover {
        background: rgba(186, 26, 26, 0.08);
      }
    }

    /* Dark theme */
    :host-context(.dark-theme) {
      .more-sheet {
        background: var(--md-surface-container, #1E1F25);
      }

      .search-bar {
        background: var(--md-surface-container-high, #282A30);
        &:focus-within {
          background: var(--md-surface-container, #1E1F25);
        }
      }

      .module-card:hover {
        background: var(--md-surface-container-high, #282A30);
      }

      .profile-avatar .avatar-img {
        border-color: var(--md-primary-container, #1A3A6B);
      }

      .settings-btn:hover {
        background: var(--md-surface-container-high);
      }
    }

    /* ============================================
       RESPONSIVE: Small mobile screens (≤375px)
       Makes grid items, icons, and labels smaller
       but labels are ALWAYS visible
       ============================================ */
    @media (max-width: 375px) {
      .sheet-header {
        padding: 10px 16px 6px;
      }

      .sheet-title {
        font-size: 16px;
      }

      .close-btn {
        width: 36px;
        height: 36px;
        mat-icon { font-size: 18px; width: 18px; height: 18px; }
      }

      .search-bar {
        margin: 4px 16px 10px;
        height: 40px;
        padding: 0 12px;
        gap: 6px;
      }

      .search-icon {
        font-size: 18px;
        width: 18px;
        height: 18px;
      }

      .search-input {
        font-size: 13px;
      }

      .module-grid {
        grid-template-columns: repeat(4, 1fr);
        gap: 6px;
        padding: 4px 12px 12px;
      }

      .module-card {
        padding: 8px 2px 6px;
        gap: 5px;
        min-height: 70px;
        border-radius: 12px;
      }

      .module-icon {
        width: 40px;
        height: 40px;
        border-radius: 12px;

        mat-icon {
          font-size: var(--font-size-xl);
          width: 22px;
          height: 22px;
        }
      }

      .module-label {
        font-size: 10px;
        font-weight: 600;
        line-height: 1.2;
      }

      .profile-section {
        padding: 0 16px 12px;
      }

      .profile-row {
        gap: 10px;
      }

      .profile-avatar .avatar-img {
        width: 36px;
        height: 36px;
      }

      .profile-name {
        font-size: 13px;
      }

      .profile-role {
        font-size: 11px;
      }

      .settings-btn {
        width: 36px;
        height: 36px;
        mat-icon { font-size: 20px; width: 20px; height: 20px; }
      }

      .logout-row {
        padding: 10px;
        font-size: 13px;
        gap: 10px;
      }
    }

    /* ============================================
       RESPONSIVE: Extra small screens (≤320px)
       For iPhone SE, older small phones
       Labels still visible with slightly smaller size
       ============================================ */
    @media (max-width: 320px) {
      .more-sheet {
        max-height: 90vh;
      }

      .sheet-header {
        padding: 8px 12px 4px;
      }

      .sheet-title {
        font-size: var(--font-size-base);
      }

      .search-bar {
        margin: 4px 12px 8px;
        height: 38px;
        padding: 0 10px;
        border-radius: 10px;
      }

      .module-grid {
        grid-template-columns: repeat(4, 1fr);
        gap: 4px;
        padding: 2px 10px 10px;
      }

      .module-card {
        padding: 6px 2px 4px;
        gap: 4px;
        min-height: 62px;
        border-radius: 10px;
      }

      .module-icon {
        width: 36px;
        height: 36px;
        border-radius: 10px;

        mat-icon {
          font-size: 20px;
          width: 20px;
          height: 20px;
        }
      }

      .module-label {
        font-size: 9.5px;
        font-weight: 600;
        line-height: 1.2;
      }

      .profile-avatar .avatar-img {
        width: 32px;
        height: 32px;
      }

      .profile-name {
        font-size: 12px;
      }

      .profile-role {
        font-size: 10px;
      }
    }

    /* ============================================
       RESPONSIVE: Tablets (≥768px)
       ============================================ */
    @media (min-width: 768px) {
      .more-sheet {
        max-width: 480px;
        border-radius: 24px;
        margin-bottom: 16px;
      }
    }
  `]
})
export class MoreMenuComponent implements OnInit, OnDestroy {
  @Output() closeMenu = new EventEmitter<void>();
  @HostListener("document:keydown.escape")
  onEscapeKey(): void { this.close(); }

  searchTerm = '';
  user: any = null;
  avatarUrl = '';

  /** Permission-filtered module cards (built live from the dynamic menu —
   *  the same server-filtered tree the desktop sidebar renders). The sheet
   *  starts empty and renders only after the user's menu arrives, so
   *  unauthorized modules are never visible, not even while loading. */
  allItems: MoreMenuItem[] = [];

  filteredItems: MoreMenuItem[] = [];

  loading = false;
  error: string | null = null;

  private menuSub: { unsubscribe(): void } | null = null;

  /** Category name (backend MenuItem.Category) → accent color for the icon tile. */
  private static readonly categoryColors: Record<string, string> = {
    'academic': 'var(--md-primary)',
    'academics': 'var(--md-primary)',
    'finance': 'var(--md-success)',
    'fees': 'var(--md-success)',
    'people': '#6A1B9A',
    'staff': '#6A1B9A',
    'students': 'var(--md-primary-light)',
    'infrastructure': 'var(--md-warning)',
    'facilities': 'var(--md-warning)',
    'analytics': '#00695C',
    'reports': '#00695C',
    'communication': '#2563EB',
    'admin': '#455A64',
    'administration': '#455A64'
  };

  constructor(
    private router: Router,
    private authService: AuthService,
    private menuService: DynamicMenuService
  ) {}

  ngOnInit(): void {
    this.user = this.authService.getCurrentUser();
    if (this.user) {
      const name = this.user.username || this.user.name || 'User';
      this.avatarUrl = `https://ui-avatars.com/api/?name=${encodeURIComponent(name)}&background=1565C0&color=fff&size=80&bold=true`;
    }

    // Start empty — never render an unfiltered list.
    this.filteredItems = [];

    // Render the permission-filtered menu tree the moment it arrives (it is
    // usually already cached from the sidebar/bottom-nav load). This keeps
    // the sheet in lock-step with the authenticated user's permissions.
    this.menuSub = this.menuService.mainMenu$.subscribe(() => {
      this.rebuildItems();
    });
    this.menuService.loading$.subscribe(l => { this.loading = l; });
    this.menuService.error$.subscribe(err => {
      this.error = err;
      if (err && this.menuService.getMainMenuSync().length === 0) { this.rebuildItems(); }
    });
    // Menu was never loaded before opening this sheet → load it now.
    if (this.menuService.getMainMenuSync().length === 0) {
      this.menuService.loadMainMenu().subscribe({ error: () => { /* error$ drives the UI */ } });
    } else {
      this.rebuildItems();
    }
  }

  ngOnDestroy(): void {
    this.menuSub?.unsubscribe();
  }

  retryLoadMenu(): void {
    this.menuService.refreshMenu().subscribe({ error: () => { /* error$ drives the UI */ } });
  }

  /**
   * Flatten the server-filtered menu tree into module cards. Only items that
   * actually navigate (have a route, are active) become cards — nested items
   * are included recursively. Unauthorized items are already absent from the
   * tree: /api/menu/main filters by the authenticated user's permissions,
   * tenant and role before responding.
   */
  private rebuildItems(): void {
    const menu = this.menuService.getMainMenuSync();
    this.allItems = [];

    const walk = (items: MenuItem[]) => {
      for (const item of items) {
        if (item.route && item.isActive !== false) {
          this.allItems.push({
            icon: item.icon,
            label: item.label,
            route: item.route,
            color: this.colorForCategory(item.category)
          });
        }
        if (item.children && item.children.length > 0) {
          walk(item.children);
        }
      }
    };
    walk(menu);

    this.filterItems();
  }

  private colorForCategory(category?: string): string {
    const key = (category || '').toLowerCase().trim();
    return MoreMenuComponent.categoryColors[key] ?? 'var(--md-primary)';
  }

  filterItems(): void {
    if (!this.searchTerm.trim()) {
      this.filteredItems = [...this.allItems];
      return;
    }
    const term = this.searchTerm.toLowerCase();
    this.filteredItems = this.allItems.filter(item =>
      item.label.toLowerCase().includes(term)
    );
  }

  navigateTo(item: MoreMenuItem): void {
    this.router.navigate([item.route]);
    this.close();
  }

  close(): void {
    this.closeMenu.emit();
  }

  openSettings(): void {
    this.router.navigate(['/app/settings']);
    this.close();
  }

  logout(): void {
    this.authService.logout();
    this.close();
  }
}
