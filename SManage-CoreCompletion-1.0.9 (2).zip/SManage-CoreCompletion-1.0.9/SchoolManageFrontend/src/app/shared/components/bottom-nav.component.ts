import { Component, Input, Output, EventEmitter, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { MatRippleModule } from '@angular/material/core';
import { RouterModule } from '@angular/router';

export interface BottomNavItem {
  icon: string;
  label: string;
  route?: string;
  badge?: number;
  isMore?: boolean;
}

@Component({
  selector: 'app-bottom-nav',
  standalone: true,
  imports: [CommonModule, MatIconModule, MatRippleModule, RouterModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <nav class="bottom-nav" [class.elevated]="elevated" role="navigation" aria-label="Main navigation">
      <a *ngFor="let item of items; trackBy: trackByLabel"
         class="nav-item"
         [class.is-more]="item.isMore"
         [routerLink]="item.route || null"
         [routerLinkActive]="'active'"
         [routerLinkActiveOptions]="{exact: item.route === '/app/dashboard'}"
         (click)="onItemClick(item)"
         matRipple
         [matRippleCentered]="true"
         [matRippleUnbounded]="true"
         [matRippleRadius]="28"
         [attr.aria-label]="item.label + (item.badge ? ', ' + item.badge + ' pending' : '')"
         [attr.aria-current]="item.route ? 'page' : undefined"
         role="tab">
        <div class="nav-icon-wrapper">
          <mat-icon class="nav-icon">{{ item.icon }}</mat-icon>
          <span *ngIf="item.badge && item.badge > 0"
                class="nav-badge"
                role="status"
                [attr.aria-label]="item.badge + ' notifications'">
            {{ item.badge > 99 ? '99+' : item.badge }}
          </span>
        </div>
        <span class="nav-label">{{ item.label }}</span>
        <div class="active-pill"></div>
      </a>
    </nav>
  `,
  styles: [`
    :host {
      display: block;
      position: fixed;
      bottom: 0;
      left: 0;
      right: 0;
      z-index: var(--z-nav, 100);
      padding-bottom: env(safe-area-inset-bottom, 0px);
    }

    .bottom-nav {
      display: flex;
      align-items: stretch;
      justify-content: space-around;
      background: rgba(255, 255, 255, 0.95);
      backdrop-filter: blur(20px) saturate(180%);
      -webkit-backdrop-filter: blur(20px) saturate(180%);
      border-top: 1px solid rgba(0, 0, 0, 0.08);
      height: 56px;
      transition: box-shadow 0.2s ease;
      box-shadow: 0 -1px 0 rgba(0, 0, 0, 0.04);

      &.elevated {
        box-shadow: 0 -2px 10px rgba(0, 0, 0, 0.06);
      }
    }

    :host-context(.dark-theme) .bottom-nav {
      background: rgba(18, 19, 24, 0.96);
      border-top-color: rgba(255, 255, 255, 0.08);
      box-shadow: 0 -1px 8px rgba(0, 0, 0, 0.4);
    }

    .nav-item {
      flex: 1;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      gap: 2px;
      text-decoration: none;
      color: var(--md-on-surface-variant, var(--color-text-secondary));
      padding: 4px 0 6px;
      position: relative;
      transition: color 0.2s cubic-bezier(0.2, 0, 0, 1);
      -webkit-tap-highlight-color: transparent;
      cursor: pointer;
      min-width: 44px;
      min-height: 44px;
      outline: none;

      &:focus-visible {
        outline: 2px solid var(--md-primary, var(--md-primary));
        outline-offset: -2px;
        border-radius: 10px;
      }

      &:active {
        transform: scale(0.9);
        transition: transform 0.08s ease;
      }

      &.is-active, &.active {
        color: var(--md-primary, var(--md-primary));
        /* keep translateX(-50%) — without it the pill anchors at left:50%
           and the higher specificity of this rule breaks centering */
        .active-pill { transform: translateX(-50%) scaleX(1); opacity: 1; }
        .nav-icon { transform: translateY(-1px); }
        .nav-label { font-weight: 700; color: var(--md-primary, var(--md-primary)); }
      }
    }

    .nav-icon-wrapper {
      position: relative;
      display: flex;
      align-items: center;
      justify-content: center;
      width: 40px;
      height: 28px;
      border-radius: var(--radius-full, 9999px);
      transition: background-color 0.25s cubic-bezier(0.2, 0, 0, 1);
    }

    /* Active state: reference's tinted pill behind the icon
       ([&>div]:bg-surface-container [&>div]:text-primary-interactive) */
    .is-active .nav-icon-wrapper, .active .nav-icon-wrapper {
      background: var(--md-surface-container, #eaedff);
      color: var(--md-primary-interactive, #2563eb);
    }
    .is-active .nav-icon, .active .nav-icon {
      color: var(--md-primary-interactive, #2563eb);
    }

    .nav-icon {
      font-size: var(--font-size-xl);
      width: 22px;
      height: 22px;
      transition: transform 0.25s cubic-bezier(0.2, 0, 0, 1);
    }

    .nav-badge {
      position: absolute;
      top: -6px;
      right: -2px;
      min-width: 16px;
      height: 16px;
      padding: 0 4px;
      background: var(--md-error, #BA1A1A);
      color: white;
      font-size: 9px;
      font-weight: 700;
      border-radius: 8px;
      display: flex;
      align-items: center;
      justify-content: center;
      line-height: 1;
      box-shadow: 0 1px 3px rgba(186, 26, 26, 0.3);
      animation: badgePulse 2s ease-in-out infinite;
    }

    .nav-label {
      font-size: 10px;
      font-weight: 500;
      letter-spacing: 0.01em;
      line-height: 1;
      white-space: nowrap;
      max-width: 56px;
      overflow: hidden;
      text-overflow: ellipsis;
    }

    .active-pill {
      position: absolute;
      top: 2px;
      left: 50%;
      transform: translateX(-50%) scaleX(0);
      width: 28px;
      height: 2.5px;
      background: var(--md-primary, var(--md-primary));
      border-radius: 2px 2px 0 0;
      transition: transform 0.3s cubic-bezier(0.2, 0, 0, 1), opacity 0.2s ease;
      opacity: 0;
    }

    .is-active .active-pill, .active .active-pill {
      transform: translateX(-50%) scaleX(1);
      opacity: 1;
    }

    @keyframes badgePulse {
      0%, 100% { transform: scale(1); }
      50% { transform: scale(1.05); }
    }

    /* Respect user motion preferences */
    @media (prefers-reduced-motion: reduce) {
      .nav-badge { animation: none; }
      .nav-item:active { transform: none; }
      .active-pill { transition: opacity 0.2s ease; transform: translateX(-50%) scaleX(0); }
    }

    /* Extra small screens (iPhone SE, etc.) */
    @media (max-width: 320px) {
      .bottom-nav {
        height: 52px;
      }
      .nav-item {
        padding: 3px 0 5px;
        min-width: 40px;
        gap: 1px;
      }
      .nav-icon {
        font-size: 20px;
        width: 20px;
        height: 20px;
      }
      .nav-icon-wrapper {
        width: 36px;
        height: 24px;
      }
      .nav-label {
        font-size: 9px;
        max-width: 48px;
      }
      .active-pill {
        width: 24px;
        height: 2px;
      }
    }

    /* Small phones (iPhone 12 mini, etc.) */
    @media (min-width: 321px) and (max-width: 375px) {
      .nav-label {
        font-size: 10px;
        max-width: 52px;
      }
    }

    @media (min-width: 840px) {
      :host { display: none; }
    }
  `]
})
export class BottomNavComponent {
  @Input() items: BottomNavItem[] = [
    { icon: 'home', label: 'Home', route: '/app/dashboard' },
    { icon: 'school', label: 'Students', route: '/app/students/full-details' },
    { icon: 'payments', label: 'Fees', route: '/app/fees/dashboard' },
    { icon: 'event_available', label: 'Attendance', route: '/app/attendance' },
    { icon: 'more_horiz', label: 'More', isMore: true }
  ];
  @Input() elevated = true;
  @Output() moreClick = new EventEmitter<void>();

  onItemClick(item: BottomNavItem): void {
    if (item.isMore) { this.moreClick.emit(); }
  }

  trackByLabel(index: number, item: BottomNavItem): string { return item.label; }
}
