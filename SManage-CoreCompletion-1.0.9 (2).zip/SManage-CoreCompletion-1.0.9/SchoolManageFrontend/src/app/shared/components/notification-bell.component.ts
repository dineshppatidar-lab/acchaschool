import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatTooltipModule } from '@angular/material/tooltip';

import { NotificationStreamService, AppNotification } from '../../services/notification-stream.service';

/** Icon for a notification event type (Material icon name). */
function iconFor(type: string): string {
  const t = (type || '').toLowerCase();
  if (t.includes('announce')) return 'campaign';
  if (t.includes('fee')) return 'payments';
  if (t.includes('exam') || t.includes('result')) return 'grading';
  if (t.includes('assignment')) return 'assignment';
  if (t.includes('attendance') || t.includes('absent')) return 'event_available';
  if (t.includes('book') || t.includes('library')) return 'menu_book';
  if (t.includes('meeting')) return 'groups';
  if (t.includes('message')) return 'chat';
  if (t.includes('progress')) return 'trending_up';
  if (t.includes('system')) return 'settings_alert';
  return 'notifications';
}

@Component({
  selector: 'app-notification-bell',
  standalone: true,
  imports: [CommonModule, MatIconModule, MatButtonModule, MatTooltipModule],
  template: `
    <div class="notif-pop" (click)="$event.stopPropagation()">
      <div class="notif-head">
        <span class="notif-title">Notifications</span>
        <span class="unread-chip" [class.muted]="stream.unreadCount() === 0">
          {{ stream.unreadCount() }} new
        </span>
        <button mat-icon-button class="mark-all" matTooltip="Mark all as read" (click)="stream.markAllRead()"
                [disabled]="stream.unreadCount() === 0">
          <mat-icon>done_all</mat-icon>
        </button>
      </div>

      <div class="notif-list">
        <div class="notif-empty" *ngIf="stream.notifications().length === 0">
          <mat-icon>notifications_off</mat-icon>
          <p>No notifications yet</p>
          <span>Fee, exam, announcement and system events will appear here.</span>
        </div>

        <button type="button" class="notif-item"
                *ngFor="let n of stream.notifications(); trackBy: trackById"
                [class.unread]="!n.isRead"
                (click)="onOpen(n)">
          <span class="notif-ico"><mat-icon>{{ iconFor(n.type) }}</mat-icon></span>
          <span class="notif-body">
            <span class="notif-row1">
              <span class="notif-heading">{{ n.title || 'Notification' }}</span>
              <span class="notif-time">{{ timeAgo(n.createdOn) }}</span>
            </span>
            <span class="notif-msg">{{ n.message }}</span>
            <span class="notif-open-hint" *ngIf="n.link">Open →</span>
          </span>
          <span class="notif-del" mat-icon-button matTooltip="Delete"
                (click)="onDelete($event, n)">
            <mat-icon>close</mat-icon>
          </span>
        </button>
      </div>

      <div class="notif-foot" *ngIf="stream.notifications().length > 0">
        <button mat-button (click)="stream.refresh()">
          <mat-icon>refresh</mat-icon> Refresh
        </button>
      </div>
    </div>
  `,
  styles: [`
    :host { display: block; }
    .notif-pop {
      width: 380px; max-width: 92vw;
      background: #fff; border-radius: 14px;
      box-shadow: 0 12px 40px rgba(16,42,84,.18), 0 2px 8px rgba(16,42,84,.08);
      overflow: hidden; display: flex; flex-direction: column;
      max-height: 520px;
    }
    .notif-head {
      display: flex; align-items: center; gap: 8px;
      padding: 12px 14px; border-bottom: 1px solid #eef1f6;
      .notif-title { font-weight: 700; font-size: var(--font-size-base); color: #102a54; }
      .unread-chip {
        background: var(--md-error); color: #fff; font-size: 11px; font-weight: 600;
        border-radius: 999px; padding: 2px 8px;
        &.muted { background: #eceff4; color: #6b7a90; }
      }
      .mark-all { margin-left: auto; }
    }
    .notif-list { overflow-y: auto; }
    .notif-empty {
      display: flex; flex-direction: column; align-items: center; gap: 6px;
      padding: 36px 16px; color: #6b7a90; text-align: center;
      mat-icon { font-size: var(--font-size-7xl); width: 36px; height: 36px; color: #b7c2d4; }
      p { margin: 0; font-weight: 600; color: #3c4c66; }
      span { font-size: 12.5px; }
    }
    .notif-item {
      display: flex; gap: 10px; width: 100%; text-align: left;
      padding: 11px 14px; border: 0; border-bottom: 1px solid #f1f4f9;
      background: #fff; cursor: pointer; align-items: flex-start;
      &:hover { background: #f6f9ff; }
      &.unread { background: #eef5ff; &:hover { background: #e4f0ff; } }
      .notif-ico {
        width: 34px; height: 34px; border-radius: 10px; flex: 0 0 34px;
        background: var(--md-surface-container-low); display: grid; place-items: center; color: var(--md-primary);
        mat-icon { font-size: 19px; width: 19px; height: 19px; }
      }
      .notif-body { flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 2px; }
      .notif-row1 { display: flex; justify-content: space-between; gap: 8px; }
      .notif-heading { font-weight: 600; font-size: 13.5px; color: #16233c;
                       overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
      .notif-time { font-size: 11px; color: #8b98ad; flex: 0 0 auto; }
      .notif-msg { font-size: 12.5px; color: #4d5d77;
                   display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }
      .notif-open-hint { font-size: 11.5px; color: var(--md-primary); font-weight: 600; }
      .notif-del {
        flex: 0 0 auto; color: #a5b0c2; width: 26px; height: 26px;
        display: grid; place-items: center; border-radius: 6px;
        &:hover { color: #d93025; background: #fdeceb; }
        mat-icon { font-size: var(--font-size-base); width: 15px; height: 15px; }
      }
    }
    .notif-foot {
      border-top: 1px solid #eef1f6; display: flex; justify-content: center;
      padding: 4px;
    }
  `]
})
export class NotificationBellComponent {
  readonly stream = inject(NotificationStreamService);

  iconFor = iconFor;

  trackById(_i: number, n: AppNotification): number { return n.id; }

  onOpen(n: AppNotification): void { this.stream.open(n); }

  onDelete(ev: MouseEvent, n: AppNotification): void {
    ev.stopPropagation();
    this.stream.remove(n);
  }

  timeAgo(iso: string): string {
    const then = new Date(iso).getTime();
    if (Number.isNaN(then)) return '';
    const mins = Math.floor((Date.now() - then) / 60000);
    if (mins < 1) return 'just now';
    if (mins < 60) return `${mins}m ago`;
    const hrs = Math.floor(mins / 60);
    if (hrs < 24) return `${hrs}h ago`;
    const days = Math.floor(hrs / 24);
    if (days < 7) return `${days}d ago`;
    return new Date(iso).toLocaleDateString();
  }
}
