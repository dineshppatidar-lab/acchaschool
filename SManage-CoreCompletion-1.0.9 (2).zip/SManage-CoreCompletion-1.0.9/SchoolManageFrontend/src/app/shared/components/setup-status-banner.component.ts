import { Component, ChangeDetectorRef, computed, inject, signal } from '@angular/core';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatTooltipModule } from '@angular/material/tooltip';
import { SetupStatusService, SetupStatusItem } from '../../core/services/setup-status.service';

/**
 * Persistent "Complete your school setup" banner.
 *
 * Enterprise-onboarding style: shows required-only progress, expands a
 * checklist of remaining steps with direct navigation links, and disappears
 * automatically once all required steps are completed. Fully responsive:
 * compact single-row layout on mobile with the checklist opening below.
 */
@Component({
  selector: 'app-setup-status-banner',
  standalone: true,
  imports: [CommonModule, MatButtonModule, MatIconModule, MatProgressBarModule, MatTooltipModule],
  template: `
    @if (setup.canViewSetupStatus() && setup.showSetupUi()) {
      <div class="setup-banner" role="status" [class.expanded]="expanded()">
        <div class="banner-main">
          <div class="banner-icon">
            <mat-icon>{{ expanded() ? 'expand_less' : 'school' }}</mat-icon>
          </div>

          <button type="button" class="banner-text" (click)="toggle()" aria-label="Toggle setup checklist">
            <span class="banner-title">
              School setup is incomplete
              <mat-icon class="chevron">{{ expanded() ? 'keyboard_arrow_up' : 'keyboard_arrow_down' }}</mat-icon>
            </span>
            <span class="banner-sub desktop-only">
              {{ setup.status()!.completedCount }} of {{ setup.status()!.requiredCount }} required steps completed
              &middot; {{ setup.status()!.completionPercentage }}%
            </span>
            <!-- Mobile: compact inline progress -->
            <span class="banner-progress mobile-progress">
              <mat-progress-bar mode="determinate" [value]="setup.status()!.completionPercentage"></mat-progress-bar>
            </span>
          </button>

          <div class="banner-progress desktop-progress">
            <div class="progress-track">
              <div class="progress-fill" [style.width.%]="setup.status()!.completionPercentage"></div>
            </div>
            <span class="progress-pct">{{ setup.status()!.completionPercentage }}%</span>
          </div>

          <button mat-flat-button color="primary" class="continue-btn" (click)="continueSetup()">
            <mat-icon>arrow_forward</mat-icon>
            <span class="desktop-only">Continue Setup</span>
            <span class="mobile-only">Setup</span>
          </button>

          <button mat-icon-button class="expand-btn" (click)="toggle()"
                  [matTooltip]="expanded() ? 'Hide remaining steps' : 'Show remaining steps'">
            <mat-icon>{{ expanded() ? 'expand_less' : 'expand_more' }}</mat-icon>
          </button>
        </div>

        @if (expanded()) {
          <div class="banner-checklist">
            <div class="checklist-head desktop-only">Remaining setup steps</div>
            @for (item of setup.status()!.items; track item.key) {
              <a class="check-item" [class.done]="item.isCompleted" [class.optional]="!item.isRequired"
                 (click)="goToStep(item, $event)">
                <mat-icon class="check-icon">{{ item.isCompleted ? 'check_circle' : (item.isRequired ? 'error_outline' : 'radio_button_unchecked') }}</mat-icon>
                <span class="check-name">{{ item.name }}</span>
                @if (!item.isRequired) {
                  <span class="check-tag optional-tag">Optional</span>
                } @else if (!item.isCompleted) {
                  <span class="check-tag required-tag">Required</span>
                }
                <span class="check-desc desktop-only">{{ item.description }}</span>
                @if (!item.isCompleted) {
                  <span class="check-action">Complete<mat-icon>chevron_right</mat-icon></span>
                }
              </a>
            }
          </div>
        }
      </div>
    }
  `,
  styles: [`
    :host { display: block; }
    .setup-banner {
      background: var(--md-primary-container, #D1E4FF);
      border-bottom: 1px solid rgba(13, 71, 161, .15);
      color: var(--md-on-primary-container, #001D36);
      transition: box-shadow .2s ease;
    }
    .setup-banner.expanded { box-shadow: 0 4px 14px rgba(13, 71, 161, .12); }
    .banner-main {
      display: flex; align-items: center; gap: 12px;
      padding: 8px 16px; max-width: 100%;
    }
    .banner-icon {
      width: 34px; height: 34px; border-radius: 50%;
      background: var(--md-primary, var(--md-primary)); color: #fff;
      display: flex; align-items: center; justify-content: center; flex-shrink: 0;
    }
    .banner-icon mat-icon { font-size: 20px; width: 20px; height: 20px; }
    .banner-text {
      display: flex; flex-direction: column; align-items: flex-start;
      background: none; border: none; cursor: pointer; padding: 0;
      color: inherit; font: inherit; text-align: left; min-width: 0;
    }
    .banner-title {
      font-size: 14px; font-weight: 700; display: inline-flex; align-items: center; gap: 4px;
      white-space: nowrap;
    }
    .chevron { font-size: 16px; width: 16px; height: 16px; opacity: .7; }
    .banner-sub { font-size: 12px; opacity: .85; }
    .banner-progress { flex: 1 1 auto; min-width: 80px; }
    .desktop-progress { display: flex; align-items: center; gap: 8px; }
    .progress-track {
      width: 160px; height: 6px; border-radius: 3px;
      background: rgba(13, 71, 161, .18); overflow: hidden;
    }
    .progress-fill {
      height: 100%; border-radius: 3px;
      background: var(--md-primary, var(--md-primary)); transition: width .4s ease;
    }
    .progress-pct { font-size: 12px; font-weight: 700; }
    .mobile-progress { display: none; }
    .continue-btn { flex-shrink: 0; }
    .expand-btn { color: inherit; opacity: .75; }

    .banner-checklist {
      padding: 4px 16px 12px 62px;
      display: flex; flex-direction: column; gap: 2px;
    }
    .checklist-head {
      font-size: 11px; font-weight: 700; letter-spacing: .5px; text-transform: uppercase;
      opacity: .6; margin-bottom: 4px;
    }
    .check-item {
      display: flex; align-items: center; gap: 8px;
      padding: 6px 8px; border-radius: 8px; cursor: pointer;
      color: inherit; text-decoration: none; font-size: 13px;
    }
    .check-item:hover { background: rgba(13, 71, 161, .08); }
    .check-item.done { opacity: .65; }
    .check-icon { font-size: 18px; width: 18px; height: 18px; flex-shrink: 0; }
    .check-item.done .check-icon { color: var(--md-success); }
    .check-item:not(.done) .check-icon.required-flag { color: var(--md-warning, var(--md-warning)); }
    .check-name { font-weight: 600; white-space: nowrap; }
    .check-desc { font-size: 12px; opacity: .7; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; flex: 1; }
    .check-tag {
      font-size: 10px; font-weight: 700; padding: 1px 7px; border-radius: 8px;
      text-transform: uppercase; letter-spacing: .4px; flex-shrink: 0;
    }
    .required-tag { background: rgba(230, 81, 0, .15); color: var(--md-warning, var(--md-warning)); }
    .optional-tag { background: rgba(0, 0, 0, .08); color: rgba(0, 0, 0, .55); }
    .check-action {
      margin-left: auto; display: inline-flex; align-items: center;
      font-size: 12px; font-weight: 700; color: var(--md-primary, var(--md-primary)); flex-shrink: 0;
    }
    .check-action mat-icon { font-size: 16px; width: 16px; height: 16px; }

    /* Mobile: compact single row, checklist below */
    @media (max-width: 768px) {
      .desktop-only { display: none !important; }
      .mobile-only { display: inline-flex; }
      .banner-main { padding: 8px 12px; gap: 8px; flex-wrap: nowrap; }
      .banner-icon { display: none; }
      .banner-progress { display: none; }
      .mobile-progress {
        display: block; width: 130px; margin-top: 2px;
      }
      .banner-checklist { padding: 2px 12px 10px 12px; }
      .check-desc { display: none; }
      .expand-btn { display: none; }
    }
    .mobile-only { display: none; }
  `]
})
export class SetupStatusBannerComponent {
  readonly setup = inject(SetupStatusService);
  private readonly router = inject(Router);
  private readonly cdr = inject(ChangeDetectorRef);

  readonly expanded = signal(false);

  /** Remaining required steps, for the "Continue Setup" jump target. */
  readonly nextIncomplete = computed<SetupStatusItem | null>(() =>
    this.setup.incompleteRequired()[0] ?? null
  );

  toggle(): void {
    this.expanded.update(v => !v);
    this.cdr.detectChanges();
  }

  continueSetup(): void {
    // Prefer navigating into the wizard itself (covers all steps).
    this.router.navigate(['/app/setup']);
  }

  goToStep(item: SetupStatusItem, event: Event): void {
    event.preventDefault();
    event.stopPropagation();
    if (item.isCompleted) return;
    this.router.navigateByUrl(item.route || '/app/setup');
  }
}
