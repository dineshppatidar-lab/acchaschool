import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressBarModule } from '@angular/material/progress-bar';

export type StudentKpiTone = 'primary' | 'success' | 'warn' | 'danger' | 'info' | 'neutral' | 'accent';

/**
 * One summary card used by every Students page (Total Enrolled, Male,
 * Female, Active Ratio, ...), matching the Advanced Finance page's
 * `.summary-card` pattern: mat-card + 48px plain colored icon +
 * 24px value + var(--color-text-secondary) label.
 *
 * An optional ratio (0–100) renders a thin progress bar under the
 * value, preserving the gender/active split info the directory shows.
 *
 * Wrap instances in `<div class="stu-kpi-grid">…</div>`
 * (auto-fit minmax(280px, 1fr), 20px gap — same as AF).
 */
@Component({
  selector: 'app-student-kpi-card',
  standalone: true,
  imports: [CommonModule, MatCardModule, MatIconModule, MatProgressBarModule],
  template: `
    <mat-card class="stu-kpi" [class]="'tone-' + tone">
      <mat-card-content>
        <div class="kpi-content">
          <mat-icon class="kpi-icon">{{ icon }}</mat-icon>
          <div class="kpi-info">
            <h3 class="kpi-value">{{ value }}</h3>
            <p class="kpi-label">{{ label }}</p>
            @if (progress !== null) {
              <mat-progress-bar class="kpi-progress" mode="determinate" [value]="progress" />
            }
          </div>
        </div>
      </mat-card-content>
    </mat-card>
  `,
})
export class StudentKpiCardComponent {
  @Input({ required: true }) value: string | number = '';
  @Input({ required: true }) label = '';
  @Input() icon = 'school';
  @Input() tone: StudentKpiTone = 'primary';
  /** Optional 0–100 ratio rendered as a thin progress bar. */
  @Input() progress: number | null = null;
}
