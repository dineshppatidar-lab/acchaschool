import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { BackButtonComponent } from '../back-button.component';

/**
 * Unified page header for every Students module page, matching the
 * Advanced Finance Management / Fees module pattern:
 *
 *   [back] Title
 *          Subtitle
 *   [projected actions row]
 *
 * Actions are projected so callers keep full control of permission
 * directives and button variants (raised primary / stroked secondary).
 */
@Component({
  selector: 'app-student-page-header',
  standalone: true,
  imports: [CommonModule, MatCardModule, BackButtonComponent],
  template: `
    <div class="stu-page-header">
      <div class="sph-title-row">
        @if (showBack) {
          <app-back-button />
        }
        <div class="sph-text">
          <h1 class="sph-title">{{ title }}</h1>
          @if (subtitle) {
            <p class="sph-subtitle">{{ subtitle }}</p>
          }
        </div>
      </div>
      @if (actions) {
        <div class="sph-actions">
          <ng-content select="[headerActions]"></ng-content>
          <ng-content select="[headerActionsEnd]"></ng-content>
        </div>
      }
    </div>
  `,
})
export class StudentPageHeaderComponent {
  @Input() title = '';
  @Input() subtitle = '';
  /** Set false when a parent page already renders its own back navigation. */
  @Input() showBack = true;
  /** Hide the (empty) actions row entirely. */
  @Input() get actions(): boolean {
    return this._actions;
  }
  set actions(v: boolean) {
    this._actions = v ?? true;
  }
  private _actions = true;
}
