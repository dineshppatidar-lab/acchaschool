import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Router } from '@angular/router';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatListModule } from '@angular/material/list';
import { MatTooltipModule } from '@angular/material/tooltip';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { MenuItem, DynamicMenuService } from '../../services/dynamic-menu.service';

/**
 * Recursive menu item component for displaying hierarchical menu items.
 * This component displays a single menu item and recursively renders its children.
 */
@Component({
  selector: 'app-dynamic-menu-item',
  standalone: true,
  imports: [
    CommonModule,
    RouterModule,
    MatIconModule,
    MatButtonModule,
    MatListModule,
    MatTooltipModule
  ],
  templateUrl: './dynamic-menu-item.component.html',
  styleUrls: ['./dynamic-menu-item.component.scss'],
  animations: [
    trigger('expandCollapse', [
      state('collapsed', style({
        height: '0',
        overflow: 'hidden',
        opacity: '0'
      })),
      state('expanded', style({
        height: '*',
        overflow: 'visible',
        opacity: '1'
      })),
      transition('collapsed <=> expanded', [
        animate('250ms ease-in-out')
      ])
    ])
  ]
})
export class DynamicMenuItemComponent {
  /**
   * The menu item to display
   */
  @Input() item!: MenuItem;

  /**
   * The nesting level (used for indentation)
   */
  @Input() level: number = 0;

  /**
   * Maximum nesting level before stopping recursion
   */
  @Input() maxLevel: number = 5;

  /**
   * Emitted when user navigates to a menu item
   */
  @Output() navigate = new EventEmitter<MenuItem>();

  /**
   * Whether the item is expanded (for parent items with children)
   */
  isExpanded = false;

  /**
   * Indentation in pixels per level
   */
  readonly indentPerLevel = 24;

  constructor(
    private menuService: DynamicMenuService,
    private router: Router
  ) {}

  /**
   * Get the indent style for nested items
   */
  get indentStyle(): string {
    return `${this.level * this.indentPerLevel}px`;
  }

  /**
   * Check if this item can expand (has children)
   */
  get canExpand(): boolean {
    return !!(this.item.children && this.item.children.length > 0);
  }

  /**
   * Get visible children (filtered by permissions)
   */
  get visibleChildren(): MenuItem[] {
    if (!this.item.children) {
      return [];
    }

    return this.item.children.filter((child: MenuItem) => 
      this.menuService.hasPermission(child)
    );
  }

  /**
   * Check if this is an external link
   */
  get isExternalUrl(): boolean {
    return !!(this.item.externalUrl || (this.item.openInNewTab && this.item.route?.startsWith('http')));
  }

  /**
   * Get the target for external links
   */
  get externalTarget(): string {
    return this.item.openInNewTab ? '_blank' : '_self';
  }

  /**
   * Get external URL
   */
  get externalUrl(): string {
    return this.item.externalUrl || this.item.route || '';
  }

  /**
   * Get badge content
   */
  get badgeText(): string {
    return this.item.badge || '';
  }

  /**
   * Check if badge should be displayed
   */
  get showBadge(): boolean {
    return !!(this.item.badge && this.item.badge.trim().length > 0);
  }

  /**
   * Toggle expand/collapse state
   */
  toggleExpand(event: Event): void {
    event.stopPropagation();
    if (this.canExpand) {
      this.isExpanded = !this.isExpanded;
    }
  }

  /**
   * Handle menu item click/navigation
   */
  onItemClick(event: Event): void {
    event.stopPropagation();

    if (this.item.disabled) {
      return;
    }

    // If item has children, expand/collapse instead of navigate
    if (this.canExpand && !this.item.route) {
      this.toggleExpand(event);
      return;
    }

    // Emit navigation event
    this.navigate.emit(this.item);

    // Navigate if internal route is specified
    if (this.item.route && !this.isExternalUrl) {
      this.router.navigate([this.item.route]);
    }

    // For parent items with route, navigate but keep menu expanded for context
    if (this.canExpand && this.item.route && !this.isExternalUrl) {
      this.isExpanded = true;
    }
  }

  /**
   * Handle external link click
   */
  onExternalLinkClick(event: Event): void {
    event.stopPropagation();
    if (this.isExternalUrl && this.externalUrl) {
      window.open(this.externalUrl, this.externalTarget);
    }
  }

  /**
   * Get icon name for expand/collapse indicator
   */
  get expandIconName(): string {
    if (!this.canExpand) {
      return '';
    }
    return this.isExpanded ? 'expand_less' : 'expand_more';
  }

  /**
   * Get CSS classes for the menu item
   */
  get itemClasses(): string {
    const classes = [
      'menu-item',
      `level-${this.level}`
    ];

    if (this.item.disabled) {
      classes.push('disabled');
    }

    if (this.canExpand) {
      classes.push('parent-item');
    }

    if (this.isExpanded) {
      classes.push('expanded');
    }

    return classes.join(' ');
  }

  /**
   * Get animation state for children
   */
  get childrenAnimationState(): string {
    return this.isExpanded ? 'expanded' : 'collapsed';
  }

  /**
   * TrackBy function for ngFor optimization
   */
  trackByItemId(index: number, item: MenuItem): number {
    return item.id;
  }
}