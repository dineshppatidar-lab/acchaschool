import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';

export type FeeStatus =
  | 'paid' | 'partial' | 'pending' | 'overdue'
  | 'cancelled' | 'refunded' | 'waived' | 'discounted'
  | 'active' | 'inactive' | 'approved' | 'rejected'
  | 'info' | 'warn' | 'danger';

/**
 * Unified status badge for the Fees module. Renders a pill with a colored dot
 * plus a text label so status is never communicated by color alone (a11y).
 *
 * The visual treatment lives in the global `.fee-badge` CSS layer; this
 * component only normalizes the label and tone mapping. Unknown statuses
 * fall back to `pending` styling so new API values never render unstyled.
 */
@Component({
  selector: 'app-fee-status-badge',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  template: `
    <span class="fee-badge" [class]="'fee-badge-' + tone()">{{ label() }}</span>
  `,
})
export class FeeStatusBadgeComponent {
  @Input({ required: true }) status!: string;
  /** Optional explicit label; defaults to a Title Case of the status. */
  @Input() labelOverride?: string;

  tone(): string {
    const s = (this.status || 'pending').toLowerCase().replace(/[\s_]+/g, '-');
    const map: Record<string, string> = {
      'paid': 'paid',
      'fully-paid': 'paid',
      'complete': 'paid',
      'completed': 'paid',
      'partial': 'partial',
      'partially-paid': 'partial',
      'half-paid': 'partial',
      'pending': 'pending',
      'unpaid': 'pending',
      'due': 'pending',
      'overdue': 'overdue',
      'cancelled': 'cancelled',
      'canceled': 'cancelled',
      'refunded': 'refunded',
      'waived': 'waived',
      'discounted': 'discounted',
      'active': 'active',
      'inactive': 'inactive',
      'approved': 'approved',
      'rejected': 'rejected',
      'processing': 'warn',
      'info': 'info',
      'warning': 'warn',
      'danger': 'danger',
    };
    return map[s] || 'pending';
  }

  label(): string {
    if (this.labelOverride) { return this.labelOverride; }
    const s = (this.status || '').replace(/[\s_]+/g, ' ').trim();
    return s ? s.replace(/\b\w/g, c => c.toUpperCase()) : 'Pending';
  }
}
