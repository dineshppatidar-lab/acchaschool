import { Component, Input, ViewChild, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatTableModule, MatTableDataSource } from '@angular/material/table';
import { MatPaginatorModule, MatPaginator } from '@angular/material/paginator';
import { MatSortModule, MatSort } from '@angular/material/sort';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatNativeDateModule } from '@angular/material/core';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatChipsModule } from '@angular/material/chips';
import { MatDividerModule } from '@angular/material/divider';
import { MatCardModule } from '@angular/material/card';
import { ReactiveFormsModule, FormBuilder, FormGroup } from '@angular/forms';

export interface LedgerEntry {
  id: number;
  date: Date;
  description: string;
  entryType: 'debit' | 'credit';
  amount: number;
  reference?: string;
  balance: number;
  remarks?: string;
  relatedEntity?: string;
}

@Component({
  selector: 'app-ledger-view',
  standalone: true,
  imports: [
    CommonModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    MatDatepickerModule,
    MatFormFieldModule,
    MatInputModule,
    MatNativeDateModule,
    MatButtonModule,
    MatIconModule,
    MatChipsModule,
    MatDividerModule,
    MatCardModule,
    ReactiveFormsModule
  ],
  template: `
    <div class="ledger-container">
      <!-- Header -->
      <div class="ledger-header" *ngIf="showHeader">
        <h3>Student Ledger</h3>
        <p class="ledger-subtitle" *ngIf="studentName">{{ studentName }}</p>
      </div>

      <!-- Filter Section -->
      <mat-card class="filter-card" *ngIf="showFilters">
        <form [formGroup]="filterForm" class="filter-form">
          <mat-form-field appearance="outline">
            <mat-label>Start Date</mat-label>
            <input
              matInput
              [matDatepicker]="startPicker"
              formControlName="startDate"
              (change)="onFilterChange()">
            <mat-datepicker-toggle matIconSuffix [for]="startPicker"></mat-datepicker-toggle>
            <mat-datepicker #startPicker></mat-datepicker>
          </mat-form-field>

          <mat-form-field appearance="outline">
            <mat-label>End Date</mat-label>
            <input
              matInput
              [matDatepicker]="endPicker"
              formControlName="endDate"
              (change)="onFilterChange()">
            <mat-datepicker-toggle matIconSuffix [for]="endPicker"></mat-datepicker-toggle>
            <mat-datepicker #endPicker></mat-datepicker>
          </mat-form-field>

          <mat-form-field appearance="outline" class="flex">
            <mat-label>Search</mat-label>
            <input
              matInput
              formControlName="search"
              placeholder="Reference, description..."
              (change)="onFilterChange()">
            <mat-icon matPrefix>search</mat-icon>
          </mat-form-field>

          <button
            mat-stroked-button
            (click)="resetFilters()">
            <mat-icon>refresh</mat-icon>
            Reset
          </button>
        </form>
      </mat-card>

      <!-- Summary Cards -->
      <div class="summary-cards" *ngIf="ledgerEntries.length > 0">
        <mat-card class="summary-card">
          <div class="summary-item">
            <span class="summary-label">Total Debits</span>
            <span class="summary-value debit">₹{{ getTotalDebits() | number:'1.2-2' }}</span>
          </div>
        </mat-card>

        <mat-card class="summary-card">
          <div class="summary-item">
            <span class="summary-label">Total Credits</span>
            <span class="summary-value credit">₹{{ getTotalCredits() | number:'1.2-2' }}</span>
          </div>
        </mat-card>

        <mat-card class="summary-card">
          <div class="summary-item">
            <span class="summary-label">Current Balance</span>
            <span class="summary-value" [class.positive]="getCurrentBalance() >= 0" [class.negative]="getCurrentBalance() < 0">
              ₹{{ getCurrentBalance() | number:'1.2-2' }}
            </span>
          </div>
        </mat-card>
      </div>

      <!-- Ledger Table -->
      <div class="mat-elevation-z1 table-wrapper">
        <table
          mat-table
          [dataSource]="dataSource"
          matSort
          class="ledger-table"
          [trackBy]="trackByLedgerId">

          <!-- Date Column -->
          <ng-container matColumnDef="date">
            <th mat-header-cell *matHeaderCellDef mat-sort-header>Date</th>
            <td mat-cell *matCellDef="let element" class="date-column">
              <div class="date-cell">
                <strong class="date-value">{{ element.date | date:'dd MMM' }}</strong>
                <small class="date-year">{{ element.date | date:'yyyy' }}</small>
              </div>
            </td>
          </ng-container>

          <!-- Description Column -->
          <ng-container matColumnDef="description">
            <th mat-header-cell *matHeaderCellDef mat-sort-header>Description</th>
            <td mat-cell *matCellDef="let element" class="description-column">
              <div class="description-cell">
                <span class="description-text">{{ element.description }}</span>
                <small class="related-entity" *ngIf="element.relatedEntity">
                  {{ element.relatedEntity }}
                </small>
              </div>
            </td>
          </ng-container>

          <!-- Type Column -->
          <ng-container matColumnDef="type">
            <th mat-header-cell *matHeaderCellDef mat-sort-header>Type</th>
            <td mat-cell *matCellDef="let element" class="type-column">
              <mat-chip [class]="'type-chip type-' + element.entryType">
                <mat-icon>{{ element.entryType === 'debit' ? 'remove_circle' : 'add_circle' }}</mat-icon>
                {{ element.entryType | uppercase }}
              </mat-chip>
            </td>
          </ng-container>

          <!-- Amount Column -->
          <ng-container matColumnDef="amount">
            <th mat-header-cell *matHeaderCellDef mat-sort-header class="text-right">Amount</th>
            <td mat-cell *matCellDef="let element" class="amount-column text-right">
              <span class="amount" [class]="'amount-' + element.entryType">
                {{ element.entryType === 'debit' ? '-' : '+' }} ₹{{ element.amount | number:'1.2-2' }}
              </span>
            </td>
          </ng-container>

          <!-- Reference Column -->
          <ng-container matColumnDef="reference">
            <th mat-header-cell *matHeaderCellDef>Reference</th>
            <td mat-cell *matCellDef="let element" class="reference-column">
              <small class="reference-text" *ngIf="element.reference">{{ element.reference }}</small>
              <small class="no-reference" *ngIf="!element.reference">—</small>
            </td>
          </ng-container>

          <!-- Balance Column -->
          <ng-container matColumnDef="balance">
            <th mat-header-cell *matHeaderCellDef mat-sort-header class="text-right">Balance</th>
            <td mat-cell *matCellDef="let element" class="balance-column text-right">
              <strong class="balance-value" [class]="element.balance >= 0 ? 'positive' : 'negative'">
                ₹{{ element.balance | number:'1.2-2' }}
              </strong>
            </td>
          </ng-container>

          <!-- Remarks Column -->
          <ng-container matColumnDef="remarks">
            <th mat-header-cell *matHeaderCellDef>Remarks</th>
            <td mat-cell *matCellDef="let element" class="remarks-column">
              <small class="remarks-text" *ngIf="element.remarks">{{ element.remarks }}</small>
              <small class="no-remarks" *ngIf="!element.remarks">—</small>
            </td>
          </ng-container>

          <!-- Header Row -->
          <tr mat-header-row *matHeaderRowDef="displayedColumns; sticky: true" class="header-row"></tr>

          <!-- Data Rows -->
          <tr
            mat-row
            *matRowDef="let row; columns: displayedColumns;"
            [class.debit-row]="row.entryType === 'debit'"
            [class.credit-row]="row.entryType === 'credit'"
            class="data-row">
          </tr>

          <!-- No Data Row -->
          <tr class="no-data-row" *matNoDataRow>
            <td [attr.colspan]="displayedColumns.length" class="no-data-cell">
              <mat-icon>inbox</mat-icon>
              <p>No ledger entries found</p>
            </td>
          </tr>
        </table>
      </div>

      <!-- Paginator -->
      <mat-paginator
        [pageSizeOptions]="[5, 10, 25, 50]"
        showFirstLastButtons>
      </mat-paginator>

      <!-- Export Section -->
      <div class="export-section" *ngIf="ledgerEntries.length > 0">
        <button mat-stroked-button (click)="onExportCSV()">
          <mat-icon>download</mat-icon>
          Export as CSV
        </button>
        <button mat-stroked-button (click)="onExportPDF()">
          <mat-icon>picture_as_pdf</mat-icon>
          Export as PDF
        </button>
      </div>
    </div>
  `,
  styles: [`
    .ledger-container {
      display: flex;
      flex-direction: column;
      gap: 20px;
    }

    .ledger-header {
      h3 {
        margin: 0 0 4px;
        font-size: 20px;
        font-weight: 600;
        color: var(--md-on-surface);
      }

      .ledger-subtitle {
        margin: 0;
        font-size: 13px;
        color: var(--color-text-secondary);
      }
    }

    .filter-card {
      padding: 16px;
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);

      .filter-form {
        display: flex;
        gap: 12px;
        align-items: flex-end;
        flex-wrap: wrap;

        mat-form-field {
          flex: 0 0 auto;

          &.flex {
            flex: 1 1 auto;
            min-width: 200px;
          }
        }

        button {
          margin-bottom: 4px;
        }
      }
    }

    .summary-cards {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 16px;

      .summary-card {
        padding: 16px;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
        border-radius: 8px;

        .summary-item {
          display: flex;
          flex-direction: column;
          gap: 8px;

          .summary-label {
            font-size: 12px;
            font-weight: 600;
            color: var(--color-text-secondary);
            text-transform: uppercase;
          }

          .summary-value {
            font-size: 24px;
            font-weight: bold;

            &.debit { color: var(--md-error); }
            &.credit { color: var(--md-success); }
            &.positive { color: var(--md-success); }
            &.negative { color: var(--md-error); }
          }
        }
      }
    }

    .table-wrapper {
      overflow-x: auto;
      border-radius: 4px;
      margin: 0;
    }

    .ledger-table {
      width: 100%;
      background: white;

      .header-row {
        background: var(--md-surface-container-low);
        font-weight: 600;
        border-bottom: 2px solid var(--color-border);

        th {
          padding: 12px 16px !important;
          font-size: 13px;
          text-transform: uppercase;
          color: var(--color-text-secondary);
          letter-spacing: 0.5px;

          &.text-right {
            text-align: right;
          }
        }
      }

      .data-row {
        border-bottom: 1px solid var(--color-border);
        transition: background-color 0.2s ease;

        &:hover {
          background-color: var(--md-surface-container-low);
        }

        &.debit-row {
          border-left: 4px solid var(--md-error);
        }

        &.credit-row {
          border-left: 4px solid var(--md-success);
        }

        td {
          padding: 12px 16px !important;
          font-size: 14px;
        }
      }
    }

    .date-column {
      min-width: 100px;

      .date-cell {
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 2px;

        .date-value {
          color: var(--md-on-surface);
        }

        .date-year {
          color: var(--md-outline);
          font-size: 11px;
        }
      }
    }

    .description-column {
      min-width: 200px;

      .description-cell {
        display: flex;
        flex-direction: column;
        gap: 4px;

        .description-text {
          color: var(--md-on-surface);
          font-weight: 500;
        }

        .related-entity {
          color: var(--md-outline);
          font-size: 12px;
        }
      }
    }

    .type-column {
      min-width: 120px;

      .type-chip {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 4px 12px;
        font-size: 11px;
        font-weight: 600;
        text-transform: uppercase;
        border-radius: 16px;

        mat-icon {
          font-size: 14px;
          width: 14px;
          height: 14px;
        }

        &.type-debit {
          background: var(--md-error-container);
          color: var(--md-error);
        }

        &.type-credit {
          background: var(--md-success-container);
          color: var(--md-success);
        }
      }
    }

    .amount-column {
      min-width: 120px;

      .amount {
        font-weight: 600;
        font-size: var(--font-size-base);

        &.amount-debit {
          color: var(--md-error);
        }

        &.amount-credit {
          color: var(--md-success);
        }
      }

      &.text-right {
        text-align: right;
      }
    }

    .text-right {
      text-align: right !important;
    }

    .reference-column {
      min-width: 120px;

      .reference-text {
        color: var(--md-primary);
        font-weight: 600;
      }

      .no-reference {
        color: var(--color-border);
      }
    }

    .balance-column {
      min-width: 120px;

      .balance-value {
        font-size: 16px;

        &.positive {
          color: var(--md-success);
        }

        &.negative {
          color: var(--md-error);
        }
      }

      &.text-right {
        text-align: right;
      }
    }

    .remarks-column {
      min-width: 150px;

      .remarks-text {
        color: var(--color-text-secondary);
        font-style: italic;
      }

      .no-remarks {
        color: var(--color-border);
      }
    }

    .no-data-row {
      .no-data-cell {
        padding: 60px 20px !important;
        text-align: center;
        color: var(--color-border);

        mat-icon {
          font-size: 48px;
          width: 48px;
          height: 48px;
          margin-bottom: 8px;
        }

        p {
          margin: 8px 0 0;
          font-size: 14px;
        }
      }
    }

    mat-paginator {
      background: var(--md-surface-container-low);
      border-top: 1px solid var(--color-border);
    }

    .export-section {
      display: flex;
      gap: 12px;
      justify-content: flex-end;
      padding: 12px 0;

      button {
        display: flex;
        align-items: center;
        gap: 6px;
      }
    }
  `]
})
export class LedgerViewComponent implements OnInit {
  @Input() ledgerEntries: LedgerEntry[] = [];
  @Input() studentName: string = '';
  @Input() showFilters = true;
  @Input() showHeader = true;
  @Input() pageSize = 10;

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  dataSource = new MatTableDataSource<LedgerEntry>();
  displayedColumns: string[] = ['date', 'description', 'type', 'amount', 'reference', 'balance', 'remarks'];
  filterForm!: FormGroup;

  constructor(private fb: FormBuilder) {}

  ngOnInit(): void {
    this.initializeForm();
    this.updateTable();
  }

  private initializeForm(): void {
    this.filterForm = this.fb.group({
      startDate: [null],
      endDate: [null],
      search: ['']
    });
  }

  private updateTable(): void {
    this.dataSource.data = this.ledgerEntries;
    setTimeout(() => {
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    });
  }

  onFilterChange(): void {
    const { startDate, endDate, search } = this.filterForm.value;
    
    let filtered = this.ledgerEntries;

    if (startDate) {
      filtered = filtered.filter(e => new Date(e.date) >= new Date(startDate));
    }

    if (endDate) {
      filtered = filtered.filter(e => new Date(e.date) <= new Date(endDate));
    }

    if (search) {
      const searchLower = search.toLowerCase();
      filtered = filtered.filter(e =>
        e.description.toLowerCase().includes(searchLower) ||
        (e.reference && e.reference.toLowerCase().includes(searchLower)) ||
        (e.remarks && e.remarks.toLowerCase().includes(searchLower))
      );
    }

    this.dataSource.data = filtered;
  }

  resetFilters(): void {
    this.filterForm.reset();
    this.updateTable();
  }

  getTotalDebits(): number {
    return this.ledgerEntries
      .filter(e => e.entryType === 'debit')
      .reduce((sum, e) => sum + e.amount, 0);
  }

  getTotalCredits(): number {
    return this.ledgerEntries
      .filter(e => e.entryType === 'credit')
      .reduce((sum, e) => sum + e.amount, 0);
  }

  getCurrentBalance(): number {
    if (this.ledgerEntries.length === 0) return 0;
    return this.ledgerEntries[this.ledgerEntries.length - 1].balance;
  }

  onExportCSV(): void {
    const headers = ['Date', 'Description', 'Type', 'Amount', 'Reference', 'Balance', 'Remarks'];
    const rows = this.dataSource.filteredData.map(entry => [
      new Date(entry.date).toLocaleDateString(),
      entry.description,
      entry.entryType.toUpperCase(),
      entry.amount.toFixed(2),
      entry.reference || '',
      entry.balance.toFixed(2),
      entry.remarks || ''
    ]);

    const csvContent = [
      headers.join(','),
      ...rows.map(row => row.map(cell => `"${cell}"`).join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `ledger-${new Date().getTime()}.csv`;
    link.click();
  }

  onExportPDF(): void {
    console.log('Export to PDF - implement using jsPDF or similar');
    // Implement PDF export
  }

  trackByLedgerId(index: number, item: LedgerEntry): number {
    return item.id;
  }
}
