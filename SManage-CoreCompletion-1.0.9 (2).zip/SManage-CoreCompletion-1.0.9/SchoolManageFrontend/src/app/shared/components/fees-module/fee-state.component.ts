import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';

export type FeeStateKind = 'loading' | 'empty' | 'error' | 'success';

/**
 * Unified loading / empty / error / success state for Fees pages.
 *
 * - loading: spinner + message
 * - empty:   icon + title + guidance (+ optional action button)
 * - error:   icon + message + Retry button
 *
 * The visual treatment lives in the global `.fee-state` CSS layer.
 */
@Component({
  selector: 'app-fee-state',
  standalone: true,
  imports: [CommonModule, MatProgressSpinnerModule, MatButtonModule, MatIconModule],
  template: `
    <div class="fee-state" [class]="'fee-state-' + kind" role="status">
      @if (kind === 'loading') {
        <mat-spinner [diameter]="36" aria-label="Loading"></mat-spinner>
      } @else {
        <mat-icon class="fee-state-icon">{{ icon() }}</mat-icon>
      }
      @if (title) {
        <h3 class="fee-state-title">{{ title }}</h3>
      }
      <p class="fee-state-text">{{ message }}</p>
      @if (kind === 'error' || actionLabel) {
        <button
          type="button"
          mat-flat-button
          color="primary"
          class="fee-state-action"
          (click)="action.emit()">
          <mat-icon>{{ kind === 'error' ? 'refresh' : 'add' }}</mat-icon>
          {{ actionLabel || 'Retry' }}
        </button>
      }
    </div>
  `,
})
export class FeeStateComponent {
  @Input() kind: FeeStateKind = 'empty';
  @Input() title = '';
  @Input() message = '';
  /** Button label for empty/success states. Errors always show Retry. */
  @Input() actionLabel = '';
  /** Configurable empty-state icon (search_off, receipt_long, …). */
  @Input() emptyIcon = 'inbox';

  @Output() action = new EventEmitter<void>();

  icon(): string {
    switch (this.kind) {
      case 'error': return 'error_outline';
      case 'success': return 'check_circle';
      case 'empty': return this.emptyIcon;
      default: return 'info';
    }
  }
}
