import { Component, Input, OnInit, OnChanges, SimpleChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatChipsModule } from '@angular/material/chips';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatDividerModule } from '@angular/material/divider';

export interface FeeSummary {
  totalFee: number;
  totalPaid: number;
  totalBalance: number;
  collectionPercentage: number;
  status: 'paid' | 'partial' | 'overdue' | 'pending';
  lastPaymentDate?: Date;
  nextDueDate?: Date;
  overdueAmount?: number;
  daysOverdue?: number;
}

@Component({
  selector: 'app-fee-summary-card',
  standalone: true,
  imports: [
    CommonModule,
    MatCardModule,
    MatIconModule,
    MatProgressBarModule,
    MatChipsModule,
    MatTooltipModule,
    MatDividerModule
  ],
  template: `
    <mat-card class="fee-summary-card" [class.loaded]="!!summary">
      <!-- Header -->
      <div class="card-header">
        <div class="header-title">
          <mat-icon class="header-icon">account_balance_wallet</mat-icon>
          <h3>Fee Summary</h3>
        </div>
        <mat-chip
          [class]="'status-chip status-' + (summary?.status || 'pending')"
          [matTooltip]="getStatusTooltip()">
          <mat-icon>{{ getStatusIcon() }}</mat-icon>
          {{ (summary?.status || 'pending') | uppercase }}
        </mat-chip>
      </div>

      <mat-divider></mat-divider>

      <!-- Summary Stats (3 columns) -->
      <div class="summary-grid" *ngIf="summary">
        <!-- Total Fee -->
        <div class="stat-item">
          <div class="stat-label">
            <mat-icon>receipt</mat-icon>
            Total Fee
          </div>
          <div class="stat-value total-fee">₹{{ summary.totalFee | number:'1.2-2' }}</div>
        </div>

        <!-- Paid Amount -->
        <div class="stat-item">
          <div class="stat-label">
            <mat-icon>check_circle</mat-icon>
            Paid
          </div>
          <div class="stat-value paid">₹{{ summary.totalPaid | number:'1.2-2' }}</div>
        </div>

        <!-- Balance/Overdue -->
        <div class="stat-item">
          <div class="stat-label">
            <mat-icon>error_outline</mat-icon>
            {{ summary.totalBalance > 0 ? 'Balance' : 'Credit' }}
          </div>
          <div class="stat-value" [class.balance]="summary.totalBalance > 0" [class.credit]="summary.totalBalance <= 0">
            ₹{{ Math.abs(summary.totalBalance) | number:'1.2-2' }}
          </div>
        </div>
      </div>

      <!-- Progress Bar -->
      <div class="progress-section" *ngIf="summary">
        <div class="progress-label">
          <span>Collection Progress</span>
          <span class="percentage">{{ summary.collectionPercentage | number:'1.0-0' }}%</span>
        </div>
        <mat-progress-bar
          mode="determinate"
          [value]="summary.collectionPercentage"
          [class.over-collected]="summary.collectionPercentage > 100">
        </mat-progress-bar>
      </div>

      <!-- Additional Info (Optional) -->
      <div class="additional-info" *ngIf="summary">
        <div class="info-row" *ngIf="summary.lastPaymentDate">
          <span class="info-label">Last Payment</span>
          <span class="info-value">{{ summary.lastPaymentDate | date:'dd MMM yyyy' }}</span>
        </div>

        <div class="info-row" *ngIf="summary.nextDueDate">
          <span class="info-label">Next Due</span>
          <span class="info-value" [class.overdue]="isOverdue(summary.nextDueDate)">
            {{ summary.nextDueDate | date:'dd MMM yyyy' }}
          </span>
        </div>

        <div class="info-row" *ngIf="summary.daysOverdue && summary.daysOverdue > 0">
          <span class="info-label">Days Overdue</span>
          <span class="info-value warning">{{ summary.daysOverdue }} days</span>
        </div>

        <div class="info-row" *ngIf="summary.overdueAmount && summary.overdueAmount > 0">
          <span class="info-label">Overdue Amount</span>
          <span class="info-value warning">₹{{ summary.overdueAmount | number:'1.2-2' }}</span>
        </div>
      </div>

      <!-- Loading State -->
      <div class="loading-state" *ngIf="!summary && loading">
        <mat-icon>hourglass_empty</mat-icon>
        <p>Loading fee summary...</p>
      </div>

      <!-- Empty State -->
      <div class="empty-state" *ngIf="!summary && !loading">
        <mat-icon>info</mat-icon>
        <p>No fee data available</p>
      </div>
    </mat-card>
  `,
  styles: [`
    .fee-summary-card {
      background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
      border-radius: 12px;
      padding: 20px;
      transition: all 0.3s ease;

      &.loaded {
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
      }
    }

    .card-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 16px;

      .header-title {
        display: flex;
        align-items: center;
        gap: 12px;

        .header-icon {
          color: var(--md-primary);
          font-size: 28px;
          width: 28px;
          height: 28px;
        }

        h3 {
          margin: 0;
          font-size: 18px;
          font-weight: 600;
          color: var(--md-on-surface);
        }
      }

      .status-chip {
        display: flex;
        align-items: center;
        gap: 6px;
        padding: 6px 12px;
        font-size: 12px;
        font-weight: 600;

        mat-icon {
          font-size: 16px;
          width: 16px;
          height: 16px;
        }

        &.status-paid { background: var(--md-success-container) !important; color: var(--md-success) !important; }
        &.status-partial { background: var(--md-warning-container) !important; color: var(--md-warning) !important; }
        &.status-overdue { background: var(--md-error-container) !important; color: var(--md-error) !important; }
        &.status-pending { background: var(--md-surface-container-low) !important; color: var(--color-text-secondary) !important; }
      }
    }

    mat-divider {
      margin: 12px 0;
    }

    .summary-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
      gap: 16px;
      margin-bottom: 20px;

      .stat-item {
        text-align: center;

        .stat-label {
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 6px;
          font-size: 12px;
          font-weight: 600;
          color: var(--color-text-secondary);
          margin-bottom: 8px;
          text-transform: uppercase;

          mat-icon {
            font-size: 16px;
            width: 16px;
            height: 16px;
          }
        }

        .stat-value {
          font-size: var(--font-size-xl);
          font-weight: bold;

          &.total-fee { color: var(--md-primary); }
          &.paid { color: var(--md-success); }
          &.balance { color: var(--md-error); }
          &.credit { color: var(--md-success); }
        }
      }
    }

    .progress-section {
      margin-bottom: 20px;

      .progress-label {
        display: flex;
        justify-content: space-between;
        font-size: 13px;
        font-weight: 600;
        color: var(--color-text-secondary);
        margin-bottom: 8px;

        .percentage {
          color: var(--md-primary);
        }
      }

      mat-progress-bar {
        height: 8px;
        border-radius: 4px;

        &.over-collected {
          ::ng-deep .mat-progress-bar-fill::after {
            background-color: var(--md-success) !important;
          }
        }
      }
    }

    .additional-info {
      display: flex;
      flex-direction: column;
      gap: 12px;
      padding-top: 12px;
      border-top: 1px solid rgba(0, 0, 0, 0.1);

      .info-row {
        display: flex;
        justify-content: space-between;
        font-size: 13px;

        .info-label {
          color: var(--color-text-secondary);
          font-weight: 600;
        }

        .info-value {
          color: var(--md-on-surface);
          font-weight: 500;

          &.overdue { color: var(--md-error); }
          &.warning { color: #ff6f00; }
        }
      }
    }

    .loading-state,
    .empty-state {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      padding: 30px 20px;
      text-align: center;
      color: var(--md-outline);

      mat-icon {
        font-size: 48px;
        width: 48px;
        height: 48px;
        margin-bottom: 12px;
      }

      p {
        margin: 0;
        font-size: 14px;
      }
    }
  `]
})
export class FeeSummaryCardComponent implements OnInit, OnChanges {
  @Input() summary!: FeeSummary | null;
  @Input() loading = false;

  Math = Math;

  ngOnInit(): void {}

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['summary']) {
      // Component auto-updates when summary changes
    }
  }

  getStatusIcon(): string {
    switch (this.summary?.status) {
      case 'paid': return 'check_circle';
      case 'partial': return 'hourglass_half';
      case 'overdue': return 'warning';
      case 'pending': return 'schedule';
      default: return 'help';
    }
  }

  getStatusTooltip(): string {
    switch (this.summary?.status) {
      case 'paid': return 'All fees paid';
      case 'partial': return 'Partial payment made';
      case 'overdue': return 'Payment overdue';
      case 'pending': return 'Awaiting payment';
      default: return 'Unknown status';
    }
  }

  isOverdue(dueDate: Date): boolean {
    return new Date(dueDate) < new Date();
  }
}
