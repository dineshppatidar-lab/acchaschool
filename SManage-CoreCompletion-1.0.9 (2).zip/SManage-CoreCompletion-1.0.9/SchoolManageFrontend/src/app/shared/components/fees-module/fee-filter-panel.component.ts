import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';

/**
 * Unified filter container for Fees list pages, matching the
 * Advanced Finance page's `.actions-bar` pattern: a single wrapping
 * flex row holding action buttons and outline form fields, which
 * wraps naturally on tablet/phone widths (fields go full-width).
 *
 * Projection slots:
 *   [filterSearch]  — the search / student autocomplete field
 *   [filterFields]  — additional filter fields (selects, dates…)
 *   [filterActions] — buttons (Apply/Clear/export…)
 */
@Component({
  selector: 'app-fee-filter-panel',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="fee-filter-bar">
      <div class="ffe-row">
        <ng-content select="[filterSearch]"></ng-content>
        <ng-content select="[filterFields]"></ng-content>
        <ng-content select="[filterActions]"></ng-content>
      </div>
    </div>
  `,
})
export class FeeFilterPanelComponent {
  /** Number of active non-default filters (reserved for a future count chip). */
  @Input() activeCount = 0;
}
