import { Component, Inject, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef, MatDialogModule } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatDividerModule } from '@angular/material/divider';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatCardModule } from '@angular/material/card';
import { MatListModule } from '@angular/material/list';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

export interface PaymentData {
  installmentId: number;
  installmentName: string;
  studentId: number;
  studentName: string;
  amount: number;
  paidAmount: number;
  balanceAmount: number;
  lateFeeAmount?: number;
  dueDate: Date;
  status: string;
  multiInstallment?: boolean; // Enable multi-payment mode
  selectedInstallments?: Array<{id: number; amount: number; name: string}>;
}

@Component({
  selector: 'app-payment-drawer',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatDialogModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatButtonModule,
    MatIconModule,
    MatDividerModule,
    MatProgressBarModule,
    MatCheckboxModule,
    MatTooltipModule,
    MatCardModule,
    MatListModule
  ],
  template: `
    <div class="payment-drawer">
      <!-- Header -->
      <div class="drawer-header">
        <div class="header-content">
          <mat-icon class="header-icon" [matTooltip]="data.multiInstallment ? 'Multi-Installment Payment' : 'Single Payment'">
            {{ data.multiInstallment ? 'paid' : 'payment' }}
          </mat-icon>
          <div>
            <h2>{{ data.multiInstallment ? 'Multi-Installment Payment' : 'Payment' }}</h2>
            <p class="student-info">{{ data.studentName }} (ID: {{ data.studentId }})</p>
          </div>
        </div>
        <button mat-icon-button (click)="onCancel()" class="close-button">
          <mat-icon>close</mat-icon>
        </button>
      </div>

      <mat-divider></mat-divider>

      <!-- Scrollable Content -->
      <div class="drawer-content">
        <!-- Single Installment Info OR Multi-installment Summary -->
        <div class="installment-summary" [class.multi]="data.multiInstallment">
          <h3 *ngIf="!data.multiInstallment" class="installment-name">
            {{ data.installmentName }}
          </h3>
          <p *ngIf="!data.multiInstallment" class="due-date">
            Due: {{ data.dueDate | date:'dd MMM yyyy' }}
          </p>

          <!-- Multi-installment summary -->
          <div *ngIf="data.multiInstallment && data.selectedInstallments" class="multi-summary">
            <p class="multi-count">{{ data.selectedInstallments.length }} installments selected</p>
            <mat-card class="summary-card">
              <mat-card-content>
                <div class="summary-row">
                  <span class="summary-label">Total Amount:</span>
                  <span class="summary-value">₹{{ getTotalAmount() | number:'1.2-2' }}</span>
                </div>
              </mat-card-content>
            </mat-card>
          </div>
        </div>

        <!-- Summary Section -->
        <mat-card class="amount-card">
          <mat-card-header>
            <mat-card-title>Payment Summary</mat-card-title>
          </mat-card-header>
          <mat-card-content>
            <div class="amount-row">
              <span class="amount-label">Total Amount:</span>
              <span class="amount-value">₹{{ getPayableAmount() | number:'1.2-2' }}</span>
            </div>
            <div class="amount-row" *ngIf="!data.multiInstallment">
              <span class="amount-label">Paid Amount:</span>
              <span class="amount-subtext">₹{{ data.paidAmount | number:'1.2-2' }}</span>
            </div>
            <div class="amount-row" *ngIf="!data.multiInstallment">
              <span class="amount-label">Balance:</span>
              <span class="amount-subtext">₹{{ data.balanceAmount | number:'1.2-2' }}</span>
            </div>
            <div class="amount-row" *ngIf="data.lateFeeAmount && data.lateFeeAmount > 0">
              <span class="amount-label">Late Fee:</span>
              <span class="late-fee">₹{{ data.lateFeeAmount | number:'1.2-2' }}</span>
            </div>
            <mat-divider class="summary-divider"></mat-divider>
            <div class="amount-row total">
              <span class="amount-label">Total Payable:</span>
              <span class="amount-total">₹{{ getTotalPayable() | number:'1.2-2' }}</span>
            </div>

            <!-- Progress indicator -->
            <div class="progress-section" *ngIf="!data.multiInstallment">
              <mat-progress-bar
                mode="determinate"
                [value]="(data.paidAmount / data.amount) * 100">
              </mat-progress-bar>
              <small class="progress-text">
                {{ ((data.paidAmount / data.amount) * 100) | number:'1.0-0' }}% collected
              </small>
            </div>
          </mat-card-content>
        </mat-card>

        <!-- Payment Form -->
        <form [formGroup]="paymentForm" class="payment-form">
          <!-- Payment Amount -->
          <mat-form-field appearance="outline" class="full-width">
            <mat-label>Payment Amount</mat-label>
            <input
              matInput
              type="number"
              formControlName="paymentAmount"
              [placeholder]="'₹ 0.00'"
              step="0.01">
            <mat-icon matPrefix>currency_rupee</mat-icon>
            <mat-error *ngIf="paymentForm.get('paymentAmount')?.hasError('required')">
              Amount is required
            </mat-error>
            <mat-error *ngIf="paymentForm.get('paymentAmount')?.hasError('min')">
              Amount must be greater than 0
            </mat-error>
            <mat-error *ngIf="paymentForm.get('paymentAmount')?.hasError('max')">
              Amount exceeds payable amount
            </mat-error>
          </mat-form-field>

          <!-- Payment Method -->
          <mat-form-field appearance="outline" class="full-width">
            <mat-label>Payment Method</mat-label>
            <mat-select formControlName="paymentMethod">
              <mat-option value="cash">Cash</mat-option>
              <mat-option value="cheque">Cheque</mat-option>
              <mat-option value="dd">Demand Draft</mat-option>
              <mat-option value="online">Online Transfer</mat-option>
              <mat-option value="card">Card</mat-option>
            </mat-select>
            <mat-icon matPrefix>payment</mat-icon>
          </mat-form-field>

          <!-- Transaction ID (for online payments) -->
          <mat-form-field
            appearance="outline"
            class="full-width"
            *ngIf="paymentForm.get('paymentMethod')?.value === 'online'">
            <mat-label>Transaction ID / Reference</mat-label>
            <input
              matInput
              formControlName="transactionId"
              placeholder="e.g., UTR/Reference number">
            <mat-icon matPrefix>receipt_long</mat-icon>
          </mat-form-field>

          <!-- Cheque Details (for cheque payments) -->
          <div *ngIf="paymentForm.get('paymentMethod')?.value === 'cheque'" class="cheque-details">
            <mat-form-field appearance="outline" class="full-width">
              <mat-label>Cheque Number</mat-label>
              <input
                matInput
                formControlName="chequeNumber"
                placeholder="e.g., 123456">
              <mat-icon matPrefix>confirmation_number</mat-icon>
            </mat-form-field>

            <mat-form-field appearance="outline" class="full-width">
              <mat-label>Cheque Date</mat-label>
              <input
                matInput
                type="date"
                formControlName="chequeDate">
              <mat-icon matPrefix>calendar_today</mat-icon>
            </mat-form-field>

            <mat-form-field appearance="outline" class="full-width">
              <mat-label>Bank Name</mat-label>
              <input
                matInput
                formControlName="bankName"
                placeholder="e.g., SBI, HDFC">
              <mat-icon matPrefix>account_balance</mat-icon>
            </mat-form-field>
          </div>

          <!-- Notes -->
          <mat-form-field appearance="outline" class="full-width">
            <mat-label>Notes (Optional)</mat-label>
            <textarea
              matInput
              formControlName="notes"
              placeholder="Additional notes about this payment"
              rows="3">
            </textarea>
            <mat-icon matPrefix>notes</mat-icon>
          </mat-form-field>

          <!-- Verify Checkbox -->
          <div class="verify-section">
            <mat-checkbox formControlName="verified">
              I confirm the payment details are correct
            </mat-checkbox>
          </div>
        </form>
      </div>

      <mat-divider></mat-divider>

      <!-- Footer with Actions -->
      <div class="drawer-footer">
        <button mat-stroked-button (click)="onCancel()" class="cancel-button">
          Cancel
        </button>
        <button
          mat-raised-button
          color="primary"
          (click)="onSubmit()"
          [disabled]="!paymentForm.valid || isProcessing"
          class="submit-button">
          <mat-icon *ngIf="!isProcessing">check_circle</mat-icon>
          <mat-icon *ngIf="isProcessing" class="spinner">progress</mat-icon>
          {{ isProcessing ? 'Processing...' : 'Confirm Payment' }}
        </button>
      </div>

      <!-- Processing Indicator -->
      <mat-progress-bar
        *ngIf="isProcessing"
        mode="indeterminate"
        class="processing-bar">
      </mat-progress-bar>
    </div>
  `,
  styles: [`
    .payment-drawer {
      display: flex;
      flex-direction: column;
      height: 100%;
      max-width: 500px;
      width: 100%;
    }

    .drawer-header {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      padding: 20px;
      gap: 16px;

      .header-content {
        display: flex;
        gap: 12px;

        .header-icon {
          color: var(--md-primary);
          font-size: 32px;
          width: 32px;
          height: 32px;
          flex-shrink: 0;
        }

        h2 {
          margin: 0;
          font-size: 20px;
          font-weight: 600;
          color: var(--md-on-surface);
        }

        .student-info {
          margin: 4px 0 0;
          font-size: 13px;
          color: var(--color-text-secondary);
        }
      }

      .close-button {
        color: var(--md-outline);
      }
    }

    .drawer-content {
      flex: 1;
      overflow-y: auto;
      padding: 20px;
      display: flex;
      flex-direction: column;
      gap: 20px;
    }

    .installment-summary {
      padding-bottom: 16px;
      border-bottom: 1px solid var(--color-border);

      .installment-name {
        margin: 0 0 4px;
        font-size: 18px;
        font-weight: 600;
        color: var(--md-on-surface);
      }

      .due-date {
        margin: 0;
        font-size: 13px;
        color: var(--color-text-secondary);
      }

      &.multi {
        .multi-count {
          margin: 0 0 12px;
          font-size: 14px;
          color: var(--color-text-secondary);
          font-weight: 600;
        }

        .summary-card {
          box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);

          mat-card-content {
            padding: 12px;

            .summary-row {
              display: flex;
              justify-content: space-between;
              align-items: center;

              .summary-label {
                font-size: 13px;
                color: var(--color-text-secondary);
                font-weight: 600;
              }

              .summary-value {
                font-size: 18px;
                font-weight: bold;
                color: var(--md-primary);
              }
            }
          }
        }
      }
    }

    .amount-card {
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
      border-radius: 8px;

      mat-card-header {
        padding: 16px;
        margin-bottom: 0;

        mat-card-title {
          font-size: 14px;
          font-weight: 600;
          text-transform: uppercase;
          color: var(--color-text-secondary);
          margin: 0;
        }
      }

      mat-card-content {
        padding: 16px;
        display: flex;
        flex-direction: column;
        gap: 12px;

        .amount-row {
          display: flex;
          justify-content: space-between;
          align-items: center;
          font-size: 14px;

          .amount-label {
            color: var(--color-text-secondary);
            font-weight: 600;
          }

          .amount-value {
            font-size: 20px;
            font-weight: bold;
            color: var(--md-primary);
          }

          .amount-subtext {
            color: var(--md-outline);
            font-size: 13px;
          }

          .late-fee {
            color: #ff6f00;
            font-weight: 600;
          }

          &.total {
            padding-top: 12px;

            .amount-label {
              font-weight: bold;
              color: var(--md-on-surface);
            }

            .amount-total {
              font-size: 24px;
              font-weight: bold;
              color: var(--md-error);
            }
          }
        }

        .summary-divider {
          margin: 8px 0;
        }

        .progress-section {
          margin-top: 12px;

          mat-progress-bar {
            height: 6px;
            border-radius: 3px;
          }

          .progress-text {
            display: block;
            margin-top: 4px;
            font-size: 12px;
            color: var(--color-text-secondary);
            text-align: right;
          }
        }
      }
    }

    .payment-form {
      display: flex;
      flex-direction: column;
      gap: 16px;

      .full-width {
        width: 100%;
      }

      .cheque-details {
        display: flex;
        flex-direction: column;
        gap: 16px;
        padding: 12px;
        background: var(--md-surface-container-low);
        border-radius: 4px;
      }

      .verify-section {
        padding: 12px;
        background: var(--md-primary-container);
        border-radius: 4px;

        ::ng-deep .mdc-checkbox__background {
          border-color: var(--md-primary) !important;
        }
      }
    }

    .drawer-footer {
      display: flex;
      gap: 12px;
      padding: 16px 20px;
      justify-content: flex-end;
      background: var(--md-surface-container-low);

      .cancel-button {
        min-width: 100px;
      }

      .submit-button {
        min-width: 140px;
        display: flex;
        align-items: center;
        gap: 8px;

        .spinner {
          animation: spin 1s linear infinite;
        }
      }
    }

    .processing-bar {
      position: absolute;
      bottom: 0;
      left: 0;
      right: 0;
    }

    @keyframes spin {
      from { transform: rotate(0deg); }
      to { transform: rotate(360deg); }
    }
  `]
})
export class PaymentDrawerComponent implements OnInit, OnDestroy {
  paymentForm!: FormGroup;
  isProcessing = false;
  private destroy$ = new Subject<void>();

  constructor(
    public dialogRef: MatDialogRef<PaymentDrawerComponent>,
    @Inject(MAT_DIALOG_DATA) public data: PaymentData,
    private fb: FormBuilder
  ) {}

  ngOnInit(): void {
    this.initializeForm();
  }

  private initializeForm(): void {
    const maxAmount = this.getTotalPayable();

    this.paymentForm = this.fb.group({
      paymentAmount: [maxAmount, [
        Validators.required,
        Validators.min(0.01),
        Validators.max(maxAmount)
      ]],
      paymentMethod: ['cash', Validators.required],
      transactionId: [''],
      chequeNumber: [''],
      chequeDate: [''],
      bankName: [''],
      notes: [''],
      verified: [false, Validators.requiredTrue]
    });

    // React to payment method changes
    this.paymentForm.get('paymentMethod')
      ?.valueChanges
      .pipe(takeUntil(this.destroy$))
      .subscribe(() => {
        this.updateValidators();
      });
  }

  private updateValidators(): void {
    const method = this.paymentForm.get('paymentMethod')?.value;
    const transactionIdControl = this.paymentForm.get('transactionId');
    const chequeNumberControl = this.paymentForm.get('chequeNumber');
    const chequeDateControl = this.paymentForm.get('chequeDate');

    // Reset validators
    transactionIdControl?.clearAsyncValidators();
    chequeNumberControl?.clearAsyncValidators();
    chequeDateControl?.clearAsyncValidators();

    if (method === 'online') {
      transactionIdControl?.setValidators([Validators.required]);
    } else if (method === 'cheque') {
      chequeNumberControl?.setValidators([Validators.required]);
      chequeDateControl?.setValidators([Validators.required]);
    }

    transactionIdControl?.updateValueAndValidity();
    chequeNumberControl?.updateValueAndValidity();
    chequeDateControl?.updateValueAndValidity();
  }

  getTotalAmount(): number {
    if (this.data.multiInstallment && this.data.selectedInstallments) {
      return this.data.selectedInstallments.reduce((sum, inst) => sum + inst.amount, 0);
    }
    return this.data.amount;
  }

  getPayableAmount(): number {
    return this.getTotalAmount();
  }

  getTotalPayable(): number {
    const baseAmount = this.getPayableAmount();
    const lateFee = this.data.lateFeeAmount || 0;
    return baseAmount + lateFee;
  }

  onSubmit(): void {
    if (!this.paymentForm.valid) return;

    this.isProcessing = true;

    // Simulate processing
    setTimeout(() => {
      this.dialogRef.close({
        success: true,
        paymentData: this.paymentForm.value,
        amount: this.getTotalPayable(),
        installmentId: this.data.installmentId
      });
      this.isProcessing = false;
    }, 1000);
  }

  onCancel(): void {
    this.dialogRef.close({ success: false });
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }
}
