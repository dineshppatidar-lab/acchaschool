import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';

export type FeeKpiTone = 'primary' | 'success' | 'warn' | 'danger' | 'info' | 'neutral';

/**
 * One summary card used by every Fees page (Total Fees, Collected,
 * Outstanding, Overdue, ...), matching the Advanced Finance page's
 * `.summary-card` pattern: mat-card + 48px plain colored icon +
 * 24px value + var(--color-text-secondary) label.
 *
 * Wrap instances in `<div class="fee-kpi-grid">…</div>`
 * (auto-fit minmax(280px, 1fr), 20px gap — same as AF).
 */
@Component({
  selector: 'app-fee-kpi-card',
  standalone: true,
  imports: [CommonModule, MatCardModule, MatIconModule],
  template: `
    <mat-card class="fee-kpi" [class]="'tone-' + tone">
      <mat-card-content>
        <div class="kpi-content">
          <mat-icon class="kpi-icon">{{ icon }}</mat-icon>
          <div class="kpi-info">
            <h3 class="kpi-value">{{ value }}</h3>
            <p class="kpi-label">{{ label }}</p>
          </div>
        </div>
      </mat-card-content>
    </mat-card>
  `,
})
export class FeeKpiCardComponent {
  @Input({ required: true }) value: string | number = '';
  @Input({ required: true }) label = '';
  @Input() icon = 'payments';
  @Input() tone: FeeKpiTone = 'primary';
}
