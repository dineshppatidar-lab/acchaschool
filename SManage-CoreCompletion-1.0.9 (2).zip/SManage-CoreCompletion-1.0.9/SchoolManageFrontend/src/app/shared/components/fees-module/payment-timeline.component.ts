import { Component, Input, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { MatCardModule } from '@angular/material/card';
import { MatDividerModule } from '@angular/material/divider';
import { MatChipsModule } from '@angular/material/chips';
import { MatTooltipModule } from '@angular/material/tooltip';

export interface PaymentRecord {
  id: number;
  date: Date;
  amount: number;
  method: string;
  status: 'success' | 'pending' | 'failed';
  reference?: string;
  notes?: string;
  processedBy?: string;
  receiptNumber?: string;
}

@Component({
  selector: 'app-payment-timeline',
  standalone: true,
  imports: [
    CommonModule,
    MatIconModule,
    MatCardModule,
    MatDividerModule,
    MatChipsModule,
    MatTooltipModule
  ],
  template: `
    <div class="timeline-container">
      <!-- Header -->
      <div class="timeline-header" *ngIf="showHeader">
        <h3>Payment History</h3>
        <span class="payment-count" *ngIf="payments.length > 0">
          {{ payments.length }} {{ payments.length === 1 ? 'payment' : 'payments' }}
        </span>
      </div>

      <!-- Timeline -->
      <div class="timeline-wrapper" *ngIf="payments.length > 0; else emptyState">
        <div class="timeline-item" *ngFor="let payment of payments; let isLast = last" [class.last]="isLast">
          
          <!-- Timeline Dot -->
          <div class="timeline-opposite">
            <small class="timeline-date">{{ payment.date | date:'dd MMM' }}</small>
            <small class="timeline-time">{{ payment.date | date:'HH:mm' }}</small>
          </div>

          <!-- Timeline Marker -->
          <div [class]="'timeline-marker marker-' + payment.status">
            <mat-icon>{{ getStatusIcon(payment.status) }}</mat-icon>
          </div>

          <!-- Timeline Content -->
          <div class="timeline-content payment-content">
            <mat-card [class]="'payment-card card-' + payment.status">
              <!-- Header -->
              <div class="payment-header">
                <div class="payment-info">
                  <h4 class="payment-amount">₹{{ payment.amount | number:'1.2-2' }}</h4>
                  <p class="payment-method">
                    <mat-icon class="method-icon">{{ getMethodIcon(payment.method) }}</mat-icon>
                    {{ getMethodLabel(payment.method) }}
                  </p>
                </div>
                <mat-chip
                  [class]="'status-chip status-' + payment.status"
                  [matTooltip]="getStatusTooltip(payment.status)">
                  {{ payment.status | uppercase }}
                </mat-chip>
              </div>

              <!-- Details -->
              <mat-divider class="card-divider"></mat-divider>

              <div class="payment-details">
                <!-- Reference -->
                <div class="detail-row" *ngIf="payment.reference">
                  <span class="detail-label">Reference:</span>
                  <span class="detail-value">{{ payment.reference }}</span>
                </div>

                <!-- Receipt -->
                <div class="detail-row" *ngIf="payment.receiptNumber">
                  <span class="detail-label">Receipt #:</span>
                  <span class="detail-value">{{ payment.receiptNumber }}</span>
                </div>

                <!-- Processed By -->
                <div class="detail-row" *ngIf="payment.processedBy">
                  <span class="detail-label">Processed By:</span>
                  <span class="detail-value">{{ payment.processedBy }}</span>
                </div>

                <!-- Notes -->
                <div class="detail-row notes-row" *ngIf="payment.notes">
                  <span class="detail-label">Notes:</span>
                  <span class="detail-value notes-text">{{ payment.notes }}</span>
                </div>

                <!-- Full Date -->
                <div class="detail-row full-date">
                  <mat-icon>calendar_today</mat-icon>
                  <span class="full-date-text">{{ payment.date | date:'dd MMMM yyyy, HH:mm:ss' }}</span>
                </div>
              </div>

              <!-- Actions (Future) -->
              <div class="payment-actions" *ngIf="payment.status === 'success'">
                <button class="action-link">
                  <mat-icon>download</mat-icon>
                  Receipt
                </button>
                <button class="action-link">
                  <mat-icon>print</mat-icon>
                  Print
                </button>
              </div>
            </mat-card>
          </div>
        </div>
      </div>

      <!-- Empty State -->
      <ng-template #emptyState>
        <div class="empty-state">
          <mat-icon>payment</mat-icon>
          <p>No payment records found</p>
          <small>Payments will appear here once made</small>
        </div>
      </ng-template>

      <!-- Load More (if pagination needed) -->
      <div class="timeline-footer" *ngIf="payments.length > 0 && totalRecords > payments.length">
        <button class="load-more-btn" (click)="onLoadMore()">
          <mat-icon>expand_more</mat-icon>
          Load More Payments
        </button>
      </div>
    </div>
  `,
  styles: [`
    .timeline-container {
      display: flex;
      flex-direction: column;
      gap: 20px;
      padding: 0;
    }

    .timeline-header {
      display: flex;
      justify-content: space-between;
      align-items: center;

      h3 {
        margin: 0;
        font-size: 18px;
        font-weight: 600;
        color: var(--md-on-surface);
      }

      .payment-count {
        background: var(--md-primary-container);
        color: var(--md-primary);
        padding: 4px 12px;
        border-radius: 12px;
        font-size: 12px;
        font-weight: 600;
      }
    }

    mat-vertical-timeline {
      padding: 0;

      ::ng-deep {
        .mat-mdc-timeline-item {
          padding: 0 0 24px 0;

          &.last-item {
            padding-bottom: 0;
          }
        }
      }
    }

    .opposite {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      min-width: 80px;

      .timeline-date {
        font-size: 13px;
        font-weight: 600;
        color: var(--md-primary);
      }

      .timeline-time {
        font-size: 11px;
        color: var(--md-outline);
        margin-top: 2px;
      }
    }

    .marker {
      background: var(--color-border);
      display: flex;
      align-items: center;
      justify-content: center;
      color: white;

      &.marker-success {
        background: linear-gradient(135deg, var(--md-success) 0%, var(--md-success) 100%);
        box-shadow: 0 4px 8px rgba(76, 175, 80, 0.3);
      }

      &.marker-pending {
        background: linear-gradient(135deg, var(--md-warning) 0%, var(--md-warning) 100%);
        box-shadow: 0 4px 8px rgba(255, 152, 0, 0.3);
      }

      &.marker-failed {
        background: linear-gradient(135deg, var(--md-error) 0%, var(--md-error) 100%);
        box-shadow: 0 4px 8px rgba(244, 67, 54, 0.3);
      }

      mat-icon {
        font-size: 20px;
        width: 20px;
        height: 20px;
      }
    }

    .payment-content {
      padding: 0 24px;

      .payment-card {
        border-radius: 8px;
        padding: 16px;
        transition: all 0.3s ease;

        &:hover {
          box-shadow: 0 4px 12px rgba(0, 0, 0, 0.12);
          transform: translateX(4px);
        }

        &.card-success {
          background: #f1f8e9;
          border-left: 4px solid var(--md-success);
        }

        &.card-pending {
          background: var(--md-warning-container);
          border-left: 4px solid var(--md-warning);
        }

        &.card-failed {
          background: var(--md-error-container);
          border-left: 4px solid var(--md-error);
        }
      }
    }

    .payment-header {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      gap: 12px;

      .payment-info {
        flex: 1;

        .payment-amount {
          margin: 0;
          font-size: 20px;
          font-weight: bold;
          color: var(--md-on-surface);
        }

        .payment-method {
          margin: 4px 0 0;
          font-size: 13px;
          color: var(--color-text-secondary);
          display: flex;
          align-items: center;
          gap: 6px;

          .method-icon {
            font-size: 14px;
            width: 14px;
            height: 14px;
          }
        }
      }

      .status-chip {
        padding: 4px 10px;
        font-size: 11px;
        font-weight: 600;
        text-transform: uppercase;
        border-radius: 12px;

        &.status-success {
          background: var(--md-success-container);
          color: var(--md-success);
        }

        &.status-pending {
          background: var(--md-warning-container);
          color: var(--md-warning);
        }

        &.status-failed {
          background: var(--md-error-container);
          color: var(--md-error);
        }
      }
    }

    .card-divider {
      margin: 12px -16px 12px;
    }

    .payment-details {
      display: flex;
      flex-direction: column;
      gap: 8px;

      .detail-row {
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        font-size: 13px;
        gap: 12px;

        .detail-label {
          font-weight: 600;
          color: var(--color-text-secondary);
          flex-shrink: 0;
        }

        .detail-value {
          color: var(--md-on-surface);
          text-align: right;
          flex: 1;

          &.notes-text {
            text-align: left;
            font-style: italic;
            color: var(--color-text-secondary);
          }
        }

        &.notes-row {
          align-items: flex-start;
        }

        &.full-date {
          display: flex;
          align-items: center;
          gap: 6px;
          margin-top: 8px;
          padding-top: 8px;
          border-top: 1px solid rgba(0, 0, 0, 0.1);
          color: var(--md-outline);
          font-size: 12px;

          mat-icon {
            font-size: 14px;
            width: 14px;
            height: 14px;
          }

          .full-date-text {
            font-weight: 600;
          }
        }
      }
    }

    .payment-actions {
      display: flex;
      gap: 12px;
      margin-top: 12px;
      padding-top: 12px;
      border-top: 1px solid rgba(0, 0, 0, 0.1);

      .action-link {
        flex: 1;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 6px;
        padding: 6px 12px;
        background: transparent;
        border: 1px solid var(--color-border);
        border-radius: 4px;
        color: var(--md-primary);
        font-size: 12px;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.2s ease;

        mat-icon {
          font-size: 14px;
          width: 14px;
          height: 14px;
        }

        &:hover {
          background: var(--md-primary-container);
          border-color: var(--md-primary);
        }
      }
    }

    .empty-state {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      padding: 60px 20px;
      text-align: center;
      color: var(--color-border);
      background: var(--md-surface-container-low);
      border-radius: 8px;

      mat-icon {
        font-size: 48px;
        width: 48px;
        height: 48px;
        margin-bottom: 12px;
      }

      p {
        margin: 8px 0 4px;
        font-size: var(--font-size-base);
        color: var(--md-outline);
      }

      small {
        font-size: 12px;
        color: #bbb;
      }
    }

    .timeline-footer {
      display: flex;
      justify-content: center;
      padding-top: 12px;

      .load-more-btn {
        display: flex;
        align-items: center;
        gap: 6px;
        padding: 8px 16px;
        background: transparent;
        border: 1px solid var(--color-border);
        border-radius: 4px;
        color: var(--md-primary);
        font-size: 13px;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.2s ease;

        mat-icon {
          font-size: 18px;
        }

        &:hover {
          background: var(--md-primary-container);
          border-color: var(--md-primary);
        }
      }
    }

    @media (max-width: 768px) {
      .opposite {
        min-width: 60px;

        .timeline-date,
        .timeline-time {
          font-size: 11px;
        }
      }

      .payment-content {
        padding: 0 16px;
      }

      .payment-header {
        flex-direction: column;

        .payment-info {
          width: 100%;
        }

        .status-chip {
          align-self: flex-start;
        }
      }

      .payment-details {
        .detail-row {
          flex-direction: column;
          align-items: flex-start;

          .detail-value {
            text-align: left;
          }
        }
      }
    }
  `]
})
export class PaymentTimelineComponent implements OnInit {
  @Input() payments: PaymentRecord[] = [];
  @Input() totalRecords = 0;
  @Input() showHeader = true;

  ngOnInit(): void {}

  getStatusIcon(status: string): string {
    switch (status) {
      case 'success': return 'check_circle';
      case 'pending': return 'hourglass_bottom';
      case 'failed': return 'cancel';
      default: return 'help';
    }
  }

  getStatusTooltip(status: string): string {
    switch (status) {
      case 'success': return 'Payment successful';
      case 'pending': return 'Payment pending';
      case 'failed': return 'Payment failed';
      default: return 'Unknown status';
    }
  }

  getMethodIcon(method: string): string {
    switch (method.toLowerCase()) {
      case 'cash': return 'attach_money';
      case 'cheque': return 'description';
      case 'dd': return 'inventory_2';
      case 'online': return 'account_balance';
      case 'card': return 'credit_card';
      default: return 'payment';
    }
  }

  getMethodLabel(method: string): string {
    switch (method.toLowerCase()) {
      case 'cash': return 'Cash Payment';
      case 'cheque': return 'Cheque';
      case 'dd': return 'Demand Draft';
      case 'online': return 'Online Transfer';
      case 'card': return 'Card Payment';
      default: return method;
    }
  }

  onLoadMore(): void {
    // Emit event or load more records
    console.log('Load more payments');
  }
}
