import { Component, Input, Output, EventEmitter, ViewChild, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatTableModule, MatTableDataSource } from '@angular/material/table';
import { MatPaginatorModule, MatPaginator } from '@angular/material/paginator';
import { MatSortModule, MatSort } from '@angular/material/sort';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatChipsModule } from '@angular/material/chips';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatMenuModule } from '@angular/material/menu';

export interface Installment {
  id: number;
  installmentName: string;
  dueDate: Date;
  amount: number;
  paidAmount: number;
  balanceAmount: number;
  status: 'paid' | 'partial' | 'overdue' | 'pending';
  lateFeeAmount?: number;
  discountAmount?: number;
  notes?: string;
  daysOverdue?: number;
}

@Component({
  selector: 'app-installment-table',
  standalone: true,
  imports: [
    CommonModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    MatButtonModule,
    MatIconModule,
    MatChipsModule,
    MatTooltipModule,
    MatProgressBarModule,
    MatMenuModule
  ],
  template: `
    <div class="installment-table-container">
      <!-- Header Actions -->
      <div class="table-header" *ngIf="showHeader">
        <h3>Fee Installments</h3>
        <div class="header-actions">
          <button mat-stroked-button (click)="selectAllRows()" *ngIf="!allSelected">
            <mat-icon>done_all</mat-icon>
            Select All
          </button>
          <button mat-stroked-button (click)="clearSelection()" *ngIf="allSelected" color="warn">
            <mat-icon>clear</mat-icon>
            Clear
          </button>
        </div>
      </div>

      <!-- Table -->
      <div class="mat-elevation-z1 table-wrapper">
        <table
          mat-table
          [dataSource]="dataSource"
          matSort
          class="installment-table"
          [trackBy]="trackByInstallmentId">
          
          <!-- Checkbox Column -->
          <ng-container matColumnDef="select" *ngIf="showSelection">
            <th mat-header-cell *matHeaderCellDef class="checkbox-column">
              <input
                type="checkbox"
                [checked]="allSelected"
                (change)="toggleSelectAll()">
            </th>
            <td mat-cell *matCellDef="let element" class="checkbox-column">
              <input
                type="checkbox"
                [checked]="isSelected(element.id)"
                (change)="toggleSelection(element.id)">
            </td>
          </ng-container>

          <!-- Installment Name Column -->
          <ng-container matColumnDef="installmentName">
            <th mat-header-cell *matHeaderCellDef mat-sort-header>Installment</th>
            <td mat-cell *matCellDef="let element" class="name-column">
              <div class="installment-name-cell">
                <span class="name">{{ element.installmentName }}</span>
                <span class="due-date" *ngIf="element.dueDate">
                  Due: {{ element.dueDate | date:'dd MMM yyyy' }}
                </span>
              </div>
            </td>
          </ng-container>

          <!-- Amount Column -->
          <ng-container matColumnDef="amount">
            <th mat-header-cell *matHeaderCellDef mat-sort-header>Amount</th>
            <td mat-cell *matCellDef="let element" class="amount-column">
              ₹{{ element.amount | number:'1.2-2' }}
            </td>
          </ng-container>

          <!-- Paid Column -->
          <ng-container matColumnDef="paid">
            <th mat-header-cell *matHeaderCellDef mat-sort-header>Paid</th>
            <td mat-cell *matCellDef="let element" class="paid-column">
              <span class="paid-badge">₹{{ element.paidAmount | number:'1.2-2' }}</span>
            </td>
          </ng-container>

          <!-- Balance Column -->
          <ng-container matColumnDef="balance">
            <th mat-header-cell *matHeaderCellDef mat-sort-header>Balance</th>
            <td mat-cell *matCellDef="let element" class="balance-column">
              <span class="balance-badge" [class.zero]="element.balanceAmount === 0">
                ₹{{ element.balanceAmount | number:'1.2-2' }}
              </span>
            </td>
          </ng-container>

          <!-- Status Column -->
          <ng-container matColumnDef="status">
            <th mat-header-cell *matHeaderCellDef mat-sort-header>Status</th>
            <td mat-cell *matCellDef="let element" class="status-column">
              <mat-chip
                [class]="'status-chip status-' + element.status"
                [matTooltip]="getStatusTooltip(element)">
                <mat-icon>{{ getStatusIcon(element.status) }}</mat-icon>
                {{ element.status | uppercase }}
              </mat-chip>

              <!-- Additional status info -->
              <div class="status-details" *ngIf="element.daysOverdue && element.daysOverdue > 0">
                <small class="overdue-badge">{{ element.daysOverdue }}d overdue</small>
              </div>
              <div class="status-details" *ngIf="element.lateFeeAmount && element.lateFeeAmount > 0">
                <small class="late-fee-badge">Late: ₹{{ element.lateFeeAmount | number:'1.2-2' }}</small>
              </div>
            </td>
          </ng-container>

          <!-- Progress Column -->
          <ng-container matColumnDef="progress">
            <th mat-header-cell *matHeaderCellDef>Progress</th>
            <td mat-cell *matCellDef="let element" class="progress-column">
              <div class="progress-section">
                <mat-progress-bar
                  mode="determinate"
                  [value]="getProgressPercentage(element)"
                  [class.over-collected]="getProgressPercentage(element) > 100">
                </mat-progress-bar>
                <small class="progress-text">{{ getProgressPercentage(element) | number:'1.0-0' }}%</small>
              </div>
            </td>
          </ng-container>

          <!-- Actions Column -->
          <ng-container matColumnDef="actions">
            <th mat-header-cell *matHeaderCellDef>Actions</th>
            <td mat-cell *matCellDef="let element" class="actions-column">
              <button
                mat-icon-button
                [matMenuTriggerFor]="menu"
                matTooltip="More options">
                <mat-icon>more_vert</mat-icon>
              </button>
              <mat-menu #menu="matMenu">
                <button
                  mat-menu-item
                  (click)="onPayClick(element)"
                  [disabled]="element.balanceAmount <= 0">
                  <mat-icon>payment</mat-icon>
                  <span>Pay</span>
                </button>
                <button mat-menu-item (click)="onViewDetails(element)">
                  <mat-icon>info</mat-icon>
                  <span>View Details</span>
                </button>
                <button mat-menu-item (click)="onPrintReceipt(element)">
                  <mat-icon>print</mat-icon>
                  <span>Print Receipt</span>
                </button>
              </mat-menu>
            </td>
          </ng-container>

          <!-- Table Headers -->
          <tr mat-header-row *matHeaderRowDef="displayedColumns; sticky: true" class="header-row"></tr>

          <!-- Table Rows -->
          <tr
            mat-row
            *matRowDef="let row; columns: displayedColumns;"
            [class.selected-row]="isSelected(row.id)"
            [class.overdue-row]="row.status === 'overdue'"
            class="data-row">
          </tr>

          <!-- No Data Row -->
          <tr class="no-data-row" *matNoDataRow>
            <td [attr.colspan]="displayedColumns.length" class="no-data-cell">
              <mat-icon>inbox</mat-icon>
              <p>No installments found</p>
            </td>
          </tr>
        </table>
      </div>

      <!-- Paginator -->
      <mat-paginator
        [pageSizeOptions]="[5, 10, 25, 50]"
        showFirstLastButtons>
      </mat-paginator>
    </div>
  `,
  styles: [`
    .installment-table-container {
      display: flex;
      flex-direction: column;
      gap: 16px;
    }

    .table-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 0 16px;

      h3 {
        margin: 0;
        font-size: 18px;
        font-weight: 600;
      }

      .header-actions {
        display: flex;
        gap: 8px;
      }
    }

    .table-wrapper {
      overflow-x: auto;
      border-radius: 4px;
    }

    .installment-table {
      width: 100%;
      background: white;

      .header-row {
        background: var(--md-surface-container-low);
        font-weight: 600;
        border-bottom: 2px solid var(--color-border);

        th {
          padding: 12px 16px !important;
          font-size: 13px;
          text-transform: uppercase;
          color: var(--color-text-secondary);
          letter-spacing: 0.5px;
        }
      }

      .data-row {
        border-bottom: 1px solid var(--color-border);
        transition: background-color 0.2s ease;

        &:hover {
          background-color: var(--md-surface-container-low);
        }

        &.selected-row {
          background-color: var(--md-primary-container);
        }

        &.overdue-row {
          background-color: var(--md-warning-container);

          &:hover {
            background-color: var(--md-warning-container);
          }
        }

        td {
          padding: 12px 16px !important;
          font-size: 14px;
        }
      }
    }

    .checkbox-column {
      width: 50px;
      text-align: center;
    }

    .name-column {
      min-width: 180px;

      .installment-name-cell {
        display: flex;
        flex-direction: column;
        gap: 4px;

        .name {
          font-weight: 600;
          color: var(--md-on-surface);
        }

        .due-date {
          font-size: 12px;
          color: var(--md-outline);
        }
      }
    }

    .amount-column {
      min-width: 100px;
      text-align: right;
      font-weight: 600;
      color: var(--md-primary);
    }

    .paid-column {
      min-width: 100px;
      text-align: right;

      .paid-badge {
        color: var(--md-success);
        font-weight: 600;
      }
    }

    .balance-column {
      min-width: 100px;
      text-align: right;

      .balance-badge {
        color: var(--md-error);
        font-weight: 600;

        &.zero {
          color: var(--md-success);
        }
      }
    }

    .status-column {
      min-width: 140px;

      .status-chip {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 4px 12px;
        font-size: 11px;
        font-weight: 600;
        text-transform: uppercase;
        border-radius: 16px;

        mat-icon {
          font-size: 14px;
          width: 14px;
          height: 14px;
        }

        &.status-paid { background: var(--md-success-container); color: var(--md-success); }
        &.status-partial { background: var(--md-warning-container); color: var(--md-warning); }
        &.status-overdue { background: var(--md-error-container); color: var(--md-error); }
        &.status-pending { background: var(--md-surface-container-low); color: var(--color-text-secondary); }
      }

      .status-details {
        margin-top: 4px;
        font-size: 11px;

        .overdue-badge { color: var(--md-error); font-weight: 600; }
        .late-fee-badge { color: #ff6f00; font-weight: 600; }
      }
    }

    .progress-column {
      min-width: 150px;

      .progress-section {
        display: flex;
        align-items: center;
        gap: 12px;

        mat-progress-bar {
          flex: 1;
          height: 6px;
          border-radius: 3px;

          &.over-collected {
            ::ng-deep .mat-progress-bar-fill::after {
              background-color: var(--md-success) !important;
            }
          }
        }

        .progress-text {
          min-width: 30px;
          text-align: right;
          font-weight: 600;
          color: var(--color-text-secondary);
        }
      }
    }

    .actions-column {
      text-align: center;
    }

    .no-data-row {
      .no-data-cell {
        padding: 60px 20px !important;
        text-align: center;
        color: var(--color-border);

        mat-icon {
          font-size: 48px;
          width: 48px;
          height: 48px;
          margin-bottom: 8px;
        }

        p {
          margin: 8px 0 0;
          font-size: 14px;
        }
      }
    }

    mat-paginator {
      background: var(--md-surface-container-low);
      border-top: 1px solid var(--color-border);
    }
  `]
})
export class InstallmentTableComponent implements OnInit {
  @Input() installments: Installment[] = [];
  @Input() showSelection = false;
  @Input() showHeader = true;
  @Input() pageSize = 10;

  @Output() paymentRequested = new EventEmitter<Installment>();
  @Output() detailsRequested = new EventEmitter<Installment>();
  @Output() selectionChanged = new EventEmitter<number[]>();
  @Output() printReceipt = new EventEmitter<Installment>();

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  dataSource = new MatTableDataSource<Installment>();
  displayedColumns: string[] = ['installmentName', 'amount', 'paid', 'balance', 'status', 'progress', 'actions'];
  selectedIds: Set<number> = new Set();
  allSelected = false;

  ngOnInit(): void {
    this.dataSource.data = this.installments;
    setTimeout(() => {
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    });

    if (this.showSelection) {
      this.displayedColumns.unshift('select');
    }
  }

  onPayClick(installment: Installment): void {
    this.paymentRequested.emit(installment);
  }

  onViewDetails(installment: Installment): void {
    this.detailsRequested.emit(installment);
  }

  onPrintReceipt(installment: Installment): void {
    this.printReceipt.emit(installment);
  }

  toggleSelection(id: number): void {
    if (this.selectedIds.has(id)) {
      this.selectedIds.delete(id);
    } else {
      this.selectedIds.add(id);
    }
    this.updateAllSelected();
    this.emitSelection();
  }

  toggleSelectAll(): void {
    if (this.allSelected) {
      this.selectedIds.clear();
    } else {
      this.installments.forEach(inst => this.selectedIds.add(inst.id));
    }
    this.updateAllSelected();
    this.emitSelection();
  }

  selectAllRows(): void {
    this.installments.forEach(inst => this.selectedIds.add(inst.id));
    this.updateAllSelected();
    this.emitSelection();
  }

  clearSelection(): void {
    this.selectedIds.clear();
    this.updateAllSelected();
    this.emitSelection();
  }

  isSelected(id: number): boolean {
    return this.selectedIds.has(id);
  }

  private updateAllSelected(): void {
    this.allSelected = this.selectedIds.size === this.installments.length && this.installments.length > 0;
  }

  private emitSelection(): void {
    this.selectionChanged.emit(Array.from(this.selectedIds));
  }

  getProgressPercentage(installment: Installment): number {
    if (installment.amount === 0) return 0;
    return (installment.paidAmount / installment.amount) * 100;
  }

  getStatusIcon(status: string): string {
    switch (status) {
      case 'paid': return 'check_circle';
      case 'partial': return 'hourglass_half';
      case 'overdue': return 'warning';
      case 'pending': return 'schedule';
      default: return 'help';
    }
  }

  getStatusTooltip(installment: Installment): string {
    if (installment.status === 'overdue' && installment.daysOverdue) {
      return `${installment.daysOverdue} days overdue`;
    }
    return installment.status.charAt(0).toUpperCase() + installment.status.slice(1);
  }

  trackByInstallmentId(index: number, item: Installment): number {
    return item.id;
  }
}
