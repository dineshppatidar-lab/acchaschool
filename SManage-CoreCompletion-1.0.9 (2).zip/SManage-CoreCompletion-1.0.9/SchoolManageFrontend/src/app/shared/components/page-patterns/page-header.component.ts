import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { BackButtonComponent } from '../back-button.component';

/**
 * Generic page header using the shared Advanced-Finance page pattern
 * (global classes live in styles/_students-system.scss — the `stu-`
 * prefix is the app-wide page-pattern layer, shared by Students,
 * Staff, Transport and future modules):
 *
 *   [back] Title
 *          Subtitle
 *   [projected actions row]
 *
 * Actions are projected so callers keep full control of permission
 * directives and button variants (raised primary / stroked secondary).
 */
@Component({
  selector: 'app-page-header',
  standalone: true,
  imports: [CommonModule, MatCardModule, BackButtonComponent],
  template: `
    <div class="stu-page-header">
      <div class="sph-title-row">
        @if (showBack) {
          <app-back-button />
        }
        <div class="sph-text">
          <h1 class="sph-title">{{ title }}</h1>
          @if (subtitle) {
            <p class="sph-subtitle">{{ subtitle }}</p>
          }
        </div>
      </div>
      @if (actions) {
        <div class="sph-actions">
          <ng-content select="[headerActions]"></ng-content>
          <ng-content select="[headerActionsEnd]"></ng-content>
        </div>
      }
    </div>
  `,
})
export class PageHeaderComponent {
  @Input() title = '';
  @Input() subtitle = '';
  /** Set false when a parent page already renders its own back navigation. */
  @Input() showBack = true;
  /** Hide the (empty) actions row entirely. */
  @Input() get actions(): boolean {
    return this._actions;
  }
  set actions(v: boolean) {
    this._actions = v ?? true;
  }
  private _actions = true;
}
