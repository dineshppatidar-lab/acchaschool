// Shared page-pattern components — the app-wide Advanced-Finance look
// (page header, KPI summary cards) used by Staff, Transport and future
// modules. Students/Fees have their own identical, module-prefixed
// components in shared/components/{students,fees}-module/.

export * from './page-header.component';
export * from './kpi-card.component';
