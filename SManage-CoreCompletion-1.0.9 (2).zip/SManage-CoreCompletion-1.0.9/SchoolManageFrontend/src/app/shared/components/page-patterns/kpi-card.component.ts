import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressBarModule } from '@angular/material/progress-bar';

export type KpiTone = 'primary' | 'success' | 'warn' | 'danger' | 'info' | 'neutral' | 'accent';

/**
 * Generic summary card using the shared Advanced-Finance page pattern
 * (global classes live in styles/_students-system.scss — the `stu-`
 * prefix is the app-wide page-pattern layer): mat-card + 48px plain
 * colored icon + 24px value + var(--color-text-secondary) label, with an optional 0–100
 * progress bar.
 *
 * Wrap instances in `<div class="stu-kpi-grid">…</div>`
 * (auto-fit minmax(280px, 1fr), 20px gap — same as Advanced Finance).
 */
@Component({
  selector: 'app-kpi-card',
  standalone: true,
  imports: [CommonModule, MatCardModule, MatIconModule, MatProgressBarModule],
  template: `
    <mat-card class="stu-kpi" [class]="'tone-' + tone">
      <mat-card-content>
        <div class="kpi-content">
          <mat-icon class="kpi-icon">{{ icon }}</mat-icon>
          <div class="kpi-info">
            <h3 class="kpi-value">{{ value }}</h3>
            <p class="kpi-label">{{ label }}</p>
            @if (progress !== null) {
              <mat-progress-bar class="kpi-progress" mode="determinate" [value]="progress" />
            }
          </div>
        </div>
      </mat-card-content>
    </mat-card>
  `,
})
export class KpiCardComponent {
  @Input({ required: true }) value: string | number = '';
  @Input({ required: true }) label = '';
  @Input() icon = 'insights';
  @Input() tone: KpiTone = 'primary';
  /** Optional 0–100 ratio rendered as a thin progress bar. */
  @Input() progress: number | null = null;
}
