import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Location } from '@angular/common';
import { Router } from '@angular/router';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';

/**
 * Retired: the compact topbar (MainLayout `app-header`) now owns back
 * navigation — it swaps its hamburger for a back arrow on nested screens
 * (and shows the page title). This in-page arrow was mobile-only and
 * duplicated the topbar one, so it is hidden at every width. Kept as a
 * component so existing usages keep compiling without mass edits.
 */
@Component({
  selector: 'app-back-button',
  standalone: true,
  imports: [CommonModule, MatButtonModule, MatIconModule],
  template: `
    <button mat-icon-button type="button" class="app-back-btn"
            aria-label="Go back" (click)="goBack()">
      <mat-icon>arrow_back</mat-icon>
    </button>
  `,
  styles: [`
    :host { display: none; }
 `]
})
export class BackButtonComponent {
  constructor(
    private location: Location,
    private router: Router
  ) {}

  goBack(): void {
    if (typeof window !== 'undefined' && window.history.length > 1) {
      this.location.back();
    } else {
      this.router.navigate(['/app/dashboard']);
    }
  }
}
