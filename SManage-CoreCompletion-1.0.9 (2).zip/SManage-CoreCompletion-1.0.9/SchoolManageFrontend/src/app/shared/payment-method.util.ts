/**
 * Maps a human-readable payment method name (e.g. "Credit Card", "bank_transfer")
 * to the backend PaymentMethodType enum integer.
 *
 * Handles variations with spaces, underscores, hyphens, and case differences.
 * Falls back to 1 (Cash) for unrecognized values.
 */
const PAYMENT_METHOD_MAP: Record<string, number> = {
  cash:          1,
  cheque:        2,
  check:         2,  // US spelling alias
  creditcard:    3,
  debitcard:     4,
  onlinetransfer:5,
  banktransfer:  5,  // alias for OnlineTransfer
  upi:           6,
  netbanking:    7,
  emi:           8,
};

export function mapPaymentMethodToEnum(name: string | null | undefined): number {
  if (!name) return 1;
  const key = name.toLowerCase().replace(/[\s_\-]/g, '');
  return PAYMENT_METHOD_MAP[key] ?? 1;
}

/**
 * Returns true if the given payment method requires a transaction ID
 * (i.e. it is an online/digital method, not Cash or Cheque).
 */
export function requiresTransactionId(name: string | null | undefined): boolean {
  if (!name) return false;
  const key = name.toLowerCase().replace(/[\s_\-]/g, '');
  return key !== 'cash' && key !== 'cheque' && key !== 'check';
}
