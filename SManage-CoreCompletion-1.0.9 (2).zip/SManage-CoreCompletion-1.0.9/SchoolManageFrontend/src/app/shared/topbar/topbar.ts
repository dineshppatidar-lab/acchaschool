import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { VoiceService } from '../../services/voice.service';
import { SidebarService } from '../services/sidebar.service';
import { AcademicYearContextService, AcademicYearItem } from '../services/academic-year-context.service';
import { ThemeService } from '../services/theme.service';

import { MatToolbarModule } from '@angular/material/toolbar';
import { MatIconModule } from '@angular/material/icon';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatButtonModule } from '@angular/material/button';
import { MatSelectModule } from '@angular/material/select';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-topbar',
  standalone: true,
  imports: [MatToolbarModule, MatIconModule, MatTooltipModule, MatButtonModule, MatSelectModule, MatProgressSpinnerModule, CommonModule, RouterModule],
  templateUrl: './topbar.html',
  styleUrls: ['./topbar.scss']
})
export class Topbar implements OnInit, OnDestroy {
  user: any;
  theme: string;
  avatarUrl: string = '';
  currentPage: string = '';
  notificationCount: number = 5;
  isListening: boolean = false;
  isLoading: boolean = false;

  // Academic Year context
  academicYears: AcademicYearItem[] = [];
  selectedYearId: number | null = null;
  isLoadingYears = false;
  private yearSub?: Subscription;
  private themeSub?: Subscription;

  constructor(
    public auth: AuthService, 
    private voice: VoiceService, 
    private sidebarService: SidebarService,
    private router: Router,
    private yearContext: AcademicYearContextService,
    private themeService: ThemeService
  ) {
    // Subscribe to user changes
    this.auth.user$.subscribe(user => {
      this.user = user;
      this.generateAvatar();
    });
    
    this.theme = this.themeService.currentTheme;
  }

  ngOnInit(): void {
    // Follow the single ThemeService source of truth (also covers the
    // sidebar toggle and the Settings page changing the theme).
    // Load user data from localStorage if available
    const userData = localStorage.getItem('user');
    if (userData && !this.user) {
      this.user = JSON.parse(userData);
      this.generateAvatar();
    }

    // Set current page based on router
    this.updateCurrentPage();

    // Load and subscribe to academic year context
    this.isLoadingYears = true;
    this.yearContext.loadAcademicYears().subscribe({
      complete: () => { this.isLoadingYears = false; }
    });
    this.yearSub = this.yearContext.academicYears$.subscribe(years => {
      this.academicYears = years;
    });
    this.yearContext.selectedAcademicYear$.subscribe(id => {
      this.selectedYearId = id;
    });
    this.themeSub = this.themeService.theme$.subscribe(theme => {
      this.theme = theme;
    });
  }

  ngOnDestroy(): void {
    this.yearSub?.unsubscribe();
    this.themeSub?.unsubscribe();
  }

  onAcademicYearChange(yearId: number): void {
    this.yearContext.setYear(yearId);
  }

  private generateAvatar(): void {
    if (this.user?.username) {
      const initial = this.user.username.charAt(0).toUpperCase();
      this.avatarUrl = `https://ui-avatars.com/api/?name=${initial}&background=00288e&color=ffffff&size=48&bold=true`;
    } else {
      this.avatarUrl = 'https://ui-avatars.com/api/?name=U&background=00288e&color=ffffff&size=48&bold=true';
    }
  }

  private updateCurrentPage(): void {
    // Extract current page from URL
    const url = this.router.url;
    const segments = url.split('/');
    if (segments.length > 2) {
      this.currentPage = segments[2].charAt(0).toUpperCase() + segments[2].slice(1);
    }
  }

  getTimeGreeting(): string {
    const hour = new Date().getHours();
    if (hour < 12) return 'Morning';
    if (hour < 17) return 'Afternoon';
    return 'Evening';
  }

  getFormattedUserRole(): string {
    if (!this.user) return 'Guest';
    
    const roles = this.user.roles || this.user.role || 'User';
    
    // Handle comma-separated roles
    if (roles.includes(',')) {
      const roleArray = roles.split(',').map((role: string) => role.trim());
      // Get the first (primary) role and format it
      const primaryRole = roleArray[0];
      const additionalCount = roleArray.length - 1;
      
      if (additionalCount > 0) {
        return `${this.formatSingleRole(primaryRole)} +${additionalCount}`;
      }
      return this.formatSingleRole(primaryRole);
    }
    
    return this.formatSingleRole(roles);
  }

  private formatSingleRole(role: string): string {
    // Convert role names to more user-friendly format
    const roleMap: { [key: string]: string } = {
      'admin': 'Administrator',
      'staff': 'Staff Member',
      'teacher': 'Teacher',
      'parent': 'Parent',
      'student': 'Student'
    };
    
    const lowerRole = role.toLowerCase();
    return roleMap[lowerRole] || role;
  }

  logout(): void {
    this.auth.logout();
  }

  openUserMenu(): void {
    // Implement user dropdown menu
    console.log('User menu clicked');
  }

  openSettings(): void {
    this.router.navigate(['/app/settings']);
  }

  toggleTheme(): void {
    this.themeService.toggleTheme();
  }

  startVoice(): void {
    this.isListening = true;
    
    this.voice.listen((command) => {
      this.isListening = false;
      
      // Voice command processing
      if (typeof window !== 'undefined') {
        if (command.includes('dashboard')) {
          this.router.navigate(['/app/dashboard']);
        } else if (command.includes('students')) {
          this.router.navigate(['/app/students/full-details']);
        } else if (command.includes('staff')) {
          this.router.navigate(['/app/staff']);
        } else if (command.includes('logout')) {
          this.auth.logout();
        }
      }
    });

    // Auto-stop listening after 5 seconds
    setTimeout(() => {
      this.isListening = false;
    }, 5000);
  }

  toggleSidebar(): void {
    this.sidebarService.toggleSidebar();
  }

  // Quick search functionality
  openQuickSearch(): void {
    // Implement quick search dialog
    console.log('Quick search opened');
  }

  // Notification functionality  
  openNotifications(): void {
    // Implement notifications panel
    console.log('Notifications opened');
  }
}
