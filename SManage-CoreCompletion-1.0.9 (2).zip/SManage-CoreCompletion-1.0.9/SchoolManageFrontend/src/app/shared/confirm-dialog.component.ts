import { Component, Inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatDialogModule, MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';

export interface ConfirmDialogData {
  title?: string;
  message?: string;
  confirmText?: string;
  cancelText?: string;
  icon?: string;
  /** 'warning' | 'danger' | 'info' | 'success' — controls icon color. Defaults to 'warning' */
  severity?: 'warning' | 'danger' | 'info' | 'success';
}

@Component({
  selector: 'app-confirm-dialog',
  standalone: true,
  imports: [CommonModule, MatDialogModule, MatButtonModule, MatIconModule],
  styles: [`
    :host { display: block; }

    .confirm-body {
      display: flex;
      flex-direction: column;
      align-items: center;
      padding: 24px 24px 8px;
      text-align: center;
    }

    .confirm-icon {
      margin-bottom: 16px;
    }

    .icon-circle {
      width: 56px;
      height: 56px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .icon-circle.warning  { background: var(--md-warning-container); }
    .icon-circle.danger   { background: var(--md-error-container); }
    .icon-circle.info     { background: var(--md-primary-container); }
    .icon-circle.success  { background: var(--md-success-container); }

    .icon-circle mat-icon {
      font-size: 28px;
      width: 28px;
      height: 28px;
    }

    .icon-circle.warning  mat-icon { color: var(--md-warning); }
    .icon-circle.danger   mat-icon { color: var(--md-error); }
    .icon-circle.info     mat-icon { color: var(--md-primary); }
    .icon-circle.success  mat-icon { color: var(--md-success); }

    .confirm-title {
      font-size: 18px;
      font-weight: 600;
      margin: 0 0 8px;
      color: var(--md-on-surface, var(--md-on-surface));
    }

    .confirm-message {
      font-size: 14px;
      color: var(--md-on-surface-variant, #43474E);
      margin: 0;
      line-height: 1.5;
    }

    /* Mobile: full width actions stacked */
    .confirm-actions {
      display: flex;
      gap: 8px;
      padding: 16px 24px 24px;
    }

    .confirm-actions button {
      flex: 1;
      min-height: 48px;
      border-radius: 24px !important;
      font-weight: 600 !important;
      font-size: 14px !important;
    }

    .cancel-btn {
      background: var(--md-surface-container-low, #F2F3F9) !important;
      color: var(--md-on-surface-variant, #43474E) !important;
    }

    .confirm-btn {
      background: var(--md-primary, var(--md-primary)) !important;
      color: white !important;
    }

    .confirm-btn.danger {
      background: var(--md-error, #BA1A1A) !important;
    }

    /* Tablet+: inline actions */
    @media (min-width: 600px) {
      .confirm-actions {
        justify-content: flex-end;
      }

      .confirm-actions button {
        flex: 0 0 auto;
        min-width: 100px;
      }
    }
  `],
  template: `
    <div class="confirm-body">
      <div class="confirm-icon">
        <div class="icon-circle" [ngClass]="data.severity || 'warning'">
          <mat-icon>{{ data.icon || 'help_outline' }}</mat-icon>
        </div>
      </div>
      <h2 class="confirm-title">{{ data.title || 'Are you sure?' }}</h2>
      <p class="confirm-message">{{ data.message || 'Please confirm this action.' }}</p>
    </div>
    <div class="confirm-actions">
      <button mat-flat-button class="cancel-btn" (click)="dialogRef.close(false)">
        {{ data.cancelText || 'Cancel' }}
      </button>
      <button mat-flat-button class="confirm-btn" [ngClass]="{ 'danger': data.severity === 'danger' }" (click)="dialogRef.close(true)">
        {{ data.confirmText || 'Confirm' }}
      </button>
    </div>
  `
})
export class ConfirmDialogComponent {
  constructor(
    public dialogRef: MatDialogRef<ConfirmDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: ConfirmDialogData
  ) {}
}
