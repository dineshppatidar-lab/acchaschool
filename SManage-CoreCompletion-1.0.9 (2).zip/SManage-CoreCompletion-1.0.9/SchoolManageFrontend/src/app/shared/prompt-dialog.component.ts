import { Component, Inject, ViewChild, ElementRef, AfterViewInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatDialogModule, MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';

export interface PromptDialogData {
  title?: string;
  message?: string;
  /** Initial value for the input (e.g. the name being renamed). */
  initialValue?: string;
  placeholder?: string;
  confirmText?: string;
  cancelText?: string;
  icon?: string;
  maxLength?: number;
}

/**
 * Material dialog with a single text input. Returns the trimmed entered string
 * on confirm, or empty/null when cancelled. Used for rename flows that
 * previously resorted to window.prompt().
 */
@Component({
  selector: 'app-prompt-dialog',
  standalone: true,
  imports: [CommonModule, FormsModule, MatDialogModule, MatButtonModule, MatIconModule, MatFormFieldModule, MatInputModule],
  styles: [`
    :host { display: block; }

    .prompt-body {
      padding: 24px 24px 0;
    }

    .prompt-header {
      display: flex;
      align-items: center;
      gap: 12px;
      margin-bottom: 16px;
    }

    .icon-circle {
      width: 44px;
      height: 44px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      background: var(--md-primary-container, var(--md-primary-container));
      flex-shrink: 0;
    }

    .icon-circle mat-icon {
      color: var(--md-primary, var(--md-primary));
      font-size: 24px;
      width: 24px;
      height: 24px;
    }

    .prompt-title {
      font-size: 18px;
      font-weight: 600;
      margin: 0;
      color: var(--md-on-surface, var(--md-on-surface));
    }

    .prompt-message {
      font-size: 14px;
      color: var(--md-on-surface-variant, #43474E);
      margin: 0 0 16px;
      line-height: 1.5;
    }

    .prompt-input mat-form-field { width: 100%; }

    .prompt-actions {
      display: flex;
      gap: 8px;
      padding: 16px 24px 24px;
    }

    .prompt-actions button {
      flex: 1;
      min-height: 48px;
      border-radius: 24px !important;
      font-weight: 600 !important;
      font-size: 14px !important;
    }

    .cancel-btn {
      background: var(--md-surface-container-low, #F2F3F9) !important;
      color: var(--md-on-surface-variant, #43474E) !important;
    }

    .confirm-btn {
      background: var(--md-primary, var(--md-primary)) !important;
      color: white !important;
    }

    @media (min-width: 600px) {
      .prompt-actions { justify-content: flex-end; }
      .prompt-actions button { flex: 0 0 auto; min-width: 100px; }
    }
  `],
  template: `
    <div class="prompt-body">
      <div class="prompt-header">
        <div class="icon-circle">
          <mat-icon>{{ data.icon || 'edit' }}</mat-icon>
        </div>
        <h2 class="prompt-title">{{ data.title || 'Enter a value' }}</h2>
      </div>
      <p class="prompt-message" *ngIf="data.message">{{ data.message }}</p>
      <div class="prompt-input">
        <mat-form-field appearance="outline">
          <mat-label>{{ data.placeholder || 'Value' }}</mat-label>
          <input matInput #inputEl [(ngModel)]="value" [maxlength]="data.maxLength || 100" (keyup.enter)="confirm()">
          <mat-hint *ngIf="value && value.trim() !== originalValue">Press Enter or click Save</mat-hint>
        </mat-form-field>
      </div>
    </div>
    <div class="prompt-actions">
      <button mat-flat-button class="cancel-btn" (click)="dialogRef.close(null)">
        {{ data.cancelText || 'Cancel' }}
      </button>
      <button mat-flat-button class="confirm-btn" (click)="confirm()" [disabled]="!value || !value.trim()">
        {{ data.confirmText || 'Save' }}
      </button>
    </div>
  `
})
export class PromptDialogComponent implements AfterViewInit {
  value = '';
  readonly originalValue: string = '';

  @ViewChild('inputEl') inputEl?: ElementRef<HTMLInputElement>;

  constructor(
    public dialogRef: MatDialogRef<PromptDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: PromptDialogData
  ) {
    this.value = (this.data.initialValue ?? '').trim();
    this.originalValue = this.value;
  }

  ngAfterViewInit(): void {
    // Select the existing text so typing replaces it (standard rename UX).
    setTimeout(() => this.inputEl?.nativeElement.select());
  }

  confirm(): void {
    const trimmed = (this.value ?? '').trim();
    if (!trimmed) return;
    this.dialogRef.close(trimmed);
  }
}
