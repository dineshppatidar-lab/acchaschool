export interface StudentFullDetailsDto {
  id?: number;
  firstName: string;
  lastName: string;
  dateOfBirth: Date;
  gender: string;
  address: string;
  contactNumber: string;
  email: string;
  admissionDate: Date;
  classId: number;
  sectionId: number;
  parentId?: number;
  rollNumber: string;
  busRouteId?: number;

  newParentDetails?: ParentDto;
  examResults?: ExamResultDto[];
  attendances?: AttendanceDto[];
  fees?: FeeDto[];
  hostelAllocation?: HostelAllocationDto;
  hostelLeaves?: HostelLeaveDto[];
  busAttendances?: BusAttendanceDto[];
  documents?: DocumentDto[];
}

export interface ParentDto {
  id?: number;
  firstName: string;
  lastName: string;
  contactNumber: string;
  email: string;
  occupation: string;
}

export interface ExamResultDto {
  id?: number;
  studentId: number;
  subjectId: number;
  examType: string;
  examDate: Date;
  marksObtained: number;
  totalMarks: number;
  grade: string;
  remarks: string;
}

export interface AttendanceDto {
  id?: number;
  date: Date;
  isPresent: boolean;
  remarks: string;
  studentId?: number;
  staffId?: number;
}

export interface FeeDto {
  id?: number;
  studentId: number;
  feeType: string;
  amount: number;
  dueDate: Date;
  status: string;
}

export interface HostelAllocationDto {
  id?: number;
  studentId: number;
  roomId: number;
  allocationDate: Date;
  releaseDate?: Date;
  bedNumber: string;
  mealPlan: string;
}

export interface HostelLeaveDto {
  id?: number;
  studentId: number;
  startDate: Date;
  endDate: Date;
  reason: string;
  status: string;
  approvedById?: number;
  requestDate: Date;
}

export interface BusAttendanceDto {
  id?: number;
  studentId: number;
  routeId: number;
  date: Date;
  isPresent: boolean;
  markingMethod: string;
}

export interface DocumentDto {
  id?: number;
  studentId?: number;                    // Optional for new documents
  documentType?: string;                 // Optional for new documents
  fileName?: string;                     // Optional - original file name
  filePath?: string;                     // Optional - file reference
  fileContent?: string;                  // Optional - Base64 encoded content
  fileSize?: number;                     // Optional - file size in bytes
  uploadDate?: Date;                     // Optional - upload date
}
