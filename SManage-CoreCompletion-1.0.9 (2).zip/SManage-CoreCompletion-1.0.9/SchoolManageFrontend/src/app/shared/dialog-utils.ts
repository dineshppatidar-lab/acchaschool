import { Injectable } from '@angular/core';
import { MatDialogConfig } from '@angular/material/dialog';

/**
 * Utility service for configuring dialogs based on screen size.
 * On mobile (< 600px): dialogs open full-screen.
 * On tablet+: dialogs open as centered cards.
 */
@Injectable({ providedIn: 'root' })
export class DialogUtils {
  private readonly MOBILE_BREAKPOINT = 600;

  /** Check if current viewport is mobile */
  isMobile(): boolean {
    return typeof window !== 'undefined' && window.innerWidth < this.MOBILE_BREAKPOINT;
  }

  /** Get a mobile-optimized MatDialogConfig */
  getMobileConfig(overrides?: MatDialogConfig): MatDialogConfig {
    const isMobile = this.isMobile();

    const base: MatDialogConfig = {
      width: isMobile ? '100vw' : '560px',
      maxWidth: isMobile ? '100vw' : '560px',
      height: isMobile ? '100vh' : undefined,
      maxHeight: isMobile ? '100vh' : '85vh',
      panelClass: isMobile
        ? ['edusphere-dialog', 'mobile-fullscreen-dialog']
        : ['edusphere-dialog'],
      autoFocus: true,
      restoreFocus: true,
      hasBackdrop: true,
      disableClose: false,
    };

    if (isMobile) {
      /* On mobile the dialog is always full-screen (styles/_dialogs.scss).
         Callers pass width/maxHeight sized for the tablet card layout
         (e.g. maxHeight: '90vh'); if they leaked onto the mobile config, the
         pane would be 90vh tall while the full-screen surface is 100vh —
         clipping the pinned bottom action bar (Cancel/Save) out of view.
         Dimension overrides are therefore ignored on mobile; everything
         else (data, etc.) still merges through. */
      const { width, maxWidth, height, maxHeight, ...rest } = overrides ?? {} as MatDialogConfig;
      return { ...base, ...rest };
    }

    return { ...base, ...overrides };
  }

  /** Get a bottom-sheet style dialog config (for actions, confirms, etc.) */
  getBottomSheetConfig(overrides?: MatDialogConfig): MatDialogConfig {
    const isMobile = this.isMobile();

    const base: MatDialogConfig = {
      width: isMobile ? '100vw' : '480px',
      maxWidth: isMobile ? '100vw' : '480px',
      height: undefined,
      maxHeight: '80vh',
      panelClass: ['edusphere-dialog', 'bottom-sheet-dialog'],
      position: isMobile ? { bottom: '0' } : undefined,
      autoFocus: true,
      restoreFocus: true,
      hasBackdrop: true,
      disableClose: false,
    };

    return { ...base, ...overrides };
  }

  /** Get an action-sheet style dialog config (for mobile action menus) */
  getActionSheetConfig(overrides?: MatDialogConfig): MatDialogConfig {
    const isMobile = this.isMobile();

    const base: MatDialogConfig = {
      width: isMobile ? '100vw' : '360px',
      maxWidth: isMobile ? '100vw' : '360px',
      maxHeight: '70vh',
      panelClass: ['edusphere-dialog', 'action-sheet-mobile'],
      position: isMobile ? { bottom: '0' } : undefined,
      autoFocus: true,
      hasBackdrop: true,
      disableClose: false,
    };

    return { ...base, ...overrides };
  }
}
