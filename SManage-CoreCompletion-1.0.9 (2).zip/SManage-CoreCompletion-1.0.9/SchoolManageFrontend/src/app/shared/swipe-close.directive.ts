import { Directive, ElementRef, Input, OnDestroy, OnInit, Renderer2 } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';

/**
 * Directive that enables swipe-down-to-close on mobile dialogs.
 * Apply to the dialog's content area or a drag handle element.
 *
 * Usage:
 *   <div mat-dialog-content appSwipeClose [swipeClose]="dialogRef">
 *     ...
 *   </div>
 *
 * Or on a handle:
 *   <div class="swipe-handle" appSwipeClose [swipeClose]="dialogRef"></div>
 */
@Directive({
  selector: '[appSwipeClose]',
  standalone: true,
})
export class SwipeCloseDirective implements OnInit, OnDestroy {
  /** Pass the MatDialogRef so the directive can close it on swipe */
  @Input() swipeClose!: MatDialogRef<any>;

  private startY = 0;
  private currentY = 0;
  private isDragging = false;
  private threshold = 100; // px to trigger close

  private touchStartFn!: (e: TouchEvent) => void;
  private touchMoveFn!: (e: TouchEvent) => void;
  private touchEndFn!: (e: TouchEvent) => void;

  constructor(
    private el: ElementRef<HTMLElement>,
    private renderer: Renderer2
  ) {}

  ngOnInit(): void {
    this.touchStartFn = this.onTouchStart.bind(this);
    this.touchMoveFn = this.onTouchMove.bind(this);
    this.touchEndFn = this.onTouchEnd.bind(this);

    this.el.nativeElement.addEventListener('touchstart', this.touchStartFn, { passive: true });
    this.el.nativeElement.addEventListener('touchmove', this.touchMoveFn, { passive: false });
    this.el.nativeElement.addEventListener('touchend', this.touchEndFn, { passive: true });
  }

  ngOnDestroy(): void {
    this.el.nativeElement.removeEventListener('touchstart', this.touchStartFn);
    this.el.nativeElement.removeEventListener('touchmove', this.touchMoveFn);
    this.el.nativeElement.removeEventListener('touchend', this.touchEndFn);
  }

  private onTouchStart(e: TouchEvent): void {
    this.startY = e.touches[0].clientY;
    this.isDragging = true;
  }

  private onTouchMove(e: TouchEvent): void {
    if (!this.isDragging) return;

    this.currentY = e.touches[0].clientY;
    const deltaY = this.currentY - this.startY;

    // Only allow downward swiping
    if (deltaY > 0) {
      // Prevent page scroll while dragging dialog
      e.preventDefault();

      // Apply transform for visual feedback
      const opacity = Math.max(0, 1 - deltaY / 400);
      const surface = this.el.nativeElement.closest('.mat-mdc-dialog-container') ||
                      this.el.nativeElement;
      this.renderer.setStyle(surface, 'transform', `translateY(${deltaY}px)`);
      this.renderer.setStyle(surface, 'opacity', opacity.toString());
      this.renderer.setStyle(surface, 'transition', 'none');
    }
  }

  private onTouchEnd(_e: TouchEvent): void {
    if (!this.isDragging) return;
    this.isDragging = false;

    const deltaY = this.currentY - this.startY;
    const surface = this.el.nativeElement.closest('.mat-mdc-dialog-container') ||
                    this.el.nativeElement;

    if (deltaY > this.threshold) {
      // Close dialog with animation
      this.renderer.setStyle(surface, 'transition', 'transform 0.2s ease-out, opacity 0.2s ease-out');
      this.renderer.setStyle(surface, 'transform', 'translateY(100%)');
      this.renderer.setStyle(surface, 'opacity', '0');
      setTimeout(() => {
        this.swipeClose?.close();
      }, 200);
    } else {
      // Snap back
      this.renderer.setStyle(surface, 'transition', 'transform 0.2s cubic-bezier(0.2, 0, 0, 1), opacity 0.2s ease');
      this.renderer.setStyle(surface, 'transform', 'translateY(0)');
      this.renderer.setStyle(surface, 'opacity', '1');
    }
  }
}
