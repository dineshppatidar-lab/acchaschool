import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatTooltipModule } from '@angular/material/tooltip';

export interface SubnavItem {
  label: string;
  icon?: string;
  route?: string;
  queryParams?: Record<string, any>;
  active?: boolean;
  disabled?: boolean;
}

@Component({
  selector: 'app-top-subnav',
  standalone: true,
  imports: [CommonModule, RouterModule, MatIconModule, MatButtonModule, MatTooltipModule],
  templateUrl: './top-subnav.component.html',
  styleUrls: ['./top-subnav.component.scss']
})
export class TopSubnavComponent {
  @Input() title = '';
  @Input() items: SubnavItem[] = [];
  @Input() visible = false;
  @Output() itemClick = new EventEmitter<SubnavItem>();

  onClick(item: SubnavItem, event: Event) {
    if (item.disabled) {
      event.preventDefault();
      return;
    }
    this.itemClick.emit(item);
  }
}
