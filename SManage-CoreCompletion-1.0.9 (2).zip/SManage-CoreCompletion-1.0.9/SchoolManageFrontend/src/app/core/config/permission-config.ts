// src/app/core/config/permission-config.ts
// Dynamic, Centralized Permission Configuration

/**
 * Centralized Permission Configuration System
 * This allows all permissions to be defined and maintained in one place
 * without needing to change code across the application
 */

export const PERMISSION_CONFIGURATION = {
  // Version for tracking configuration changes
  version: '1.0.0',
  lastUpdated: new Date(),

  // Permission metadata and descriptions
  permissions: {
    // User Management Permissions
    UsersView: {
      id: 1,
      name: 'UsersView',
      displayName: 'View Users',
      description: 'View user list and details',
      category: 'User Management',
      icon: 'people',
      requiresApproval: false,
    },
    UsersCreate: {
      id: 2,
      name: 'UsersCreate',
      displayName: 'Create Users',
      description: 'Create new user accounts',
      category: 'User Management',
      icon: 'person_add',
      requiresApproval: true,
    },
    UsersEdit: {
      id: 3,
      name: 'UsersEdit',
      displayName: 'Edit Users',
      description: 'Modify existing user accounts',
      category: 'User Management',
      icon: 'edit',
      requiresApproval: true,
    },
    UsersDelete: {
      id: 4,
      name: 'UsersDelete',
      displayName: 'Delete Users',
      description: 'Delete user accounts',
      category: 'User Management',
      icon: 'delete',
      requiresApproval: true,
      riskLevel: 'HIGH',
    },

    // Student Management Permissions
    StudentsView: {
      id: 10,
      name: 'StudentsView',
      displayName: 'View Students',
      description: 'View student list and basic information',
      category: 'Student Management',
      icon: 'school',
    },
    StudentsCreate: {
      id: 11,
      name: 'StudentsCreate',
      displayName: 'Create Students',
      description: 'Enroll new students',
      category: 'Student Management',
      icon: 'person_add',
    },
    StudentsEdit: {
      id: 12,
      name: 'StudentsEdit',
      displayName: 'Edit Student Details',
      description: 'Update student information',
      category: 'Student Management',
      icon: 'edit',
    },
    StudentsDelete: {
      id: 13,
      name: 'StudentsDelete',
      displayName: 'Delete Students',
      description: 'Remove student records',
      category: 'Student Management',
      icon: 'delete',
      riskLevel: 'HIGH',
    },
    StudentsViewDetails: {
      id: 14,
      name: 'StudentsViewDetails',
      displayName: 'View Student Details',
      description: 'View detailed student information',
      category: 'Student Management',
      icon: 'visibility',
      dependsOn: ['StudentsView'],
    },

    // Finance Permissions
    FeesView: {
      id: 50,
      name: 'FeesView',
      displayName: 'View Fees',
      description: 'View fee records and reports',
      category: 'Finance Management',
      icon: 'receipt',
    },
    FeesCollect: {
      id: 51,
      name: 'FeesCollect',
      displayName: 'Collect Fees',
      description: 'Record and process fee payments',
      category: 'Finance Management',
      icon: 'payment',
    },
    FeesManageStructure: {
      id: 52,
      name: 'FeesManageStructure',
      displayName: 'Manage Fee Structure',
      description: 'Define and modify fee structure',
      category: 'Finance Management',
      icon: 'settings',
      requiresApproval: true,
    },

    // System Permissions
    SystemManage: {
      id: 113,
      name: 'SystemManage',
      displayName: 'System Administration',
      description: 'Full system administration access',
      category: 'System',
      icon: 'admin_panel_settings',
      requiresApproval: true,
      riskLevel: 'CRITICAL',
    },
    SystemSettings: {
      id: 110,
      name: 'SystemSettings',
      displayName: 'System Settings',
      description: 'Configure system settings',
      category: 'System',
      icon: 'settings',
      requiresApproval: true,
    },
    SystemAuditLogs: {
      id: 112,
      name: 'SystemAuditLogs',
      displayName: 'View Audit Logs',
      description: 'Access system audit logs',
      category: 'System',
      icon: 'history',
    },
    SystemBackupRestore: {
      id: 111,
      name: 'SystemBackupRestore',
      displayName: 'Backup & Restore',
      description: 'Manage system backups and restoration',
      category: 'System',
      icon: 'backup',
      requiresApproval: true,
      riskLevel: 'CRITICAL',
    },

    // Dashboard
    DashboardView: {
      id: 103,
      name: 'DashboardView',
      displayName: 'View Dashboard',
      description: 'Access main dashboard',
      category: 'Dashboard',
      icon: 'dashboard',
    },
  },

  // Role-Permission Mappings
  rolePermissions: {
    SuperAdmin: {
      displayName: 'Super Administrator',
      description: 'Full system access with all permissions',
      color: 'var(--md-error)',
      permissions: ['*'], // Wildcard: grants ALL permissions automatically
      canGrantPermissions: true,
      canModifyRoles: true,
      isSuperAdmin: true, // Explicit superadmin flag
    },
    Administrator: {
      displayName: 'Administrator',
      description: 'Administrative access',
      color: 'var(--md-warning)',
      permissions: [
        'UsersView', 'UsersCreate', 'UsersEdit', 'UsersDelete',
        'StudentsView', 'StudentsCreate', 'StudentsEdit', 'StudentsDelete',
        'FeesView', 'FeesCollect', 'FeesManageStructure',
        'SystemSettings', 'SystemAuditLogs',
        'DashboardView'
      ],
      canGrantPermissions: true,
    },
    Principal: {
      displayName: 'Principal',
      description: 'School principal access',
      color: 'var(--md-primary)',
      permissions: [
        'StudentsView', 'StudentsViewDetails',
        'FeesView', 'FeesCollect',
        'SystemAuditLogs',
        'DashboardView',
        'ClassesView', 'SubjectsView', 'TimetablesView'
      ],
    },
    Teacher: {
      displayName: 'Teacher',
      description: 'Teacher access',
      color: 'var(--md-success)',
      permissions: [
        'StudentsView', 'StudentsViewDetails',
        'ClassesView', 'SubjectsView',
        'DashboardView'
      ],
    },
    Student: {
      displayName: 'Student',
      description: 'Student access',
      color: 'var(--md-primary-light)',
      permissions: [
        'StudentsViewDetails',
        'FeesView',
        'DashboardView'
      ],
    },
  },

  // Route Permission Requirements
  routePermissions: {
    'dashboard': {
      requiredPermission: 'DashboardView',
      fallbackRoute: '/',
      cacheSeconds: 3600,
    },
    'students': {
      requiredPermission: 'StudentsView',
      fallbackRoute: '/dashboard',
      canCache: true,
    },
    'students/edit/:id': {
      requiredPermission: 'StudentsEdit',
      requiresApproval: true,
      auditLog: true,
    },
    'fees': {
      requiredPermission: 'FeesView',
      fallbackRoute: '/dashboard',
    },
    'fees/collect': {
      requiredPermission: 'FeesCollect',
      requiresApproval: true,
      auditLog: true,
    },
    'admin/user-management': {
      requiredPermission: 'UsersView',
      fallbackRoute: '/dashboard',
      adminOnly: true,
    },
  },

  // API Endpoint Permission Configuration
  apiEndpoints: {
    // Students API
    'GET /api/students': {
      permission: 'StudentsView',
      operationType: 'read',
      rateLimitPerMinute: 100,
      cacheSeconds: 300,
    },
    'POST /api/students': {
      permission: 'StudentsCreate',
      operationType: 'create',
      requiresApproval: true,
      auditLog: true,
    },
    'PUT /api/students/:id': {
      permission: 'StudentsEdit',
      operationType: 'update',
      requiresApproval: true,
      auditLog: true,
    },
    'DELETE /api/students/:id': {
      permission: 'StudentsDelete',
      operationType: 'delete',
      requiresApproval: true,
      auditLog: true,
    },

    // Fees API
    'GET /api/fees': {
      permission: 'FeesView',
      operationType: 'read',
      cacheSeconds: 300,
    },
    'POST /api/fees': {
      permission: 'FeesCollect',
      operationType: 'create',
      requiresApproval: true,
      auditLog: true,
    },

    // Users API
    'GET /api/users': {
      permission: 'UsersView',
      operationType: 'read',
      adminOnly: true,
      cacheSeconds: 600,
    },
    'POST /api/users': {
      permission: 'UsersCreate',
      operationType: 'create',
      requiresApproval: true,
      auditLog: true,
      adminOnly: true,
    },
  },

  // Permission Categories for UI Organization
  categories: [
    {
      name: 'User Management',
      displayName: 'User Management',
      icon: 'people',
      description: 'User account and access management',
    },
    {
      name: 'Student Management',
      displayName: 'Student Management',
      icon: 'school',
      description: 'Student records and enrollment',
    },
    {
      name: 'Finance Management',
      displayName: 'Finance Management',
      icon: 'receipt',
      description: 'Fees and financial records',
    },
    {
      name: 'System',
      displayName: 'System Administration',
      icon: 'admin_panel_settings',
      description: 'System settings and administration',
    },
  ],

  // Permission Inheritance Rules
  inheritanceRules: {
    // If user has StudentsEdit, automatically get StudentsView
    StudentsEdit: ['StudentsView'],
    UsersEdit: ['UsersView'],
    FeesManageStructure: ['FeesView', 'FeesCollect'],
    SystemManage: ['*'], // SuperAdmin has all
  },

  // Feature Flags for Permission System
  features: {
    enableDynamicPermissions: true,
    enablePermissionCaching: true,
    enableAuditLogging: true,
    enablePermissionApproval: true,
    enableRoleBasedAccess: true,
    cacheTTL: 3600, // seconds
    maxCacheSize: 1000, // items
  },

  // Notification Settings
  notifications: {
    onPermissionDenied: {
      type: 'warning',
      duration: 3000,
      message: 'You do not have permission to access this resource',
    },
    onPermissionApprovalNeeded: {
      type: 'info',
      duration: 5000,
      message: 'This action requires administrative approval',
    },
  },
};

// Export for use across the application
export default PERMISSION_CONFIGURATION;
