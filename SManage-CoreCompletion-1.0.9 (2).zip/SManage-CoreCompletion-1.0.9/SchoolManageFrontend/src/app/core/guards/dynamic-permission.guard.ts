// src/app/core/guards/dynamic-permission.guard.ts
// Dynamic Permission Guard Using Configuration

import { Injectable } from '@angular/core';
import { CanActivate, CanLoad, ActivatedRouteSnapshot, RouterStateSnapshot, Route, UrlTree, Router } from '@angular/router';
import { Observable, of } from 'rxjs';
import { map, tap, catchError } from 'rxjs/operators';
import { AuthService } from '../services/auth.service';
import { DynamicPermissionService } from '../services/dynamic-permission.service';

@Injectable({
  providedIn: 'root'
})
export class DynamicPermissionGuard implements CanActivate, CanLoad {
  
  constructor(
    private permissionService: DynamicPermissionService,
    private authService: AuthService,
    private router: Router
  ) {}

  /**
   * Check if user can activate the route
   */
  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): Observable<boolean | UrlTree> {
    return this.checkPermission(route, state.url);
  }

  /**
   * Check if user can load the route
   */
  canLoad(
    route: Route,
    segments: any[]
  ): Observable<boolean | UrlTree> {
    const url = segments.map(s => s.path).join('/');
    return this.checkPermission(route, `/${url}`);
  }

  /**
   * Main permission checking logic - uses configuration
   */
  private checkPermission(
    route: Route | ActivatedRouteSnapshot,
    url: string
  ): Observable<boolean | UrlTree> {
    const currentUser = this.authService.getCurrentUser();
    if (!currentUser) {
      console.error('User not authenticated');
      return of(this.router.parseUrl('/login'));
    }

    return of(currentUser).pipe(
      map(user => {
        // Get required permission from route data
        const data = 'data' in route ? route.data : route.data;
        const requiredPermission = data?.['requiredPermission'] as string | null;
        const requiredRole = data?.['requiredRole'] as string | null;

        // If no permission specified, use configuration
        const routePath = this.extractRoutePath(url);
        const configuredPermission = this.permissionService.getRoutePermissionRequirement(routePath);

        const finalPermission = requiredPermission || configuredPermission;

        // Check permission
        if (finalPermission) {
          const userPermissions = new Set<string>((user as any).permissions || []);
          if (!this.permissionService.hasPermission(finalPermission, userPermissions)) {
            this.handlePermissionDenied(user as any, finalPermission, url);
            const fallback = this.permissionService.getRouteFallback(routePath);
            return this.router.parseUrl(fallback);
          }
        }

        // Check role if specified
        if (requiredRole) {
          const userRoles = (user as any).roles || [];
          if (!userRoles.includes(requiredRole)) {
            this.handleRoleDenied(user as any, requiredRole, url);
            return this.router.parseUrl('/dashboard');
          }
        }

        // Check if approval is needed
        if (this.permissionService.routeRequiresApproval(routePath)) {
          this.checkApprovalStatus(user as any, routePath);
        }

        // Log audit if configured
        if (this.permissionService.shouldAuditRoute(routePath)) {
          this.auditAccess(user as any, routePath, 'ACCESS_GRANTED');
        }

        return true;
      }),
      tap(result => {
        if (result === true) {
          console.log(`✅ Permission granted for route: ${url}`);
        }
      }),
      catchError(error => {
        console.error('Permission check error:', error);
        return of(false);
      })
    );
  }

  /**
   * Extract route path from full URL
   */
  private extractRoutePath(url: string): string {
    return url.split('?')[0].split('#')[0].substring(1); // Remove leading /
  }

  /**
   * Handle permission denied
   */
  private handlePermissionDenied(user: any, permission: string, url: string): void {
    const config = this.permissionService.getPermissionConfig(permission);
    const message = `You don't have permission to access "${config?.displayName || permission}"`;
    
    console.error(message);
    console.warn(`❌ Permission denied: ${permission} for user ${user.id}`, {
      permission,
      user: user.username,
      requestedUrl: url,
      userPermissions: Array.from(user.permissions || []),
    });

    this.auditAccess(user, url, 'PERMISSION_DENIED', { permission });
  }

  /**
   * Handle role denied
   */
  private handleRoleDenied(user: any, role: string, url: string): void {
    console.error(`This action requires ${role} role`);
    console.warn(`❌ Role denied: ${role} for user ${user.id}`, {
      role,
      user: user.username,
      userRoles: user.roles || [],
      requestedUrl: url,
    });

    this.auditAccess(user, url, 'ROLE_DENIED', { role });
  }

  /**
   * Check if approval is needed
   */
  private checkApprovalStatus(user: any, route: string): void {
    // TODO: Check approval queue and notify user if action is pending approval
    console.log(`ℹ️ Route ${route} requires approval for user ${user.username}`);
  }

  /**
   * Audit route access
   */
  private auditAccess(
    user: any,
    route: string,
    action: string,
    metadata?: any
  ): void {
    // TODO: Call audit service to log access
    console.log(`📝 Audit: ${action} - Route: ${route} - User: ${user.username}`, metadata);
  }
}
