import { Injectable } from '@angular/core';
import { CanActivate, CanLoad, ActivatedRouteSnapshot, RouterStateSnapshot, Route, UrlSegment, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { map, take, filter } from 'rxjs/operators';
import { PermissionService } from '../services/permission.service';
import { Permission, UserRole } from '../models/permission.model';

@Injectable({
  providedIn: 'root'
})
export class PermissionGuard implements CanActivate, CanLoad {
  constructor(
    private permissionService: PermissionService,
    private router: Router
  ) {}

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> | boolean {
    return this.checkAccess(route.data, state.url);
  }

  canLoad(route: Route, segments: UrlSegment[]): Observable<boolean> | boolean {
    const url = segments.map(s => s.path).join('/');
    return this.checkAccess(route.data || {}, url);
  }

  private checkAccess(routeData: any, attemptedUrl: string = ''): Observable<boolean> | boolean {
    // If the current user is SuperAdmin, allow access immediately.
    // This avoids race conditions where permissions are loaded asynchronously and
    // the guard runs before the permission list is available.
    const currentRole = this.permissionService.getCurrentRole();
    if (currentRole === UserRole.SuperAdmin) {
      return true;
    }

    // Wait for permission loading to actually finish before evaluating gate.
    // filter+take(1) (instead of take(1) alone) skips the initial `false` state so the
    // check runs against the authoritative loaded permissions, not a provisional snapshot.
    return this.permissionService.permissionsLoaded$.pipe(
      filter(loaded => loaded),
      take(1),
      map(loaded => {
        if (!loaded) {
          // fallback deny while permissions not fully loaded, but should not happen due to guard waits
          return false;
        }

        // Now evaluate actual check below
        if (routeData['requiredPermission']) {
          const permission = routeData['requiredPermission'] as Permission;
          return this.permissionService.hasPermission(permission);
        }
        if (routeData['requiredRoles']) {
          const roles = routeData['requiredRoles'] as UserRole[];
          return this.permissionService.hasAnyRole(roles);
        }
        if (routeData['requiredReadPermission']) {
          const permission = routeData['requiredReadPermission'] as Permission;
          return this.permissionService.canRead(permission);
        }
        if (routeData['requiredWritePermission']) {
          const permission = routeData['requiredWritePermission'] as Permission;
          return this.permissionService.canWrite(permission);
        }
        return true;
      }),
      map(allowed => {
        if (!allowed) {
          // Pass context about which permission was required and which URL was attempted
          const navigationExtras = {
            state: {
              requiredPermission: routeData['requiredPermission'],
              requiredRoles: routeData['requiredRoles'],
              attemptedUrl: attemptedUrl
            }
          };
          this.router.navigate(['/access-denied'], navigationExtras);
        }
        return allowed;
      })
    );

    // removed old immediate checks; moved above inside permissionsLoaded$.pipe
  }
}

@Injectable({
  providedIn: 'root'
})
export class RoleGuard implements CanActivate, CanLoad {
  constructor(
    private permissionService: PermissionService,
    private router: Router
  ) {}

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> | boolean {
    const requiredRoles = route.data['roles'] as UserRole[];
    if (!requiredRoles || requiredRoles.length === 0) {
      return true;
    }

    return this.permissionService.hasAnyRole$(requiredRoles).pipe(
      take(1),
      map(hasRole => {
        if (!hasRole) {
          this.router.navigate(['/access-denied']);
          return false;
        }
        return true;
      })
    );
  }

  canLoad(route: Route, segments: UrlSegment[]): Observable<boolean> | boolean {
    const requiredRoles = route.data?.['roles'] as UserRole[];
    if (!requiredRoles || requiredRoles.length === 0) {
      return true;
    }

    return this.permissionService.hasAnyRole$(requiredRoles).pipe(
      take(1),
      map(hasRole => {
        if (!hasRole) {
          this.router.navigate(['/access-denied']);
          return false;
        }
        return true;
      })
    );
  }
}