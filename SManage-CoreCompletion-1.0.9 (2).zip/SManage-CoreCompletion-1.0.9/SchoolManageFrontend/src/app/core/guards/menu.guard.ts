import { Injectable, inject } from '@angular/core';
import { CanActivateFn, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { Observable, of } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { DynamicMenuService, MenuItem } from '../../services/dynamic-menu.service';
import { AuthService } from '../../services/auth.service';

/**
 * Menu-based Route Guard
 * 
 * Checks if:
 * 1. User has permission for the accessed route
 * 2. Route is accessible via a menu item
 * 3. Menu item is active
 * 
 * This can be used as a functional guard or injectable service
 */
@Injectable({
  providedIn: 'root'
})
export class MenuGuard {
  constructor(
    private menuService: DynamicMenuService,
    private authService: AuthService,
    private router: Router
  ) {}

  /**
   * Check if user can access a route based on menu permissions
   */
  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> {
    return this.checkMenuAccess(state.url);
  }

  /**
   * Check if user can access a route based on menu permissions
   * Functional guard version
   */
  private checkMenuAccess(url: string): Observable<boolean> {
    // Skip check for public routes
    if (this.isPublicRoute(url)) {
      return of(true);
    }

    // Check if user is authenticated
    if (!this.authService.isAuthenticated()) {
      this.router.navigate(['/login']);
      return of(false);
    }

    // Load and check menu
    return this.menuService.loadMainMenu().pipe(
      map(menu => {
        const menuItem = this.findMenuItemByRoute(menu, url);

        if (!menuItem) {
          console.warn(`No menu item found for route: ${url}`);
          this.router.navigate(['/app/dashboard']);
          return false;
        }

        if (!menuItem.isActive) {
          console.warn(`Menu item is inactive for route: ${url}`);
          this.router.navigate(['/app/dashboard']);
          return false;
        }

        if (!this.menuService.hasPermission(menuItem)) {
          console.warn(`User does not have permission for route: ${url}`);
          this.router.navigate(['/access-denied']);
          return false;
        }

        return true;
      }),
      catchError(error => {
        console.error('Error checking menu access:', error);
        // Fail CLOSED: if permission data cannot be reliably evaluated (menu API
        // error), protected access must not be granted. Route to the dashboard,
        // which every authenticated role can reach, instead of allowing access.
        this.router.navigate(['/app/dashboard']);
        return of(false);
      })
    );
  }

  /**
   * Find menu item by route recursively
   */
  private findMenuItemByRoute(
    menu: MenuItem[],
    route: string
  ): MenuItem | undefined {
    for (const item of menu) {
      if (item.route && this.routeMatches(item.route, route)) {
        return item;
      }

      if (item.children && item.children.length > 0) {
        const found = this.findMenuItemByRoute(item.children, route);
        if (found) {
          return found;
        }
      }
    }

    return undefined;
  }

  /**
   * Check if route matches (handles wildcards and parameters)
   */
  private routeMatches(menuRoute: string, currentRoute: string): boolean {
    // Exact match
    if (menuRoute === currentRoute) {
      return true;
    }

    // Parent route match (e.g., /app/academic matches /app/academic/classes)
    if (currentRoute.startsWith(menuRoute + '/')) {
      return true;
    }

    // Pattern matching for routes with parameters
    const menuPattern = menuRoute
      .replace(/:[^/]+/g, '[^/]+') // Replace :param with regex
      .replace(/\*/g, '.*'); // Replace * with regex

    const regex = new RegExp(`^${menuPattern}$`);
    return regex.test(currentRoute);
  }

  /**
   * Public routes that don't require menu checks
   */
  private isPublicRoute(url: string): boolean {
    const publicRoutes = [
      '/login',
      '/register',
      '/forgot-password',
      '/reset-password',
      '/access-denied',
      '/404',
      '/500'
    ];

    return publicRoutes.some(route => url.startsWith(route));
  }
}

/**
 * Functional menu guard using inject
 * Usage: canActivate: [menuGuard]
 */
export const menuGuard: CanActivateFn = (route, state) => {
  const menuService = inject(DynamicMenuService);
  const authService = inject(AuthService);
  const router = inject(Router);

  const url = state.url;

  // Skip check for public routes
  const publicRoutes = [
    '/login',
    '/register',
    '/forgot-password',
    '/reset-password',
    '/access-denied',
    '/404',
    '/500'
  ];

  if (publicRoutes.some(r => url.startsWith(r))) {
    return true;
  }

  // Check if user is authenticated
  if (!authService.isAuthenticated()) {
    router.navigate(['/login']);
    return false;
  }

  // Load and check menu
  return menuService.loadMainMenu().pipe(
    map((menu: MenuItem[]) => {
      const menuItem = findMenuItemByRoute(menu, url);

      if (!menuItem) {
        console.warn(`No menu item found for route: ${url}`);
        router.navigate(['/app/dashboard']);
        return false;
      }

      if (menuItem.isActive === false) {
        console.warn(`Menu item is inactive for route: ${url}`);
        router.navigate(['/app/dashboard']);
        return false;
      }

      if (!menuService.hasPermission(menuItem)) {
        console.warn(`User does not have permission for route: ${url}`);
        router.navigate(['/access-denied']);
        return false;
      }

      return true;
    }),
    catchError(error => {
      console.error('Error checking menu access:', error);
      // Fail CLOSED (same rule as the class version above): never grant access
      // when the permission evaluation failed.
      router.navigate(['/app/dashboard']);
      return of(false);
    })
  );
};

/**
 * Helper function to find menu item by route recursively
 */
function findMenuItemByRoute(
  menu: MenuItem[],
  route: string
): MenuItem | undefined {
  for (const item of menu) {
    if (item.route && routeMatches(item.route, route)) {
      return item;
    }

    if (item.children && item.children.length > 0) {
      const found = findMenuItemByRoute(item.children, route);
      if (found) {
        return found;
      }
    }
  }

  return undefined;
}

/**
 * Helper function to check if route matches (handles wildcards and parameters)
 */
function routeMatches(menuRoute: string, currentRoute: string): boolean {
  // Exact match
  if (menuRoute === currentRoute) {
    return true;
  }

  // Parent route match (e.g., /app/academic matches /app/academic/classes)
  if (currentRoute.startsWith(menuRoute + '/')) {
    return true;
  }

  // Pattern matching for routes with parameters
  const menuPattern = menuRoute
    .replace(/:[^/]+/g, '[^/]+') // Replace :param with regex
    .replace(/\*/g, '.*'); // Replace * with regex

  const regex = new RegExp(`^${menuPattern}$`);
  return regex.test(currentRoute);
}
