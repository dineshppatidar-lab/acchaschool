// src/app/core/services/dynamic-permission.service.ts
// Dynamic Permission Service with Caching and Configuration Support

import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { map, shareReplay } from 'rxjs/operators';
import { PERMISSION_CONFIGURATION } from '../config/permission-config';

export interface PermissionConfig {
  id: number;
  name: string;
  displayName: string;
  description: string;
  category: string;
  icon?: string;
  requiresApproval?: boolean;
  riskLevel?: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  dependsOn?: string[];
}

export interface RoleConfig {
  displayName: string;
  description: string;
  color: string;
  permissions: string[];
  canGrantPermissions?: boolean;
  canModifyRoles?: boolean;
}

@Injectable({
  providedIn: 'root'
})
export class DynamicPermissionService {
  private permissionCache = new Map<string, boolean>();
  private roleCache = new Map<string, RoleConfig>();
  private userPermissionsSubject = new BehaviorSubject<Set<string>>(new Set());
  private configSubject = new BehaviorSubject<typeof PERMISSION_CONFIGURATION>(
    PERMISSION_CONFIGURATION
  );

  // Configuration observables
  public permissions$ = this.configSubject.asObservable().pipe(
    map(config => config.permissions),
    shareReplay(1)
  );

  public rolePermissions$ = this.configSubject.asObservable().pipe(
    map(config => config.rolePermissions),
    shareReplay(1)
  );

  public routePermissions$ = this.configSubject.asObservable().pipe(
    map(config => config.routePermissions),
    shareReplay(1)
  );

  public apiEndpoints$ = this.configSubject.asObservable().pipe(
    map(config => config.apiEndpoints),
    shareReplay(1)
  );

  constructor() {
    this.initializeCache();
  }

  /**
   * Initialize role cache from configuration
   */
  private initializeCache(): void {
    const config = this.configSubject.value;
    Object.entries(config.rolePermissions).forEach(([role, roleConfig]) => {
      this.roleCache.set(role, roleConfig as RoleConfig);
    });
  }

  /**
   * Get all available permissions from configuration
   */
  getAvailablePermissions(): PermissionConfig[] {
    const config = this.configSubject.value;
    return Object.values(config.permissions) as PermissionConfig[];
  }

  /**
   * Get permission config by name
   */
  getPermissionConfig(permissionName: string): PermissionConfig | undefined {
    const config = this.configSubject.value;
    return (config.permissions as any)[permissionName];
  }

  /**
   * Get permissions for a specific role from configuration
   */
  getRolePermissions(roleName: string): string[] {
    const config = this.configSubject.value;
    const roleConfig = (config.rolePermissions as any)[roleName];
    if (!roleConfig) return [];

    // Handle wildcard permissions
    if (roleConfig.permissions.includes('*')) {
      return this.getAllPermissionNames();
    }

    // Expand inherited permissions
    return this.expandPermissions(roleConfig.permissions);
  }

  /**
   * Expand permissions based on inheritance rules
   */
  private expandPermissions(permissions: string[]): string[] {
    const config = this.configSubject.value;
    const expanded = new Set(permissions);
    const inheritanceRules = config.inheritanceRules;

    // Keep expanding until no new permissions are added
    let changed = true;
    while (changed) {
      changed = false;
      const currentPermissions = Array.from(expanded);

      for (const permission of currentPermissions) {
        const inherited = (inheritanceRules as any)[permission];
        if (inherited) {
          for (const inheritedPerm of inherited) {
            if (inheritedPerm === '*') {
              // Add all permissions
              this.getAllPermissionNames().forEach(p => expanded.add(p));
              changed = true;
            } else if (!expanded.has(inheritedPerm)) {
              expanded.add(inheritedPerm);
              changed = true;
            }
          }
        }
      }
    }

    return Array.from(expanded);
  }

  /**
   * Get all permission names
   */
  private getAllPermissionNames(): string[] {
    const config = this.configSubject.value;
    return Object.keys(config.permissions);
  }

  /**
   * Check if user has a specific permission
   */
  hasPermission(permissionName: string, userPermissions: Set<string>): boolean {
    // Check cache
    const cacheKey = `${permissionName}:${Array.from(userPermissions).sort().join(',')}`;
    if (this.permissionCache.has(cacheKey)) {
      return this.permissionCache.get(cacheKey)!;
    }

    // Check if user has the permission
    const hasPermission = userPermissions.has(permissionName);

    // Cache result
    if (this.permissionCache.size < (this.configSubject.value.features.maxCacheSize || 1000)) {
      this.permissionCache.set(cacheKey, hasPermission);
    }

    return hasPermission;
  }

  /**
   * Check if user has any of the specified permissions
   */
  hasAnyPermission(
    permissionNames: string[],
    userPermissions: Set<string>
  ): boolean {
    return permissionNames.some(perm => this.hasPermission(perm, userPermissions));
  }

  /**
   * Check if user has all specified permissions
   */
  hasAllPermissions(
    permissionNames: string[],
    userPermissions: Set<string>
  ): boolean {
    return permissionNames.every(perm => this.hasPermission(perm, userPermissions));
  }

  /**
   * Get permission requirement for a route
   */
  getRoutePermissionRequirement(route: string): string | null {
    const config = this.configSubject.value;
    const routeConfig = (config.routePermissions as any)[route];
    return routeConfig?.requiredPermission || null;
  }

  /**
   * Get API endpoint configuration
   */
  getApiEndpointConfig(endpoint: string): any {
    const config = this.configSubject.value;
    return (config.apiEndpoints as any)[endpoint];
  }

  /**
   * Update user permissions (after login/role change)
   */
  setUserPermissions(permissions: string[]): void {
    this.userPermissionsSubject.next(new Set(permissions));
    this.clearCache();
  }

  /**
   * Get current user permissions observable
   */
  getUserPermissions$(): Observable<Set<string>> {
    return this.userPermissionsSubject.asObservable();
  }

  /**
   * Update permission configuration dynamically
   */
  updateConfiguration(newConfig: Partial<typeof PERMISSION_CONFIGURATION>): void {
    const currentConfig = this.configSubject.value;
    const updatedConfig = { ...currentConfig, ...newConfig };
    this.configSubject.next(updatedConfig);
    this.clearCache();
    this.initializeCache();
  }

  /**
   * Get permission category
   */
  getPermissionCategory(permissionName: string): string | undefined {
    const config = this.getPermissionConfig(permissionName);
    return config?.category;
  }

  /**
   * Get all permissions grouped by category
   */
  getPermissionsByCategory(): Map<string, PermissionConfig[]> {
    const result = new Map<string, PermissionConfig[]>();
    const permissions = this.getAvailablePermissions();

    permissions.forEach(permission => {
      const category = permission.category;
      if (!result.has(category)) {
        result.set(category, []);
      }
      result.get(category)!.push(permission);
    });

    return result;
  }

  /**
   * Check if permission requires approval
   */
  requiresApproval(permissionName: string): boolean {
    const config = this.getPermissionConfig(permissionName);
    return config?.requiresApproval || false;
  }

  /**
   * Get risk level of a permission
   */
  getRiskLevel(permissionName: string): string | undefined {
    const config = this.getPermissionConfig(permissionName);
    return config?.riskLevel;
  }

  /**
   * Get permissions with a specific risk level
   */
  getPermissionsByRiskLevel(riskLevel: string): PermissionConfig[] {
    return this.getAvailablePermissions().filter(
      p => p.riskLevel === riskLevel
    );
  }

  /**
   * Check if permission can be granted by a role
   */
  canRoleGrantPermission(roleName: string): boolean {
    const config = this.configSubject.value;
    const roleConfig = (config.rolePermissions as any)[roleName];
    return roleConfig?.canGrantPermissions || false;
  }

  /**
   * Check if a role is SuperAdmin
   * SuperAdmin has all permissions via wildcard ['*']
   */
  isSuperAdminRole(roleName: string): boolean {
    const config = this.configSubject.value;
    const roleConfig = (config.rolePermissions as any)[roleName];
    return roleName === 'SuperAdmin' || 
           roleConfig?.isSuperAdmin === true ||
           roleConfig?.permissions?.includes('*') === true;
  }

  /**
   * Check if user has SuperAdmin permissions
   * Useful for bypassing certain checks or granting full access
   */
  hasSuperAdminPermissions(userPermissions: Set<string>): boolean {
    // If user has all permissions (from wildcard expansion)
    const config = this.configSubject.value;
    const allPermissions = this.getAllPermissionNames();
    
    // Check if user has most critical permissions
    const criticalPerms = ['UsersDelete', 'SystemManage', 'SystemSettings'];
    return criticalPerms.every(perm => userPermissions.has(perm));
  }

  /**
   * Get route fallback when permission denied
   */
  getRouteFallback(route: string): string {
    const config = this.configSubject.value;
    const routeConfig = (config.routePermissions as any)[route];
    return routeConfig?.fallbackRoute || '/dashboard';
  }

  /**
   * Check if route requires approval
   */
  routeRequiresApproval(route: string): boolean {
    const config = this.configSubject.value;
    const routeConfig = (config.routePermissions as any)[route];
    return routeConfig?.requiresApproval || false;
  }

  /**
   * Check if route should be audited
   */
  shouldAuditRoute(route: string): boolean {
    const config = this.configSubject.value;
    const routeConfig = (config.routePermissions as any)[route];
    return routeConfig?.auditLog || false;
  }

  /**
   * Clear cache
   */
  clearCache(): void {
    this.permissionCache.clear();
  }

  /**
   * Get cache statistics
   */
  getCacheStats(): { size: number; maxSize: number } {
    return {
      size: this.permissionCache.size,
      maxSize: this.configSubject.value.features.maxCacheSize || 1000,
    };
  }

  /**
   * Is feature enabled
   */
  isFeatureEnabled(featureName: keyof typeof PERMISSION_CONFIGURATION.features): boolean {
    const features = this.configSubject.value.features;
    return (features as any)[featureName] || false;
  }

  /**
   * Export current configuration (for backup/migration)
   */
  exportConfiguration(): typeof PERMISSION_CONFIGURATION {
    return JSON.parse(JSON.stringify(this.configSubject.value));
  }

  /**
   * Import configuration (for migration/update)
   */
  importConfiguration(config: typeof PERMISSION_CONFIGURATION): void {
    this.updateConfiguration(config);
  }
}
