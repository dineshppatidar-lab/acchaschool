import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { shareReplay, catchError, map } from 'rxjs/operators';
import { environment } from '../../../environments/environment';

export interface MasterDataResponse {
  success: boolean;
  data: any;
}

export interface DropdownItem {
  id: number;
  name: string;
}

@Injectable({
  providedIn: 'root'
})
export class MasterDataService {
  // Caching Observables
  private standardLookups$: Observable<{ bloodGroups: DropdownItem[], religions: DropdownItem[], categories: DropdownItem[] }> | undefined;
  private parentLookups$: Observable<{ relationships: DropdownItem[], occupations: DropdownItem[], incomeGroups: DropdownItem[] }> | undefined;
  private academicYears$: Observable<DropdownItem[]> | undefined;

  private apiUrl = `${environment.apiUrl}/api/master-data`;
  private academicUrl = `${environment.apiUrl}/api/academic`;
  private advancedAcademicUrl = `${environment.apiUrl}/api/advancedacademic`;
  private lookupUrl = `${environment.apiUrl}/api/lookup`;

  constructor(private http: HttpClient) {}

  // Fetch standard lookup tables (Blood Groups, Religions, Categories)
  // Now with client-side caching and error handling
  getStandardLookups(): Observable<{ bloodGroups: DropdownItem[], religions: DropdownItem[], categories: DropdownItem[] }> {
    if (!this.standardLookups$) {
      this.standardLookups$ = this.http.get<{ bloodGroups: DropdownItem[], religions: DropdownItem[], categories: DropdownItem[] }>(`${this.apiUrl}/student-lookups`).pipe(
        shareReplay(1), // Cache the result and replay for subsequent subscribers
        catchError(() => of({ bloodGroups: [], religions: [], categories: [] })) // On error, return an empty object to prevent UI crash
      );
    }
    return this.standardLookups$;
  }

  // Fetch Parent/Guardian Lookups (Relationships, Occupations)
  // Now with client-side caching and error handling
  getParentLookups(): Observable<{ relationships: DropdownItem[], occupations: DropdownItem[], incomeGroups: DropdownItem[] }> {
    if (!this.parentLookups$) {
      this.parentLookups$ = this.http.get<{ relationships: DropdownItem[], occupations: DropdownItem[], incomeGroups: DropdownItem[] }>(`${this.apiUrl}/parent-lookups`).pipe(
        shareReplay(1),
        catchError(() => of({ relationships: [], occupations: [], incomeGroups: [] }))
      );
    }
    return this.parentLookups$;
  }

  // Fetch all active classes for the current tenant
  // This is not cached as it might change more frequently.
  getClasses(): Observable<DropdownItem[]> {
    return this.http.get<any>(`${this.academicUrl}/all`).pipe(
      map((response: any) => {
        const data = response?.data || response;
        if (Array.isArray(data)) {
          return data.map((cls: any) => ({
            id: cls.id || cls.Id,
            name: cls.name || cls.Name
          }));
        }
        return [];
      }),
      catchError(error => {
        console.error('Error fetching classes:', error);
        return of([]);
      })
    );
  }

  // Fetch classes filtered by a specific academic year
  getClassesByAcademicYear(academicYearId: number): Observable<DropdownItem[]> {
    return this.http.get<any>(`${this.academicUrl}/year/${academicYearId}`).pipe(
      map((response: any) => {
        const data = response?.data || response;
        if (Array.isArray(data)) {
          return data.map((cls: any) => ({
            id: cls.id || cls.Id,
            name: cls.name || cls.Name
          }));
        }
        return [];
      }),
      catchError(error => {
        console.error('Error fetching classes by academic year:', error);
        return of([]);
      })
    );
  }

  // Fetch sections cascading from a selected class ID
  getSectionsByClass(classId: number): Observable<DropdownItem[]> {
    return this.http.get<any>(`${this.academicUrl}/class/${classId}/sections`).pipe(
      map((response: any) => {
        const data = response?.data || response;
        if (Array.isArray(data)) {
          return data.map((sec: any) => ({
            id: sec.id || sec.Id,
            name: sec.name || sec.Name
          }));
        }
        return [];
      }),
      catchError(error => {
        console.error('Error fetching sections:', error);
        return of([]);
      })
    );
  }

  // Staff structure lookups (departments / positions).
  // Same DB-backed store as the Departments/Designations admin screens and the
  // Setup Wizard Staff tab, so every consumer always agrees.
  private toDropdownItems = (rows: any): DropdownItem[] =>
    Array.isArray(rows)
      ? rows.map((r: any) => ({ id: r?.value ?? r?.id, name: r?.label ?? r?.name ?? String(r) }))
      : [];

  getStaffDepartments(): Observable<DropdownItem[]> {
    return this.http.get<any>(`${this.lookupUrl}/staff-departments`).pipe(
      map(this.toDropdownItems),
      catchError(error => {
        console.error('Error fetching staff departments:', error);
        return of([]);
      })
    );
  }

  getStaffPositions(): Observable<DropdownItem[]> {
    return this.http.get<any>(`${this.lookupUrl}/staff-positions`).pipe(
      map(this.toDropdownItems),
      catchError(error => {
        console.error('Error fetching staff positions:', error);
        return of([]);
      })
    );
  }

  // Fetch Academic Years/Sessions
  getAcademicYears(): Observable<DropdownItem[]> {
    if (!this.academicYears$) {
      // Use setup API to ensure consistency during setup wizard
      const setupUrl = `${environment.apiUrl}/api/setup/academic-years`;
      this.academicYears$ = this.http.get<any>(setupUrl).pipe(
        map((response: any) => {
          const data = response?.data || response;
          if (Array.isArray(data)) {
            return data.map((year: any) => ({
              id: year.id || year.Id,
              name: year.name || `${year.startYear}-${year.endYear}`
            }));
          }
          return [];
        }),
        shareReplay(1),
        catchError(error => {
          console.error('Error fetching academic years:', error);
          return of([]);
        })
      );
    }
    return this.academicYears$;
  }
}