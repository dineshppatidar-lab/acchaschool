import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, BehaviorSubject } from 'rxjs';
import { map, tap, catchError } from 'rxjs/operators';
import { throwError } from 'rxjs';

/**
 * Generic CRUD Interface
 * Implement this interface for all DTOs/Models
 */
export interface ICrudEntity {
  id?: number;
  tenantId?: number;
}

/**
 * Pagination Metadata
 */
export interface PaginationMeta {
  pageNumber: number;
  pageSize: number;
  totalCount: number;
  totalPages: number;
  hasNextPage: boolean;
  hasPreviousPage: boolean;
}

/**
 * Paginated Response Format
 */
export interface PaginatedResponse<T> {
  data: T[];
  meta?: PaginationMeta;
  success: boolean;
  message?: string;
}

/**
 * Filter Options for List Queries
 */
export interface FilterOptions {
  searchTerm?: string;
  pageNumber?: number;
  pageSize?: number;
  sortBy?: string;
  sortDirection?: 'asc' | 'desc';
  [key: string]: any; // Allow custom filters
}

/**
 * Generic CRUD Service for All Entities
 * 
 * Usage:
 * 1. Extend this service in your specific entity service
 * 2. Override apiUrl in constructor: super(http, '/api/your-endpoint')
 * 3. Add entity-specific methods if needed
 * 
 * Example:
 * ```
 * @Injectable({ providedIn: 'root' })
 * export class ClassService extends BaseCrudService<Class> {
 *   constructor(http: HttpClient) {
 *     super(http, '/api/academic/classes');
 *   }
 * }
 * ```
 */
@Injectable()
export class BaseCrudService<T extends ICrudEntity> {
  protected apiUrl: string = '';
  
  // BehaviorSubjects for reactive state management
  protected entityList$ = new BehaviorSubject<T[]>([]);
  protected loading$ = new BehaviorSubject<boolean>(false);
  protected error$ = new BehaviorSubject<string | null>(null);
  protected currentEntity$ = new BehaviorSubject<T | null>(null);

  constructor(
    protected http: HttpClient
  ) {}

  /**
   * Set the API endpoint for this service
   */
  setApiEndpoint(endpoint: string): void {
    this.apiUrl = endpoint;
  }

  /**
   * Get all entities with optional pagination and filtering
   */
  getAll(
    filters?: FilterOptions,
    paginate: boolean = false
  ): Observable<T[] | PaginatedResponse<T>> {
    this.loading$.next(true);
    this.error$.next(null);

    let params = new HttpParams();
    
    if (filters) {
      if (filters.searchTerm) {
        params = params.set('search', filters.searchTerm);
      }
      if (filters.sortBy) {
        params = params.set('sortBy', filters.sortBy);
      }
      if (filters.sortDirection) {
        params = params.set('sortDirection', filters.sortDirection);
      }
      if (paginate && filters.pageNumber !== undefined) {
        params = params.set('pageNumber', filters.pageNumber.toString());
      }
      if (paginate && filters.pageSize !== undefined) {
        params = params.set('pageSize', filters.pageSize.toString());
      }
      
      // Add custom filters
      Object.keys(filters).forEach(key => {
        if (!['searchTerm', 'pageNumber', 'pageSize', 'sortBy', 'sortDirection'].includes(key)) {
          params = params.set(key, filters[key]);
        }
      });
    }

    return this.http.get<any>(this.apiUrl, { params }).pipe(
      map(response => this._normalizeResponse(response, paginate)),
      tap(data => {
        if (Array.isArray(data)) {
          this.entityList$.next(data);
        } else if ((data as PaginatedResponse<T>).data) {
          this.entityList$.next((data as PaginatedResponse<T>).data);
        }
        this.loading$.next(false);
      }),
      catchError(error => {
        const errorMessage = this._extractErrorMessage(error);
        this.error$.next(errorMessage);
        this.loading$.next(false);
        return throwError(() => error);
      })
    );
  }

  /**
   * Get single entity by ID
   */
  getById(id: number): Observable<T> {
    this.loading$.next(true);
    this.error$.next(null);

    return this.http.get<any>(`${this.apiUrl}/${id}`).pipe(
      map(response => this._normalizeEntity(response)),
      tap(entity => {
        this.currentEntity$.next(entity);
        this.loading$.next(false);
      }),
      catchError(error => {
        const errorMessage = this._extractErrorMessage(error);
        this.error$.next(errorMessage);
        this.loading$.next(false);
        return throwError(() => error);
      })
    );
  }

  /**
   * Create new entity
   */
  create(entity: Omit<T, 'id'>): Observable<T> {
    this.loading$.next(true);
    this.error$.next(null);

    return this.http.post<any>(this.apiUrl, entity).pipe(
      map(response => this._normalizeEntity(response)),
      tap(createdEntity => {
        const currentEntities = this.entityList$.value;
        this.entityList$.next([...currentEntities, createdEntity]);
        this.loading$.next(false);
      }),
      catchError(error => {
        const errorMessage = this._extractErrorMessage(error);
        this.error$.next(errorMessage);
        this.loading$.next(false);
        return throwError(() => error);
      })
    );
  }

  /**
   * Update existing entity
   */
  update(id: number, entity: Partial<T>): Observable<T> {
    this.loading$.next(true);
    this.error$.next(null);

    return this.http.put<any>(`${this.apiUrl}/${id}`, entity).pipe(
      map(response => this._normalizeEntity(response)),
      tap(updatedEntity => {
        const currentEntities = this.entityList$.value;
        const index = currentEntities.findIndex(e => e.id === id);
        if (index !== -1) {
          currentEntities[index] = updatedEntity;
          this.entityList$.next([...currentEntities]);
        }
        this.loading$.next(false);
      }),
      catchError(error => {
        const errorMessage = this._extractErrorMessage(error);
        this.error$.next(errorMessage);
        this.loading$.next(false);
        return throwError(() => error);
      })
    );
  }

  /**
   * Delete entity by ID
   */
  delete(id: number): Observable<void> {
    this.loading$.next(true);
    this.error$.next(null);

    return this.http.delete<void>(`${this.apiUrl}/${id}`).pipe(
      tap(() => {
        const currentEntities = this.entityList$.value;
        this.entityList$.next(currentEntities.filter(e => e.id !== id));
        this.loading$.next(false);
      }),
      catchError(error => {
        const errorMessage = this._extractErrorMessage(error);
        this.error$.next(errorMessage);
        this.loading$.next(false);
        return throwError(() => error);
      })
    );
  }

  /**
   * Batch delete entities
   */
  batchDelete(ids: number[]): Observable<void> {
    this.loading$.next(true);
    this.error$.next(null);

    return this.http.post<void>(`${this.apiUrl}/batch-delete`, { ids }).pipe(
      tap(() => {
        const currentEntities = this.entityList$.value;
        this.entityList$.next(
          currentEntities.filter(e => !ids.includes(e.id || 0))
        );
        this.loading$.next(false);
      }),
      catchError(error => {
        const errorMessage = this._extractErrorMessage(error);
        this.error$.next(errorMessage);
        this.loading$.next(false);
        return throwError(() => error);
      })
    );
  }

  /**
   * Search with custom criteria
   */
  search(searchTerm: string, filters?: FilterOptions): Observable<T[]> {
    return this.getAll({ ...filters, searchTerm }, false).pipe(
      map(response => Array.isArray(response) ? response : response.data)
    );
  }

  /**
   * Get entity list as Observable
   */
  getEntityList$(): Observable<T[]> {
    return this.entityList$.asObservable();
  }

  /**
   * Get loading state as Observable
   */
  getLoading$(): Observable<boolean> {
    return this.loading$.asObservable();
  }

  /**
   * Get error state as Observable
   */
  getError$(): Observable<string | null> {
    return this.error$.asObservable();
  }

  /**
   * Get current entity as Observable
   */
  getCurrentEntity$(): Observable<T | null> {
    return this.currentEntity$.asObservable();
  }

  /**
   * Clear error message
   */
  clearError(): void {
    this.error$.next(null);
  }

  /**
   * Refresh data from server
   */
  refresh(filters?: FilterOptions): Observable<T[] | PaginatedResponse<T>> {
    return this.getAll(filters);
  }

  /**
   * Normalize API response - handle multiple response formats
   * APIs might return: data[], {data: []}, {items: []}, {success: true, data: []}
   */
  protected _normalizeResponse(
    response: any,
    pagination: boolean
  ): T[] | PaginatedResponse<T> {
    // If response is already an array
    if (Array.isArray(response)) {
      return response as T[];
    }

    // If response has data array (paginated or not)
    if (response?.data && Array.isArray(response.data)) {
      if (pagination && response?.meta) {
        return {
          data: response.data,
          meta: response.meta,
          success: response.success !== false,
          message: response.message
        };
      }
      return response.data;
    }

    // If response has items array
    if (response?.items && Array.isArray(response.items)) {
      return response.items;
    }

    // Fallback: return empty array
    return [];
  }

  /**
   * Normalize single entity from API response
   * Handle both {data: entity} and direct entity response
   */
  protected _normalizeEntity(response: any): T {
    if (response?.data && typeof response.data === 'object' && !Array.isArray(response.data)) {
      return response.data as T;
    }
    return response as T;
  }

  /**
   * Extract user-friendly error message from HTTP error
   */
  protected _extractErrorMessage(error: any): string {
    // Handle custom error format
    if (error?.error?.message) {
      return error.error.message;
    }

    // Handle validation errors
    if (error?.error?.errors) {
      return Object.values(error.error.errors).flat().join(', ');
    }

    // Handle standard error format
    if (error?.message) {
      return error.message;
    }

    // Handle HTTP error status
    if (error?.status) {
      const statusMessages: { [key: number]: string } = {
        400: 'Invalid request. Please check your input.',
        401: 'Unauthorized. Please log in again.',
        403: 'You do not have permission to perform this action.',
        404: 'Resource not found.',
        409: 'This resource already exists.',
        500: 'Server error. Please try again later.',
      };
      return statusMessages[error.status] || `Error (${error.status}): ${error.statusText}`;
    }

    return 'An unknown error occurred. Please try again.';
  }
}
