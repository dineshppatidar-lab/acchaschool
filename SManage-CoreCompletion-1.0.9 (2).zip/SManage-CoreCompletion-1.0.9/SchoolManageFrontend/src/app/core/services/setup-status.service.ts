import { Injectable, computed, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError, map, shareReplay, tap } from 'rxjs/operators';
import { PermissionService } from './permission.service';
import { Permission } from '../models/permission.model';

/** One configurable setup requirement (mirrors backend SetupStatusItem). */
export interface SetupStatusItem {
  key: string;
  name: string;
  description: string;
  isRequired: boolean;
  isCompleted: boolean;
  displayOrder: number;
  category: string;
  route: string;
}

/** Aggregated setup status (mirrors backend SetupStatusSummary). */
export interface SetupStatusSummary {
  isComplete: boolean;
  completedCount: number;
  requiredCount: number;
  completionPercentage: number;
  items: SetupStatusItem[];
}

/**
 * Central setup-status store for the onboarding experience.
 *
 * - Loads GET /api/setup/status once per session (login/refresh) — NOT on every
 *   navigation — and caches it in signals.
 * - `refresh()` re-fetches after the wizard completes a step or config changes.
 * - `canViewSetupStatus` gates the UI to users who can actually configure the
 *   school (SystemSettings readers); teachers/students/parents see nothing.
 */
@Injectable({ providedIn: 'root' })
export class SetupStatusService {
  private readonly http = inject(HttpClient);
  private readonly permissions = inject(PermissionService);

  private readonly statusSignal = signal<SetupStatusSummary | null>(null);
  private readonly loadedSignal = signal(false);

  /** In-flight request, shared so concurrent callers trigger one HTTP call. */
  private inFlight$: Observable<SetupStatusSummary | null> | null = null;

  /** Raw status summary (null until first load completes). */
  readonly status = this.statusSignal.asReadonly();

  /** True once the status has been fetched at least this session. */
  readonly loaded = this.loadedSignal.asReadonly();

  /** Required steps that are still incomplete (drives banner + checklist). */
  readonly incompleteRequired = computed<SetupStatusItem[]>(() => {
    const s = this.statusSignal();
    if (!s) return [];
    return s.items.filter(i => i.isRequired && !i.isCompleted);
  });

  /** Number of incomplete REQUIRED steps (drives the sidebar badge). */
  readonly incompleteRequiredCount = computed(() => this.incompleteRequired().length);

  /** Whether the persistent banner/card should be visible. */
  readonly showSetupUi = computed(() => {
    const s = this.statusSignal();
    return !!s && !s.isComplete;
  });

  /** Only users allowed to configure the school see setup status UI. */
  readonly canViewSetupStatus = computed(() =>
    this.permissions.canRead(Permission.SystemSettings)
  );

  /**
   * Load the status once per session. Safe to call from multiple components —
   * only the first call hits the API (per in-flight window); the rest get the
   * cached signal immediately.
   */
  load(): void {
    if (!this.canViewSetupStatus()) return; // no API call for non-admin users
    if (this.loadedSignal() || this.inFlight$) return;
    this.fetch().subscribe();
  }

  /** Force a re-fetch (after a wizard step completes, config changes, tenant switch). */
  refresh(): void {
    if (!this.canViewSetupStatus()) return;
    this.loadedSignal.set(false);
    this.fetch().subscribe();
  }

  private fetch(): Observable<SetupStatusSummary | null> {
    if (!this.inFlight$) {
      this.inFlight$ = this.http.get<any>('/api/setup/status').pipe(
        // Be tolerant of the ApiResponse envelope — the global interceptor
        // usually unwraps it, but don't depend on that here.
        map(resp => (resp && typeof resp === 'object' && 'items' in resp
          ? (resp as SetupStatusSummary)
          : ((resp?.data ?? resp) as SetupStatusSummary))),
        tap(summary => {
          this.statusSignal.set(summary ?? null);
          this.loadedSignal.set(true);
          this.inFlight$ = null;
        }),
        catchError(err => {
          // Silent failure: the banner is onboarding sugar, never an error toast.
          console.warn('[SetupStatus] Failed to load setup status', err);
          this.loadedSignal.set(true);
          this.inFlight$ = null;
          return of(null);
        }),
        shareReplay({ bufferSize: 1, refCount: false })
      );
    }
    return this.inFlight$;
  }
}
