import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { map, catchError, tap } from 'rxjs/operators';
import { Permission, PermissionLevel, UserPermissions, UserRole } from '../models/permission.model';
import { AuthService } from '../../services/auth.service';

@Injectable({
  providedIn: 'root'
})
export class PermissionService {
  private readonly baseUrl = '/api/permissions';
  private userPermissionsSubject = new BehaviorSubject<UserPermissions>({});
  private userRoleSubject = new BehaviorSubject<UserRole | null>(null);
  private permissionsLoadedSubject = new BehaviorSubject<boolean>(false);
  
  public userPermissions$ = this.userPermissionsSubject.asObservable();
  public userRole$ = this.userRoleSubject.asObservable();
  public permissionsLoaded$ = this.permissionsLoadedSubject.asObservable();

  constructor(
    private http: HttpClient,
    private authService: AuthService
  ) {
    this.permissionsLoadedSubject.next(false);
    this.initializePermissions();
  }

  private initializePermissions(): void {
    // Try immediate bootstrap from AuthService
    const current = this.authService.getCurrentUser() as any;
    if (current) {
      this.bootstrapFromUser(current);
    } else {
      // Fallback to localStorage when core AuthService hasn't been populated yet
      try {
        const raw = localStorage.getItem('currentUser') ?? localStorage.getItem('user');
        if (raw) {
          const parsed = JSON.parse(raw);
          this.bootstrapFromUser(parsed);
        }
      } catch (e) {
        console.warn('PermissionService: failed to bootstrap from localStorage', e);
      }
    }

    // Keep permissions in sync if user object changes (especially after login)
    this.authService.currentUser$.subscribe((user: any) => {
      if (user) {
        this.bootstrapFromUser(user);
      } else {
        this.userPermissionsSubject.next({});
        this.userRoleSubject.next(null);
        this.permissionsLoadedSubject.next(false);
      }
    });
  }

  private bootstrapFromUser(user: any): void {
    const role = user?.role ?? user?.roles ?? null;
    if (user?.id) {
      // Seed UI rendering (menus etc.) from the login-response snapshot if available,
      // but do NOT mark permissionsLoaded here: the snapshot is provisional and can be
      // stale (e.g. permissions granted after this session logged in). The authoritative
      // /api/permissions/user/{id} load below settles permissionsLoaded, and on server
      // error the snapshot already in the subject remains as fallback. Only seed when
      // the subject is empty so a fresh server load is never overwritten by a stale snapshot.
      if (user.permissions && Array.isArray(user.permissions) && Object.keys(this.userPermissionsSubject.value ?? {}).length === 0) {
        const normalized = this.normalizePermissions(user.permissions);
        this.userPermissionsSubject.next(normalized);
      }

      this.loadUserPermissions(user.id).subscribe();
    }
    if (role !== null && role !== undefined) {
      let normalized: UserRole | null = null;
      if (typeof role === 'number') {
        normalized = role as UserRole;
      } else if (typeof role === 'string') {
        const trimmed = role.trim();
        // Try numeric string first
        if (!isNaN(Number(trimmed))) {
          normalized = Number(trimmed) as UserRole;
        } else {
          // Case-insensitive lookup against UserRole enum keys
          const enumKey = Object.keys(UserRole).find(
            k => k.toLowerCase() === trimmed.toLowerCase()
          );
          if (enumKey) {
            normalized = UserRole[enumKey as keyof typeof UserRole];
          }
        }
      }
      this.userRoleSubject.next(normalized);
    }
  }

  private loadUserPermissions(userId: number): Observable<UserPermissions> {
    return this.http.get<UserPermissions>(`${this.baseUrl}/user/${userId}`)
      .pipe(
        map(permissions => this.normalizePermissions(permissions)),
        tap(permissions => {
          this.userPermissionsSubject.next(permissions);
          this.permissionsLoadedSubject.next(true);
        }),
        catchError(error => {
          console.error('Failed to load user permissions:', error);
          this.permissionsLoadedSubject.next(true);
          return of({});
        })
      );
  }

  private normalizePermissions(raw: any): UserPermissions {
    const normalized: UserPermissions = {};

    if (!raw) return normalized;

    // If backend sends an array of permissions (e.g. from login response)
    if (Array.isArray(raw)) {
      for (const item of raw) {
        const key = this.normalizePermissionKey(item);
        if (key !== null) {
          normalized[key] = { canRead: true, canWrite: true, canDelete: true };
        }
      }
      return normalized;
    }

    // If backend sends an object/map
    Object.entries(raw).forEach(([key, value]) => {
      const permKey = this.normalizePermissionKey(key);
      if (permKey === null) return;

      // If value already contains canRead/canWrite/canDelete, use it.
      if (value && typeof value === 'object') {
        const v = value as any;
        const canRead = !!v.canRead;
        const canWrite = !!v.canWrite;
        const canDelete = !!v.canDelete;
        normalized[permKey] = { canRead, canWrite, canDelete };
      } else {
        // Fallback: treat as granted
        normalized[permKey] = { canRead: true, canWrite: true, canDelete: true };
      }
    });

    return normalized;
  }

  public normalizePermissionKey(key: any): number | null {
    if (key === null || key === undefined) return null;
    // Numeric keys are ok
    if (typeof key === 'number') return key;

    // String keys that contain numbers
    if (typeof key === 'string') {
      const trimmed = key.trim();
      const numeric = Number(trimmed);
      if (!isNaN(numeric)) {
        return numeric;
      }

      // Try mapping from Permission enum name -> numeric value
      if (trimmed in Permission) {
        return Permission[trimmed as keyof typeof Permission] as unknown as number;
      }
    }

    return null;
  }

  // Permission checking methods
  hasPermission(permission: Permission): boolean {
    // SuperAdmin bypass: has all permissions
    if (this.isSuperAdmin()) {
      return true;
    }
    const permissions = this.userPermissionsSubject.value;
    const permissionLevel = permissions[permission];
    return permissionLevel?.canRead || permissionLevel?.canWrite || permissionLevel?.canDelete || false;
  }

  canRead(permission: Permission): boolean {
    if (this.isSuperAdmin()) return true;
    const permissions = this.userPermissionsSubject.value;
    return permissions[permission]?.canRead || false;
  }

  canWrite(permission: Permission): boolean {
    if (this.isSuperAdmin()) return true;
    const permissions = this.userPermissionsSubject.value;
    return permissions[permission]?.canWrite || false;
  }

  canDelete(permission: Permission): boolean {
    if (this.isSuperAdmin()) return true;
    const permissions = this.userPermissionsSubject.value;
    return permissions[permission]?.canDelete || false;
  }

  private isSuperAdmin(): boolean {
    return this.userRoleSubject.value === UserRole.SuperAdmin;
  }

  hasRole(role: UserRole): boolean {
    return this.userRoleSubject.value === role;
  }

  hasAnyRole(roles: UserRole[]): boolean {
    const currentRole = this.userRoleSubject.value;
    return currentRole !== null && roles.includes(currentRole);
  }

  getCurrentRole(): UserRole | null {
    return this.userRoleSubject.value;
  }

  // Async versions for reactive programming
  hasPermission$(permission: Permission): Observable<boolean> {
    return this.userPermissions$.pipe(
      map(permissions => {
        if (this.userRoleSubject.value === UserRole.SuperAdmin) return true;
        const permissionLevel = permissions[permission];
        return permissionLevel?.canRead || permissionLevel?.canWrite || permissionLevel?.canDelete || false;
      })
    );
  }

  canRead$(permission: Permission): Observable<boolean> {
    return this.userPermissions$.pipe(
      map(permissions => {
        if (this.userRoleSubject.value === UserRole.SuperAdmin) return true;
        return permissions[permission]?.canRead || false;
      })
    );
  }

  canWrite$(permission: Permission): Observable<boolean> {
    return this.userPermissions$.pipe(
      map(permissions => {
        if (this.userRoleSubject.value === UserRole.SuperAdmin) return true;
        return permissions[permission]?.canWrite || false;
      })
    );
  }

  canDelete$(permission: Permission): Observable<boolean> {
    return this.userPermissions$.pipe(
      map(permissions => {
        if (this.userRoleSubject.value === UserRole.SuperAdmin) return true;
        return permissions[permission]?.canDelete || false;
      })
    );
  }

  hasRole$(role: UserRole): Observable<boolean> {
    return this.userRole$.pipe(
      map(currentRole => currentRole === role)
    );
  }

  hasAnyRole$(roles: UserRole[]): Observable<boolean> {
    return this.userRole$.pipe(
      map(currentRole => currentRole !== null && roles.includes(currentRole))
    );
  }

  // Admin methods for managing permissions
  getRolePermissions(role: UserRole): Observable<any[]> {
    return this.http.get<any[]>(`${this.baseUrl}/roles/${role}`);
  }

  updateRolePermission(role: UserRole, permission: Permission, canRead: boolean, canWrite: boolean, canDelete: boolean): Observable<boolean> {
    return this.http.post<boolean>(`${this.baseUrl}/roles/${role}/${permission}`, {
      canRead,
      canWrite,
      canDelete
    });
  }

  bulkUpdateRolePermissions(role: UserRole, permissions: any[]): Observable<boolean> {
    return this.http.post<boolean>(`${this.baseUrl}/roles/${role}/bulk`, permissions);
  }

  resetRoleModule(role: UserRole, permissions: Permission[]): Observable<boolean> {
    return this.http.post<boolean>(`${this.baseUrl}/roles/${role}/reset-module`, { permissions });
  }

  grantUserPermission(userId: number, permission: Permission, canRead: boolean, canWrite: boolean, canDelete: boolean): Observable<boolean> {
    return this.http.post<boolean>(`${this.baseUrl}/users/${userId}/grant`, {
      permission,
      canRead,
      canWrite,
      canDelete
    });
  }

  revokeUserPermission(userId: number, permission: Permission): Observable<boolean> {
    return this.http.post<boolean>(`${this.baseUrl}/users/${userId}/revoke`, {
      permission
    });
  }

  ping(): Observable<any> {
    return this.http.post(`${this.baseUrl}/ping`, {});
  }

  // Utility methods
  getPermissionsByModule(): { [module: string]: Permission[] } {
    return {
      'User Management': [
        Permission.UsersView,
        Permission.UsersCreate,
        Permission.UsersEdit,
        Permission.UsersDelete,
        Permission.UsersManageRoles
      ],
      'Student Management': [
        Permission.StudentsView,
        Permission.StudentsCreate,
        Permission.StudentsEdit,
        Permission.StudentsDelete,
        Permission.StudentsViewDetails,
        Permission.StudentsManageAdmissions
      ],
      'Staff Management': [
        Permission.StaffView,
        Permission.StaffCreate,
        Permission.StaffEdit,
        Permission.StaffDelete,
        Permission.StaffManagePayroll
      ],
      'Academic Management': [
        Permission.ClassesView,
        Permission.ClassesCreate,
        Permission.ClassesEdit,
        Permission.ClassesDelete,
        Permission.SubjectsView,
        Permission.SubjectsManage,
        Permission.TimetablesView,
        Permission.TimetablesManage
      ],
      'Examination Management': [
        Permission.ExaminationsView,
        Permission.ExaminationsCreate,
        Permission.ExaminationsEdit,
        Permission.ExaminationsDelete,
        Permission.ResultsView,
        Permission.ResultsEnter,
        Permission.ResultsPublish
      ],
      'Finance Management': [
        Permission.FeesView,
        Permission.FeesCollect,
        Permission.FeesManageStructure,
        Permission.FeesReports,
        Permission.PaymentsView,
        Permission.PaymentsProcess
      ],
      'Library Management': [
        Permission.LibraryView,
        Permission.LibraryIssueBooks,
        Permission.LibraryReturnBooks,
        Permission.LibraryManageInventory
      ],
      'Communication': [
        Permission.MessagesView,
        Permission.MessagesSend,
        Permission.AnnouncementsSend,
        Permission.EventsManage
      ],
      'Reports & Analytics': [
        Permission.ReportsView,
        Permission.ReportsGenerate,
        Permission.AnalyticsView,
        Permission.DashboardView
      ],
      'System Administration': [
        Permission.SystemSettings,
        Permission.SystemBackupRestore,
        Permission.SystemAuditLogs,
        Permission.SystemManage
      ]
    };
  }

  refreshPermissions(): Observable<UserPermissions> {
  const currentUser = this.authService.getCurrentUser();
    if (currentUser) {
      return this.loadUserPermissions(currentUser.id);
    }
    return of({});
  }

  getUserPermissionOverrides(userId: string): Observable<any[]> {
    return this.http.get<any[]>(`${this.baseUrl}/users/${userId}/overrides`);
  }

  // ── Unified Role Summary (single source of truth for admin UI) ──

  /**
   * Get the unified role summary: all permissions AND derived menu visibility.
   * This is the single source of truth for the Permissions admin page.
   */
  getRoleSummary(role: UserRole): Observable<RoleSummary> {
    return this.http.get<RoleSummary>(`${this.baseUrl}/role-summary/${role}`);
  }

  /**
   * Check if a specific menu item would be visible for the given role,
   * based on the role's permissions (auto-derived from CanRead).
   */
  isMenuVisibleForRole(rolePermissions: { [key: number]: PermissionLevel }, requiredPermission: string): boolean {
    if (!requiredPermission) return true;
    const permKey = this.normalizePermissionKey(requiredPermission);
    if (permKey === null) return true;
    const level = rolePermissions[permKey];
    return level?.canRead || false;
  }
}

// ── Response DTOs for role summary ──

export interface RoleSummary {
  role: UserRole;
  roleName: string;
  rolePermissions: RolePermissionDto[];
  menuVisibility: MenuVisibilityDto[];
  modulePermissions: ModulePermissionSummaryDto[];
  totalPermissions: number;
  visibleMenuItems: number;
  totalMenuItems: number;
}

export interface RolePermissionDto {
  permission: Permission;
  permissionName: string;
  canRead: boolean;
  canWrite: boolean;
  canDelete: boolean;
}

export interface MenuVisibilityDto {
  menuItemId: number;
  label: string;
  route: string;
  icon: string;
  parentId: number | null;
  category: string;
  displayOrder: number;
  requiredPermission: string;
  isVisible: boolean;
  hasExplicitOverride: boolean;
  permissionAllows: boolean;
}

export interface ModulePermissionSummaryDto {
  moduleName: string;
  icon: string;
  category: string;
  permissions: RolePermissionDto[];
  menuVisible: boolean;
  hasAnyWrite: boolean;
  hasAnyDelete: boolean;
}