import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { UserRole } from '../models/permission.model';
import { DynamicPermissionService } from './dynamic-permission.service';

export interface CurrentUser {
  id: number;
  username: string;
  email: string;
  firstName?: string;
  lastName?: string;
  role?: UserRole;
  roles?: string; // Backend may return comma-separated roles
  isActive?: boolean;
  tenantId?: number;
  permissions?: string[]; // ✅ NEW: Array of permission strings from backend
}

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private currentUserSubject = new BehaviorSubject<CurrentUser | null>(null);
  public currentUser$ = this.currentUserSubject.asObservable();

  constructor(private permissionService: DynamicPermissionService) {
    this.loadCurrentUser();
  }

  private loadCurrentUser(): void {
    // Load current user from localStorage (supports both new 'currentUser' and legacy 'user' keys)
    const raw = localStorage.getItem('currentUser') ?? localStorage.getItem('user');
    if (!raw) {
      return;
    }
    try {
      const parsed = JSON.parse(raw);
      const normalized = this.normalizeUser(parsed);
      this.currentUserSubject.next(normalized);
      // Ensure the normalized user is stored under 'currentUser' for consistency
      localStorage.setItem('currentUser', JSON.stringify(normalized));
      // ✅ NEW: Initialize permissions if available
      if (normalized.permissions && normalized.permissions.length > 0) {
        this.permissionService.setUserPermissions(normalized.permissions);
      }
    } catch (error) {
      console.error('Error parsing stored user:', error);
      localStorage.removeItem('currentUser');
    }
  }

  private normalizeUser(user: any): CurrentUser {
    // Attempt to coerce various shapes into CurrentUser
    const roleValue = this.normalizeRole(user?.role ?? user?.roles);
    return {
      id: user?.id ?? user?.userId ?? 0,
      username: user?.username ?? user?.userName ?? user?.email ?? 'user',
      email: user?.email ?? '',
      firstName: user?.firstName ?? user?.givenName ?? '',
      lastName: user?.lastName ?? user?.surname ?? '',
      role: roleValue,
      roles: user?.roles,
      isActive: user?.isActive ?? true,
      tenantId: user?.tenantId,
      permissions: user?.permissions // ✅ NEW: Include permissions from login response
    } as CurrentUser;
  }

  private normalizeRole(input: any): UserRole | null {
    if (input === null || input === undefined) return null;
    // If it's already a number in the enum range
    if (typeof input === 'number') {
      return (Object.values(UserRole) as number[]).includes(input) ? input as UserRole : null;
    }
    // If it's a numeric string
    const asNumber = Number(input);
    if (!isNaN(asNumber)) {
      return (Object.values(UserRole) as number[]).includes(asNumber) ? asNumber as UserRole : null;
    }
    // If it's a role name string like 'SuperAdmin'
    if (typeof input === 'string' && (input in UserRole)) {
      return UserRole[input as keyof typeof UserRole];
    }
    return null;
  }

  getCurrentUser(): CurrentUser | null {
    return this.currentUserSubject.value;
  }

  setCurrentUser(user: CurrentUser): void {
    this.currentUserSubject.next(user);
    localStorage.setItem('currentUser', JSON.stringify(user));
    // ✅ NEW: Initialize permissions if available from login
    if (user.permissions && user.permissions.length > 0) {
      this.permissionService.setUserPermissions(user.permissions);
    }
  }

  logout(): void {
    this.currentUserSubject.next(null);
    localStorage.removeItem('currentUser');
    // ✅ NEW: Clear permissions cache on logout
    this.permissionService.clearCache();
  }

  isAuthenticated(): boolean {
    return this.currentUserSubject.value !== null;
  }

  hasRole(role: UserRole): boolean {
    const currentUser = this.currentUserSubject.value;
    return currentUser?.role === role;
  }

  hasAnyRole(roles: UserRole[]): boolean {
    const currentUser = this.currentUserSubject.value;
    return currentUser && currentUser.role ? roles.includes(currentUser.role) : false;
  }
}