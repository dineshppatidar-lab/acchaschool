import {
  Component,
  OnInit,
  OnDestroy,
  ChangeDetectionStrategy,
  Input,
  Output,
  EventEmitter,
  inject,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  ReactiveFormsModule,
  FormBuilder,
  FormGroup,
  Validators,
  AbstractControl,
  ValidationErrors,
} from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatIconModule } from '@angular/material/icon';
import { MatCardModule } from '@angular/material/card';
import { MatDividerModule } from '@angular/material/divider';
import { MatTooltipModule } from '@angular/material/tooltip';
import { ActivatedRoute, Router } from '@angular/router';

import { BaseCrudService, ICrudEntity } from '../services/base-crud.service';
import { PageHeaderComponent } from '../../shared/components/page-patterns/index';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

/**
 * Form field configuration for dynamic form generation
 */
export interface FormFieldConfig {
  name: string;
  label: string;
  type: 'text' | 'email' | 'number' | 'date' | 'select' | 'checkbox' | 'textarea';
  placeholder?: string;
  required?: boolean;
  pattern?: string;
  minLength?: number;
  maxLength?: number;
  min?: number;
  max?: number;
  options?: Array<{ id: any; name: string }>;
  disabled?: boolean;
  grid?: 'full' | 'half' | 'third';
  readonly?: boolean;
}

/**
 * Abstract Base Form Component
 * 
 * Extend this component for all form views. Implement:
 * - getService(): BaseCrudService<T>
 * - getFormConfig(): FormFieldConfig[]
 * - getFormTitle(): string
 * 
 * Features:
 * - Automatic form generation from config
 * - Validation with error messages
 * - Create and Update modes
 * - Auto-populate on edit
 * - Submission handling
 * - Responsive design
 * 
 * Usage:
 * ```
 * @Component({
 *   selector: 'app-class-form',
 *   templateUrl: './base-form.component.html',
 *   styleUrls: ['./base-form.component.scss']
 * })
 * export class ClassFormComponent extends BaseFormComponent<Class> {
 *   constructor(
 *     private classService: ClassService,
 *     snackBar: MatSnackBar,
 *     router: Router,
 *     route: ActivatedRoute,
 *     fb: FormBuilder
 *   ) {
 *     super(snackBar, router, route, fb);
 *   }
 *
 *   getService(): BaseCrudService<Class> {
 *     return this.classService;
 *   }
 *
 *   getFormTitle(): string {
 *     return this.isCreateMode ? 'Add New Class' : 'Edit Class';
 *   }
 *
 *   getFormConfig(): FormFieldConfig[] {
 *     return [
 *       { name: 'name', label: 'Class Name', type: 'text', required: true, grid: 'full' },
 *       { name: 'abbreviation', label: 'Abbreviation', type: 'text', maxLength: 5, grid: 'half' },
 *       { name: 'isActive', label: 'Is Active', type: 'checkbox', grid: 'half' },
 *     ];
 *   }
 *
 *   buildForm(): void {
 *     // Optional: Custom form building logic
 *     super.buildForm();
 *   }
 * }
 * ```
 */
@Component({
  selector: 'app-base-form',
  templateUrl: './base-form.component.html',
  styleUrls: ['./base-form.component.scss'],
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatSelectModule,
    MatCheckboxModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatProgressSpinnerModule,
    MatProgressBarModule,
    MatIconModule,
    MatCardModule,
    MatDividerModule,
    MatTooltipModule,
    MatSnackBarModule,
    PageHeaderComponent,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export abstract class BaseFormComponent<T extends ICrudEntity>
  implements OnInit, OnDestroy {
  
  // Form
  form!: FormGroup;
  formConfig: FormFieldConfig[] = [];
  
  // State
  isCreateMode = true;
  isLoading = false;
  isSubmitting = false;
  entityId: number | null = null;
  
  // Lifecycle
  private destroy$ = new Subject<void>();
  
  // Injections
  protected snackBar = inject(MatSnackBar);
  protected router = inject(Router);
  protected route = inject(ActivatedRoute);
  protected fb = inject(FormBuilder);

  ngOnInit(): void {
    this.formConfig = this.getFormConfig();
    this.buildForm();
    this.checkEditMode();
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  /**
   * Override to provide the service
   */
  abstract getService(): BaseCrudService<T>;

  /**
   * Override to provide form field configuration
   */
  abstract getFormConfig(): FormFieldConfig[];

  /**
   * Override to provide form title
   */
  abstract getFormTitle(): string;

  /**
   * Override to handle custom form building
   */
  buildForm(): void {
    const formControls: { [key: string]: any } = {};

    this.formConfig.forEach((field) => {
      const validators = [];

      if (field.required) {
        validators.push(Validators.required);
      }
      if (field.minLength) {
        validators.push(Validators.minLength(field.minLength));
      }
      if (field.maxLength) {
        validators.push(Validators.maxLength(field.maxLength));
      }
      if (field.pattern) {
        validators.push(Validators.pattern(field.pattern));
      }
      if (field.min !== undefined) {
        validators.push(Validators.min(field.min));
      }
      if (field.max !== undefined) {
        validators.push(Validators.max(field.max));
      }
      if (field.type === 'email') {
        validators.push(Validators.email);
      }

      formControls[field.name] = [
        { value: '', disabled: field.disabled || false },
        validators,
      ];
    });

    this.form = this.fb.group(formControls);
  }

  /**
   * Check if form is in edit mode by reading route params
   */
  private checkEditMode(): void {
    this.route.params.pipe(takeUntil(this.destroy$)).subscribe((params) => {
      if (params['id']) {
        this.entityId = +params['id'];
        this.isCreateMode = false;
        this.loadEntity();
      } else {
        this.isCreateMode = true;
      }
    });
  }

  /**
   * Load entity data for edit mode
   */
  private loadEntity(): void {
    if (!this.entityId) return;

    this.isLoading = true;
    this.getService()
      .getById(this.entityId)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (entity) => {
          this.populateForm(entity);
          this.isLoading = false;
        },
        error: (err) => {
          this.showMessage('Error loading entity', 'error');
          console.error('Load entity error:', err);
          this.isLoading = false;
        },
      });
  }

  /**
   * Populate form with entity data
   */
  protected populateForm(entity: T): void {
    Object.keys(entity).forEach((key) => {
      const control = this.form.get(key);
      if (control) {
        control.setValue(entity[key as keyof T]);
      }
    });
  }

  /**
   * Submit form
   */
  onSubmit(): void {
    if (this.form.invalid) {
      this.showMessage('Please fix all validation errors', 'error');
      return;
    }

    this.isSubmitting = true;
    const formData = this.form.getRawValue();

    if (this.isCreateMode) {
      this.getService()
        .create(formData)
        .pipe(takeUntil(this.destroy$))
        .subscribe({
          next: () => {
            this.showMessage('Created successfully', 'success');
            this.router.navigate(['../'], { relativeTo: this.route });
          },
          error: (err) => {
            this.showMessage('Error creating entity', 'error');
            console.error('Create error:', err);
            this.isSubmitting = false;
          },
        });
    } else {
      if (!this.entityId) return;

      this.getService()
        .update(this.entityId, formData)
        .pipe(takeUntil(this.destroy$))
        .subscribe({
          next: () => {
            this.showMessage('Updated successfully', 'success');
            this.router.navigate(['../'], { relativeTo: this.route });
          },
          error: (err) => {
            this.showMessage('Error updating entity', 'error');
            console.error('Update error:', err);
            this.isSubmitting = false;
          },
        });
    }
  }

  /**
   * Reset form to initial state
   */
  onReset(): void {
    this.form.reset();
  }

  /**
   * Navigate back to list
   */
  onCancel(): void {
    this.router.navigate(['../'], { relativeTo: this.route });
  }

  /**
   * Get form field config by name
   */
  getFieldConfig(fieldName: string): FormFieldConfig | undefined {
    return this.formConfig.find((f) => f.name === fieldName);
  }

  /**
   * Get form field control
   */
  getControl(fieldName: string): AbstractControl | null {
    return this.form.get(fieldName);
  }

  /**
   * Check if field has error
   */
  hasError(fieldName: string, errorType: string): boolean {
    const control = this.getControl(fieldName);
    return !!(control && control.hasError(errorType) && (control.dirty || control.touched));
  }

  /**
   * Get field error message
   */
  getErrorMessage(fieldName: string): string {
    const control = this.getControl(fieldName);
    if (!control) return '';

    const config = this.getFieldConfig(fieldName);
    const errorType = Object.keys(control.errors || {})[0];

    const errorMessages: { [key: string]: string } = {
      required: `${config?.label} is required`,
      minlength: `${config?.label} must be at least ${control.getError('minlength')?.requiredLength} characters`,
      maxlength: `${config?.label} cannot exceed ${control.getError('maxlength')?.requiredLength} characters`,
      min: `${config?.label} must be at least ${control.getError('min')?.min}`,
      max: `${config?.label} cannot exceed ${control.getError('max')?.max}`,
      email: 'Invalid email address',
      pattern: `${config?.label} format is invalid`,
    };

    return errorMessages[errorType || ''] || 'Invalid input';
  }

  /**
   * Group form fields by grid layout
   */
  getFieldsByGrid(grid: 'full' | 'half' | 'third'): FormFieldConfig[] {
    return this.formConfig.filter((f) => (f.grid || 'full') === grid);
  }

  /**
   * Show snackbar message
   */
  protected showMessage(
    message: string,
    type: 'success' | 'error' | 'warning' = 'success'
  ): void {
    const panelClass = {
      success: 'snackbar-success',
      error: 'snackbar-error',
      warning: 'snackbar-warning',
    };
    this.snackBar.open(message, 'Close', {
      duration: 3000,
      horizontalPosition: 'end',
      verticalPosition: 'bottom',
      panelClass: [panelClass[type]],
    });
  }
}
