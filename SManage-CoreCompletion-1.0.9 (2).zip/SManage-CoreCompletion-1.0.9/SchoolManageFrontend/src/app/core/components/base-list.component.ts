import {
  Component,
  ViewChild,
  OnInit,
  OnDestroy,
  ChangeDetectionStrategy,
  Input,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormControl } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatTableModule, MatTableDataSource } from '@angular/material/table';
import { MatIconModule } from '@angular/material/icon';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatPaginatorModule, PageEvent } from '@angular/material/paginator';
import { MatSortModule, Sort } from '@angular/material/sort';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatMenuModule } from '@angular/material/menu';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatCardModule } from '@angular/material/card';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';

import { BaseCrudService, ICrudEntity, PaginationMeta, FilterOptions } from '../services/base-crud.service';
import { Subject } from 'rxjs';
import { takeUntil, debounceTime, distinctUntilChanged } from 'rxjs/operators';

/**
 * Configuration for Base List Component
 */
export interface BaseListConfig {
  displayColumns: string[];
  filterFields?: string[];
  pageSize?: number;
  sortBy?: string;
  sortDirection?: 'asc' | 'desc';
  enableSearch?: boolean;
  enableSelection?: boolean;
  enablePagination?: boolean;
}

/**
 * Abstract Base List Component
 * 
 * Extend this component for all list views. Implement:
 * - getService(): BaseCrudService<T>
 * - getConfig(): BaseListConfig
 * 
 * Features:
 * - Reusable table with pagination, sorting, filtering
 * - Selection checkboxes
 * - Bulk delete
 * - Search functionality
 * - Responsive design
 * 
 * Usage:
 * ```
 * @Component({
 *   selector: 'app-class-list',
 *   templateUrl: './base-list.component.html',
 *   styleUrls: ['./base-list.component.scss']
 * })
 * export class ClassListComponent extends BaseListComponent<Class> {
 *   constructor(
 *     private classService: ClassService,
 *     snackBar: MatSnackBar,
 *     dialog: MatDialog,
 *     router: Router
 *   ) {
 *     super(snackBar, dialog, router);
 *   }
 *
 *   getService(): BaseCrudService<Class> {
 *     return this.classService;
 *   }
 *
 *   getConfig(): BaseListConfig {
 *     return {
 *       displayColumns: ['select', 'name', 'sections', 'isActive', 'actions'],
 *       filterFields: ['name'],
 *       pageSize: 10,
 *       enableSearch: true,
 *       enableSelection: true,
 *       enablePagination: true
 *     };
 *   }
 *
 *   onEdit(element: Class): void {
 *     this.router.navigate(['/masters/classes/edit', element.id]);
 *   }
 * }
 * ```
 */
@Component({
  selector: 'app-base-list',
  templateUrl: './base-list.component.html',
  styleUrls: ['./base-list.component.scss'],
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatTableModule,
    MatIconModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatPaginatorModule,
    MatSortModule,
    MatProgressBarModule,
    MatTooltipModule,
    MatMenuModule,
    MatCheckboxModule,
    MatCardModule,
    MatSnackBarModule,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export abstract class BaseListComponent<T extends ICrudEntity>
  implements OnInit, OnDestroy {
  
  // Data
  dataSource = new MatTableDataSource<T>();
  entities: T[] = [];
  
  // Configuration
  config!: BaseListConfig;
  displayColumns: string[] = [];
  filterFields: string[] = [];
  
  // Pagination & Sorting
  pageSizeOptions = [5, 10, 25, 50];
  paginationMeta: PaginationMeta | null = null;
  
  // Controls
  searchControl = new FormControl('');
  filterControls: { [key: string]: FormControl } = {};
  selectedRows = new Set<number>();
  
  // States
  isLoading = false;
  showFilters = false;
  
  // Lifecycle
  private destroy$ = new Subject<void>();

  constructor(
    protected snackBar: MatSnackBar,
    protected dialog: MatDialog,
    protected router: Router
  ) {}

  ngOnInit(): void {
    this.config = this.getConfig();
    this.displayColumns = [...this.config.displayColumns];
    this.filterFields = this.config.filterFields || [];
    
    this.setupFilters();
    this.setupSearch();
    this.loadData();
    this.subscribeToService();
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  /**
   * Override this method to provide the service
   */
  abstract getService(): BaseCrudService<T>;

  /**
   * Override this method to provide configuration
   */
  abstract getConfig(): BaseListConfig;

  /**
   * Override to handle edit action
   */
  onEdit(element: T): void {
    this.showMessage(`Edit: ${JSON.stringify(element)}`);
  }

  /**
   * Override to handle additional actions
   */
  onAction(action: string, element: T): void {
    console.log(`Action: ${action}`, element);
  }

  /**
   * Delete single entity
   */
  onDelete(element: T, event: any): void {
    event.stopPropagation();
    if (!element.id) return;

    const confirmDelete = confirm(
      `Are you sure you want to delete this item?`
    );
    if (!confirmDelete) return;

    this.getService()
      .delete(element.id)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: () => {
          this.showMessage('Deleted successfully', 'success');
          this.loadData();
        },
        error: (err) => {
          this.showMessage('Error deleting item', 'error');
          console.error('Delete error:', err);
        },
      });
  }

  /**
   * Bulk delete selected rows
   */
  onBulkDelete(): void {
    if (this.selectedRows.size === 0) {
      this.showMessage('Please select items to delete', 'warning');
      return;
    }

    const confirmDelete = confirm(
      `Are you sure you want to delete ${this.selectedRows.size} selected items?`
    );
    if (!confirmDelete) return;

    const ids = Array.from(this.selectedRows);
    this.getService()
      .batchDelete(ids)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: () => {
          this.showMessage(
            `${ids.length} items deleted successfully`,
            'success'
          );
          this.selectedRows.clear();
          this.loadData();
        },
        error: (err) => {
          this.showMessage('Error deleting items', 'error');
          console.error('Bulk delete error:', err);
        },
      });
  }

  /**
   * Handle row selection
   */
  toggleRowSelection(element: T, event: any): void {
    event.stopPropagation();
    if (!element.id) return;

    if (this.selectedRows.has(element.id)) {
      this.selectedRows.delete(element.id);
    } else {
      this.selectedRows.add(element.id);
    }
  }

  /**
   * Select all rows on current page
   */
  toggleSelectAll(event: any): void {
    if (event.checked) {
      this.dataSource.data.forEach((item) => {
        if (item.id) {
          this.selectedRows.add(item.id);
        }
      });
    } else {
      this.dataSource.data.forEach((item) => {
        if (item.id) {
          this.selectedRows.delete(item.id);
        }
      });
    }
  }

  /**
   * Check if row is selected
   */
  isRowSelected(element: T): boolean {
    return element.id ? this.selectedRows.has(element.id) : false;
  }

  /**
   * Get value from element by column name
   */
  getValue(element: T, column: string): any {
    return (element as any)[column];
  }

  /**
   * Check if value is a boolean
   */
  isBooleanValue(element: T, column: string): boolean {
    const value = this.getValue(element, column);
    return typeof value === 'boolean';
  }

  /**
   * Check if value is a date
   */
  isDate(value: any): boolean {
    if (!value) return false;
    return value instanceof Date || !isNaN(Date.parse(value as any));
  }

  /**
   * Get filter value for column
   */
  getFilterValue(field: string): string {
    return this.filterControls[field]?.value || '';
  }

  /**
   * Clear all filters
   */
  clearFilters(): void {
    this.searchControl.reset('');
    Object.values(this.filterControls).forEach((control) => control.reset(''));
    this.loadData();
  }

  /**
   * Handle pagination change
   */
  onPageChange(event: PageEvent): void {
    const filters: FilterOptions = {
      pageNumber: event.pageIndex + 1,
      pageSize: event.pageSize,
      searchTerm: this.searchControl.value || undefined,
    };
    this.loadData(filters);
  }

  /**
   * Handle sort change
   */
  onSortChange(event: Sort): void {
    const filters: FilterOptions = {
      sortBy: event.active,
      sortDirection: event.direction as 'asc' | 'desc',
      searchTerm: this.searchControl.value || undefined,
    };
    this.loadData(filters);
  }

  /**
   * Load data from service
   */
  private loadData(filters?: FilterOptions): void {
    const service = this.getService();
    const searchTerm = filters?.searchTerm || this.searchControl.value;
    
    const finalFilters: FilterOptions = {
      ...filters,
      searchTerm: searchTerm || undefined,
      pageSize: this.config.pageSize || 10,
    };

    service
      .getAll(finalFilters, this.config.enablePagination)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (response) => {
          if (Array.isArray(response)) {
            this.dataSource.data = response;
          } else {
            this.dataSource.data = response.data;
            this.paginationMeta = response.meta || null;
          }
        },
        error: (err) => {
          this.showMessage('Error loading data', 'error');
          console.error('Load data error:', err);
        },
      });
  }

  /**
   * Setup filter controls
   */
  private setupFilters(): void {
    this.filterFields.forEach((field) => {
      this.filterControls[field] = new FormControl('');
      this.filterControls[field].valueChanges
        .pipe(
          debounceTime(300),
          distinctUntilChanged(),
          takeUntil(this.destroy$)
        )
        .subscribe(() => {
          this.loadData();
        });
    });
  }

  /**
   * Setup search with debounce
   */
  private setupSearch(): void {
    if (!this.config.enableSearch) return;

    this.searchControl.valueChanges
      .pipe(
        debounceTime(300),
        distinctUntilChanged(),
        takeUntil(this.destroy$)
      )
      .subscribe(() => {
        this.loadData();
      });
  }

  /**
   * Subscribe to service updates
   */
  private subscribeToService(): void {
    const service = this.getService();

    service
      .getLoading$()
      .pipe(takeUntil(this.destroy$))
      .subscribe((loading) => {
        this.isLoading = loading;
      });
  }

  /**
   * Show snackbar message
   */
  protected showMessage(
    message: string,
    type: 'success' | 'error' | 'warning' = 'success'
  ): void {
    const panelClass = {
      success: 'snackbar-success',
      error: 'snackbar-error',
      warning: 'snackbar-warning',
    };
    this.snackBar.open(message, 'Close', {
      duration: 3000,
      horizontalPosition: 'end',
      verticalPosition: 'bottom',
      panelClass: [panelClass[type]],
    });
  }
}
