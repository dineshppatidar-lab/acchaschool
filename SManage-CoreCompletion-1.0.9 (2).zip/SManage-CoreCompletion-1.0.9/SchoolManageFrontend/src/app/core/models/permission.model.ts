export enum UserRole {
  SuperAdmin = 1,
  Administrator = 2,
  Principal = 3,
  VicePrincipal = 4,
  Teacher = 5,
  Staff = 6,
  Student = 7,
  Parent = 8,
  Librarian = 9,
  Accountant = 10,
  Receptionist = 11
}

export enum Permission {
  // User Management
  UsersView = 1,
  UsersCreate = 2,
  UsersEdit = 3,
  UsersDelete = 4,
  UsersManageRoles = 5,

  // Student Management
  StudentsView = 10,
  StudentsCreate = 11,
  StudentsEdit = 12,
  StudentsDelete = 13,
  StudentsViewDetails = 14,
  StudentsManageAdmissions = 15,

  // Staff Management
  StaffView = 20,
  StaffCreate = 21,
  StaffEdit = 22,
  StaffDelete = 23,
  StaffManagePayroll = 24,

  // Academic Management
  ClassesView = 30,
  ClassesCreate = 31,
  ClassesEdit = 32,
  ClassesDelete = 33,
  SubjectsView = 34,
  SubjectsManage = 35,
  TimetablesView = 36,
  TimetablesManage = 37,

  // Examination Management
  ExaminationsView = 40,
  ExaminationsCreate = 41,
  ExaminationsEdit = 42,
  ExaminationsDelete = 43,
  ResultsView = 44,
  ResultsEnter = 45,
  ResultsPublish = 46,

  // Finance Management
  FeesView = 50,
  FeesCollect = 51,
  FeesManageStructure = 52,
  FeesReports = 53,
  PaymentsView = 54,
  PaymentsProcess = 55,

  // Library Management
  LibraryView = 60,
  LibraryIssueBooks = 61,
  LibraryReturnBooks = 62,
  LibraryManageInventory = 63,

  // Transport Management
  TransportView = 70,
  TransportManageRoutes = 71,
  TransportManageVehicles = 72,
  TransportTrackAttendance = 73,

  // Hostel Management
  HostelView = 80,
  HostelManageRooms = 81,
  HostelManageAllocations = 82,
  HostelManageLeaves = 83,

  // Communication
  MessagesView = 90,
  MessagesSend = 91,
  AnnouncementsSend = 92,
  EventsManage = 93,

  // Reports & Analytics
  ReportsView = 100,
  ReportsGenerate = 101,
  AnalyticsView = 102,
  DashboardView = 103,

  // System Administration
  SystemSettings = 110,
  SystemBackupRestore = 111,
  SystemAuditLogs = 112,
  SystemManage = 113,

  // WhatsApp Integration
  WhatsAppView = 120,
  WhatsAppConfigure = 121,
  WhatsAppSend = 122,
  WhatsAppSendBulk = 123,
  WhatsAppViewHistory = 124,
  WhatsAppManageTemplates = 125,
  WhatsAppManageAutomation = 126,

  // School Website CMS (public website + content)
  WebsiteView = 130,
  WebsiteManage = 131
}

export interface PermissionLevel {
  canRead: boolean;
  canWrite: boolean;
  canDelete: boolean;
}

export interface UserPermissions {
  [key: number]: PermissionLevel; // Permission enum as key
}

export interface RolePermission {
  id: number;
  role: UserRole;
  permission: Permission;
  canRead: boolean;
  canWrite: boolean;
  canDelete: boolean;
  CreatedOn: Date;
}

export const RoleLabels: { [key in UserRole]: string } = {
  [UserRole.SuperAdmin]: 'Super Administrator',
  [UserRole.Administrator]: 'Administrator',
  [UserRole.Principal]: 'Principal',
  [UserRole.VicePrincipal]: 'Vice Principal',
  [UserRole.Teacher]: 'Teacher',
  [UserRole.Staff]: 'Staff',
  [UserRole.Student]: 'Student',
  [UserRole.Parent]: 'Parent',
  [UserRole.Librarian]: 'Librarian',
  [UserRole.Accountant]: 'Accountant',
  [UserRole.Receptionist]: 'Receptionist'
};

export const PermissionLabels: { [key in Permission]: string } = {
  [Permission.UsersView]: 'View Users',
  [Permission.UsersCreate]: 'Create Users',
  [Permission.UsersEdit]: 'Edit Users',
  [Permission.UsersDelete]: 'Delete Users',
  [Permission.UsersManageRoles]: 'Manage User Roles',
  
  [Permission.StudentsView]: 'View Students',
  [Permission.StudentsCreate]: 'Create Students',
  [Permission.StudentsEdit]: 'Edit Students',
  [Permission.StudentsDelete]: 'Delete Students',
  [Permission.StudentsViewDetails]: 'View Student Details',
  [Permission.StudentsManageAdmissions]: 'Manage Student Admissions',
  
  [Permission.StaffView]: 'View Staff',
  [Permission.StaffCreate]: 'Create Staff',
  [Permission.StaffEdit]: 'Edit Staff',
  [Permission.StaffDelete]: 'Delete Staff',
  [Permission.StaffManagePayroll]: 'Manage Staff Payroll',
  
  [Permission.ClassesView]: 'View Classes',
  [Permission.ClassesCreate]: 'Create Classes',
  [Permission.ClassesEdit]: 'Edit Classes',
  [Permission.ClassesDelete]: 'Delete Classes',
  [Permission.SubjectsView]: 'View Subjects',
  [Permission.SubjectsManage]: 'Manage Subjects',
  [Permission.TimetablesView]: 'View Timetables',
  [Permission.TimetablesManage]: 'Manage Timetables',
  
  [Permission.ExaminationsView]: 'View Examinations',
  [Permission.ExaminationsCreate]: 'Create Examinations',
  [Permission.ExaminationsEdit]: 'Edit Examinations',
  [Permission.ExaminationsDelete]: 'Delete Examinations',
  [Permission.ResultsView]: 'View Results',
  [Permission.ResultsEnter]: 'Enter Results',
  [Permission.ResultsPublish]: 'Publish Results',
  
  [Permission.FeesView]: 'View Fees',
  [Permission.FeesCollect]: 'Collect Fees',
  [Permission.FeesManageStructure]: 'Manage Fee Structure',
  [Permission.FeesReports]: 'Generate Fee Reports',
  [Permission.PaymentsView]: 'View Payments',
  [Permission.PaymentsProcess]: 'Process Payments',
  
  [Permission.LibraryView]: 'View Library',
  [Permission.LibraryIssueBooks]: 'Issue Books',
  [Permission.LibraryReturnBooks]: 'Return Books',
  [Permission.LibraryManageInventory]: 'Manage Library Inventory',
  
  [Permission.TransportView]: 'View Transport',
  [Permission.TransportManageRoutes]: 'Manage Transport Routes',
  [Permission.TransportManageVehicles]: 'Manage Vehicles',
  [Permission.TransportTrackAttendance]: 'Track Transport Attendance',
  
  [Permission.HostelView]: 'View Hostels',
  [Permission.HostelManageRooms]: 'Manage Hostel Rooms',
  [Permission.HostelManageAllocations]: 'Manage Hostel Allocations',
  [Permission.HostelManageLeaves]: 'Manage Hostel Leaves',
  
  [Permission.MessagesView]: 'View Messages',
  [Permission.MessagesSend]: 'Send Messages',
  [Permission.AnnouncementsSend]: 'Send Announcements',
  [Permission.EventsManage]: 'Manage Events',
  
  [Permission.ReportsView]: 'View Reports',
  [Permission.ReportsGenerate]: 'Generate Reports',
  [Permission.AnalyticsView]: 'View Analytics',
  [Permission.DashboardView]: 'View Dashboard',
  
  [Permission.SystemSettings]: 'System Settings',
  [Permission.SystemBackupRestore]: 'Backup & Restore',
  [Permission.SystemAuditLogs]: 'View Audit Logs',
  [Permission.SystemManage]: 'Manage System',

  [Permission.WhatsAppView]: 'View WhatsApp',

  [Permission.WebsiteView]: 'Public Website CMS',
  [Permission.WebsiteManage]: 'Manage School Website',
  [Permission.WhatsAppConfigure]: 'Configure WhatsApp',
  [Permission.WhatsAppSend]: 'Send WhatsApp Messages',
  [Permission.WhatsAppSendBulk]: 'Send Bulk WhatsApp Reminders',
  [Permission.WhatsAppViewHistory]: 'View WhatsApp History',
  [Permission.WhatsAppManageTemplates]: 'Manage WhatsApp Templates',
  [Permission.WhatsAppManageAutomation]: 'Manage WhatsApp Automation'
};