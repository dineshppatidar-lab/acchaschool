import { Component, OnInit, inject } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { IdleTimeoutService } from './services/idle-timeout.service';
import { GlobalLoadingComponent } from './shared/components/global-loading.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, GlobalLoadingComponent],
  template: '<router-outlet></router-outlet><app-global-loading />',
  styleUrl: './app.scss'
})
export class App implements OnInit {
  protected title = 'FrontendProject';

  // Auto-logout after inactivity (docs/critical-issues/16-jwt-in-localstorage.md).
  private readonly idleTimeout = inject(IdleTimeoutService);

  ngOnInit(): void {
    this.idleTimeout.start();
  }
}
