import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { StaffService, Staff } from '../services/staff.service';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-staff-list',
  standalone: true,
  imports: [CommonModule, MatIconModule, MatButtonModule, RouterModule],
  templateUrl: './staff-list.html',
  styleUrls: ['./staff-list.scss']
})
export class StaffListComponent implements OnInit {
  staff: Staff[] = [];
  loading = true;
  error: string | null = null;

  constructor(private staffService: StaffService) {}

  ngOnInit(): void {
    console.log('👥 Loading staff list...');
    this.staffService.getAll().subscribe({
      next: (data) => {
        console.log('👥 Staff loaded successfully:', data);
        console.log('👥 Number of staff:', data?.length || 0);
        this.staff = data;
        this.loading = false;
      },
      error: (err) => {
        console.error('❌ Error loading staff:', err);
        console.error('❌ Error status:', err.status);
        console.error('❌ Error message:', err.message);
        this.error = 'Failed to load staff';
        this.loading = false;
      }
    });
  }
}
