import { ApplicationConfig, DEFAULT_CURRENCY_CODE, ErrorHandler, importProvidersFrom, inject, provideAppInitializer, isDevMode, provideZonelessChangeDetection } from '@angular/core';
import { provideRouter } from '@angular/router';
import {
  HTTP_INTERCEPTORS,
  provideHttpClient,
  withFetch,
  withInterceptors,
  withInterceptorsFromDi
} from '@angular/common/http';
import { provideClientHydration, withEventReplay } from '@angular/platform-browser';
import { provideServiceWorker, SwUpdate, VersionReadyEvent } from '@angular/service-worker';
import { filter, first } from 'rxjs';
import { routes } from './app.routes';
import { provideAnimations } from '@angular/platform-browser/animations';
import { MatDialogModule, MAT_DIALOG_DEFAULT_OPTIONS, MatDialogConfig } from '@angular/material/dialog';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { provideNativeDateAdapter } from '@angular/material/core';

// Interceptors
import { authInterceptor } from './services/auth.interceptor'; // function-based
// import { JwtInterceptor } from './services/jwt.interceptor';   // class-based
import { GlobalErrorHandler } from './services/global-error-handler';
import { baseUrlInterceptor } from './services/base-url-interceptor';
import { tenantInterceptor } from './services/tenant-interceptor';
import { ThemeService } from './shared/services/theme.service';
import { authRefreshInterceptor } from './services/auth-refresh.interceptor';
import { apiResponseInterceptor } from './services/api-response.interceptor';
import { globalLoadingInterceptor } from './services/global-loading.interceptor';

export const appConfig: ApplicationConfig = {
  providers: [
// True zoneless mode: every component's async state is signal-based (writes schedule
// their own change detection), so no zone.js is needed. Keep it that way — new async
// state must use signals, otherwise UI updates will silently stop rendering.
    provideZonelessChangeDetection(),
    provideRouter(routes),
    provideClientHydration(withEventReplay()),
    provideAnimations(),
    { provide: DEFAULT_CURRENCY_CODE, useValue: 'INR' },

    // Material datepicker: NativeDateAdapter + MAT_DATE_FORMATS app-wide.
    // Standalone components that import MatDatepickerModule (dialogs opened from
    // Events, etc.) resolve DateAdapter through the environment injector — without
    // this they crash with NullInjectorError: No provider for DateAdapter.
    provideNativeDateAdapter(),

    // ✅ Register function-based + class-based interceptors
    provideHttpClient(
       withFetch(), // ✅ Enable Fetch API support
  // globalLoadingInterceptor runs FIRST (outermost) so its counter window
  // also covers silent token-refresh + retry inside authRefreshInterceptor.
  withInterceptors([globalLoadingInterceptor, authInterceptor, baseUrlInterceptor, tenantInterceptor, authRefreshInterceptor, apiResponseInterceptor]),
      withInterceptorsFromDi()
      // function-based interceptor
    ),

  { provide: ErrorHandler, useClass: GlobalErrorHandler },
  MatSnackBar,
  importProvidersFrom(MatSnackBarModule),

    // ✅ Only class-based interceptors go here
    // { provide: HTTP_INTERCEPTORS, useClass: JwtInterceptor, multi: true }

    // ✅ Global Dialog Defaults (mobile-first)
    {
      provide: MAT_DIALOG_DEFAULT_OPTIONS,
      useValue: {
        hasBackdrop: true,
        autoFocus: true,
        restoreFocus: true,
        disableClose: false,
        panelClass: 'edusphere-dialog',
      } as MatDialogConfig
    },

    // PWA Service Worker
    provideServiceWorker('ngsw-worker.js', {
      enabled: !isDevMode(),
      registrationStrategy: 'registerWhenStable:30000'
    }),

    // Apply the persisted/system theme at startup so every page — including
    // the standalone login route — renders with the active theme and data-theme
    // is on <html> before any overlay or component reads it.
    provideAppInitializer(() => {
      inject(ThemeService);
      return Promise.resolve();
    }),

    // Auto-update: when a new app version is available, activate it and reload.
    // Without this, users stay on a stale bundle + stale SW-managed caches until a
    // manual hard-refresh (the old bundle kept serving week-old cached API data).
    provideAppInitializer(() => {
      const updates = inject(SwUpdate);
      if (!updates.isEnabled) return Promise.resolve();

      updates.versionUpdates
        .pipe(filter((e): e is VersionReadyEvent => e.type === 'VERSION_READY'), first())
        .subscribe(async () => {
          try {
            await updates.activateUpdate();
            document.location.reload();
          } catch { /* keep the current version running */ }
        });

      updates.unrecoverable.subscribe(() => document.location.reload());
      return Promise.resolve();
    }),
  ]
};
