import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AcademicService } from '../services/academic.service';
import { Class } from '../shared/models/academic.models';
import { MatTableModule } from '@angular/material/table';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { RouterModule } from '@angular/router';
import { Observable } from 'rxjs';
import { delay } from 'rxjs/operators';

@Component({
  selector: 'app-academic-list',
  standalone: true,
  imports: [CommonModule, MatTableModule, MatButtonModule, MatIconModule, RouterModule],
  templateUrl: './academic-list.html',
  styleUrls: ['./academic-list.scss']
})
export class AcademicListComponent implements OnInit {
  classes$!: Observable<Class[]>;
  displayedColumns: string[] = ['id', 'name', 'description', 'actions'];
  loading = true;
  error: string | null = null;

  constructor(private academicService: AcademicService) {}

  ngOnInit() {
    this.loadClasses();
  }

  loadClasses() {
    this.classes$ = this.academicService.getAll().pipe(delay(0));
  }

  editClass(id: number) {
    // Implement navigation to edit form
  }

  deleteClass(id: number) {
    if (confirm('Are you sure you want to delete this class?')) {
      this.academicService.delete(id).subscribe(() => {
        this.loadClasses();
      });
    }
  }
}
