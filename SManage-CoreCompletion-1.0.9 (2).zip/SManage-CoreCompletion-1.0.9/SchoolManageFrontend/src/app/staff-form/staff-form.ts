
import { Component, OnInit, signal } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatSelectModule } from '@angular/material/select';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { RouterModule, ActivatedRoute, Router } from '@angular/router';
import { StaffService, Staff } from '../services/staff.service';
import { MasterDataService } from '../services/master-data.service';

@Component({
  selector: 'app-staff-form',
  standalone: true,
  imports: [
    CommonModule, 
    ReactiveFormsModule, 
    MatFormFieldModule, 
    MatInputModule, 
    MatButtonModule, 
    MatCardModule, 
    MatIconModule,
    MatSelectModule,
    MatProgressSpinnerModule,
    RouterModule
  ],
  templateUrl: './staff-form.html',
  styleUrls: ['./staff-form.scss']
})
export class StaffFormComponent implements OnInit {
  staffForm: FormGroup;
  success: string | null = null;
  error: string | null = null;
  isEditMode = false;
  staffId: number | null = null;
  isSubmitting = false;

  // Position/Role options come from the DB-backed lookups so this form always
  // agrees with the Designations/Departments admin screens (no static lists).
  positions = signal<string[]>([]);
  designations = signal<string[]>([]);

  constructor(
    private fb: FormBuilder, 
    private staffService: StaffService,
    private masterDataService: MasterDataService,
    private route: ActivatedRoute,
    private router: Router
  ) {
    this.staffForm = this.fb.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      dateOfBirth: ['', Validators.required],
      gender: ['', Validators.required],
      address: [''],
      city: [''],
      state: [''],
      zipCode: [''],
      phoneNumber: [''],
      email: ['', [Validators.required, Validators.email]],
      hireDate: ['', Validators.required],
      position: ['', Validators.required],
      salary: [0, Validators.required],
      role: ['', Validators.required],
      qualification: [''],
      specialization: ['']
    });
  }

  ngOnInit(): void {
    this.loadLookups();
    this.route.params.subscribe(params => {
      if (params['id']) {
        this.isEditMode = true;
        this.staffId = +params['id'];
        this.loadStaffData();
      }
    });
  }

  private loadLookups(): void {
    this.masterDataService.getStaffPositions().subscribe(res => this.positions.set(res || []));
    this.masterDataService.getStaffPositions().subscribe(res => this.designations.set(res || []));
  }

  loadStaffData(): void {
    if (this.staffId) {
      this.staffService.getById(this.staffId).subscribe({
        next: (staff) => {
          this.staffForm.patchValue(staff);
        },
        error: (error) => {
          console.error('Error loading staff data:', error);
          this.error = 'Error loading staff data';
        }
      });
    }
  }

  onSubmit() {
    if (this.staffForm.valid) {
      this.isSubmitting = true;
      this.error = null;
      this.success = null;
      
      const staffData = this.staffForm.value as Staff;
      
      if (this.isEditMode && this.staffId) {
        staffData.id = this.staffId;
        this.staffService.update(this.staffId, staffData).subscribe({
          next: () => {
            this.isSubmitting = false;
            this.success = 'Staff updated successfully!';
            this.error = null;
            setTimeout(() => {
              this.router.navigate(['/app/staff/list']);
            }, 1500);
          },
          error: (error) => {
            this.isSubmitting = false;
            console.error('Error updating staff:', error);
            this.error = 'Error updating staff. Please try again.';
          }
        });
      } else {
        this.staffService.create(staffData).subscribe({
          next: () => {
            this.isSubmitting = false;
            this.success = 'Staff added successfully!';
            this.error = null;
            this.staffForm.reset();
            // Go back to the list right after (same flow as the update path),
            // so the freshly-cleared form is never shown with 'Required' errors
            // that look like a failed save.
            setTimeout(() => {
              this.router.navigate(['/app/staff/list']);
            }, 1200);
          },
          error: () => {
            this.isSubmitting = false;
            this.error = 'Failed to add staff. Please try again.';
            this.success = null;
          }
        });
      }
    } else {
      // Mark all fields as touched to show validation errors
      Object.keys(this.staffForm.controls).forEach(key => {
        const control = this.staffForm.get(key);
        if (control) {
          control.markAsTouched();
        }
      });
      this.error = 'Please fill in all required fields correctly.';
    }
  }
}
