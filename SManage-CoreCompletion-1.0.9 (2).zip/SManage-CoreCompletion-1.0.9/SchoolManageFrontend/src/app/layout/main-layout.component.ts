import { Component, ViewChild, HostListener, OnInit, OnDestroy, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterOutlet, RouterModule, Router, NavigationEnd } from '@angular/router';
import { Location } from '@angular/common';
import { MatSidenavModule, MatSidenav } from '@angular/material/sidenav';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatListModule } from '@angular/material/list';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatMenuModule } from '@angular/material/menu';
import { MatBadgeModule } from '@angular/material/badge';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatDividerModule } from '@angular/material/divider';
import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';
import { filter, map, shareReplay } from 'rxjs/operators';

import { AuthService } from '../services/auth.service';
import { TenantService, TenantDto } from '../services/tenant.service';
import { AcademicYearContextService, AcademicYearItem } from '../shared/services/academic-year-context.service';
import { DynamicMenuService, MenuItem } from '../services/dynamic-menu.service';

import { SidebarDynamicComponent } from '../shared/sidebar/sidebar-dynamic.component';
import { SidebarService } from '../shared/services/sidebar.service';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { BottomNavComponent, BottomNavItem } from '../shared/components/bottom-nav.component';
import { MoreMenuComponent } from '../shared/components/more-menu.component';
import { NotificationBellComponent } from '../shared/components/notification-bell.component';
import { NotificationStreamService } from '../services/notification-stream.service';
import { SetupStatusService } from '../core/services/setup-status.service';
import { SetupStatusBannerComponent } from '../shared/components/setup-status-banner.component';

@Component({
  selector: 'app-main-layout',
  standalone: true,
  imports: [
    CommonModule, RouterOutlet, RouterModule,
    MatSidenavModule, MatToolbarModule, MatIconModule, MatButtonModule,
    MatListModule, MatExpansionModule, MatTooltipModule, MatMenuModule,
    MatBadgeModule, MatFormFieldModule, MatInputModule, MatSelectModule,
    MatProgressSpinnerModule, MatDividerModule,
    SidebarDynamicComponent, BottomNavComponent, MoreMenuComponent,
    NotificationBellComponent, SetupStatusBannerComponent
  ],
  templateUrl: './main-layout.component.html',
  styleUrls: ['./main-layout.component.scss']
})
export class MainLayoutComponent implements OnInit, OnDestroy {
  @ViewChild('drawer', { static: true }) drawer!: MatSidenav;

  currentRoute = '';
  sidenavOpened = true;
  isHandset$: any;
  showMoreMenu = false;

  /* ── Trimmed mobile header state (hamburger ⇄ back arrow + page title) ──
   * Computed on every NavigationEnd from the permission-filtered dynamic
   * menu tree (the same data the drawer renders) so nesting follows the
   * real navigation hierarchy, not URL segment counts. Desktop ignores
   * back/title entirely via CSS — the header markup is shared. */
  headerTitle = '';
  isNestedPage = false;

  /** Home (dashboard) keeps the hamburger on the compact mobile header;
   *  every other page is a back page — the topbar is the single owner
   *  of back + title (in-page headers were removed). */
  isHomePage = true;

  /** In-app history (this session): enables the breadcrumb-style back on
   *  handsets and a safe fallback when the user deep-links/refreshes. */
  private navHistory: string[] = [];

  /** True when the compact phone header applies (same 767.98px break the
   *  header SCSS uses); separate from isHandset$ which also treats tablet
   *  portrait as a drawer-over layout for the *sidebar*. */
  isMobileWidth = false;

  /** Curated titles for pages the menu doesn't list (redirect aliases,
   *  standalone admin pages …); see matchOverride. */
  private static readonly screenTitles: Record<string, string> = {
    'students/list': 'Students',
    'students/import-export': 'Student Records',
    'staff/list': 'Staff',
    'staff/designations': 'Designations',
    'payroll': 'Payroll',
    'parents': 'Parents',
    'fees/list': 'Fees',
    'fees': 'Fees',
    'fees/waivers': 'Fee Waivers',
    'fees/discounts': 'Student Discounts',
    'fees/family-payments': 'Family Payments',
    'fees/defaulters': 'Fee Defaulters',
    'fees/rules': 'Fee Rules',
    'finance/structure': 'Fee Structure',
    'finance/reports': 'Finance Reports',
    'advanced-finance': 'Advanced Finance',
    'whatsapp': 'WhatsApp',
    'whatsapp/fee-reminders': 'WhatsApp Reminders',
    'whatsapp/history': 'WhatsApp History',
    'notifications': 'Notifications',
    'hostels': 'Hostels',
    'hostel': 'Hostel',
    'transport': 'Transport',
    'library': 'Library',
    'students/enquiry': 'Student Enquiry',
    'students/enquiry-list': 'Enquiry List',
    'examinations/results': 'Results',
    'examinations': 'Examinations',
    'examination-types': 'Examination Types',
    'academic': 'Manage Academic',
    'attendance': 'Attendance',
    'analytics': 'Analytics',
    'daily-ops': 'Daily Operations',
    'import-export': 'Import / Export',
    'settings': 'Settings',
    'admin/audit-logs': 'Audit Logs',
    'admin/permissions': 'Permissions',
    'admin/menu-permissions': 'Menu Permissions',
    'admin/tenants': 'Tenants',
    'admin/settings': 'Settings',
    'admin/backup': 'Backup & Restore',
    'admin/user-management': 'User Management',
    'users': 'Users',
    'profile': 'My Profile',
    'help': 'Help & Support',
    'access-denied': 'Access Denied'
  };

  userProfile = {
    name: 'Administrator',
    role: 'System Admin',
    email: 'admin@acchaschool.com',
    avatar: ''
  };

  /** Which modules the bottom nav would like to pin, in priority order.
   *  Actual visibility is decided from the permission-filtered dynamic menu
   *  (the exact same tree the desktop sidebar renders) — see rebuildBottomNav.
   *  Unauthorized modules are dropped and never flash while the menu loads:
   *  the initial list only contains Home + More, both accessible to every
   *  authenticated user. */
  private readonly preferredBottomItems: BottomNavItem[] = [
    { icon: 'school', label: 'Students', route: '/app/students/full-details' },
    { icon: 'payments', label: 'Fees', route: '/app/fees/dashboard' },
    { icon: 'event_available', label: 'Attendance', route: '/app/attendance' }
  ];

  bottomNavItems: BottomNavItem[] = [
    { icon: 'home', label: 'Home', route: '/app/dashboard' },
    { icon: 'more_horiz', label: 'More', isMore: true }
  ];

  tenants: TenantDto[] = [];
  selectedTenantId: number = 1;
  academicYears: AcademicYearItem[] = [];
  selectedYearId: number | null = null;
  isLoadingYears = false;

  constructor(
    private breakpointObserver: BreakpointObserver,
    private router: Router,
    private authService: AuthService,
    private cdr: ChangeDetectorRef,
    private tenantService: TenantService,
    private sidebarService: SidebarService,
    private yearContext: AcademicYearContextService,
    private menuService: DynamicMenuService,
    private location: Location,
    public notifStream: NotificationStreamService,
    public setupStatus: SetupStatusService,
  ) {
    this.isHandset$ = this.breakpointObserver.observe([
      Breakpoints.Handset, Breakpoints.TabletPortrait
    ]).pipe(
      map(result => result.matches),
      shareReplay()
    );
    // Compact phone-header width — mirrors the @media (max-width: 767.98px)
    // blocks in the header styles so JS/CSS agree on when the title/back
    // mode is active.
    this.breakpointObserver.observe(['(max-width: 767.98px)']).subscribe(r => {
      setTimeout(() => { this.isMobileWidth = r.matches; this.cdr.markForCheck(); });
    });
  }

  ngOnInit(): void {
    this.loadUserProfile();

    // Mobile bottom navigation mirrors the desktop sidebar's permissions:
    // react to the dynamically loaded (permission-filtered) menu and rebuild
    // the pinned icons from it. Until the load settles the list stays at the
    // safe Home + More default — unauthorized icons never flash.
    this.menuSubscriptions.push(
      this.menuService.mainMenu$.subscribe(menu => {
        if (menu && menu.length > 0) { this.rebuildBottomNav(menu); }
      }),
      this.menuService.error$.subscribe(err => {
        if (err && !this.menuService.getMainMenuSync().length) {
          this.bottomNavItems = [
            { icon: 'home', label: 'Home', route: '/app/dashboard' },
            { icon: 'more_horiz', label: 'More', isMore: true }
          ];
          this.cdr.markForCheck();
        }
      })
    );
    // Trigger the load (cached + shared with the sidebar — one API call).
    this.menuService.loadMainMenu().subscribe({ error: () => { /* error$ handles the UI */ } });

    // Onboarding: load setup status once per session (cached in the service;
    // the banner, dashboard card and sidebar badge all read the same signals).
    this.setupStatus.load();

    // Notification bell: load list + unread badge, subscribe to live push.
    this.notifStream.start();

    this.sidebarService.sidebarOpen$.subscribe((isOpen: boolean) => {
      setTimeout(() => {
        this.sidenavOpened = isOpen;
        if (isOpen && this.drawer) { this.drawer.open(); }
        else if (!isOpen && this.drawer) { this.drawer.close(); }
        this.cdr.markForCheck();
      });
    });

    this.isLoadingYears = true;
    this.yearContext.loadAcademicYears().subscribe({
      complete: () => { this.isLoadingYears = false; this.cdr.markForCheck(); }
    });
    this.yearContext.academicYears$.subscribe(years => { this.academicYears = years; this.cdr.markForCheck(); });
    this.yearContext.selectedAcademicYear$.subscribe(id => { this.selectedYearId = id; this.cdr.markForCheck(); });

    this.tenantService.selectedTenant$.subscribe(id => {
      setTimeout(() => { this.selectedTenantId = id ?? 1; this.cdr.markForCheck(); });
    });
    this.tenantService.loadTenants().subscribe({
      next: () => {
        setTimeout(() => {
          this.tenants = this.tenantService.getTenantsSnapshot();
          if (!this.tenants.some(t => t.id === this.selectedTenantId)) {
            const fallback = this.tenants.find(t => t.isActive)?.id ?? 1;
            this.onTenantChange(fallback);
          }
          this.cdr.markForCheck();
        });
      }
    });

    this.router.events.pipe(filter(event => event instanceof NavigationEnd)).subscribe((event: NavigationEnd) => {
      setTimeout(() => { this.currentRoute = event.url; this.updateHeaderState(event.url); this.cdr.markForCheck(); });
    });
    this.currentRoute = this.router.url;
    this.updateHeaderState(this.router.url);

    // The header's nesting logic keys off the (async-loaded) menu tree;
    // recompute once it arrives so a refresh on a menu route gets the
    // right title immediately, and again on permission-filter changes.
    this.menuSubscriptions.push(
      this.menuService.mainMenu$.subscribe(menu => {
        if (menu && menu.length > 0) { this.updateHeaderState(this.currentRoute); this.cdr.markForCheck(); }
      })
    );

    this.isHandset$.subscribe((isHandset: boolean) => {
      setTimeout(() => {
        if (isHandset) {
          if (this.drawer) this.drawer.mode = 'over';
          this.sidebarService.setSidebarOpen(false);
        } else {
          if (this.drawer) this.drawer.mode = 'side';
          this.sidebarService.setSidebarOpen(true);
        }
        this.cdr.markForCheck();
      });
    });
  }

  toggleSidenav(): void { this.sidebarService.toggleSidebar(); }

  /** Left icon tap: back navigates up one level on every non-home mobile
   *  page; Home keeps the hamburger that opens the drawer. */
  onNavAction(): void {
    if (this.isMobileWidth && !this.isHomePage) { this.navigateToParent(); } else { this.toggleSidenav(); }
  }

  /** Back from a nested screen: prefer the exact in-app origin (one
   *  history step — restores params/scroll, honors CanDeactivate guards),
   *  fall back to the module's menu parent when the screen was reached
   *  directly (refresh/deep link), then to the dashboard. */
  navigateToParent(): void {
    if (this.navHistory.length > 1) {
      this.location.back();
      return;
    }
    const parent = this.findMenuParentRoute(this.currentRoute);
    if (parent && parent !== this.stripRouteQuery(this.currentRoute)) {
      this.router.navigateByUrl(parent);
      return;
    }
    this.router.navigate(['/app/dashboard']);
  }

  /** ── Header title/nesting computation ─────────────────────────────────
   *  A page is root-level when the permission-filtered menu tree points at
   *  it — either exactly, or as the module's own landing page (the menu
   *  stores module roots like '/app/students' that redirect to overview
   *  pages such as '…/full-details'). Everything else — forms, detail and
   *  edit screens — is a nested workflow and gets the back arrow. Titles
   *  come from: the menu label, a curated workflow override
   *  (alwaysNestedTitleOverrides / screenTitles), or a prettified URL segment. */
  private updateHeaderState(rawUrl: string): void {
    const path = this.stripRouteQuery(rawUrl);
    // RelPath like "students/form" under /app (menu routes are stored with
    // the /app/ prefix — normalize both sides before matching).
    const rel = this.stripAppPrefix(path);
    // Home keeps the hamburger; every other page is a back page on mobile.
    this.isHomePage = rel === 'dashboard' || rel === '';
    const menu = this.menuService.getMainMenuSync();

    let title: string | undefined;
    let nested: boolean;

    // 1. Exact menu hit → the page is itself a drawer destination.
    const exact = menu.length ? this.findMenuMatch(menu, rel) : undefined;
    if (exact) {
      nested = false;
      title = exact.label;
    } else {
      const override = this.matchOverride(rel);
      // 2. Module landing page: the deepest menu route that prefixes the
      //    URL equals the URL's module root and the remainder is a plain
      //    overview segment (not form/edit details → those stay nested).
      //    Menu labels win over URL words — menus update from the DB.
      const modRoot = rel.split('/')[0];
      const deepest = menu.length ? this.findDeepestMenuPrefix(menu, rel) : undefined;
      if (override) {
        // A named workflow screen (alwaysNested) is by definition nested;
        // a screenTitles alias keeps nesting from the menu-based checks.
        nested = MainLayoutComponent.alwaysNestedTitleOverrides[rel] !== undefined
          || this.matchTable(MainLayoutComponent.alwaysNestedTitleOverrides, rel) === override;
        title = override;
      } else if (deepest && deepest.rel === modRoot && this.isOverviewSegment(rel)) {
        nested = false;
        title = deepest.item.label;
      } else if (deepest) {
        nested = true;
        title = deepest.item.label;
      } else {
        nested = modRoot !== 'dashboard'; // Home stays a hamburger page
        title = undefined;
      }
      if (title === undefined) {
        title = this.prettifySegment(rel.split('/').pop() ?? rel);
      }
      this.isNestedPage = nested;
      this.headerTitle = title;
      this.pushNavHistory(path);
      return;
    }
    this.isNestedPage = nested;
    this.headerTitle = title!;
    this.pushNavHistory(path);
  }

  /** Route patterns (fees/dashboard/:studentId → 'Student Fees') that are
   *  *always* treated as nested/back pages. */
  private static readonly alwaysNestedTitleOverrides: Record<string, string> = {
    'students/form': 'Student Admission',
    'students/edit/:id': 'Edit Student',
    'students/full-details/add': 'Student Admission',
    'students/full-details/edit/:id': 'Edit Student',
    'students/full-details/view/:id': 'Student Details',
    'students/full-details/enterprise/add': 'Student Admission',
    'students/full-details/enterprise/edit/:id': 'Edit Student',
    'staff/import-export': 'Staff Records',
    'staff/form': 'Add Staff',
    'staff/edit/:id': 'Edit Staff',
    'fees/form': 'Collect Fee Payment',
    'fees/edit/:id': 'Collect Fee Payment',
    'fees/dashboard/:studentId': 'Student Fees',
    'fees/student/:studentId/ledger': 'Student Ledger',
    'users/add': 'Add User',
    'users/edit/:id': 'Edit User',
    'users/view/:id': 'User Details',
    'academic/form': 'Academic Setup',
    'academic/edit/:id': 'Edit Academic',
    'examinations/:id/schedules': 'Exam Schedules',
    'hostel/form': 'Add Hostel',
    'hostel/edit/:id': 'Edit Hostel',
    'transport/form': 'Add Transport',
    'transport/edit/:id': 'Edit Transport',
    'vehicles/edit/:id': 'Edit Vehicle',
    'transport/routes/:routeId/stops': 'Route Stops',
    'transport/routes/:routeId/assign': 'Route Assignment',
    'students/enquiry/edit/:id': 'Edit Enquiry',
    'master-data/:type': 'Master Data'
  };

  /** Remember in-app URLs (capped) for the exact-step back action. */
  private pushNavHistory(path: string): void {
    if (this.navHistory[this.navHistory.length - 1] !== path) {
      this.navHistory.push(path);
      if (this.navHistory.length > 10) { this.navHistory.shift(); }
    }
  }

  /** "students/form" (accepts both "/app/x" and "x" spellings). */
  private stripAppPrefix(path: string): string {
    return path.replace(/^\/+(?:app\/)?/, '');
  }

  private stripRouteQuery(url: string): string {
    return url.split('?')[0].split('#')[0].replace(/\/+$/, '') || '/app/dashboard';
  }

  /** Deepest menu entry whose route exactly equals the current path. */
  private findMenuMatch(items: MenuItem[], relPath: string): MenuItem | undefined {
    const norm = (r?: string) => this.stripAppPrefix((r || '').split('?')[0]).replace(/\/+$/, '');
    const target = norm(relPath);
    for (const item of items) {
      const candidate = norm(item.route);
      if (candidate && candidate === target && item.isActive !== false) {
        return item;
      }
      if (item.children && item.children.length > 0) {
        const found = this.findMenuMatch(item.children, relPath);
        if (found) { return found; }
      }
    }
    return undefined;
  }

  /** Deepest menu route that is a prefix of the current path */
  private findMenuParentRoute(rawUrl: string): string | undefined {
    const menu = this.menuService.getMainMenuSync();
    if (!menu.length) { return undefined; }
    const target = this.stripAppPrefix(this.stripRouteQuery(rawUrl));

    let best: { route: string; depth: number } | undefined;
    const walk = (items: MenuItem[]) => {
      for (const item of items) {
        if (item.route && item.isActive !== false) {
          const candidate = this.stripAppPrefix(item.route.split('?')[0]).replace(/\/+$/, '');
          if (target.startsWith(candidate + '/') || candidate.startsWith(target + '/') || candidate === target) {
            const depth = candidate.split('/').length;
            if (!best || depth > best.depth) { best = { route: item.route, depth }; }
          }
        }
        if (item.children) { walk(item.children); }
      }
    };
    walk(menu);
    return best?.route;
  }

  /** Matches the current path against a table's ':param' keys — longest
   *  (most specific) matching key wins. */
  private matchTable(table: Record<string, string>, relPath: string): string | undefined {
    const segs = relPath.split('/');
    let best: string | undefined;
    for (const key of Object.keys(table)) {
      const keySegs = key.split('/');
      if (keySegs.length !== segs.length) { continue; }
      let ok = true;
      for (let i = 0; i < keySegs.length; i++) {
        if (keySegs[i] !== segs[i] && !keySegs[i].startsWith(':')) { ok = false; break; }
      }
      if (ok) { best = table[key]; }
    }
    return best;
  }

  /** Title for the current rel path: named workflows beat module aliases. */
  private matchOverride(relPath: string): string | undefined {
    return this.matchTable(MainLayoutComponent.alwaysNestedTitleOverrides, relPath)
      ?? this.matchTable(MainLayoutComponent.screenTitles, relPath);
  }

  /** Deepest active menu route that starts the current path, e.g. menu
   *  '/app/students' for URL 'students/full-details'. Only ancestor
   *  matching (candidate ⊂ target) — reverse matches don't apply here. */
  private findDeepestMenuPrefix(items: MenuItem[], relPath: string): { item: MenuItem; rel: string } | undefined {
    const norm = (r?: string) => this.stripAppPrefix((r || '').split('?')[0]).replace(/\/+$/, '');
    const target = norm(relPath);
    if (!target) { return undefined; }
    let best: { item: MenuItem; rel: string } | undefined;
    const walk = (nodes: MenuItem[]) => {
      for (const node of nodes) {
        if (node.route && node.isActive !== false) {
          const candidate = norm(node.route);
          if (candidate && target.startsWith(candidate + '/')) {
            const depth = candidate.split('/').length;
            if (!best || depth > best.rel.split('/').length) { best = { item: node, rel: candidate }; }
          }
        }
        if (node.children) { walk(node.children); }
      }
    };
    walk(items);
    return best;
  }

  /** True when the URL's remainder after its module root looks like a
   *  plain overview segment ('full-details', 'results', a single word),
   *  vs. an editing workflow ('edit/5', 'form', numeric ids …). */
  private isOverviewSegment(relPath: string): boolean {
    const segs = relPath.split('/');
    if (segs.length < 2) { return false; }
    const tail = segs.slice(1).join('/');
    if (/^\d+$/.test(tail)) { return false; }
    return segs.slice(1).every(s => !/^(form|add|edit|view|import|export)$/i.test(s) && !/^\d+$/.test(s));
  }

  /** "fee-defaulters" → "Fee Defaulters" */
  private prettifySegment(seg: string): string {
    return (seg || '').replace(/[-_]+/g, ' ').replace(/\b\w/g, c => c.toUpperCase());
  }

  openMoreMenu(): void {
    this.showMoreMenu = true;
    if (this.drawer && this.sidenavOpened) { this.sidebarService.setSidebarOpen(false); }
  }

  closeMoreMenu(): void { this.showMoreMenu = false; }
  onDrawerClosed(): void { this.sidebarService.setSidebarOpen(false); }

  onTenantChange(id: number) {
    this.selectedTenantId = id;
    this.tenantService.setSelectedTenant(id);
    // (snack removed) The tenant switch happens silently now — the toast
    // ("Tenant switched to #01") also fired automatically on first load
    // when the fallback tenant was applied.
  }

  onAcademicYearChange(yearId: number): void { this.yearContext.setYear(yearId); }

  loadUserProfile(): void {
    this.authService.user$.subscribe(user => {
      if (user) {
        const userTenantId = user.tenantId || user.selectedTenantId || null;
        if (userTenantId) { this.tenantService.setSelectedTenant(userTenantId); }
        const name = user.username || user.name || 'User';
        this.userProfile = {
          name: name,
          role: user.role || user.roles || 'User',
          email: user.email || 'user@system.com',
          avatar: user.avatar || `https://ui-avatars.com/api/?name=${encodeURIComponent(name)}&background=1565C0&color=fff&size=80&bold=true`
        };
      }
    });
  }

  onProfile(): void { this.router.navigate(['/app/profile']); }
  onSettings(): void { this.router.navigate(['/app/settings']); }
  onHelp(): void { this.router.navigate(['/app/help']); }

  onLogout(): void {
    try { this.authService.logout(); } catch (error) {
      console.error('Logout error:', error); this.router.navigate(['/']);
    }
  }

  openNotifications(): void { this.router.navigate(['/app/communication']); }

  private menuSubscriptions: { unsubscribe(): void }[] = [];

  ngOnDestroy(): void {
    this.menuSubscriptions.forEach(s => s.unsubscribe());
  }

  /**
   * Rebuild the bottom nav from the permission-filtered menu tree.
   * A preferred module is pinned only when the (server-filtered) sidebar
   * tree contains a menu item whose route matches it — so mobile shows
   * exactly the modules the user's role is authorized for, identical to
   * the desktop sidebar. Home stays pinned regardless (every role reaches
   * the dashboard), and More is always last.
   */
  private rebuildBottomNav(menu: MenuItem[]): void {
    const items: BottomNavItem[] = [
      { icon: 'home', label: 'Home', route: '/app/dashboard' }
    ];
    for (const pref of this.preferredBottomItems) {
      if (menuAuthorizesRoute(menu, pref.route!)) {
        items.push({ ...pref });
      }
    }
    items.push({ icon: 'more_horiz', label: 'More', isMore: true });
    this.bottomNavItems = items;
    this.cdr.markForCheck();
  }

  @HostListener('keydown', ['$event'])
  handleKeyDown(event: KeyboardEvent): void {
    if (event.ctrlKey && event.key === 'b') { event.preventDefault(); this.toggleSidenav(); }
  }
}

/**
 * Recursively checks the menu tree for an item whose route matches `route`
 * (normalized: query stripped, trailing slashes removed). Matching works in
 * both directions so menu `/app/students` authorizes the pinned
 * `/app/students/full-details` and a menu detail route authorizes its parent.
 */
export function menuAuthorizesRoute(menu: MenuItem[], route: string): boolean {
  const norm = (r: string) => (r || '').split('?')[0].split('#')[0].replace(/\/+$/, '');
  const wanted = norm(route);
  if (!wanted) { return false; }

  const walk = (items: MenuItem[]): boolean => {
    for (const item of items) {
      if (item.route) {
        const candidate = norm(item.route);
        if (candidate === wanted || wanted.startsWith(candidate + '/') || candidate.startsWith(wanted + '/')) {
          return item.isActive === undefined || item.isActive !== false;
        }
      }
      if (item.children && item.children.length > 0 && walk(item.children)) {
        return true;
      }
    }
    return false;
  };
  return walk(menu);
}
