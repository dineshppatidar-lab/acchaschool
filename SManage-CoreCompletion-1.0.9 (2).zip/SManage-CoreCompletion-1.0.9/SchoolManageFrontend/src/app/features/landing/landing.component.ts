import { Component, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatCardModule } from '@angular/material/card';
import { MatChipsModule } from '@angular/material/chips';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-landing',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatButtonModule, MatIconModule, MatCardModule, MatChipsModule, RouterModule],
  templateUrl: './landing.component.html',
  styleUrls: ['./landing.component.css']
})
export class LandingComponent {
  readonly currentYear = new Date().getFullYear();
  readonly maxFreeStudents = 200;

  // Honest product stats — everything below ships in the app today
  readonly stats = [
    { value: '20+', label: 'Integrated modules', icon: 'widgets' },
    { value: '100+', label: 'Screens & workflows', icon: 'layers' },
    { value: '6', label: 'Campus operations domains', icon: 'domain' },
    { value: '0', label: 'Cost up to 200 students', icon: 'savings' }
  ];

  // Headline capabilities — drawn from real feature areas
  readonly features = [
    {
      icon: 'how_to_reg',
      title: 'Admissions & Student Records',
      description: 'Enquiry pipeline, admissions, full student profiles, siblings, documents, and parent linkage — all searchable in one place.'
    },
    {
      icon: 'fact_check',
      title: 'Attendance, Done Daily',
      description: 'Fast per-class marking, staff attendance, and daily operations checks so every absence is noticed the same morning.'
    },
    {
      icon: 'payments',
      title: 'Fees & Finance',
      description: 'Fee structures with multi-installment plans, discounts & waivers, refunds, family ledgers, receipts, and collection dashboards.'
    },
    {
      icon: 'quiz',
      title: 'Examinations & Results',
      description: 'Exam types, schedules, marks entry, and consolidated result cards with grades computed the way your board expects.'
    },
    {
      icon: 'schedule',
      title: 'Timetables & Academics',
      description: 'Classes, sections, subjects, and academic years wired together — plus timetable views per class and teacher.'
    },
    {
      icon: 'badge',
      title: 'Staff & Payroll',
      description: 'Staff directory, designations, departments, payroll runs, and salary slips — from hiring to month-end in one system.'
    },
    {
      icon: 'menu_book',
      title: 'Library & Assets',
      description: 'Catalogue, issue & return tracking, and overdue visibility without a separate library tool.'
    },
    {
      icon: 'directions_bus',
      title: 'Hostel & Transport',
      description: 'Room allocation, hostel rolls, routes, stops, and vehicle records for schools that board and bus their students.'
    },
    {
      icon: 'family_restroom',
      title: 'Parent Portal',
      description: 'Parents see fees, attendance, results, and announcements — reducing front-office phone traffic dramatically.'
    }
  ];

  // Module grid grouped by domain — mirrors the actual navigation of the app
  readonly moduleGroups = [
    {
      group: 'Academic',
      icon: 'school',
      modules: ['Classes & Sections', 'Subjects', 'Academic Years', 'Timetables', 'Examinations', 'Results & Grades', 'Advanced Academics']
    },
    {
      group: 'Finance',
      icon: 'account_balance_wallet',
      modules: ['Fee Structures', 'Installments', 'Collections & Receipts', 'Discounts & Waivers', 'Refunds', 'Family Ledgers', 'Advanced Finance']
    },
    {
      group: 'People',
      icon: 'groups',
      modules: ['Students & Admissions', 'Enquiries', 'Parents', 'Staff Directory', 'Designations', 'Departments', 'Payroll']
    },
    {
      group: 'Campus',
      icon: 'apartment',
      modules: ['Attendance', 'Daily Operations', 'Library', 'Hostels & Rooms', 'Transport Routes & Stops', 'Events', 'Announcements']
    },
    {
      group: 'Administration',
      icon: 'admin_panel_settings',
      modules: ['Users & Roles', 'Granular Permissions', 'Menu Visibility', 'Multi-tenant Isolation', 'Import/Export', 'Audit Logs', 'Backup']
    },
    {
      group: 'Insights',
      icon: 'insights',
      modules: ['Dashboards', 'Analytics', 'Report Generation', 'Fee Dashboards', 'Realtime Notifications', 'Help & Support']
    }
  ];

  readonly pricing = [
    {
      name: 'Free',
      price: '\u20B90',
      period: 'forever',
      tagline: `For schools up to ${this.maxFreeStudents} students`,
      highlight: true,
      cta: 'Get Started Free',
      link: '/register-tenant',
      features: [
        'All 20+ modules included',
        'Unlimited staff & parent accounts',
        'Setup wizard & starter data',
        'Realtime notifications',
        'Data import/export',
        'Community support'
      ]
    },
    {
      name: 'Scale',
      price: 'Custom',
      period: 'annual',
      tagline: `For schools above ${this.maxFreeStudents} students & groups`,
      highlight: false,
      cta: 'Contact Us',
      link: '/register-tenant',
      features: [
        'Everything in Free',
        'Multiple campuses under one group',
        'Priority support & onboarding',
        'Custom reports & integrations',
        'Data migration assistance',
        'Training for your staff'
      ]
    }
  ];

  readonly steps = [
    {
      icon: 'app_registration',
      title: 'Register your school',
      description: 'Create your school workspace in a minute. You receive a unique tenant code — your school lives in its own isolated database tenant.'
    },
    {
      icon: 'account_tree',
      title: 'Run the setup wizard',
      description: 'Academic year, classes, sections, subjects, fee structures, and payment methods — guided step by step, editable later.'
    },
    {
      icon: 'group_add',
      title: 'Invite staff & parents',
      description: 'Assign roles and fine-grained permissions per user. Parents get their portal; staff see exactly what their role allows.'
    }
  ];

  scrollTo(sectionId: string) {
    document.getElementById(sectionId)?.scrollIntoView({ behavior: 'smooth' });
  }

  scrollToTop() {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }
}
