import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnDestroy, OnInit, signal } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { Router, RouterModule, ActivatedRoute } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { TenantService, TenantDto } from '../../services/tenant.service';
import { TenantResolutionService } from '../../services/tenant-resolution.service';

import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatCheckboxModule } from '@angular/material/checkbox';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatProgressSpinnerModule,
    MatCardModule,
    MatButtonModule,
    MatIconModule,
    MatCheckboxModule,

    RouterModule
  ],
  templateUrl: './login.component.html',
  styleUrls: ['./auth-shared.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class LoginComponent implements OnInit, OnDestroy {
  loginForm: FormGroup;
  loading = signal(false);
  error = signal('');
  hidePassword = true;
  rememberMe = signal(false);
  tenants$!: Observable<TenantDto[]>;
  selectedTenantId = signal(0);
  tenantJustCreated = signal(false);
  showTenantCreatedBanner = signal(false);

  // Lockout state (backend enforces 5 failed attempts → 1 minute lock)
  lockoutSeconds = 0;
  private lockoutTimer = signal<any>(null);

  // School code arriving via query params (?tenantCode=…) wins over domain resolution.
  private tenantCodeFromQuery = false;

  constructor(
    private fb: FormBuilder,
    private auth: AuthService, 
    private router: Router,
    private route: ActivatedRoute,
    private tenantService: TenantService,
    public tenantResolution: TenantResolutionService,
    private title: Title,
    private cdr: ChangeDetectorRef
  ) {
    this.loginForm = this.fb.group({
      tenantCode: ['', [Validators.required, Validators.pattern('^[0-9]{6}$')]],
      username: ['', [Validators.required, Validators.minLength(3)]],
      password: ['', [Validators.required, Validators.minLength(6)]]
    });
  }

  ngOnInit() {
    // Load tenants and track selected tenant
    this.tenants$ = this.tenantService.tenants$;
    this.tenantService.loadTenants().subscribe(() => {
      this.cdr.markForCheck();
    });
    this.tenantService.selectedTenant$.subscribe(id => {
      // Defer to next tick to avoid ExpressionChanged errors in dev
      setTimeout(() => {
        this.selectedTenantId.set(id);
        this.cdr.markForCheck();
      });
    });

    // If redirected from tenant registration, honor the provided tenantId
    this.route.queryParamMap.subscribe(params => {
      const tcode = params.get('tenantCode');
      const created = params.get('tenantCreated');
      setTimeout(() => {
        if (tcode) {
          this.tenantCodeFromQuery = true;
          this.loginForm.patchValue({ tenantCode: tcode });
        }
        this.tenantJustCreated.set(created === 'true');
        // Show banner only if created and not dismissed in this session
        const dismissed = (typeof window !== 'undefined' && window.sessionStorage)
          ? sessionStorage.getItem('hideTenantCreatedBanner') === '1'
          : false;
        this.showTenantCreatedBanner.set(this.tenantJustCreated() && !dismissed);
        this.cdr.markForCheck();
      });
    });

    // If user manually switches tenants later, we can keep banner hidden
    // Check if user credentials are remembered
    const rememberedUser = localStorage.getItem('rememberedUser');
    if (rememberedUser) {
      const userData = JSON.parse(rememberedUser);
      this.loginForm.patchValue({
        username: userData.username
      });
      this.rememberMe.set(true);
      this.cdr.markForCheck();
    }

    // ── Tenant resolution + domain binding ──
    // GET /api/auth/resolve-domain (via TenantResolutionService, called once per app)
    // tells the frontend which school this subdomain belongs to: the page then renders
    // that school's branding (name/logo/welcome text) BEFORE showing any brand, and
    // auto-fills the school code for bound hosts. Unknown subdomains show a dedicated
    // "school not found" state instead of the form.
    // Explicit query params (?tenantCode=…) still win over domain resolution.
    if (!this.loginForm.get('tenantCode')?.value) {
      this.tenantResolution.initialize().then(() => {
        const code = this.tenantResolution.schoolCode();
        if (code && !this.tenantCodeFromQuery) {
          this.loginForm.patchValue({ tenantCode: String(code) });
        }
        this.applyTitle();
        this.cdr.markForCheck();
      });
    } else {
      this.tenantResolution.initialize();
    }
  }

  /** Browser tab title reflects the resolved school (no hardcoded school names). */
  private applyTitle() {
    const kind = this.tenantResolution.siteKind();
    if (kind === 'school') {
      this.title.setTitle(`Sign in — ${this.tenantResolution.displayName()}`);
    } else {
      this.title.setTitle('Sign in — AcchaSchool');
    }
  }

  dismissTenantCreatedBanner() {
    this.showTenantCreatedBanner.set(false);
    try {
      if (typeof window !== 'undefined' && window.sessionStorage) {
        sessionStorage.setItem('hideTenantCreatedBanner', '1');
      }
    } catch {}
    this.cdr.markForCheck();
  }

  onTenantChange(id: number) {
    this.selectedTenantId.set(id);
    this.tenantService.setSelectedTenant(id);
    this.cdr.markForCheck();
  }

  login() {
    // Block submit while locked out
    if (this.lockoutSeconds > 0) {
      return;
    }
    if (this.loginForm.invalid) {
      this.markFormGroupTouched();
      this.cdr.markForCheck();
      return;
    }

    setTimeout(() => {
      this.loading.set(true);
      this.cdr.markForCheck();
    });
    this.error.set('');
    
    const formValues = this.loginForm.value;
    const username = String(formValues.username).trim();
    const password = String(formValues.password);
    const tenantCode = String(formValues.tenantCode).trim(); 
    
    if (this.rememberMe()) {
      localStorage.setItem('rememberedUser', JSON.stringify({ username }));
    } else {
      localStorage.removeItem('rememberedUser');
    }

    this.auth.login(username, password, tenantCode).subscribe({
      next: (response) => {
        const resolvedTenantId = response?.user?.tenantId;
        if (resolvedTenantId) {
          this.tenantService.setSelectedTenant(resolvedTenantId);
        }
        setTimeout(() => {
          this.loading.set(false);
          this.cdr.markForCheck();
          this.router.navigate(['/app/dashboard']);
        });
      },
      error: err => {
        setTimeout(() => {
          this.loading.set(false);
          const status = err?.status;

          if (status === 429) {
            // Rate limited: prefer server-provided values, fall back to local parsing
            const serverRetry = err?.error?.retryAfterSeconds ?? Number(err?.headers?.get('Retry-After')) ?? 0;
            const retryAfter = Number(serverRetry) > 0 ? Number(serverRetry) : 60;
            this.startLockoutCountdown(retryAfter);
            this.error.set(err?.error?.message || `Too many failed attempts. Please wait ${retryAfter}s before trying again.`);
          } else if (status === 401) {
            const msg = err?.error?.message;
            if (msg) {
              this.error.set(msg); // e.g. "Invalid username or password. 3 attempts remaining."
            } else {
              this.error.set('Invalid credentials. Please check your username and password.');
            }
          } else {
            const backendMsg = (err?.error?.message) || (Array.isArray(err?.error?.errors) && err.error.errors[0]) || err?.message;
            this.error.set(backendMsg || 'Invalid credentials. Please check your username and password.');
          }
          this.cdr.markForCheck();
        });
      }
    });
  }

  private startLockoutCountdown(seconds: number) {
    this.stopLockoutCountdown();
    this.lockoutSeconds = Math.max(1, Math.ceil(seconds));
    this.loginForm.disable();
    this.lockoutTimer.set(setInterval(() => {
      this.lockoutSeconds--;
      if (this.lockoutSeconds <= 0) {
        this.stopLockoutCountdown();
        this.error.set('');
      }
      this.cdr.markForCheck();
    }, 1000));
  }

  private stopLockoutCountdown() {
    if (this.lockoutTimer()) {
      clearInterval(this.lockoutTimer());
      this.lockoutTimer.set(null);
    }
    this.lockoutSeconds = 0;
    this.loginForm.enable();
  }

  ngOnDestroy() {
    this.stopLockoutCountdown();
  }

  togglePasswordVisibility() {
    this.hidePassword = !this.hidePassword;
    this.cdr.markForCheck();
  }

  private markFormGroupTouched() {
    Object.keys(this.loginForm.controls).forEach(key => {
      const control = this.loginForm.get(key);
      control?.markAsTouched();
    });
  }

  getErrorMessage(fieldName: string): string {
    const control = this.loginForm.get(fieldName);
    if (control?.hasError('required')) {
      return `${this.capitalize(fieldName)} is required`;
    }
    if (control?.hasError('minlength')) {
      const minLength = control.errors?.['minlength']?.requiredLength;
      return `${this.capitalize(fieldName)} must be at least ${minLength} characters`;
    }
    return '';
  }

  private capitalize(str: string): string {
    return str.charAt(0).toUpperCase() + str.slice(1);
  }
}
