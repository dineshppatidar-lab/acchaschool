import { ChangeDetectorRef, Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, Validators, ReactiveFormsModule, FormGroup } from '@angular/forms';
import { Router, RouterModule, ActivatedRoute } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';

@Component({
  selector: 'app-reset-password',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule,
    MatProgressSpinnerModule
  ],
  templateUrl: './reset-password.component.html',
  styleUrls: ['./auth-shared.scss']
})
export class ResetPasswordComponent implements OnInit {
  resetForm: FormGroup;
  token = signal('');
  loading = signal(false);
  error = signal('');
  resetSuccess = signal(false);
  invalidToken = signal(false);
  hidePassword = true;
  hideConfirmPassword = true;

  // Password strength
  passwordStrength = signal(0);
  passwordStrengthLabel = signal('');
  passwordStrengthColor = signal('');
  showPasswordStrength = signal(false);

  // Password match
  passwordsMatch = false;

  constructor(
    private fb: FormBuilder,
    private http: HttpClient,
    private router: Router,
    private route: ActivatedRoute,
    private cdr: ChangeDetectorRef
  ) {
    this.resetForm = this.fb.group({
      newPassword: ['', [Validators.required, Validators.minLength(8)]],
      confirmPassword: ['', [Validators.required]]
    }, { validators: this.passwordMatchValidator });

    // Watch passwords for match
    this.resetForm.get('newPassword')?.valueChanges.subscribe(() => {
      this.updatePasswordMatch();
      this.cdr.markForCheck();
    });
    this.resetForm.get('confirmPassword')?.valueChanges.subscribe(() => {
      this.updatePasswordMatch();
      this.cdr.markForCheck();
    });
  }

  ngOnInit(): void {
    this.route.queryParamMap.subscribe(params => {
      this.token.set(params.get('token') || '');
      if (!this.token()) {
        this.invalidToken.set(true);
        this.cdr.markForCheck();
      }
    });
  }

  passwordMatchValidator(group: FormGroup): { [key: string]: boolean } | null {
    const password = group.get('newPassword');
    const confirmPassword = group.get('confirmPassword');
    return password && confirmPassword && password.value === confirmPassword.value ? null : { passwordMismatch: true };
  }

  private updatePasswordMatch(): void {
    const pw = this.resetForm.get('newPassword')?.value || '';
    const cpw = this.resetForm.get('confirmPassword')?.value || '';
    this.passwordsMatch = pw.length > 0 && cpw.length > 0 && pw === cpw;
  }

  onPasswordInput(): void {
    const pw = this.resetForm.get('newPassword')?.value || '';
    this.showPasswordStrength.set(pw.length > 0);
    this.calculatePasswordStrength(pw);
    this.cdr.markForCheck();
  }

  private calculatePasswordStrength(password: string): void {
    let score = 0;
    if (password.length >= 8) score++;
    if (password.length >= 10) score++;
    if (/[A-Z]/.test(password)) score++;
    if (/[0-9]/.test(password)) score++;
    if (/[^A-Za-z0-9]/.test(password)) score++;

    if (score <= 1) {
      this.passwordStrength.set(1);
      this.passwordStrengthLabel.set('Weak');
      this.passwordStrengthColor.set('#f44336');
    } else if (score === 2) {
      this.passwordStrength.set(2);
      this.passwordStrengthLabel.set('Fair');
      this.passwordStrengthColor.set('#ff9800');
    } else if (score === 3) {
      this.passwordStrength.set(3);
      this.passwordStrengthLabel.set('Good');
      this.passwordStrengthColor.set('#4caf50');
    } else {
      this.passwordStrength.set(4);
      this.passwordStrengthLabel.set('Strong');
      this.passwordStrengthColor.set('#2e7d32');
    }
  }

  submit(): void {
    if (this.resetForm.invalid) {
      this.resetForm.markAllAsTouched();
      return;
    }

    this.scheduleUI(() => {
      this.loading.set(true);
      this.error.set('');
    });

    const { newPassword, confirmPassword } = this.resetForm.value;

    this.http.post<any>('/api/auth/reset-password', {
      token: this.token(),
      newPassword,
      confirmPassword
    }).subscribe({
      next: (res) => {
        this.scheduleUI(() => {
          this.loading.set(false);
          if (res?.success) {
            this.resetSuccess.set(true);
          } else {
            this.error.set(res?.message || 'Failed to reset password.');
          }
        });
      },
      error: (err) => {
        this.scheduleUI(() => {
          this.loading.set(false);
          const msg = err?.error?.message || err?.message || 'Failed to reset password.';
          if (msg.toLowerCase().includes('expired') || msg.toLowerCase().includes('invalid')) {
            this.invalidToken.set(true);
          } else {
            this.error.set(msg);
          }
        });
      }
    });
  }

  goToLogin(): void {
    this.router.navigate(['/login']);
  }

  private scheduleUI(fn: () => void): void {
    // Zoneless: an explicit pass keeps legacy non-signal UI state in sync.
    setTimeout(() => {
      fn();
      try { this.cdr.detectChanges(); } catch {}
    }, 0);
  }
}
