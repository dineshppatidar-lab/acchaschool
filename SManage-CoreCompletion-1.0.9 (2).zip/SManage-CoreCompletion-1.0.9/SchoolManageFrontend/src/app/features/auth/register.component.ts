import { ChangeDetectorRef, Component, OnInit, signal } from '@angular/core';
import { Router, RouterModule, ActivatedRoute } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule, FormsModule, AbstractControl, ValidationErrors } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatDividerModule } from '@angular/material/divider';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSelectModule } from '@angular/material/select';
import { MatStepperModule } from '@angular/material/stepper';
import { CommonModule } from '@angular/common';
import { TenantService, TenantDto } from '../../services/tenant.service';
import { MasterDataService } from '../../services/master-data.service';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatCardModule,
    MatIconModule,
    MatCheckboxModule,
    MatDividerModule,
    MatProgressSpinnerModule,
    MatSelectModule,
    MatStepperModule,
    RouterModule
  ],
  templateUrl: './register.component.html',
  styleUrls: ['./auth-shared.scss', './register.component.scss']
})
export class RegisterComponent implements OnInit {
  registerForm: FormGroup;
  loading = signal(false);
  error = signal('');
  success = signal('');
  hidePassword = true;
  hideConfirmPassword = true;
  termsAccepted = false;

  userRoles$!: Observable<any[]>;
  userTypes = signal<any[]>([]);

  /** Role-card selection (mobile-first register design). */
  selectRole(value: any) {
    const roleControl = this.registerForm.get('userType');
    if (!roleControl) return;
    roleControl.setValue(value);
    roleControl.markAsTouched();
    roleControl.updateValueAndValidity();
  }

  constructor(
    private fb: FormBuilder,
    public auth: AuthService,
    private router: Router,
    private route: ActivatedRoute,
    private tenantService: TenantService,
    private cdr: ChangeDetectorRef,
    private masterDataService: MasterDataService
  ) {
    this.registerForm = this.fb.group({
  tenantId: [null, [Validators.required, Validators.min(1)]],
      firstName: ['', [Validators.required, Validators.minLength(2)]],
      lastName: ['', [Validators.required, Validators.minLength(2)]],
      username: ['', [Validators.required, Validators.minLength(3), Validators.pattern(/^[a-zA-Z0-9_]+$/)]],
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(8), this.passwordValidator]],
      confirmPassword: ['', Validators.required],
      userType: ['student', Validators.required],
      phone: ['', [Validators.pattern(/^[0-9]{10}$/)]]
    }, { validators: this.passwordMatchValidator });
  }

  ngOnInit() {
    this.userRoles$ = this.masterDataService.getUserRoles();
    this.userRoles$.subscribe(roles => {
      this.userTypes.set(roles || []);
    });
    // Keep branding in sync and optionally prefill tenant if available
    this.tenantService.selectedTenant$.subscribe(id => {
      this.scheduleUI(() => {
        if (id && id > 0) {
          this.registerForm.patchValue({ tenantId: id });
        }
      });
    });

    // Allow tenant pre-selection by query parameter (e.g., /register?tenantId=2)
    this.route.queryParamMap.subscribe(params => {
      const tid = params.get('tenantId');
      if (tid && !isNaN(+tid)) {
        const tenantId = +tid;
        this.registerForm.patchValue({ tenantId });
      }
    });
  }

  // Custom password validator
  passwordValidator(control: AbstractControl): ValidationErrors | null {
    const value = control.value;
    if (!value) {
      return null;
    }

    const hasNumber = /[0-9]/.test(value);
    const hasUpper = /[A-Z]/.test(value);
    const hasLower = /[a-z]/.test(value);
    const hasSpecial = /[#?!@$%^&*-]/.test(value);

    const passwordValid = hasNumber && hasUpper && hasLower && hasSpecial;

    return !passwordValid ? { passwordStrength: true } : null;
  }

  // tenant selection is manual via tenantId input in Option A
  onTenantChange(id: number) {
    this.tenantService.setSelectedTenant(id);
  }

  // Password match validator
  passwordMatchValidator(group: AbstractControl): ValidationErrors | null {
    const password = group.get('password');
    const confirmPassword = group.get('confirmPassword');

    if (!password || !confirmPassword) {
      return null;
    }

    return password.value === confirmPassword.value ? null : { passwordMismatch: true };
  }

  register() {
    if (this.registerForm.invalid) {
      this.markFormGroupTouched();
      return;
    }

    if (!this.termsAccepted) {
      this.scheduleUI(() => {
        this.error.set('Please accept the terms and conditions');
      });
      return;
    }

    // Defer UI state changes to avoid ExpressionChangedAfterItHasBeenCheckedError
    this.scheduleUI(() => {
      this.loading.set(true);
      this.error.set('');
      this.success.set('');
    });
    
    const { firstName, lastName, username, email, password, confirmPassword, userType, phone } = this.registerForm.value;
    const storedTenantId = (typeof window !== 'undefined' && window.localStorage)
      ? Number(localStorage.getItem('tenantId') || 0)
      : 0;
    const tenantId = Number(this.registerForm.value?.tenantId || storedTenantId || 1);
    
    const registerData = {
      firstName,
      lastName,
      username,
      email,
      password,
      confirmPassword,
      userType,
      phone: phone || '',
      acceptedTerms: this.termsAccepted
    };
    
    if (!environment.production) {
      console.debug('[RegisterComponent] Submitting registration for', username);
    }
  this.auth.register(registerData, tenantId).subscribe({
      next: (res: any) => {
        if (!environment.production) {
          console.debug('[RegisterComponent] Registration success:', res);
        }
        this.scheduleUI(() => {
          this.loading.set(false);
          this.success.set(this.auth.isAuthenticated() 
            ? 'User registered successfully!' 
            : 'Registration successful! You can now sign in with your credentials.');
          
          // Navigate after a short pause
          setTimeout(() => {
            if (this.auth.isAuthenticated()) {
              this.router.navigate(['/app/admin/user-management']);
            } else {
              this.router.navigate(['/login'], { 
                queryParams: { registered: 'true', username: username }
              });
            }
          }, 1200);
        });
      },
      error: (err: any) => {
        if (!environment.production) {
          console.error('[RegisterComponent] Registration error:', err);
        }
        this.scheduleUI(() => {
          this.loading.set(false);
          const backendMsg = (err?.error?.message) || (Array.isArray(err?.error?.errors) && err.error.errors[0]) || err?.message;
          this.error.set(backendMsg || 'Registration failed. Please try again.');
        });
      }
    });
  }

  togglePasswordVisibility() {
    this.hidePassword = !this.hidePassword;
  }

  toggleConfirmPasswordVisibility() {
    this.hideConfirmPassword = !this.hideConfirmPassword;
  }

  onTermsChange() {
    this.scheduleUI(() => {
      this.termsAccepted = !this.termsAccepted;
    });
  }

  private markFormGroupTouched() {
    Object.keys(this.registerForm.controls).forEach(key => {
      const control = this.registerForm.get(key);
      control?.markAsTouched();
    });
  }

  getErrorMessage(fieldName: string): string {
    const control = this.registerForm.get(fieldName);
    if (control?.hasError('required')) {
      return `${this.capitalize(fieldName)} is required`;
    }
    if (control?.hasError('minlength')) {
      const minLength = control.errors?.['minlength']?.requiredLength;
      return `${this.capitalize(fieldName)} must be at least ${minLength} characters`;
    }
    if (control?.hasError('email')) {
      return 'Please enter a valid email address';
    }
    if (control?.hasError('pattern')) {
      if (fieldName === 'username') {
        return 'Username can only contain letters, numbers, and underscores';
      }
      if (fieldName === 'phone') {
        return 'Please enter a valid 10-digit phone number';
      }
    }
    if (control?.hasError('passwordStrength')) {
      return 'Password must contain uppercase, lowercase, number, and special character';
    }
    if (fieldName === 'confirmPassword' && this.registerForm.hasError('passwordMismatch')) {
      return 'Passwords do not match';
    }
    return '';
  }

  private capitalize(str: string): string {
    return str.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase());
  }

  getPasswordStrength(): { strength: string; color: string; width: string } {
    const password = this.registerForm.get('password')?.value || '';
    let score = 0;
    
    if (password.length >= 8) score++;
    if (/[a-z]/.test(password)) score++;
    if (/[A-Z]/.test(password)) score++;
    if (/[0-9]/.test(password)) score++;
    if (/[#?!@$%^&*-]/.test(password)) score++;

    if (score < 2) return { strength: 'Weak', color: '#f44336', width: '20%' };
    if (score < 4) return { strength: 'Fair', color: '#ff9800', width: '50%' };
    if (score < 5) return { strength: 'Good', color: '#2196f3', width: '75%' };
    return { strength: 'Strong', color: '#4caf50', width: '100%' };
  }

  private scheduleUI(fn: () => void) {
    // Schedule changes to avoid NG0100 in dev mode; zoneless: explicit CD pass after updates
    setTimeout(() => {
      fn();
      try { this.cdr.detectChanges(); } catch {}
    }, 0);
  }
}
