import { ChangeDetectorRef, Component, OnDestroy, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, Validators, ReactiveFormsModule, FormGroup } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';

@Component({
  selector: 'app-forgot-password',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule,
    MatProgressSpinnerModule
  ],
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./auth-shared.scss']
})
export class ForgotPasswordComponent implements OnDestroy {
  forgotForm: FormGroup;
  loading = signal(false);
  error = signal('');
  submitted = signal(false);
  submittedEmail = signal('');
  resendCooldown = signal(false);
  cooldownSeconds = 60;
  private cooldownTimer = signal<any>(null);

  constructor(
    private fb: FormBuilder,
    private http: HttpClient,
    private router: Router,
    private cdr: ChangeDetectorRef
  ) {
    this.forgotForm = this.fb.group({
      schoolCode: ['', [Validators.required, Validators.pattern('^[0-9]{6}$')]],
      email: ['', [Validators.required, Validators.email]]
    });
  }

  ngOnDestroy(): void {
    this.clearCooldown();
  }

  private clearCooldown(): void {
    if (this.cooldownTimer()) {
      clearInterval(this.cooldownTimer());
      this.cooldownTimer.set(null);
    }
  }

  submit(): void {
    if (this.forgotForm.invalid) {
      this.forgotForm.markAllAsTouched();
      return;
    }

    this.scheduleUI(() => {
      this.loading.set(true);
      this.error.set('');
    });

    const { schoolCode, email } = this.forgotForm.value;

    this.http.post<any>('/api/auth/forgot-password', { schoolCode, email }).subscribe({
      next: (res) => {
        this.scheduleUI(() => {
          this.loading.set(false);
          if (res?.success) {
            this.submitted.set(true);
            this.submittedEmail.set(email);
            this.startCooldown();
          } else {
            this.error.set(res?.message || 'Something went wrong. Please try again.');
          }
        });
      },
      error: (err) => {
        this.scheduleUI(() => {
          this.loading.set(false);
          this.error.set(err?.error?.message || 'Failed to send reset link. Please try again.');
        });
      }
    });
  }

  resetForm(): void {
    this.submitted.set(false);
    this.error.set('');
    this.forgotForm.reset();
    this.clearCooldown();
    this.resendCooldown.set(false);
    this.cdr.markForCheck();
  }

  private startCooldown(): void {
    this.resendCooldown.set(true);
    this.cooldownSeconds = 60;
    this.cooldownTimer.set(setInterval(() => {
      this.cooldownSeconds--;
      this.cdr.markForCheck();
      if (this.cooldownSeconds <= 0) {
        this.clearCooldown();
        this.resendCooldown.set(false);
        this.cdr.markForCheck();
      }
    }, 1000));
  }

  private scheduleUI(fn: () => void): void {
    // Zoneless: an explicit pass keeps legacy non-signal UI state in sync.
    setTimeout(() => {
      fn();
      try { this.cdr.detectChanges(); } catch {}
    }, 0);
  }
}
