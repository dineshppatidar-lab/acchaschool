import { ChangeDetectorRef, Component, OnDestroy, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, Validators, FormsModule, ReactiveFormsModule, FormGroup, AbstractControl, ValidationErrors } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { TenantService } from '../../services/tenant.service';
import { environment } from '../../../environments/environment';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-tenant-register',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatCardModule,
    MatCheckboxModule,
    MatProgressSpinnerModule,
    MatIconModule
  ],
  templateUrl: './tenant-register.component.html',
  styleUrls: ['./auth-shared.scss']
})
export class TenantRegisterComponent implements OnDestroy {
  loading = signal(false);
  error = signal('');
  success = signal('');
  hidePassword = true;
  hideConfirmPassword = true;

  // Registration success state
  registrationComplete = signal(false);
  registeredSchoolCode = signal('');
  registeredSchoolName = signal('');
  registeredEmail = signal('');
  emailSent = signal(false);
  countdown = signal(8);
  countdownTimer = signal<any>(null);

  // Password strength
  passwordStrength = 0; // 0-4: none, weak, fair, good, strong
  passwordStrengthLabel = signal('');
  passwordStrengthColor = signal('');
  showPasswordStrength = signal(false);

  // Password match
  passwordsMatch = false;

  form: FormGroup;

  constructor(
    private fb: FormBuilder,
    private tenantService: TenantService,
    private router: Router,
    private cdr: ChangeDetectorRef
  ) {
    this.form = this.fb.group({
      tenantName: ['', [Validators.required, Validators.minLength(3)]],
      subdomain: ['', [Validators.pattern(/^[a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?$/)]],
      adminUsername: ['', [Validators.required, Validators.minLength(3)]],
      adminEmail: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(8), this.passwordStrengthValidator]],
      confirmPassword: ['', [Validators.required]],
      acceptedTerms: [false, [Validators.requiredTrue]]
    }, { validators: this.passwordMatchValidator });

    // Watch password and confirmPassword for match & strength
    this.form.get('password')?.valueChanges.subscribe(() => {
      this.updatePasswordMatch();
      this.cdr.markForCheck();
    });
    this.form.get('confirmPassword')?.valueChanges.subscribe(() => {
      this.updatePasswordMatch();
      this.cdr.markForCheck();
    });
  }

  passwordStrengthValidator(control: AbstractControl): ValidationErrors | null {
    const value = control.value;
    if (!value) return null;
    const hasUpper = /[A-Z]/.test(value);
    const hasLower = /[a-z]/.test(value);
    const hasNumber = /[0-9]/.test(value);
    const hasSpecial = /[#?!@$%^&*-]/.test(value);
    const isValid = hasUpper && hasLower && hasNumber && hasSpecial;
    return !isValid ? { passwordStrength: true } : null;
  }

  passwordMatchValidator(group: AbstractControl): ValidationErrors | null {
    const password = group.get('password');
    const confirmPassword = group.get('confirmPassword');
    return password && confirmPassword && password.value === confirmPassword.value ? null : { passwordMismatch: true };
  }

  private updatePasswordMatch(): void {
    const pw = this.form.get('password')?.value || '';
    const cpw = this.form.get('confirmPassword')?.value || '';
    this.passwordsMatch = pw.length > 0 && cpw.length > 0 && pw === cpw;
  }

  togglePasswordVisibility(): void {
    this.hidePassword = !this.hidePassword;
    this.cdr.markForCheck();
  }

  toggleConfirmPasswordVisibility(): void {
    this.hideConfirmPassword = !this.hideConfirmPassword;
    this.cdr.markForCheck();
  }

  onPasswordFocus(): void {
    const pw = this.form.get('password')?.value || '';
    this.showPasswordStrength.set(pw.length > 0);
    this.cdr.markForCheck();
  }

  onPasswordBlur(): void {
    const pw = this.form.get('password')?.value || '';
    this.showPasswordStrength.set(pw.length > 0);
    this.cdr.markForCheck();
  }

  onPasswordInput(): void {
    const pw = this.form.get('password')?.value || '';
    this.showPasswordStrength.set(pw.length > 0);
    this.calculatePasswordStrength(pw);
    this.cdr.markForCheck();
  }

  private calculatePasswordStrength(password: string): void {
    let score = 0;
    if (password.length >= 8) score++;
    if (password.length >= 10) score++;
    if (/[A-Z]/.test(password)) score++;
    if (/[0-9]/.test(password)) score++;
    if (/[^A-Za-z0-9]/.test(password)) score++;

    if (score <= 1) {
      this.passwordStrength = 1;
      this.passwordStrengthLabel.set('Weak');
      this.passwordStrengthColor.set('#f44336');
    } else if (score === 2) {
      this.passwordStrength = 2;
      this.passwordStrengthLabel.set('Fair');
      this.passwordStrengthColor.set('#ff9800');
    } else if (score === 3) {
      this.passwordStrength = 3;
      this.passwordStrengthLabel.set('Good');
      this.passwordStrengthColor.set('#4caf50');
    } else {
      this.passwordStrength = 4;
      this.passwordStrengthLabel.set('Strong');
      this.passwordStrengthColor.set('#2e7d32');
    }
  }

  ngOnDestroy(): void {
    this.clearCountdown();
  }

  private clearCountdown(): void {
    if (this.countdownTimer()) {
      clearInterval(this.countdownTimer());
      this.countdownTimer.set(null);
    }
  }

  copySchoolCode(): void {
    if (this.registeredSchoolCode() && typeof navigator !== 'undefined' && navigator.clipboard) {
      navigator.clipboard.writeText(this.registeredSchoolCode()).then(() => {
        this.success.set('School code copied to clipboard!');
        this.cdr.markForCheck();
        setTimeout(() => {
          if (this.registrationComplete()) {
            this.success.set(this.emailSent()
              ? `Welcome email sent to ${this.registeredEmail()}`
              : 'School registered! Please note your school code below.');
            this.cdr.markForCheck();
          }
        }, 2000);
      });
    }
  }

  /** Platform root domain shown as a suffix chip behind the subdomain input. */
  readonly schoolBaseDomain = environment.baseDomain;

  isFullHostname(): boolean {
    const v = String(this.form.get('subdomain')?.value ?? '').trim();
    return v.includes('.');
  }

  subdomainLabel(): string {
    return String(this.form.get('subdomain')?.value ?? '').trim().toLowerCase();
  }

  goToLogin(): void {
    this.clearCountdown();
    this.router.navigate(['/login'], {
      queryParams: { tenantCreated: 'true', tenantCode: this.registeredSchoolCode() }
    });
  }

  submit() {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      this.error.set('Please correct the errors before submitting.');
      return;
    }

    // Build the request with a full domain: bare labels become <label>.<baseDomain>
    // (the school's future URL, e.g. greenfield.acchaschool.com); values that already
    // look like a full hostname (a dot) are sent as-is (custom-domain case).
    // Reserved platform subdomains (www/api/login/…) are rejected by the backend.
    const v = this.form.value;
    const sub = String(v.subdomain ?? '').trim().toLowerCase();
    const baseDomain = environment.baseDomain;
    const domain = !sub
      ? undefined
      : sub.includes('.') ? sub : `${sub}.${baseDomain}`;
    const payload = {
      tenantName: v.tenantName,
      domain,
      adminUsername: v.adminUsername,
      adminEmail: v.adminEmail,
      password: v.password,
      confirmPassword: v.confirmPassword,
      acceptedTerms: v.acceptedTerms
    };

    this.scheduleUI(() => {
      this.loading.set(true);
      this.error.set('');
      this.success.set('');
    });

    this.tenantService.registerClient(payload).subscribe({
      next: (res) => {
        this.scheduleUI(() => {
          this.loading.set(false);
          const data = res?.data ?? res;
          this.registeredSchoolCode.set(data?.tenantCode ?? data?.TenantCode ?? '');
          this.registeredSchoolName.set(data?.tenantName ?? data?.TenantName ?? '');
          this.registeredEmail.set(data?.adminEmail ?? data?.AdminEmail ?? '');
          this.emailSent.set(data?.emailSent ?? data?.EmailSent ?? false);
          this.registrationComplete.set(true);

          if (this.emailSent()) {
            this.success.set(`Welcome email sent to ${this.registeredEmail()}`);
          } else {
            this.success.set('School registered! Please note your school code below.');
          }

          // Pre-select the newly created tenant on the login page
          if (this.registeredSchoolCode() && typeof window !== 'undefined' && window.localStorage) {
            try {
              localStorage.setItem('tenantCode', this.registeredSchoolCode());
            } catch {}
          }

          // Start countdown
          this.countdown.set(8);
          this.countdownTimer.set(setInterval(() => {
            this.countdown.update(v => v - 1);
            this.cdr.markForCheck();
            if (this.countdown() <= 0) {
              this.goToLogin();
            }
          }, 1000));
        });
      },
      error: (err) => {
        this.scheduleUI(() => {
          this.loading.set(false);
          this.error.set(err?.error?.message || 'Registration failed. Please try again.');
        });
      }
    });
  }

  private scheduleUI(fn: () => void) {
    // Zoneless: an explicit pass keeps legacy non-signal UI state in sync.
    setTimeout(() => {
      fn();
      try { this.cdr.detectChanges(); } catch {}
    }, 0);
  }
}
