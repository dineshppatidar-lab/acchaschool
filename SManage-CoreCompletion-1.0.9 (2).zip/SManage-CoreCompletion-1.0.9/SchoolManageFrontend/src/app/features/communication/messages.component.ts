import { AfterViewInit, ChangeDetectorRef, Component, OnInit, ViewChild, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatTableModule, MatTableDataSource } from '@angular/material/table';
import { MatPaginatorModule, MatPaginator } from '@angular/material/paginator';
import { MatSortModule, MatSort } from '@angular/material/sort';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatDialogModule, MatDialog } from '@angular/material/dialog';
import { MatSnackBarModule, MatSnackBar } from '@angular/material/snack-bar';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatCardModule } from '@angular/material/card';
import { MatChipsModule } from '@angular/material/chips';
import { MatMenuModule } from '@angular/material/menu';
import { MatDividerModule } from '@angular/material/divider';
import { MatTooltipModule } from '@angular/material/tooltip';
import { CommunicationService, Message } from '../../services/communication.service';
import { CanWriteDirective, CanDeleteDirective } from '../../core/directives/permission.directive';
import { Permission } from '../../core/models/permission.model';
import { DialogUtils } from '../../shared/dialog-utils';
import { PageHeaderComponent, KpiCardComponent } from '../../shared/components/page-patterns/index';

// Extended Message interface with status
interface MessageWithStatus extends Message {
  status?: string;
}

@Component({
  selector: 'app-messages',
  standalone: true,
  imports: [
    CommonModule, FormsModule, MatTableModule, MatPaginatorModule, MatSortModule,
    MatButtonModule, MatIconModule, MatDialogModule, MatSnackBarModule,
    MatFormFieldModule, MatInputModule, MatSelectModule, MatCardModule,
    MatChipsModule, MatMenuModule, MatDividerModule, MatTooltipModule,
    CanWriteDirective, CanDeleteDirective, PageHeaderComponent, KpiCardComponent
  ],
  template: `
    <div class="messages-container">
      <!-- Page Header -->
      <app-page-header
        title="Messages"
        subtitle="Manage and send messages to students, parents, and staff">
        <button headerActions mat-raised-button color="primary" (click)="composeMessage()" *appCanWrite="Permission.MessagesSend">
          <mat-icon>edit</mat-icon>
          Compose
        </button>
        <button headerActions mat-stroked-button color="primary" (click)="sendBulkMessage()" *appCanWrite="Permission.MessagesSend">
          <mat-icon>send</mat-icon>
          Bulk Send
        </button>
        <button headerActionsEnd mat-stroked-button (click)="markAllAsRead()">
          <mat-icon>mark_email_read</mat-icon>
          Mark Read
        </button>
      </app-page-header>

      <!-- Quick Stats -->
      <div class="stu-kpi-grid">
        <app-kpi-card icon="inbox" tone="primary" [value]="totalMessages()" label="Total Messages" />
        <app-kpi-card icon="mark_email_unread" tone="warn" [value]="unreadMessagesCount()" label="Unread" />
        <app-kpi-card icon="today" tone="success" [value]="todaysMessages()" label="Sent Today" />
      </div>      <!-- Search & Filters -->
      <div class="stu-filter-bar">
        <div class="sfe-row">
          <mat-form-field appearance="outline" subscriptSizing="dynamic" class="sfe-search">
            <mat-label>Search messages</mat-label>
            <input matInput [(ngModel)]="messageSearchTerm" (ngModelChange)="searchMessages()"
                   placeholder="Subject or content..." autocomplete="off">
            <mat-icon matPrefix>search</mat-icon>
            <button *ngIf="messageSearchTerm" matSuffix mat-icon-button (click)="messageSearchTerm = ''; loadMessages()">
              <mat-icon>close</mat-icon>
            </button>
          </mat-form-field>

          <mat-form-field appearance="outline" subscriptSizing="dynamic" class="sfe-field">
            <mat-label>Type</mat-label>
            <mat-select [(value)]="messageTypeFilter" (selectionChange)="filterMessages()">
              <mat-option value="">All Types</mat-option>
              <mat-option value="General">General</mat-option>
              <mat-option value="Academic">Academic</mat-option>
              <mat-option value="Administrative">Administrative</mat-option>
              <mat-option value="Emergency">Emergency</mat-option>
            </mat-select>
          </mat-form-field>

          <mat-form-field appearance="outline" subscriptSizing="dynamic" class="sfe-field">
            <mat-label>Status</mat-label>
            <mat-select [(value)]="messageStatusFilter" (selectionChange)="filterMessages()">
              <mat-option value="">All Status</mat-option>
              <mat-option value="Sent">Sent</mat-option>
              <mat-option value="Delivered">Delivered</mat-option>
              <mat-option value="Read">Read</mat-option>
              <mat-option value="Failed">Failed</mat-option>
            </mat-select>
          </mat-form-field>
        </div>
      </div>

      <!-- Messages List (Mobile Card View) -->
      <div class="messages-list">
        <div *ngFor="let message of messageDataSource.data" class="message-card" (click)="viewMessage(message)">
          <div class="message-status-bar" [class]="'status-' + (message.status || 'sent').toLowerCase()"></div>
          <div class="message-content">
            <div class="message-header">
              <div class="message-subject" [class.unread]="!message.isRead">
                {{ message.subject }}
              </div>
              <mat-chip [color]="getPriorityColor(message.priority)" size="small" class="priority-chip">
                {{ message.priority }}
              </mat-chip>
            </div>
            <div class="message-preview">{{ getMessagePreview(message.content) }}</div>
            <div class="message-meta">
              <span class="sender">
                <mat-icon>person</mat-icon>
                {{ message.senderName }}
              </span>
              <span class="date">
                <mat-icon>schedule</mat-icon>
                {{ message.sentDate | date:'short' }}
              </span>
            </div>
          </div>
          <div class="message-actions">
            <button mat-icon-button [matMenuTriggerFor]="messageMenu" (click)="$event.stopPropagation()">
              <mat-icon>more_vert</mat-icon>
            </button>
            <mat-menu #messageMenu="matMenu">
              <button mat-menu-item (click)="editMessage(message)" *appCanWrite="Permission.MessagesSend">
                <mat-icon>edit</mat-icon><span>Edit</span>
              </button>
              <button mat-menu-item (click)="replyToMessage(message)" *appCanWrite="Permission.MessagesSend">
                <mat-icon>reply</mat-icon><span>Reply</span>
              </button>
              <button mat-menu-item (click)="forwardMessage(message)" *appCanWrite="Permission.MessagesSend">
                <mat-icon>forward</mat-icon><span>Forward</span>
              </button>
              <mat-divider *appCanDelete="Permission.MessagesSend"></mat-divider>
              <button mat-menu-item (click)="deleteMessage(message.id)" class="warn-item" *appCanDelete="Permission.MessagesSend">
                <mat-icon>delete</mat-icon><span>Delete</span>
              </button>
            </mat-menu>
          </div>
        </div>

        <!-- Empty State -->
        <div *ngIf="messageDataSource.data.length === 0" class="stu-state">
          <mat-icon class="stu-state-icon">mail_outline</mat-icon>
          <h3 class="stu-state-title">No messages found</h3>
          <p class="stu-state-text">Start a conversation by composing a new message</p>
          <div class="stu-state-action">
            <button mat-raised-button color="primary" (click)="composeMessage()">
              <mat-icon>edit</mat-icon>Compose Message
            </button>
          </div>
        </div>
      </div>

      <!-- Desktop Table View (hidden on mobile) -->
      <div class="desktop-table">
        <mat-table [dataSource]="messageDataSource" matSort #messageSort="matSort">
          <ng-container matColumnDef="status">
            <mat-header-cell *matHeaderCellDef>Status</mat-header-cell>
            <mat-cell *matCellDef="let message">
              <mat-icon [class]="'status-icon ' + getStatusClass(message.status)">
                {{ getStatusIcon(message.status) }}
              </mat-icon>
            </mat-cell>
          </ng-container>

          <ng-container matColumnDef="priority">
            <mat-header-cell *matHeaderCellDef>Priority</mat-header-cell>
            <mat-cell *matCellDef="let message">
              <mat-chip [color]="getPriorityColor(message.priority)" size="small">
                {{ message.priority }}
              </mat-chip>
            </mat-cell>
          </ng-container>

          <ng-container matColumnDef="subject">
            <mat-header-cell *matHeaderCellDef mat-sort-header>Subject</mat-header-cell>
            <mat-cell *matCellDef="let message">
              <div [class.unread]="!message.isRead">{{ message.subject }}</div>
            </mat-cell>
          </ng-container>

          <ng-container matColumnDef="sender">
            <mat-header-cell *matHeaderCellDef>Sender</mat-header-cell>
            <mat-cell *matCellDef="let message">{{ message.senderName }}</mat-cell>
          </ng-container>

          <ng-container matColumnDef="sentDate">
            <mat-header-cell *matHeaderCellDef mat-sort-header>Date</mat-header-cell>
            <mat-cell *matCellDef="let message">{{ message.sentDate | date:'short' }}</mat-cell>
          </ng-container>

          <ng-container matColumnDef="actions">
            <mat-header-cell *matHeaderCellDef>Actions</mat-header-cell>
            <mat-cell *matCellDef="let message">
              <button mat-icon-button color="primary" (click)="viewMessage(message)">
                <mat-icon>visibility</mat-icon>
              </button>
              <button mat-icon-button [matMenuTriggerFor]="desktopMenu">
                <mat-icon>more_vert</mat-icon>
              </button>
              <mat-menu #desktopMenu="matMenu">
                <button mat-menu-item (click)="editMessage(message)" *appCanWrite="Permission.MessagesSend">
                  <mat-icon>edit</mat-icon><span>Edit</span>
                </button>
                <button mat-menu-item (click)="replyToMessage(message)" *appCanWrite="Permission.MessagesSend">
                  <mat-icon>reply</mat-icon><span>Reply</span>
                </button>
                <button mat-menu-item (click)="forwardMessage(message)" *appCanWrite="Permission.MessagesSend">
                  <mat-icon>forward</mat-icon><span>Forward</span>
                </button>
                <mat-divider *appCanDelete="Permission.MessagesSend"></mat-divider>
                <button mat-menu-item (click)="deleteMessage(message.id)" *appCanDelete="Permission.MessagesSend">
                  <mat-icon>delete</mat-icon><span>Delete</span>
                </button>
              </mat-menu>
            </mat-cell>
          </ng-container>

          <mat-header-row *matHeaderRowDef="displayedColumns"></mat-header-row>
          <mat-row *matRowDef="let row; columns: displayedColumns;" (click)="viewMessage(row)"></mat-row>
        </mat-table>
        <mat-paginator [pageSizeOptions]="[10, 25, 50]" showFirstLastButtons></mat-paginator>
      </div>
    </div>
  `,
  styles: [`
    .messages-container {
      padding: 16px;
      min-height: 100vh;
      background: var(--md-surface-container-low);
    }

    .page-header {
      margin-bottom: 20px;
    }

    .header-content {
      display: flex;
      align-items: center;
      justify-content: space-between;
      flex-wrap: wrap;
      gap: 8px;
    }

    .page-title {
      display: flex;
      align-items: center;
      gap: 10px;
      font-size: var(--font-size-4xl);
      font-weight: 700;
      color: var(--md-on-surface);
      margin: 0;
    }

    .title-icon {
      color: var(--md-primary-light);
      font-size: 28px;
      width: 28px;
      height: 28px;
    }

    .unread-badge {
      background: var(--md-error);
      color: white;
      padding: 4px 12px;
      border-radius: 16px;
      font-size: 12px;
      font-weight: 600;
    }

    .page-subtitle {
      color: #64748b;
      font-size: 14px;
      margin: 4px 0 0 0;
    }

    .stats-row {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 12px;
      margin-bottom: 20px;
    }

    .stat-card {
      background: white;
      border-radius: 12px;
      padding: 16px;
      display: flex;
      align-items: center;
      gap: 12px;
      border: 1px solid var(--color-border);
      box-shadow: 0 1px 3px rgba(0,0,0,0.05);
    }

    .stat-icon {
      font-size: 24px;
      width: 40px;
      height: 40px;
      display: flex;
      align-items: center;
      justify-content: center;
      border-radius: 10px;
      background: #eff6ff;
      color: #3b82f6;
    }

    .stat-card.unread .stat-icon {
      background: var(--md-error-container);
      color: var(--md-error);
    }

    .stat-card.today .stat-icon {
      background: #f0fdf4;
      color: #22c55e;
    }

    .stat-info {
      display: flex;
      flex-direction: column;
    }

    .stat-value {
      font-size: var(--font-size-xl);
      font-weight: 700;
      color: var(--md-on-surface);
    }

    .stat-label {
      font-size: 12px;
      color: #64748b;
    }

    .action-buttons {
      display: flex;
      gap: 10px;
      margin-bottom: 16px;
      flex-wrap: wrap;
    }

    .compose-btn {
      flex: 1;
      min-width: 120px;
    }

    .action-buttons button {
      flex: 1;
    }

    .search-section {
      margin-bottom: 16px;
    }

    .search-field {
      width: 100%;
      margin-bottom: 12px;
    }

    .filter-chips {
      display: flex;
      gap: 12px;
      flex-wrap: wrap;
    }

    .filter-field {
      flex: 1;
      min-width: 140px;
    }

    .messages-list {
      display: flex;
      flex-direction: column;
      gap: 12px;
    }

    .message-card {
      background: white;
      border-radius: 12px;
      border: 1px solid var(--color-border);
      display: flex;
      overflow: hidden;
      cursor: pointer;
      transition: all 0.2s ease;
    }

    .message-card:hover {
      border-color: var(--md-primary-light);
      box-shadow: 0 2px 8px rgba(0, 40, 142, 0.15);
    }

    .message-status-bar {
      width: 4px;
      flex-shrink: 0;
    }

    .message-status-bar.status-sent { background: #0ea5e9; }
    .message-status-bar.status-delivered { background: #22c55e; }
    .message-status-bar.status-read { background: #84cc16; }
    .message-status-bar.status-failed { background: var(--md-error); }

    .message-content {
      flex: 1;
      padding: 14px;
      min-width: 0;
    }

    .message-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 8px;
      margin-bottom: 6px;
    }

    .message-subject {
      font-weight: 600;
      color: #374151;
      font-size: 14px;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }

    .message-subject.unread {
      color: #4f46e5;
      font-weight: 700;
    }

    .priority-chip {
      flex-shrink: 0;
    }

    .message-preview {
      font-size: 13px;
      color: var(--color-text-secondary);
      line-height: 1.4;
      margin-bottom: 8px;
      display: -webkit-box;
      -webkit-line-clamp: 2;
      -webkit-box-orient: vertical;
      overflow: hidden;
    }

    .message-meta {
      display: flex;
      gap: 16px;
      font-size: 12px;
      color: #9ca3af;
    }

    .message-meta span {
      display: flex;
      align-items: center;
      gap: 4px;
    }

    .message-meta mat-icon {
      font-size: 14px;
      width: 14px;
      height: 14px;
    }

    .message-actions {
      display: flex;
      align-items: flex-start;
      padding: 8px;
    }

    .empty-state {
      text-align: center;
      padding: 60px 20px;
      background: white;
      border-radius: 12px;
      border: 1px dashed var(--color-border);
    }

    .empty-state mat-icon {
      font-size: 64px;
      width: 64px;
      height: 64px;
      color: #d1d5db;
      margin-bottom: 16px;
    }

    .empty-state h3 {
      color: #374151;
      margin: 0 0 8px 0;
    }

    .empty-state p {
      color: var(--color-text-secondary);
      margin: 0 0 20px 0;
    }

    .desktop-table {
      display: none;
    }

    .status-icon {
      padding: 4px 8px;
      border-radius: 8px;
      font-size: 18px;
      width: 18px;
      height: 18px;
    }

    .status-icon.status-sent { color: #0ea5e9; background: rgba(14, 165, 233, 0.1); }
    .status-icon.status-delivered { color: #22c55e; background: rgba(34, 197, 94, 0.1); }
    .status-icon.status-read { color: #84cc16; background: rgba(132, 204, 22, 0.1); }
    .status-icon.status-failed { color: var(--md-error); background: rgba(239, 68, 68, 0.1); }

    /* Tablet */
    @media (min-width: 768px) {
      .messages-container {
        padding: 24px;
      }

      .page-title {
        font-size: var(--font-size-5xl);
      }

      .compose-btn {
        flex: none;
      }

      .filter-chips {
        flex-wrap: nowrap;
      }
    }

    /* Desktop */
    @media (min-width: 1024px) {
      .messages-list {
        display: none;
      }

      .desktop-table {
        display: block;
        background: white;
        border-radius: 12px;
        border: 1px solid var(--color-border);
        overflow: hidden;
        overflow-x: auto;
        -webkit-overflow-scrolling: touch;
      }

      .desktop-table table { min-width: 760px; }

      .stats-row {
        grid-template-columns: repeat(3, 1fr);
        max-width: 600px;
      }

      .action-buttons {
        max-width: 500px;
      }

      .search-section {
        max-width: 600px;
      }

      .filter-chips {
        max-width: 500px;
      }
    }
  `]
})
export class MessagesComponent implements OnInit, AfterViewInit {
  Permission = Permission;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  messageDataSource = new MatTableDataSource<MessageWithStatus>();
  displayedColumns = ['status', 'priority', 'subject', 'sender', 'sentDate', 'actions'];

  messageTypeFilter = '';
  messageStatusFilter = '';
  messageSearchTerm = '';

  totalMessages = signal(0);
  unreadMessagesCount = signal(0);
  todaysMessages = signal(0);

  constructor(
    private communicationService: CommunicationService,
    private dialog: MatDialog,
    private dialogUtils: DialogUtils,
    private snackBar: MatSnackBar,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.loadMessages();
    this.loadMessageStats();
  }

  ngAfterViewInit(): void {
    this.messageDataSource.paginator = this.paginator;
    this.messageDataSource.sort = this.sort;
  }

  loadMessages(): void {
    this.communicationService.getMessages(
      this.messageTypeFilter || undefined,
      this.messageStatusFilter || undefined,
      this.messageSearchTerm || undefined
    ).subscribe((data: Message[]) => {
      setTimeout(() => {
        // Map messages to include status
        const messagesWithStatus: MessageWithStatus[] = data.map(msg => ({
          ...msg,
          status: msg.isRead ? 'Read' : 'Delivered'
        }));
        this.messageDataSource.data = messagesWithStatus;
        this.totalMessages.set(data.length);
        this.cdr.detectChanges();
      });
    });
  }

  loadMessageStats(): void {
    this.communicationService.getMessageStats().subscribe(
      (stats: any) => {
        setTimeout(() => {
          this.unreadMessagesCount.set(stats?.unreadCount || stats?.UnreadCount || 0);
          this.todaysMessages.set(stats?.todayCount || stats?.TodayCount || 0);
          this.cdr.detectChanges();
        });
      },
      (error) => {
        console.error('Error loading message stats:', error);
      }
    );
  }

  filterMessages(): void {
    this.loadMessages();
  }

  searchMessages(): void {
    if (this.messageSearchTerm.length > 2) {
      this.communicationService.searchMessages(this.messageSearchTerm).subscribe((data: Message[]) => {
        const messagesWithStatus: MessageWithStatus[] = data.map(msg => ({
          ...msg,
          status: msg.isRead ? 'Read' : 'Delivered'
        }));
        this.messageDataSource.data = messagesWithStatus;
      });
    } else if (this.messageSearchTerm.length === 0) {
      this.loadMessages();
    }
  }

  composeMessage(): void {
    (async () => {
      const { MessageDialogComponent } = await import('./message-dialog.component');
      const dialogRef = this.dialog.open(MessageDialogComponent, {
        ...this.dialogUtils.getMobileConfig({ maxWidth: '600px', maxHeight: '90vh' }),
        data: { mode: 'compose' }
      });
      dialogRef.afterClosed().subscribe(result => {
        if (result) this.loadMessages();
      });
    })();
  }

  sendBulkMessage(): void {
    (async () => {
      const { MessageDialogComponent } = await import('./message-dialog.component');
      const dialogRef = this.dialog.open(MessageDialogComponent, {
        ...this.dialogUtils.getMobileConfig({ maxWidth: '600px', maxHeight: '90vh' }),
        data: { mode: 'create', recipientType: 'All' }
      });
      dialogRef.afterClosed().subscribe(result => {
        if (result) this.loadMessages();
      });
    })();
  }

  viewMessage(message: MessageWithStatus): void {
    (async () => {
      const { MessageDialogComponent } = await import('./message-dialog.component');
      this.dialog.open(MessageDialogComponent, {
        ...this.dialogUtils.getMobileConfig({ maxWidth: '600px', maxHeight: '90vh' }),
        data: { mode: 'view', message }
      });
    })();
  }

  replyToMessage(message: Message): void {
    (async () => {
      const { MessageDialogComponent } = await import('./message-dialog.component');
      const dialogRef = this.dialog.open(MessageDialogComponent, {
        ...this.dialogUtils.getMobileConfig({ maxWidth: '600px', maxHeight: '90vh' }),
        data: { mode: 'reply', originalMessage: message }
      });
      dialogRef.afterClosed().subscribe(result => {
        if (result) this.loadMessages();
      });
    })();
  }

  forwardMessage(message: Message): void {
    (async () => {
      const { MessageDialogComponent } = await import('./message-dialog.component');
      const dialogRef = this.dialog.open(MessageDialogComponent, {
        ...this.dialogUtils.getMobileConfig({ maxWidth: '600px', maxHeight: '90vh' }),
        data: { mode: 'forward', originalMessage: message }
      });
      dialogRef.afterClosed().subscribe(result => {
        if (result) this.loadMessages();
      });
    })();
  }

  editMessage(message: Message): void {
    (async () => {
      const { MessageDialogComponent } = await import('./message-dialog.component');
      const dialogRef = this.dialog.open(MessageDialogComponent, {
        ...this.dialogUtils.getMobileConfig({ maxWidth: '600px', maxHeight: '90vh' }),
        data: { mode: 'edit', message }
      });
      dialogRef.afterClosed().subscribe(result => {
        if (result) this.loadMessages();
      });
    })();
  }

  deleteMessage(id: number): void {
    if (confirm('Are you sure you want to delete this message?')) {
      this.communicationService.deleteMessage(id).subscribe(() => {
        this.snackBar.open('Message deleted', 'Close', { duration: 3000 });
        this.loadMessages();
      });
    }
  }

  markAllAsRead(): void {
    this.communicationService.markAllMessagesAsRead().subscribe(() => {
      this.snackBar.open('All messages marked as read', 'Close', { duration: 3000 });
      this.loadMessages();
      this.loadMessageStats();
    });
  }

  getStatusIcon(status: string | undefined): string {
    const icons: { [key: string]: string } = {
      'Sent': 'send',
      'Delivered': 'done',
      'Read': 'done_all',
      'Failed': 'error',
      'Draft': 'save'
    };
    return icons[status || ''] || 'help';
  }

  getStatusClass(status: string | undefined): string {
    const classes: { [key: string]: string } = {
      'Sent': 'status-sent',
      'Delivered': 'status-delivered',
      'Read': 'status-read',
      'Failed': 'status-failed',
      'Draft': 'status-sent'
    };
    return classes[status || ''] || 'status-sent';
  }

  getMessagePreview(content: string): string {
    if (!content) return '';
    return content.length > 100 ? content.substring(0, 100) + '...' : content;
  }

  getPriorityColor(priority: string): string {
    const colors: { [key: string]: string } = {
      'Low': 'basic', 'Medium': 'primary', 'High': 'accent', 'Critical': 'warn'
    };
    return colors[priority] || 'basic';
  }
}
