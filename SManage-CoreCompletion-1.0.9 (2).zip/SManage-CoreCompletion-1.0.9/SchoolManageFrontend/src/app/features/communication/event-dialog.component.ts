import { AfterViewInit, ChangeDetectorRef, Component, Inject, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatDialogModule, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatIconModule } from '@angular/material/icon';
import { MatCardModule } from '@angular/material/card';
import { MatChipsModule } from '@angular/material/chips';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatDividerModule } from '@angular/material/divider';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatSliderModule } from '@angular/material/slider';
import { CommunicationService, Event } from '../../services/communication.service';

interface EventDialogData {
  mode: 'create' | 'edit' | 'duplicate' | 'view';
  event?: Event;
  focusTab?: string;
}

@Component({
  selector: 'app-event-dialog',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatDialogModule,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatIconModule,
    MatCardModule,
    MatChipsModule,
    MatSnackBarModule,
    MatProgressSpinnerModule,
    MatDividerModule,
    MatCheckboxModule,
    MatSliderModule,
  ],
  templateUrl: './event-dialog.component.html',
  styleUrls: ['./event-dialog.component.scss']
})
export class EventDialogComponent implements OnInit, AfterViewInit {
  eventForm: FormGroup;
  processing = signal(false);
  maxDescriptionLength = 1000;
  minDate = new Date();

  constructor(
    private fb: FormBuilder,
    private dialogRef: MatDialogRef<EventDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: EventDialogData,
    private communicationService: CommunicationService,
    private snackBar: MatSnackBar,
    private cdr: ChangeDetectorRef
  ) {
    this.eventForm = this.fb.group({
      title: ['', [Validators.required, Validators.maxLength(200)]],
      description: ['', [Validators.required, Validators.maxLength(this.maxDescriptionLength)]],
      eventType: ['Academic', Validators.required],
      organizer: ['', Validators.required],
      eventDate: ['', Validators.required],
      startTime: ['', Validators.required],
      endTime: ['', [Validators.required]],
      location: ['', Validators.required],
      requiresRegistration: [false],
      maxParticipants: [''],
      registrationDeadline: [''],
      isPublic: [true],
      isAllDay: [false],
      color: ['primary']
    });
  }

  ngOnInit(): void {
    // Add custom validator for end time
    this.eventForm.get('endTime')?.setValidators([
      Validators.required,
      this.endTimeValidator.bind(this)
    ]);

    if ((this.data.mode === 'edit' || this.data.mode === 'view') && this.data.event) {
      this.populateFormForEdit();
    } else if (this.data.mode === 'duplicate' && this.data.event) {
      this.populateFormForDuplicate();
    }

    if (this.data.mode === 'view') {
      this.eventForm.disable();
    }
  }

  ngAfterViewInit(): void {
    this.cdr.detectChanges();
  }

  endTimeValidator(control: any) {
    const endTime = control.value;
    const startTime = this.eventForm?.get('startTime')?.value;
    
    if (endTime && startTime && endTime <= startTime) {
      return { timeOrder: true };
    }
    return null;
  }

  onRegistrationToggle(requiresRegistration: boolean): void {
    const maxParticipantsControl = this.eventForm.get('maxParticipants');
    const deadlineControl = this.eventForm.get('registrationDeadline');

    if (requiresRegistration) {
      maxParticipantsControl?.setValidators([Validators.min(1)]);
      deadlineControl?.setValidators([Validators.required]);
    } else {
      maxParticipantsControl?.clearValidators();
      deadlineControl?.clearValidators();
      maxParticipantsControl?.setValue('');
      deadlineControl?.setValue('');
    }

    maxParticipantsControl?.updateValueAndValidity();
    deadlineControl?.updateValueAndValidity();
  }

  getDialogTitle(): string {
    switch (this.data.mode) {
      case 'create': return 'New Event';
      case 'edit': return 'Edit Event';
      case 'duplicate': return 'Duplicate Event';
      case 'view': return 'Event Details';
      default: return 'Event';
    }
  }

  getDialogIcon(): string {
    switch (this.data.mode) {
      case 'create': return 'add_circle';
      case 'edit': return 'edit';
      case 'duplicate': return 'content_copy';
      case 'view': return 'visibility';
      default: return 'event';
    }
  }

  getActionLabel(): string {
    switch (this.data.mode) {
      case 'create': return 'Create Event';
      case 'edit': return 'Update Event';
      case 'duplicate': return 'Duplicate Event';
      default: return 'Save';
    }
  }

  getActionIcon(): string {
    switch (this.data.mode) {
      case 'create': return 'add';
      case 'edit': return 'update';
      case 'duplicate': return 'content_copy';
      default: return 'save';
    }
  }

  getEventTypeIcon(eventType: string): string {
    switch (eventType) {
      case 'Academic': return 'school';
      case 'Sports': return 'sports';
      case 'Cultural': return 'theater_comedy';
      case 'Meeting': return 'meeting_room';
      case 'Workshop': return 'construction';
      default: return 'event';
    }
  }

  populateFormForEdit(): void {
    if (!this.data.event) return;
    
    this.eventForm.patchValue({
      title: this.data.event.title,
      description: this.data.event.description,
      eventType: this.data.event.type,
      organizer: this.data.event.organizer || '',
      eventDate: new Date(this.data.event.startDate),
      startTime: this.data.event.startTime,
      endTime: this.data.event.endTime,
      location: this.data.event.location,
      requiresRegistration: !!this.data.event.maxParticipants,
      maxParticipants: this.data.event.maxParticipants || '',
      registrationDeadline: this.data.event.registrationDeadline ? new Date(this.data.event.registrationDeadline) : '',
      isPublic: this.data.event.isPublic !== false,
      isAllDay: this.data.event.isAllDay || false,
      color: this.data.event.color || 'primary'
    });
  }

  populateFormForDuplicate(): void {
    if (!this.data.event) return;
    
    this.eventForm.patchValue({
      title: `Copy of ${this.data.event.title}`,
      description: this.data.event.description,
      eventType: this.data.event.type,
      organizer: this.data.event.organizer || '',
      eventDate: new Date(),
      startTime: this.data.event.startTime,
      endTime: this.data.event.endTime,
      location: this.data.event.location,
      requiresRegistration: !!this.data.event.maxParticipants,
      maxParticipants: this.data.event.maxParticipants || '',
      registrationDeadline: '',
      isPublic: this.data.event.isPublic !== false,
      isAllDay: this.data.event.isAllDay || false,
      color: this.data.event.color || 'primary'
    });
  }

  saveDraft(): void {
    if (!this.eventForm.valid) return;
    
    this.processing.set(true);
    const formData = this.eventForm.value;
    
    const eventData: any = {
      title: formData.title,
      description: formData.description,
      type: formData.eventType,
      startDate: formData.eventDate,
      endDate: formData.eventDate,
      startTime: formData.startTime,
      endTime: formData.endTime,
      location: formData.location,
      isPublic: formData.isPublic,
      isAllDay: formData.isAllDay,
      color: formData.color,
      maxParticipants: formData.maxParticipants ? parseInt(formData.maxParticipants) : undefined,
      status: 'Draft'
    };

    this.communicationService.createEvent(eventData).subscribe({
      next: (result) => {
        this.processing.set(false);
        this.snackBar.open('Event saved as draft', 'Close', { duration: 3000 });
        this.dialogRef.close(result);
      },
      error: (err) => {
        this.processing.set(false);
        this.snackBar.open('Failed to save draft: ' + (err.error?.message || 'Server error'), 'Close', { duration: 3000 });
      }
    });
  }

  saveEvent(): void {
    if (!this.eventForm.valid) return;
    
    // Map string values to backend enum integers if needed, 
    // but since we use JsonStringEnumConverter, we can send strings.
    // However, let's see what the backend expects. 
    // CreateEventRequest has EventType Type, and EventType is an enum.
    // ASP.NET Core can bind string to Enum if configured.

    this.processing.set(true);
    const formData = this.eventForm.value;
    
    const eventData: any = {
      title: formData.title,
      description: formData.description,
      type: formData.eventType,
      startDate: formData.eventDate,
      endDate: formData.eventDate,
      startTime: formData.startTime,
      endTime: formData.endTime,
      location: formData.location,
      isPublic: formData.isPublic,
      isAllDay: formData.isAllDay,
      color: formData.color,
      maxParticipants: formData.maxParticipants ? parseInt(formData.maxParticipants) : undefined,
      registrationDeadline: formData.registrationDeadline || undefined,
      status: 'Scheduled'
    };

    const request = this.data.mode === 'edit' && this.data.event
      ? this.communicationService.updateEvent(this.data.event.id!, eventData)
      : this.communicationService.createEvent(eventData);

    request.subscribe({
      next: (result) => {
        this.processing.set(false);
        const successMessage = this.data.mode === 'edit' 
          ? 'Event updated successfully!' 
          : 'Event created successfully!';
        this.snackBar.open(successMessage, 'Close', { duration: 3000 });
        this.dialogRef.close(result);
      },
      error: (err) => {
        this.processing.set(false);
        this.snackBar.open('Failed to save event: ' + (err.error?.message || 'Server error'), 'Close', { duration: 3000 });
      }
    });
  }

  onCancel(): void {
    this.dialogRef.close();
  }
}
