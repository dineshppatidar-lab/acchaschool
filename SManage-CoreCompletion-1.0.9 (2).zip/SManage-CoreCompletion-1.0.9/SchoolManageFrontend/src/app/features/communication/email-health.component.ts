import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSnackBarModule, MatSnackBar } from '@angular/material/snack-bar';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatChipsModule } from '@angular/material/chips';
import { MatDividerModule } from '@angular/material/divider';
import { MatTooltipModule } from '@angular/material/tooltip';
import { EmailAdminService, EmailHealth, EmailTestResult } from '../../services/email-admin.service';
import { PageHeaderComponent } from '../../shared/components/page-patterns/index';

@Component({
  selector: 'app-email-health',
  standalone: true,
  imports: [
    CommonModule, FormsModule, MatButtonModule, MatIconModule, MatCardModule,
    MatFormFieldModule, MatInputModule, MatSnackBarModule, MatProgressSpinnerModule,
    MatChipsModule, MatDividerModule, MatTooltipModule, PageHeaderComponent
  ],
  template: `
    <div class="email-health-container">
      <!-- Page Header -->
      <app-page-header
        title="Email Health"
        subtitle="Diagnose the email subsystem and send a test email"
        [actions]="false" />

      <!-- Loading -->
      <div *ngIf="loading()" class="loading-row">
        <mat-spinner diameter="36"></mat-spinner>
        <span>Loading email configuration…</span>
      </div>

      <!-- Config Card -->
      <mat-card class="config-card" *ngIf="!loading() && health()">
        <mat-card-header>
          <mat-icon mat-card-avatar [class.ok-icon]="health().transport === 'HostingerApi'" class="transport-icon">route</mat-icon>
          <mat-card-title>Active Transport</mat-card-title>
          <mat-card-subtitle>How the system sends outgoing email</mat-card-subtitle>
        </mat-card-header>
        <mat-card-content>
          <div class="transport-chip-row">
            <mat-chip [class.chip-api]="health().transport === 'HostingerApi'" [class.chip-smtp]="health().transport === 'Smtp'">
              <mat-icon matChipAvatar>{{ health().transport === 'HostingerApi' ? 'cloud_done' : 'dns' }}</mat-icon>
              {{ health().transport === 'HostingerApi' ? 'Hostinger Mail API (HTTPS)' : 'SMTP (' + health().smtpHost + ':' + health().smtpPort + ')' }}
            </mat-chip>
          </div>

          <mat-divider></mat-divider>

          <div class="detail-grid">
            <div class="detail-item">
              <span class="detail-label">From address</span>
              <span class="detail-value">{{ health().fromEmail || '—' }}</span>
            </div>
            <div class="detail-item">
              <span class="detail-label">From name</span>
              <span class="detail-value">{{ health().fromName || '—' }}</span>
            </div>

            <!-- SMTP specifics -->
            <ng-container *ngIf="health().transport === 'Smtp'">
              <div class="detail-item">
                <span class="detail-label">SMTP host</span>
                <span class="detail-value">{{ health().smtpHost || '—' }}</span>
              </div>
              <div class="detail-item">
                <span class="detail-label">SMTP port / TLS</span>
                <span class="detail-value">{{ health().smtpPort }} (STARTTLS)</span>
              </div>
              <div class="detail-item">
                <span class="detail-label">SMTP username</span>
                <span class="detail-value" [class.bad]="!health().smtpUsernameConfigured">
                  {{ health().smtpUsernameConfigured ? 'Configured ✓' : 'Not configured' }}
                </span>
              </div>
              <div class="detail-item">
                <span class="detail-label">SMTP password</span>
                <span class="detail-value" [class.bad]="!health().smtpPasswordConfigured">
                  {{ health().smtpPasswordConfigured ? 'Configured ✓' : 'Not configured' }}
                </span>
              </div>
            </ng-container>

            <!-- Hostinger API specifics -->
            <ng-container *ngIf="health().transport === 'HostingerApi'">
              <div class="detail-item">
                <span class="detail-label">API base URL</span>
                <span class="detail-value">{{ health().apiBaseUrl }}</span>
              </div>
              <div class="detail-item">
                <span class="detail-label">API token</span>
                <span class="detail-value" [class.bad]="!health().apiTokenConfigured">
                  {{ health().apiTokenConfigured ? 'Configured ✓' : 'Not configured' }}
                </span>
              </div>
              <div class="detail-item">
                <span class="detail-label">Mailbox resource ID</span>
                <span class="detail-value">{{ health().apiMailboxResourceId || 'Auto-resolved from token' }}</span>
              </div>
            </ng-container>
          </div>

          <div class="warning-box" *ngIf="hasMissingSecrets">
            <mat-icon>warning_amber</mat-icon>
            <span>Some required credentials are missing. Test emails will fail until configured (user-secrets in dev, environment variables in production).</span>
          </div>
        </mat-card-content>
      </mat-card>

      <!-- Test Send Card -->
      <mat-card class="test-card" *ngIf="!loading() && health()">
        <mat-card-header>
          <mat-icon mat-card-avatar class="transport-icon">send</mat-icon>
          <mat-card-title>Send Test Email</mat-card-title>
          <mat-card-subtitle>Verifies end-to-end delivery through the active transport</mat-card-subtitle>
        </mat-card-header>
        <mat-card-content>
          <div class="test-row">
            <mat-form-field appearance="outline" class="test-field">
              <mat-label>Recipient email</mat-label>
              <input matInput type="email" [ngModel]="testEmail()" (ngModelChange)="testEmail.set($event)" placeholder="you@example.com" (keyup.enter)="sendTest()" />
              <mat-icon matSuffix>alternate_email</mat-icon>
            </mat-form-field>
            <button mat-raised-button color="primary" (click)="sendTest()" [disabled]="sending() || !testEmail()">
              <mat-icon *ngIf="!sending()">outgoing_mail</mat-icon>
              <mat-spinner *ngIf="sending()" diameter="18"></mat-spinner>
              {{ sending() ? 'Sending…' : 'Send Test' }}
            </button>
            <button mat-stroked-button (click)="sendTest()" [disabled]="sending() || !testEmail() || testEmail() !== health().fromEmail"
                    matTooltip="Same as Send — kept for clarity">
              <mat-icon>check_circle</mat-icon>
              <span class="btn-text">Verify Own Address</span>
            </button>
          </div>

          <!-- Result -->
          <div class="result-box" *ngIf="lastResult()">
            <div class="result-head" [class.result-ok]="lastResult().success" [class.result-fail]="!lastResult().success">
              <mat-icon>{{ lastResult().success ? 'mark_email_read' : 'report' }}</mat-icon>
              <strong>{{ lastResult().success ? 'Test email sent' : 'Test email failed' }}</strong>
              <span class="result-transport">via {{ lastResult().transport }}</span>
            </div>
            <div class="result-meta">
              To {{ lastResult().sentTo }} at {{ lastResult().sentAtUtc | date:'medium' }} (UTC)
            </div>
            <div class="result-error" *ngIf="lastResult().error">{{ lastResult().error }}</div>
          </div>
        </mat-card-content>
      </mat-card>
    </div>
  `,
  styles: [`
    .email-health-container { padding: 24px; max-width: 900px; margin: 0 auto; }
    .page-header { margin-bottom: 16px; }
    .page-title { display: flex; align-items: center; gap: 10px; margin: 0; font-size: 24px; }
    .title-icon { color: var(--md-primary); }
    .page-subtitle { color: var(--color-text-secondary); margin: 6px 0 0 34px; }
    .loading-row { display: flex; align-items: center; gap: 12px; padding: 24px 0; color: var(--color-text-secondary); }

    .config-card, .test-card { margin-bottom: 20px; }
    .transport-icon { color: var(--md-primary); font-size: 32px; width: 32px; height: 32px; }
    .ok-icon { color: var(--md-success); }

    .transport-chip-row { display: flex; gap: 8px; padding: 12px 0 16px; }
    .chip-api { background: var(--md-success-container); color: var(--md-success); }
    .chip-smtp { background: var(--md-primary-container); color: var(--md-primary-dark); }

    .detail-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px 24px; padding: 16px 0 4px; }
    .detail-item { display: flex; flex-direction: column; }
    .detail-label { font-size: 12px; color: var(--color-text-secondary); }
    .detail-value { font-size: 14px; font-weight: 500; word-break: break-all; }
    .detail-value.bad { color: var(--md-error); }
    .detail-value.good { color: var(--md-success); }

    .warning-box { display: flex; align-items: center; gap: 10px; margin-top: 16px; padding: 12px 16px;
      background: var(--md-warning-container); border: 1px solid #ffecb3; border-radius: 8px; color: #795548; font-size: 13px; }
    .warning-box mat-icon { color: var(--md-warning); }

    .test-row { display: flex; gap: 12px; align-items: flex-start; flex-wrap: wrap; padding-top: 8px; }
    .test-field { flex: 1; min-width: 260px; }
    .btn-text { font-size: 14px; }

    .result-box { margin-top: 16px; border-radius: 8px; padding: 14px 16px; background: var(--md-surface-container-low); border: 1px solid var(--color-border); }
    .result-head { display: flex; align-items: center; gap: 8px; }
    .result-ok mat-icon { color: var(--md-success); }
    .result-fail mat-icon { color: var(--md-error); }
    .result-transport { color: var(--color-text-secondary); font-size: 13px; }
    .result-meta { color: var(--color-text-secondary); font-size: 13px; margin-top: 4px; }
    .result-error { margin-top: 8px; padding: 10px; background: var(--md-error-container); border-radius: 6px;
      color: var(--md-error); font-size: 13px; font-family: monospace; word-break: break-all; }

    @media (max-width: 600px) {
      .detail-grid { grid-template-columns: 1fr; }
    }
  `]
})
export class EmailHealthComponent implements OnInit {
  health = signal<any>(null);
  loading = signal(true);
  sending = signal(false);
  testEmail = signal('');
  lastResult = signal<any>(null);

  constructor(
    private emailAdminService: EmailAdminService,
    private snackBar: MatSnackBar
  ) {}

  ngOnInit(): void {
    this.loadHealth();
  }

  /** True when the active transport is missing a required credential. */
  get hasMissingSecrets(): boolean {
    if (!this.health()) return false;
    if (this.health().transport === 'HostingerApi') {
      return !this.health().apiTokenConfigured;
    }
    return !this.health().smtpUsernameConfigured || !this.health().smtpPasswordConfigured;
  }

  loadHealth(): void {
    this.loading.set(true);
    this.emailAdminService.getHealth().subscribe({
      next: (res) => {
        this.health.set(res?.data ?? res);
        this.loading.set(false);
        // Default the test recipient to the system From address
        if (this.health()?.fromEmail) {
          this.testEmail.set(this.health().fromEmail);
        }
      },
      error: () => {
        this.loading.set(false);
        this.snackBar.open('Failed to load email configuration', 'Close', { duration: 4000 });
      }
    });
  }

  sendTest(): void {
    if (!this.testEmail() || this.sending()) return;
    this.sending.set(true);
    this.lastResult.set(null);

    this.emailAdminService.sendTestEmail(this.testEmail()).subscribe({
      next: (res) => {
        this.sending.set(false);
        this.lastResult.set(res?.data ?? res);
        if (this.lastResult()?.success) {
          this.snackBar.open('Test email sent successfully', 'Close', { duration: 3000 });
        }
      },
      error: (err) => {
        this.sending.set(false);
        const msg = err?.error?.message || err?.message || 'Request failed';
        this.lastResult.set({
          success: false,
          transport: this.health()?.transport ?? 'Unknown',
          sentTo: this.testEmail(),
          sentAtUtc: new Date().toISOString(),
          error: msg
        });
      }
    });
  }
}
