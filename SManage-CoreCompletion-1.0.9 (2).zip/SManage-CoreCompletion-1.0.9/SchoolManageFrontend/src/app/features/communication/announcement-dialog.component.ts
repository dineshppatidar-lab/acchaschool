import { AfterViewInit, ChangeDetectorRef, Component, Inject, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatDialogModule, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatIconModule } from '@angular/material/icon';
import { MatCardModule } from '@angular/material/card';
import { MatChipsModule } from '@angular/material/chips';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatDividerModule } from '@angular/material/divider';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { CommunicationService, Announcement } from '../../services/communication.service';

interface AnnouncementDialogData {
  mode: 'create' | 'edit' | 'duplicate';
  announcement?: Announcement;
}

@Component({
  selector: 'app-announcement-dialog',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatDialogModule,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatIconModule,
    MatCardModule,
    MatChipsModule,
    MatSnackBarModule,
    MatProgressSpinnerModule,
    MatDividerModule,
    MatCheckboxModule,
  ],
  templateUrl: './announcement-dialog.component.html',
  styleUrls: ['./announcement-dialog.component.scss']
})
export class AnnouncementDialogComponent implements OnInit, AfterViewInit {
  announcementForm: FormGroup;
  processing = signal(false);
  maxContentLength = 5000;
  
  // Missing properties
  minDate = new Date();
  selectedFiles: File[] = [];
  publishImmediately = true;
  hasExpiryDate = false;

  constructor(
    private fb: FormBuilder,
    private dialogRef: MatDialogRef<AnnouncementDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: AnnouncementDialogData,
    private communicationService: CommunicationService,
    private snackBar: MatSnackBar,
    private cdr: ChangeDetectorRef
  ) {
    this.announcementForm = this.fb.group({
      title: ['', [Validators.required, Validators.maxLength(200)]],
      content: ['', [Validators.required, Validators.maxLength(this.maxContentLength)]],
      priority: ['Medium', Validators.required],
      targetAudience: ['All', Validators.required],
      publishDate: [new Date(), Validators.required],
      publishTime: ['09:00'],
      expiryDate: [''],
      expiryTime: ['17:00'],
      publishImmediately: [true],
      hasExpiry: [false],
      sendNotification: [true],
      pinToTop: [false]
    });
  }

  ngOnInit(): void {
    // Add custom validator for expiry date
    this.announcementForm.get('expiryDate')?.setValidators([
      this.expiryDateValidator.bind(this)
    ]);

    if (this.data.mode === 'edit' && this.data.announcement) {
      this.populateFormForEdit();
    } else if (this.data.mode === 'duplicate' && this.data.announcement) {
      this.populateFormForDuplicate();
    }

    // Sync flags with form values to prevent ExpressionChangedAfterItHasBeenCheckedError
    this.publishImmediately = this.announcementForm.get('publishImmediately')?.value;
    this.hasExpiryDate = this.announcementForm.get('hasExpiry')?.value;
  }

  ngAfterViewInit(): void {
    // No manual detectChanges() here — synchronous flips of `processing` in async
    // callbacks were re-rendering changed bindings mid-check (NG0100). Zone.js
    // schedules a fresh CD pass for us.
  }

  expiryDateValidator(control: any) {
    const expiryDate = control.value;
    const publishDate = this.announcementForm?.get('publishDate')?.value;
    
    if (expiryDate && publishDate && new Date(expiryDate) <= new Date(publishDate)) {
      return { minDate: true };
    }
    return null;
  }

  getDialogTitle(): string {
    switch (this.data.mode) {
      case 'create': return 'New Announcement';
      case 'edit': return 'Edit Announcement';
      case 'duplicate': return 'Duplicate Announcement';
      default: return 'Announcement';
    }
  }

  getDialogIcon(): string {
    switch (this.data.mode) {
      case 'create': return 'add_circle';
      case 'edit': return 'edit';
      case 'duplicate': return 'content_copy';
      default: return 'announcement';
    }
  }

  getActionLabel(): string {
    const publishImmediately = this.announcementForm.get('publishImmediately')?.value;
    
    switch (this.data.mode) {
      case 'create': return publishImmediately ? 'Create & Publish' : 'Create';
      case 'edit': return 'Update';
      case 'duplicate': return publishImmediately ? 'Duplicate & Publish' : 'Duplicate';
      default: return 'Save';
    }
  }

  getActionIcon(): string {
    const publishImmediately = this.announcementForm.get('publishImmediately')?.value;
    
    switch (this.data.mode) {
      case 'create': return publishImmediately ? 'publish' : 'add';
      case 'edit': return 'update';
      case 'duplicate': return publishImmediately ? 'publish' : 'content_copy';
      default: return 'save';
    }
  }

  getPriorityIcon(priority: string): string {
    switch (priority) {
      case 'Low': return 'info';
      case 'Medium': return 'priority_high';
      case 'High': return 'warning';
      case 'Critical': return 'error';
      default: return 'announcement';
    }
  }

  getPriorityColor(priority: string): string {
    switch (priority) {
      case 'Low': return 'accent';
      case 'Medium': return 'primary';
      case 'High': return 'warn';
      case 'Critical': return 'warn';
      default: return 'primary';
    }
  }

  populateFormForEdit(): void {
    if (!this.data.announcement) return;
    
    this.announcementForm.patchValue({
      title: this.data.announcement.title,
      content: this.data.announcement.content,
      priority: this.data.announcement.priority,
      targetAudience: this.data.announcement.targetAudience,
      publishDate: new Date(this.data.announcement.validFrom),
      expiryDate: this.data.announcement.validTo ? new Date(this.data.announcement.validTo) : '',
      publishImmediately: this.data.announcement.isActive,
      pinToTop: false // This would come from announcement data
    });
  }

  populateFormForDuplicate(): void {
    if (!this.data.announcement) return;
    
    this.announcementForm.patchValue({
      title: `Copy of ${this.data.announcement.title}`,
      content: this.data.announcement.content,
      priority: this.data.announcement.priority,
      targetAudience: this.data.announcement.targetAudience,
      publishDate: new Date(),
      expiryDate: '',
      publishImmediately: false,
      pinToTop: false
    });
  }

  saveDraft(): void {
    if (!this.announcementForm.valid) return;
    
    this.processing.set(true);
    const formData = this.announcementForm.value;
    
    const announcementData: Partial<Announcement> = {
      title: formData.title,
      content: formData.content,
      type: formData.priority === 'Critical' ? 'Emergency' : 'General',
      priority: formData.priority || 'Normal',
      validFrom: formData.publishDate,
      validTo: formData.expiryDate || undefined,
      targetAudience: formData.targetAudience,
      isActive: true,
      status: 'Draft'
    };

    this.communicationService.createAnnouncement(announcementData).subscribe({
      next: (result) => {
        this.processing.set(false);
        this.snackBar.open('Announcement saved as draft', 'Close', { duration: 3000 });
        this.dialogRef.close(result);
      },
      error: (err) => {
        this.processing.set(false);
        this.snackBar.open('Failed to save draft: ' + (err.error?.message || 'Server error'), 'Close', { duration: 3000 });
      }
    });
  }

  saveAnnouncement(): void {
    if (!this.announcementForm.valid) return;

    this.processing.set(true);
    const formData = this.announcementForm.value;

    // Map display names to enum string values
    const priorityMap: { [key: string]: string } = {
      'Low': 'Low',
      'Normal': 'Normal',
      'Medium': 'Normal',
      'High': 'High',
      'Critical': 'Critical'
    };

    const typeMap: { [key: string]: string } = {
      'Low': 'General',
      'Normal': 'Academic',
      'Medium': 'Event',
      'High': 'Holiday',
      'Critical': 'Emergency'
    };

    const announcementData: Partial<Announcement> = {
      title: formData.title,
      content: formData.content,
      type: typeMap[formData.priority] || 'General',
      priority: priorityMap[formData.priority] || 'Normal',
      validFrom: formData.publishDate,
      validTo: formData.expiryDate || undefined,
      targetAudience: formData.targetAudience,
      isActive: true,
      status: 'Published'
    };

    const request = this.data.mode === 'edit' && this.data.announcement
      ? this.communicationService.updateAnnouncement(this.data.announcement.id!, announcementData)
      : this.communicationService.createAnnouncement(announcementData);

    request.subscribe({
      next: (result) => {
        // Close first, then show the snackbar — reopening after the dialog tears
        // down avoids re-rendering this component's changed bindings (NG0100).
        this.dialogRef.close(result);
        const successMessage = this.data.mode === 'edit'
          ? 'Announcement updated successfully!'
          : 'Announcement created successfully!';
        this.snackBar.open(successMessage, 'Close', { duration: 3000 });
      },
      error: (err) => {
        this.processing.set(false);
        this.snackBar.open('Failed to save announcement: ' + (err.error?.message || 'Server error'), 'Close', { duration: 3000 });
      }
    });
  }

  onCancel(): void {
    this.dialogRef.close();
  }

  // Missing methods
  onPublishToggle(checked: boolean): void {
    this.publishImmediately = checked;
    if (checked) {
      this.announcementForm.get('publishDate')?.setValue(new Date());
    }
  }

  onExpiryToggle(checked: boolean): void {
    this.hasExpiryDate = checked;
    if (!checked) {
      this.announcementForm.get('expiryDate')?.setValue('');
    } else {
      // Set default expiry date to 30 days from publish date
      const publishDate = this.announcementForm.get('publishDate')?.value || new Date();
      const expiryDate = new Date(publishDate);
      expiryDate.setDate(expiryDate.getDate() + 30);
      this.announcementForm.get('expiryDate')?.setValue(expiryDate);
    }
  }

  getMinExpiryDate(): Date {
    const publishDate = this.announcementForm.get('publishDate')?.value;
    if (publishDate) {
      const minExpiry = new Date(publishDate);
      minExpiry.setDate(minExpiry.getDate() + 1); // At least 1 day after publish
      return minExpiry;
    }
    return new Date();
  }

  onFileSelected(event: any): void {
    const files = event.target.files;
    if (files) {
      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        // Check file size (limit to 10MB)
        if (file.size > 10 * 1024 * 1024) {
          this.snackBar.open(`File ${file.name} is too large. Maximum size is 10MB.`, 'Close', { duration: 3000 });
          continue;
        }
        // Check if file already selected
        if (!this.selectedFiles.find(f => f.name === file.name)) {
          this.selectedFiles.push(file);
        }
      }
    }
  }

  removeFile(index: number): void {
    this.selectedFiles.splice(index, 1);
  }

  getFileIcon(fileType: string): string {
    if (fileType.startsWith('image/')) {
      return 'image';
    } else if (fileType.includes('pdf')) {
      return 'picture_as_pdf';
    } else if (fileType.includes('word') || fileType.includes('document')) {
      return 'description';
    } else if (fileType.includes('sheet') || fileType.includes('excel')) {
      return 'table_chart';
    } else if (fileType.includes('presentation') || fileType.includes('powerpoint')) {
      return 'slideshow';
    } else {
      return 'attachment';
    }
  }

  getPublishInfo(): string {
    if (this.publishImmediately) {
      return 'This announcement will be published immediately.';
    } else {
      const publishDate = this.announcementForm.get('publishDate')?.value;
      if (publishDate) {
        return `This announcement will be published on ${new Date(publishDate).toLocaleDateString()}.`;
      }
      return 'Please select a publish date.';
    }
  }
}