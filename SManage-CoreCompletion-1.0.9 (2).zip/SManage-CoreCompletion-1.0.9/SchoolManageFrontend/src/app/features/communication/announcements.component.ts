import { ChangeDetectorRef, Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatDialogModule, MatDialog } from '@angular/material/dialog';
import { MatSnackBarModule, MatSnackBar } from '@angular/material/snack-bar';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatCardModule } from '@angular/material/card';
import { MatChipsModule } from '@angular/material/chips';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatDividerModule } from '@angular/material/divider';
import { CommunicationService, Announcement } from '../../services/communication.service';
import { CanWriteDirective, CanDeleteDirective } from '../../core/directives/permission.directive';
import { Permission } from '../../core/models/permission.model';
import { PageHeaderComponent } from '../../shared/components/page-patterns/index';
import { DialogUtils } from '../../shared/dialog-utils';

@Component({
  selector: 'app-announcements',
  standalone: true,
  imports: [
    CommonModule, FormsModule, MatButtonModule, MatIconModule, MatDialogModule,
    MatSnackBarModule, MatFormFieldModule, MatInputModule, MatSelectModule,
    MatCardModule, MatChipsModule, MatExpansionModule, MatTooltipModule, MatDividerModule,
    CanWriteDirective, CanDeleteDirective, PageHeaderComponent
  ],
  template: `
    <div class="announcements-container">
      <!-- Page Header -->
      <app-page-header
        title="Announcements"
        subtitle="Create and manage announcements for students, parents, and staff">
        <button headerActions mat-raised-button color="primary" (click)="createAnnouncement()" *appCanWrite="Permission.AnnouncementsSend">
          <mat-icon>add_circle</mat-icon>
          Create
        </button>
        <button headerActions mat-stroked-button color="primary" (click)="scheduleAnnouncement()" *appCanWrite="Permission.AnnouncementsSend">
          <mat-icon>schedule_send</mat-icon>
          Schedule
        </button>
        <button headerActionsEnd mat-stroked-button (click)="publishAllDrafts()" *appCanWrite="Permission.AnnouncementsSend">
          <mat-icon>publish</mat-icon>
          Publish All
        </button>
      </app-page-header>

      <!-- Filters -->
      <div class="stu-filter-bar">
        <div class="sfe-row">
          <mat-form-field appearance="outline" subscriptSizing="dynamic" class="sfe-field">
            <mat-label>Audience</mat-label>
            <mat-select [(value)]="audienceFilter" (selectionChange)="filterAnnouncements()">
              <mat-option value="">All Audiences</mat-option>
              <mat-option value="Students">Students</mat-option>
              <mat-option value="Parents">Parents</mat-option>
              <mat-option value="Staff">Staff</mat-option>
              <mat-option value="All">Everyone</mat-option>
            </mat-select>
          </mat-form-field>

          <mat-form-field appearance="outline" subscriptSizing="dynamic" class="sfe-field">
            <mat-label>Status</mat-label>
            <mat-select [(value)]="statusFilter" (selectionChange)="filterAnnouncements()">
              <mat-option value="">All Status</mat-option>
              <mat-option value="Draft">Draft</mat-option>
              <mat-option value="Published">Published</mat-option>
              <mat-option value="Scheduled">Scheduled</mat-option>
              <mat-option value="Expired">Expired</mat-option>
            </mat-select>
          </mat-form-field>
        </div>
      </div>

      <!-- Announcements List -->
      <div class="announcements-list">
        <mat-accordion>
          <mat-expansion-panel *ngFor="let announcement of filteredAnnouncements"
                               [expanded]="announcement.priority === 'High'"
                               class="announcement-panel">
            <mat-expansion-panel-header>
              <mat-panel-title>
                <div class="panel-header-content">
                  <div class="priority-indicator" [class]="'priority-' + announcement.priority.toLowerCase()"></div>
                  <div class="panel-info">
                    <span class="panel-title">{{ announcement.title }}</span>
                    <div class="panel-meta">
                      <span class="badge" [class]="'badge badge-' + announcement.priority.toLowerCase()">
                        <span class="badge-dot"></span>{{ announcement.priority }}
                      </span>
                      <span
                        *ngIf="announcement.status"
                        [class]="'badge badge-status badge-' + announcement.status.toLowerCase()">
                        {{ announcement.status }}
                      </span>
                      <span class="badge-date" *ngIf="announcement.validFrom">
                        <mat-icon>event</mat-icon>{{ announcement.validFrom | date:'mediumDate' }}
                      </span>
                    </div>
                  </div>
                </div>
              </mat-panel-title>
            </mat-expansion-panel-header>

            <div class="announcement-body">
              <div class="meta-row">
                <span class="meta-item">
                  <mat-icon>groups</mat-icon>
                  {{ announcement.targetAudience }}
                </span>
                <span class="meta-item">
                  <mat-icon>event</mat-icon>
                  {{ announcement.validFrom | date:'shortDate' }}
                </span>
                <span class="meta-item" *ngIf="announcement.validTo">
                  <mat-icon>event_busy</mat-icon>
                  Expires: {{ announcement.validTo | date:'shortDate' }}
                </span>
              </div>

              <div class="content-text" [innerHTML]="announcement.content"></div>

              <div class="attachments" *ngIf="announcement.attachments?.length">
                <h4><mat-icon>attach_file</mat-icon> Attachments</h4>
                <div class="attachment-chips">
                  <mat-chip *ngFor="let attachment of announcement.attachments">
                    <mat-icon>description</mat-icon>
                    {{ attachment.fileName }}
                  </mat-chip>
                </div>
              </div>

              <div class="announcement-actions">
                <button mat-raised-button color="primary" (click)="editAnnouncement(announcement)" *appCanWrite="Permission.AnnouncementsSend">
                  <mat-icon>edit</mat-icon> Edit
                </button>
                <button mat-stroked-button (click)="duplicateAnnouncement(announcement)">
                  <mat-icon>content_copy</mat-icon> Duplicate
                </button>
                <ng-container *appCanWrite="Permission.AnnouncementsSend">
                  <button mat-stroked-button *ngIf="announcement.status === 'Draft'"
                          color="primary" (click)="publishAnnouncement(announcement)">
                    <mat-icon>publish</mat-icon> Publish
                  </button>
                </ng-container>
                <button mat-stroked-button color="warn" (click)="deleteAnnouncement(announcement.id)" *appCanDelete="Permission.AnnouncementsSend">
                  <mat-icon>delete</mat-icon> Delete
                </button>
              </div>
            </div>
          </mat-expansion-panel>
        </mat-accordion>

        <!-- Empty State -->
        <div *ngIf="filteredAnnouncements.length === 0" class="stu-state">
          <mat-icon class="stu-state-icon">campaign</mat-icon>
          <h3 class="stu-state-title">No announcements found</h3>
          <p class="stu-state-text">Create your first announcement to get started</p>
          <div class="stu-state-action">
            <button mat-raised-button color="primary" (click)="createAnnouncement()" *appCanWrite="Permission.AnnouncementsSend">
              <mat-icon>add_circle</mat-icon>Create Announcement
            </button>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .announcements-container {
      padding: 16px;
      min-height: 100vh;
      background: var(--md-surface-container-low);
    }

    .page-header {
      margin-bottom: 20px;
    }

    .header-content {
      display: flex;
      align-items: center;
      justify-content: space-between;
    }

    .page-title {
      display: flex;
      align-items: center;
      gap: 10px;
      font-size: var(--font-size-4xl);
      font-weight: 700;
      color: var(--md-on-surface);
      margin: 0;
    }

    .title-icon {
      color: var(--md-primary-light);
      font-size: 28px;
      width: 28px;
      height: 28px;
    }

    .page-subtitle {
      color: #64748b;
      font-size: 14px;
      margin: 4px 0 0 0;
    }

    .action-buttons {
      display: flex;
      gap: 10px;
      margin-bottom: 16px;
      flex-wrap: wrap;
    }

    .create-btn {
      flex: 1;
      min-width: 100px;
    }

    .action-buttons button {
      flex: 1;
    }

    .filter-section {
      display: flex;
      gap: 12px;
      margin-bottom: 16px;
      flex-wrap: wrap;
    }

    .filter-field {
      flex: 1;
      min-width: 140px;
    }

    .announcements-list {
      display: flex;
      flex-direction: column;
      gap: 12px;
    }

    .announcement-panel {
      border-radius: 12px !important;
      border: 1px solid var(--color-border) !important;
      box-shadow: none !important;
      background: white;
      margin-bottom: 0 !important;
    }

    /* The global density layer squeezes every expansion header to ~44px
       (styles/_compact.scss) — the list items need a taller, auto-height
       row so title + badges breathe on phones. */
    ::ng-deep .announcement-panel .mat-expansion-panel-header {
      min-height: 68px !important;
      height: auto !important;
      padding: 12px 16px;
      align-items: center;
    }

    ::ng-deep .announcement-panel .mat-expansion-panel-header-title {
      align-items: center;
      min-width: 0;
    }

    ::ng-deep .announcement-panel .mat-expansion-panel-header:not([aria-expanded="true"]) .mat-expansion-panel-header-title {
      height: 44px;
    }

    ::ng-deep .announcement-panel .mat-expansion-panel-header[aria-expanded="true"] {
      padding-bottom: 4px;
    }

    .panel-header-content {
      display: flex;
      align-items: center;
      gap: 12px;
      width: 100%;
      min-width: 0;
    }

    .priority-indicator {
      width: 4px;
      height: 44px;
      border-radius: 2px;
      flex-shrink: 0;
    }

    .priority-indicator.priority-low { background: #22c55e; }
    .priority-indicator.priority-medium { background: var(--md-warning); }
    .priority-indicator.priority-normal { background: #6366f1; }
    .priority-indicator.priority-high { background: var(--md-error); }
    .priority-indicator.priority-critical { background: var(--md-error); }

    .panel-info {
      display: flex;
      flex-direction: column;
      gap: 6px;
      min-width: 0;
      flex: 1;
    }

    .panel-title {
      font-weight: 600;
      color: var(--md-on-surface);
      font-size: 14.5px;
      line-height: 1.35;
      overflow-wrap: anywhere;
      display: -webkit-box;
      -webkit-line-clamp: 2;
      -webkit-box-orient: vertical;
      overflow: hidden;
    }

    .panel-meta {
      display: flex;
      align-items: center;
      flex-wrap: wrap;
      gap: 6px;
    }

    /* Soft pill badges instead of MDC chips: sized for the list row and
       colored per priority/status. The API payload has no status field —
       the old status chip rendered as an empty grey blob and is now
       rendered only when a status is present (template *ngIf). */
    .badge {
      display: inline-flex;
      align-items: center;
      gap: 5px;
      padding: 2px 9px;
      border-radius: 999px;
      font-size: 11px;
      font-weight: 600;
      letter-spacing: 0.2px;
      color: var(--color-text-secondary);
      background: var(--md-surface-container-low);
      white-space: nowrap;
    }

    .badge-dot {
      width: 6px;
      height: 6px;
      border-radius: 50%;
      background: currentColor;
      flex-shrink: 0;
    }

    .badge-low { color: #15803d; background: #f0fdf4; }
    .badge-medium { color: #b45309; background: #fffbeb; }
    .badge-normal { color: #4338ca; background: #eef2ff; }
    .badge-high { color: #b91c1c; background: var(--md-error-container); }
    .badge-critical { color: #991b1b; background: var(--md-error-container); }

    .badge-draft { color: #64748b; background: var(--md-surface-container-low); }
    .badge-published { color: #15803d; background: #f0fdf4; }
    .badge-scheduled { color: #1d4ed8; background: #eff6ff; }
    .badge-expired { color: #b91c1c; background: var(--md-error-container); }

    .badge-date {
      display: inline-flex;
      align-items: center;
      gap: 4px;
      font-size: 11.5px;
      color: var(--md-outline);

      mat-icon { font-size: 13px; width: 13px; height: 13px; }
    }

    .announcement-body {
      padding: 16px 0;
    }

    .meta-row {
      display: flex;
      flex-wrap: wrap;
      gap: 16px;
      margin-bottom: 16px;
      padding: 12px;
      background: var(--md-surface-container-low);
      border-radius: 8px;
    }

    .meta-item {
      display: flex;
      align-items: center;
      gap: 6px;
      font-size: 13px;
      color: var(--color-text-secondary);
    }

    .meta-item mat-icon {
      font-size: 16px;
      width: 16px;
      height: 16px;
      color: #9ca3af;
    }

    .content-text {
      font-size: 14px;
      line-height: 1.6;
      color: #374151;
      margin-bottom: 16px;
    }

    .attachments {
      margin-bottom: 16px;
      padding: 12px;
      background: var(--md-surface-container-low);
      border-radius: 8px;
    }

    .attachments h4 {
      display: flex;
      align-items: center;
      gap: 6px;
      margin: 0 0 10px 0;
      font-size: 13px;
      color: var(--color-text-secondary);
    }

    .attachment-chips {
      display: flex;
      flex-wrap: wrap;
      gap: 8px;
    }

    .announcement-actions {
      display: flex;
      gap: 10px;
      flex-wrap: wrap;
      padding-top: 16px;
      border-top: 1px solid var(--color-border);
    }

    .empty-state {
      text-align: center;
      padding: 60px 20px;
      background: white;
      border-radius: 12px;
      border: 1px dashed var(--color-border);
    }

    .empty-state mat-icon {
      font-size: 64px;
      width: 64px;
      height: 64px;
      color: #d1d5db;
      margin-bottom: 16px;
    }

    .empty-state h3 {
      color: #374151;
      margin: 0 0 8px 0;
    }

    .empty-state p {
      color: var(--color-text-secondary);
      margin: 0 0 20px 0;
    }

    /* Tablet */
    @media (min-width: 768px) {
      .announcements-container {
        padding: 24px;
      }

      .page-title {
        font-size: var(--font-size-5xl);
      }

      .create-btn {
        flex: none;
      }
    }

    /* Desktop */
    @media (min-width: 1024px) {
      .filter-section {
        max-width: 500px;
      }

      .action-buttons {
        max-width: 500px;
      }
    }
  `]
})
export class AnnouncementsComponent implements OnInit {
  Permission = Permission;
  audienceFilter = '';
  statusFilter = '';
  announcements = signal<any[]>([]);
  filteredAnnouncements: Announcement[] = [];

  constructor(
    private communicationService: CommunicationService,
    private dialog: MatDialog,
    private dialogUtils: DialogUtils,
    private snackBar: MatSnackBar,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.loadAnnouncements();
  }

  loadAnnouncements(): void {
    this.communicationService.getAnnouncements().subscribe(
      (data: Announcement[]) => {
        setTimeout(() => {
          this.announcements.set(data);
          this.filterAnnouncements();
          this.cdr.detectChanges();
        });
      },
      (error) => {
        this.snackBar.open('Failed to load announcements', 'Close', { duration: 3000 });
      }
    );
  }

  filterAnnouncements(): void {
    this.filteredAnnouncements = this.announcements().filter(a => {
      const audienceMatch = !this.audienceFilter || a.targetAudience === this.audienceFilter;
      const statusMatch = !this.statusFilter || a.status === this.statusFilter;
      return audienceMatch && statusMatch;
    });
  }

  createAnnouncement(): void {
    (async () => {
      const { AnnouncementDialogComponent } = await import('./announcement-dialog.component');
      const dialogRef = this.dialog.open(AnnouncementDialogComponent, {
        ...this.dialogUtils.getMobileConfig({ width: '90vw', maxWidth: '700px' }),
                maxHeight: '90vh',
        data: { mode: 'create' }
      });
      dialogRef.afterClosed().subscribe(result => {
        if (result) this.loadAnnouncements();
      });
    })();
  }

  scheduleAnnouncement(): void {
    (async () => {
      const { AnnouncementDialogComponent } = await import('./announcement-dialog.component');
      const dialogRef = this.dialog.open(AnnouncementDialogComponent, {
        ...this.dialogUtils.getMobileConfig({ width: '90vw', maxWidth: '700px' }),
                maxHeight: '90vh',
        data: { mode: 'create', defaultScheduled: true }
      });
      dialogRef.afterClosed().subscribe(result => {
        if (result) {
          this.snackBar.open('Announcement scheduled!', 'Close', { duration: 3000 });
          this.loadAnnouncements();
        }
      });
    })();
  }

  editAnnouncement(announcement: Announcement): void {
    (async () => {
      const { AnnouncementDialogComponent } = await import('./announcement-dialog.component');
      const dialogRef = this.dialog.open(AnnouncementDialogComponent, {
        ...this.dialogUtils.getMobileConfig({ width: '90vw', maxWidth: '700px' }),
                maxHeight: '90vh',
        data: { mode: 'edit', announcement }
      });
      dialogRef.afterClosed().subscribe(result => {
        if (result) this.loadAnnouncements();
      });
    })();
  }

  duplicateAnnouncement(announcement: Announcement): void {
    (async () => {
      const { AnnouncementDialogComponent } = await import('./announcement-dialog.component');
      const dialogRef = this.dialog.open(AnnouncementDialogComponent, {
        ...this.dialogUtils.getMobileConfig({ width: '90vw', maxWidth: '700px' }),
                maxHeight: '90vh',
        data: { mode: 'duplicate', announcement }
      });
      dialogRef.afterClosed().subscribe(result => {
        if (result) this.loadAnnouncements();
      });
    })();
  }

  publishAnnouncement(announcement: Announcement): void {
    this.communicationService.publishAnnouncement(announcement.id).subscribe(() => {
      this.snackBar.open('Announcement published', 'Close', { duration: 3000 });
      this.loadAnnouncements();
    });
  }

  publishAllDrafts(): void {
    this.communicationService.publishAllDrafts().subscribe(() => {
      this.snackBar.open('All drafts published', 'Close', { duration: 3000 });
      this.loadAnnouncements();
    });
  }

  deleteAnnouncement(id: number): void {
    if (confirm('Are you sure you want to delete this announcement?')) {
      this.communicationService.deleteAnnouncement(id).subscribe(() => {
        this.snackBar.open('Announcement deleted', 'Close', { duration: 3000 });
        this.loadAnnouncements();
      });
    }
  }

  getPriorityColor(priority: string): string {
    const colors: { [key: string]: string } = {
      'Low': 'basic', 'Medium': 'primary', 'High': 'accent', 'Critical': 'warn'
    };
    return colors[priority] || 'basic';
  }

  getStatusColor(status: string): string {
    const colors: { [key: string]: string } = {
      'Draft': 'basic', 'Published': 'primary', 'Scheduled': 'accent', 'Expired': 'warn'
    };
    return colors[status] || 'basic';
  }
}
