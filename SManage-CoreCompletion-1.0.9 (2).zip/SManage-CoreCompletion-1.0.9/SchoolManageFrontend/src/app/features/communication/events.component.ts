import { Component, OnInit, AfterViewInit, ViewChild, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatTableModule, MatTableDataSource } from '@angular/material/table';
import { MatPaginatorModule, MatPaginator } from '@angular/material/paginator';
import { MatSortModule, MatSort } from '@angular/material/sort';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatDialogModule, MatDialog } from '@angular/material/dialog';
import { MatSnackBarModule, MatSnackBar } from '@angular/material/snack-bar';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatCardModule } from '@angular/material/card';
import { MatChipsModule } from '@angular/material/chips';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatMenuModule } from '@angular/material/menu';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatDividerModule } from '@angular/material/divider';
import { CommunicationService, Event } from '../../services/communication.service';
import { CanWriteDirective } from '../../core/directives/permission.directive';
import { Permission } from '../../core/models/permission.model';
import { PageHeaderComponent } from '../../shared/components/page-patterns/index';
import { DialogUtils } from '../../shared/dialog-utils';

interface CalendarDay {
  date: Date;
  isCurrentMonth: boolean;
  isToday: boolean;
  isSelected: boolean;
  events: Event[];
}

@Component({
  selector: 'app-events',
  standalone: true,
  imports: [
    CommonModule, FormsModule, MatTableModule, MatPaginatorModule, MatSortModule,
    MatButtonModule, MatIconModule, MatDialogModule, MatSnackBarModule,
    MatFormFieldModule, MatInputModule, MatSelectModule, MatCardModule,
    MatChipsModule, MatButtonToggleModule, MatProgressBarModule, MatMenuModule,
    MatTooltipModule, MatDividerModule,
    CanWriteDirective, PageHeaderComponent
  ],
  template: `
    <div class="events-container">
      <!-- Page Header -->
      <app-page-header
        title="Events"
        subtitle="Manage school events, meetings, and activities">
        <button headerActions mat-raised-button color="primary" (click)="createEvent()" *appCanWrite="Permission.EventsManage">
          <mat-icon>add_circle</mat-icon>
          Create
        </button>
        <button headerActions mat-stroked-button (click)="importEvents()">
          <mat-icon>upload</mat-icon>
          Import
        </button>
        <button headerActionsEnd mat-stroked-button (click)="exportEvents()">
          <mat-icon>download</mat-icon>
          Export
        </button>
      </app-page-header>

      <!-- View Toggle -->
      <div class="view-toggle">
        <mat-button-toggle-group [(value)]="eventViewMode" (change)="changeEventView($event)">
          <mat-button-toggle value="list">
            <mat-icon>view_list</mat-icon>
            List
          </mat-button-toggle>
          <mat-button-toggle value="calendar">
            <mat-icon>calendar_month</mat-icon>
            Calendar
          </mat-button-toggle>
        </mat-button-toggle-group>
      </div>

      <!-- Filters -->
      <div class="filter-section">
        <mat-form-field appearance="outline" class="filter-field">
          <mat-select [(value)]="typeFilter" (selectionChange)="filterEvents()">
            <mat-option value="">All Types</mat-option>
            <mat-option value="Academic">Academic</mat-option>
            <mat-option value="Sports">Sports</mat-option>
            <mat-option value="Cultural">Cultural</mat-option>
            <mat-option value="Meeting">Meeting</mat-option>
            <mat-option value="Holiday">Holiday</mat-option>
          </mat-select>
        </mat-form-field>

        <mat-form-field appearance="outline" class="filter-field">
          <mat-select [(value)]="eventDateFilter" (selectionChange)="filterEvents()">
            <mat-option value="upcoming">Upcoming</mat-option>
            <mat-option value="all">All Events</mat-option>
            <mat-option value="thisWeek">This Week</mat-option>
            <mat-option value="thisMonth">This Month</mat-option>
            <mat-option value="past">Past</mat-option>
          </mat-select>
        </mat-form-field>
      </div>

      <!-- List View -->
      <div *ngIf="eventViewMode === 'list'" class="events-list">
        <div *ngFor="let event of eventDataSource.data" class="event-card">
          <div class="event-date-badge">
            <span class="date-month">{{ event.startDate | date:'MMM' }}</span>
            <span class="date-day">{{ event.startDate | date:'dd' }}</span>
          </div>
          <div class="event-content">
            <div class="event-header">
              <span class="event-title">{{ event.title }}</span>
              <mat-chip [color]="getStatusColor(event.status)" size="small">
                {{ event.status }}
              </mat-chip>
            </div>
            <div class="event-details">
              <span class="detail-item">
                <mat-icon>schedule</mat-icon>
                {{ event.startTime }} - {{ event.endTime }}
              </span>
              <span class="detail-item">
                <mat-icon>location_on</mat-icon>
                {{ event.location }}
              </span>
              <span class="detail-item">
                <mat-icon>group</mat-icon>
                {{ event.participantCount || 0 }}
                <span *ngIf="event.maxParticipants">/ {{ event.maxParticipants }}</span>
              </span>
            </div>
            <div class="event-type">
              <mat-chip [color]="getEventTypeColor(event.type)" size="small" outlined>
                {{ event.type }}
              </mat-chip>
              <span class="organizer" *ngIf="event.organizer">by {{ event.organizer }}</span>
            </div>
          </div>
          <div class="event-actions">
            <button mat-icon-button [matMenuTriggerFor]="eventMenu">
              <mat-icon>more_vert</mat-icon>
            </button>
            <mat-menu #eventMenu="matMenu">
              <button mat-menu-item (click)="viewEvent(event)">
                <mat-icon>visibility</mat-icon><span>View</span>
              </button>
              <button mat-menu-item (click)="editEvent(event)" *appCanWrite="Permission.EventsManage">
                <mat-icon>edit</mat-icon><span>Edit</span>
              </button>
              <button mat-menu-item (click)="duplicateEvent(event)">
                <mat-icon>content_copy</mat-icon><span>Duplicate</span>
              </button>
              <button mat-menu-item (click)="manageParticipants(event)">
                <mat-icon>people</mat-icon><span>Participants</span>
              </button>
              <mat-divider></mat-divider>
              <button mat-menu-item (click)="cancelEvent(event.id)" class="warn-item" *appCanWrite="Permission.EventsManage">
                <mat-icon>cancel</mat-icon><span>Cancel</span>
              </button>
            </mat-menu>
          </div>
        </div>

        <!-- Empty State -->
        <div *ngIf="eventDataSource.data.length === 0" class="stu-state">
          <mat-icon class="stu-state-icon">event_busy</mat-icon>
          <h3 class="stu-state-title">No events found</h3>
          <p class="stu-state-text">Create your first event to get started</p>
          <div class="stu-state-action">
            <button mat-raised-button color="primary" (click)="createEvent()" *appCanWrite="Permission.EventsManage">
              <mat-icon>add_circle</mat-icon>Create Event
            </button>
          </div>
        </div>
      </div>

      <!-- Calendar View -->
      <div *ngIf="eventViewMode === 'calendar'" class="calendar-view">
        <div class="calendar-nav">
          <button mat-icon-button (click)="previousMonth()">
            <mat-icon>chevron_left</mat-icon>
          </button>
          <span class="month-label">{{ currentMonth | date:'MMMM yyyy' }}</span>
          <button mat-icon-button (click)="nextMonth()">
            <mat-icon>chevron_right</mat-icon>
          </button>
          <button mat-stroked-button class="today-btn" (click)="goToToday()">Today</button>
        </div>

        <div class="calendar-grid">
          <div class="weekday-header" *ngFor="let day of weekDays">{{ day }}</div>
          <div *ngFor="let day of calendarDays; trackBy: trackByDate"
               class="calendar-day"
               [class.other-month]="!day.isCurrentMonth"
               [class.today]="day.isToday"
               [class.selected]="day.isSelected"
               [class.has-events]="day.events.length > 0"
               (click)="selectDate(day)">
            <span class="day-number">{{ day.date.getDate() }}</span>
            <div class="day-events" *ngIf="day.events.length > 0">
              <div *ngFor="let event of day.events.slice(0, 2)"
                   class="event-dot"
                   [class]="'event-' + event.type.toLowerCase()"
                   [matTooltip]="event.title">
              </div>
              <span class="more-events" *ngIf="day.events.length > 2">
                +{{ day.events.length - 2 }}
              </span>
            </div>
          </div>
        </div>
      </div>

      <!-- Desktop Table (hidden on mobile) -->
      <div class="desktop-table">
        <mat-table [dataSource]="eventDataSource" matSort #eventSort="matSort">
          <ng-container matColumnDef="type">
            <mat-header-cell *matHeaderCellDef>Type</mat-header-cell>
            <mat-cell *matCellDef="let event">
              <mat-chip [color]="getEventTypeColor(event.type)" size="small">
                {{ event.type }}
              </mat-chip>
            </mat-cell>
          </ng-container>

          <ng-container matColumnDef="title">
            <mat-header-cell *matHeaderCellDef mat-sort-header>Event</mat-header-cell>
            <mat-cell *matCellDef="let event">
              <div class="event-title-cell">
                <span class="title">{{ event.title }}</span>
                <span class="organizer" *ngIf="event.organizer">{{ event.organizer }}</span>
              </div>
            </mat-cell>
          </ng-container>

          <ng-container matColumnDef="dateTime">
            <mat-header-cell *matHeaderCellDef mat-sort-header>Date & Time</mat-header-cell>
            <mat-cell *matCellDef="let event">
              <div>{{ event.startDate | date:'mediumDate' }}</div>
              <div class="time">{{ event.startTime }} - {{ event.endTime }}</div>
            </mat-cell>
          </ng-container>

          <ng-container matColumnDef="location">
            <mat-header-cell *matHeaderCellDef>Location</mat-header-cell>
            <mat-cell *matCellDef="let event">{{ event.location }}</mat-cell>
          </ng-container>

          <ng-container matColumnDef="participants">
            <mat-header-cell *matHeaderCellDef>Participants</mat-header-cell>
            <mat-cell *matCellDef="let event">
              {{ event.participantCount || 0 }}
              <span *ngIf="event.maxParticipants">/ {{ event.maxParticipants }}</span>
            </mat-cell>
          </ng-container>

          <ng-container matColumnDef="status">
            <mat-header-cell *matHeaderCellDef>Status</mat-header-cell>
            <mat-cell *matCellDef="let event">
              <mat-chip [color]="getStatusColor(event.status)" size="small">
                {{ event.status }}
              </mat-chip>
            </mat-cell>
          </ng-container>

          <ng-container matColumnDef="actions">
            <mat-header-cell *matHeaderCellDef>Actions</mat-header-cell>
            <mat-cell *matCellDef="let event">
              <button mat-icon-button color="primary" (click)="viewEvent(event)">
                <mat-icon>visibility</mat-icon>
              </button>
              <button mat-icon-button [matMenuTriggerFor]="desktopMenu">
                <mat-icon>more_vert</mat-icon>
              </button>
              <mat-menu #desktopMenu="matMenu">
                <button mat-menu-item (click)="editEvent(event)" *appCanWrite="Permission.EventsManage">
                  <mat-icon>edit</mat-icon><span>Edit</span>
                </button>
                <button mat-menu-item (click)="duplicateEvent(event)">
                  <mat-icon>content_copy</mat-icon><span>Duplicate</span>
                </button>
                <button mat-menu-item (click)="manageParticipants(event)">
                  <mat-icon>people</mat-icon><span>Participants</span>
                </button>
                <mat-divider></mat-divider>
                <button mat-menu-item (click)="cancelEvent(event.id)" *appCanWrite="Permission.EventsManage">
                  <mat-icon>cancel</mat-icon><span>Cancel</span>
                </button>
              </mat-menu>
            </mat-cell>
          </ng-container>

          <mat-header-row *matHeaderRowDef="desktopColumns"></mat-header-row>
          <mat-row *matRowDef="let row; columns: desktopColumns;"></mat-row>
        </mat-table>
        <mat-paginator [pageSizeOptions]="[10, 25, 50]" showFirstLastButtons></mat-paginator>
      </div>
    </div>
  `,
  styles: [`
    .events-container {
      padding: 16px;
      min-height: 100vh;
      background: var(--md-surface-container-low);
    }

    .page-header {
      margin-bottom: 20px;
    }

    .header-content {
      display: flex;
      align-items: center;
      justify-content: space-between;
    }

    .page-title {
      display: flex;
      align-items: center;
      gap: 10px;
      font-size: var(--font-size-4xl);
      font-weight: 700;
      color: var(--md-on-surface);
      margin: 0;
    }

    .title-icon {
      color: var(--md-primary-light);
      font-size: 28px;
      width: 28px;
      height: 28px;
    }

    .page-subtitle {
      color: #64748b;
      font-size: 14px;
      margin: 4px 0 0 0;
    }

    .action-buttons {
      display: flex;
      gap: 10px;
      margin-bottom: 16px;
      flex-wrap: wrap;
    }

    .create-btn {
      flex: 1;
      min-width: 100px;
    }

    .action-buttons button {
      flex: 1;
    }

    .view-toggle {
      display: flex;
      justify-content: center;
      margin-bottom: 16px;
    }

    .view-toggle mat-button-toggle-group {
      border-radius: 25px;
      overflow: hidden;
    }

    .filter-section {
      display: flex;
      gap: 12px;
      margin-bottom: 16px;
      flex-wrap: wrap;
    }

    .filter-field {
      flex: 1;
      min-width: 140px;
    }

    .events-list {
      display: flex;
      flex-direction: column;
      gap: 12px;
    }

    .event-card {
      background: white;
      border-radius: 12px;
      border: 1px solid var(--color-border);
      display: flex;
      overflow: hidden;
      transition: all 0.2s ease;
    }

    .event-card:hover {
      border-color: var(--md-primary-light);
      box-shadow: 0 2px 8px rgba(0, 40, 142, 0.15);
    }

    .event-date-badge {
      width: 60px;
      flex-shrink: 0;
      background: linear-gradient(135deg, var(--md-primary-light) 0%, var(--md-primary-dark) 100%);
      color: white;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      gap: 2px;
    }

    .date-month {
      font-size: 11px;
      text-transform: uppercase;
      font-weight: 600;
      opacity: 0.9;
    }

    .date-day {
      font-size: 20px;
      font-weight: 700;
      line-height: 1;
    }

    .event-content {
      flex: 1;
      padding: 14px;
      min-width: 0;
    }

    .event-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 8px;
      margin-bottom: 8px;
    }

    .event-title {
      font-weight: 600;
      color: var(--md-on-surface);
      font-size: 14px;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }

    .event-details {
      display: flex;
      flex-wrap: wrap;
      gap: 12px;
      margin-bottom: 8px;
    }

    .detail-item {
      display: flex;
      align-items: center;
      gap: 4px;
      font-size: 12px;
      color: var(--color-text-secondary);
    }

    .detail-item mat-icon {
      font-size: 14px;
      width: 14px;
      height: 14px;
      color: #9ca3af;
    }

    .event-type {
      display: flex;
      align-items: center;
      gap: 8px;
    }

    .organizer {
      font-size: 12px;
      color: #9ca3af;
    }

    .event-actions {
      display: flex;
      align-items: flex-start;
      padding: 8px;
    }

    /* Calendar */
    .calendar-view {
      background: white;
      border-radius: 12px;
      border: 1px solid var(--color-border);
      padding: 16px;
    }

    .calendar-nav {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 12px;
      margin-bottom: 16px;
    }

    .month-label {
      font-size: var(--font-size-lg);
      font-weight: 600;
      color: var(--md-on-surface);
      min-width: 160px;
      text-align: center;
    }

    .today-btn {
      margin-left: 8px;
    }

    .calendar-grid {
      display: grid;
      grid-template-columns: repeat(7, 1fr);
      gap: 4px;
    }

    .weekday-header {
      text-align: center;
      font-size: 11px;
      font-weight: 600;
      color: var(--color-text-secondary);
      padding: 8px 0;
      text-transform: uppercase;
    }

    .calendar-day {
      aspect-ratio: 1;
      border-radius: 8px;
      padding: 4px;
      display: flex;
      flex-direction: column;
      align-items: center;
      cursor: pointer;
      transition: background 0.15s;
    }

    .calendar-day:hover {
      background: var(--md-surface-container-low);
    }

    .calendar-day.other-month {
      opacity: 0.4;
    }

    .calendar-day.today {
      background: #eff6ff;
      border: 1px solid #3b82f6;
    }

    .calendar-day.selected {
      background: var(--md-primary-light);
      color: white;
    }

    .day-number {
      font-size: 13px;
      font-weight: 500;
    }

    .day-events {
      display: flex;
      gap: 2px;
      margin-top: 4px;
    }

    .event-dot {
      width: 6px;
      height: 6px;
      border-radius: 50%;
    }

    .event-dot.event-academic { background: #3b82f6; }
    .event-dot.event-sports { background: var(--md-warning); }
    .event-dot.event-cultural { background: #ec4899; }
    .event-dot.event-meeting { background: #8b5cf6; }
    .event-dot.event-holiday { background: #22c55e; }

    .more-events {
      font-size: 9px;
      color: var(--color-text-secondary);
    }

    .desktop-table {
      display: none;
    }

    .empty-state {
      text-align: center;
      padding: 60px 20px;
      background: white;
      border-radius: 12px;
      border: 1px dashed var(--color-border);
    }

    .empty-state mat-icon {
      font-size: 64px;
      width: 64px;
      height: 64px;
      color: #d1d5db;
      margin-bottom: 16px;
    }

    .empty-state h3 {
      color: #374151;
      margin: 0 0 8px 0;
    }

    .empty-state p {
      color: var(--color-text-secondary);
      margin: 0 0 20px 0;
    }

    /* Tablet */
    @media (min-width: 768px) {
      .events-container {
        padding: 24px;
      }

      .page-title {
        font-size: var(--font-size-5xl);
      }

      .create-btn {
        flex: none;
      }

      .calendar-day {
        padding: 8px;
      }
    }

    /* Desktop */
    @media (min-width: 1024px) {
      .events-list {
        display: none;
      }

      .desktop-table {
        display: block;
        background: white;
        border-radius: 12px;
        border: 1px solid var(--color-border);
        overflow: hidden;
      }

      .filter-section {
        max-width: 500px;
      }

      .action-buttons {
        max-width: 500px;
      }

      .view-toggle {
        display: none;
      }
    }
  `]
})
export class EventsComponent implements OnInit, AfterViewInit {
  Permission = Permission;
  @ViewChild('eventPaginator') eventPaginator!: MatPaginator;
  @ViewChild('eventSort') eventSort!: MatSort;

  eventDataSource = new MatTableDataSource<Event>();
  desktopColumns = ['type', 'title', 'dateTime', 'location', 'participants', 'status', 'actions'];

  typeFilter = '';
  eventDateFilter = 'upcoming';
  eventViewMode = 'list';

  currentMonth = new Date();
  weekDays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  calendarDays: CalendarDay[] = [];
  selectedDate: Date | null = null;

  constructor(
    private communicationService: CommunicationService,
    private dialog: MatDialog,
    private dialogUtils: DialogUtils,
    private snackBar: MatSnackBar,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.loadEvents();
  }

  ngAfterViewInit(): void {
    this.eventDataSource.paginator = this.eventPaginator;
    this.eventDataSource.sort = this.eventSort;
  }

  loadEvents(): void {
    let startDate: Date | undefined;
    let endDate: Date | undefined;
    let upcoming = 30;

    const today = new Date();
    today.setHours(0, 0, 0, 0);

    switch (this.eventDateFilter) {
      case 'upcoming': upcoming = 30; break;
      case 'all':
        startDate = new Date(2000, 0, 1);
        endDate = new Date(today.getFullYear() + 10, 11, 31);
        upcoming = 3650;
        break;
      case 'thisWeek':
        startDate = today;
        endDate = new Date(today);
        endDate.setDate(today.getDate() + 7);
        break;
      case 'thisMonth':
        startDate = new Date(today.getFullYear(), today.getMonth(), 1);
        endDate = new Date(today.getFullYear(), today.getMonth() + 1, 0);
        break;
      case 'past':
        startDate = new Date(2000, 0, 1);
        endDate = today;
        upcoming = 0;
        break;
    }

    this.communicationService.getEvents(startDate, endDate, upcoming).subscribe(
      (data: Event[]) => {
        setTimeout(() => {
          if (!data || !Array.isArray(data)) {
            this.eventDataSource.data = [];
            this.cdr.detectChanges();
            return;
          }

          let processedData = data.map(event => {
            if (!event) return null;
            const startDateObj = event.startDate ? new Date(event.startDate) : new Date();
            const endDateObj = event.endDate ? new Date(event.endDate) : startDateObj;

            return {
              ...event,
              type: this.normalizeEventType(event.type) || 'Other',
              status: this.normalizeEventStatus(event.status) || 'Scheduled',
              participantCount: event.participantCount || event.participants?.length || 0,
              startTime: event.startTime || this.extractTime(startDateObj),
              endTime: event.endTime || this.extractTime(endDateObj),
              startDate: event.startDate || startDateObj.toISOString(),
              location: event.location || 'Not Specified',
              title: event.title || 'Untitled Event',
              organizer: event.organizer || 'System'
            };
          }).filter(e => e !== null) as Event[];

          if (this.typeFilter) {
            processedData = processedData.filter(e =>
              e.type && e.type.toLowerCase() === this.typeFilter.toLowerCase()
            );
          }

          this.eventDataSource.data = processedData;
          if (this.eventViewMode === 'calendar') {
            this.generateCalendarDays();
          }
          this.cdr.detectChanges();
        });
      },
      (error) => {
        this.snackBar.open('Failed to load events', 'Close', { duration: 3000 });
      }
    );
  }

  normalizeEventType(type: any): string {
    if (type === null || type === undefined) return 'Other';
    if (typeof type === 'string') {
      const typeNum = parseInt(type);
      if (!isNaN(typeNum) && typeNum.toString() === type) {
        const typeMap: { [key: number]: string } = {
          1: 'Academic', 2: 'Sports', 3: 'Cultural', 4: 'Meeting',
          5: 'Exam', 6: 'Holiday', 7: 'Training', 8: 'Other'
        };
        return typeMap[typeNum] || 'Other';
      }
      return type;
    }
    if (typeof type === 'number') {
      const typeMap: { [key: number]: string } = {
        1: 'Academic', 2: 'Sports', 3: 'Cultural', 4: 'Meeting',
        5: 'Exam', 6: 'Holiday', 7: 'Training', 8: 'Other'
      };
      return typeMap[type] || 'Other';
    }
    return 'Other';
  }

  normalizeEventStatus(status: any): string {
    if (status === null || status === undefined) return 'Scheduled';
    if (typeof status === 'string') {
      const statusNum = parseInt(status);
      if (!isNaN(statusNum) && statusNum.toString() === status) {
        const statusMap: { [key: number]: string } = {
          1: 'Scheduled', 2: 'InProgress', 3: 'Completed', 4: 'Cancelled', 5: 'Postponed'
        };
        return statusMap[statusNum] || 'Scheduled';
      }
      return status;
    }
    if (typeof status === 'number') {
      const statusMap: { [key: number]: string } = {
        1: 'Scheduled', 2: 'InProgress', 3: 'Completed', 4: 'Cancelled', 5: 'Postponed'
      };
      return statusMap[status] || 'Scheduled';
    }
    return 'Scheduled';
  }

  extractTime(date: Date): string {
    if (!date || isNaN(date.getTime())) return '00:00';
    const hours = date.getHours().toString().padStart(2, '0');
    const minutes = date.getMinutes().toString().padStart(2, '0');
    return `${hours}:${minutes}`;
  }

  filterEvents(): void {
    this.loadEvents();
  }

  changeEventView(event: any): void {
    this.eventViewMode = event.value;
    if (this.eventViewMode === 'calendar') {
      this.generateCalendarDays();
    }
  }

  createEvent(): void {
    (async () => {
      const { EventDialogComponent } = await import('./event-dialog.component');
      const dialogRef = this.dialog.open(EventDialogComponent, {
        ...this.dialogUtils.getMobileConfig({ width: '90vw', maxWidth: '700px' }),
                maxHeight: '90vh',
        data: { mode: 'create' }
      });
      dialogRef.afterClosed().subscribe(result => {
        if (result) this.loadEvents();
      });
    })();
  }

  viewEvent(event: Event): void {
    (async () => {
      const { EventDialogComponent } = await import('./event-dialog.component');
      this.dialog.open(EventDialogComponent, {
        ...this.dialogUtils.getMobileConfig({ width: '90vw', maxWidth: '700px' }),
                maxHeight: '90vh',
        data: { mode: 'view', event }
      });
    })();
  }

  editEvent(event: Event): void {
    (async () => {
      const { EventDialogComponent } = await import('./event-dialog.component');
      const dialogRef = this.dialog.open(EventDialogComponent, {
        ...this.dialogUtils.getMobileConfig({ width: '90vw', maxWidth: '700px' }),
                maxHeight: '90vh',
        data: { mode: 'edit', event }
      });
      dialogRef.afterClosed().subscribe(result => {
        if (result) this.loadEvents();
      });
    })();
  }

  duplicateEvent(event: Event): void {
    (async () => {
      const { EventDialogComponent } = await import('./event-dialog.component');
      const dialogRef = this.dialog.open(EventDialogComponent, {
        ...this.dialogUtils.getMobileConfig({ width: '90vw', maxWidth: '700px' }),
                maxHeight: '90vh',
        data: { mode: 'duplicate', event }
      });
      dialogRef.afterClosed().subscribe(result => {
        if (result) this.loadEvents();
      });
    })();
  }

  manageParticipants(event: Event): void {
    (async () => {
      const { EventDialogComponent } = await import('./event-dialog.component');
      const dialogRef = this.dialog.open(EventDialogComponent, {
        ...this.dialogUtils.getMobileConfig({ width: '90vw', maxWidth: '700px' }),
                maxHeight: '90vh',
        data: { mode: 'edit', event, focusTab: 'participants' }
      });
      dialogRef.afterClosed().subscribe(result => {
        if (result) this.loadEvents();
      });
    })();
  }

  cancelEvent(id: number): void {
    if (confirm('Are you sure you want to cancel this event?')) {
      this.communicationService.cancelEvent(id).subscribe(() => {
        this.snackBar.open('Event cancelled', 'Close', { duration: 3000 });
        this.loadEvents();
      });
    }
  }

  importEvents(): void {}
  exportEvents(): void {}

  previousMonth(): void {
    this.currentMonth = new Date(this.currentMonth.getFullYear(), this.currentMonth.getMonth() - 1, 1);
    this.generateCalendarDays();
  }

  nextMonth(): void {
    this.currentMonth = new Date(this.currentMonth.getFullYear(), this.currentMonth.getMonth() + 1, 1);
    this.generateCalendarDays();
  }

  goToToday(): void {
    this.currentMonth = new Date();
    this.selectedDate = new Date();
    this.generateCalendarDays();
  }

  generateCalendarDays(): void {
    const year = this.currentMonth.getFullYear();
    const month = this.currentMonth.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const startDate = new Date(firstDay);
    startDate.setDate(firstDay.getDate() - firstDay.getDay());
    const endDate = new Date(lastDay);
    endDate.setDate(lastDay.getDate() + (6 - lastDay.getDay()));

    this.calendarDays = [];
    const currentDate = new Date(startDate);

    while (currentDate <= endDate) {
      const day: CalendarDay = {
        date: new Date(currentDate),
        isCurrentMonth: currentDate.getMonth() === month,
        isToday: this.isSameDay(currentDate, new Date()),
        isSelected: this.selectedDate ? this.isSameDay(currentDate, this.selectedDate) : false,
        events: this.getEventsForDate(currentDate)
      };
      this.calendarDays.push(day);
      currentDate.setDate(currentDate.getDate() + 1);
    }
  }

  getEventsForDate(date: Date): Event[] {
    return this.eventDataSource.data.filter(event => {
      const eventDate = new Date(event.startDate);
      return this.isSameDay(eventDate, date);
    });
  }

  isSameDay(date1: Date, date2: Date): boolean {
    return date1.getFullYear() === date2.getFullYear() &&
           date1.getMonth() === date2.getMonth() &&
           date1.getDate() === date2.getDate();
  }

  selectDate(day: CalendarDay): void {
    this.selectedDate = day.date;
    this.generateCalendarDays();
  }

  trackByDate(index: number, day: CalendarDay): string {
    return day.date.toISOString();
  }

  getEventTypeColor(eventType: string): string {
    const colors: { [key: string]: string } = {
      'Academic': 'primary', 'Sports': 'accent', 'Cultural': 'warn',
      'Meeting': 'basic', 'Holiday': 'primary'
    };
    return colors[eventType] || 'basic';
  }

  getStatusColor(status: string): string {
    const colors: { [key: string]: string } = {
      'Scheduled': 'primary', 'InProgress': 'accent', 'Completed': 'basic',
      'Cancelled': 'warn', 'Postponed': 'basic'
    };
    return colors[status] || 'basic';
  }
}
