import { ChangeDetectorRef, Component, Inject, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatDialogModule, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatIconModule } from '@angular/material/icon';
import { MatCardModule } from '@angular/material/card';
import { MatChipsModule } from '@angular/material/chips';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatDividerModule } from '@angular/material/divider';
import { CommunicationService, Message } from '../../services/communication.service';
import { UserManagementService } from '../user-management/user-management.service';
import { AuthService } from '../../core/services/auth.service';
import { forkJoin } from 'rxjs';

interface MessageDialogData {
  mode: 'create' | 'edit' | 'reply' | 'forward' | 'compose' | 'view';
  message?: Message;
  originalMessage?: Message;
  recipients?: string[];
  recipientType?: string;
  messageTypes?: string[];
  priorities?: string[];
}

@Component({
  selector: 'app-message-dialog',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatDialogModule,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatIconModule,
    MatCardModule,
    MatChipsModule,
    MatSnackBarModule,
    MatProgressSpinnerModule,
    MatDividerModule,
  ],
  templateUrl: './message-dialog.component.html',
  styleUrls: ['./message-dialog.component.scss']
})
export class MessageDialogComponent implements OnInit {
  messageForm: FormGroup;
  processing = signal(false);
  maxContentLength = 2000;
  availableRecipients = signal<any[]>([]);

  availableUsers = signal<any[]>([]);
  dynamicMessageTypes = signal<any[]>([]);
  dynamicPriorities = signal<any[]>([]);
  selectedRecipients: any[] = [];
  originalMessage?: Message;

  constructor(
    private fb: FormBuilder,
    private dialogRef: MatDialogRef<MessageDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: MessageDialogData,
    private communicationService: CommunicationService,
    private userService: UserManagementService,
    private authService: AuthService,
    private snackBar: MatSnackBar,
    private cdr: ChangeDetectorRef
  ) {
    this.messageForm = this.fb.group({
      recipientType: ['Individual', Validators.required],
      specificRecipients: [[]],
      priority: ['', Validators.required],
      messageType: ['', Validators.required],
      subject: ['', [Validators.required, Validators.maxLength(200)]],
      content: ['', [Validators.required, Validators.maxLength(this.maxContentLength)]]
    });
  }

  ngOnInit(): void {
    this.originalMessage = this.data.message || this.data.originalMessage;

    // For view mode, disable the form immediately
    if (this.data.mode === 'view') {
      this.messageForm.disable();
    }

    this.loadInitialData();
  }

  loadInitialData(): void {
    this.processing.set(true);
    
    forkJoin({
      users: this.userService.getAllUsers(),
      types: this.communicationService.getMessageTypes(),
      priorities: this.communicationService.getMessagePriorities()
    }).subscribe({
      next: (results) => {
        this.availableUsers.set(results.users || []);
        this.availableRecipients.set(this.availableUsers());
        this.dynamicMessageTypes.set(results.types || []);
        this.dynamicPriorities.set(results.priorities || []);
        
        // Set default values if not editing or viewing
        if (this.data.mode !== 'edit' && this.data.mode !== 'view') {
          const defaultType = this.dynamicMessageTypes().find(t => t.label === 'General')?.label || 
                             this.dynamicMessageTypes()[0]?.label || 'General';
          const defaultPriority = this.dynamicPriorities().find(p => p.label === 'Normal' || p.label === 'Medium')?.label || 
                                 this.dynamicPriorities()[0]?.label || 'Normal';
          
          this.messageForm.patchValue({
            messageType: defaultType,
            priority: defaultPriority
          });
        }

        if (this.data.mode === 'edit' && this.data.message) {
          this.populateFormForEdit();
        } else if (this.data.mode === 'view' && (this.data.message || this.data.originalMessage)) {
          this.populateFormForView();
        } else if (this.data.mode === 'reply' && (this.data.message || this.data.originalMessage)) {
          this.populateFormForReply();
        } else if (this.data.mode === 'forward' && (this.data.message || this.data.originalMessage)) {
          this.populateFormForForward();
        }
        
        this.processing.set(false);
      },
      error: (err) => {
        console.error('Error loading dialog data:', err);
        this.processing.set(false);
        this.snackBar.open('Error loading data from server', 'Close', { duration: 3000 });
      }
    });
  }

  initializeProperties(): void {
    this.originalMessage = this.data.message || this.data.originalMessage;
  }

  getDialogTitle(): string {
    switch (this.data.mode) {
      case 'create':
      case 'compose': return 'Compose New Message';
      case 'edit': return 'Edit Message';
      case 'reply': return 'Reply';
      case 'forward': return 'Forward Message';
      case 'view': return 'Message Details';
      default: return 'Message';
    }
  }

  getDialogIcon(): string {
    switch (this.data.mode) {
      case 'create':
      case 'compose': return 'create';
      case 'edit': return 'edit';
      case 'reply': return 'reply';
      case 'forward': return 'forward';
      case 'view': return 'visibility';
      default: return 'message';
    }
  }

  getActionLabel(): string {
    switch (this.data.mode) {
      case 'create':
      case 'compose': return 'Send Message';
      case 'edit': return 'Update Message';
      case 'reply': return 'Send Reply';
      case 'forward': return 'Forward Message';
      case 'view': return 'Close';
      default: return 'Send';
    }
  }

  getActionIcon(): string {
    switch (this.data.mode) {
      case 'create':
      case 'compose': return 'send';
      case 'edit': return 'update';
      case 'reply': return 'reply';
      case 'forward': return 'forward';
      case 'view': return 'close';
      default: return 'send';
    }
  }

  getPriorityIcon(priority: string): string {
    switch (priority) {
      case 'Low': return 'arrow_downward';
      case 'Normal':
      case 'Medium': return 'remove';
      case 'High': return 'arrow_upward';
      case 'Urgent':
      case 'Critical': return 'priority_high';
      default: return 'remove';
    }
  }

  loadAvailableRecipients(): void {
  }

  onRecipientTypeChange(type: string): void {
    const recipientsControl = this.messageForm.get('specificRecipients');
    if (type !== 'Individual') {
      recipientsControl?.setValue([]);
      recipientsControl?.clearValidators();
    } else {
      recipientsControl?.setValidators([Validators.required]);
    }
    recipientsControl?.updateValueAndValidity();
  }

  removeRecipient(recipientId: number): void {
    const recipientsControl = this.messageForm.get('specificRecipients');
    const currentRecipients = recipientsControl?.value || [];
    const updatedRecipients = currentRecipients.filter((id: number) => id !== recipientId);
    recipientsControl?.setValue(updatedRecipients);
  }

  getRecipientName(recipientId: number): string {
    const recipient = this.availableUsers().find(r => r.id === recipientId);
    return recipient ? recipient.name : 'Unknown';
  }

  populateFormForView(): void {
    const msg = this.data.message || this.data.originalMessage;
    if (!msg) return;
    
    this.messageForm.patchValue({
      recipientType: 'Individual',
      priority: msg.priority,
      messageType: msg.type,
      subject: msg.subject,
      content: msg.content
    });

    // Disable the form for view mode
    this.messageForm.disable();
  }

  populateFormForEdit(): void {
    if (!this.data.message) return;
    
    this.messageForm.patchValue({
      recipientType: 'Individual',
      priority: this.data.message.priority,
      messageType: this.data.message.type,
      subject: this.data.message.subject,
      content: this.data.message.content
    });
  }

  populateFormForReply(): void {
    const msg = this.data.message || this.data.originalMessage;
    if (!msg) return;
    
    this.messageForm.patchValue({
      recipientType: 'Individual',
      specificRecipients: [msg.senderId],
      priority: msg.priority,
      messageType: msg.type,
      subject: `Re: ${msg.subject}`,
      content: ''
    });
  }

  populateFormForForward(): void {
    const msg = this.data.message || this.data.originalMessage;
    if (!msg) return;
    
    this.messageForm.patchValue({
      priority: msg.priority,
      messageType: msg.type,
      subject: `Fwd: ${msg.subject}`,
      content: `\n\n--- Forwarded Message ---\nFrom: ${msg.senderName}\nSubject: ${msg.subject}\n\n${msg.content}`
    });
  }

  saveDraft(): void {
    if (!this.messageForm.valid) return;
    
    this.processing.set(true);
    const formData = this.messageForm.value;
    const currentUser = this.authService.getCurrentUser();
    
    const messageData: any = {
      subject: formData.subject,
      content: formData.content,
      priority: formData.priority,
      type: formData.messageType,
      sentDate: new Date(),
      senderId: currentUser?.id || 0,
      senderType: currentUser?.role?.toString() || 'Staff'
    };

    this.communicationService.sendMessage(messageData).subscribe({
      next: (result) => {
        this.processing.set(false);
        this.snackBar.open('Message saved as draft', 'Close', { duration: 3000 });
        this.dialogRef.close(result);
      },
      error: (err) => {
        this.processing.set(false);
        this.snackBar.open('Failed to save draft', 'Close', { duration: 3000 });
      }
    });
  }

  sendMessage(): void {
    if (this.data.mode === 'view') {
      this.dialogRef.close();
      return;
    }

    if (!this.messageForm.valid) return;

    this.processing.set(true);
    const currentUser = this.authService.getCurrentUser();
    const formData = this.messageForm.value;

    const messageData: any = {
      subject: formData.subject,
      content: formData.content,
      priority: formData.priority,
      type: formData.messageType,
      senderId: currentUser?.id || 0,
      senderType: currentUser?.role?.toString() || 'Staff',
      senderName: `${currentUser?.firstName} ${currentUser?.lastName}`.trim(),
      recipients: [],
      sendEmailNotification: true
    };

    if (formData.recipientType === 'Individual' && Array.isArray(formData.specificRecipients)) {
      messageData.recipients = formData.specificRecipients.map((id: number) => ({
        recipientId: id,
        recipientType: this.getRecipientTypeById(id),
        email: this.getRecipientEmailById(id)
      }));
    } else if (formData.recipientType !== 'Individual') {
      let filteredUsers = [];
      if (formData.recipientType === 'All') {
        filteredUsers = this.availableUsers();
      } else {
        const targetType = formData.recipientType.toLowerCase();
        filteredUsers = this.availableUsers().filter(u => {
          const userRole = (u.roles || u.role || '').toLowerCase();
          return userRole === targetType || 
                 userRole === targetType.slice(0, -1) ||
                 targetType.includes(userRole);
        });
      }

      messageData.recipients = filteredUsers.map((u: any) => ({
        recipientId: u.id,
        recipientType: u.roles || u.role || 'Staff',
        email: u.email
      }));
    }

    const request = this.data.mode === 'edit' && this.data.message
      ? this.communicationService.updateMessage(this.data.message.id, messageData)
      : this.communicationService.sendMessage(messageData);

    request.subscribe({
      next: (result) => {
        // Close first, then show the snackbar — reopening after the dialog tears
        // down avoids re-rendering this component's changed bindings (NG0100).
        this.dialogRef.close(result);
        const successMessage = this.data.mode === 'edit' ? 'Message updated successfully!' : 'Message sent successfully!';
        this.snackBar.open(successMessage, 'Close', { duration: 3000 });
      },
      error: (err) => {
        this.processing.set(false);
        this.snackBar.open('Failed to send message: ' + (err.error?.message || 'Server error'), 'Close', { duration: 3000 });
      }
    });
  }

  getRecipientTypeById(id: number): string {
    const user = this.availableUsers().find(u => u.id === id);
    return user ? user.type : 'Staff';
  }

  getRecipientEmailById(id: number): string {
    const user = this.availableUsers().find(u => u.id === id);
    return user ? user.email : '';
  }

  onCancel(): void {
    this.dialogRef.close();
  }

  getMessageTypeIcon(messageType: string): string {
    const icons: { [key: string]: string } = {
      'General': 'message',
      'Academic': 'school',
      'Administrative': 'business',
      'Emergency': 'warning',
      'Event': 'event',
      'Reminder': 'alarm',
      'Information': 'info',
      'Alert': 'warning',
      'Update': 'update'
    };
    return icons[messageType] || 'message';
  }

  getPriorityColor(priority: string): string {
    const colors: { [key: string]: string } = {
      'Low': 'basic',
      'Medium': 'primary',
      'High': 'accent',
      'Critical': 'warn',
      'Urgent': 'warn'
    };
    return colors[priority] || 'basic';
  }

  getRecipientCount(): number {
    if (this.messageForm.get('recipientType')?.value !== 'Individual') {
      return 0;
    }
    const recipients = this.messageForm.get('specificRecipients')?.value;
    if (Array.isArray(recipients)) {
      return recipients.length;
    }
    return 0;
  }
}
