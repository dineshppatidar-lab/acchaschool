import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatDividerModule } from '@angular/material/divider';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatNativeDateModule } from '@angular/material/core';

import { BaseFormComponent, FormFieldConfig } from '../../core/components/base-form.component';
import { PageHeaderComponent } from '../../shared/components/page-patterns/index';
import { BaseCrudService } from '../../core/services/base-crud.service';
import { AcademicService } from '../../services/academic.service';
import { Section } from '../../shared/models/academic.models';

/**
 * Section Form Component
 * 
 * Handles creation and editing of class sections.
 * Associates sections with classes and assigns class teachers.
 * 
 * Usage:
 * - Create: /app/academic/section/form
 * - Edit: /app/academic/section/form/123
 */
@Component({
  selector: 'app-section-form',
  templateUrl: '../../core/components/base-form.component.html',
  styleUrls: ['../../core/components/base-form.component.scss'],
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatButtonModule,
    MatCardModule,
    MatIconModule,
    MatDividerModule,
    MatProgressSpinnerModule,
    MatProgressBarModule,
    MatSnackBarModule,
    MatDatepickerModule,
    MatCheckboxModule,
    MatNativeDateModule,
    PageHeaderComponent,
      MatNativeDateModule
  ]
})
export class SectionFormComponent extends BaseFormComponent<Section> {
  classOptions: { id: number; name: string }[] = [];

  shifts = [
    { id: 'MORNING', name: 'Morning Shift (6:00 AM - 1:00 PM)' },
    { id: 'AFTERNOON', name: 'Afternoon Shift (1:00 PM - 6:00 PM)' }
  ];

  constructor(private sectionService: AcademicService) {
    super();
    this.loadClasses();
  }

  private loadClasses(): void {
    this.sectionService.getAll().subscribe({
      next: (classes) => {
        if (classes && classes.length > 0) {
          this.classOptions = classes.map(c => ({ id: c.id, name: c.name }));
        }
      },
      error: () => {}
    });
  }

  getService(): BaseCrudService<Section> {
    return this.sectionService as any;
  }

  getFormTitle(): string {
    return this.isCreateMode ? 'Add New Section' : 'Edit Section';
  }

  getFormConfig(): FormFieldConfig[] {
    return [
      {
        name: 'name',
        label: 'Section Name',
        type: 'text',
        placeholder: 'e.g., Section A, Section B',
        required: true,
        minLength: 1,
        maxLength: 50,
        grid: 'half'
      },
      {
        name: 'classId',
        label: 'Class',
        type: 'select',
        required: true,
        options: this.classOptions,
        grid: 'half'
      },
      {
        name: 'capacity',
        label: 'Student Capacity',
        type: 'number',
        placeholder: 'Maximum number of students',
        required: true,
        min: 1,
        max: 100,
        grid: 'half'
      },
      {
        name: 'shift',
        label: 'Shift',
        type: 'select',
        options: this.shifts,
        grid: 'half'
      },
      {
        name: 'classTeacher',
        label: 'Class Teacher',
        type: 'text',
        placeholder: 'Enter teacher name or ID',
        minLength: 2,
        maxLength: 100,
        grid: 'full'
      },
      {
        name: 'roomNumber',
        label: 'Room Number/Block',
        type: 'text',
        placeholder: 'e.g., Block A - Room 10',
        maxLength: 50,
        grid: 'half'
      },
      {
        name: 'floor',
        label: 'Floor',
        type: 'text',
        placeholder: 'e.g., Ground, First, Second',
        maxLength: 30,
        grid: 'half'
      },
      {
        name: 'totalTeachers',
        label: 'Total Teachers',
        type: 'number',
        placeholder: 'Number of teachers assigned',
        min: 1,
        max: 20,
        grid: 'half'
      },
      {
        name: 'academicYear',
        label: 'Academic Year',
        type: 'text',
        placeholder: 'e.g., 2024-2025',
        maxLength: 20,
        grid: 'half'
      },
      {
        name: 'enrollmentStatus',
        label: 'Enrollment Status',
        type: 'select',
        options: [
          { id: 'OPEN', name: 'Open for Enrollment' },
          { id: 'CLOSED', name: 'Closed' },
          { id: 'WAITLIST', name: 'Waitlist Only' }
        ],
        grid: 'half'
      },
      {
        name: 'description',
        label: 'Description/Notes',
        type: 'textarea',
        placeholder: 'Additional information about this section',
        maxLength: 500,
        grid: 'full'
      },
      {
        name: 'isActive',
        label: 'Is Active',
        type: 'checkbox',
        grid: 'half'
      }
    ];
  }
}
