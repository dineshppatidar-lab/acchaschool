import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AcademicListComponent } from './academic-list.component';
import { AcademicFormComponent } from './academic-form.component';
import { ReactiveFormsModule } from '@angular/forms';
import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSortModule } from '@angular/material/sort';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { AcademicRoutingModule } from './academic-routing.module';

@NgModule({
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    MatInputModule,
    MatButtonModule,
    AcademicRoutingModule,
    ]
})
export class AcademicModule {}
