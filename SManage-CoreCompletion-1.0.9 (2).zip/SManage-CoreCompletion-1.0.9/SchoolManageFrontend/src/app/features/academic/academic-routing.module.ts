import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AcademicListComponent } from './academic-list.component';
import { AcademicFormComponent } from './academic-form.component';

const routes: Routes = [
  { path: '', redirectTo: 'list', pathMatch: 'full' },
  { path: 'list', component: AcademicListComponent },
  { path: 'form', component: AcademicFormComponent },
  { path: 'edit/:id', component: AcademicFormComponent },
  { path: 'subjects', loadComponent: () => import('./subject-list.component').then(m => m.SubjectListComponent) }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AcademicRoutingModule { }
