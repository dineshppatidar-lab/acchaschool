import { Component, OnInit, signal } from '@angular/core';
import { Router } from '@angular/router';
import { MasterDataService } from '../../services/master-data.service';
import { Section } from '../../shared/models/academic.models';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { RouterModule } from '@angular/router';
import { MatTableModule } from '@angular/material/table';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatMenuModule } from '@angular/material/menu';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Observable, BehaviorSubject } from 'rxjs';
import { delay, map, startWith, debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { CanWriteDirective, CanDeleteDirective } from '../../core/directives/permission.directive';
import { Permission } from '../../core/models/permission.model';

@Component({
  selector: 'app-section-list',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatIconModule,
    MatButtonModule,
    RouterModule,
    MatTableModule,
    MatCardModule,
    MatFormFieldModule,
    MatInputModule,
    MatMenuModule,
    MatTooltipModule,
    MatProgressSpinnerModule,
    CanWriteDirective,
    CanDeleteDirective
  ],
  templateUrl: './section-list.component.html',
  styleUrls: ['./section-list.component.scss']
})
export class SectionListComponent implements OnInit {
  Permission = Permission;
  sections$?: Observable<Section[]>;
  displayedColumns: string[] = ['id', 'name', 'actions'];

  isLoading = signal(true);
  searchTerm = '';
  private searchSubject = new BehaviorSubject<string>('');

  constructor(private masterDataService: MasterDataService, private router: Router) {}

  ngOnInit() {
    this.loadSections();
  }

  loadSections() {
    console.log('Loading sections...');
    this.isLoading.set(true);
    this.sections$ = this.masterDataService.getSections().pipe(
      delay(500),
      map((sections: Section[]) => {
        this.isLoading.set(false);
        return sections;
      })
    );
  }

  onSearchChange(event: Event) {
    const target = event.target as HTMLInputElement;
    this.searchTerm = target.value;
    this.searchSubject.next(this.searchTerm);
  }

  createSection() {
    this.router.navigate(['/app/academic/form']);
  }

  editSection(id: number) {
    this.router.navigate(['/app/academic/edit', id]);
  }

  deleteSection(id: number) {
    if (confirm('Are you sure you want to delete this section?')) {
      // API call would go here
    }
  }
}
