import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatDividerModule } from '@angular/material/divider';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatNativeDateModule } from '@angular/material/core';

import { BaseFormComponent, FormFieldConfig } from '../../core/components/base-form.component';
import { PageHeaderComponent } from '../../shared/components/page-patterns/index';
import { BaseCrudService } from '../../core/services/base-crud.service';
import { AcademicService } from '../../services/academic.service';
import { AcademicYear } from '../../shared/models/academic.models';

/**
 * Academic Year Form Component
 * 
 * Handles creation and editing of academic years.
 * Manages start/end dates and academic calendar configuration.
 * 
 * Usage:
 * - Create: /app/academic/year/form
 * - Edit: /app/academic/year/form/123
 */
@Component({
  selector: 'app-academic-year-form',
  templateUrl: '../../core/components/base-form.component.html',
  styleUrls: ['../../core/components/base-form.component.scss'],
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatButtonModule,
    MatCardModule,
    MatIconModule,
    MatDividerModule,
    MatProgressSpinnerModule,
    MatProgressBarModule,
    MatSnackBarModule,
    MatDatepickerModule,
    MatCheckboxModule,
    MatNativeDateModule,
    PageHeaderComponent,
      MatNativeDateModule
  ]
})
export class AcademicYearFormComponent extends BaseFormComponent<AcademicYear> {
  constructor(private academicYearService: AcademicService) {
    super();
  }

  getService(): BaseCrudService<AcademicYear> {
    return this.academicYearService as any;
  }

  getFormTitle(): string {
    return this.isCreateMode ? 'Add New Academic Year' : 'Edit Academic Year';
  }

  getFormConfig(): FormFieldConfig[] {
    return [
      {
        name: 'year',
        label: 'Academic Year',
        type: 'text',
        placeholder: 'e.g., 2024-2025',
        required: true,
        pattern: '^\\d{4}-\\d{4}$',
        minLength: 9,
        maxLength: 9,
        grid: 'half'
      },
      {
        name: 'startDate',
        label: 'Start Date',
        type: 'date',
        required: true,
        grid: 'half'
      },
      {
        name: 'endDate',
        label: 'End Date',
        type: 'date',
        required: true,
        grid: 'half'
      },
      {
        name: 'admissionStartDate',
        label: 'Admission Period Start',
        type: 'date',
        grid: 'half'
      },
      {
        name: 'admissionEndDate',
        label: 'Admission Period End',
        type: 'date',
        grid: 'half'
      },
      {
        name: 'term1StartDate',
        label: 'Term 1 Start Date',
        type: 'date',
        grid: 'half'
      },
      {
        name: 'term1EndDate',
        label: 'Term 1 End Date',
        type: 'date',
        grid: 'half'
      },
      {
        name: 'term2StartDate',
        label: 'Term 2 Start Date',
        type: 'date',
        grid: 'half'
      },
      {
        name: 'term2EndDate',
        label: 'Term 2 End Date',
        type: 'date',
        grid: 'half'
      },
      {
        name: 'examStartDate',
        label: 'Exam Period Start',
        type: 'date',
        grid: 'half'
      },
      {
        name: 'examEndDate',
        label: 'Exam Period End',
        type: 'date',
        grid: 'half'
      },
      {
        name: 'reportCardGenerationDate',
        label: 'Report Card Generation Date',
        type: 'date',
        grid: 'half'
      },
      {
        name: 'totalWorkingDays',
        label: 'Total Working Days',
        type: 'number',
        placeholder: 'e.g., 240',
        min: 100,
        max: 280,
        grid: 'half'
      },
      {
        name: 'description',
        label: 'Description/Remarks',
        type: 'textarea',
        placeholder: 'Any special notes about this academic year',
        maxLength: 500,
        grid: 'full'
      },
      {
        name: 'isActive',
        label: 'Is Current Academic Year',
        type: 'checkbox',
        grid: 'half'
      },
      {
        name: 'isClosed',
        label: 'Is Year Closed',
        type: 'checkbox',
        grid: 'half'
      }
    ];
  }
}
