import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatDividerModule } from '@angular/material/divider';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatNativeDateModule } from '@angular/material/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormBuilder } from '@angular/forms';

import { BaseFormComponent, FormFieldConfig } from '../../core/components/base-form.component';
import { PageHeaderComponent } from '../../shared/components/page-patterns/index';
import { BaseCrudService } from '../../core/services/base-crud.service';
import { AcademicService } from '../../services/academic.service';
import { Subject } from '../../shared/models/academic.models';

/**
 * Subject Form Component
 * 
 * Handles creation and editing of subject information.
 * Supports different subject types (Core, Elective, Co-Curricular).
 * 
 * Usage:
 * - Create: /app/academic/subject/form
 * - Edit: /app/academic/subject/form/123
 */
@Component({
  selector: 'app-subject-form',
  templateUrl: '../../core/components/base-form.component.html',
  styleUrls: ['../../core/components/base-form.component.scss'],
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatButtonModule,
    MatCardModule,
    MatIconModule,
    MatDividerModule,
    MatProgressSpinnerModule,
    MatProgressBarModule,
    MatSnackBarModule,
    MatDatepickerModule,
    MatCheckboxModule,
    MatNativeDateModule,
    PageHeaderComponent,
      MatNativeDateModule
  ]
})
export class SubjectFormComponent extends BaseFormComponent<Subject> {
  subjectTypes = [
    { id: 'CORE', name: 'Core Subject' },
    { id: 'ELECTIVE', name: 'Elective Subject' },
    { id: 'CO_CURRICULAR', name: 'Co-Curricular Activity' },
    { id: 'LANGUAGE', name: 'Language' },
    { id: 'SKILL', name: 'Skill Development' }
  ];

  difficultyLevels = [
    { id: 'BEGINNER', name: 'Beginner' },
    { id: 'INTERMEDIATE', name: 'Intermediate' },
    { id: 'ADVANCED', name: 'Advanced' }
  ];

  constructor(private subjectService: AcademicService) {
    super();
  }

  getService(): BaseCrudService<Subject> {
    return this.subjectService as any;
  }

  getFormTitle(): string {
    return this.isCreateMode ? 'Add New Subject' : 'Edit Subject';
  }

  getFormConfig(): FormFieldConfig[] {
    return [
      {
        name: 'name',
        label: 'Subject Name',
        type: 'text',
        placeholder: 'e.g., Mathematics, Physics, English',
        required: true,
        minLength: 2,
        maxLength: 100,
        grid: 'full'
      },
      {
        name: 'code',
        label: 'Subject Code',
        type: 'text',
        placeholder: 'e.g., MATH-001, PHY-102',
        required: true,
        minLength: 2,
        maxLength: 20,
        grid: 'half'
      },
      {
        name: 'type',
        label: 'Subject Type',
        type: 'select',
        required: true,
        options: this.subjectTypes,
        grid: 'half'
      },
      {
        name: 'creditHours',
        label: 'Credit Hours',
        type: 'number',
        placeholder: 'Number of credit hours',
        min: 0,
        max: 10,
        grid: 'half'
      },
      {
        name: 'difficultyLevel',
        label: 'Difficulty Level',
        type: 'select',
        options: this.difficultyLevels,
        grid: 'half'
      },
      {
        name: 'maxMarks',
        label: 'Maximum Marks',
        type: 'number',
        placeholder: 'e.g., 100',
        min: 0,
        max: 1000,
        grid: 'half'
      },
      {
        name: 'passMarks',
        label: 'Pass Marks',
        type: 'number',
        placeholder: 'Minimum marks to pass',
        min: 0,
        max: 1000,
        grid: 'half'
      },
      {
        name: 'description',
        label: 'Subject Description',
        type: 'textarea',
        placeholder: 'Brief description of the subject content and objectives',
        maxLength: 500,
        grid: 'full'
      },
      {
        name: 'isActive',
        label: 'Is Active',
        type: 'checkbox',
        grid: 'half'
      },
      {
        name: 'isOptional',
        label: 'Is Optional',
        type: 'checkbox',
        grid: 'half'
      }
    ];
  }
}
