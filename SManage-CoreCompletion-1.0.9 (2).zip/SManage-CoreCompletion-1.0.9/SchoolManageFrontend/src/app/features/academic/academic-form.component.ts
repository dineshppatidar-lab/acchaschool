import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatDividerModule } from '@angular/material/divider';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatNativeDateModule } from '@angular/material/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormBuilder } from '@angular/forms';

import { BaseFormComponent, FormFieldConfig } from '../../core/components/base-form.component';
import { PageHeaderComponent } from '../../shared/components/page-patterns/index';
import { BaseCrudService } from '../../core/services/base-crud.service';
import { AcademicService } from '../../services/academic.service';
import { Class } from '../../shared/models/academic.models';

/**
 * Class Form Component
 * 
 * Extends BaseFormComponent for Create/Edit functionality.
 * Handles both creating new classes and editing existing ones.
 * 
 * Usage:
 * - Create: /app/academic/form
 * - Edit: /app/academic/form/123
 */
@Component({
  selector: 'app-academic-form',
  templateUrl: '../../core/components/base-form.component.html',
  styleUrls: ['../../core/components/base-form.component.scss'],
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatButtonModule,
    MatCardModule,
    MatIconModule,
    MatDividerModule,
    MatProgressSpinnerModule,
    MatProgressBarModule,
    MatSnackBarModule,
    MatDatepickerModule,
    MatCheckboxModule,
    MatNativeDateModule,
    PageHeaderComponent,
      MatNativeDateModule
  ]
})
export class AcademicFormComponent extends BaseFormComponent<Class> {
  constructor(private classService: AcademicService) {
    super();
  }

  getService(): BaseCrudService<Class> {
    return this.classService as any;
  }

  getFormTitle(): string {
    return this.isCreateMode ? 'Add New Class' : 'Edit Class';
  }

  getFormConfig(): FormFieldConfig[] {
    return [
      {
        name: 'name',
        label: 'Class Name',
        type: 'text',
        placeholder: 'Enter class name (e.g., Class 10 A)',
        required: true,
        minLength: 2,
        maxLength: 50,
        grid: 'full'
      },
      {
        name: 'description',
        label: 'Description',
        type: 'textarea',
        placeholder: 'Brief description of the class',
        maxLength: 500,
        grid: 'full'
      },
      {
        name: 'isActive',
        label: 'Is Active',
        type: 'checkbox',
        grid: 'half'
      }
    ];
  }
}
