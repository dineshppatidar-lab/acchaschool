import { Component, OnInit, signal } from '@angular/core';
import { Router } from '@angular/router';
import { AcademicService } from '../../services/academic.service';
import { Class } from '../../shared/models/academic.models';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { RouterModule } from '@angular/router';
import { MatTableModule } from '@angular/material/table';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatChipsModule } from '@angular/material/chips';
import { MatMenuModule } from '@angular/material/menu';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatDividerModule } from '@angular/material/divider';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSortModule } from '@angular/material/sort';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Observable, combineLatest, BehaviorSubject } from 'rxjs';
import { delay, map, startWith, debounceTime, distinctUntilChanged, take } from 'rxjs/operators';
import { CanWriteDirective, CanDeleteDirective } from '../../core/directives/permission.directive';
import { Permission } from '../../core/models/permission.model';

@Component({
  selector: 'app-academic-list',
  standalone: true,
  imports: [
    CommonModule, 
    FormsModule, 
    ReactiveFormsModule,
    MatIconModule, 
    MatButtonModule, 
    RouterModule, 
    MatTableModule,
    MatCardModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatChipsModule,
    MatMenuModule,
    MatTooltipModule,
    MatDividerModule,
    MatProgressSpinnerModule,
    MatProgressBarModule,
    MatPaginatorModule,
    MatSortModule,
    CanWriteDirective,
    CanDeleteDirective
  ],
  templateUrl: './academic-list.component.html',
  styleUrls: ['./academic-list.component.scss']
})
export class AcademicListComponent implements OnInit {
  Permission = Permission;
  classes$?: Observable<Class[]>;
  filteredClasses$?: Observable<Class[]>;
  displayedColumns: string[] = ['id', 'name', 'description', 'students', 'subjects', 'actions'];
  
  // View controls
  viewMode: 'cards' | 'table' = 'cards';
  isLoading = signal(true);
  
  // Filter controls
  searchTerm = '';
  selectedType = 'all';
  private searchSubject = new BehaviorSubject<string>('');
  private typeFilterSubject = new BehaviorSubject<string>('all');
  
  // Statistics
  statistics = {
    totalClasses: 0,
    totalStudents: 0,
    activeClasses: 0,
    averageClassSize: 0
  };

  constructor(private academicService: AcademicService, private router: Router) {}

  /** Real per-class aggregates keyed by class id (issue #7) */
  statsByClassId: Record<number, { studentCount: number; sectionCount: number; subjectCount: number }> = {};

  ngOnInit() {
    this.loadClasses();
    this.setupFilters();
  }

  loadClasses() {
    console.log('Loading classes...');
    this.isLoading.set(true);
    this.classes$ = this.academicService.getAll().pipe(
      delay(500),
      map((classes: Class[]) => {
        this.isLoading.set(false);
        this.updateStatistics(classes);
        return classes;
      })
    );
    // Real per-class aggregates (issue #7) — merged into the class objects so the
    // table rows and stat cards show actual counts instead of hardcoded values.
    this.academicService.getStatistics().subscribe({
      next: (statsByClassId) => {
        this.statsByClassId = statsByClassId;
        this.classes$ = this.classes$!.pipe(
          map((classes: Class[]) => classes.map(c => ({
            ...c,
            studentCount: statsByClassId[c.id]?.studentCount ?? 0,
            sectionCount: statsByClassId[c.id]?.sectionCount ?? 0,
            subjectCount: statsByClassId[c.id]?.subjectCount ?? 0
          })))
        );
        // Recompute totals once real counts arrive
        this.classes$!
          .pipe(take(1))
          .subscribe((classes: Class[]) => this.updateStatistics(classes));
      },
      error: (err) => console.error('Failed to load class statistics:', err)
    });
  }
  
  setupFilters() {
    if (this.classes$) {
      this.filteredClasses$ = combineLatest([
        this.classes$,
        this.searchSubject.pipe(
          debounceTime(300),
          distinctUntilChanged(),
          startWith('')
        ),
        this.typeFilterSubject.pipe(
          startWith('all')
        )
      ]).pipe(
        map(([classes, searchTerm, typeFilter]) => 
          this.filterClasses(classes, searchTerm, typeFilter)
        )
      );
    }
  }

  private filterClasses(classes: Class[], searchTerm: string, typeFilter: string): Class[] {
    return classes.filter(classItem => {
      const matchesSearch = !searchTerm || 
        classItem.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        classItem.description?.toLowerCase().includes(searchTerm.toLowerCase());
      
      const matchesType = typeFilter === 'all'; // Simplified for now
      
      return matchesSearch && matchesType;
    });
  }
  
  private updateStatistics(classes: Class[]) {
    const totalStudents = classes.reduce((sum, cls) => sum + (cls.studentCount ?? 0), 0);
    const sizedClasses = classes.filter(c => (c.studentCount ?? 0) > 0);
    this.statistics = {
      totalClasses: classes.length,
      totalStudents,
      activeClasses: classes.length, // All classes active for now
      averageClassSize: sizedClasses.length > 0
        ? Math.round(totalStudents / sizedClasses.length)
        : 0
    };
  }

  onSearchChange(value: string) {
    this.searchTerm = value;
    this.searchSubject.next(value);
  }

  onTypeFilterChange(value: string) {
    this.selectedType = value;
    this.typeFilterSubject.next(value);
  }

  toggleViewMode() {
    this.viewMode = this.viewMode === 'cards' ? 'table' : 'cards';
  }

  editClass(id?: number) {
    if (id) {
      this.router.navigate(['/app/academic/edit', id]);
    }
  }

  addClass() {
    this.router.navigate(['/app/academic/form']);
  }

  deleteClass(id?: number) {
    if (id && confirm('Are you sure you want to delete this class?')) {
      this.academicService.delete(id).subscribe(() => {
        this.loadClasses();
      });
    }
  }

  exportClasses() {
    // Implement export functionality
    console.log('Export classes');
  }

  refreshList() {
    this.loadClasses();
  }

  // Enhanced functionality for modern UI
  selectedStatus = 'all';

  setViewMode(mode: 'cards' | 'table') {
    this.viewMode = mode;
  }

  clearFilters() {
    this.searchTerm = '';
    this.selectedType = 'all';
    this.selectedStatus = 'all';
    this.loadClasses();
  }

  // Progress bar calculation methods
  getActiveClassesPercentage(): number {
    if (this.statistics.totalClasses === 0) return 0;
    return Math.round((this.statistics.activeClasses / this.statistics.totalClasses) * 100);
  }

  getStudentsProgressPercentage(): number {
    // Assuming max capacity of 2000 students for the school
    const maxCapacity = 2000;
    if (this.statistics.totalStudents === 0) return 0;
    return Math.min(Math.round((this.statistics.totalStudents / maxCapacity) * 100), 100);
  }

  getClassSizePercentage(): number {
    // Optimal class size range is 25-30 students
    const optimalSize = 30;
    if (this.statistics.averageClassSize === 0) return 0;
    return Math.min(Math.round((this.statistics.averageClassSize / optimalSize) * 100), 100);
  }
}