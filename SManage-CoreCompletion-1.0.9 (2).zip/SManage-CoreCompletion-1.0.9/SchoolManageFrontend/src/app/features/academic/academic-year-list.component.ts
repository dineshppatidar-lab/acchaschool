import { Component, OnInit, signal } from '@angular/core';
import { Router } from '@angular/router';
import { AdvancedAcademicService } from '../../services/advanced-academic.service';
import { AcademicYear } from '../../shared/models/academic.models';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { RouterModule } from '@angular/router';
import { MatTableModule } from '@angular/material/table';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatMenuModule } from '@angular/material/menu';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Observable, BehaviorSubject } from 'rxjs';
import { delay, map, startWith, debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { CanWriteDirective, CanDeleteDirective } from '../../core/directives/permission.directive';
import { Permission } from '../../core/models/permission.model';

@Component({
  selector: 'app-academic-year-list',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatIconModule,
    MatButtonModule,
    RouterModule,
    MatTableModule,
    MatCardModule,
    MatFormFieldModule,
    MatInputModule,
    MatMenuModule,
    MatTooltipModule,
    MatProgressSpinnerModule,
    CanWriteDirective,
    CanDeleteDirective
  ],
  templateUrl: './academic-year-list.component.html',
  styleUrls: ['./academic-year-list.component.scss']
})
export class AcademicYearListComponent implements OnInit {
  Permission = Permission;
  years$?: Observable<AcademicYear[]>;
  displayedColumns: string[] = ['id', 'name', 'actions'];

  isLoading = signal(true);
  searchTerm = '';
  private searchSubject = new BehaviorSubject<string>('');

  constructor(private advancedAcademicService: AdvancedAcademicService, private router: Router) {}

  ngOnInit() {
    this.loadYears();
  }

  loadYears() {
    console.log('Loading academic years...');
    this.isLoading.set(true);
    this.years$ = this.advancedAcademicService.getAcademicYears().pipe(
      delay(500),
      map((years: AcademicYear[]) => {
        this.isLoading.set(false);
        return years;
      })
    );
  }

  onSearchChange(event: Event) {
    const target = event.target as HTMLInputElement;
    this.searchTerm = target.value;
    this.searchSubject.next(this.searchTerm);
  }

  createYear() {
    this.router.navigate(['/app/academic/years/form']);
  }

  editYear(id: number) {
    this.router.navigate(['/app/academic/years/edit', id]);
  }

  deleteYear(id: number) {
    if (confirm('Are you sure you want to delete this academic year?')) {
      // API call would go here
    }
  }
}
