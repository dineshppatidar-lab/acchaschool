import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnDestroy, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatSelectModule } from '@angular/material/select';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatIconModule } from '@angular/material/icon';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatDividerModule } from '@angular/material/divider';
import { MatTooltipModule } from '@angular/material/tooltip';
import { StudentEnquiryService, StudentEnquiry } from '../../shared/services/student-enquiry.service';
import { MasterDataService, DropdownItem } from '../../core/services/master-data.service';
import { AcademicYearContextService } from '../../shared/services/academic-year-context.service';
import { StudentPageHeaderComponent } from '../../shared/components/students-module/student-page-header.component';

/**
 * Student Enquiry — captures pre-admission enquiries for information only.
 * Stored in the StudentEnquiries table; NO relation to the admission form
 * or the Students table. Only Student Name and Contact No are mandatory.
 * Also handles edit mode via /app/students/enquiry/edit/:id.
 *
 * The "Class Interested In" dropdown follows the app-wide academic year
 * context (the year picker in the top bar) — classes are reloaded whenever
 * the selected academic year changes.
 */
@Component({
  selector: 'app-student-enquiry',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterLink,
    MatCardModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatSelectModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatIconModule,
    MatSnackBarModule,
    MatProgressSpinnerModule,
    MatDividerModule,
    MatTooltipModule,
    StudentPageHeaderComponent
  ],
  templateUrl: './student-enquiry.component.html',
  styleUrls: ['./student-enquiry.component.scss']
})
export class StudentEnquiryComponent implements OnInit, OnDestroy {
  enquiryForm!: FormGroup;
  isEditMode = signal(false);
  editId: number | null = null;
  saving = signal(false);
  loading = signal(false);
  classes = signal<any[]>([]);
  loadingClasses = signal(false);
  selectedAcademicYearId = signal<any>(null);
  sources = ['Walk-in', 'Phone', 'Website', 'Reference', 'Advertisement', 'Other'];
  statuses = ['New', 'Contacted', 'Converted', 'Closed'];
  recentEnquiries = signal<any[]>([]);

  private destroy$ = new Subject<void>();

  constructor(
    private fb: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private enquiryService: StudentEnquiryService,
    private masterData: MasterDataService,
    private academicYearContext: AcademicYearContextService,
    private snackBar: MatSnackBar,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    const idParam = this.route.snapshot.paramMap.get('id');
    this.isEditMode.set(!!idParam);
    this.editId = idParam ? Number(idParam) : null;

    this.enquiryForm = this.fb.group({
      studentName: ['', Validators.required],
      contactNo: ['', Validators.required],
      email: ['', [Validators.email]],
      classInterestedIn: [null],
      source: [null],
      enquiryDate: [new Date()],
      notes: [''],
      status: [null]
    });

    // Classes follow the global academic year context (top-bar year picker)
    this.academicYearContext.selectedAcademicYear$
      .pipe(takeUntil(this.destroy$))
      .subscribe(yearId => {
        this.selectedAcademicYearId.set(yearId);
        if (yearId != null) {
          this.loadClassesForYear(yearId);
        }
      });
    this.academicYearContext.loadAcademicYears()
      .pipe(takeUntil(this.destroy$))
      .subscribe();

    if (this.isEditMode()) {
      this.loadForEdit();
    } else {
      this.loadRecent();
    }
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  loadClassesForYear(yearId: number): void {
    this.loadingClasses.set(true);
    this.masterData.getClassesByAcademicYear(yearId).subscribe({
      next: (classes) => {
        this.classes.set(classes || []);
        this.loadingClasses.set(false);
        // Drop selected class if it no longer exists in the new year's list
        const current = this.enquiryForm.get('classInterestedIn')?.value;
        if (current && !this.classes().some(c => c.name === current)) {
          this.enquiryForm.get('classInterestedIn')?.setValue(null);
        }
        this.cdr.markForCheck();
      },
      error: () => {
        this.classes.set([]);
        this.loadingClasses.set(false);
        this.cdr.markForCheck();
      }
    });
  }

  loadForEdit(): void {
    if (this.editId == null) { return; }
    this.loading.set(true);
    this.enquiryService.getEnquiry(this.editId).subscribe({
      next: (resp) => {
        const e = resp?.data ?? resp;
        if (e) {
          this.enquiryForm.patchValue({
            studentName: e.studentName ?? '',
            contactNo: e.contactNo ?? '',
            email: e.email ?? '',
            classInterestedIn: e.classInterestedIn ?? null,
            source: e.source ?? null,
            enquiryDate: e.enquiryDate ? new Date(e.enquiryDate) : null,
            notes: e.notes ?? '',
            status: e.status ?? null
          });
        }
        this.loading.set(false);
        this.cdr.markForCheck();
      },
      error: () => {
        this.loading.set(false);
        this.snackBar.open('Failed to load enquiry', 'Close', { duration: 4000 });
        this.cdr.markForCheck();
      }
    });
  }

  loadRecent(): void {
    this.enquiryService.getEnquiries().subscribe({
      next: (resp) => {
        const data = resp?.data ?? resp;
        this.recentEnquiries.set(Array.isArray(data) ? data.slice(0, 5) : []);
        this.cdr.markForCheck();
      },
      error: () => {
        this.recentEnquiries.set([]);
      }
    });
  }

  enquiryDateOf(e: StudentEnquiry): Date {
    return new Date(e.enquiryDate ?? e.createdOn);
  }

  selectedYearLabel(): string {
    return this.selectedAcademicYearId()
      ? this.academicYearContext.getYearName(this.selectedAcademicYearId())
      : '';
  }

  onSubmit(): void {
    if (this.enquiryForm.invalid || this.saving()) {
      this.enquiryForm.markAllAsTouched();
      return;
    }

    this.saving.set(true);
    const v = this.enquiryForm.value;
    const payload: Partial<StudentEnquiry> = {
      studentName: v.studentName,
      contactNo: v.contactNo,
      email: v.email || null,
      classInterestedIn: v.classInterestedIn || null,
      source: v.source || null,
      enquiryDate: v.enquiryDate || new Date(),
      notes: v.notes || null,
      status: v.status || null
    };

    const request$ = this.isEditMode() && this.editId != null
      ? this.enquiryService.updateEnquiry(this.editId, payload)
      : this.enquiryService.createEnquiry(payload);

    request$.subscribe({
      next: (resp) => {
        this.saving.set(false);
        const msg = resp?.message ?? (this.isEditMode() ? 'Enquiry updated successfully' : 'Enquiry saved successfully');
        this.snackBar.open(msg, 'Close', { duration: 3500 });
        // Redirect to the list page so the user sees the saved result
        this.router.navigate(['/app/students/enquiry-list']);
      },
      error: () => {
        this.saving.set(false);
        this.snackBar.open('Failed to save enquiry. Please try again.', 'Close', { duration: 4000 });
        this.cdr.markForCheck();
      }
    });
  }

  resetForm(): void {
    if (this.isEditMode()) { return; }
    this.enquiryForm.reset({
      studentName: '', contactNo: '', email: '', classInterestedIn: null,
      source: null, enquiryDate: new Date(), notes: '', status: null
    });
  }

  cancelForm(): void {
    this.router.navigate(['/app/students/enquiry-list']);
  }
}
