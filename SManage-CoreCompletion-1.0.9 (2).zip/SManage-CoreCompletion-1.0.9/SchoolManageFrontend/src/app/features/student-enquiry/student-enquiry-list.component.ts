import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormControl } from '@angular/forms';
import { RouterLink, Router } from '@angular/router';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule, PageEvent } from '@angular/material/paginator';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { StudentEnquiryService, StudentEnquiry } from '../../shared/services/student-enquiry.service';
import { ConfirmDialogComponent, ConfirmDialogData } from '../../shared/confirm-dialog.component';
import { StudentPageHeaderComponent } from '../../shared/components/students-module/student-page-header.component';

/**
 * Lists all captured student enquiries (informational only — no relation to
 * the Students table). Search by name/contact/email, filter by status and
 * source, edit (opens the full enquiry form) and delete (confirmation dialog).
 */
@Component({
  selector: 'app-student-enquiry-list',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterLink,
    MatDialogModule,
    MatButtonModule,
    MatIconModule,
    MatCardModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatTableModule,
    MatPaginatorModule,
    MatSnackBarModule,
    MatProgressSpinnerModule,
    MatTooltipModule,
    StudentPageHeaderComponent
  ],
  templateUrl: './student-enquiry-list.component.html',
  styleUrls: ['./student-enquiry-list.component.scss']
})
export class StudentEnquiryListComponent implements OnInit {
  displayedColumns = ['student', 'contactNo', 'classInterestedIn', 'source', 'status', 'enquiryDate', 'actions'];
  allEnquiries = signal<any[]>([]);
  pagedEnquiries: StudentEnquiry[] = [];
  filtered: StudentEnquiry[] = [];
  totalCount = 0;
  pageIndex = signal(0);
  pageSize = 10;
  loading = signal(true);

  searchControl = new FormControl('');
  statusFilterControl = new FormControl('');
  sourceFilterControl = new FormControl('');

  statuses = ['New', 'Contacted', 'Converted', 'Closed'];
  sources = ['Walk-in', 'Phone', 'Website', 'Reference', 'Advertisement', 'Other'];

  constructor(
    private enquiryService: StudentEnquiryService,
    private dialog: MatDialog,
    private router: Router,
    private snackBar: MatSnackBar,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.searchControl.valueChanges.subscribe(() => {
      this.pageIndex.set(0);
      this.applyFilterAndPage();
    });
    this.statusFilterControl.valueChanges.subscribe(() => {
      this.pageIndex.set(0);
      this.applyFilterAndPage();
    });
    this.sourceFilterControl.valueChanges.subscribe(() => {
      this.pageIndex.set(0);
      this.applyFilterAndPage();
    });
    this.load();
  }

  get hasActiveFilters(): boolean {
    return !!(this.searchControl.value || this.statusFilterControl.value || this.sourceFilterControl.value);
  }

  clearFilters(): void {
    this.searchControl.setValue('');
    this.statusFilterControl.setValue('');
    this.sourceFilterControl.setValue('');
  }

  load(): void {
    this.loading.set(true);
    this.enquiryService.getEnquiries().subscribe({
      next: (resp) => {
        const data = resp?.data ?? resp;
        this.allEnquiries.set(Array.isArray(data) ? data : []);
        this.loading.set(false);
        this.applyFilterAndPage();
      },
      error: () => {
        this.loading.set(false);
        this.allEnquiries.set([]);
        this.applyFilterAndPage();
        this.snackBar.open('Failed to load enquiries', 'Close', { duration: 4000 });
      }
    });
  }

  applyFilterAndPage(): void {
    const term = (this.searchControl.value || '').toString().trim().toLowerCase();
    const statusFilter = (this.statusFilterControl.value || '').toString();
    const sourceFilter = (this.sourceFilterControl.value || '').toString();

    this.filtered = this.allEnquiries().filter(e => {
      const matchesTerm = !term ||
        (e.studentName || '').toLowerCase().includes(term) ||
        (e.contactNo || '').includes(term) ||
        (e.email || '').toLowerCase().includes(term);
      const matchesStatus = !statusFilter || e.status === statusFilter;
      const matchesSource = !sourceFilter || e.source === sourceFilter;
      return matchesTerm && matchesStatus && matchesSource;
    });

    this.totalCount = this.filtered.length;
    const start = this.pageIndex() * this.pageSize;
    this.pagedEnquiries = this.filtered.slice(start, start + this.pageSize);
    this.cdr.markForCheck();
  }

  onPage(event: PageEvent): void {
    this.pageIndex.set(event.pageIndex);
    this.pageSize = event.pageSize;
    this.applyFilterAndPage();
  }

  /** Range text for the summary line, e.g. "1–10 of 23" */
  rangeLabel(): string {
    if (this.totalCount === 0) { return '0'; }
    const from = this.pageIndex() * this.pageSize + 1;
    const to = Math.min((this.pageIndex() + 1) * this.pageSize, this.totalCount);
    return `${from}–${to} of ${this.totalCount}`;
  }

  statusClass(status: string | null | undefined): string {
    return 'stu-badge-' + (status || 'new').toLowerCase();
  }

  initials(name: string): string {
    return (name || '?')
      .split(' ')
      .filter(Boolean)
      .slice(0, 2)
      .map(w => w[0].toUpperCase())
      .join('');
  }

  enquiryDateOf(e: StudentEnquiry): Date {
    return new Date(e.enquiryDate ?? e.createdOn);
  }

  /** Opens the full enquiry form in edit mode */
  openEdit(e: StudentEnquiry): void {
    this.router.navigate(['/app/students/enquiry/edit', e.id]);
  }

  /** Deletes the enquiry after a confirmation dialog */
  confirmDelete(e: StudentEnquiry): void {
    const ref = this.dialog.open(ConfirmDialogComponent, {
      data: {
        title: 'Delete enquiry?',
        message: `This will permanently delete the enquiry for "${e.studentName}". This action cannot be undone.`,
        confirmText: 'Delete',
        cancelText: 'Cancel',
        icon: 'delete_forever',
        severity: 'danger'
      } as ConfirmDialogData
    });

    ref.afterClosed().subscribe((ok) => {
      if (!ok) { return; }
      this.enquiryService.deleteEnquiry(e.id).subscribe({
        next: () => {
          this.snackBar.open('Enquiry deleted', 'Close', { duration: 3000 });
          this.load();
        },
        error: () => this.snackBar.open('Failed to delete enquiry', 'Close', { duration: 4000 })
      });
    });
  }
}
