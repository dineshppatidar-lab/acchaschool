import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { StaffImportExportComponent } from './staff-import-export.component';
import { StaffFormComponent } from '../../staff-form/staff-form';
import { StaffListComponent } from './staff-list.component';

const routes: Routes = [
  { path: '', redirectTo: 'list', pathMatch: 'full' },
  { path: 'import-export', component: StaffImportExportComponent },
  { path: 'form', component: StaffFormComponent },
  { path: 'list', component: StaffListComponent },
  { path: 'payroll', component: StaffListComponent },
  { path: 'edit/:id', component: StaffFormComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class StaffRoutingModule { }
