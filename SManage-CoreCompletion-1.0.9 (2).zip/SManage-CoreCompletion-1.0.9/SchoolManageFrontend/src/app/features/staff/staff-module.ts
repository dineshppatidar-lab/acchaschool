import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { StaffImportExportComponent } from './staff-import-export.component';
import { StaffListComponent } from './staff-list.component';
import { StaffFormComponent } from '../../staff-form/staff-form';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { StaffRoutingModule } from './staff-routing.module';

@NgModule({ 
  imports: [
    CommonModule,
    MatCardModule,
    MatButtonModule,
    StaffRoutingModule,
    StaffImportExportComponent,
    StaffListComponent,
    StaffFormComponent
  ],
  exports: [StaffImportExportComponent, StaffListComponent, StaffFormComponent]
})
export class StaffModule { }
