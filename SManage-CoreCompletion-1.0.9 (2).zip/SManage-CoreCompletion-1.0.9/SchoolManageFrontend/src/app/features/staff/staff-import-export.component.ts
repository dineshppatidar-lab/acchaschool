import { Component, signal } from '@angular/core';
import { StaffImportExportService } from '../../services/staff-import-export.service';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { CommonModule } from '@angular/common';
import { PageHeaderComponent } from '../../shared/components/page-patterns/index';

@Component({
  selector: 'app-staff-import-export',
  standalone: true,
  imports: [CommonModule, MatButtonModule, MatIconModule, MatCardModule, PageHeaderComponent],
  templateUrl: './staff-import-export.component.html',
  styleUrls: ['./staff-import-export.component.scss']
})
export class StaffImportExportComponent {
  file: File | null = null;
  fileName = signal('');
  message = signal('');
  constructor(private service: StaffImportExportService) {}

  onFileChange(event: any) {
    this.file = event.target.files[0];
    this.fileName.set(this.file?.name || '');
  }

  import() {
    if (!this.file) return;
    this.service.importStaff(this.file).subscribe(res => {
      this.message.set(`Imported ${res.count} staff.`);
    });
  }

  export() {
    this.service.exportStaff().subscribe(blob => {
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `staff_${new Date().toISOString().split('T')[0]}.xlsx`;
      a.click();
      window.URL.revokeObjectURL(url);
    });
  }
}
