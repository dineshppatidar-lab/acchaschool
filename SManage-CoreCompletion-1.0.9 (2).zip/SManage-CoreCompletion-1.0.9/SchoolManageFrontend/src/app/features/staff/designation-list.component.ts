import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatTableModule } from '@angular/material/table';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { PageHeaderComponent } from '../../shared/components/page-patterns/index';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { finalize } from 'rxjs';
import { PromptDialogComponent } from '../../shared/prompt-dialog.component';
import { ConfirmDialogComponent } from '../../shared/confirm-dialog.component';
import { MasterDataService } from '../../services/master-data.service';
import { DialogUtils } from '../../shared/dialog-utils';

export interface LookupRow {
  value: number;
  label: string;
}

@Component({
  selector: 'app-designation-list',
  standalone: true,
  imports: [
    CommonModule,
    MatIconModule,
    MatButtonModule,
    MatTableModule,
    MatCardModule,
    MatFormFieldModule,
    MatInputModule,
    MatTooltipModule,
    MatProgressSpinnerModule,
    MatSnackBarModule,
    PageHeaderComponent
  ],
  templateUrl: './designation-list.component.html',
  styleUrls: ['./designation-list.component.scss', '../../shared/styles/master-list.scss']
})
export class DesignationListComponent implements OnInit {
  designations = signal<any[]>([]);
  filteredDesignations: LookupRow[] = [];
  // NOTE: internal row.value still holds the DB id for edit/delete — it is just not shown.
  displayedColumns: string[] = ['label', 'actions'];

  // Zoneless CD: signal writes schedule their own change-detection pass, so mutating
  // this from HTTP / dialog-close callbacks can never trip NG0100.
  readonly isLoading = signal(true);
  searchTerm = '';
  readonly saving = signal(false);

  constructor(
    private masterDataService: MasterDataService,
    private dialog: MatDialog,
    private dialogUtils: DialogUtils,
    private snackBar: MatSnackBar
  ) {}

  ngOnInit() {
    this.loadDesignations();
  }

  loadDesignations() {
    this.isLoading.set(true);
    // Generic DB-backed endpoint: rows carry real IDs so edit/delete hit the right row
    this.masterDataService.getLookupData('staff-positions').subscribe({
      next: (rows) => {
        // Accept both the DB-backed [{value,label}] shape and plain string[] fallback
        this.designations.set(this.toRows(rows));
        this.applySearch();
        this.isLoading.set(false);
      },
      error: (err) => {
        console.error('Error loading designations:', err);
        this.isLoading.set(false);
        this.snackBar.open('Failed to load designations', 'Close', { duration: 3000 });
      }
    });
  }

  /** Backend returns [{value,label}] for DB-backed lookups; older deployments may return string[]. */
  private toRows(rows: any): LookupRow[] {
    if (!Array.isArray(rows)) return [];
    return rows.map((r: any, i: number) =>
      typeof r === 'string' ? { value: i + 1, label: r } : { value: r.value ?? i + 1, label: r.label ?? String(r) }
    );
  }

  applySearch() {
    const term = this.searchTerm.trim().toLowerCase();
    this.filteredDesignations = !term
      ? [...this.designations()]
      : this.designations().filter(d => d.label.toLowerCase().includes(term));
  }

  onSearchChange(event: Event) {
    this.searchTerm = (event.target as HTMLInputElement).value;
    this.applySearch();
  }

  createDesignation() {
    this.openDialog(null);
  }

  editDesignation(row: LookupRow) {
    this.openDialog(row);
  }

  private openDialog(row: LookupRow | null) {
    const dialogRef = this.dialog.open(PromptDialogComponent, {
        ...this.dialogUtils.getMobileConfig({ width: '420px' }),
        data: {
                title: row ? 'Edit Designation' : 'New Designation',
        message: row
          ? 'Rename this designation. Staff already using it keep their records.'
          : 'Enter a name for the new designation.',
        initialValue: row?.label ?? '',
        placeholder: 'Designation name',
        confirmText: row ? 'Save' : 'Create',
        icon: 'badge'
      }
    });

    dialogRef.afterClosed().subscribe((result: string | null) => {
      if (!result) return;
      this.saving.set(true);
      const request = row
        ? this.masterDataService.updateLookupData('staff-positions', row.value, { value: row.value, label: result })
        : this.masterDataService.createLookupData('staff-positions', { value: 0, label: result });

      request
        .pipe(finalize(() => {
          this.saving.set(false);
        }))
        .subscribe({
          next: () => {
            this.snackBar.open(row ? 'Designation updated' : 'Designation created', 'Close', { duration: 2500 });
            this.loadDesignations();
          },
          error: (err) => {
            this.snackBar.open(err?.error?.message || err?.error?.title || 'Failed to save designation', 'Close', { duration: 3500 });
          }
        });
    });
  }

  deleteDesignation(row: LookupRow) {
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
        ...this.dialogUtils.getMobileConfig({ width: '400px' }),
        data: {
                title: 'Delete designation?',
        message: `Delete "${row.label}"? Staff already using it keep their records, but it won't be selectable for new staff.`,
        confirmText: 'Delete',
        cancelText: 'Cancel',
        icon: 'delete_forever',
        severity: 'danger' as const
      }
    });

    dialogRef.afterClosed().subscribe((confirmed: boolean) => {
      if (!confirmed) return;
      this.masterDataService.deleteLookupData('staff-positions', row.value).subscribe({
        next: () => {
          this.snackBar.open('Designation deleted', 'Close', { duration: 2500 });
          this.loadDesignations();
        },
        error: (err) => {
          this.snackBar.open(err?.error?.message || 'Failed to delete designation', 'Close', { duration: 3500 });
        }
      });
    });
  }
}

