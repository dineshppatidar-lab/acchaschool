import { ChangeDetectorRef, Component, Inject, OnInit, signal } from '@angular/core';
import { StaffService, Staff } from '../../services/staff.service';
import { Router } from '@angular/router';

import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatTableModule } from '@angular/material/table';
import { MatIconModule } from '@angular/material/icon';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatChipsModule } from '@angular/material/chips';
import { MatMenuModule } from '@angular/material/menu';
import { MatDialog, MatDialogModule, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSortModule } from '@angular/material/sort';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatDividerModule } from '@angular/material/divider';
import { RouterModule } from '@angular/router';
import { ReactiveFormsModule, FormControl } from '@angular/forms';
import { Observable, combineLatest, of } from 'rxjs';
import { map, startWith, debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { MasterDataService } from '../../services/master-data.service';
import { CanWriteDirective, CanDeleteDirective } from '../../core/directives/permission.directive';
import { Permission } from '../../core/models/permission.model';
import { PageHeaderComponent, KpiCardComponent } from '../../shared/components/page-patterns/index';
import { DialogUtils } from '../../shared/dialog-utils';

@Component({
  selector: 'app-staff-list',
  standalone: true,
  imports: [
    CommonModule, 
    MatCardModule, 
    MatButtonModule, 
    MatTableModule, 
    MatIconModule, 
    MatFormFieldModule, 
    MatInputModule, 
    MatSelectModule, 
    MatChipsModule, 
    MatMenuModule, 
    MatDialogModule, 
    MatSnackBarModule, 
    MatPaginatorModule, 
    MatSortModule, 
    MatProgressSpinnerModule,
    MatProgressBarModule,
    MatTooltipModule, 
    MatDatepickerModule,
    MatDividerModule,
    RouterModule, 
    ReactiveFormsModule,
    CanWriteDirective,
    CanDeleteDirective,
    PageHeaderComponent,
    KpiCardComponent
  ],
  templateUrl: './staff-list.component.html',
  styleUrls: ['./staff-list.component.scss']
})
export class StaffListComponent implements OnInit {
  Permission = Permission;
  staffMembers = signal<any[]>([]);
  filteredStaff$?: Observable<Staff[]>;
  displayedColumns: string[] = ['staff', 'position', 'contact', 'qualification', 'experience', 'actions'];
  
  // View Controls
  viewMode: 'card' | 'table' = 'table';
  isLoading = signal(false);
  
  // Filter Controls
  searchControl = new FormControl('');
  positionFilterControl = new FormControl('');
  qualificationFilterControl = new FormControl('');
  
  // Staff Data (filter options come from the DB-backed lookups — no static lists)
  positions$!: Observable<string[]>;
  qualifications$!: Observable<string[]>;
  positions = signal<any[]>([]);
  qualifications = signal<any[]>([]);

  constructor(
    private staffService: StaffService, 
    public router: Router, 
    private cdr: ChangeDetectorRef,
    private masterDataService: MasterDataService,
    private dialog: MatDialog,
    private snack: MatSnackBar,
    private dialogUtils: DialogUtils
  ) { }

  ngOnInit(): void {
    this.loadStaff();
    this.setupFiltering();
    this.loadLookups();
  }

  loadStaff(): void {
    this.isLoading.set(true);
    console.log('👨‍🏫 Loading staff list...');
    this.staffService.getAll().subscribe({
      next: (data) => {
        console.log('👨‍🏫 Staff loaded successfully:', data);
        console.log('👨‍🏫 Number of staff members:', data?.length || 0);
        this.staffMembers.set(data);
        this.isLoading.set(false);
        this.setupFiltering(); // Re-setup filtering after data loads
        this.cdr.markForCheck();
      },
      error: (err) => {
        console.error('❌ Error loading staff:', err);
        console.error('❌ Error status:', err.status);
        console.error('❌ Error message:', err.message);
        this.isLoading.set(false);
        this.cdr.markForCheck();
      }
    });
  }

  loadLookups(): void {
    this.positions$ = this.masterDataService.getStaffPositions();
    this.positions$.subscribe(res => {
      this.positions.set(res || []);
    });

    this.qualifications$ = this.masterDataService.getStaffQualifications();
    this.qualifications$.subscribe(res => {
      this.qualifications.set(res || []);
    });
  }

  setupFiltering(): void {
    const staff$ = of(this.staffMembers());

    this.filteredStaff$ = combineLatest([
      staff$,
      this.searchControl.valueChanges.pipe(startWith(''), debounceTime(300), distinctUntilChanged()),
      this.positionFilterControl.valueChanges.pipe(startWith('')),
      this.qualificationFilterControl.valueChanges.pipe(startWith(''))
    ]).pipe(
      map(([staff, search, position, qualification]) => {
        return staff.filter(member => {
          const matchesSearch = !search || 
            member.firstName?.toLowerCase().includes(search.toLowerCase()) ||
            member.lastName?.toLowerCase().includes(search.toLowerCase()) ||
            member.email?.toLowerCase().includes(search.toLowerCase()) ||
            member.position?.toLowerCase().includes(search.toLowerCase());
          const matchesPosition = !position || member.position === position;
          const matchesQualification = !qualification || member.qualification?.includes(qualification);

          return matchesSearch && matchesPosition && matchesQualification;
        });
      })
    );
  }

  // Statistics Methods
  getTotalStaff(): number {
    return this.staffMembers()?.length || 0;
  }

  getTeachingStaff(): number {
    const teachingPositions = ['Principal', 'Vice Principal', 'Teacher', 'Assistant Teacher'];
    return this.staffMembers()?.filter(s => teachingPositions.includes(s.position))?.length || 0;
  }

  getNonTeachingStaff(): number {
    const teachingPositions = ['Principal', 'Vice Principal', 'Teacher', 'Assistant Teacher'];
    return this.staffMembers()?.filter(s => !teachingPositions.includes(s.position))?.length || 0;
  }

  getAverageSalary(): number {
    if (!this.staffMembers()?.length) return 0;
    const totalSalary = this.staffMembers().reduce((sum, member) => sum + (member.salary || 0), 0);
    return Math.round(totalSalary / this.staffMembers().length);
  }

  // View Methods
  toggleView(mode: 'card' | 'table') {
    this.viewMode = mode;
  }

  clearFilters() {
    this.searchControl.setValue('');
    this.positionFilterControl.setValue('');
    this.qualificationFilterControl.setValue('');
  }

  // Staff Actions
  editStaff(staff: Staff): void {
    // Route /app/staff/edit/:id reuses the Add Staff form in edit mode.
    this.router.navigate(['/app/staff/edit', staff.id]);
  }

  deleteStaff(staff: Staff): void {
    if (confirm(`Are you sure you want to delete staff member ${staff.firstName} ${staff.lastName}?`)) {
      this.staffService.delete(staff.id!).subscribe(() => {
        this.loadStaff(); // Reload staff after deletion
      });
    }
  }

  viewStaffProfile(staff: Staff): void {
    this.dialog.open(StaffProfileDialog, {
      ...this.dialogUtils.getMobileConfig({ width: '480px', data: { staff } })
    });
  }

  contactStaff(staff: Staff): void {
    this.dialog.open(StaffContactDialog, {
      ...this.dialogUtils.getMobileConfig({ width: '420px', data: { staff } })
    });
  }

  generatePayroll(staff: Staff): void {
    // The payroll module routes all runs at /app/payroll.
    this.router.navigate(['/app/payroll']);
  }

  assignSubjects(staff: Staff): void {
    // No teacher-subject assignment screen exists yet.
    this.snack.open(`Subject assignment for ${staff.firstName} ${staff.lastName} is coming soon`, 'Close', { duration: 3000 });
  }

  viewAttendance(staff: Staff): void {
    // No staff-attendance screen exists yet (the attendance module is student-only).
    this.snack.open(`Attendance tracking for ${staff.firstName} ${staff.lastName} is coming soon`, 'Close', { duration: 3000 });
  }

  // Helper Methods
  getPositionColor(position: string): string {
    const colorMap: { [key: string]: string } = {
      'Principal': '#9c27b0',
      'Vice Principal': '#673ab7',
      'Teacher': '#3157a4',
      'Assistant Teacher': '#03a9f4',
      'Librarian': 'var(--md-success)',
      'Lab Assistant': '#8bc34a',
      'Clerk': 'var(--md-warning)',
      'Accountant': 'var(--md-error)',
      'Security Guard': '#795548',
      'Driver': '#607d8b',
      'Peon': 'var(--md-outline)'
    };
    const normalizedPosition = position?.trim().toLowerCase() || '';
    const matchingRole = Object.keys(colorMap)
      .sort((firstRole, secondRole) => secondRole.length - firstRole.length)
      .find(role => normalizedPosition.startsWith(role.toLowerCase()));
    return matchingRole ? colorMap[matchingRole] : 'var(--color-text-secondary)';
  }

  getPositionIcon(position: string): string {
    const iconMap: { [key: string]: string } = {
      'Principal': 'account_balance',
      'Vice Principal': 'supervisor_account',
      'Teacher': 'school',
      'Assistant Teacher': 'person',
      'Librarian': 'local_library',
      'Lab Assistant': 'science',
      'Clerk': 'description',
      'Accountant': 'account_balance_wallet',
      'Security Guard': 'security',
      'Driver': 'directions_car',
      'Peon': 'cleaning_services'
    };
    return iconMap[position] || 'person';
  }

  getExperience(hireDate: string): string {
    if (!hireDate) return '0 years';
    const hire = new Date(hireDate);
    const today = new Date();
    const years = today.getFullYear() - hire.getFullYear();
    const months = today.getMonth() - hire.getMonth();
    
    if (years === 0) {
      return months <= 0 ? '< 1 month' : `${months} months`;
    }
    
    return years === 1 ? '1 year' : `${years} years`;
  }

  formatSalary(salary: number): string {
    if (!salary) return 'Not specified';
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR'
    }).format(salary);
  }

  formatPhoneNumber(phone: string): string {
    if (!phone) return 'N/A';
    // Format phone number (adjust based on your locale)
    return phone.replace(/(\d{3})(\d{3})(\d{4})/, '($1) $2-$3');
  }

  getInitials(firstName: string, lastName: string): string {
    const first = firstName ? firstName.charAt(0).toUpperCase() : '';
    const last = lastName ? lastName.charAt(0).toUpperCase() : '';
    return first + last;
  }

  getGenderColor(gender: string): string {
    return gender?.toLowerCase() === 'male' ? 'var(--md-primary-light)' : '#e91e63';
  }

  // Percentage calculation methods for progress bars
  getTeachingStaffPercentage(): number {
    if (this.staffMembers().length === 0) return 0;
    const teachingStaff = this.staffMembers().filter(staff => 
      staff.position?.toLowerCase().includes('teacher') || 
      staff.position?.toLowerCase().includes('principal') ||
      staff.role?.toLowerCase().includes('teacher') ||
      staff.role?.toLowerCase().includes('academic')
    ).length;
    return Math.round((teachingStaff / this.staffMembers().length) * 100);
  }

  getSupportStaffPercentage(): number {
    if (this.staffMembers().length === 0) return 0;
    const supportStaff = this.staffMembers().filter(staff => 
      staff.position?.toLowerCase().includes('assistant') ||
      staff.position?.toLowerCase().includes('clerk') ||
      staff.position?.toLowerCase().includes('guard') ||
      staff.position?.toLowerCase().includes('driver') ||
      staff.position?.toLowerCase().includes('peon') ||
      staff.role?.toLowerCase().includes('support')
    ).length;
    return Math.round((supportStaff / this.staffMembers().length) * 100);
  }

  getSalaryProgressPercentage(): number {
    // Real average salary relative to the highest salary on staff (issue #7).
    // The old version divided by an invented "1 crore budget" — pure fiction.
    const salaries = this.staffMembers().map(s => s.salary || 0).filter(s => s > 0);
    if (salaries.length === 0) return 0;
    const average = salaries.reduce((sum, s) => sum + s, 0) / salaries.length;
    const max = Math.max(...salaries);
    if (max <= 0) return 0;
    return Math.min(Math.round((average / max) * 100), 100);
  }
}

/** Experience duration shared by the card grid and the profile dialog. */
function experienceFor(hireDate: string): string {
  if (!hireDate) return '0 years';
  const hire = new Date(hireDate);
  const today = new Date();
  const years = today.getFullYear() - hire.getFullYear();
  const months = today.getMonth() - hire.getMonth();
  if (years === 0) {
    return months <= 0 ? '< 1 month' : `${months} months`;
  }
  return years === 1 ? '1 year' : `${years} years`;
}

/*
 * View Profile dialog — full detail sheet for one staff member.
 * (There is no dedicated staff profile page yet; this dialog covers the
 * kebab-menu "View Profile" action with the same data.)
 */
@Component({
  selector: 'app-staff-profile-dialog',
  standalone: true,
  imports: [
    CommonModule,
    MatDialogModule,
    MatButtonModule,
    MatIconModule,
    MatDividerModule
  ],
  template: `
    <h2 mat-dialog-title class="profile-title">
      <span class="avatar">{{ initials() }}</span>
      <span>
        {{ staff.firstName }} {{ staff.lastName }}
        <small class="position">{{ staff.position || '—' }}</small>
      </span>
    </h2>

    <mat-dialog-content>
      <div class="detail-group">
        <h4>Personal</h4>
        <div class="detail-row"><span class="label">Date of Birth</span><span class="value">{{ staff.dateOfBirth ? (staff.dateOfBirth | date: 'dd MMM yyyy') : '—' }}</span></div>
        <div class="detail-row"><span class="label">Gender</span><span class="value">{{ staff.gender || '—' }}</span></div>
      </div>

      <div class="detail-group">
        <h4>Contact</h4>
        <div class="detail-row"><span class="label">Email</span><span class="value word-break">{{ staff.email || '—' }}</span></div>
        <div class="detail-row"><span class="label">Phone</span><span class="value">{{ staff.phoneNumber || '—' }}</span></div>
        <div class="detail-row"><span class="label">Address</span><span class="value word-break">{{ addressLine() }}</span></div>
      </div>

      <div class="detail-group">
        <h4>Professional</h4>
        <div class="detail-row"><span class="label">Role</span><span class="value">{{ staff.role || '—' }}</span></div>
        <div class="detail-row"><span class="label">Qualification</span><span class="value">{{ staff.qualification || '—' }}</span></div>
        <div class="detail-row"><span class="label">Specialization</span><span class="value">{{ staff.specialization || '—' }}</span></div>
        <div class="detail-row"><span class="label">Hire Date</span><span class="value">{{ staff.hireDate ? (staff.hireDate | date: 'dd MMM yyyy') : '—' }}</span></div>
        <div class="detail-row"><span class="label">Experience</span><span class="value">{{ experienceFor(staff.hireDate) }}</span></div>
        <div class="detail-row"><span class="label">Salary</span><span class="value">{{ salaryText() }}</span></div>
      </div>
    </mat-dialog-content>

    <mat-dialog-actions align="end">
      <button mat-button mat-dialog-close (click)="close()">Close</button>
    </mat-dialog-actions>
  `,
  styles: [`
    .profile-title { display: flex; align-items: center; gap: 12px; }
    .avatar {
      display: inline-flex; align-items: center; justify-content: center;
      width: 42px; height: 42px; border-radius: 50%;
      background: var(--md-primary-light); color: #fff; font-weight: 700; flex: none;
    }
    .position { display: block; font-size: 12px; color: rgba(0,0,0,.55); }

    .detail-group { margin-bottom: 8px; }
    .detail-group h4 {
      margin: 12px 0 4px; font-size: 13px; font-weight: 700;
      color: rgba(0,0,0,.65); text-transform: uppercase; letter-spacing: .04em;
    }
    .detail-row {
      display: flex; justify-content: space-between; gap: 16px;
      padding: 7px 0; border-bottom: 1px solid rgba(0,0,0,.05); font-size: 14px;
    }
    .detail-row:last-child { border-bottom: none; }
    .label { color: rgba(0,0,0,.55); flex: none; }
    .value { font-weight: 500; text-align: right; }
    .word-break { word-break: break-word; }
  `]
})
export class StaffProfileDialog {
  readonly experienceFor = experienceFor;

  constructor(
    public dialogRef: MatDialogRef<StaffProfileDialog>,
    @Inject(MAT_DIALOG_DATA) public data: { staff: Staff }
  ) {}

  get staff(): Staff { return this.data.staff; }

  close(): void { this.dialogRef.close(); }

  initials(): string {
    const first = this.staff.firstName ? this.staff.firstName.charAt(0).toUpperCase() : '';
    const last = this.staff.lastName ? this.staff.lastName.charAt(0).toUpperCase() : '';
    return first + last;
  }

  addressLine(): string {
    const parts = [this.staff.address, this.staff.city, this.staff.state, this.staff.zipCode].filter(Boolean);
    return parts.length ? parts.join(', ') : '—';
  }

  salaryText(): string {
    if (!this.staff.salary) return 'Not specified';
    return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR' }).format(this.staff.salary);
  }
}

/*
 * Contact dialog — quick way to call or email a staff member.
 */
@Component({
  selector: 'app-staff-contact-dialog',
  standalone: true,
  imports: [CommonModule, MatDialogModule, MatButtonModule, MatIconModule],
  template: `
    <h2 mat-dialog-title>Contact {{ staff.firstName }} {{ staff.lastName }}</h2>
    <mat-dialog-content>
      <div class="contact-row">
        <mat-icon>phone</mat-icon>
        <div class="contact-details">
          <strong>{{ staff.phoneNumber || 'No phone number' }}</strong>
          <small>Phone Number</small>
        </div>
        <a mat-raised-button color="primary"
           [href]="'tel:' + staff.phoneNumber"
           [class.disabled]="!staff.phoneNumber">Call</a>
      </div>

      <div class="contact-row">
        <mat-icon>email</mat-icon>
        <div class="contact-details">
          <strong class="word-break">{{ staff.email || 'No email address' }}</strong>
          <small>Email Address</small>
        </div>
        <a mat-raised-button color="accent"
           [href]="'mailto:' + staff.email"
           [class.disabled]="!staff.email">Email</a>
      </div>
    </mat-dialog-content>

    <mat-dialog-actions align="end">
      <button mat-button mat-dialog-close (click)="close()">Close</button>
    </mat-dialog-actions>
  `,
  styles: [`
    .contact-row {
      display: flex; align-items: center; gap: 12px;
      padding: 10px 0;
    }
    .contact-details { flex: 1; display: flex; flex-direction: column; min-width: 0; }
    .contact-details small { color: rgba(0,0,0,.55); }
    .word-break { word-break: break-word; white-space: normal; }
    a.disabled { pointer-events: none; opacity: .4; }
  `]
})
export class StaffContactDialog {
  constructor(
    public dialogRef: MatDialogRef<StaffContactDialog>,
    @Inject(MAT_DIALOG_DATA) public data: { staff: Staff }
  ) {}

  get staff(): Staff { return this.data.staff; }

  close(): void { this.dialogRef.close(); }
}
