import { Component, inject, OnInit, OnDestroy, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatChipsModule } from '@angular/material/chips';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { FormsModule } from '@angular/forms';
import { DailyOpsService, DailySummaryDto, QuickMarkRequest, FeeReminderRequest } from '../../services/daily-ops.service';
import { AcademicYearContextService, AcademicYearItem } from '../../shared/services/academic-year-context.service';
import { CanWriteDirective } from '../../core/directives/permission.directive';
import { Permission } from '../../core/models/permission.model';
import { BackButtonComponent } from '../../shared/components/back-button.component';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-daily-ops',
  standalone: true,
  imports: [CommonModule, FormsModule, MatCardModule, MatButtonModule, MatIconModule, MatChipsModule, MatProgressSpinnerModule, MatSnackBarModule, MatFormFieldModule, MatInputModule, MatSelectModule, CanWriteDirective, BackButtonComponent],
  templateUrl: './daily-ops.component.html',
  styleUrls: ['./daily-ops.component.scss']
})
export class DailyOpsComponent implements OnInit, OnDestroy {
  Permission = Permission;
  private svc = inject(DailyOpsService);
  private snack = inject(MatSnackBar);
  private yearContext = inject(AcademicYearContextService);

  loading = signal<boolean>(false);
  today = new Date().toISOString().slice(0, 10);
  summary = signal<DailySummaryDto | null>(null);

  // Academic Year: selected in the global header (AcademicYearContextService).
  // This page intentionally has no local year dropdown — it just follows the header.
  selectedYearId = signal<any>(null);
  private yearSub?: Subscription;

  // Class/Section selectors
  classes: { id: number; name: string }[] = [];
  sections: { id: number; name: string }[] = [];
  classId = signal<any>(null);
  sectionId = signal<any>(null);
  presentCsv = '';
  reminderChannel: 'SMS' | 'Email' | 'Push' = 'SMS';
  reminderMessage = '';

  ngOnInit() {
    // Follow the global header's academic-year selection (no local dropdown).
    this.yearSub = this.yearContext.selectedAcademicYear$.subscribe(yearId => {
      const changed = yearId !== this.selectedYearId();
      this.selectedYearId.set(yearId);
      if (changed && yearId) {
        // Classes are year-scoped: reload when the header changes the year
        this.loadClasses();
        this.load();
      }
    });
    this.yearContext.loadAcademicYears().subscribe();

    this.load();
    this.loadClasses();
  }

  ngOnDestroy() {
    this.yearSub?.unsubscribe();
  }

  loadClasses() {
    const yearId = this.selectedYearId();
    const request$ = yearId
      ? this.svc.getClassesByAcademicYear(yearId)
      : this.svc.getClasses();

    request$.subscribe({
      next: (data: any) => {
        this.classes = Array.isArray(data) ? data : (data?.data ?? []);
        this.classId.set(null);
        this.sectionId.set(null);
        this.sections = [];
      },
      error: () => { this.classes = []; }
    });
  }

  onClassChange() {
    this.sectionId.set(null);
    if (this.classId()) {
      this.svc.getSectionsByClass(this.classId()).subscribe({
        next: (data: any) => {
          this.sections = Array.isArray(data) ? data : (data?.data ?? []);
        },
        error: () => { this.sections = []; }
      });
    } else {
      this.sections = [];
    }
  }

  load(date?: string) {
    this.loading.set(true);
    this.svc.getSummary(date ?? this.today, this.selectedYearId()).subscribe({
      next: dto => { this.summary.set(dto); this.loading.set(false); },
      error: _ => { this.loading.set(false); this.snack.open('Failed to load daily summary', 'Dismiss', { duration: 3000 }); }
    });
  }

  quickMark() {
    if (!this.classId() || !this.sectionId()) {
      this.snack.open('Please select a class and section first', 'Dismiss', { duration: 3000 });
      return;
    }
    const ids = (this.presentCsv || '').split(',').map(x => parseInt(x.trim(), 10)).filter(x => !isNaN(x));
    const payload: QuickMarkRequest = { classId: this.classId(), sectionId: this.sectionId(), date: this.today, presentStudentIds: ids };
    this.svc.quickMarkAttendance(payload).subscribe({
      next: _ => { this.snack.open('Attendance quick-marked', 'OK', { duration: 2500 }); this.load(); },
      error: _ => this.snack.open('Failed to quick-mark', 'Dismiss', { duration: 3000 })
    });
  }

  sendReminders() {
    const dto = this.summary();
    if (!dto) return;
    const studentIds = new Set<number>();
    const payload: FeeReminderRequest = { studentIds: Array.from(studentIds), channel: this.reminderChannel, message: this.reminderMessage };
    this.svc.sendFeeReminders(payload).subscribe({
      next: _ => this.snack.open('Fee reminders sent (if any)', 'OK', { duration: 2500 }),
      error: _ => this.snack.open('Failed to send reminders', 'Dismiss', { duration: 3000 })
    });
  }
}
