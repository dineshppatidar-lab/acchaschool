import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { User } from './user.model';
import { environment } from '../../../environments/environment';

/**
 * Write payloads for the users API. The API contract is DTO-based:
 * a clear-text `password` (hashed server-side) and NO `passwordHash` —
 * credential hashes never travel in either direction.
 */
export type CreateUserPayload = Partial<Omit<User, 'id'>> & {
  username: string;
  email: string;
  password: string;
  roles: string;
};
export type UpdateUserPayload = Partial<Omit<User, 'id'>> & { id?: number };

@Injectable({
  providedIn: 'root'
})
export class UserManagementService {
  private apiUrl = `${environment.apiUrl}/api/users`;

  constructor(private http: HttpClient) { }

  getAllUsers(tenantId?: number): Observable<User[]> {
    if (tenantId && typeof window !== 'undefined' && window.localStorage) {
      localStorage.setItem('tenantId', String(tenantId));
    }
    const url = tenantId ? `${this.apiUrl}?tenantId=${tenantId}` : this.apiUrl;
    console.log('👤 UserManagementService.getAllUsers() called, API URL:', url, 'tenantId:', tenantId);
    return this.http.get<any>(url).pipe(
      map((response: any) => {
        console.log('👤 Raw users response:', response);
        
        // Handle different response formats
        // Format 1: { data: User[], total: number }
        if (response.data && Array.isArray(response.data)) {
          console.log('👤 Response format: { data, total }');
          return response.data;
        }
        // Format 2: Direct array of users
        if (Array.isArray(response)) {
          console.log('👤 Response format: Direct array');
          return response;
        }
        // Format 3: ApiResponse<User[]> format
        if (response.success && response.data) {
          console.log('👤 Response format: ApiResponse wrapper');
          return response.data;
        }
        
        console.warn('👤 Unexpected response format:', response);
        return [];
      }),
      catchError(error => {
        console.error('👤 Error fetching users:', error);
        throw error;
      })
    );
  }

  getUserById(id: number): Observable<User> {
    return this.http.get<any>(`${this.apiUrl}/${id}`).pipe(
      map(response => this.extractData(response))
    );
  }

  createUser(user: CreateUserPayload): Observable<User> {
    return this.http.post<any>(this.apiUrl, user).pipe(
      map(response => this.extractData(response))
    );
  }

  updateUser(id: number, user: UpdateUserPayload): Observable<any> {
    return this.http.put<any>(`${this.apiUrl}/${id}`, user).pipe(
      map(response => this.extractData(response))
    );
  }

  deleteUser(id: number): Observable<any> {
    return this.http.delete<any>(`${this.apiUrl}/${id}`).pipe(
      map(response => this.extractData(response))
    );
  }

  getProfile(): Observable<User> {
    return this.http.get<any>(`${this.apiUrl}/profile`).pipe(
      map(response => this.extractData(response))
    );
  }

  updateProfile(user: User): Observable<any> {
    return this.http.put<any>(`${this.apiUrl}/profile`, user).pipe(
      map(response => this.extractData(response))
    );
  }

  /**
   * Standardized data extraction from ApiResponse wrapper
   */
  private extractData(response: any): any {
    if (!response) return null;
    
    // Check if it's the standard ApiResponse format
    if (response.hasOwnProperty('success')) {
      return response.success ? response.data : response;
    }
    
    // Otherwise return as is
    return response;
  }
}
