export interface User {
  id: number;
  tenantId?: number;
  username: string;
  email: string;
  firstName?: string;
  lastName?: string;
  phone?: string;
  /**
   * Clear-text password typed by the admin on create/update — sent to the
   * API as `password`, hashed server-side (Identity v3). Never a hash:
   * the old `passwordHash`-carries-the-password convention is what stored
   * plaintext credentials and broke every newly created user's login.
   */
  password?: string;
  roles: string;
  isActive: boolean;
  lastLogin: Date;
  createdAt?: Date;
  permissions?: string[];
  recentLogins?: any[];
}
