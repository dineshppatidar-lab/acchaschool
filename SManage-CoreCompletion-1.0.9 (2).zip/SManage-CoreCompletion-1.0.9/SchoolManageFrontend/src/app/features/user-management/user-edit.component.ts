import { Component, OnInit, signal } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { UserManagementService } from './user-management.service';
import { User } from './user.model';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatIconModule } from '@angular/material/icon';
import { MatDividerModule } from '@angular/material/divider';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { UserNotificationService } from '../../services/user-notification.service';
import { UserRole, RoleLabels } from '../../core/models/permission.model';

@Component({
  selector: 'app-user-edit',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatCardModule,
    MatButtonModule,
    MatInputModule,
    MatSelectModule,
    MatCheckboxModule,
    MatIconModule,
    MatDividerModule,
    MatFormFieldModule,
    MatSnackBarModule
  ],
  templateUrl: './user-edit.component.html',
  styleUrls: ['./user-edit.component.scss']
})
export class UserEditComponent implements OnInit {
  userForm!: FormGroup;
  isEditMode = signal(false);
  userId: number | null = null;
  
  // Dynamic roles from the same source as Permission Management
  availableRoles = Object.values(UserRole).filter(v => typeof v === 'number') as UserRole[];
  roleLabels = RoleLabels;

  constructor(
    private fb: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private userManagementService: UserManagementService,
    private userNotificationService: UserNotificationService,
    private snackBar: MatSnackBar
  ) { }

  ngOnInit(): void {
    const idParam = this.route.snapshot.params['id'];
    this.userId = idParam ? Number(idParam) : null;
    this.isEditMode.set(!!this.userId);

    this.initForm();

    if (this.isEditMode()) {
      this.loadUserDetails();
    }
  }

  initForm(): void {
    // `password` is the clear-text credential the admin types — the API hashes
    // it server-side (Identity v3). The old form sent the typed password in a
    // `passwordHash` field, which the backend then stored verbatim in the hash
    // column, breaking login for every user created after it was deployed.
    this.userForm = this.fb.group({
      id: [0],
      username: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      password: ['', this.isEditMode()
        ? Validators.minLength(8)
        : [Validators.required, Validators.minLength(8)]],
      roles: [[] as any[], Validators.required],
      firstName: [''],
      lastName: [''],
      phone: [''],
      isActive: [true]
    });
  }

  getRoleName(role: any): string {
    if (role === null || role === undefined) return '';
    // If it's a number (enum value)
    if (typeof role === 'number') {
      return UserRole[role] || role.toString();
    }
    return role.toString();
  }

  getRoleLabel(role: any): string {
    if (role === null || role === undefined) return '';
    const roleId = typeof role === 'number' ? role : Number(role);
    return this.roleLabels[roleId as UserRole] || this.getRoleName(role);
  }

  loadUserDetails(): void {
    if (this.userId) {
      this.userManagementService.getUserById(this.userId).subscribe({
        next: (user) => {
          let rolesArray: any[] = [];
          if (typeof user.roles === 'string') {
            // Convert string roles to their numeric enum equivalents if they are names
            rolesArray = user.roles.split(',').map(r => {
              const trimmed = r.trim();
              // Check if it's a number string
              if (!isNaN(Number(trimmed))) return Number(trimmed);
              // Check if it matches an enum key
              const enumValue = (UserRole as any)[trimmed];
              return enumValue !== undefined ? enumValue : trimmed;
            });
          } else if (Array.isArray(user.roles)) {
            rolesArray = user.roles;
          }

          this.userForm.patchValue({
            id: user.id,
            username: user.username,
            email: user.email,
            roles: rolesArray,
            firstName: user.firstName ?? '',
            lastName: user.lastName ?? '',
            phone: user.phone ?? '',
            isActive: user.isActive
            // password intentionally left blank — the API no longer returns
            // credential material, so there is nothing to pre-fill.
          }, { emitEvent: false });
        },
        error: (err) => console.error('Error loading user details', err)
      });
    }
  }

  onSubmit(): void {
    if (this.userForm.valid) {
      const formValue = this.userForm.value;

      // Convert numeric role IDs back to strings (enum keys) for backend compatibility
      // as the current UsersController and DB expect string roles
      const rolesToSave = Array.isArray(formValue.roles)
        ? formValue.roles.map((r: any) => this.getRoleName(r)).join(',')
        : formValue.roles;

      if (this.isEditMode() && this.userId) {
        const updateData = {
          username: formValue.username,
          email: formValue.email,
          roles: rolesToSave,
          firstName: formValue.firstName,
          lastName: formValue.lastName,
          phone: formValue.phone,
          isActive: formValue.isActive,
          // Only send the password when the admin actually typed one —
          // blank means "keep current credentials".
          ...(formValue.password ? { password: formValue.password } : {})
        };
        this.userManagementService.updateUser(this.userId, updateData).subscribe({
          next: () => {
            this.userNotificationService.notifyUserModified();
            this.router.navigate(['/app/admin/user-management']);
          },
          error: (err) => this.submitFailed('update', err)
        });
      } else {
        const createData = {
          username: formValue.username,
          email: formValue.email,
          password: formValue.password,
          roles: rolesToSave,
          firstName: formValue.firstName,
          lastName: formValue.lastName,
          phone: formValue.phone,
          isActive: formValue.isActive
        };
        this.userManagementService.createUser(createData).subscribe({
          next: () => {
            this.userNotificationService.notifyUserModified();
            this.router.navigate(['/app/admin/user-management']);
          },
          error: (err) => this.submitFailed('create', err)
        });
      }
    } else {
      this.userForm.markAllAsTouched();
    }
  }

  /**
   * Surface the API's safe error message (400 validation / 409 duplicate /
   * 401 auth) instead of a silent console error, so duplicate usernames or
   * weak passwords are immediately actionable for the admin.
   */
  private submitFailed(operation: string, err: any): void {
    // Never log or display request bodies — they contain the typed password.
    console.error(`Error during user ${operation}`, err.status ?? err);
    const message: string = err?.error?.message
      ?? err?.message
      ?? `Failed to ${operation} user${err?.status === 409 ? ' — that username or email already exists' : ''}.`;
    this.snackBar.open(message, 'OK', { duration: 6000, panelClass: 'error-snackbar' });
  }

  onCancel(): void {
    this.router.navigate(['/app/admin/user-management']);
  }
}
