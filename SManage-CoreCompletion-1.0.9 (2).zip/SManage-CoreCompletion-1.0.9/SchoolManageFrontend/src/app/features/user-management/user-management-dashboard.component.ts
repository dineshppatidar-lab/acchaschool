import { Component, OnDestroy, OnInit, ViewChild, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatMenuModule } from '@angular/material/menu';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatChipsModule } from '@angular/material/chips';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatDialog } from '@angular/material/dialog';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatDividerModule } from '@angular/material/divider';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatTabsModule } from '@angular/material/tabs';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatBadgeModule } from '@angular/material/badge';
import { MatListModule } from '@angular/material/list';
import { SelectionModel } from '@angular/cdk/collections';
import { Observable, Subject, combineLatest } from 'rxjs';
import { takeUntil, debounceTime, map, startWith } from 'rxjs/operators';

import { User } from '../user-management/user.model';
import { UserManagementService } from '../user-management/user-management.service';

interface UserStats {
  total: number;
  active: number;
  inactive: number;
  byRole: { [key: string]: number };
  recentLogins: number;
  newThisMonth: number;
}

interface BulkAction {
  action: string;
  label: string;
  icon: string;
  color: string;
}

@Component({
  selector: 'app-user-management-dashboard',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    MatCardModule,
    MatButtonModule,
    MatIconModule,
    MatInputModule,
    MatSelectModule,
    MatCheckboxModule,
    MatMenuModule,
    MatTooltipModule,
    MatChipsModule,
    MatProgressSpinnerModule,
    MatSlideToggleModule,
    MatDividerModule,
    MatProgressBarModule,
    MatTabsModule,
    MatExpansionModule,
    MatBadgeModule,
    MatListModule
  ],
  templateUrl: './user-management-dashboard.component.html',
  styleUrls: ['./user-management-dashboard.component.scss']
})
export class UserManagementDashboardComponent implements OnInit, OnDestroy {
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  // Data Sources
  dataSource = new MatTableDataSource<User>();
  selection = new SelectionModel<User>(true, []);
  
  // Component State
  isLoading = signal(true);
  viewMode: 'grid' | 'table' | 'compact' = 'table';
  selectedTab = 0;
  
  // User Statistics
  userStats: UserStats = {
    total: 0,
    active: 0,
    inactive: 0,
    byRole: {},
    recentLogins: 0,
    newThisMonth: 0
  };

  // Table Configuration
  displayedColumns: string[] = [
    'select', 'avatar', 'username', 'email', 'roles', 
    'status', 'lastLogin', 'loginCount', 'actions'
  ];

  // Filter and Search
  searchForm!: FormGroup;
  private destroy$ = new Subject<void>();
  
  // Available Roles and Statuses
  availableRoles = ['Admin', 'Teacher', 'Student', 'Parent', 'Staff', 'Warden', 'Driver'];
  availableStatuses = ['all', 'active', 'inactive'];
  
  // Bulk Actions
  bulkActions: BulkAction[] = [
    { action: 'activate', label: 'Activate Users', icon: 'check_circle', color: 'primary' },
    { action: 'deactivate', label: 'Deactivate Users', icon: 'cancel', color: 'warn' },
    { action: 'delete', label: 'Delete Users', icon: 'delete', color: 'warn' },
    { action: 'export', label: 'Export Selected', icon: 'download', color: 'accent' },
    { action: 'resetPassword', label: 'Reset Passwords', icon: 'lock_reset', color: 'primary' }
  ];

  // Chart Data
  roleDistributionData: any[] = [];
  userActivityData: any[] = [];

  constructor(
    private userService: UserManagementService,
    private fb: FormBuilder,
    private router: Router,
    private snackBar: MatSnackBar,
    private dialog: MatDialog
  ) {
    this.initializeSearchForm();
  }

  ngOnInit(): void {
    this.loadUsers();
    this.setupFilters();
    this.loadUserStatistics();
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  private initializeSearchForm(): void {
    this.searchForm = this.fb.group({
      searchTerm: [''],
      roleFilter: ['all'],
      statusFilter: ['all'],
      dateFrom: [''],
      dateTo: ['']
    });
  }

  private setupFilters(): void {
    this.searchForm.valueChanges
      .pipe(
        debounceTime(300),
        takeUntil(this.destroy$)
      )
      .subscribe(() => {
        this.applyFilters();
      });
  }

  loadUsers(): void {
    this.isLoading.set(true);
    this.userService.getAllUsers()
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (users) => {
          this.dataSource.data = users;
          this.dataSource.paginator = this.paginator;
          this.dataSource.sort = this.sort;
          this.updateUserStatistics(users);
          this.prepareChartData(users);
          this.isLoading.set(false);
        },
        error: (error) => {
          console.error('Error loading users:', error);
          this.showNotification('Error loading users', 'error');
          this.isLoading.set(false);
        }
      });
  }

  private loadUserStatistics(): void {
    // Load additional statistics from API if available
    // This could include login analytics, activity data, etc.
  }

  private updateUserStatistics(users: User[]): void {
    this.userStats = {
      total: users.length,
      active: users.filter(u => u.isActive).length,
      inactive: users.filter(u => !u.isActive).length,
      byRole: this.calculateRoleDistribution(users),
      recentLogins: users.filter(u => this.isRecentLogin(u.lastLogin)).length,
      newThisMonth: users.filter(u => this.isThisMonth(u.lastLogin)).length
    };
  }

  private calculateRoleDistribution(users: User[]): { [key: string]: number } {
    const roleCount: { [key: string]: number } = {};
    users.forEach(user => {
      const roles = user.roles.split(',').map(r => r.trim());
      roles.forEach(role => {
        roleCount[role] = (roleCount[role] || 0) + 1;
      });
    });
    return roleCount;
  }

  private prepareChartData(users: User[]): void {
    // Prepare data for charts
    this.roleDistributionData = Object.entries(this.userStats.byRole)
      .map(([role, count]) => ({ name: role, value: count }));
  }

  private isRecentLogin(lastLogin: Date): boolean {
    const sevenDaysAgo = new Date();
    sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
    return new Date(lastLogin) > sevenDaysAgo;
  }

  private isThisMonth(date: Date): boolean {
    const now = new Date();
    const checkDate = new Date(date);
    return checkDate.getMonth() === now.getMonth() && 
           checkDate.getFullYear() === now.getFullYear();
  }

  applyFilters(): void {
    const filters = this.searchForm.value;
    
    this.dataSource.filterPredicate = (user: User, filter: string) => {
      const filterObj = JSON.parse(filter);
      
      // Search term filter
      const searchMatch = !filterObj.searchTerm || 
        user.username.toLowerCase().includes(filterObj.searchTerm.toLowerCase()) ||
        user.email.toLowerCase().includes(filterObj.searchTerm.toLowerCase()) ||
        user.roles.toLowerCase().includes(filterObj.searchTerm.toLowerCase());
      
      // Role filter
      const roleMatch = filterObj.roleFilter === 'all' || 
        user.roles.toLowerCase().includes(filterObj.roleFilter.toLowerCase());
      
      // Status filter
      const statusMatch = filterObj.statusFilter === 'all' ||
        (filterObj.statusFilter === 'active' && user.isActive) ||
        (filterObj.statusFilter === 'inactive' && !user.isActive);
      
      return searchMatch && roleMatch && statusMatch;
    };

    this.dataSource.filter = JSON.stringify(filters);
  }

  // Selection Methods
  isAllSelected(): boolean {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected === numRows;
  }

  masterToggle(): void {
    this.isAllSelected() ?
      this.selection.clear() :
      this.dataSource.data.forEach(row => this.selection.select(row));
  }

  // User Actions
  createUser(): void {
    this.router.navigate(['/app/admin/user-management/add']);
  }

  editUser(user: User): void {
    this.router.navigate(['/app/admin/user-management/edit', user.id]);
  }

  viewUser(user: User): void {
    this.router.navigate(['/app/admin/user-management/view', user.id]);
  }

  toggleUserStatus(user: User): void {
    const updatedUser = { ...user, isActive: !user.isActive };
    this.userService.updateUser(user.id, updatedUser)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: () => {
          this.showNotification(
            `User ${user.username} ${updatedUser.isActive ? 'activated' : 'deactivated'}`,
            'success'
          );
          this.loadUsers();
        },
        error: (error) => {
          console.error('Error updating user status:', error);
          this.showNotification('Error updating user status', 'error');
        }
      });
  }

  deleteUser(user: User): void {
    if (confirm(`Are you sure you want to delete user "${user.username}"?`)) {
      this.userService.deleteUser(user.id)
        .pipe(takeUntil(this.destroy$))
        .subscribe({
          next: () => {
            this.showNotification(`User ${user.username} deleted successfully`, 'success');
            this.loadUsers();
          },
          error: (error) => {
            console.error('Error deleting user:', error);
            this.showNotification('Error deleting user', 'error');
          }
        });
    }
  }

  // Bulk Actions
  executeBulkAction(action: string): void {
    const selectedUsers = this.selection.selected;
    
    if (selectedUsers.length === 0) {
      this.showNotification('Please select users first', 'warning');
      return;
    }

    switch (action) {
      case 'activate':
        this.bulkActivateUsers(selectedUsers);
        break;
      case 'deactivate':
        this.bulkDeactivateUsers(selectedUsers);
        break;
      case 'delete':
        this.bulkDeleteUsers(selectedUsers);
        break;
      case 'export':
        this.exportSelectedUsers(selectedUsers);
        break;
      case 'resetPassword':
        this.bulkResetPasswords(selectedUsers);
        break;
    }
  }

  private bulkActivateUsers(users: User[]): void {
    // Implementation for bulk activation
    users.forEach(user => {
      if (!user.isActive) {
        this.toggleUserStatus(user);
      }
    });
    this.selection.clear();
  }

  private bulkDeactivateUsers(users: User[]): void {
    // Implementation for bulk deactivation
    users.forEach(user => {
      if (user.isActive) {
        this.toggleUserStatus(user);
      }
    });
    this.selection.clear();
  }

  private bulkDeleteUsers(users: User[]): void {
    if (confirm(`Are you sure you want to delete ${users.length} users?`)) {
      users.forEach(user => this.deleteUser(user));
      this.selection.clear();
    }
  }

  private exportSelectedUsers(users: User[]): void {
    // Implementation for exporting users to CSV/Excel
    const csvData = this.convertToCSV(users);
    this.downloadCSV(csvData, 'selected_users.csv');
    this.showNotification(`${users.length} users exported successfully`, 'success');
  }

  private bulkResetPasswords(users: User[]): void {
    if (confirm(`Are you sure you want to reset passwords for ${users.length} users?`)) {
      // Implementation for bulk password reset
      this.showNotification(`Password reset initiated for ${users.length} users`, 'success');
      this.selection.clear();
    }
  }

  // Utility Methods
  private convertToCSV(users: User[]): string {
    const headers = ['ID', 'Username', 'Email', 'Roles', 'Status', 'Last Login'];
    const rows = users.map(user => [
      user.id,
      user.username,
      user.email,
      user.roles,
      user.isActive ? 'Active' : 'Inactive',
      new Date(user.lastLogin).toLocaleString()
    ]);
    
    return [headers, ...rows].map(row => row.join(',')).join('\n');
  }

  private downloadCSV(csvData: string, filename: string): void {
    const blob = new Blob([csvData], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    link.click();
    window.URL.revokeObjectURL(url);
  }

  getRoleChipColor(role: string): string {
    const colors: { [key: string]: string } = {
      'Admin': 'warn',
      'Teacher': 'primary',
      'Student': 'accent',
      'Parent': 'basic',
      'Staff': 'primary',
      'Warden': 'warn',
      'Driver': 'accent'
    };
    return colors[role] || 'basic';
  }

  formatLastLogin(date: Date): string {
    if (!date) return 'Never';
    
    const now = new Date();
    const loginDate = new Date(date);
    const diffTime = Math.abs(now.getTime() - loginDate.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays === 1) return 'Today';
    if (diffDays === 2) return 'Yesterday';
    if (diffDays <= 7) return `${diffDays} days ago`;
    
    return loginDate.toLocaleDateString();
  }

  getStatusIcon(isActive: boolean): string {
    return isActive ? 'check_circle' : 'cancel';
  }

  getStatusColor(isActive: boolean): string {
    return isActive ? 'primary' : 'warn';
  }

  refreshData(): void {
    this.loadUsers();
    this.showNotification('Data refreshed successfully', 'success');
  }

  importUsers(): void {
    // Implementation for importing users from CSV/Excel
    this.showNotification('Import functionality coming soon', 'info');
  }

  exportAllUsers(): void {
    this.exportSelectedUsers(this.dataSource.data);
  }

  changeViewMode(mode: 'grid' | 'table' | 'compact'): void {
    this.viewMode = mode;
  }

  private showNotification(message: string, type: 'success' | 'error' | 'warning' | 'info'): void {
    this.snackBar.open(message, 'Close', {
      duration: 3000,
      panelClass: [`snackbar-${type}`]
    });
  }

  // Analytics Methods
  getUserGrowthData(): any[] {
    // Implementation for user growth analytics
    return [];
  }

  getRoleDistributionPercentage(role: string): number {
    const total = this.userStats.total;
    const roleCount = this.userStats.byRole[role] || 0;
    return total > 0 ? Math.round((roleCount / total) * 100) : 0;
  }

  getActivePercentage(): number {
    return this.userStats.total > 0 ? 
      Math.round((this.userStats.active / this.userStats.total) * 100) : 0;
  }

  getRoleIcon(role: string): string {
    const roleIcons: { [key: string]: string } = {
      'Admin': 'admin_panel_settings',
      'Teacher': 'school',
      'Student': 'person',
      'Parent': 'family_restroom',
      'Staff': 'work',
      'Warden': 'security',
      'Driver': 'local_shipping'
    };
    return roleIcons[role] || 'person';
  }
}