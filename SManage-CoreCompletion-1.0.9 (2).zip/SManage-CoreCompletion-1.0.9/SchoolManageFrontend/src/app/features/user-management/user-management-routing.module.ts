import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { UserListComponent } from './user-list-modern';
import { UserEditComponent } from './user-edit.component';
import { UserManagementDashboardComponent } from './user-management-dashboard.component';

const routes: Routes = [
  { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
  { path: 'dashboard', component: UserManagementDashboardComponent },
  { path: 'list', component: UserListComponent },
  { path: 'add', component: UserEditComponent },
  { path: 'edit/:id', component: UserEditComponent },
  { path: 'view/:id', component: UserEditComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class UserManagementRoutingModule { }
