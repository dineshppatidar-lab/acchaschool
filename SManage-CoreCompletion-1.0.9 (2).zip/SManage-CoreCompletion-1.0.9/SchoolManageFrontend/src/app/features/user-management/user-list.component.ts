import { ChangeDetectorRef, Component, OnDestroy, OnInit, ViewChild, signal } from '@angular/core';
import { User } from './user.model';
import { UserManagementService } from './user-management.service';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTableModule, MatTableDataSource } from '@angular/material/table';
import { MatSortModule, MatSort } from '@angular/material/sort';
import { MatPaginatorModule, MatPaginator } from '@angular/material/paginator';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatMenuModule } from '@angular/material/menu';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatChipsModule } from '@angular/material/chips';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatDividerModule } from '@angular/material/divider';
import { UserNotificationService } from '../../services/user-notification.service';
import { Subscription } from 'rxjs';
import { TenantService } from '../../services/tenant.service';
import { AuthService } from '../../services/auth.service';
import { UserRole, RoleLabels } from '../../core/models/permission.model';

@Component({
  selector: 'app-user-list',
  standalone: true,
  imports: [
    CommonModule, 
    MatCardModule, 
    MatButtonModule, 
    MatIconModule,
    MatTableModule,
    MatSortModule,
    MatPaginatorModule,
    MatInputModule,
    MatFormFieldModule,
    MatMenuModule,
    MatTooltipModule,
    MatChipsModule,
    MatProgressSpinnerModule,
    MatDividerModule
  ],
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.scss']
})
export class UserListComponent implements OnInit, OnDestroy {
  displayedColumns: string[] = ['name', 'email', 'roles', 'status', 'lastLogin', 'actions'];
  dataSource = new MatTableDataSource<User>([]);
  isLoading = signal(true);
  selectedTenantId = signal(0);
  
  @ViewChild(MatSort) sort!: MatSort;
  @ViewChild(MatPaginator) paginator!: MatPaginator;

  // Getter for template compatibility
  get users(): User[] {
    return this.dataSource.data;
  }

  private userModifiedSubscription: Subscription | undefined;
  private tenantSubscription: Subscription | undefined;

  constructor(
    private userManagementService: UserManagementService, 
    private router: Router, 
    private userNotificationService: UserNotificationService, 
    private tenantService: TenantService, 
    private authService: AuthService, 
    private cdr: ChangeDetectorRef
  ) { }

  ngOnInit(): void {
    this.tenantSubscription = this.tenantService.selectedTenant$.subscribe(id => {
      const finalId = id || Number(localStorage.getItem('tenantId')) || 1;
      this.selectedTenantId.set(finalId);
      this.loadUsers(finalId);
    });

    this.userModifiedSubscription = this.userNotificationService.userModified$.subscribe(() => {
      this.loadUsers();
    });
  }

  ngOnDestroy(): void {
    this.userModifiedSubscription?.unsubscribe();
    this.tenantSubscription?.unsubscribe();
  }

  loadUsers(tenantId?: number): void {
    this.isLoading.set(true);
    const finalTenantId = tenantId || this.selectedTenantId() || (Number(localStorage.getItem('tenantId')) || 1);
    
    this.userManagementService.getAllUsers(finalTenantId).subscribe({
      next: (data: any) => {
        // Handle potential different response structures
        const userList = Array.isArray(data) ? data : (data?.data || []);
        
        this.dataSource.data = userList;
        this.dataSource.sort = this.sort;
        this.dataSource.paginator = this.paginator;
        
        // Custom filter for properties
        this.dataSource.filterPredicate = (user: User, filter: string) => {
          const searchStr = (
            (user.username || '') + 
            (user.email || '') + 
            (user.firstName || '') + 
            (user.lastName || '') + 
            (user.roles || '')
          ).toLowerCase();
          return searchStr.indexOf(filter.toLowerCase()) !== -1;
        };
        
        this.isLoading.set(false);
        this.cdr.detectChanges();
      },
      error: (err) => {
        console.error('❌ Error loading users:', err);
        this.isLoading.set(false);
        this.cdr.detectChanges();
      }
    });
  }

  applyFilter(event: Event): void {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  clearFilter(): void {
    this.dataSource.filter = '';
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  getUserInitial(user: User): string {
    if (user.firstName && user.firstName.length > 0) {
      return user.firstName.charAt(0).toUpperCase();
    }
    if (user.username && user.username.length > 0) {
      return user.username.charAt(0).toUpperCase();
    }
    return 'U';
  }

  getRolesArray(roles: any): string[] {
    if (!roles) return [];
    if (Array.isArray(roles)) return roles.map(r => String(r));
    return String(roles).split(',').map((r: string) => r.trim());
  }

  getRoleLabel(roleName: string): string {
    if (!roleName) return '';
    
    // Try to find if it matches an enum key
    const enumValue = (UserRole as any)[roleName];
    if (enumValue !== undefined) {
      return RoleLabels[enumValue as UserRole] || roleName;
    }
    // If it's already a number or numeric string
    const numericRole = Number(roleName);
    if (!isNaN(numericRole) && numericRole > 0) {
      return RoleLabels[numericRole as UserRole] || roleName;
    }
    return roleName;
  }

  editUser(userId: number): void {
    this.router.navigate(['/app/admin/user-management/edit', userId]);
  }

  deleteUser(userId: number): void {
    if (confirm('Are you sure you want to permanently delete this user? This action cannot be undone.')) {
      this.userManagementService.deleteUser(userId).subscribe({
        next: () => {
          this.loadUsers();
        },
        error: (err) => console.error('Error deleting user', err)
      });
    }
  }

  addNewUser(): void {
    this.router.navigate(['/app/admin/user-management/add']);
  }
}
