import { Component, OnDestroy, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatListModule } from '@angular/material/list';
import { MatCardModule } from '@angular/material/card';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { RouterModule } from '@angular/router';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatChipsModule } from '@angular/material/chips';
import { MatMenuModule } from '@angular/material/menu';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatDividerModule } from '@angular/material/divider';
import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSortModule } from '@angular/material/sort';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { User } from './user.model';
import { UserManagementService } from './user-management.service';
import { UserNotificationService } from '../../services/user-notification.service';
import { Observable, combineLatest, BehaviorSubject, Subscription } from 'rxjs';
import { delay, map, startWith, debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-user-list',
  standalone: true,
  imports: [
    CommonModule, 
    FormsModule,
    ReactiveFormsModule,
    MatListModule, 
    MatCardModule, 
    MatProgressSpinnerModule, 
    MatIconModule, 
    MatButtonModule, 
    RouterModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatChipsModule,
    MatMenuModule,
    MatTooltipModule,
    MatDividerModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    MatSlideToggleModule
  ],
  templateUrl: './user-list-modern.html',
  styleUrls: ['./user-list-modern.scss']
})
export class UserListComponent implements OnInit, OnDestroy {
  users$?: Observable<User[]>;
  filteredUsers$?: Observable<User[]>;
  displayedColumns: string[] = ['id', 'username', 'email', 'roles', 'status', 'lastLogin', 'actions'];
  
  // View controls
  viewMode: 'cards' | 'table' = 'cards';
  isLoading = signal(true);
  
  // Filter controls
  searchTerm = '';
  selectedRole = 'all';
  selectedStatus = 'all';
  private searchSubject = new BehaviorSubject<string>('');
  private roleFilterSubject = new BehaviorSubject<string>('all');
  private statusFilterSubject = new BehaviorSubject<string>('all');
  
  // Subscriptions
  private userModifiedSubscription: Subscription | undefined;
  
  // Statistics
  statistics = {
    totalUsers: 0,
    activeUsers: 0,
    inactiveUsers: 0,
    adminUsers: 0
  };

  constructor(
    private userManagementService: UserManagementService,
    private userNotificationService: UserNotificationService,
    private router: Router,
    private route: ActivatedRoute
  ) {}

  ngOnInit(): void {
    this.loadUsers();
    this.setupFilters();
    
    // Subscribe to user modifications
    this.userModifiedSubscription = this.userNotificationService.userModified$.subscribe(() => {
      this.loadUsers();
    });
  }

  ngOnDestroy(): void {
    this.userModifiedSubscription?.unsubscribe();
  }

  loadUsers() {
    console.log('👤 Loading users...');
    this.isLoading.set(true);
    this.users$ = this.userManagementService.getAllUsers().pipe(
      delay(500),
      map((users: User[]) => {
        this.isLoading.set(false);
        this.updateStatistics(users);
        return users;
      })
    );
  }

  setupFilters() {
    if (this.users$) {
      this.filteredUsers$ = combineLatest([
        this.users$,
        this.searchSubject.pipe(
          debounceTime(300),
          distinctUntilChanged(),
          startWith('')
        ),
        this.roleFilterSubject.pipe(
          startWith('all')
        ),
        this.statusFilterSubject.pipe(
          startWith('all')
        )
      ]).pipe(
        map(([users, searchTerm, roleFilter, statusFilter]) => 
          this.filterUsers(users, searchTerm, roleFilter, statusFilter)
        )
      );
    }
  }

  private filterUsers(users: User[], searchTerm: string, roleFilter: string, statusFilter: string): User[] {
    return users.filter(user => {
      const matchesSearch = !searchTerm || 
        user.username?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        user.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        user.roles?.toLowerCase().includes(searchTerm.toLowerCase());
      
      const matchesRole = roleFilter === 'all' || user.roles?.toLowerCase().includes(roleFilter.toLowerCase());
      const matchesStatus = statusFilter === 'all' || 
        (statusFilter === 'active' && user.isActive) ||
        (statusFilter === 'inactive' && !user.isActive);
      
      return matchesSearch && matchesRole && matchesStatus;
    });
  }

  private updateStatistics(users: User[]) {
    this.statistics = {
      totalUsers: users.length,
      activeUsers: users.filter(u => u.isActive).length,
      inactiveUsers: users.filter(u => !u.isActive).length,
      adminUsers: users.filter(u => u.roles?.toLowerCase().includes('admin')).length
    };
  }

  onSearchChange(value: string) {
    this.searchTerm = value;
    this.searchSubject.next(value);
  }

  onRoleFilterChange(value: string) {
    this.selectedRole = value;
    this.roleFilterSubject.next(value);
  }

  onStatusFilterChange(value: string) {
    this.selectedStatus = value;
    this.statusFilterSubject.next(value);
  }

  toggleViewMode() {
    this.viewMode = this.viewMode === 'cards' ? 'table' : 'cards';
  }

  editUser(id?: number) {
    if (id) {
      this.router.navigate(['edit', id], { relativeTo: this.route });
    }
  }

  deleteUser(id?: number) {
    if (id && confirm('Are you sure you want to delete this user?')) {
      this.userManagementService.deleteUser(id).subscribe({
        next: () => {
          console.log('User deleted successfully');
          this.loadUsers();
        },
        error: (error) => {
          console.error('Error deleting user:', error);
        }
      });
    }
  }

  toggleUserStatus(user: User) {
    const updatedUser = { ...user, isActive: !user.isActive };
    this.userManagementService.updateUser(updatedUser.id, updatedUser).subscribe({
      next: () => {
        console.log('User status updated successfully');
        this.loadUsers();
      },
      error: (error) => {
        console.error('Error updating user status:', error);
      }
    });
  }

  viewDetails(id?: number) {
    if (id) {
      console.log('View user details:', id);
    }
  }

  exportUsers() {
    console.log('Export users');
  }

  refreshList() {
    this.loadUsers();
  }

  createUser() {
    this.router.navigate(['add'], { relativeTo: this.route });
  }
}