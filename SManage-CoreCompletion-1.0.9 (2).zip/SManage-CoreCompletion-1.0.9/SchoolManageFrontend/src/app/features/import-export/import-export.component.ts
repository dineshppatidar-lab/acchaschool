import { Component, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatSnackBarModule, MatSnackBar } from '@angular/material/snack-bar';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { MatTabsModule } from '@angular/material/tabs';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatChipsModule } from '@angular/material/chips';
import { MatListModule } from '@angular/material/list';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { extractApiErrorMessage } from '../../services/api-response.interceptor';
import { ImportExportService } from '../../services/import-export.service';

interface ImportOutcome {
  kind: 'success' | 'partial' | 'error';
  fileName: string;
  message: string;
  imported: string[];
  failedRows: { rowNumber: number; studentName: string; errors: string[] }[];
  errors: string[];
  timestamp: Date;
}

interface ExportOutcome {
  fileName: string;
  dataType: string;
  message: string;
  timestamp: Date;
}

@Component({
  selector: 'app-import-export',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    MatButtonModule,
    MatIconModule,
    MatSnackBarModule,
    MatCardModule,
    MatFormFieldModule,
    MatSelectModule,
    MatTabsModule,
    MatProgressSpinnerModule,
    MatTooltipModule,
    MatChipsModule,
    MatListModule
  ],
  templateUrl: './import-export.component.html',
  styleUrls: ['./import-export.component.scss']
})
export class ImportExportComponent {
  readonly dataTypes = [
    { value: 'students', label: 'Students', available: true },
    { value: 'staff', label: 'Staff Members', available: true }
  ];

  selectedDataType = 'students';
  selectedFile = signal<any>(null);

  readonly exporting = signal(false);
  readonly importing = signal(false);

  readonly importHistory = signal<ImportOutcome[]>([]);
  readonly exportHistory = signal<ExportOutcome[]>([]);

  readonly isBusy = computed(() => this.exporting() || this.importing());

  private readonly exportEndpoints: Record<string, { url: string; baseName: string }> = {
    students: { url: '/api/importexport/students/export', baseName: 'students' },
    staff: { url: '/api/staffimportexport/export', baseName: 'staff' }
  };

  constructor(
    private http: HttpClient,
    private snackBar: MatSnackBar,
    private importExportService: ImportExportService
  ) {}

  /**
   * Downloads the tenant-aware admission template (.xlsx): Instructions sheet, a
   * Lookups sheet listing the academic years / classes / sections (IDs + names)
   * configured in THIS school's database with the current session flagged, and
   * dropdowns for Academic Year / Class / Section / Gender / Category so the
   * uploaded values always match what the import validates against.
   */
  downloadTemplate(): void {
    this.importExportService.downloadAdmissionTemplate().subscribe({
      next: (blob) => {
        this.downloadBlob(blob, 'Student_Admission_Template.xlsx');
        this.snackBar.open('Template downloaded — see the Lookups sheet for your school\'s valid Academic Years, Classes and Sections.', 'Close', { duration: 6000 });
      },
      error: (err: HttpErrorResponse) => {
        const msg = this.isHtmlError(err) ? 'Template download failed: server error.' : extractApiErrorMessage(err.error) || 'Template download failed.';
        this.snackBar.open(msg, 'Close', { duration: 5000 });
      }
    });
  }

  onDataTypeChange(value: string): void {
    this.selectedDataType = value;
    this.selectedFile.set(null);
  }

  onDragOver(event: DragEvent): void {
    event.preventDefault();
    event.stopPropagation();
  }

  onFileDropped(event: DragEvent): void {
    event.preventDefault();
    event.stopPropagation();
    const file = event.dataTransfer?.files?.[0];
    if (file) this.setSelectedFile(file);
  }

  onFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    const file = input.files?.[0];
    if (file) this.setSelectedFile(file);
  }

  removeSelectedFile(event?: Event): void {
    event?.stopPropagation();
    this.selectedFile.set(null);
  }

  private setSelectedFile(file: File): void {
    const ext = file.name.toLowerCase().substring(file.name.lastIndexOf('.'));
    const allowed = this.selectedDataType === 'students' ? ['.xlsx'] : ['.xlsx'];
    if (!allowed.includes(ext)) {
      this.snackBar.open(
        this.selectedDataType === 'students'
          ? 'Student import needs the .xlsx admission template downloaded from this screen.'
          : 'Unsupported file format. Please use the Excel (.xlsx) file exported from this screen.',
        'Close',
        { duration: 5000 }
      );
      return;
    }
    if (file.size > 10 * 1024 * 1024) {
      this.snackBar.open('File size exceeds 10MB limit', 'Close', { duration: 5000 });
      return;
    }
    this.selectedFile.set(file);
  }

  formatFileSize(bytes: number): string {
    if (!bytes) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  }

  startExport(): void {
    if (this.exporting()) return;
    const endpoint = this.exportEndpoints[this.selectedDataType];
    if (!endpoint) {
      this.snackBar.open('Export is not available for this data type yet.', 'Close', { duration: 4000 });
      return;
    }

    this.exporting.set(true);
    const stamp = new Date().toISOString().split('T')[0];
    const fileName = `${endpoint.baseName}_${stamp}.xlsx`;

    this.http.get(endpoint.url, { responseType: 'blob' }).subscribe({
      next: (blob) => {
        this.exporting.set(false);
        this.downloadBlob(blob, fileName);
        this.exportHistory.update((h) => [
          {
            fileName,
            dataType: this.selectedDataType,
            message: 'Export completed — file downloaded.',
            timestamp: new Date()
          },
          ...h
        ]);
        this.snackBar.open('Export completed — check your downloads.', 'Close', { duration: 4000 });
      },
      error: (err: HttpErrorResponse) => {
        this.exporting.set(false);
        const msg = this.isHtmlError(err) ? 'Export failed: server error.' : extractApiErrorMessage(err.error) || 'Export failed.';
        this.snackBar.open(msg, 'Close', { duration: 5000 });
      }
    });
  }

  startImport(): void {
    if (!this.selectedFile() || this.importing()) return;
    const dataType = this.selectedDataType;
    const formData = new FormData();
    formData.append('file', this.selectedFile());
    const url = dataType === 'students' ? '/api/importexport/students/import' : '/api/staffimportexport/import';

    this.importing.set(true);
    this.http.post<any>(url, formData).subscribe({
      next: (res) => {
        this.importing.set(false);
        const importedCount = res?.importedCount ?? res?.count ?? 0;
        const failedRows = res?.failedRows ?? [];
        const globalErrors: string[] = res?.errors ?? [];

        if (dataType === 'students') {
          this.importHistory.update((h) => [
            {
              kind: failedRows.length === 0 && globalErrors.length === 0 ? 'success' : 'partial',
              fileName: this.selectedFile()!.name,
              message: `${importedCount} student(s) imported, ${failedRows.length} row(s) failed.`,
              imported: res?.imported ?? [],
              failedRows,
              errors: globalErrors,
              timestamp: new Date()
            },
            ...h
          ]);
        } else {
          this.importHistory.update((h) => [
            {
              kind: 'success',
              fileName: this.selectedFile()!.name,
              message: `${importedCount} staff record(s) imported.`,
              imported: [],
              failedRows: [],
              errors: [],
              timestamp: new Date()
            },
            ...h
          ]);
        }

        if (failedRows.length === 0 && globalErrors.length === 0) {
          this.selectedFile.set(null);
          this.snackBar.open(`${importedCount} record(s) imported successfully.`, 'Close', { duration: 4000 });
        } else {
          this.snackBar.open(`${importedCount} imported, review the errors below.`, 'Close', { duration: 6000 });
        }
      },
      error: (err: HttpErrorResponse) => {
        this.importing.set(false);
        const msg = this.isHtmlError(err) ? 'Import failed: server error.' : extractApiErrorMessage(err.error) || 'Import failed.';
        this.importHistory.update((h) => [
          {
            kind: 'error',
            fileName: this.selectedFile()?.name ?? '',
            message: msg,
            imported: [],
            failedRows: [],
            errors: [],
            timestamp: new Date()
          },
          ...h
        ]);
        this.snackBar.open(msg, 'Close', { duration: 6000 });
      }
    });
  }

  private downloadBlob(blob: Blob, fileName: string): void {
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = fileName;
    a.click();
    window.URL.revokeObjectURL(url);
  }

  /** Detects an index.html fallback body masquerading as a file download. */
  private isHtmlError(err: HttpErrorResponse): boolean {
    return err.error instanceof Blob && err.error.type?.includes('text/html');
  }
}
