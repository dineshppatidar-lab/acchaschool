import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { FormBuilder, ReactiveFormsModule, Validators, FormGroup } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatTableModule } from '@angular/material/table';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { AdvancedAcademicService } from '../../services/advanced-academic.service';
import { CanWriteDirective } from '../../core/directives/permission.directive';
import { Permission } from '../../core/models/permission.model';
import { PageHeaderComponent } from '../../shared/components/page-patterns/index';

@Component({
  selector: 'app-exam-schedules',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, MatCardModule, MatTableModule, MatFormFieldModule, MatInputModule, MatButtonModule, MatSnackBarModule, CanWriteDirective, PageHeaderComponent, MatIconModule],
  templateUrl: './exam-schedules.component.html',
  styleUrls: ['./exam-schedules.component.scss']
})
export class ExamSchedulesComponent implements OnInit {
  Permission = Permission;
  examId!: number;
  schedules = signal<any[]>([]);
  displayedColumns = ['date', 'startTime', 'endTime', 'subject', 'room'];
  adding = signal(false);
  form!: FormGroup;

  constructor(
    private route: ActivatedRoute,
    private fb: FormBuilder,
    private academic: AdvancedAcademicService,
    private snack: MatSnackBar
  ) {
    this.form = this.fb.group({
      date: ['', Validators.required],
      startTime: ['', Validators.required],
      endTime: ['', Validators.required],
      subject: ['', Validators.required],
      room: ['']
    });
  }

  ngOnInit(): void {
    this.examId = Number(this.route.snapshot.paramMap.get('id'));
    this.load();
  }

  load(): void {
    this.academic.getExamSchedules(this.examId).subscribe({
      next: data => this.schedules.set(data ?? []),
      error: () => this.snack.open('Failed to load schedules', 'Close', { duration: 3000 })
    });
  }

  add(): void {
    if (this.form.invalid) return;
    this.adding.set(true);
    this.academic.createExamSchedule(this.examId, this.form.value).subscribe({
      next: () => { this.snack.open('Schedule added', 'Close', { duration: 2000 }); this.form.reset(); this.load(); },
      error: () => this.snack.open('Failed to add schedule', 'Close', { duration: 3000 }),
      complete: () => this.adding.set(false)
    });
  }
}
