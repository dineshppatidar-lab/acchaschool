import { ChangeDetectorRef, Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule, FormsModule } from '@angular/forms';
import { MatTableModule } from '@angular/material/table';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatCardModule } from '@angular/material/card';
import { PageHeaderComponent } from '../../shared/components/page-patterns/index';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatDividerModule } from '@angular/material/divider';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { finalize } from 'rxjs/operators';
import { AdvancedAcademicService } from '../../services/advanced-academic.service';
import { ExaminationType } from '../../shared/models/academic.models';
import { CanWriteDirective, CanDeleteDirective } from '../../core/directives/permission.directive';
import { Permission } from '../../core/models/permission.model';

@Component({
  selector: 'app-examination-type-list',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatTableModule,
    MatButtonModule,
    MatIconModule,
    MatFormFieldModule,
    MatInputModule,
    MatCardModule,
    PageHeaderComponent,
    MatSnackBarModule,
    MatProgressSpinnerModule,
    MatDividerModule,
    MatTooltipModule,
    MatSlideToggleModule,
    MatProgressBarModule,
    CanWriteDirective,
    CanDeleteDirective
  ],
  templateUrl: './examination-type-list.component.html',
  styleUrls: ['./examination-type-list.component.scss']
})
export class ExaminationTypeListComponent implements OnInit {
  Permission = Permission;
  displayedColumns: string[] = ['name', 'weightage', 'status', 'actions'];
  examinationTypes = signal<any[]>([]);
  loading = signal(false);
  saving = signal(false);
  
  typeForm: FormGroup;
  isEditMode = signal(false);
  editingId: number | null = null;

  constructor(
    private academic: AdvancedAcademicService,
    private fb: FormBuilder,
    private snack: MatSnackBar,
    private cdr: ChangeDetectorRef
  ) {
    this.typeForm = this.fb.group({
      name: ['', [Validators.required, Validators.minLength(2)]],
      description: [''],
      weightagePercentage: [0, [Validators.required, Validators.min(0), Validators.max(100)]],
      isActive: [true]
    });
  }

  ngOnInit(): void {
    this.loadExaminationTypes();
  }

  loadExaminationTypes(): void {
    this.loading.set(true);
    this.cdr.detectChanges();

    this.academic.getExaminationTypes().pipe(
      finalize(() => {
        this.loading.set(false);
        this.cdr.detectChanges();
      })
    ).subscribe({
      next: (data) => { this.examinationTypes.set(data || []); },
      error: () => this.snack.open('Failed to load examination types', 'Close', { duration: 3000 })
    });
  }

  onSubmit(): void {
    if (this.typeForm.invalid) return;
    this.saving.set(true);
    this.cdr.detectChanges();
    
    const payload = this.typeForm.value;

    if (this.isEditMode() && this.editingId) {
      this.academic.updateExaminationType(this.editingId, payload).pipe(
        finalize(() => {
          this.saving.set(false);
          this.cdr.detectChanges();
        })
      ).subscribe({
        next: () => {
          this.snack.open('Examination type updated', 'Close', { duration: 2500 });
          this.cancelEdit();
          this.loadExaminationTypes();
        },
        error: (err) => this.snack.open(err.error?.message || 'Failed to update type', 'Close', { duration: 3000 })
      });
    } else {
      this.academic.createExaminationType(payload).pipe(
        finalize(() => {
          this.saving.set(false);
          this.cdr.detectChanges();
        })
      ).subscribe({
        next: () => {
          this.snack.open('Examination type created', 'Close', { duration: 2500 });
          this.typeForm.reset({ isActive: true, weightagePercentage: 0 });
          this.loadExaminationTypes();
        },
        error: (err) => this.snack.open(err.error?.message || 'Failed to create type', 'Close', { duration: 3000 })
      });
    }
  }

  editType(type: ExaminationType): void {
    this.isEditMode.set(true);
    this.editingId = type.id;
    this.typeForm.patchValue({
      name: type.name,
      description: type.description,
      weightagePercentage: type.weightagePercentage,
      isActive: type.isActive
    });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  cancelEdit(): void {
    this.isEditMode.set(false);
    this.editingId = null;
    this.typeForm.reset({ isActive: true, weightagePercentage: 0 });
  }

  deleteType(type: ExaminationType): void {
    if (!confirm(`Delete examination type "${type.name}"?`)) return;
    this.academic.deleteExaminationType(type.id).subscribe({
      next: () => {
        this.snack.open('Examination type deleted', 'Close', { duration: 2500 });
        this.loadExaminationTypes();
      },
      error: (err) => this.snack.open(err.error?.message || 'Failed to delete type', 'Close', { duration: 3000 })
    });
  }
}
