import { Component, OnInit, ViewChild, AfterViewInit, Inject, Input, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatTableModule, MatTableDataSource } from '@angular/material/table';
import { MatPaginatorModule, MatPaginator } from '@angular/material/paginator';
import { MatCardModule } from '@angular/material/card';
import { PageHeaderComponent } from '../../shared/components/page-patterns/index';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { MatInputModule } from '@angular/material/input';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatDialog, MatDialogModule, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { forkJoin, catchError } from 'rxjs';
import { AdvancedAcademicService } from '../../services/advanced-academic.service';
import { ExamResult, Class, Subject, ExaminationType, AcademicYear } from '../../shared/models/academic.models';
import { CanWriteDirective } from '../../core/directives/permission.directive';
import { Permission } from '../../core/models/permission.model';
import { DialogUtils } from '../../shared/dialog-utils';

interface StudentOption {
  id: number;
  fullName: string;
  rollNumber?: string;
}

/** Matches the flat DTO returned by GET /api/AdvancedAcademic/results. */
interface ResultRow {
  id: number;
  studentId: number;
  studentName: string;
  subjectId: number;
  subjectName: string;
  examType: string;
  examDate: Date;
  marksObtained: number;
  totalMarks: number;
  grade: string;
  remarks?: string;
}

/**
 * Exam results — SINGLE PAGE.
 *
 * The old split (list page + separate /results/enter form page) is merged here:
 * the filterable results table lives together with the "Enter Result" popup
 * (add) and the per-row edit/delete actions. Both URLs
 * /app/examinations/results and /app/examinations/results/enter resolve to
 * this page, backed by the same CRUD endpoints used before:
 * GET/POST/PUT/DELETE /api/AdvancedAcademic/results.
 *
 * Zoneless change detection: all template-bound async state is held in SIGNALS.
 * A signal write schedules a change-detection pass itself, so updating them from
 * HTTP callbacks is always consistent — no NG0100, no stale "Loading..." UI.
 */
@Component({
  selector: 'app-results-view',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatTableModule,
    MatPaginatorModule,
    MatCardModule,
    PageHeaderComponent,
    MatButtonModule,
    MatIconModule,
    MatFormFieldModule,
    MatSelectModule,
    MatInputModule,
    MatTooltipModule,
    MatProgressSpinnerModule,
    MatSnackBarModule,
    MatDialogModule,
    CanWriteDirective
  ],
  templateUrl: './results-view.component.html',
  styleUrls: ['./results-view.component.scss']
})
export class ResultsViewComponent implements OnInit, AfterViewInit {
  Permission = Permission;
  /**
   * Embedded mode (used by the Advanced Academic "Exam Results" tab):
   * drops the page header's back arrow — inside a tab there is no parent
   * page to go "back" to; the tab strip is the navigation.
   */
  @Input() embedded = false;
  @ViewChild(MatPaginator) paginator!: MatPaginator;

  displayedColumns: string[] = ['studentName', 'subjectName', 'examType', 'examDate', 'marks', 'grade', 'actions'];
  resultsDataSource = new MatTableDataSource<ResultRow>([]);

  // Signal-based async state (zoneless-safe: writes schedule their own CD pass)
  readonly loading = signal(false);
  readonly subjects = signal<Subject[]>([]);
  readonly examTypes = signal<ExaminationType[]>([]);

  /**
   * Subjects are class-scoped in the DB, so the flat /academic/subjects list
   * repeats the same name once per class ("Computer Science", "Computer
   * Science", …). Dedupe by name for the filter dropdown; the filter itself
   * matches on subject NAME so a selection covers every class's copy.
   */
  readonly subjectOptions = computed(() => {
    const seen = new Set<string>();
    return this.subjects().filter(s => {
      if (!s?.name || seen.has(s.name)) return false;
      seen.add(s.name);
      return true;
    });
  });

  // Filters (values are only ever changed by template events, which trigger CD)
  subjectFilter: string | null = null;
  examTypeFilter: string | null = null;
  gradeFilter: string | null = null;

  /** Unfiltered copy from the server — filters are applied on top, never destructively. */
  private allResults = signal<any[]>([]);

  constructor(
    private academic: AdvancedAcademicService,
    private snack: MatSnackBar,
    private dialog: MatDialog,
    private dialogUtils: DialogUtils,
  ) {}

  ngOnInit(): void {
    forkJoin({
      subjects: this.academic.getSubjects().pipe(catchError(() => [])),
      examTypes: this.academic.getExaminationTypes().pipe(catchError(() => []))
    }).subscribe(({ subjects, examTypes }) => {
      this.subjects.set(subjects || []);
      this.examTypes.set(examTypes || []);
    });

    this.load();
  }

  ngAfterViewInit(): void {
    // The paginator is always rendered (no *ngIf), so it exists exactly once here.
    this.resultsDataSource.paginator = this.paginator;
  }

  load(): void {
    this.loading.set(true);
    this.academic.getResults().subscribe({
      next: (results: any[]) => {
        // API returns studentName/subjectName directly; older rows may not have them
        this.allResults.set((results || []).map(r => ({
          id: r.id ?? 0,
          studentId: r.studentId,
          studentName: r.studentName || `Student #${r.studentId}`,
          subjectId: r.subjectId,
          subjectName: r.subjectName || `Subject #${r.subjectId}`,
          examType: r.examType,
          examDate: r.examDate ? new Date(r.examDate) : new Date(),
          marksObtained: r.marksObtained,
          totalMarks: r.totalMarks,
          grade: r.grade || '',
          remarks: r.remarks || ''
        })));
        this.applyFilters();
        this.loading.set(false); // signal write schedules the re-render with fresh data
      },
      error: () => {
        this.loading.set(false);
        this.snack.open('Failed to load results', 'Close', { duration: 3000 });
      }
    });
  }

  // ------------------------------------------------------------------
  // Add — "Enter Result" popup
  // ------------------------------------------------------------------
  openEnterDialog(): void {
    const dialogRef = this.dialog.open(ResultEntryDialog, {
        ...this.dialogUtils.getMobileConfig({ width: '560px', data: { subjects: this.subjects(), examTypes: this.examTypes() } }),
            });
    // Class list for the cascade is fetched by the dialog itself (lazy).

    dialogRef.afterClosed().subscribe((payload: ExamResult | undefined) => {
      if (!payload) return;
      this.academic.createResult(payload).subscribe({
        next: () => {
          this.snack.open('Result saved', 'Close', { duration: 2500 });
          this.load();
        },
        error: (err) => this.snack.open(err?.error?.message || 'Failed to save result', 'Close', { duration: 3500 })
      });
    });
  }

  // ------------------------------------------------------------------
  // Edit — popup per row
  // ------------------------------------------------------------------
  editResult(row: ResultRow): void {
    const dialogRef = this.dialog.open(ResultEditDialog, {
        ...this.dialogUtils.getMobileConfig({ width: '480px', data: { result: row, examTypes: this.examTypes() } }),
            });

    dialogRef.afterClosed().subscribe(result => {
      if (!result || !row.id) return;
      this.academic.updateResult(row.id, result).subscribe({
        next: () => {
          this.snack.open('Result updated', 'Close', { duration: 2500 });
          this.load();
        },
        error: (err) => this.snack.open(err?.error?.message || 'Failed to update result', 'Close', { duration: 3500 })
      });
    });
  }

  deleteResult(row: ResultRow): void {
    if (!row.id) return;
    if (!confirm(`Delete this result for ${row.studentName}?`)) return;
    this.academic.deleteResult(row.id).subscribe({
      next: () => {
        this.snack.open('Result deleted', 'Close', { duration: 2500 });
        this.load();
      },
      error: () => this.snack.open('Failed to delete result', 'Close', { duration: 3000 })
    });
  }

  /** Rebuilds the table from allResults (non-destructive — filters remain undoable). */
  applyFilters(): void {
    this.resultsDataSource.data = this.allResults().filter(r => {
      if (this.subjectFilter && r.subjectName !== this.subjectFilter) return false;
      if (this.examTypeFilter && r.examType !== this.examTypeFilter) return false;
      if (this.gradeFilter && !(r.grade || '').startsWith(this.gradeFilter)) return false;
      return true;
    });
  }

  onFilterChange(): void {
    this.applyFilters();
  }

  getGradeColor(grade?: string): string {
    if (!grade) return 'basic';
    if (grade.startsWith('A')) return 'primary';
    if (grade.startsWith('B')) return 'accent';
    if (grade.startsWith('C') || grade.startsWith('D')) return 'warn';
    return 'basic';
  }

  formatDate(date: Date | string): string {
    const d = date instanceof Date ? date : new Date(date);
    return new Intl.DateTimeFormat('en-US', { year: 'numeric', month: 'short', day: 'numeric' }).format(d);
  }
}

/** Auto-calculates the letter grade from a percentage (shared by both dialogs). */
function gradeFor(marks: number | null, total: number | null): string {
  if (marks == null || !total || total <= 0) return '';
  const pct = (marks / total) * 100;
  if (pct >= 90) return 'A+';
  if (pct >= 80) return 'A';
  if (pct >= 70) return 'B';
  if (pct >= 60) return 'C';
  if (pct >= 50) return 'D';
  if (pct >= 40) return 'E';
  return 'F';
}

/**
 * Add-result dialog with the class → student cascade from the old form page.
 * Closes with a ready-to-post ExamResult payload (undefined = cancelled).
 */
@Component({
  selector: 'app-result-entry-dialog',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatDialogModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatAutocompleteModule,
    MatProgressSpinnerModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatButtonModule
  ],
  template: `
    <h2 mat-dialog-title>Enter Exam Result</h2>
    <mat-dialog-content>
      <form [formGroup]="form" class="result-form">
        <mat-form-field appearance="outline">
          <mat-label>Academic Year</mat-label>
          <mat-select formControlName="academicYearId" (selectionChange)="onAcademicYearChange($event.value)">
            <mat-option *ngFor="let y of academicYears()" [value]="y.id">{{ y.name }}</mat-option>
          </mat-select>
          <mat-error>Select an academic year</mat-error>
        </mat-form-field>

        <mat-form-field appearance="outline">
          <mat-label>Class</mat-label>
          <mat-select formControlName="classId" (selectionChange)="onClassChange($event.value)">
            <mat-option *ngFor="let c of classes()" [value]="c.id">{{ c.name }}</mat-option>
          </mat-select>
          <mat-hint *ngIf="!form.get('academicYearId')?.value">Select an academic year first</mat-hint>
          <mat-error>Select a class</mat-error>
        </mat-form-field>

        <mat-form-field appearance="outline">
          <mat-label>Search Student</mat-label>
          <input type="text" matInput placeholder="Type student name or roll no"
                 [formControl]="studentSearch"
                 [matAutocomplete]="studentAuto">
          <mat-autocomplete #studentAuto="matAutocomplete" autoActiveFirstOption
                            [displayWith]="displayStudent"
                            (optionSelected)="onStudentSelected($event)">
            <mat-option *ngIf="loadingStudents()" class="is-loading">
              <mat-spinner diameter="20"></mat-spinner>
            </mat-option>
            <mat-option *ngFor="let s of filteredStudents()" [value]="s">
              {{ displayStudent(s) }}{{ s.rollNumber ? ' — ' + s.rollNumber : '' }}
            </mat-option>
          </mat-autocomplete>
          <mat-hint *ngIf="!form.get('classId')?.value">Select a class first</mat-hint>
          <mat-hint *ngIf="form.get('classId')?.value && students().length === 0">No students in this class</mat-hint>
          <mat-error>Select a student</mat-error>
        </mat-form-field>

        <mat-form-field appearance="outline">
          <mat-label>Subject</mat-label>
          <mat-select formControlName="subjectId">
            <mat-option *ngFor="let sub of subjectsForClass()" [value]="sub.id">{{ sub.name }}{{ sub.code ? ' (' + sub.code + ')' : '' }}</mat-option>
          </mat-select>
          <mat-hint *ngIf="!form.get('classId')?.value">Select a class first</mat-hint>
          <mat-error>Select a subject</mat-error>
        </mat-form-field>

        <mat-form-field appearance="outline">
          <mat-label>Exam Type</mat-label>
          <mat-select formControlName="examType">
            <mat-option *ngFor="let t of data.examTypes" [value]="t.name">{{ t.name }}</mat-option>
          </mat-select>
          <mat-error>Select an exam type</mat-error>
        </mat-form-field>

        <mat-form-field appearance="outline">
          <mat-label>Exam Date</mat-label>
          <input matInput [matDatepicker]="picker" formControlName="examDate" />
          <mat-datepicker-toggle matSuffix [for]="picker"></mat-datepicker-toggle>
          <mat-datepicker #picker></mat-datepicker>
          <mat-error>Pick a date</mat-error>
        </mat-form-field>

        <mat-form-field appearance="outline">
          <mat-label>Total Marks</mat-label>
          <input matInput type="number" formControlName="totalMarks" />
          <mat-error>Required, minimum 1</mat-error>
        </mat-form-field>

        <mat-form-field appearance="outline">
          <mat-label>Marks Obtained</mat-label>
          <input matInput type="number" formControlName="marksObtained" />
          <mat-error>Required, 0 or more</mat-error>
        </mat-form-field>

        <mat-form-field appearance="outline">
          <mat-label>Grade (auto)</mat-label>
          <input matInput formControlName="grade" readonly />
        </mat-form-field>

        <mat-form-field appearance="outline" class="full">
          <mat-label>Remarks</mat-label>
          <textarea matInput formControlName="remarks" rows="2"></textarea>
        </mat-form-field>
      </form>
    </mat-dialog-content>
    <mat-dialog-actions align="end">
      <button mat-button mat-dialog-close>Cancel</button>
      <button mat-raised-button color="primary" (click)="save()" [disabled]="form.invalid">Save</button>
    </mat-dialog-actions>
  `,
  styles: [`
    .result-form { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; }
    .result-form mat-form-field { width: 100%; }
    .full { grid-column: span 2; }

    /* ── Mobile: compact single-column sheet (matches sibling dialogs) ── */
    @media (max-width: 600px) {
      h2[mat-dialog-title] {
        font-size: var(--font-size-base);
        font-weight: 700;
        padding: 12px 16px 8px;
        margin: 0;
        border-bottom: 1px solid var(--st-border-soft, var(--md-surface-container-low));
      }

      mat-dialog-content { padding: 0 !important; }

      .result-form {
        grid-template-columns: 1fr;
        gap: 2px;
        padding: 10px 14px 14px;
      }
      .full { grid-column: 1 / -1; }

      /* Don't reserve an empty subscript row under every field —
         it was the source of the huge field-to-field gaps. */
      .result-form mat-form-field .mat-mdc-form-field-subscript-wrapper {
        min-height: 0;
        padding-bottom: 0;
      }
      .result-form mat-form-field:not(.mat-form-field-invalid)
        .mat-mdc-form-field-hint-wrapper:not(:has(mat-hint)) {
        display: none;
      }

      textarea[matInput] { min-height: 48px; }
    }
  `]
})
export class ResultEntryDialog implements OnInit {
  readonly classes = signal<Class[]>([]);
  readonly students = signal<StudentOption[]>([]);
  /** Subjects of the selected class — class-scoped subjects, so no duplicates. */
  readonly subjectsForClass = signal<Subject[]>([]);
  readonly academicYears = signal<AcademicYear[]>([]);
  readonly loadingStudents = signal(false);

  /** Search text + filtered list for the student autocomplete (fees-dialog pattern). */
  studentSearch = new FormControl('');
  readonly studentQuery = signal('');
  readonly filteredStudents = computed(() => {
    const q = this.studentQuery().trim().toLowerCase();
    const list = this.students();
    if (!q) return list;
    return list.filter(s =>
      s.fullName.toLowerCase().includes(q) ||
      (s.rollNumber || '').toLowerCase().includes(q));
  });
  form: FormGroup;

  constructor(
    private fb: FormBuilder,
    private academic: AdvancedAcademicService,
    public dialogRef: MatDialogRef<ResultEntryDialog>,
    @Inject(MAT_DIALOG_DATA) public data: { subjects: Subject[]; examTypes: ExaminationType[] }
  ) {
    this.form = this.fb.group({
      academicYearId: [null, Validators.required],
      classId: [null, Validators.required],
      studentId: [null, Validators.required],
      subjectId: [null, Validators.required],
      examType: ['', Validators.required],
      examDate: [new Date(), Validators.required],
      marksObtained: [null, [Validators.required, Validators.min(0)]],
      totalMarks: [100, [Validators.required, Validators.min(1)]],
      grade: [''],
      remarks: ['']
    });

    // Auto-calculate grade when marks change
    this.form.get('marksObtained')!.valueChanges.subscribe(m => {
      this.form.patchValue({ grade: gradeFor(m, this.form.get('totalMarks')?.value) }, { emitEvent: false });
    });
    this.form.get('totalMarks')!.valueChanges.subscribe(t => {
      this.form.patchValue({ grade: gradeFor(this.form.get('marksObtained')?.value, t) }, { emitEvent: false });
    });
  }

  ngOnInit(): void {
    // Academic years drive the class cascade; classes load per selected year.
    this.academic.getAcademicYears().pipe(catchError(() => [] as AcademicYear[])).subscribe(years => {
      this.academicYears.set((years as AcademicYear[]) || []);
    });

    // The control's value is a string while typing, but the whole StudentOption
    // object once a student is picked (autocomplete bind value + displayWith).
    // Only string values are search text; object emissions reset the query.
    this.studentSearch.valueChanges.subscribe(v => this.studentQuery.set(typeof v === 'string' ? v : ''));
  }

  /** Classes follow the selected academic year in the dialog. */
  onAcademicYearChange(yearId: number | null): void {
    this.form.patchValue({ classId: null, studentId: null, subjectId: null });
    this.classes.set([]);
    this.students.set([]);
    this.subjectsForClass.set([]);
    this.studentSearch.reset('');
    if (!yearId) return;

    this.academic.getClassesByAcademicYear(yearId).pipe(catchError(() => [] as Class[])).subscribe(classes => {
      this.classes.set((classes as Class[]) || []);
    });
  }

  /** Load students for the selected class via /api/students/class/{id}. */
  onClassChange(classId: number | null): void {
    this.form.patchValue({ studentId: null, subjectId: null });
    this.students.set([]);
    this.subjectsForClass.set([]);
    this.studentSearch.reset('');
    if (!classId) return;

    // Subjects cascade from the class too — the flat /academic/subjects list
    // repeats names across classes; per-class subjects are unique by name.
    this.academic.getSubjects(classId).pipe(catchError(() => [] as Subject[])).subscribe(subjects => {
      const subjectList = Array.isArray(subjects) ? subjects : subjects ? [subjects] : [];
      this.subjectsForClass.set(subjectList.filter((subject): subject is Subject => !!subject));
    });

    this.loadingStudents.set(true);
    this.academic.getStudentsByClass$(classId).subscribe({
      // API shape varies — normalise to { id, fullName, rollNumber } so the
      // autocomplete always binds (fixes students previously not binding).
      next: (students) => {
        this.students.set(this.normalizeStudents(students || []));
        this.loadingStudents.set(false);
      },
      error: () => {
        this.students.set([]);
        this.loadingStudents.set(false);
      }
    });
  }

  private normalizeStudents(list: any[]): StudentOption[] {
    return list.map(s => {
      const id = s.id ?? s.studentId;
      const fullName = s.fullName || s.name ||
        [s.firstName, s.lastName].filter(Boolean).join(' ').trim();
      return {
        id,
        fullName: fullName || `Student #${id}`,
        rollNumber: s.rollNumber ?? s.rollNo ?? s.admissionNumber
      } as StudentOption;
    }).filter((s: StudentOption) => s.id != null);
  }

  /** Autocomplete display + selection (value is the whole student option). */
  displayStudent(s: StudentOption | null): string {
    return s ? s.fullName : '';
  }

  onStudentSelected(event: { option: { value: StudentOption | null } }): void {
    const s = event.option?.value;
    this.form.patchValue({ studentId: s?.id ?? null });
  }

  save(): void {
    if (this.form.invalid) {
      // Surface the student error under the search input (it validates
      // studentId, not the typed text).
      if (this.form.get('studentId')?.invalid) {
        this.studentSearch.setErrors({ required: true });
      }
      this.form.markAllAsTouched();
      return;
    }
    const fv = this.form.value;
    this.dialogRef.close({
      studentId: fv.studentId,
      subjectId: fv.subjectId,
      examType: fv.examType,
      examDate: fv.examDate instanceof Date ? fv.examDate.toISOString() : fv.examDate,
      marksObtained: fv.marksObtained,
      totalMarks: fv.totalMarks,
      grade: fv.grade || '',
      remarks: fv.remarks || ''
    } as ExamResult);
  }
}

/** Edit dialog for an existing result — PUT /api/AdvancedAcademic/results/{id}. */
@Component({
  selector: 'app-result-edit-dialog',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatDialogModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatButtonModule
  ],
  template: `
    <h2 mat-dialog-title>Edit Result — {{ data.result.studentName }}</h2>
    <mat-dialog-content>
      <form [formGroup]="form" class="result-form">
        <mat-form-field appearance="outline">
          <mat-label>Exam Type</mat-label>
          <mat-select formControlName="examType">
            <mat-option *ngFor="let t of data.examTypes" [value]="t.name">{{ t.name }}</mat-option>
          </mat-select>
        </mat-form-field>

        <mat-form-field appearance="outline">
          <mat-label>Exam Date</mat-label>
          <input matInput [matDatepicker]="picker" formControlName="examDate" />
          <mat-datepicker-toggle matSuffix [for]="picker"></mat-datepicker-toggle>
          <mat-datepicker #picker></mat-datepicker>
        </mat-form-field>

        <mat-form-field appearance="outline">
          <mat-label>Marks Obtained</mat-label>
          <input matInput type="number" formControlName="marksObtained" />
        </mat-form-field>

        <mat-form-field appearance="outline">
          <mat-label>Total Marks</mat-label>
          <input matInput type="number" formControlName="totalMarks" />
        </mat-form-field>

        <mat-form-field appearance="outline">
          <mat-label>Grade (auto)</mat-label>
          <input matInput formControlName="grade" readonly />
        </mat-form-field>

        <mat-form-field appearance="outline" class="full">
          <mat-label>Remarks</mat-label>
          <textarea matInput formControlName="remarks" rows="2"></textarea>
        </mat-form-field>
      </form>
    </mat-dialog-content>
    <mat-dialog-actions align="end">
      <button mat-button mat-dialog-close>Cancel</button>
      <button mat-raised-button color="primary" (click)="save()" [disabled]="form.invalid">Save</button>
    </mat-dialog-actions>
  `,
  styles: [`
    .result-form { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; }
    .result-form mat-form-field { width: 100%; }
    .full { grid-column: span 2; }

    /* ── Mobile: compact single-column sheet (matches sibling dialogs) ── */
    @media (max-width: 600px) {
      h2[mat-dialog-title] {
        font-size: var(--font-size-base);
        font-weight: 700;
        padding: 12px 16px 8px;
        margin: 0;
        border-bottom: 1px solid var(--st-border-soft, var(--md-surface-container-low));
      }

      mat-dialog-content { padding: 0 !important; }

      .result-form {
        grid-template-columns: 1fr;
        gap: 2px;
        padding: 10px 14px 14px;
      }
      .full { grid-column: 1 / -1; }

      /* Don't reserve an empty subscript row under every field —
         it was the source of the huge field-to-field gaps. */
      .result-form mat-form-field .mat-mdc-form-field-subscript-wrapper {
        min-height: 0;
        padding-bottom: 0;
      }
      .result-form mat-form-field:not(.mat-form-field-invalid)
        .mat-mdc-form-field-hint-wrapper:not(:has(mat-hint)) {
        display: none;
      }

      textarea[matInput] { min-height: 48px; }
    }
  `]
})
export class ResultEditDialog {
  form: FormGroup;

  constructor(
    private fb: FormBuilder,
    public dialogRef: MatDialogRef<ResultEditDialog>,
    @Inject(MAT_DIALOG_DATA) public data: { result: ResultRow; examTypes: ExaminationType[] }
  ) {
    const r = data.result;
    this.form = this.fb.group({
      studentId: [r.studentId, Validators.required],
      subjectId: [r.subjectId, Validators.required],
      examType: [r.examType, Validators.required],
      examDate: [r.examDate instanceof Date ? r.examDate : new Date(r.examDate), Validators.required],
      marksObtained: [r.marksObtained, [Validators.required, Validators.min(0)]],
      totalMarks: [r.totalMarks, [Validators.required, Validators.min(1)]],
      grade: [r.grade ?? ''],
      remarks: [r.remarks ?? '']
    });

    this.form.get('marksObtained')!.valueChanges.subscribe(m => {
      this.form.patchValue({ grade: gradeFor(m, this.form.get('totalMarks')?.value) }, { emitEvent: false });
    });
    this.form.get('totalMarks')!.valueChanges.subscribe(t => {
      this.form.patchValue({ grade: gradeFor(this.form.get('marksObtained')?.value, t) }, { emitEvent: false });
    });
  }

  save(): void {
    if (this.form.invalid) return;
    const v = this.form.value;
    this.dialogRef.close({
      ...v,
      id: this.data.result.id,
      examDate: v.examDate instanceof Date ? v.examDate.toISOString() : v.examDate
    });
  }
}
