import { ChangeDetectorRef, Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatTableModule } from '@angular/material/table';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatCardModule } from '@angular/material/card';
import { PageHeaderComponent } from '../../shared/components/page-patterns/index';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatDividerModule } from '@angular/material/divider';
import { forkJoin, of } from 'rxjs';
import { catchError, finalize } from 'rxjs/operators';
import { AdvancedAcademicService } from '../../services/advanced-academic.service';
import { Examination, ExaminationType, AcademicYear } from '../../shared/models/academic.models';
import { AcademicYearContextService } from '../../shared/services/academic-year-context.service';
import { CanWriteDirective, CanDeleteDirective } from '../../core/directives/permission.directive';
import { Permission } from '../../core/models/permission.model';

@Component({
  selector: 'app-examination-list',
  standalone: true,
  imports: [
    CommonModule,
    RouterModule,
    FormsModule,
    ReactiveFormsModule,
    MatTableModule,
    MatButtonModule,
    MatIconModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatCardModule,
    PageHeaderComponent,
    MatDatepickerModule,
    MatNativeDateModule,
    MatTooltipModule,
    MatSnackBarModule,
    MatProgressSpinnerModule,
    MatDividerModule,
    CanWriteDirective,
    CanDeleteDirective
  ],
  templateUrl: './examination-list.component.html',
  styleUrls: ['./examination-list.component.scss']
})
export class ExaminationListComponent implements OnInit {
  Permission = Permission;
  displayedColumns: string[] = ['title', 'examType', 'academicYear', 'startDate', 'endDate', 'status', 'actions'];
  exams = signal<any[]>([]);
  examTypes = signal<any[]>([]);
  academicYears = signal<any[]>([]);
  loading = signal(false);
  initialLoading = true;

  examForm: FormGroup;
  creating = signal(false);
  isEditMode = signal(false);
  editingExamId: number | null = null;

  constructor(
    private academic: AdvancedAcademicService,
    private fb: FormBuilder,
    private snack: MatSnackBar,
    private cdr: ChangeDetectorRef,
    private yearContext: AcademicYearContextService
  ) {
    this.examForm = this.fb.group({
      title: ['', [Validators.required, Validators.minLength(3)]],
      examinationTypeId: ['', Validators.required],
      academicYearId: ['', Validators.required],
      startDate: [null, Validators.required],
      endDate: [null, Validators.required],
      instructions: ['']
    });
  }

  getErrorMessage(controlName: string): string {
    const control = this.examForm.get(controlName);
    if (control?.hasError('required')) return 'This field is required';
    if (control?.hasError('minlength')) return `Minimum length is ${control.errors?.['minlength'].requiredLength}`;
    return '';
  }

  ngOnInit(): void {
    this.loadInitialData();
  }

  loadInitialData(): void {
    this.initialLoading = true;
    this.cdr.detectChanges();

    forkJoin({
      // Issue #14: log lookup failures instead of silently rendering empty lists.
      exams: this.academic.getExaminations().pipe(catchError((err) => { console.error('Failed to load examinations', err); return of([]); })),
      types: this.academic.getExaminationTypes().pipe(catchError((err) => { console.error('Failed to load examination types', err); return of([]); })),
      years: this.yearContext.loadAcademicYears().pipe(catchError((err) => { console.error('Failed to load academic years', err); return of([]); }))
    }).pipe(
      finalize(() => {
        this.initialLoading = false;
        this.loading.set(false);
        this.cdr.detectChanges();
      })
    ).subscribe({
      next: (results) => {
        this.exams.set(results.exams || []);
        this.examTypes.set(results.types || []);
        this.academicYears.set(this.yearContext.yearsSnapshot as any[] || []);
        
        // Set selected academic year from context
        const selectedId = this.yearContext.selectedYearId;
        if (selectedId) {
          this.examForm.get('academicYearId')?.setValue(selectedId);
        }
      },
      error: () => this.snack.open('Error loading examination data', 'Close', { duration: 3000 })
    });
  }

  loadExaminations(): void {
    this.loading.set(true);
    this.cdr.detectChanges();

    this.academic.getExaminations().pipe(
      finalize(() => {
        this.loading.set(false);
        this.cdr.detectChanges();
      })
    ).subscribe({
      next: (data) => { 
        this.exams.set(data || []); 
      },
      error: () => { 
        this.snack.open('Failed to load examinations', 'Close', { duration: 3000 }); 
      }
    });
  }

  onSubmit(): void {
    if (this.examForm.invalid) return;
    this.creating.set(true);
    this.cdr.detectChanges();
    
    const payload = this.examForm.value;

    if (this.isEditMode() && this.editingExamId) {
      this.academic.updateExamination(this.editingExamId, payload).pipe(
        finalize(() => {
          this.creating.set(false);
          this.cdr.detectChanges();
        })
      ).subscribe({
        next: () => {
          this.snack.open('Examination updated', 'Close', { duration: 2500 });
          this.cancelEdit();
          this.loadExaminations();
        },
        error: (err) => this.snack.open(err.error?.message || 'Failed to update examination', 'Close', { duration: 3000 })
      });
    } else {
      this.academic.createExamination(payload).pipe(
        finalize(() => {
          this.creating.set(false);
          this.cdr.detectChanges();
        })
      ).subscribe({
        next: () => {
          this.snack.open('Examination created successfully', 'Close', { duration: 2500 });
          this.examForm.reset();
          this.loadExaminations();
        },
        error: (err) => this.snack.open(err.error?.message || 'Failed to create examination', 'Close', { duration: 3000 })
      });
    }
  }

  editExam(exam: Examination): void {
    this.isEditMode.set(true);
    this.editingExamId = exam.id;
    
    // Ensure dates are actual Date objects for the picker
    const startDate = exam.startDate ? new Date(exam.startDate) : null;
    const endDate = exam.endDate ? new Date(exam.endDate) : null;

    this.examForm.patchValue({
      title: exam.title,
      examinationTypeId: exam.examinationTypeId,
      academicYearId: exam.academicYearId,
      startDate: startDate,
      endDate: endDate,
      instructions: exam.instructions
    });
    // Scroll to form
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  cancelEdit(): void {
    this.isEditMode.set(false);
    this.editingExamId = null;
    this.examForm.reset();
    // Set current academic year as default again
    const currentYear = this.academicYears().find(y => y.isCurrent);
    if (currentYear) {
      this.examForm.get('academicYearId')?.setValue(currentYear.id);
    }
  }

  deleteExam(exam: Examination): void {
    if (!confirm(`Are you sure you want to delete examination "${exam.title}"?`)) return;
    this.academic.deleteExamination(exam.id).subscribe({
      next: () => { 
        this.snack.open('Examination deleted', 'Close', { duration: 2500 }); 
        this.loadExaminations(); 
      },
      error: () => this.snack.open('Failed to delete examination', 'Close', { duration: 3000 })
    });
  }

  getExamTypeName(typeId: number): string {
    return this.examTypes().find(t => t.id === typeId)?.name || 'Unknown';
  }

  getAcademicYearName(yearId: number): string {
    return this.academicYears().find(y => y.id === yearId)?.name || 'N/A';
  }
}
