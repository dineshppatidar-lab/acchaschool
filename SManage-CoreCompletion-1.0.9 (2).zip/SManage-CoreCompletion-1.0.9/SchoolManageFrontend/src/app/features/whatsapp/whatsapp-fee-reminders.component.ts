import { ChangeDetectorRef, Component, Inject, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatDialogModule, MatDialog } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatTableModule } from '@angular/material/table';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { RouterModule } from '@angular/router';
import { BackButtonComponent } from '../../shared/components/back-button.component';
import { CanWriteDirective } from '../../core/directives/permission.directive';
import { Permission } from '../../core/models/permission.model';
import { MasterDataService } from '../../core/services/master-data.service';
import { AcademicYearContextService } from '../../shared/services/academic-year-context.service';
import { DialogUtils } from '../../shared/dialog-utils';
import {
  WhatsAppService, WhatsAppRecipient, WhatsAppTemplate, WhatsAppBulkSendResult, WhatsAppConfig
} from '../../shared/services/whatsapp.service';

@Component({
  selector: 'app-whatsapp-fee-reminders',
  standalone: true,
  imports: [
    CommonModule, FormsModule, MatButtonModule, MatCardModule, MatCheckboxModule,
    MatDialogModule, MatFormFieldModule, MatIconModule, MatInputModule, MatSelectModule,
    MatSnackBarModule, MatProgressSpinnerModule, MatTooltipModule, MatTableModule,
    BackButtonComponent, CanWriteDirective, RouterModule
  ],
  templateUrl: './whatsapp-fee-reminders.component.html',
  styleUrls: ['./whatsapp-fee-reminders.component.scss']
})
export class WhatsAppFeeRemindersComponent implements OnInit {
  Permission = Permission;
  displayedColumns = ['select', 'student', 'class', 'parent', 'phone', 'installment', 'dueDate', 'outstanding', 'status'];

  isLoading = signal(false);
  isSending = signal(false);

  // Filters
  academicYearId = signal<any>(null);
  classId: number | null = null;
  sectionId: number | null = null;
  overdueStatus: string = '';
  minOutstanding: number | null = null;

  classes = signal<any[]>([]);
  sections = signal<any[]>([]);
  templates = signal<any[]>([]);
  selectedTemplateId = signal<any>(null);

  recipients = signal<any[]>([]);
  selectedIds = new Set<number>();

  // Active messaging channel from the tenant config ("WhatsApp" | "Arattai" | null when disabled/unconfigured).
  activeChannel = signal<string | null>(null);

  // Send result summary
  lastResult = signal<any>(null);

  constructor(
    private whatsappService: WhatsAppService,
    private masterDataService: MasterDataService,
    public yearContext: AcademicYearContextService,
    private dialog: MatDialog,
    private dialogUtils: DialogUtils,
    private snackBar: MatSnackBar,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.loadMasterData();
    this.loadTemplates();
    this.loadChannel();
  }

  /** Shows the tenant's configured provider so staff know the channel before composing a send. */
  private loadChannel(): void {
    this.whatsappService.getConfig().subscribe({
      next: (config: WhatsAppConfig) => {
        // Null-guard: an empty/absent config (e.g. race on first load) must not
        // throw "Cannot read properties of undefined (reading 'isEnabled')".
        if (!config?.isEnabled) { this.activeChannel.set(null); }
        else { this.activeChannel.set(config.provider === 'Arattai' ? 'Arattai' : 'WhatsApp'); }
        this.cdr.markForCheck();
      },
      error: () => { this.activeChannel.set(null); }
    });
  }

  loadMasterData(): void {
    this.yearContext.loadAcademicYears().subscribe(() => {
      const yearId = this.yearContext.selectedYearId;
      if (yearId) {
        this.academicYearId.set(yearId);
        this.loadClasses(yearId);
      }
      this.cdr.markForCheck();
    });
  }

  loadClasses(yearId: number): void {
    this.masterDataService.getClassesByAcademicYear(yearId).subscribe({
      next: classes => {
        this.classes.set(classes);
        this.cdr.markForCheck();
      },
      error: () => {}
    });
  }

  loadTemplates(): void {
    this.whatsappService.getTemplates().subscribe({
      next: templates => {
        this.templates.set(templates.filter(t => t.isActive));
        if (this.templates().length > 0 && !this.selectedTemplateId()) {
          this.selectedTemplateId.set(this.templates()[0].id);
        }
        this.cdr.markForCheck();
      },
      error: () => {}
    });
  }

  onClassChange(): void {
    this.sectionId = null;
    this.sections.set([]);
    if (this.classId) {
      this.masterDataService.getSectionsByClass(this.classId).subscribe(sections => {
        this.sections.set(sections);
        this.cdr.markForCheck();
      });
    }
  }

  search(): void {
    this.isLoading.set(true);
    this.recipients.set([]);
    this.selectedIds.clear();
    this.lastResult.set(null);

    this.whatsappService.previewRecipients({
      academicYearId: this.academicYearId() ?? undefined,
      classId: this.classId ?? undefined,
      sectionId: this.sectionId ?? undefined,
      overdueStatus: this.overdueStatus || undefined,
      minOutstanding: this.minOutstanding ?? undefined
    }).subscribe({
      next: recipients => {
        this.recipients.set(recipients);
        // Pre-select all recipients with valid numbers.
        this.recipients().forEach(r => { if (r.isValidNumber) this.selectedIds.add(r.studentId); });
        this.isLoading.set(false);
        this.cdr.markForCheck();
      },
      error: (err: Error) => {
        this.isLoading.set(false);
        this.snackBar.open(err.message, 'Close', { duration: 5000 });
        this.cdr.markForCheck();
      }
    });
  }

  clearFilters(): void {
    this.classId = null;
    this.sectionId = null;
    this.overdueStatus = '';
    this.minOutstanding = null;
  }

  // ── Selection ────────────────────────────────────────────────────────

  isSelected(studentId: number): boolean {
    return this.selectedIds.has(studentId);
  }

  toggle(studentId: number, checked: boolean): void {
    if (checked) this.selectedIds.add(studentId); else this.selectedIds.delete(studentId);
  }

  toggleAll(checked: boolean): void {
    if (checked) {
      this.recipients().forEach(r => { if (r.isValidNumber) this.selectedIds.add(r.studentId); });
    } else {
      this.selectedIds.clear();
    }
  }

  get allSelected(): boolean {
    const valid = this.recipients().filter(r => r.isValidNumber);
    return valid.length > 0 && valid.every(r => this.selectedIds.has(r.studentId));
  }

  get selectedCount(): number {
    return this.selectedIds.size;
  }

  get validSelectedCount(): number {
    return this.recipients().filter(r => this.selectedIds.has(r.studentId) && r.isValidNumber).length;
  }

  get invalidSelectedCount(): number {
    return this.recipients().filter(r => this.selectedIds.has(r.studentId) && !r.isValidNumber).length;
  }

  get totalOutstandingSelected(): number {
    return this.recipients()
      .filter(r => this.selectedIds.has(r.studentId) && r.isValidNumber)
      .reduce((sum, r) => sum + r.outstandingAmount, 0);
  }

  // ── Preview & send ───────────────────────────────────────────────────

  openPreview(): void {
    if (!this.selectedTemplateId() || this.validSelectedCount === 0) return;

    const template = this.templates().find(t => t.id === this.selectedTemplateId());
    const sample = this.recipients().find(r => this.selectedIds.has(r.studentId) && r.isValidNumber);

    const dialogRef = this.dialog.open(WhatsAppPreviewDialog, {
        ...this.dialogUtils.getMobileConfig({ width: '640px' }),
        data: {
                template,
        sample,
        selectedCount: this.validSelectedCount,
        invalidCount: this.invalidSelectedCount,
        totalOutstanding: this.totalOutstandingSelected
      }
    });

    dialogRef.afterClosed().subscribe(confirmed => {
      if (confirmed) this.send();
    });
  }

  private send(): void {
    if (!this.selectedTemplateId()) return;
    const studentIds = Array.from(this.selectedIds);
    this.isSending.set(true);
    this.cdr.markForCheck();

    this.whatsappService.sendBulk(studentIds, this.selectedTemplateId(), 'Manual').subscribe({
      next: result => {
        this.lastResult.set(result);
        this.isSending.set(false);
        this.snackBar.open(`${result.queued} message(s) queued via ${this.activeChannel() ?? 'messaging'} — status in History`, 'Close', { duration: 4000 });
        this.cdr.markForCheck();
      },
      error: (err: Error) => {
        this.isSending.set(false);
        this.snackBar.open(err.message, 'Close', { duration: 5000 });
        this.cdr.markForCheck();
      }
    });
  }

  // ── Rendering helpers ────────────────────────────────────────────────

  renderPreviewBody(template: WhatsAppTemplate | undefined, r: WhatsAppRecipient | undefined): string {
    if (!template || !r) return '';
    const values: Record<string, string> = {
      ParentName: r.parentName || 'Parent',
      StudentName: r.studentName,
      ClassName: r.className,
      SectionName: r.sectionName,
      FeeType: r.installmentName,
      OutstandingAmount: r.outstandingAmount.toFixed(2),
      InstallmentAmount: r.outstandingAmount.toFixed(2),
      TotalFee: r.totalFee.toFixed(2),
      PaidAmount: r.paidAmount.toFixed(2),
      DueDate: r.dueDate ? new Date(r.dueDate).toLocaleDateString() : '',
      SchoolName: 'School',
      SchoolPhone: '', SchoolEmail: '', PaymentLink: '', AcademicYear: ''
    };
    return template.bodyText.replace(/\{\{\s*(\w+)\s*\}\}/g, (m, key) => values[key] ?? m);
  }
}

// ── Preview dialog ───────────────────────────────────────────────────

@Component({
  selector: 'app-whatsapp-preview-dialog',
  standalone: true,
  imports: [CommonModule, MatDialogModule, MatButtonModule, MatIconModule],
  template: `
    <h2 mat-dialog-title>Confirm Fee Reminders</h2>
    <mat-dialog-content>
      <div class="summary-grid">
        <div class="summary-item"><label>Messages to send</label><span>{{ data.selectedCount }}</span></div>
        <div class="summary-item"><label>Invalid numbers (excluded)</label><span>{{ data.invalidCount }}</span></div>
        <div class="summary-item"><label>Total outstanding</label><span>₹ {{ data.totalOutstanding | number:'1.2-2' }}</span></div>
        <div class="summary-item"><label>Template</label><span>{{ data.template?.name || '—' }}</span></div>
      </div>

      <div class="preview-label">Message preview (sample recipient: {{ data.sample?.parentName || data.sample?.studentName }})</div>
      <pre class="preview-body">{{ renderBody() }}</pre>

      <p class="note">Messages are queued and sent in the background with rate limiting.
      Delivery status appears in WhatsApp History shortly after sending.</p>
    </mat-dialog-content>
    <mat-dialog-actions align="end">
      <button mat-button mat-dialog-close>Cancel</button>
      <button mat-raised-button color="primary" [mat-dialog-close]="true">
        <mat-icon>send</mat-icon> Send Reminders
      </button>
    </mat-dialog-actions>
  `,
  styles: [`
    .summary-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 16px; }
    .summary-item label { display: block; font-size: 11px; color: var(--color-text-secondary); }
    .summary-item span { font-size: 18px; font-weight: 600; }
    .preview-label { font-weight: 500; margin-bottom: 6px; }
    .preview-body { white-space: pre-wrap; background: var(--md-success-container); border-radius: 8px; padding: 12px; font-family: inherit; margin: 0; }
    .note { font-size: 12px; color: var(--color-text-secondary); margin-top: 12px; }
  `]
})
export class WhatsAppPreviewDialog {
  constructor(@Inject(MAT_DIALOG_DATA) public data: any) {}

  renderBody(): string {
    const t = this.data.template;
    const r = this.data.sample;
    if (!t || !r) return '';
    const values: Record<string, string> = {
      ParentName: r.parentName || 'Parent',
      StudentName: r.studentName,
      ClassName: r.className,
      SectionName: r.sectionName,
      FeeType: r.installmentName,
      OutstandingAmount: r.outstandingAmount.toFixed(2),
      InstallmentAmount: r.outstandingAmount.toFixed(2),
      TotalFee: r.totalFee.toFixed(2),
      PaidAmount: r.paidAmount.toFixed(2),
      DueDate: r.dueDate ? new Date(r.dueDate).toLocaleDateString() : '',
      SchoolName: 'School', SchoolPhone: '', SchoolEmail: '', PaymentLink: '', AcademicYear: ''
    };
    return t.bodyText.replace(/\{\{\s*(\w+)\s*\}\}/g, (m: string, key: string) => values[key] ?? m);
  }
}
