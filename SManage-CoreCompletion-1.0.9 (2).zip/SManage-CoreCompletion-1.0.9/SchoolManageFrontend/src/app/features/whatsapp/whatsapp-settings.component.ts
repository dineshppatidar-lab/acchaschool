import { ChangeDetectorRef, Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatTabsModule } from '@angular/material/tabs';
import { MatDividerModule } from '@angular/material/divider';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatDialogModule } from '@angular/material/dialog';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatChipsModule } from '@angular/material/chips';
import { MatTableModule } from '@angular/material/table';
import { BackButtonComponent } from '../../shared/components/back-button.component';
import { CanWriteDirective } from '../../core/directives/permission.directive';
import { Permission } from '../../core/models/permission.model';
import { RouterModule } from '@angular/router';
import {
  WhatsAppService, WhatsAppConfig, WhatsAppTemplate, WhatsAppReminderRule
} from '../../shared/services/whatsapp.service';

@Component({
  selector: 'app-whatsapp-settings',
  standalone: true,
  imports: [
    CommonModule, FormsModule,
    MatCardModule, MatButtonModule, MatIconModule, MatFormFieldModule, MatInputModule,
    MatSelectModule, MatSlideToggleModule, MatTabsModule, MatDividerModule,
    MatSnackBarModule, MatProgressSpinnerModule, MatDialogModule, MatTooltipModule,
    MatCheckboxModule, MatChipsModule, MatTableModule, BackButtonComponent, CanWriteDirective, RouterModule
  ],
  templateUrl: './whatsapp-settings.component.html',
  styleUrls: ['./whatsapp-settings.component.scss']
})
export class WhatsappSettingsComponent implements OnInit {
  Permission = Permission;
  isLoading = signal(false);
  isSaving = signal(false);

  config = signal<any>(null);
  templates = signal<any[]>([]);
  rules = signal<any[]>([]);

  // Secret inputs (write-only, cleared after save)
  accessTokenInput = signal('');
  webhookVerifyTokenInput = signal('');
  webhookSecretInput = signal('');
  arattaiRefreshTokenInput = signal('');
  testPhoneNumber = '';

  // Supported normalized language codes for Arattai sends (subset of the official list).
  readonly arattaiLanguages = ['en', 'hi', 'ta', 'te', 'kn', 'ml', 'bn', 'gu', 'mr', 'pa', 'ur'];

  testingConnection = signal(false);
  sendingTestMessage = signal(false);

  // Template editor
  editingTemplate = signal<any>(null);
  savingTemplate = signal(false);

  // Rule editor
  editingRule = signal<any>(null);
  savingRule = signal(false);

  readonly placeholderHelp = [
    '{{ParentName}}', '{{StudentName}}', '{{ClassName}}', '{{SectionName}}',
    '{{AcademicYear}}', '{{FeeType}}', '{{TotalFee}}', '{{PaidAmount}}',
    '{{OutstandingAmount}}', '{{InstallmentAmount}}', '{{DueDate}}',
    '{{PaymentLink}}', '{{SchoolName}}', '{{SchoolPhone}}', '{{SchoolEmail}}'
  ];

  constructor(
    private whatsappService: WhatsAppService,
    private snackBar: MatSnackBar,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.loadAll();
  }

  loadAll(): void {
    this.isLoading.set(true);
    this.whatsappService.getConfig().subscribe({
      next: config => {
        this.config.set(config);
        this.isLoading.set(false);
        this.cdr.markForCheck();
      },
      error: () => {
        this.isLoading.set(false);
        this.snackBar.open('Failed to load WhatsApp configuration', 'Close', { duration: 4000 });
      }
    });

    this.whatsappService.getTemplates().subscribe({
      next: templates => { this.templates.set(templates); this.cdr.markForCheck(); },
      error: () => {}
    });

    this.whatsappService.getReminderRules().subscribe({
      next: rules => { this.rules.set(rules); this.cdr.markForCheck(); },
      error: () => {}
    });
  }

  // ── Configuration ────────────────────────────────────────────────────

  // Form validation before save — sanitized, provider-aware.
  validateConfig(): string[] {
    const errors: string[] = [];
    const c = this.config();
    if (!c) return errors;

    if (c.provider === 'Arattai') {
      if (!c.arattaiCompanyId?.trim()) errors.push('Arattai Company ID is required.');
      if (!c.arattaiBusinessNumberId?.trim()) errors.push('Arattai Business Number ID is required.');
      if (!this.arattaiRefreshTokenInput() && !c.arattaiRefreshTokenMask && !c.id)
        errors.push('Arattai OAuth refresh token is required (complete the one-time authorization).');
    } else {
      if (!c.phoneNumberId?.trim()) errors.push('Phone Number ID is required for Meta Cloud API.');
      if (!this.accessTokenInput() && !c.accessTokenMask && !c.id)
        errors.push('Access Token is required for Meta Cloud API.');
    }
    return errors;
  }

  saveConfig(): void {
    if (!this.config()) return;

    const validationErrors = this.validateConfig();
    if (validationErrors.length) {
      this.snackBar.open(validationErrors.join(' '), 'Close', { duration: 6000 });
      return;
    }

    this.isSaving.set(true);
    this.whatsappService.saveConfig(
      this.config(),
      this.accessTokenInput() || undefined,
      this.webhookVerifyTokenInput() || undefined,
      this.webhookSecretInput() || undefined,
      this.arattaiRefreshTokenInput() || undefined
    ).subscribe({
      next: saved => {
        this.config.set(saved);
        // Clear write-only secret inputs after save.
        this.accessTokenInput.set('');
        this.webhookVerifyTokenInput.set('');
        this.webhookSecretInput.set('');
        this.arattaiRefreshTokenInput.set('');
        this.isSaving.set(false);
        this.snackBar.open('Messaging configuration saved', 'Close', { duration: 3000 });
        this.cdr.markForCheck();
      },
      error: (err: Error) => {
        this.isSaving.set(false);
        this.snackBar.open(err.message, 'Close', { duration: 5000 });
        this.cdr.markForCheck();
      }
    });
  }

  testConnection(): void {
    this.testingConnection.set(true);
    this.whatsappService.testConnection().subscribe({
      next: result => {
        this.testingConnection.set(false);
        this.snackBar.open(
          result.success ? '✅ Connection successful' : `❌ ${result.errorMessage || 'Connection failed'}`,
          'Close', { duration: 6000 });
        if (this.config()) {
          this.config().lastTestStatus = result.success ? 'Success' : 'Failed';
          this.config().lastTestedOn = new Date().toISOString();
          if (!result.success) this.config().lastTestMessage = result.errorMessage;
        }
        this.cdr.markForCheck();
      },
      error: (err: Error) => {
        this.testingConnection.set(false);
        this.snackBar.open(err.message, 'Close', { duration: 5000 });
      }
    });
  }

  sendTestMessage(): void {
    if (!this.testPhoneNumber) return;
    this.sendingTestMessage.set(true);
    this.whatsappService.sendTestMessage(this.testPhoneNumber).subscribe({
      next: result => {
        this.sendingTestMessage.set(false);
        this.snackBar.open(
          result.success ? '✅ Test message sent' : `❌ ${result.errorMessage || 'Send failed'}`,
          'Close', { duration: 6000 });
        this.cdr.markForCheck();
      },
      error: (err: Error) => {
        this.sendingTestMessage.set(false);
        this.snackBar.open(err.message, 'Close', { duration: 5000 });
      }
    });
  }

  // ── Templates ────────────────────────────────────────────────────────

  newTemplate(): void {
    this.editingTemplate.set({
      id: 0, name: '', messageType: 'FeeReminder', languageCode: this.config()?.defaultLanguageCode || 'en',
      bodyText: `Dear {{ParentName}},\nThis is a reminder that the fee of {{OutstandingAmount}}\nfor {{StudentName}} is due on {{DueDate}}.\nPlease make the payment before the due date.\nThank you,\n{{SchoolName}}`,
      isApproved: false, isActive: true, description: ''
    });
  }

  editTemplate(t: WhatsAppTemplate): void {
    this.editingTemplate.set({ ...t });
  }

  saveTemplate(): void {
    if (!this.editingTemplate()) return;
    this.savingTemplate.set(true);
    this.whatsappService.saveTemplate(this.editingTemplate()).subscribe({
      next: saved => {
        const idx = this.templates().findIndex(t => t.id === saved.id);
        if (idx >= 0) this.templates()[idx] = saved; else this.templates.update(arr => { arr.push(saved); return arr; });
        this.editingTemplate.set(null);
        this.savingTemplate.set(false);
        this.snackBar.open('Template saved', 'Close', { duration: 3000 });
        this.cdr.markForCheck();
      },
      error: (err: Error) => {
        this.savingTemplate.set(false);
        this.snackBar.open(err.message, 'Close', { duration: 5000 });
      }
    });
  }

  cancelTemplateEdit(): void { this.editingTemplate.set(null); }

  deleteTemplate(t: WhatsAppTemplate): void {
    if (!confirm(`Delete template "${t.name}"?`)) return;
    this.whatsappService.deleteTemplate(t.id).subscribe({
      next: () => {
        this.templates.set(this.templates().filter(x => x.id !== t.id));
        this.snackBar.open('Template deleted', 'Close', { duration: 3000 });
        this.cdr.markForCheck();
      },
      error: (err: Error) => this.snackBar.open(err.message, 'Close', { duration: 5000 })
    });
  }

  insertPlaceholder(ph: string): void {
    if (this.editingTemplate()) {
      this.editingTemplate().bodyText += ph;
    }
  }

  // ── Automation rules ─────────────────────────────────────────────────

  newRule(): void {
    this.editingRule.set({
      id: 0, name: '', templateId: this.templates()[0]?.id ?? 0, isEnabled: true,
      offsetType: 'BeforeDueDate', offsetDays: 7, sendTime: '09:00',
      minOutstandingAmount: 0
    });
  }

  editRule(r: WhatsAppReminderRule): void {
    this.editingRule.set({ ...r });
  }

  saveRule(): void {
    if (!this.editingRule()) return;
    this.savingRule.set(true);
    this.whatsappService.saveRule(this.editingRule()).subscribe({
      next: saved => {
        const idx = this.rules().findIndex(r => r.id === saved.id);
        if (idx >= 0) this.rules()[idx] = saved; else this.rules.update(arr => { arr.push(saved); return arr; });
        this.editingRule.set(null);
        this.savingRule.set(false);
        this.snackBar.open('Reminder rule saved', 'Close', { duration: 3000 });
        this.cdr.markForCheck();
      },
      error: (err: Error) => {
        this.savingRule.set(false);
        this.snackBar.open(err.message, 'Close', { duration: 5000 });
      }
    });
  }

  cancelRuleEdit(): void { this.editingRule.set(null); }

  deleteRule(r: WhatsAppReminderRule): void {
    if (!confirm(`Delete rule "${r.name}"?`)) return;
    this.whatsappService.deleteRule(r.id).subscribe({
      next: () => {
        this.rules.set(this.rules().filter(x => x.id !== r.id));
        this.snackBar.open('Rule deleted', 'Close', { duration: 3000 });
        this.cdr.markForCheck();
      },
      error: (err: Error) => this.snackBar.open(err.message, 'Close', { duration: 5000 })
    });
  }

  runAutomationNow(): void {
    this.whatsappService.runAutomationNow().subscribe({
      next: count => this.snackBar.open(`${count} reminder(s) enqueued by automated rules`, 'Close', { duration: 4000 }),
      error: (err: Error) => this.snackBar.open(err.message, 'Close', { duration: 5000 })
    });
  }

  offsetLabel(r: WhatsAppReminderRule): string {
    switch (r.offsetType) {
      case 'BeforeDueDate': return `${r.offsetDays} day(s) before due date`;
      case 'OnDueDate': return 'On the due date';
      case 'AfterDueDate': return `${r.offsetDays} day(s) after due date`;
      default: return '';
    }
  }
}
