import { ChangeDetectorRef, Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatTableModule } from '@angular/material/table';
import { MatTooltipModule } from '@angular/material/tooltip';
import { BackButtonComponent } from '../../shared/components/back-button.component';
import { CanWriteDirective } from '../../core/directives/permission.directive';
import { Permission } from '../../core/models/permission.model';
import { WhatsAppService, WhatsAppHistoryItem } from '../../shared/services/whatsapp.service';

@Component({
  selector: 'app-whatsapp-history',
  standalone: true,
  imports: [
    CommonModule, FormsModule, MatButtonModule, MatCardModule, MatFormFieldModule,
    MatIconModule, MatInputModule, MatSelectModule, MatPaginatorModule, MatSnackBarModule,
    MatProgressSpinnerModule, MatTableModule, MatTooltipModule, BackButtonComponent, CanWriteDirective
  ],
  templateUrl: './whatsapp-history.component.html',
  styleUrls: ['./whatsapp-history.component.scss']
})
export class WhatsAppHistoryComponent implements OnInit {
  Permission = Permission;
  displayedColumns = ['student', 'recipient', 'channel', 'type', 'template', 'trigger', 'status', 'sentAt', 'detail', 'actions'];
  retryingId: number | null = null;
  items = signal<any[]>([]);
  total = signal(0);
  page = 1;
  pageSize = 25;
  isLoading = signal(false);

  statusFilter = '';
  triggerFilter = '';
  readonly statusOptions = ['Pending', 'Queued', 'Sending', 'Sent', 'Delivered', 'Read', 'Failed', 'Cancelled'];
  readonly triggerOptions = ['Manual', 'Automated'];

  constructor(
    private whatsappService: WhatsAppService,
    private snackBar: MatSnackBar,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.load();
  }

  load(): void {
    this.isLoading.set(true);
    this.whatsappService.getHistory(this.page, this.pageSize, {
      status: this.statusFilter || undefined,
      trigger: this.triggerFilter || undefined
    }).subscribe({
      next: result => {
        // Null-guard: tolerate an absent/empty history payload instead of
        // throwing "Cannot read properties of undefined (reading 'items')".
        this.items.set(result?.items ?? []);
        this.total.set(result?.total ?? 0);
        this.isLoading.set(false);
        this.cdr.markForCheck();
      },
      error: (err: Error) => {
        this.isLoading.set(false);
        this.snackBar.open(err.message, 'Close', { duration: 5000 });
        this.cdr.markForCheck();
      }
    });
  }

  onPageChange(event: any): void {
    this.page = event.pageIndex + 1;
    this.pageSize = event.pageSize;
    this.load();
  }

  applyFilters(): void {
    this.page = 1;
    this.load();
  }

  statusClass(status: string): string {
    return 'status-' + (status || 'pending').toLowerCase();
  }

  /** Failed/Cancelled messages can be re-queued by admins; queued/sent ones cannot. */
  canRetry(m: WhatsAppHistoryItem): boolean {
    return m.status === 'Failed' || m.status === 'Cancelled';
  }

  retry(m: WhatsAppHistoryItem): void {
    if (!this.canRetry(m) || this.retryingId !== null) return;
    this.retryingId = m.id;
    this.whatsappService.retryFailed(m.id).subscribe({
      next: result => {
        this.retryingId = null;
        if (result.success) {
          m.status = 'Queued';
          m.failureReason = undefined;
          this.snackBar.open('Message re-queued for sending', 'Close', { duration: 3000 });
        } else {
          this.snackBar.open(result.errorMessage || 'Retry not possible', 'Close', { duration: 5000 });
        }
        this.cdr.markForCheck();
      },
      error: (err: Error) => {
        this.retryingId = null;
        this.snackBar.open(err.message, 'Close', { duration: 5000 });
      }
    });
  }
}
