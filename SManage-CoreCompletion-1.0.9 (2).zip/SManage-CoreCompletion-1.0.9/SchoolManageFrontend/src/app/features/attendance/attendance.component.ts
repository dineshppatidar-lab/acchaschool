import { ChangeDetectionStrategy, Component, OnDestroy, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTabsModule } from '@angular/material/tabs';
import { MatSelectModule } from '@angular/material/select';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatListModule } from '@angular/material/list';
import { MatChipsModule } from '@angular/material/chips';
import { MatBadgeModule } from '@angular/material/badge';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatTableModule } from '@angular/material/table';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { AttendanceService, StudentForAttendance, AttendanceRecord, ClassOption, SectionOption } from '../../services/attendance.service';
import { AcademicYearContextService } from '../../shared/services/academic-year-context.service';
import { PageHeaderComponent, KpiCardComponent } from '../../shared/components/page-patterns/index';
import { KpiTone } from '../../shared/components/page-patterns/kpi-card.component';
import { Subject, takeUntil } from 'rxjs';

@Component({
  selector: 'app-attendance',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    MatCardModule,
    MatButtonModule,
    MatIconModule,
    MatTabsModule,
    MatSelectModule,
    MatFormFieldModule,
    MatInputModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatProgressSpinnerModule,
    MatSnackBarModule,
    MatListModule,
    MatChipsModule,
    MatBadgeModule,
    MatTooltipModule,
    MatTableModule,
    MatProgressBarModule,
    PageHeaderComponent,
    KpiCardComponent
  ],
  templateUrl: './attendance.component.html',
  styleUrls: ['./attendance.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AttendanceComponent implements OnInit {
  // Tab state
  selectedTab = 0;

  // Date state
  selectedDate = new Date();
  minDate = new Date(2024, 0, 1);
  maxDate = new Date();

  // Class/Section selection
  selectedClassId: number | null = null;
  selectedSectionId: number | null = null;
  classes = signal<any[]>([]);
  sections = signal<any[]>([]);

  // Academic Year selection
  academicYears: { id: number; name: string }[] = [];
  selectedYearId = signal<any>(null);

  // Students for marking
  students = signal<any[]>([]);
  filteredStudents = signal<any[]>([]);
  searchQuery = '';

  // Loading states
  loadingStudents = signal(false);
  saving = signal(false);

  // Summary stats
  totalStudents = 0;
  presentCount = 0;
  absentCount = 0;
  attendancePercentage = 0;

  // History data
  historyRecords = signal<any[]>([]);
  historyDateFrom: Date | null = null;
  historyDateTo: Date | null = null;
  loadingHistory = signal(false);

  // Analytics data
  analytics = signal<any>(null);
  loadingAnalytics = signal(false);

  // Cleanup
  private destroy$ = new Subject<void>();

  constructor(
    private attendanceService: AttendanceService,
    private yearContext: AcademicYearContextService,
    private snackBar: MatSnackBar
  ) {}

  ngOnInit(): void {
    // Load academic years via the shared context (auto-selects current year)
    this.yearContext.loadAcademicYears()
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: () => {
          this.academicYears = this.yearContext.yearsSnapshot.map(y => ({ id: y.id, name: y.name }));
          this.selectedYearId.set(this.yearContext.selectedYearId);
          if (this.selectedYearId()) {
            // Classes must be bound to the selected academic year; loading them
            // here also covers the auto-selected year, whose change never fires
            // the template's (selectionChange) event.
            this.loadClasses();
          }
        },
        error: () => {
          // Fall back to all classes so the page remains usable
          this.loadClasses();
        }
      });
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  onAcademicYearChange(yearId: number | null): void {
    this.selectedYearId.set(yearId);
    if (yearId) {
      this.yearContext.setYear(yearId);
    }
    this.selectedClassId = null;
    this.selectedSectionId = null;
    this.students.set([]);
    this.filteredStudents.set([]);
    this.analytics.set(null);
    this.loadClasses();
  }

  loadClasses(): void {
    const fetch$ = this.selectedYearId()
      ? this.attendanceService.getClassesByAcademicYear(this.selectedYearId())
      : this.attendanceService.getClasses();

    fetch$.subscribe({
      next: (data: any) => {
        const list: ClassOption[] = Array.isArray(data) ? data : (data?.data ?? []);
        // Defensive dedupe: same-named classes from other years (or legacy data
        // without an academic year) would otherwise appear twice in the dropdown.
        const seen = new Set<string>();
        this.classes.set(list.filter(c => {
          const key = `${c.id}|${(c.name ?? '').trim().toLowerCase()}`;
          if (seen.has(key)) return false;
          seen.add(key);
          return true;
        }));
      },
      error: () => {
        this.snackBar.open('Failed to load classes', 'Dismiss', { duration: 3000 });
      }
    });
  }

  loadSections(classId: number): void {
    this.attendanceService.getSectionsByClass(classId).subscribe({
      next: (data: any) => {
        this.sections.set(Array.isArray(data) ? data : (data?.data ?? []));
      },
      error: () => {
        this.snackBar.open('Failed to load sections', 'Dismiss', { duration: 3000 });
      }
    });
  }

  loadStudents(): void {
    if (!this.selectedClassId || !this.selectedSectionId) return;

    this.loadingStudents.set(true);
    this.attendanceService.getStudents(this.selectedClassId, this.selectedSectionId).subscribe({
      next: (data: any) => {
        const list = Array.isArray(data) ? data : (data?.data ?? data?.items ?? []);
        this.students.set(list.map((s: any) => ({
          id: s.id,
          firstName: s.firstName || s.FirstName || '',
          lastName: s.lastName || s.LastName || '',
          rollNumber: s.rollNumber || s.RollNumber || '',
          isPresent: true,
          remarks: ''
        })));
        this.filteredStudents.set([...this.students()]);
        this.updateCounts();
        this.loadingStudents.set(false);
      },
      error: () => {
        this.loadingStudents.set(false);
        this.snackBar.open('Failed to load students', 'Dismiss', { duration: 3000 });
      }
    });
  }

  onClassChange(): void {
    this.selectedSectionId = null;
    this.students.set([]);
    this.filteredStudents.set([]);
    this.analytics.set(null);
    this.sections.set([]);
    if (this.selectedClassId) {
      this.loadSections(this.selectedClassId);
    }
  }

  onSectionChange(): void {
    this.loadStudents();
    this.loadAnalytics();
  }

  toggleAttendance(student: StudentForAttendance): void {
    student.isPresent = !student.isPresent;
    this.updateCounts();
  }

  markAllPresent(): void {
    this.students().forEach(s => s.isPresent = true);
    this.updateCounts();
  }

  markAllAbsent(): void {
    this.students().forEach(s => s.isPresent = false);
    this.updateCounts();
  }

  updateCounts(): void {
    this.totalStudents = this.students().length;
    this.presentCount = this.students().filter(s => s.isPresent).length;
    this.absentCount = this.totalStudents - this.presentCount;
    this.attendancePercentage = this.totalStudents > 0
      ? Math.round((this.presentCount / this.totalStudents) * 100)
      : 0;
  }

  filterStudents(): void {
    const query = this.searchQuery.toLowerCase();
    this.filteredStudents.set(this.students().filter(s =>
      s.firstName.toLowerCase().includes(query) ||
      s.lastName.toLowerCase().includes(query) ||
      s.rollNumber.toLowerCase().includes(query)
    ));
  }

  saveAttendance(): void {
    if (!this.selectedClassId || !this.selectedSectionId || this.students().length === 0) {
      this.snackBar.open('Please select class, section and load students first', 'Dismiss', { duration: 3000 });
      return;
    }

    this.saving.set(true);

    // Local-date serialization: toISOString() would shift the picked date
    // back a day for timezones ahead of UTC (e.g. IST evening picks), so the
    // backend baseDate.ToDate() mismatched the date the user selected. Using
    // the calendar date components keeps exactly the picked day.
    const y = this.selectedDate.getFullYear();
    const m = String(this.selectedDate.getMonth() + 1).padStart(2, '0');
    const d = String(this.selectedDate.getDate()).padStart(2, '0');
    const dateStr = `${y}-${m}-${d}`;

    const presentIds = this.students().filter(s => s.isPresent).map(s => s.id);

    this.attendanceService.quickMarkAttendance({
      classId: this.selectedClassId,
      sectionId: this.selectedSectionId,
      date: dateStr,
      presentStudentIds: presentIds
    }).subscribe({
      next: (res: any) => {
        this.saving.set(false);
        // Surface the REAL backend result instead of a blanket success:
        // zero students saved means the class/section has no enrolled students.
        const total = res?.total ?? res?.Total ?? this.students().length;
        if (total === 0) {
          this.snackBar.open('No enrolled students found for this class & section', 'Dismiss', { duration: 4000 });
          return;
        }
        this.snackBar.open(`Attendance saved for ${total} student${total === 1 ? '' : 's'}!`, 'OK', { duration: 3000 });
        // Reload from the server so history + analytics reflect what actually persisted.
        this.loadHistory();
        this.loadAnalytics();
        if (this.selectedTab !== 0) {
          this.onSectionChange();
        }
      },
      error: (err: any) => {
        this.saving.set(false);
        // Show the real API error (validation message, permission denial,...)
        // instead of a generic string so failures are diagnosable.
        const apiMsg = err?.error?.message || err?.error?.Message || err?.error?.errors
                  || err?.message || null;
        const msg = typeof apiMsg === 'object' ? JSON.stringify(apiMsg) : apiMsg;
        this.snackBar.open(msg || 'Failed to save attendance. Please try again.', 'Dismiss', { duration: 5000 });
      }
    });
  }

  loadHistory(): void {
    this.loadingHistory.set(true);
    const fromStr = this.historyDateFrom ? this.historyDateFrom.toISOString().split('T')[0] : undefined;
    const toStr = this.historyDateTo ? this.historyDateTo.toISOString().split('T')[0] : undefined;

    this.attendanceService.getAttendanceHistory(
      this.selectedClassId ?? undefined,
      this.selectedSectionId ?? undefined,
      fromStr,
      toStr
    ).subscribe({
      next: (data: any) => {
        this.historyRecords.set(Array.isArray(data) ? data : (data?.records ?? data?.data ?? []));
        this.loadingHistory.set(false);
      },
      error: () => {
        this.loadingHistory.set(false);
        this.snackBar.open('Failed to load attendance history', 'Dismiss', { duration: 3000 });
      }
    });
  }

  loadAnalytics(): void {
    this.loadingAnalytics.set(true);
    this.attendanceService.getAttendanceAnalytics(
      this.selectedClassId ?? undefined
    ).subscribe({
      next: (data: any) => {
        this.analytics.set(data);
        this.loadingAnalytics.set(false);
      },
      error: () => {
        this.loadingAnalytics.set(false);
      }
    });
  }

  getStudentName(student: StudentForAttendance): string {
    return `${student.firstName} ${student.lastName}`.trim();
  }

  getAttendanceColor(percentage: number): KpiTone {
    if (percentage >= 90) return 'success';
    if (percentage >= 75) return 'primary';
    return 'warn';
  }

  trackByStudentId(index: number, student: StudentForAttendance): number {
    return student.id;
  }
}
