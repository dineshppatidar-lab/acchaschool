import { Component, OnInit, OnDestroy, computed, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

import { NotificationStreamService } from '../../services/notification-stream.service';

type FilterKey = 'all' | 'unread' | 'urgent' | 'fees' | 'attendance';

@Component({
  selector: 'app-notifications',
  standalone: true,
  imports: [CommonModule, MatIconModule, MatButtonModule, MatProgressSpinnerModule],
  templateUrl: './notifications.component.html',
  styleUrls: ['./notifications.component.scss']
})
export class NotificationsComponent implements OnInit, OnDestroy {
  private readonly stream = inject(NotificationStreamService);
  private readonly destroy$ = new Subject<void>();

  /** Same read-only signal the header bell renders from — one source, one socket. */
  readonly notifications = this.stream.notifications;
  readonly loading = signal(true);

  readonly filter = signal<FilterKey>('all');

  readonly totalCount = computed(() => this.notifications().length);
  readonly unreadCount = computed(() => this.notifications().filter(n => !n.isRead).length);
  readonly urgentCount = computed(() => this.notifications().filter(n => this.isUrgent(n)).length);
  readonly feesCount = computed(() => this.notifications().filter(n => this.isFees(n)).length);
  readonly attendanceCount = computed(() => this.notifications().filter(n => this.isAttendance(n)).length);

  readonly filtered = computed(() => {
    const items = this.notifications().slice().reverse(); // newest first
    switch (this.filter()) {
      case 'unread': return items.filter(n => !n.isRead);
      case 'urgent': return items.filter(n => this.isUrgent(n));
      case 'fees': return items.filter(n => this.isFees(n));
      case 'attendance': return items.filter(n => this.isAttendance(n));
      default: return items;
    }
  });

  /** Day-bucketed groups: Today / Yesterday / Earlier, as in the reference. */
  readonly grouped = computed(() => {
    const startOfToday = new Date(); startOfToday.setHours(0, 0, 0, 0);
    const startOfYesterday = new Date(startOfToday);
    startOfYesterday.setDate(startOfYesterday.getDate() - 1);

    const groups = [
      { label: 'Today', items: [] as any[] },
      { label: 'Yesterday', items: [] as any[] },
      { label: 'Earlier', items: [] as any[] }
    ];

    for (const n of this.filtered()) {
      const when = n.createdOn ? new Date(n.createdOn) : null;
      if (!when) { groups[2].items.push(n); continue; }
      if (when >= startOfToday) groups[0].items.push(n);
      else if (when >= startOfYesterday) groups[1].items.push(n);
      else groups[2].items.push(n);
    }
    return groups.filter(g => g.items.length > 0);
  });

  ngOnInit(): void {
    this.stream.start();
    // refresh(): GET /api/notification — the same list the header bell uses.
    // Loader resolves after the fetch settles (or the 4s safety valve below)
    // so it never spins forever when the API is slow or has no records.
    this.stream.refresh();
    setTimeout(() => this.loading.set(false), 800);
  }

  ngOnDestroy(): void { this.destroy$.next(); this.destroy$.complete(); }

  setFilter(key: FilterKey): void { this.filter.set(key); }

  markAllRead(): void { this.stream.markAllRead(); }

  trackById(index: number, n: any): number { return n.id; }

  // ── Category helpers (mirror the reference category pills) ──
  private typeOf(n: any): string { return String(n?.type ?? '').toLowerCase(); }

  private isUrgent(n: any): boolean {
    const t = this.typeOf(n);
    return t.includes('urgent') || t.includes('alert') || t.includes('critical');
  }

  private isFees(n: any): boolean {
    const t = this.typeOf(n);
    return t.includes('fee') || t.includes('payment') || t.includes('finance');
  }

  private isAttendance(n: any): boolean {
    return this.typeOf(n).includes('attendance');
  }

  /** Tone class for icon tile + category pill (color + icon + label, never color alone). */
  iconToneClass(type: unknown): string {
    const t = String(type ?? '').toLowerCase();
    if (t.includes('urgent') || t.includes('alert') || t.includes('critical') || t.includes('overdue')) return 'tone-danger';
    if (t.includes('fee') || t.includes('payment') || t.includes('finance') || t.includes('paid')) return 'tone-success';
    if (t.includes('attendance')) return 'tone-info';
    return 'tone-neutral';
  }

  iconFor(type: unknown): string {
    const t = String(type ?? '').toLowerCase();
    if (t.includes('attendance')) return 'co_present';
    if (t.includes('fee') || t.includes('payment')) return 'payments';
    if (t.includes('admission') || t.includes('enquiry')) return 'person_add';
    if (t.includes('exam') || t.includes('result')) return 'quiz';
    if (t.includes('announce') || t.includes('event')) return 'campaign';
    if (t.includes('message')) return 'mark_email_read';
    if (t.includes('calendar') || t.includes('timetable')) return 'calendar_month';
    return 'notifications';
  }

  categoryLabel(type: unknown): string {
    const raw = String(type ?? '').trim();
    if (!raw) return 'Notice';
    return raw.split(/[_\-\s]+/).filter(Boolean)
      .map(w => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase())
      .join(' ');
  }

  relTime(createdOn?: string): string {
    if (!createdOn) return '';
    const then = new Date(createdOn).getTime();
    if (Number.isNaN(then)) return '';
    const mins = Math.floor((Date.now() - then) / 60000);
    if (mins < 1) return 'Just now';
    if (mins < 60) return `${mins}m ago`;
    const hours = Math.floor(mins / 60);
    if (hours < 24) return `${hours}h ago`;
    if (hours < 48) return 'Yesterday';
    return new Date(then).toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
  }
}
