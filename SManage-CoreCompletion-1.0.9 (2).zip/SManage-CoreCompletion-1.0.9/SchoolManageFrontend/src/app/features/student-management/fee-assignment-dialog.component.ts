import { ChangeDetectionStrategy, ChangeDetectorRef, Component, Inject, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogModule, MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatCardModule } from '@angular/material/card';
import { MatDividerModule } from '@angular/material/divider';
import { MatIconModule } from '@angular/material/icon';
import { FeeManagementService } from '../../shared/services/fee-management.service';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';

interface DialogData {
  studentId: number;
  studentName: string;
  classId?: number;
  currentAssignedFeeStructure?: any;
}

interface FeeStructure {
  id: number;
  name: string;
  classId: number;
  academicYearId: number;
  annualFee?: number;
  registrationFee?: number;
  transportFee?: number;
  uniformFee?: number;
  examinationFee?: number;
  libraryFee?: number;
  computerFee?: number;
  laboratoryFee?: number;
  sportsFee?: number;
  miscellaneousFee?: number;
  isActive: boolean;
}

@Component({
  selector: 'app-fee-assignment-dialog',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatDialogModule,
    MatFormFieldModule,
    MatSelectModule,
    MatButtonModule,
    MatProgressSpinnerModule,
    MatCardModule,
    MatDividerModule,
    MatIconModule,
    MatSnackBarModule,
    MatInputModule
  ],
  templateUrl: './fee-assignment-dialog.component.html',
  styleUrls: ['./fee-assignment-dialog.component.scss']
})
export class FeeAssignmentDialogComponent implements OnInit {
  assignmentForm: FormGroup;
  feeStructures = signal<any[]>([]);
  selectedFeeStructure: FeeStructure | null = null;
  loadingStructures = signal(true);
  assigning = signal(false);
  errorMessage = signal('');

  constructor(
    private formBuilder: FormBuilder,
    private feeManagementService: FeeManagementService,
    private snackBar: MatSnackBar,
    private cdr: ChangeDetectorRef,
    public dialogRef: MatDialogRef<FeeAssignmentDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData
  ) {
    this.assignmentForm = this.formBuilder.group({
      feeStructureId: [null, Validators.required],
      remarks: ['']
    });
  }

  ngOnInit(): void {
    this.loadFeeStructures();
  }

  private loadFeeStructures(): void {
    console.log(`📚 Loading fee structures for class ${this.data.classId}`);
    this.loadingStructures.set(true);
    this.errorMessage.set('');
    this.cdr.markForCheck();

    // If classId is provided, filter by class; otherwise get all
    const request = this.data.classId
      ? this.feeManagementService.getFeeStructures(this.data.classId)
      : this.feeManagementService.getAllFeeStructures();

    request.subscribe({
      next: (response: any) => {
        console.log('✅ Fee structures loaded:', response);
        
        // Handle both direct array response and ApiResponse wrapper
        const structures = response.data || response;
        this.feeStructures.set(Array.isArray(structures) ? structures : []);
        
        if (this.feeStructures().length === 0) {
          this.errorMessage.set('No fee structures available for this class');
        }
        
        this.loadingStructures.set(false);
        this.cdr.markForCheck();
      },
      error: (error: any) => {
        console.error('❌ Error loading fee structures:', error);
        this.errorMessage.set(`Failed to load fee structures: ${error.message}`);
        this.loadingStructures.set(false);
        this.cdr.markForCheck();
      }
    });
  }

  onFeeStructureSelected(): void {
    const feeStructureId = this.feeStructureControl?.value;
    this.selectedFeeStructure = this.feeStructures().find(f => f.id === feeStructureId) || null;
    this.cdr.markForCheck();
    console.log('Selected fee structure:', this.selectedFeeStructure);
  }

  get feeStructureControl() {
    return this.assignmentForm.get('feeStructureId');
  }

  get totalFeeAmount(): number {
    return this.getStructureTotal(this.selectedFeeStructure);
  }

  getStructureTotal(feeStructure: FeeStructure | null | undefined): number {
    if (!feeStructure) return 0;
    return (feeStructure.annualFee || 0) +
           (feeStructure.registrationFee || 0) +
           (feeStructure.transportFee || 0) +
           (feeStructure.uniformFee || 0) +
           (feeStructure.examinationFee || 0) +
           (feeStructure.libraryFee || 0) +
           (feeStructure.computerFee || 0) +
           (feeStructure.laboratoryFee || 0) +
           (feeStructure.sportsFee || 0) +
           (feeStructure.miscellaneousFee || 0);
  }

  onCancel(): void {
    console.log('User cancelled fee assignment dialog');
    this.dialogRef.close(null);
  }

  onAssign(): void {
    if (!this.assignmentForm.valid || !this.data.studentId) {
      console.warn('Form invalid or no student ID');
      return;
    }

    this.assigning.set(true);
    this.errorMessage.set('');
    const feeStructureId = this.feeStructureControl?.value;
    const remarks = this.assignmentForm.get('remarks')?.value;

    console.log(`🔗 Assigning fee structure ${feeStructureId} to student ${this.data.studentId}`);

    this.feeManagementService.assignFeeStructureToStudent(this.data.studentId, {
      feeStructureId,
      remarks
    }).subscribe({
      next: (response: any) => {
        console.log('✅ Fee structure assigned successfully:', response);
        this.assigning.set(false);
        
        this.snackBar.open(
          `✅ Fee structure assigned successfully to ${this.data.studentName}`,
          'Close',
          { duration: 4000, horizontalPosition: 'end', verticalPosition: 'top' }
        );
        
        // Close dialog with success result
        this.dialogRef.close({ success: true, data: response.data });
      },
      error: (error: any) => {
        console.error('❌ Error assigning fee structure:', error);
        this.assigning.set(false);
        
        const errorMsg = error.error?.message || error.message || 'Failed to assign fee structure';
        this.errorMessage.set(errorMsg);
        
        this.snackBar.open(
          `❌ ${errorMsg}`,
          'Close',
          { duration: 5000, horizontalPosition: 'end', verticalPosition: 'top', panelClass: ['error-snackbar'] }
        );
      }
    });
  }
}
