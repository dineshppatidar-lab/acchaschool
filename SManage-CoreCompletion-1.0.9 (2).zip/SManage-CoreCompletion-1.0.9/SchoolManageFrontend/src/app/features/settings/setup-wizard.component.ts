import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnDestroy, OnInit, ViewChild, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule, FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { MatStepperModule, MatStepper } from '@angular/material/stepper';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatCardModule } from '@angular/material/card';
import { MatSelectModule } from '@angular/material/select';
import { MatTableModule } from '@angular/material/table';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatListModule } from '@angular/material/list';
import { MatChipsModule } from '@angular/material/chips';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';import { MatExpansionModule } from '@angular/material/expansion';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatPaginatorModule, MatPaginator } from '@angular/material/paginator';
import { Subject, forkJoin } from 'rxjs';
import { takeUntil, debounceTime } from 'rxjs/operators';

import { SetupInitializationService, ClassRequest, SubjectRequest, FeeStructureRequest, SetupChecklistResult } from './setup-initialization.service';
import { MasterDataService } from '../../core/services/master-data.service';
import { AcademicYearContextService } from '../../shared/services/academic-year-context.service';
import { DialogUtils } from '../../shared/dialog-utils';
import { SetupStatusService } from '../../core/services/setup-status.service';
import { FeeStructureDialogComponent } from './fee-structure-dialog.component';
import { MatTableDataSource } from '@angular/material/table';
import { BackButtonComponent } from '../../shared/components/back-button.component';
import { ConfirmDialogComponent, ConfirmDialogData } from '../../shared/confirm-dialog.component';
import { PromptDialogComponent, PromptDialogData } from '../../shared/prompt-dialog.component';

export interface SetupStep {
  id: string;
  title: string;
  description: string;
  icon: string;
  completed: boolean;
  required: boolean;
}

@Component({
  selector: 'app-setup-wizard',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatStepperModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule,
    MatCardModule,
    MatSelectModule,
    MatTableModule,
    MatProgressBarModule,
    MatProgressSpinnerModule,
    MatSnackBarModule,
    MatCheckboxModule,
    MatTooltipModule,
    MatListModule,
    MatChipsModule,
    MatDialogModule,
    MatExpansionModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatPaginatorModule,
    BackButtonComponent
  ],
  templateUrl: './setup-wizard.component.html',
  styleUrls: ['./setup-wizard.component.scss']
})
export class SetupWizardComponent implements OnInit, OnDestroy {
  @ViewChild('stepper') stepper!: MatStepper;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  
  isLinear = false;
  currentStep = 0;
  isProcessing = signal(false);
  setupProgress = 0;

  // Setup steps
  setupSteps: SetupStep[] = [];
  
  // Forms
  academicYearForm!: FormGroup;
  classesForm!: FormGroup;
  sectionsForm!: FormGroup;
  subjectsForm!: FormGroup;
  feesForm!: FormGroup;
  paymentMethodsForm!: FormGroup;
  completionForm!: FormGroup;
  
  // Fee Structure data
  selectedFeeStructure: any = null;
  feeStructureDataSource = new MatTableDataSource<any>([]);

  // Data
  academicYears = signal<any[]>([]);
  classes = signal<any[]>([]);
  sections: any[] = [];
  subjects: any[] = [];
  staffDepartments: any[] = [];
  staffPositions: any[] = [];
  feeTypes: any[] = [];
  paymentMethods: any[] = [];

  // Existing DB records shown in the Staff / Payment tabs
  staffList = signal<any[]>([]);
  existingPaymentMethods = signal<any[]>([]);

  // Batch creation lists
  selectedClasses = signal<any[]>([]);
  selectedSections = signal<any[]>([]);
  selectedSubjects = signal<any[]>([]);
  selectedDepartments: any[] = [];
  filteredClassesForSections = signal<any[]>([]);
  filteredClassesForSubjects = signal<any[]>([]);

  // Departments/positions already persisted for this tenant (DB-backed lookups,
  // the same store the Departments/Designations admin screens use).
  savedDepartments = signal<any[]>([]);
  savedPositions = signal<any[]>([]);

  // (Add flows use the shared PromptDialogComponent — no inline input state.)

  // UI State
  isLoadingAcademicYears = signal(false);
  isLoadingClasses = signal(false);
  isLoadingSections = signal(false);
  isLoadingSubjects = signal(false);
  isLoadingStaff = signal(false);
  isLoadingFees = signal(false);
  isLoadingPaymentMethods = signal(false);

  // Editing state
  isEditingSubject = false;
  editingSubjectIndex: number | null = null;
  isEditingSection = false;
  editingSectionIndex: number | null = null;
  isEditingClass = false;
  editingClassIndex: number | null = null;
  isEditingAcademicYear = signal(false);
  editingAcademicYearId = signal<any>(null);

  // Cleanup
  private destroy$ = new Subject<void>();

  constructor(
    private fb: FormBuilder,
    private setupService: SetupInitializationService,
    private masterDataService: MasterDataService,
    private snackBar: MatSnackBar,
    private cdr: ChangeDetectorRef,
    private router: Router,
    private dialog: MatDialog,
    private dialogUtils: DialogUtils,
    private yearContext: AcademicYearContextService,
    private setupStatus: SetupStatusService
  ) {
    this.initiateForms();
  }

  ngOnInit(): void {
    this.initializeSetupSteps();
    this.loadInitialSetupStatus();

    // Register form subscriptions BEFORE loading data. When the academic-year
    // list is already cached, yearContext emits synchronously and patches the
    // forms during loadInitialData(); valueChanges subscriptions registered
    // afterwards would miss that patch and every dependent dropdown/list
    // (Classes, Subjects, Sections, Fees) would stay empty until a refresh.
    this.setupFeesFormSubscription();
    this.setupSubjectsFormSubscription();
    this.setupClassesFormSubscription();
    this.setupSectionsFormSubscription();

    this.loadInitialData();
  }

  private loadInitialSetupStatus(): void {
    this.isProcessing.set(true);
    this.cdr.markForCheck();

    this.setupService.getSetupChecklist()
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (result: SetupChecklistResult) => {
          if (result && result.steps) {
            // Map backend steps to frontend steps
            const backendToFrontendMap: { [key: number]: string } = {
              1: 'academic-year',
              2: 'classes',
              3: 'subjects',
              4: 'staff',
              5: 'fees',
              6: 'payment-methods'
            };

            result.steps.forEach(backendStep => {
              const frontendId = backendToFrontendMap[backendStep.stepNumber];
              if (frontendId) {
                const step = this.setupSteps.find(s => s.id === frontendId);
                if (step) {
                  step.completed = backendStep.completed;
                }
              }
            });

            this.updateProgress();
          }
          this.isProcessing.set(false);
          this.cdr.markForCheck();
        },
        error: (err) => {
          console.error('Error loading setup status:', err);
          this.isProcessing.set(false);
          this.cdr.markForCheck();
        }
      });
  }

  private setupClassesFormSubscription(): void {
    this.classesForm.get('academicYearId')?.valueChanges
      .pipe(
        debounceTime(100),
        takeUntil(this.destroy$)
      )
      .subscribe((yearId) => {
        if (yearId) {
          this.loadExistingClasses(yearId);
        }
      });
  }

  private loadExistingClasses(yearId: number): void {
    this.isLoadingClasses.set(true);
    this.cdr.markForCheck();

    this.setupService.getClassesByYear(yearId)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (response) => {
          const data = response?.data || response;
          if (Array.isArray(data)) {
            this.selectedClasses.set(data.map(c => ({
              id: c.id || c.Id,
              className: c.name || c.Name,
              classCode: c.code || c.Code,
              capacity: c.capacity || c.Capacity,
              academicYearId: c.academicYearId || c.AcademicYearId
            })));
          } else {
            this.selectedClasses.set([]);
          }
          this.isLoadingClasses.set(false);
          this.cdr.markForCheck();
        },
        error: (err) => {
          console.error('Error loading existing classes:', err);
          this.isLoadingClasses.set(false);
          this.cdr.markForCheck();
        }
      });
  }

  private setupSubjectsFormSubscription(): void {
    // Watch academicYearId to filter classes
    this.subjectsForm.get('academicYearId')?.valueChanges
      .pipe(
        debounceTime(100),
        takeUntil(this.destroy$)
      )
      .subscribe((yearId) => {
        if (yearId) {
          this.loadClassesForSubjects(+yearId);
          // Reset class selection when year changes. loadClassesForSubjects
          // auto-selects the first class afterwards, which triggers
          // loadExistingSubjects so the list always shows the subjects stored
          // for Academic Year + Class.
          this.subjectsForm.get('classId')?.setValue('', { emitEvent: false });
          this.selectedSubjects.set([]);
          this.cdr.markForCheck();
        } else {
          this.filteredClassesForSubjects.set([]);
          this.subjectsForm.get('classId')?.setValue('', { emitEvent: false });
          this.selectedSubjects.set([]);
          this.cdr.markForCheck();
        }
      });

    // Watch classId to load subjects
    this.subjectsForm.get('classId')?.valueChanges
      .pipe(
        debounceTime(100),
        takeUntil(this.destroy$)
      )
      .subscribe((classId) => {
        if (classId) {
          this.loadExistingSubjects(classId);
        } else {
          this.selectedSubjects.set([]);
          this.cdr.markForCheck();
        }
      });
  }

  private loadClassesForSubjects(yearId: number): void {
    this.isLoadingClasses.set(true);
    this.cdr.markForCheck();

    this.setupService.getClassesByYear(yearId)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (response) => {
          const data = response?.data || response;
          if (Array.isArray(data)) {
            this.filteredClassesForSubjects.set(data.map(c => ({
              id: c.id || c.Id,
              name: c.name || c.Name
            })));
          } else {
            this.filteredClassesForSubjects.set([]);
          }

          // Auto-select the first class of the selected academic year so the
          // existing subjects (Academic Year → Class → Subject) load without
          // the user having to pick a class manually or refresh the page.
          const currentClassId = this.subjectsForm.get('classId')?.value;
          if ((!currentClassId || !this.filteredClassesForSubjects().some(c => c.id === +currentClassId))
              && this.filteredClassesForSubjects().length > 0) {
            this.subjectsForm.get('classId')?.setValue(this.filteredClassesForSubjects()[0].id);
          }

          this.isLoadingClasses.set(false);
          this.cdr.markForCheck();
        },
        error: (err) => {
          console.error('Error loading classes for subjects:', err);
          this.isLoadingClasses.set(false);
          this.cdr.markForCheck();
        }
      });
  }

  private loadExistingSubjects(classId: number): void {
    this.isLoadingSubjects.set(true);
    this.cdr.markForCheck();

    this.setupService.getSubjectsByClass(classId)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (response) => {
          const data = response?.data || response;
          if (Array.isArray(data)) {
            this.selectedSubjects.set(data.map(s => ({
              id: s.id || s.Id,
              subjectName: s.name || s.Name,
              subjectCode: s.code || s.Code,
              creditHours: s.creditHours || s.CreditHours,
              description: s.description || s.Description,
              classId: s.classId || s.ClassId
            })));
          } else {
            this.selectedSubjects.set([]);
          }
          this.isLoadingSubjects.set(false);
          this.cdr.markForCheck();
        },
        error: (err) => {
          console.error('Error loading existing subjects:', err);
          this.isLoadingSubjects.set(false);
          this.cdr.markForCheck();
        }
      });
  }

  private setupFeesFormSubscription(): void {
    this.feesForm.get('academicYearId')?.valueChanges
      .pipe(
        debounceTime(100),
        takeUntil(this.destroy$)
      )
      .subscribe((yearId) => {
        if (yearId) {
          this.loadExistingFeeStructure(yearId);
        }
      });
  }

  private loadExistingFeeStructure(academicYearId: number): void {
    this.isLoadingFees.set(true);
    this.cdr.markForCheck();

    this.setupService.getFeeStructures(academicYearId)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (response) => {
          const data = response?.data || response;
          let feeStructures = [];
          if (Array.isArray(data)) {
            feeStructures = data.map((f: any) => ({
              ...f,
              id: f.id || f.Id
            }));
          } else if (data && (data.id || data.Id)) {
            feeStructures = [{
              ...data,
              id: data.id || data.Id
            }];
          }
          
          this.feeStructureDataSource.data = feeStructures;
          setTimeout(() => {
            if (this.paginator) {
              this.paginator.pageSize = 50;
              this.feeStructureDataSource.paginator = this.paginator;
            }
          });
          
          this.isLoadingFees.set(false);
          this.cdr.markForCheck();
        },
        error: (err) => {
          console.error('Error loading existing fee structure:', err);
          this.isLoadingFees.set(false);
          this.cdr.markForCheck();
        }
      });
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  private initiateForms(): void {
    this.academicYearForm = this.fb.group({
      name: ['', [Validators.required, Validators.minLength(4)]],
      startDate: ['', Validators.required],
      endDate: ['', Validators.required],
      isActive: [true],
      isCurrent: [true]
    });

    this.classesForm = this.fb.group({
      className: ['', [Validators.required, Validators.minLength(2)]],
      classCode: ['', [Validators.required, Validators.minLength(1)]],
      capacity: [40, [Validators.required, Validators.min(1)]],
      classTeacher: [''],
      academicYearId: ['', Validators.required]
    });

    this.subjectsForm = this.fb.group({
      academicYearId: ['', Validators.required],
      classId: ['', Validators.required],
      subjectName: ['', [Validators.required, Validators.minLength(3)]],
      subjectCode: ['', [Validators.required, Validators.minLength(2)]],
      description: [''],
      creditHours: [4, [Validators.required, Validators.min(1)]]
    });

    this.paymentMethodsForm = this.fb.group({
      paymentMethods: this.fb.array([])
    });

    this.feesForm = this.fb.group({
      academicYearId: ['', Validators.required]
    });

    this.sectionsForm = this.fb.group({
      academicYearId: ['', Validators.required],
      classId: ['', Validators.required],
      sectionName: ['', [Validators.required, Validators.minLength(1)]]
    });
  }

  private setupSectionsFormSubscription(): void {
    // Watch academicYearId to filter classes for sections
    this.sectionsForm.get('academicYearId')?.valueChanges
      .pipe(
        debounceTime(100),
        takeUntil(this.destroy$)
      )
      .subscribe((yearId) => {
        if (yearId) {
          this.loadClassesForSections(+yearId);
          this.sectionsForm.get('classId')?.setValue('', { emitEvent: false });
          this.selectedSections.set([]);
          this.cdr.markForCheck();
        } else {
          this.filteredClassesForSections.set([]);
          this.cdr.markForCheck();
        }
      });

    // Watch classId to load existing sections
    this.sectionsForm.get('classId')?.valueChanges
      .pipe(
        debounceTime(100),
        takeUntil(this.destroy$)
      )
      .subscribe((classId) => {
        if (classId) {
          this.loadExistingSections(classId);
        } else {
          this.selectedSections.set([]);
          this.cdr.markForCheck();
        }
      });
  }

  private loadClassesForSections(yearId: number): void {
    this.isLoadingClasses.set(true);
    this.cdr.markForCheck();

    this.setupService.getClassesByYear(yearId)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (response) => {
          const data = response?.data || response;
          if (Array.isArray(data)) {
            this.filteredClassesForSections.set(data.map(c => ({
              id: c.id || c.Id,
              name: c.name || c.Name
            })));
          } else {
            this.filteredClassesForSections.set([]);
          }
          this.isLoadingClasses.set(false);
          this.cdr.markForCheck();
        },
        error: (err) => {
          console.error('Error loading classes for sections:', err);
          this.isLoadingClasses.set(false);
          this.cdr.markForCheck();
        }
      });
  }

  private loadExistingSections(classId: number): void {
    this.isLoadingSections.set(true);
    this.cdr.markForCheck();

    this.setupService.getSectionsByClass(classId)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (response) => {
          const data = response?.data || response;
          if (Array.isArray(data)) {
            this.selectedSections.set(data.map(s => ({
              id: s.id || s.Id,
              name: s.name || s.Name,
              classId: s.classId || s.ClassId
            })));
          } else {
            this.selectedSections.set([]);
          }
          this.isLoadingSections.set(false);
          this.cdr.markForCheck();
        },
        error: (err) => {
          console.error('Error loading existing sections:', err);
          this.isLoadingSections.set(false);
          this.cdr.markForCheck();
        }
      });
  }

  addSectionToList(): void {
    if (this.sectionsForm.invalid) {
      this.snackBar.open('Please enter section name', 'Close', { duration: 2000 });
      return;
    }

    const formValue = this.sectionsForm.value;
    const sectionData = {
      name: formValue.sectionName,
      classId: formValue.classId
    };

    if (this.isEditingSection && this.editingSectionIndex !== null) {
      const updated = [...this.selectedSections()];
      updated[this.editingSectionIndex] = { ...updated[this.editingSectionIndex], ...sectionData };
      this.selectedSections.set(updated);
      this.isEditingSection = false;
      this.editingSectionIndex = null;
    } else {
      this.selectedSections.set([...this.selectedSections(), sectionData]);
    }

    this.sectionsForm.patchValue({ sectionName: '' });
    this.cdr.markForCheck();
  }

  editSection(section: any, index: number): void {
    this.isEditingSection = true;
    this.editingSectionIndex = index;
    this.sectionsForm.patchValue({
      sectionName: section.name
    });
    this.cdr.markForCheck();
  }

  removeSectionFromList(index: number): void {
    this.selectedSections.set(this.selectedSections().filter((_, i) => i !== index));
    if (this.editingSectionIndex === index) {
      this.resetSectionForm();
    }
    this.cdr.markForCheck();
  }

  resetSectionForm(): void {
    this.isEditingSection = false;
    this.editingSectionIndex = null;
    this.sectionsForm.patchValue({ sectionName: '' });
    this.cdr.markForCheck();
  }

  saveSections(): void {
    const classId = this.sectionsForm.get('classId')?.value;
    if (!classId || this.selectedSections().length === 0) {
      this.snackBar.open('Please add at least one section', 'Close', { duration: 3000 });
      return;
    }

    this.isProcessing.set(true);
    const request = {
      classId: +classId,
      sections: this.selectedSections().map(s => ({ id: s.id, name: s.name }))
    };

    this.setupService.createSections(request)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: () => {
          this.snackBar.open('Sections saved successfully', 'Close', { duration: 3000 });
          this.loadExistingSections(classId);
          this.isProcessing.set(false);
          this.cdr.markForCheck();
          setTimeout(() => this.stepper.next(), 500);
        },
        error: (err) => {
          console.error('Error saving sections:', err);
          this.snackBar.open(this.getErrorMessage(err), 'Close', { duration: 5000 });
          this.isProcessing.set(false);
          this.cdr.markForCheck();
        }
      });
  }

  applySectionPresets(): void {
    const classId = this.sectionsForm.get('classId')?.value;
    if (!classId) return;

    const presets = [
      { name: 'A', classId },
      { name: 'B', classId },
      { name: 'C', classId }
    ];

    const newSections = [...this.selectedSections()];
    presets.forEach(p => {
      if (!newSections.some(s => s.name === p.name)) {
        newSections.push(p);
      }
    });
    this.selectedSections.set(newSections);
    this.cdr.markForCheck();
  }

  private initializeSetupSteps(): void {
    this.setupSteps = [
      {
        id: 'academic-year',
        title: 'Academic Year/Session',
        description: 'Create the academic year or session for your school',
        icon: 'date_range',
        completed: false,
        required: true
      },
      {
        id: 'classes',
        title: 'Classes & Sections',
        description: 'Setup classes/standards and their sections',
        icon: 'class',
        completed: false,
        required: true
      },
      {
        id: 'subjects',
        title: 'Subjects',
        description: 'Define subjects taught in your institution',
        icon: 'subject',
        completed: false,
        required: true
      },
      {
        id: 'staff',
        title: 'Staff Structure',
        description: 'Configure staff departments and positions',
        icon: 'person',
        completed: false,
        required: false
      },
      {
        id: 'fees',
        title: 'Fee Structure',
        description: 'Setup fees and payment methods',
        icon: 'payment',
        completed: false,
        required: true
      },
      {
        id: 'payment-methods',
        title: 'Payment Methods',
        description: 'Configure payment methods and modes',
        icon: 'credit_card',
        completed: false,
        required: false
      }
    ];
    this.cdr.markForCheck();
  }

  private loadInitialData(): void {
    this.loadAcademicYears();
    this.loadClasses();
    // Load existing DB records for the Staff and Payment tabs up front so the
    // data is bound as soon as the tab is opened (no browser refresh needed).
    this.loadExistingStaff();
    this.loadSavedStaffStructure();
    this.loadPaymentMethods();
  }

  /** Load departments/positions already persisted for this tenant. */
  private loadSavedStaffStructure(): void {
    forkJoin({
      departments: this.masterDataService.getStaffDepartments(),
      positions: this.masterDataService.getStaffPositions()
    })
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: ({ departments, positions }) => {
          this.savedDepartments.set(departments);
          this.savedPositions.set(positions);
          this.cdr.markForCheck();
        },
        error: (err) => {
          console.error('Error loading saved staff structure:', err);
        }
      });
  }

  /**
   * Open a Material dialog to add a new entry (department or position) and
   * persist it straight to the database.
   * lookupType: 'staff-departments' | 'staff-positions'
   */
  addSavedLookup(lookupType: string): void {
    const isDept = lookupType === 'staff-departments';
    const kind = isDept ? 'department' : 'position';

    const dialogRef = this.dialog.open(PromptDialogComponent, {
      data: {
        title: `Add ${kind}`,
        message: `Enter a name for the new ${kind}. It will be saved to your institution's staff structure.`,
        placeholder: isDept ? 'Department name' : 'Position name',
        confirmText: 'Add',
        icon: 'add_circle'
      } as PromptDialogData
    });

    dialogRef.afterClosed().subscribe((label: string | null) => {
      const trimmed = (label || '').trim();
      if (!trimmed) {
        return;
      }

      // Client-side duplicate check against what's already saved.
      const list = isDept ? this.savedDepartments() : this.savedPositions();
      if (list.some(v => (v.name || '').trim().toLowerCase() === trimmed.toLowerCase())) {
        this.snackBar.open(`"${trimmed}" is already saved`, 'Close', { duration: 2500 });
        return;
      }

      this.isProcessing.set(true);
      // Same DB-backed lookup CRUD the Departments/Designations admin screens use.
      this.setupService.createStaffStructureLookup(lookupType, trimmed)
        .pipe(takeUntil(this.destroy$))
        .subscribe({
          next: () => {
            this.snackBar.open(`${isDept ? 'Department' : 'Position'} '${trimmed}' saved`, 'Close', { duration: 2500 });
            this.isProcessing.set(false);
            this.loadSavedStaffStructure();
          },
          error: (err) => {
            console.error('Error saving staff lookup:', err);
            this.snackBar.open(this.getErrorMessage(err), 'Close', { duration: 5000 });
            this.isProcessing.set(false);
            this.cdr.markForCheck();
          }
        });
    });
  }

  /** Rename a saved entry (department or position) in place via a Material prompt dialog. */
  renameSavedLookup(entry: any, lookupType: string): void {
    const isDept = lookupType === 'staff-departments';
    const current = (entry.name || entry.label || '').trim();
    const kind = isDept ? 'department' : 'position';

    const dialogRef = this.dialog.open(PromptDialogComponent, {
      data: {
        title: `Rename ${kind}`,
        message: `Update the name of this ${kind}.`,
        initialValue: current,
        placeholder: isDept ? 'Department name' : 'Position name',
        confirmText: 'Save',
        icon: 'edit'
      } as PromptDialogData
    });

    dialogRef.afterClosed().subscribe((updated: string | null) => {
      if (!updated || updated === current) {
        return;
      }

      this.isProcessing.set(true);
      this.setupService.renameStaffStructureLookup(entry.id, lookupType, updated)
        .pipe(takeUntil(this.destroy$))
        .subscribe({
          next: () => {
            this.snackBar.open(`${isDept ? 'Department' : 'Position'} renamed to '${updated}'`, 'Close', { duration: 2500 });
            this.isProcessing.set(false);
            this.loadSavedStaffStructure();
          },
          error: (err) => {
            console.error('Error renaming staff lookup:', err);
            this.snackBar.open(this.getErrorMessage(err), 'Close', { duration: 5000 });
            this.isProcessing.set(false);
            this.cdr.markForCheck();
          }
        });
    });
  }

  /** Delete (soft) a saved entry (department or position) after a Material confirm dialog. */
  removeSavedLookup(entry: any, lookupType: string): void {
    const isDept = lookupType === 'staff-departments';
    const label = (entry.name || entry.label || '').trim();

    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      data: {
        title: `Delete ${isDept ? 'department' : 'position'}?`,
        message: `"${label}" will be removed from your staff structure. This cannot be undone.`,
        confirmText: 'Delete',
        cancelText: 'Cancel',
        icon: 'delete_forever',
        severity: 'danger'
      } as ConfirmDialogData
    });

    dialogRef.afterClosed().subscribe((confirmed: boolean) => {
      if (!confirmed) {
        return;
      }

      this.isProcessing.set(true);
      this.setupService.deleteStaffStructureLookup(entry.id, lookupType)
        .pipe(takeUntil(this.destroy$))
        .subscribe({
          next: () => {
            this.snackBar.open(`${isDept ? 'Department' : 'Position'} '${label}' deleted`, 'Close', { duration: 2500 });
            this.isProcessing.set(false);
            this.loadSavedStaffStructure();
          },
          error: (err) => {
            console.error('Error deleting staff lookup:', err);
            this.snackBar.open(this.getErrorMessage(err), 'Close', { duration: 5000 });
            this.isProcessing.set(false);
            this.cdr.markForCheck();
          }
        });
    });
  }

  /** Load staff records already stored in the database for this tenant. */
  private loadExistingStaff(): void {
    this.isLoadingStaff.set(true);
    this.cdr.markForCheck();

    this.setupService.getStaff()
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (data) => {
          this.staffList.set(Array.isArray(data) ? data : []);
          this.isLoadingStaff.set(false);
          this.cdr.markForCheck();
        },
        error: (err) => {
          console.error('Error loading existing staff:', err);
          this.isLoadingStaff.set(false);
          this.cdr.markForCheck();
        }
      });
  }

  /** Load payment methods already configured in the database for this tenant. */
  private loadPaymentMethods(): void {
    this.isLoadingPaymentMethods.set(true);
    this.cdr.markForCheck();

    this.setupService.getPaymentMethods()
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (data) => {
          this.existingPaymentMethods.set(Array.isArray(data) ? data : []);
          this.isLoadingPaymentMethods.set(false);
          this.cdr.markForCheck();
        },
        error: (err) => {
          console.error('Error loading payment methods:', err);
          this.isLoadingPaymentMethods.set(false);
          this.cdr.markForCheck();
        }
      });
  }

  /** Whether a payment method with the given name is already enabled in the DB. */
  hasPaymentMethod(name: string): boolean {
    return this.existingPaymentMethods().some(m =>
      (m.name || m.Name || '').trim().toLowerCase() === name.trim().toLowerCase());
  }

  private loadAcademicYears(): void {
    this.isLoadingAcademicYears.set(true);
    this.cdr.markForCheck();

    // Always hit the API (refreshAcademicYears) so the Session list reflects the
    // latest DB state after create/update instead of replaying a cached snapshot.
    this.yearContext.refreshAcademicYears()
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: () => {
          // Read the service's mapped snapshot instead of the raw HTTP emission:
          // it normalizes the ApiResponse envelope and keeps the FULL year objects
          // (id/name/startDate/endDate/isActive/isCurrent). Previously the years
          // were taken from a dropdown-only mapping that dropped the dates, which
          // is why the edit form could not populate date fields.
          this.academicYears.set((this.yearContext.yearsSnapshot || []).map((y: any) => ({
            id: y.id,
            name: y.name,
            isActive: y.isActive,
            isCurrent: y.isCurrent,
            startDate: y.startDate,
            endDate: y.endDate
          })));

          if (this.academicYears().length > 0) {
            const firstYear = this.academicYears()[0];
            const firstYearId = firstYear.id;

            if (!this.classesForm.get('academicYearId')?.value) {
              this.classesForm.patchValue({ academicYearId: firstYearId }, { emitEvent: false });
            }
            if (!this.feesForm.get('academicYearId')?.value) {
              this.feesForm.patchValue({ academicYearId: firstYearId }, { emitEvent: false });
            }
            if (!this.subjectsForm.get('academicYearId')?.value) {
              this.subjectsForm.patchValue({ academicYearId: firstYearId }, { emitEvent: false });
            }
            if (!this.sectionsForm.get('academicYearId')?.value) {
              this.sectionsForm.patchValue({ academicYearId: firstYearId }, { emitEvent: false });
            }

            // Seed every year-dependent list immediately for the initial year.
            // The academicYearId valueChanges subscriptions only fire on
            // *changes* — if a default was already present the patch is
            // skipped and nothing loads, leaving the Classes list, Subjects
            // / Sections dropdowns and the Fees table empty until a manual
            // page refresh. (Defense in depth on top of subscribing before
            // loadInitialData in ngOnInit.)
            this.loadExistingClasses(firstYearId);
            this.loadClassesForSubjects(firstYearId);
            this.loadClassesForSections(firstYearId);
            this.loadExistingFeeStructure(firstYearId);
          }
          this.isLoadingAcademicYears.set(false);
          this.cdr.markForCheck();
        },
        error: (err) => {
          console.error('Error loading academic years:', err);
          this.isLoadingAcademicYears.set(false);
          this.cdr.markForCheck();
        }
      });
  }

  private loadClasses(): void {
    this.isLoadingClasses.set(true);
    this.masterDataService.getClasses()
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (data) => {
          this.classes.set(data || []);
          // NOTE: subjectsForm.classId is deliberately NOT seeded here — this list
          // contains classes from ALL academic years, so picking the first one could
          // bind a class that doesn't belong to the selected year. The Subjects tab
          // auto-selects a class from the selected year's own list instead
          // (see loadClassesForSubjects), guaranteeing Year → Class consistency.
          this.isLoadingClasses.set(false);
          this.cdr.markForCheck();
        },
        error: (err) => {
          console.error('Error loading classes:', err);
          this.isLoadingClasses.set(false);
          this.cdr.markForCheck();
        }
      });
  }

  /**
   * Extract error message from HTTP error response
   */
  private getErrorMessage(error: any): string {
    try {
      if (error.error?.errors && typeof error.error.errors === 'object') {
        const errorsObj = error.error.errors as { [key: string]: string[] };
        const errorMessages: string[] = [];
        for (const [field, messages] of Object.entries(errorsObj)) {
          if (Array.isArray(messages)) {
            errorMessages.push(field === 'general' ? `${messages.join(', ')}` : `${field}: ${messages.join(', ')}`);
          }
        }
        if (errorMessages.length > 0) return errorMessages.join('\n');
      }
      if (error.error?.message) return error.error.message;
      if (error.statusText) return `${error.statusText}: ${error.error?.message || 'Please try again'}`;
      return 'An error occurred. Please try again.';
    } catch (e) {
      return 'An error occurred. Please try again.';
    }
  }


  // Step 1: Academic Year Setup
  editAcademicYear(year: any): void {
    this.isEditingAcademicYear.set(true);
    this.editingAcademicYearId.set(year.id || year.Id);
    
    // Ensure dates are actual Date objects for the datepicker
    const startDate = year.startDate || year.StartDate;
    const endDate = year.endDate || year.EndDate;
    
    this.academicYearForm.patchValue({
      name: year.name || year.Name,
      startDate: startDate ? new Date(startDate) : '',
      endDate: endDate ? new Date(endDate) : '',
      isActive: year.isActive !== undefined ? year.isActive : year.IsActive,
      isCurrent: year.isCurrent !== undefined ? year.isCurrent : year.IsCurrent
    });
    this.cdr.markForCheck();
  }

  saveAcademicYear(): void {
    if (this.academicYearForm.invalid) {
      this.snackBar.open('Please fill all required fields', 'Close', { duration: 3000 });
      return;
    }

    this.isProcessing.set(true);
    const formValue = this.academicYearForm.value;
    
    const wasEditing = this.isEditingAcademicYear();
    const editingId = this.editingAcademicYearId();

    const formData = {
      id: editingId,
      name: formValue.name,
      // Serialize Date objects as ISO strings – the backend DTO binds DateTime
      // from ISO format; passing a raw Date would be serialized consistently by
      // HttpClient but keeping it explicit avoids timezone/date-format issues.
      startDate: formValue.startDate instanceof Date ? formValue.startDate.toISOString() : formValue.startDate,
      endDate: formValue.endDate instanceof Date ? formValue.endDate.toISOString() : formValue.endDate,
      isActive: formValue.isActive,
      isCurrent: formValue.isCurrent
    };

    const action = wasEditing && editingId
      ? this.setupService.updateAcademicYear(editingId, formData)
      : this.setupService.createAcademicYear(formData);

    action.pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (result: any) => {
          this.snackBar.open(`Academic Year ${wasEditing ? 'updated' : 'created'} successfully`, 'Close', { duration: 3000 });
          this.markStepComplete('academic-year');
          this.updateProgress();
          this.isProcessing.set(false);

          // Reset edit state BEFORE anything that reads it (the old code reset it
          // first and then tested it, so the "go to next step" branch never ran).
          this.isEditingAcademicYear.set(false);
          this.editingAcademicYearId.set(null);
          this.academicYearForm.reset({ isActive: true, isCurrent: true });

          if (wasEditing && editingId) {
            // Update the edited row in place so the list reflects the change
            // immediately, then re-sync with the server (fresh dates, ordering,
            // and propagation of IsCurrent changes to other years via the API).
            const saved = result ?? formData;
            const idx = this.academicYears().findIndex(y => y.id === editingId);
            if (idx > -1) {
              const updated = [...this.academicYears()];
              updated[idx] = {
                id: editingId,
                name: saved.name ?? formData.name,
                isActive: saved.isActive ?? formData.isActive,
                isCurrent: saved.isCurrent ?? formData.isCurrent,
                startDate: saved.startDate ?? formData.startDate,
                endDate: saved.endDate ?? formData.endDate
              };
              this.academicYears.set(updated);
            }
            this.loadAcademicYears();
          } else {
            this.loadAcademicYears();
            setTimeout(() => this.stepper.next(), 500);
          }
          this.cdr.markForCheck();
        },
        error: (err) => {
          console.error(`Error ${wasEditing ? 'updating' : 'creating'} academic year:`, err);
          this.snackBar.open(this.getErrorMessage(err), 'Close', { duration: 5000 });
          this.isProcessing.set(false);
          this.cdr.markForCheck();
        }
      });
  }

  cancelEditAcademicYear(): void {
    this.isEditingAcademicYear.set(false);
    this.editingAcademicYearId.set(null);
    this.academicYearForm.reset({ isActive: true, isCurrent: true });
    this.cdr.markForCheck();
  }

  // Step 2: Classes Setup
  addClassToList(): void {
    if (this.classesForm.invalid) {
      this.snackBar.open('Please fill class details correctly', 'Close', { duration: 2000 });
      return;
    }

    const formValue = this.classesForm.value;
    const classData = {
      ...formValue,
      name: formValue.className,
      code: formValue.classCode
    };

    if (this.isEditingClass && this.editingClassIndex !== null) {
      // Update existing class in the list immutably
      const updatedClasses = [...this.selectedClasses()];
      updatedClasses[this.editingClassIndex] = {
        ...updatedClasses[this.editingClassIndex],
        ...classData
      };
      this.selectedClasses.set(updatedClasses);
      this.isEditingClass = false;
      this.editingClassIndex = null;
      this.snackBar.open('Class updated in list', 'Close', { duration: 2000 });
    } else {
      // Add new class to the list immutably
      this.selectedClasses.set([...this.selectedClasses(), classData]);
      this.snackBar.open('Class added to list', 'Close', { duration: 2000 });
    }

    const yearId = this.classesForm.get('academicYearId')?.value;
    this.resetClassForm(yearId);
    this.cdr.markForCheck();
  }

  editClass(classData: any, index: number): void {
    this.isEditingClass = true;
    this.editingClassIndex = index;
    this.classesForm.patchValue({
      academicYearId: classData.academicYearId || this.classesForm.get('academicYearId')?.value,
      className: classData.className,
      classCode: classData.classCode,
      capacity: classData.capacity,
      classTeacher: classData.classTeacher
    }, { emitEvent: false }); // Prevent re-loading existing classes when patching
    this.cdr.markForCheck();
  }

  resetClassForm(yearId?: number): void {
    this.isEditingClass = false;
    this.editingClassIndex = null;
    this.classesForm.patchValue({
      className: '',
      classCode: '',
      capacity: 40,
      classTeacher: '',
      academicYearId: yearId || this.classesForm.get('academicYearId')?.value
    }, { emitEvent: false });
  }

  removeClassFromList(index: number): void {
    this.selectedClasses.set(this.selectedClasses().filter((_, i) => i !== index));
    if (this.editingClassIndex === index) {
      this.resetClassForm();
    }
    this.cdr.markForCheck();
  }

  applyClassPresets(): void {
    const academicYearId = this.classesForm.get('academicYearId')?.value;
    if (!academicYearId) {
      this.snackBar.open('Please select/save academic year first', 'Close', { duration: 3000 });
      return;
    }

    const presets = [
      { className: 'Nursery', classCode: 'NUR', name: 'Nursery', code: 'NUR', capacity: 30, academicYearId },
      { className: 'LKG', classCode: 'LKG', name: 'LKG', code: 'LKG', capacity: 30, academicYearId },
      { className: 'UKG', classCode: 'UKG', name: 'UKG', code: 'UKG', capacity: 30, academicYearId },
      { className: 'Class 1', classCode: 'C1', name: 'Class 1', code: 'C1', capacity: 40, academicYearId },
      { className: 'Class 2', classCode: 'C2', name: 'Class 2', code: 'C2', capacity: 40, academicYearId },
      { className: 'Class 3', classCode: 'C3', name: 'Class 3', code: 'C3', capacity: 40, academicYearId },
      { className: 'Class 4', classCode: 'C4', name: 'Class 4', code: 'C4', capacity: 40, academicYearId },
      { className: 'Class 5', classCode: 'C5', name: 'Class 5', code: 'C5', capacity: 40, academicYearId },
      { className: 'Class 6', classCode: 'C6', name: 'Class 6', code: 'C6', capacity: 40, academicYearId },
      { className: 'Class 7', classCode: 'C7', name: 'Class 7', code: 'C7', capacity: 40, academicYearId },
      { className: 'Class 8', classCode: 'C8', name: 'Class 8', code: 'C8', capacity: 40, academicYearId },
      { className: 'Class 9', classCode: 'C9', name: 'Class 9', code: 'C9', capacity: 40, academicYearId },
      { className: 'Class 10', classCode: 'C10', name: 'Class 10', code: 'C10', capacity: 40, academicYearId }
    ];

    const newClasses = [...this.selectedClasses()];
    presets.forEach(preset => {
      if (!newClasses.some(c => c.className === preset.className)) {
        newClasses.push(preset);
      }
    });
    this.selectedClasses.set(newClasses);
    this.cdr.markForCheck();
    this.snackBar.open('Default classes loaded.', 'Close', { duration: 3000 });
  }

  saveClass(): void {
    if (this.selectedClasses().length === 0) {
      if (this.classesForm.valid) {
        this.addClassToList();
      } else {
        this.snackBar.open('Please add at least one class', 'Close', { duration: 3000 });
        return;
      }
    }

    this.isProcessing.set(true);
    
    const academicYearId = this.classesForm.get('academicYearId')?.value;
    
    // Map property names to match ClassRequest interface
    const classRequests: ClassRequest[] = this.selectedClasses().map(c => ({
      id: c.id,
      className: c.className || c.name,
      classCode: c.classCode || c.code,
      capacity: c.capacity,
      academicYearId: +academicYearId
    }));

    this.setupService.createClass(classRequests)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (result) => {
          this.snackBar.open(`${this.selectedClasses().length} classes saved successfully`, 'Close', { duration: 3000 });
          
          // Refresh data
          if (academicYearId) {
            this.loadExistingClasses(academicYearId);
            // Refresh dependent dropdowns so newly saved classes appear
            // without a manual page refresh
            this.loadClassesForSubjects(academicYearId);
            this.loadClassesForSections(academicYearId);
            // Refresh the master class list used by getClassName() when building            // fee-structure names. Without this, first-time setup names fee            // structures "Fee Structure for Unknown (...)" because the stale            // list loaded at page start predates the classes created in step 2.
            this.loadClasses();
          }

          this.markStepComplete('classes');
          this.updateProgress();
          this.isProcessing.set(false);
          this.resetClassForm();
          this.cdr.markForCheck();
          setTimeout(() => this.stepper.next(), 500);
        },
        error: (err) => {
          console.error('Error saving classes:', err);
          this.snackBar.open(this.getErrorMessage(err), 'Close', { duration: 5000 });
          this.isProcessing.set(false);
          this.cdr.markForCheck();
        }
      });
  }

  // Step 3: Subjects Setup
  addSubjectToList(): void {
    if (this.subjectsForm.invalid) {
      this.snackBar.open('Please fill subject details correctly', 'Close', { duration: 2000 });
      return;
    }

    const formValue = this.subjectsForm.value;
    const subjectData = {
      ...formValue,
      name: formValue.subjectName,
      code: formValue.subjectCode
    };

    if (this.isEditingSubject && this.editingSubjectIndex !== null) {
      // Update existing subject in the list immutably
      const updatedSubjects = [...this.selectedSubjects()];
      updatedSubjects[this.editingSubjectIndex] = {
        ...updatedSubjects[this.editingSubjectIndex],
        ...subjectData
      };
      this.selectedSubjects.set(updatedSubjects);
      this.isEditingSubject = false;
      this.editingSubjectIndex = null;
      this.snackBar.open('Subject updated in list', 'Close', { duration: 2000 });
    } else {
      // Prevent duplicate assignment: the list contains the subjects already
      // stored for this Academic Year + Class (loaded with their ids), so a
      // name/code collision means the subject is already configured.
      const duplicate = this.selectedSubjects().some(s =>
        (s.subjectName || s.name || '').trim().toLowerCase() === String(subjectData.subjectName).trim().toLowerCase() ||
        (s.subjectCode || s.code || '').trim().toLowerCase() === String(subjectData.subjectCode).trim().toLowerCase());
      if (duplicate) {
        this.snackBar.open(`Subject "${subjectData.subjectName}" is already configured for this class`, 'Close', { duration: 3000 });
        return;
      }
      // Add new subject to the list immutably
      this.selectedSubjects.set([...this.selectedSubjects(), subjectData]);
      this.snackBar.open('Subject added to list', 'Close', { duration: 2000 });
    }

    const classId = this.subjectsForm.get('classId')?.value;
    this.resetSubjectForm(classId);
    this.cdr.markForCheck();
  }

  editSubject(subject: any, index: number): void {
    this.isEditingSubject = true;
    this.editingSubjectIndex = index;
    this.subjectsForm.patchValue({
      classId: subject.classId || this.subjectsForm.get('classId')?.value,
      subjectName: subject.subjectName || subject.name,
      subjectCode: subject.subjectCode || subject.code,
      description: subject.description,
      creditHours: subject.creditHours
    }, { emitEvent: false }); // Prevent re-loading existing subjects when patching
    this.cdr.markForCheck();
  }

  resetSubjectForm(classId?: number): void {
    this.isEditingSubject = false;
    this.editingSubjectIndex = null;
    this.subjectsForm.patchValue({
      subjectName: '',
      subjectCode: '',
      description: '',
      creditHours: 4,
      classId: classId || this.subjectsForm.get('classId')?.value
    }, { emitEvent: false });
  }

  removeSubjectFromList(index: number): void {
    this.selectedSubjects.set(this.selectedSubjects().filter((_, i) => i !== index));
    if (this.editingSubjectIndex === index) {
      this.resetSubjectForm();
    }
    this.cdr.markForCheck();
  }

  applySubjectPresets(): void {
    const classId = this.subjectsForm.get('classId')?.value;
    if (!classId) {
      this.snackBar.open('Please select a class first', 'Close', { duration: 3000 });
      return;
    }

    const presets = [
      { subjectName: 'Mathematics', subjectCode: 'MATH', name: 'Mathematics', code: 'MATH', creditHours: 4, description: 'Core Mathematics', classId },
      { subjectName: 'Science', subjectCode: 'SCI', name: 'Science', code: 'SCI', creditHours: 4, description: 'General Science', classId },
      { subjectName: 'English', subjectCode: 'ENG', name: 'English', code: 'ENG', creditHours: 3, description: 'English Language', classId },
      { subjectName: 'Social Studies', subjectCode: 'SST', name: 'Social Studies', code: 'SST', creditHours: 3, description: 'SST', classId },
      { subjectName: 'Hindi', subjectCode: 'HIN', name: 'Hindi', code: 'HIN', creditHours: 3, description: 'Hindi', classId },
      { subjectName: 'Computer Science', subjectCode: 'CS', name: 'Computer Science', code: 'CS', creditHours: 2, description: 'IT', classId }
    ];

    const newSubjects = [...this.selectedSubjects()];
    presets.forEach(preset => {
      if (!newSubjects.some(s => s.subjectName === preset.subjectName)) {
        newSubjects.push(preset);
      }
    });
    this.selectedSubjects.set(newSubjects);
    this.cdr.markForCheck();
    this.snackBar.open('Default subjects loaded for selected class.', 'Close', { duration: 3000 });
  }

  saveSubject(): void {
    if (this.selectedSubjects().length === 0) {
      if (this.subjectsForm.valid) {
        this.addSubjectToList();
      } else {
        this.snackBar.open('Please add at least one subject', 'Close', { duration: 3000 });
        return;
      }
    }

    this.isProcessing.set(true);
    const subjectsByClass = this.selectedSubjects().reduce((acc, curr) => {
      if (!acc[curr.classId]) acc[curr.classId] = [];
      acc[curr.classId].push({
        id: curr.id,
        name: curr.name || curr.subjectName,
        code: curr.code || curr.subjectCode,
        creditHours: curr.creditHours,
        description: curr.description
      });
      return acc;
    }, {} as { [key: number]: any[] });

    const requests = Object.keys(subjectsByClass).map(classIdStr => {
      const classId = +classIdStr;
      const subjectRequests: SubjectRequest[] = subjectsByClass[classId].map((s: any) => ({
        id: s.id,
        subjectName: s.name || s.subjectName,
        subjectCode: s.code || s.subjectCode,
        creditHours: s.creditHours,
        description: s.description,
        classId: classId
      }));
      return this.setupService.createSubject(subjectRequests);
    });

    forkJoin(requests)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: () => {
          this.snackBar.open('Subjects saved successfully', 'Close', { duration: 3000 });
          
          // Refresh data
          const classId = this.subjectsForm.get('classId')?.value;
          if (classId) {
            this.loadExistingSubjects(classId);
          }

          this.markStepComplete('subjects');
          this.updateProgress();
          this.isProcessing.set(false);
          this.resetSubjectForm();
          this.cdr.markForCheck();
          setTimeout(() => this.stepper.next(), 500);
        },
        error: (err) => {
          console.error('Error saving subjects:', err);
          this.snackBar.open(this.getErrorMessage(err), 'Close', { duration: 5000 });
          this.isProcessing.set(false);
          this.cdr.markForCheck();
        }
      });
  }

  // Step 4: Staff Structure Setup
  removeDepartment(index: number): void {
    this.selectedDepartments = this.selectedDepartments.filter((_, i) => i !== index);
    this.cdr.markForCheck();
  }

  removePosition(deptIndex: number, posIndex: number): void {
    const updatedDepartments = [...this.selectedDepartments];
    const dept = updatedDepartments[deptIndex];
    updatedDepartments[deptIndex] = {
      ...dept,
      positions: dept.positions.filter((_: any, i: number) => i !== posIndex)
    };
    this.selectedDepartments = updatedDepartments;
    this.cdr.markForCheck();
  }

  applyStaffPresets(): void {
    const presets = [
      { 
        name: 'Academic', code: 'ACAD', 
        positions: [
          { name: 'Principal', code: 'PRN' },
          { name: 'HOD', code: 'HOD' },
          { name: 'Teacher', code: 'TCH' }
        ] 
      },
      { 
        name: 'Administration', code: 'ADMIN', 
        positions: [
          { name: 'Admin Officer', code: 'ADM' },
          { name: 'Clerk', code: 'CLR' }
        ] 
      },
      { 
        name: 'Accounts', code: 'ACCT', 
        positions: [
          { name: 'Accountant', code: 'ACC' }
        ] 
      },
      { 
        name: 'Transport', code: 'TRANS', 
        positions: [
          { name: 'Supervisor', code: 'SUP' },
          { name: 'Driver', code: 'DRV' }
        ] 
      }
    ];

    const newDepartments = [...this.selectedDepartments];
    presets.forEach(preset => {
      if (!newDepartments.some(d => d.name === preset.name)) {
        newDepartments.push(preset);
      }
    });
    this.selectedDepartments = newDepartments;
    this.cdr.markForCheck();
    this.snackBar.open('Standard staff structure loaded.', 'Close', { duration: 3000 });
  }

  saveStaffStructure(): void {
    if (this.selectedDepartments.length === 0) {
      // The inline form was removed — departments/positions are managed via the
      // DB-backed "Saved Staff Structure" chips. If those already have data there
      // is nothing left to POST; just mark the step complete and advance.
      if (this.savedDepartments().length > 0 || this.savedPositions().length > 0) {
        this.markStepComplete('staff');
        this.updateProgress();
        this.snackBar.open('Staff structure is already configured.', 'Close', { duration: 2500 });
        setTimeout(() => this.stepper.next(), 300);
        return;
      }
      this.snackBar.open('Add departments via "Add Department" / "Add Position", or use Apply Standard Structure, then Save & Continue.', 'Close', { duration: 4500 });
      return;
    }

    this.isProcessing.set(true);
    const payload = { departments: this.selectedDepartments };

    this.setupService.createStaffStructure(payload)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (result) => {
          this.snackBar.open('Staff structure created successfully', 'Close', { duration: 3000 });
          this.markStepComplete('staff');
          this.updateProgress();
          this.isProcessing.set(false);
          // Re-sync with the database so the tab always reflects latest state.
          this.loadExistingStaff();
          this.loadSavedStaffStructure();
          this.cdr.markForCheck();
          setTimeout(() => this.stepper.next(), 500);
        },
        error: (err) => {
          console.error('Error creating staff structure:', err);
          this.snackBar.open(this.getErrorMessage(err), 'Close', { duration: 5000 });
          this.isProcessing.set(false);
          this.cdr.markForCheck();
        }
      });
  }

  openFeeStructureDialog(): void {
    const dialogRef = this.dialog.open(FeeStructureDialogComponent, {
      ...this.dialogUtils.getMobileConfig({ width: '800px', maxWidth: '90vw' }),
      disableClose: false,
      data: { 
        mode: 'create', 
        title: 'Fee Structure Setup', 
        initialData: this.selectedFeeStructure, 
        classes: this.classes(),
        academicYears: this.academicYears()
      }
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.saveFeeStructure(result);
      }
    });
  }

  private saveFeeStructure(feeData: any): void {
    if (!feeData.academicYearId) {
      this.snackBar.open('Please select Academic Year', 'Close', { duration: 3000 });
      return;
    }

    if (!feeData.classIds || feeData.classIds.length === 0) {
      this.snackBar.open('Please select at least one Class', 'Close', { duration: 3000 });
      return;
    }

    this.isProcessing.set(true);
    const academicYearId = feeData.academicYearId;
    const yearName = this.getAcademicYearName(+academicYearId);
    
    // Calculate total annual fee
    const tuitionFee = feeData.tuitionFee || 0;
    const registrationFee = feeData.registrationFee || 0;
    const transportFee = feeData.transportFee || 0;
    const libraryFee = feeData.libraryFee || 0;
    const computerFee = feeData.computerFee || 0;
    const examinationFee = feeData.examinationFee || 0;
    const uniformFee = feeData.uniformFee || 0;
    const laboratoryFee = feeData.laboratoryFee || 0;
    const sportsFee = feeData.sportsFee || 0;
    const miscellaneousFee = feeData.miscellaneousFee || 0;
    
    const totalAnnualFee = tuitionFee + registrationFee + transportFee + libraryFee + computerFee + examinationFee + uniformFee + laboratoryFee + sportsFee + miscellaneousFee;

    const installmentTemplate = (feeData.installments || []).map((inst: any) => ({
      name: inst.name || inst.Name,
      amount: inst.amount || inst.Amount,
      dueDate: inst.dueDate instanceof Date ? inst.dueDate.toISOString() : inst.dueDate,
      lateFee: inst.lateFee || 0,
      gracePeriodDays: inst.gracePeriodDays || 0
    }));

    // Create a request for each selected class
    const requests = feeData.classIds.map((classId: any) => {
      const className = this.getClassName(+classId);
      const formattedData: FeeStructureRequest = {
        id: feeData.classIds.length === 1 ? feeData.id : undefined, // Only pass ID if updating a single specific class
        name: `Fee Structure for ${className} (${yearName})`,
        academicYearId: +academicYearId,
        classId: +classId,
        annualFee: tuitionFee, // Backend uses AnnualFee for Tuition
        registrationFee: registrationFee,
        transportFee: transportFee,
        libraryFee: libraryFee,
        computerFee: computerFee,
        examinationFee: examinationFee,
        uniformFee: uniformFee,
        laboratoryFee: laboratoryFee,
        sportsFee: sportsFee,
        miscellaneousFee: miscellaneousFee,
        totalAnnualFee,
        installments: installmentTemplate,
        effectiveDate: new Date().toISOString()
      };
      return this.setupService.createFeeStructure(formattedData);
    });

    forkJoin(requests)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (results: any) => {
          const resArray = results as any[];
          this.snackBar.open(`${resArray.length} fee structures saved successfully`, 'Close', { duration: 3000 });
          
          // Refresh list for the selected year
          this.loadExistingFeeStructure(academicYearId);

          this.markStepComplete('fees');
          this.updateProgress();
          this.isProcessing.set(false);
          this.cdr.markForCheck();
        },
        error: (err) => {
          console.error('Error creating fee structures:', err);
          this.snackBar.open(this.getErrorMessage(err), 'Close', { duration: 5000 });
          this.isProcessing.set(false);
          this.cdr.markForCheck();
        }
      });
  }

  editFeeStructure(fee: any): void {
    console.log('Editing fee structure:', fee);
    const academicYearId = fee.academicYearId || fee.AcademicYearId;
    this.feesForm.patchValue({
      academicYearId: academicYearId
    }, { emitEvent: false }); // Avoid triggering loadExistingFeeStructure while editing

    // Ensure all fee fields are mapped correctly for the dialog
    // We check both camelCase (from previous frontend edit) and PascalCase (from backend)
    // Adding extra defensive fallbacks for each field
    const initialData = {
      ...fee,
      id: fee.id ?? fee.Id,
      academicYearId: academicYearId,
      classId: fee.classId ?? fee.ClassId,
      tuitionFee: fee.tuitionFee ?? fee.AnnualFee ?? fee.annualFee ?? 0,
      registrationFee: fee.registrationFee ?? fee.RegistrationFee ?? fee.registrationFee ?? 0,
      transportFee: fee.transportFee ?? fee.TransportFee ?? fee.transportFee ?? 0,
      libraryFee: fee.libraryFee ?? fee.LibraryFee ?? fee.libraryFee ?? 0,
      computerFee: fee.computerFee ?? fee.ComputerFee ?? fee.computerFee ?? 0,
      examinationFee: fee.examinationFee ?? fee.ExaminationFee ?? fee.examinationFee ?? 0,
      uniformFee: fee.uniformFee ?? fee.UniformFee ?? fee.uniformFee ?? 0,
      laboratoryFee: fee.laboratoryFee ?? fee.LaboratoryFee ?? fee.laboratoryFee ?? 0,
      sportsFee: fee.sportsFee ?? fee.SportsFee ?? fee.sportsFee ?? 0,
      miscellaneousFee: fee.miscellaneousFee ?? fee.MiscellaneousFee ?? fee.miscellaneousFee ?? 0,
      installments: fee.installments || fee.Installments || []
    };

    const dialogRef = this.dialog.open(FeeStructureDialogComponent, {
      ...this.dialogUtils.getMobileConfig({ width: '800px', maxWidth: '90vw' }),
      disableClose: false,
      data: { 
        mode: 'edit', 
        title: 'Edit Fee Structure', 
        initialData: initialData, 
        classes: this.classes(),
        academicYears: this.academicYears()
      }
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.saveFeeStructure(result);
      }
    });
  }

  trackByFeeId(index: number, item: any): number {
    return item.id || item.Id || index;
  }

  getAcademicYearName(id: number | null | undefined): string {
    if (id == null) return 'Unknown';
    // Loose match: rows coming straight from the API may carry string ids    return this.academicYears().find(y => +y.id === +id)?.name || 'Unknown';
  }

  getClassName(id: number | null | undefined): string {
    if (id == null) return 'Unknown';
    // Loose match: rows coming straight from the API may carry string ids.
    // Falls back to the per-year class lists (filteredClassesForSubjects /
    // Sections / selectedClasses) in case the master list hasn't refreshed yet.
    const pool = [
      ...this.classes(),
      ...this.filteredClassesForSubjects(),
      ...this.filteredClassesForSections(),
      ...this.selectedClasses().map(c => ({ id: c.id, name: c.className }))
    ];
    return pool.find(c => c && c.id != null && +c.id === +id)?.name || 'Unknown';
  }

  getTotalFee(element: any): number {
    if (!element) return 0;
    return (
      (element.totalAnnualFee || element.AnnualFee || element.annualFee || 0) +
      (element.registrationFee || element.RegistrationFee || 0) +
      (element.transportFee || element.TransportFee || 0) +
      (element.libraryFee || element.LibraryFee || 0) +
      (element.computerFee || element.ComputerFee || 0) +
      (element.examinationFee || element.ExaminationFee || 0) +
      (element.uniformFee || element.UniformFee || 0) +
      (element.laboratoryFee || element.LaboratoryFee || 0) +
      (element.sportsFee || element.SportsFee || 0) +
      (element.miscellaneousFee || element.MiscellaneousFee || 0)
    );
  }

  savePaymentMethods(): void {
    this.isProcessing.set(true);
    
    // Explicitly structure to match CreatePaymentMethodsRequest DTO
    const request = {
      paymentMethods: [
        { methodName: 'Cash', isActive: true },
        { methodName: 'Online / UPI', isActive: true },
        { methodName: 'Cheque', isActive: true },
        { methodName: 'Bank Transfer', isActive: true }
      ]
    };

    this.setupService.savePaymentMethods(request.paymentMethods)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (result) => {
          this.snackBar.open('Payment methods configured successfully', 'Close', { duration: 3000 });
          this.markStepComplete('payment-methods');
          this.updateProgress();
          this.isProcessing.set(false);
          // Re-sync so the Payment tab immediately reflects the saved state.
          this.loadPaymentMethods();
          this.cdr.markForCheck();
        },
        error: (err) => {
          console.error('Error saving payment methods:', err);
          this.snackBar.open(this.getErrorMessage(err), 'Close', { duration: 5000 });
          this.isProcessing.set(false);
          this.cdr.markForCheck();
        }
      });
  }

  skipOptionalStep(): void {
    const currentStepId = this.setupSteps[this.currentStep]?.id;
    const currentStep = this.setupSteps.find(s => s.id === currentStepId);
    if (currentStep && !currentStep.required) this.stepper.next();
  }

  completeSetup(): void {
    this.isProcessing.set(true);
    this.setupService.markSetupComplete(
      this.setupSteps.map(s => ({ stepId: s.id, completed: s.completed }))
    )
    .pipe(takeUntil(this.destroy$))
    .subscribe({
      next: (result) => {
        this.snackBar.open('Setup completed successfully! Welcome to School Management System', 'Close', { duration: 5000 });
        this.isProcessing.set(false);
        this.cdr.markForCheck();
        setTimeout(() => this.router.navigate(['/app/dashboard']), 2000);
      },
      error: (err) => {
        console.error('Error completing setup:', err);
        this.snackBar.open(this.getErrorMessage(err), 'Close', { duration: 5000 });
        this.isProcessing.set(false);
        this.cdr.markForCheck();
      }
    });
  }

  private markStepComplete(stepId: string): void {
    const step = this.setupSteps.find(s => s.id === stepId);
    if (step) step.completed = true;

    // Keep the app-wide onboarding banner / dashboard card / sidebar badge in
    // sync with the backend after a wizard step saves successfully.
    this.setupStatus.refresh();
  }

  private updateProgress(): void {
    // Progress tracks REQUIRED steps only, matching isAllRequiredStepsComplete().
    // The old formula counted completed + optional steps (6) against required
    // steps (4), so a fully configured school displayed "150% Completed".
    const totalRequired = this.setupSteps.filter(s => s.required).length;
    const completedRequired = this.setupSteps.filter(s => s.required && s.completed).length;
    this.setupProgress = totalRequired === 0 ? 0 : Math.round((completedRequired / totalRequired) * 100);
  }

  getStepIcon(stepId: string): string {
    const step = this.setupSteps.find(s => s.id === stepId);
    return step?.icon || 'info';
  }

  isAllRequiredStepsComplete(): boolean {
    return this.setupSteps.filter(s => s.required).every(s => s.completed);
  }

  onStepChange(event: any): void {
    this.currentStep = event.selectedIndex;
  }
}
