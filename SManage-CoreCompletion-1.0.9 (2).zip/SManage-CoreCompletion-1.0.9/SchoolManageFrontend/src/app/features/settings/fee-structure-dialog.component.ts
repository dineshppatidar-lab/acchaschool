import { ChangeDetectionStrategy, ChangeDetectorRef, Component, Inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule, FormArray } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef, MatDialogModule } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatTabsModule } from '@angular/material/tabs';
import { MatTableModule } from '@angular/material/table';
import { MatCardModule } from '@angular/material/card';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatDividerModule } from '@angular/material/divider';
import { MatSelectModule } from '@angular/material/select';
import { SetupInitializationService } from './setup-initialization.service';
import { AcademicYearContextService } from '../../shared/services/academic-year-context.service';

export interface FeeStructureDialogData {
  mode: 'view' | 'edit' | 'create';
  title?: string;
  initialData?: any;
  classes?: any[];
  academicYears?: any[];
}

@Component({
  selector: 'app-fee-structure-dialog',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatDialogModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule,
    MatProgressSpinnerModule,
    MatSnackBarModule,
    MatTabsModule,
    MatTableModule,
    MatCardModule,
    MatCheckboxModule,
    MatDatepickerModule,
    MatTooltipModule,
    MatNativeDateModule,
    MatDividerModule,
    MatSelectModule
  ],
  templateUrl: './fee-structure-dialog.component.html',
  styleUrls: ['./fee-structure-dialog.component.scss']
})
export class FeeStructureDialogComponent {
  feeStructureForm!: FormGroup;
  isSubmitting = signal(false);
  isLoadingClasses = signal(false);
  mode: 'view' | 'edit' | 'create' = 'create';
  title = 'Fee Structure';
  displayedFeeColumns: string[] = ['label', 'amount'];
  totalAnnualFee = 0;
  
  academicYears: any[] = [];
  filteredClasses = signal<any[]>([]);

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: FeeStructureDialogData,
    private dialogRef: MatDialogRef<FeeStructureDialogComponent>,
    private fb: FormBuilder,
    private snackBar: MatSnackBar,
    private cdr: ChangeDetectorRef,
    private setupService: SetupInitializationService,
    private yearContext: AcademicYearContextService
  ) {
    this.initializeDialog();
  }

  private initializeDialog(): void {
    this.mode = this.data?.mode || 'create';
    this.title = this.data?.title || 'Fee Structure Setup';
    // Use context years if not provided in dialog data
    this.academicYears = this.data?.academicYears || this.yearContext.yearsSnapshot || [];
    console.log('FeeStructureDialog initialized with data:', this.data);
    this.createForm();
    this.setupAcademicYearChangeListener();
  }

  private createForm(): void {
    const initialClassId = this.data?.initialData?.classId || this.data?.initialData?.ClassId;
    const initialAcademicYearId = this.data?.initialData?.academicYearId || this.data?.initialData?.AcademicYearId || '';

    this.feeStructureForm = this.fb.group({
      academicYearId: [initialAcademicYearId, [Validators.required]],
      classIds: [initialClassId ? [+initialClassId] : [], [Validators.required]],
      tuitionFee: [this.data?.initialData?.tuitionFee || this.data?.initialData?.AnnualFee || 0, [Validators.required, Validators.min(0)]],
      registrationFee: [this.data?.initialData?.registrationFee || this.data?.initialData?.RegistrationFee || 0, [Validators.required, Validators.min(0)]],
      transportFee: [this.data?.initialData?.transportFee || this.data?.initialData?.TransportFee || 0, [Validators.required, Validators.min(0)]],
      libraryFee: [this.data?.initialData?.libraryFee || this.data?.initialData?.LibraryFee || 0, [Validators.required, Validators.min(0)]],
      computerFee: [this.data?.initialData?.computerFee || this.data?.initialData?.ComputerFee || 0, [Validators.required, Validators.min(0)]],
      examinationFee: [this.data?.initialData?.examinationFee || this.data?.initialData?.ExaminationFee || 0, [Validators.required, Validators.min(0)]],
      uniformFee: [this.data?.initialData?.uniformFee || this.data?.initialData?.UniformFee || 0, [Validators.required, Validators.min(0)]],
      laboratoryFee: [this.data?.initialData?.laboratoryFee || this.data?.initialData?.LaboratoryFee || 0, [Validators.required, Validators.min(0)]],
      sportsFee: [this.data?.initialData?.sportsFee || this.data?.initialData?.SportsFee || 0, [Validators.required, Validators.min(0)]],
      miscellaneousFee: [this.data?.initialData?.miscellaneousFee || this.data?.initialData?.MiscellaneousFee || 0, [Validators.required, Validators.min(0)]],
      installments: this.fb.array([])
    });

    if (initialAcademicYearId) {
      this.loadClassesForYear(initialAcademicYearId);
    }

    // Load initial installments if available
    const initialInstallments = this.data?.initialData?.installments || this.data?.initialData?.Installments;
    if (initialInstallments && Array.isArray(initialInstallments) && initialInstallments.length > 0) {
      initialInstallments.forEach(inst => {
        this.installmentsArray.push(this.createInstallmentForm(inst));
      });
    } else {
      // Add one default installment if none provided
      this.installmentsArray.push(this.createInstallmentForm());
    }

    // Subscribe to form changes to calculate total
    this.feeStructureForm.valueChanges.subscribe(() => {
      this.calculateTotalFee();
    });

    // Calculate total initially
    this.calculateTotalFee();
  }

  private setupAcademicYearChangeListener(): void {
    this.feeStructureForm.get('academicYearId')?.valueChanges.subscribe(yearId => {
      if (yearId) {
        this.loadClassesForYear(yearId);
      } else {
        this.filteredClasses.set([]);
        this.cdr.markForCheck();
      }
      // Clear selected classes when academic year changes
      this.feeStructureForm.patchValue({ classIds: [] });
    });
  }

  private loadClassesForYear(academicYearId: number | string): void {
    this.isLoadingClasses.set(true);
    this.cdr.markForCheck();

    this.setupService.getClassesByYear(+academicYearId).subscribe({
      next: (response) => {
        const data = response?.data || response;
        if (Array.isArray(data)) {
          this.filteredClasses.set(data.map(c => ({
            id: c.id || c.Id,
            name: c.name || c.Name
          })));
        } else {
          this.filteredClasses.set([]);
        }
        this.isLoadingClasses.set(false);
        this.cdr.markForCheck();
      },
      error: (err) => {
        console.error('Error loading classes for year:', err);
        this.filteredClasses.set([]);
        this.isLoadingClasses.set(false);
        this.cdr.markForCheck();
      }
    });
  }

  private createInstallmentForm(data?: any): FormGroup {
    return this.fb.group({
      name: [data?.name || data?.Name || 'Install. 1', Validators.required],
      amount: [data?.amount || data?.Amount || 0, [Validators.required, Validators.min(0)]],
      dueDate: [data?.dueDate || data?.DueDate || '', Validators.required],
      lateFee: [data?.lateFee || data?.LateFee || 0, [Validators.required, Validators.min(0)]],
      gracePeriodDays: [data?.gracePeriodDays || data?.GracePeriodDays || 0, [Validators.required, Validators.min(0)]]
    });
  }

  get installmentsArray(): FormArray {
    return this.feeStructureForm.get('installments') as FormArray;
  }

  addInstallment(): void {
    const newInstallment = this.createInstallmentForm();
    const index = this.installmentsArray.length + 1;
    newInstallment.patchValue({ name: `Install. ${index}` });
    this.installmentsArray.push(newInstallment);
    this.cdr.markForCheck();
  }

  removeInstallment(index: number): void {
    if (this.installmentsArray.length > 1) {
      this.installmentsArray.removeAt(index);
      this.cdr.markForCheck();
    } else {
      this.snackBar.open('At least one installment is required', 'Close', { duration: 3000 });
    }
  }

  private calculateTotalFee(): void {
    const formValue = this.feeStructureForm.value;
    this.totalAnnualFee = (
      (formValue.tuitionFee || 0) +
      (formValue.registrationFee || 0) +
      (formValue.transportFee || 0) +
      (formValue.libraryFee || 0) +
      (formValue.computerFee || 0) +
      (formValue.examinationFee || 0) +
      (formValue.uniformFee || 0) +
      (formValue.laboratoryFee || 0) +
      (formValue.sportsFee || 0) +
      (formValue.miscellaneousFee || 0)
    );
    this.cdr.markForCheck();
  }

  getFeeStructureData(): any {
    const formValue = this.feeStructureForm.value;
    const classIds = Array.isArray(formValue.classIds) ? formValue.classIds : [formValue.classIds];
    
    return {
      id: this.data?.initialData?.id || this.data?.initialData?.Id,
      academicYearId: formValue.academicYearId,
      classIds: classIds,
      tuitionFee: formValue.tuitionFee || 0,
      registrationFee: formValue.registrationFee || 0,
      transportFee: formValue.transportFee || 0,
      libraryFee: formValue.libraryFee || 0,
      computerFee: formValue.computerFee || 0,
      examinationFee: formValue.examinationFee || 0,
      uniformFee: formValue.uniformFee || 0,
      laboratoryFee: formValue.laboratoryFee || 0,
      sportsFee: formValue.sportsFee || 0,
      miscellaneousFee: formValue.miscellaneousFee || 0,
      installments: formValue.installments || [],
      totalAnnualFee: this.totalAnnualFee
    };
  }

  onSubmit(): void {
    if (this.feeStructureForm.invalid) {
      this.snackBar.open('Please fill all required fields with valid values', 'Close', { duration: 3000 });
      return;
    }

    // Business rule: installments must total exactly the fee amount
    const mismatch = this.getInstallmentMismatch();
    if (this.installmentsArray.length > 0 && mismatch !== 0) {
      const msg = mismatch > 0
        ? `Installment total (₹${this.getInstallmentTotal().toFixed(2)}) exceeds the fee total (₹${this.totalAnnualFee.toFixed(2)}) by ₹${mismatch.toFixed(2)}.`
        : `Installment total (₹${this.getInstallmentTotal().toFixed(2)}) is short of the fee total (₹${this.totalAnnualFee.toFixed(2)}) by ₹${Math.abs(mismatch).toFixed(2)}.`;
      this.snackBar.open(`${msg} Installments must total exactly the fee amount.`, 'Close', { duration: 6000 });
      return;
    }

    if (this.totalAnnualFee <= 0) {
      this.snackBar.open('Total fee amount must be greater than 0', 'Close', { duration: 3000 });
      return;
    }

    this.isSubmitting.set(true);
    const feeData = this.getFeeStructureData();
    console.log('Submitting fee structure data from dialog:', feeData);
    
    setTimeout(() => {
      this.dialogRef.close(feeData);
    }, 500);
  }

  onCancel(): void {
    this.dialogRef.close(null);
  }

  applyStandardTemplate(): void {
    const today = new Date();
    const startDate = new Date(today.getFullYear(), today.getMonth() + 1, 1);

    this.feeStructureForm.patchValue({
      tuitionFee: 24000,
      registrationFee: 2000,
      transportFee: 6000,
      libraryFee: 1000,
      computerFee: 1500,
      examinationFee: 1200,
      uniformFee: 2500,
      laboratoryFee: 1000,
      sportsFee: 500,
      miscellaneousFee: 500
    });

    // Reset and add quarterly installments
    while (this.installmentsArray.length > 0) {
      this.installmentsArray.removeAt(0);
    }

    const quarters = ['Q1 (Apr-Jun)', 'Q2 (Jul-Sep)', 'Q3 (Oct-Dec)', 'Q4 (Jan-Mar)'];
    const totalFee = 40200; // sum of above (24000+2000+6000+1000+1500+1200+2500+1000+500+500)
    const perQuarter = Math.floor(totalFee / 4);

    quarters.forEach((q, i) => {
      const dueDate = new Date(startDate);
      dueDate.setMonth(startDate.getMonth() + (i * 3));
      
      const installmentGroup = this.fb.group({
        name: [q, Validators.required],
        amount: [i === 3 ? totalFee - (perQuarter * 3) : perQuarter, [Validators.required, Validators.min(0)]],
        dueDate: [dueDate, Validators.required],
        lateFee: [100, [Validators.required, Validators.min(0)]],
        gracePeriodDays: [5, [Validators.required, Validators.min(0)]]
      });
      this.installmentsArray.push(installmentGroup);
    });

    this.snackBar.open('Standard fee template applied. You can now adjust amounts.', 'Close', { duration: 3000 });
    this.cdr.markForCheck();
  }

  getInstallmentTotal(): number {
    return this.installmentsArray.controls.reduce((sum, control) => {
      const amount = (control.get('amount')?.value || 0);
      return sum + amount;
    }, 0);
  }

  /** Difference: installments minus total fee (0 = balanced) */
  getInstallmentMismatch(): number {
    return this.getInstallmentTotal() - this.totalAnnualFee;
  }

  isFormValid(): boolean {
    return this.feeStructureForm.valid && this.getInstallmentMismatch() === 0;
  }

  trackByIndex(index: number): number {
    return index;
  }
}
