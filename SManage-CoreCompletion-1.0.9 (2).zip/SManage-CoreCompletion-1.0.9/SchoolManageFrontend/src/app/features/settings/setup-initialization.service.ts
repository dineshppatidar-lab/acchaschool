import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of, throwError } from 'rxjs';
import { catchError, tap, map } from 'rxjs/operators';
import { BaseCrudService } from '../../core/services/base-crud.service';

export interface AcademicYearRequest {
  name: string;
  startDate: Date | string;
  endDate: Date | string;
  isActive: boolean;
  isCurrent: boolean;
}

export interface ClassRequest {
  id?: number;
  className: string;
  classCode: string;
  capacity: number;
  classTeacher?: string;
  academicYearId: number;
}

export interface SectionRequest {
  id?: number;
  name: string;
}

export interface CreateSectionsRequest {
  classId: number;
  sections: SectionRequest[];
}

export interface SubjectRequest {
  id?: number;
  subjectName: string;
  subjectCode: string;
  description?: string;
  creditHours: number;
  classId?: number;
}

export interface PositionRequest {
  name: string;
  code: string;
}

export interface DepartmentRequest {
  name: string;
  code: string;
  positions: PositionRequest[];
}

export interface StaffStructureRequest {
  departments: DepartmentRequest[];
}

export interface FeeStructureRequest {
  id?: number;
  name: string;
  classId: number;
  academicYearId: number;
  annualFee: number;
  registrationFee: number;
  transportFee: number;
  libraryFee: number;
  computerFee: number;
  examinationFee: number;
  uniformFee: number;
  laboratoryFee?: number;
  sportsFee?: number;
  miscellaneousFee?: number;
  effectiveDate?: string;
  installments: Array<{
    name: string;
    amount: number;
    dueDate: Date | string;
    lateFee: number;
    gracePeriodDays: number;
  }>;
  totalAnnualFee: number;
}

export interface PaymentMethodRequest {
  methodName: string;
  methodCode?: string;
  isActive: boolean;
}

export interface SetupStatus {
  stepId: string;
  completed: boolean;
  completedAt?: Date;
}

export interface BackendSetupStep {
  stepNumber: number;
  title: string;
  completed: boolean;
  description: string;
  isRequired: boolean;
}

export interface SetupChecklistResult {
  steps: BackendSetupStep[];
  completedSteps: number;
  totalSteps: number;
  progressPercentage: number;
}

@Injectable({
  providedIn: 'root'
})
export class SetupInitializationService {
  private apiBaseUrl = 'api';
  private setupCompletionKey = 'schoolMgmt_setupCompleted';
  private setupStatusKey = 'schoolMgmt_setupStatus';

  constructor(
    private http: HttpClient
  ) {}

  /**
   * Update existing academic year
   */
  updateAcademicYear(id: number, data: AcademicYearRequest): Observable<any> {
    return this.http.put(`${this.apiBaseUrl}/setup/academic-years/${id}`, data).pipe(
      tap(response => console.info('Academic year updated:', response)),
      catchError(error => {
        console.error('Error updating academic year:', error);
        return throwError(() => error);
      })
    );
  }

  /**
   * Create academic year for initial setup
   */
  createAcademicYear(data: AcademicYearRequest): Observable<any> {
    return this.http.post(`${this.apiBaseUrl}/setup/academic-years`, data).pipe(
      tap(response => console.info('Academic year created:', response)),
      catchError(error => {
        console.error('Error creating academic year:', error);
        return throwError(() => error);
      })
    );
  }

  /**
   * Create class/section for initial setup
   */
  createClass(data: ClassRequest | ClassRequest[]): Observable<any> {
    const classes = Array.isArray(data) ? data : [data];
    const payload = {
      academicYearId: classes[0]?.academicYearId || 0,
      classes: classes.map(c => ({
        id: c.id,
        name: c.className,
        code: c.classCode,
        capacity: c.capacity
      }))
    };
    return this.http.post(`${this.apiBaseUrl}/setup/classes`, payload).pipe(
      tap(response => console.info('Classes created:', response)),
      catchError(error => {
        console.error('Error creating classes:', error);
        return throwError(() => error);
      })
    );
  }

  /**
   * Create section for initial setup
   */
  createSections(data: CreateSectionsRequest): Observable<any> {
    return this.http.post(`${this.apiBaseUrl}/setup/sections`, data).pipe(
      tap(response => console.info('Sections created:', response)),
      catchError(error => {
        console.error('Error creating sections:', error);
        return throwError(() => error);
      })
    );
  }

  /**
   * Get sections for a class
   */
  getSectionsByClass(classId: number): Observable<any> {
    return this.http.get<any>(`${this.apiBaseUrl}/setup/classes/${classId}/sections`).pipe(
      catchError(error => {
        console.error('Error fetching sections:', error);
        return throwError(() => error);
      })
    );
  }

  /**
   * Create subject for initial setup
   */
  createSubject(data: SubjectRequest | SubjectRequest[]): Observable<any> {
    const subjects = Array.isArray(data) ? data : [data];
    const payload = {
      classId: subjects[0]?.classId || 1, // Default to class 1 if not specified
      subjects: subjects.map(s => ({
        id: s.id,
        name: s.subjectName,
        code: s.subjectCode,
        creditHours: s.creditHours
      }))
    };
    return this.http.post(`${this.apiBaseUrl}/setup/subjects`, payload).pipe(
      tap(response => console.info('Subjects created:', response)),
      catchError(error => {
        console.error('Error creating subjects:', error);
        return throwError(() => error);
      })
    );
  }

  /**
   * Create staff structure (departments and positions) for initial setup
   */
  createStaffStructure(data: StaffStructureRequest): Observable<any> {
    return this.http.post(`${this.apiBaseUrl}/setup/staff-structure/setup`, data).pipe(
      tap(response => console.info('Staff structure created:', response)),
      catchError(error => {
        console.error('Error creating staff structure:', error);
        return throwError(() => error);
      })
    );
  }

  /**
   * Create one staff-structure entry (department or position) via the DB-backed
   * lookup CRUD shared with the Departments/Designations admin screens.
   * lookupType: 'staff-departments' | 'staff-positions'
   */
  createStaffStructureLookup(lookupType: string, label: string): Observable<any> {
    return this.http.post(`${this.apiBaseUrl}/setup/staff-structure/lookup`, { lookupType, label }).pipe(
      tap(response => console.info('Staff structure entry created:', response)),
      catchError(error => {
        console.error('Error creating staff structure entry:', error);
        return throwError(() => error);
      })
    );
  }

  /**
   * Rename a saved staff-structure entry (department or position).
   * lookupType: 'staff-departments' | 'staff-positions'
   */
  renameStaffStructureLookup(id: number, lookupType: string, label: string): Observable<any> {
    return this.http.put(`${this.apiBaseUrl}/setup/staff-structure/lookup/${id}`, { lookupType, label }).pipe(
      tap(response => console.info('Staff structure entry renamed:', response)),
      catchError(error => {
        console.error('Error renaming staff structure entry:', error);
        return throwError(() => error);
      })
    );
  }

  /**
   * Delete (soft) a saved staff-structure entry (department or position).
   * lookupType: 'staff-departments' | 'staff-positions'
   */
  deleteStaffStructureLookup(id: number, lookupType: string): Observable<any> {
    const params = { lookupType };
    return this.http.delete(`${this.apiBaseUrl}/setup/staff-structure/lookup/${id}`, { params }).pipe(
      tap(response => console.info('Staff structure entry deleted:', response)),
      catchError(error => {
        console.error('Error deleting staff structure entry:', error);
        return throwError(() => error);
      })
    );
  }

  /**
   * Create fee structure for initial setup
   */
  createFeeStructure(data: FeeStructureRequest): Observable<any> {
    return this.http.post(`${this.apiBaseUrl}/setup/fees/structure/setup`, data).pipe(
      tap(response => console.info('Fee structure created:', response)),
      catchError(error => {
        console.error('Error creating fee structure:', error);
        return throwError(() => error);
      })
    );
  }

  /**
   * Save payment methods configuration
   */
  savePaymentMethods(methods: PaymentMethodRequest[]): Observable<any> {
    return this.http.post(`${this.apiBaseUrl}/setup/payment-methods/setup`, { paymentMethods: methods }).pipe(
      tap(response => console.info('Payment methods saved:', response)),
      catchError(error => {
        console.error('Error saving payment methods:', error);
        return throwError(() => error);
      })
    );
  }

  /**
   * Mark setup as complete
   */
  markSetupComplete(setupStatus: SetupStatus[]): Observable<any> {
    return this.http.post(`${this.apiBaseUrl}/setup/complete`, { 
      status: setupStatus,
      completedAt: new Date()
    }).pipe(
      tap(response => {
        console.info('Setup marked as complete:', response);
        // Store completion status in local storage
        localStorage.setItem(this.setupCompletionKey, JSON.stringify({
          completed: true,
          completedAt: new Date(),
          steps: setupStatus
        }));
      }),
      catchError(error => {
        console.error('Error marking setup complete:', error);
        return throwError(() => error);
      })
    );
  }

  /**
   * Check if setup has been completed before
   */
  isSetupCompleted(): boolean {
    const stored = localStorage.getItem(this.setupCompletionKey);
    if (!stored) return false;
    
    try {
      const parsed = JSON.parse(stored);
      return parsed.completed === true;
    } catch {
      return false;
    }
  }

  /**
   * Get setup completion status
   */
  getSetupStatus(): SetupStatus[] {
    const stored = localStorage.getItem(this.setupStatusKey);
    if (!stored) return [];

    try {
      return JSON.parse(stored);
    } catch {
      return [];
    }
  }

  /**
   * Reset setup for demo/testing purposes
   */
  resetSetup(): void {
    localStorage.removeItem(this.setupCompletionKey);
    localStorage.removeItem(this.setupStatusKey);
  }

  /**
   * Get setup progress percentage
   */
  getSetupProgress(): number {
    const status = this.getSetupStatus();
    if (status.length === 0) return 0;

    const completed = status.filter(s => s.completed).length;
    return Math.round((completed / status.length) * 100);
  }

  /**
   * Validate setup requirements (minimum data needed)
   */
  validateMinimumSetup(): Observable<{ isValid: boolean; missingItems: string[] }> {
    return this.http.get<{ isValid: boolean; missingItems: string[] }>(
      `${this.apiBaseUrl}/setup/validate`
    ).pipe(
      catchError(error => {
        console.error('Error validating setup:', error);
        return of({ isValid: false, missingItems: [] });
      })
    );
  }

  /**
   * Get setup checklist with current status from server
   * NOTE: the global apiResponseInterceptor already unwraps ApiResponse envelopes,
   * so this returns the checklist result directly. Accessing response.data here
   * would yield undefined and silently break the progress markers.
   */
  getSetupChecklist(): Observable<SetupChecklistResult> {
    return this.http.get<any>(`${this.apiBaseUrl}/setup/checklist`).pipe(
      map(response => (response?.data !== undefined ? (response.data as SetupChecklistResult) : (response as SetupChecklistResult))),
      catchError(error => {
        console.error('Error getting setup checklist:', error);
        return throwError(() => error);
      })
    );
  }

  /**
   * Get existing staff records for the current tenant (Setup Wizard Staff tab)
   */
  getStaff(): Observable<any[]> {
    return this.http.get<any>(`${this.apiBaseUrl}/setup/staff`).pipe(
      map(response => {
        const data = response?.data ?? response;
        return Array.isArray(data) ? data : [];
      }),
      catchError(error => {
        console.error('Error fetching staff:', error);
        return of([]);
      })
    );
  }

  /**
   * Get payment methods configured in the database for the current tenant
   * (Setup Wizard Payment tab)
   */
  getPaymentMethods(): Observable<any[]> {
    return this.http.get<any>(`${this.apiBaseUrl}/setup/payment-methods`).pipe(
      map(response => {
        const data = response?.data ?? response;
        return Array.isArray(data) ? data : [];
      }),
      catchError(error => {
        console.error('Error fetching payment methods:', error);
        return of([]);
      })
    );
  }

  /**
   * Get existing fee structures for a given academic year and class
   */
  getFeeStructures(academicYearId?: number, classId?: number): Observable<any> {
    const params: any = {};
    if (academicYearId) params.academicYearId = academicYearId;
    if (classId) params.classId = classId;
    return this.http.get<any>(`${this.apiBaseUrl}/advancedfinance/fee-structures`, { params }).pipe(
      catchError(error => {
        console.error('Error fetching fee structures:', error);
        return throwError(() => error);
      })
    );
  }

  /**
   * Get existing subjects for a given class
   */
  getSubjectsByClass(classId: number): Observable<any> {
    return this.http.get<any>(`${this.apiBaseUrl}/setup/classes/${classId}/subjects`).pipe(
      catchError(error => {
        console.error('Error fetching subjects by class:', error);
        return throwError(() => error);
      })
    );
  }

  /**
   * Get existing classes for a given academic year
   */
  getClassesByYear(academicYearId: number): Observable<any> {
    return this.http.get<any>(`${this.apiBaseUrl}/setup/academic-years/${academicYearId}/classes`).pipe(
      catchError(error => {
        console.error('Error fetching classes by year:', error);
        return throwError(() => error);
      })
    );
  }

  /**
   * Export setup configuration for backup
   */
  exportSetupConfig(): Observable<Blob> {
    return this.http.get(`${this.apiBaseUrl}/setup/export`, {
      responseType: 'blob'
    }).pipe(
      catchError(error => {
        console.error('Error exporting setup:', error);
        return of(new Blob());
      })
    );
  }

  /**
   * Get available academic years
   */
  getAvailableAcademicYears(): Observable<any[]> {
    return this.http.get<any>(`${this.apiBaseUrl}/setup/academic-years`).pipe(
      map(response => response?.data || response),
      catchError(error => {
        console.error('Error fetching academic years:', error);
        return of([]);
      })
    );
  }

  /**
   * Batch create initial master data (for quick setup)
   */
  quickSetup(config: {
    academicYear?: AcademicYearRequest;
    classes?: ClassRequest[];
    subjects?: SubjectRequest[];
    staffStructure?: StaffStructureRequest;
    feeStructure?: FeeStructureRequest;
    paymentMethods?: PaymentMethodRequest[];
  }): Observable<any> {
    // No catchError fallback here: surfacing the real error matters more than
    // hiding it. Previously a failed POST was replaced by a fake
    // "Quick setup completed" success (#4), so schools could finish the wizard
    // with nothing actually saved.
    return this.http.post(`${this.apiBaseUrl}/setup/quick-setup`, config);
  }
}
