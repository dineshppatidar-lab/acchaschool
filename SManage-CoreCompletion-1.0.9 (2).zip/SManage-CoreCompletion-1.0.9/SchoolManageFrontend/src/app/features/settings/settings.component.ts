import { ChangeDetectorRef, Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatTabsModule } from '@angular/material/tabs';
import { MatDividerModule } from '@angular/material/divider';
import { MatChipsModule } from '@angular/material/chips';
import { MatDialogModule } from '@angular/material/dialog';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { UserManagementService } from '../user-management/user-management.service';
import { TenantService, TenantDto } from '../../services/tenant.service';
import { ThemeService } from '../../shared/services/theme.service';
import { User } from '../user-management/user.model';
import { PermissionLabels, Permission } from '../../core/models/permission.model';
import { CanWriteDirective } from '../../core/directives/permission.directive';

interface UserPreferences {
  theme: string;
  language: string;
  notifications: {
    email: boolean;
    push: boolean;
    sms: boolean;
  };
  privacy: {
    profileVisible: boolean;
    showEmail: boolean;
    showPhone: boolean;
  };
  dashboard: {
    defaultView: string;
    autoRefresh: boolean;
    refreshInterval: number;
  };
}

interface PermissionGroup {
  name: string;
  permissions: string[];
}

@Component({
  selector: 'app-settings',
  standalone: true,
  imports: [
    CommonModule,
    MatCardModule,
    MatButtonModule,
    MatIconModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatSlideToggleModule,
    MatTabsModule,
    MatDividerModule,
    MatChipsModule,
    MatDialogModule,
    MatSnackBarModule,
    MatProgressSpinnerModule,
    FormsModule,
    ReactiveFormsModule,
    CanWriteDirective
  ],
  templateUrl: './settings.component.html',
  styleUrls: ['./settings.component.scss']
})
export class SettingsComponent implements OnInit {
  Permission = Permission;
  
  currentUser: any = {
    id: 0,
    username: 'Loading...',
    email: '',
    firstName: '',
    lastName: '',
    roles: '',
    isActive: true,
    lastLogin: new Date(),
    permissions: [],
    recentLogins: []
  };

  currentTenant = signal<any>(null);
  isLoading = signal(true);
  isSaving = signal(false);
  permissionGroups: PermissionGroup[] = [];

  userPreferences: UserPreferences = {
    theme: 'light',
    language: 'en',
    notifications: {
      email: true,
      push: true,
      sms: false
    },
    privacy: {
      profileVisible: true,
      showEmail: false,
      showPhone: false
    },
    dashboard: {
      defaultView: 'overview',
      autoRefresh: true,
      refreshInterval: 30
    }
  };

  isEditing = signal(false);
  
  themes = [
    { value: 'light', label: 'Light Theme' },
    { value: 'dark', label: 'Dark Theme' },
    { value: 'auto', label: 'Auto (System)' }
  ];

  languages = [
    { value: 'en', label: 'English' },
    { value: 'es', label: 'Spanish' },
    { value: 'fr', label: 'French' },
    { value: 'de', label: 'German' }
  ];

  refreshIntervals = [
    { value: 10, label: '10 seconds' },
    { value: 30, label: '30 seconds' },
    { value: 60, label: '1 minute' },
    { value: 300, label: '5 minutes' },
    { value: 600, label: '10 minutes' }
  ];

  constructor(
    private router: Router, 
    private userService: UserManagementService,
    private tenantService: TenantService,
    private snackBar: MatSnackBar,
    private cdr: ChangeDetectorRef,
    private themeService: ThemeService
  ) {}

  ngOnInit(): void {
    this.loadUserData();
    this.loadPreferences();
  }

  loadUserData(): void {
    this.isLoading.set(true);
    this.userService.getProfile().subscribe({
      next: (user) => {
        if (user) {
          this.currentUser = {
            ...user,
            lastLogin: user.lastLogin ? new Date(user.lastLogin) : new Date(),
            createdAt: user.createdAt ? new Date(user.createdAt) : undefined,
            recentLogins: user.recentLogins || []
          };
          this.groupPermissions();
          this.loadTenantData();
        } else {
          this.isLoading.set(false);
        }
        this.cdr.markForCheck();
      },
      error: (err) => {
        console.error('Error loading profile:', err);
        this.isLoading.set(false);
        this.snackBar.open('Failed to load profile data. Please try again.', 'Close', { duration: 4000 });
        this.cdr.markForCheck();
      }
    });
  }

  private groupPermissions(): void {
    if (!this.currentUser.permissions || !Array.isArray(this.currentUser.permissions)) {
      this.permissionGroups = [];
      return;
    }

    const groups: { [key: string]: string[] } = {};
    
    this.currentUser.permissions.forEach((p: string) => {
      let category = 'General';
      if (p.startsWith('Users')) category = 'User Management';
      else if (p.startsWith('Students')) category = 'Student Management';
      else if (p.startsWith('Staff')) category = 'Staff Management';
      else if (p.startsWith('Classes') || p.startsWith('Subjects') || p.startsWith('Timetables')) category = 'Academic';
      else if (p.startsWith('Exams') || p.startsWith('Results')) category = 'Examinations';
      else if (p.startsWith('Fees') || p.startsWith('Payments')) category = 'Finance';
      else if (p.startsWith('System')) category = 'System';
      else if (p.startsWith('Reports') || p.startsWith('Analytics') || p.startsWith('Dashboard')) category = 'Analytics';
      
      if (!groups[category]) groups[category] = [];
      groups[category].push(p);
    });

    this.permissionGroups = Object.keys(groups).map(name => ({
      name,
      permissions: groups[name]
    }));
  }

  getPermissionLabel(p: string): string {
    // Try to find label in PermissionLabels enum mapping if it exists as a string key
    // Since we receive string names from backend, we might need a direct mapping or use the string as is
    return p.replace(/([A-Z])/g, ' $1').trim();
  }

  loadTenantData(): void {
    this.tenantService.getAllTenants().subscribe({
      next: (res) => {
        const tenants = res?.data || res;
        if (Array.isArray(tenants) && tenants.length > 0) {
          // If we're not a SuperAdmin, we only get one tenant anyway.
          // If we are, we show the first one (primary context).
          this.currentTenant.set(tenants[0]);
        }
        this.isLoading.set(false);
        this.cdr.markForCheck();
      },
      error: (err) => {
        console.error('Error loading tenant data:', err);
        this.isLoading.set(false);
        this.cdr.markForCheck();
      }
    });
  }

  loadPreferences(): void {
    const saved = localStorage.getItem('userPreferences');
    if (saved) {
      try {
        this.userPreferences = JSON.parse(saved);
      } catch (e) {
        console.warn('Failed to parse saved preferences');
      }
    }
    // Keep the Appearance select in sync with the actually active theme
    // (single source of truth is ThemeService, not the stored preference).
    this.userPreferences.theme = this.themeService.currentTheme;
  }

  toggleEdit(): void {
    if (this.isEditing()) {
      this.saveProfile();
    } else {
      this.isEditing.set(true);
    }
  }

  saveProfile(): void {
    this.isSaving.set(true);
    this.userService.updateProfile(this.currentUser).subscribe({
      next: (user) => {
        this.currentUser = user;
        this.isEditing.set(false);
        this.isSaving.set(false);
        this.snackBar.open('Profile updated successfully', 'Close', { duration: 3000 });
        this.cdr.markForCheck();
      },
      error: (err) => {
        this.isSaving.set(false);
        const msg = err?.error?.message || 'Failed to update profile';
        this.snackBar.open(msg, 'Close', { duration: 3000 });
        this.cdr.markForCheck();
      }
    });
  }

  savePreferences(): void {
    localStorage.setItem('userPreferences', JSON.stringify(this.userPreferences));
    // Apply the appearance choice through the app-wide ThemeService so the
    // whole UI (including overlays) switches without a reload.
    const theme = this.userPreferences.theme;
    if (theme === 'auto') {
      const prefersDark = window.matchMedia?.('(prefers-color-scheme: dark)').matches;
      this.themeService.setTheme(prefersDark ? 'dark' : 'light');
    } else {
      this.themeService.setTheme(theme === 'dark' ? 'dark' : 'light');
    }
    this.snackBar.open('Preferences saved', 'Close', { duration: 2000 });
  }

  changePassword(): void {
    // For now just toggle edit so user can enter new password if provided
    this.isEditing.set(true);
    this.snackBar.open('Please enter your new password in the Personal Details section', 'OK', { duration: 4000 });
  }

  exportData(): void {
    const data = JSON.stringify({
      user: this.currentUser,
      tenant: this.currentTenant(),
      preferences: this.userPreferences
    }, null, 2);
    
    const blob = new Blob([data], { type: 'application/json' });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `school-manage-profile-${this.currentUser.username}.json`;
    link.click();
    window.URL.revokeObjectURL(url);
    this.snackBar.open('Data exported successfully', 'Close', { duration: 3000 });
  }

  deleteAccount(): void {
    if (confirm('Are you sure you want to delete your account? This action cannot be undone.')) {
      this.snackBar.open('Account deletion is restricted to system administrators', 'Close', { duration: 5000 });
    }
  }

  goBack(): void {
    this.router.navigate(['/app/dashboard']);
  }

  getRoleColor(role: string): string {
    const roleColors: {[key: string]: string} = {
      'administrator': 'warn',
      'teacher': 'primary',
      'student': 'accent',
      'parent': 'basic',
      'superadmin': 'warn'
    };
    return roleColors[role.toLowerCase()] || 'primary';
  }

  getRoleIcon(role: string): string {
    const r = (role || '').trim().toLowerCase();
    if (r === 'administrator' || r === 'superadmin') return 'admin_panel_settings';
    if (r === 'teacher') return 'school';
    if (r === 'student') return 'person';
    if (r === 'parent') return 'family_restroom';
    return 'person';
  }

  getPermissionIcon(permission: string): string {
    const permissionIcons: {[key: string]: string} = {
      'UsersView': 'people',
      'DashboardView': 'dashboard',
      'SystemManage': 'admin_panel_settings',
      'FeesView': 'monetization_on',
      'StudentsView': 'school'
    };
    return permissionIcons[permission] || 'check_circle';
  }
}