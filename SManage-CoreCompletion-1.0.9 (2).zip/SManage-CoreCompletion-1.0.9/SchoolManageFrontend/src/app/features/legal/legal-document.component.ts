import { Component, OnDestroy, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, NavigationEnd, Router, RouterModule } from '@angular/router';
import { MatIconModule } from '@angular/material/icon';
import { filter } from 'rxjs';

export interface LegalSection {
  heading: string;
  body: string[];
}

export interface LegalDoc {
  title: string;
  updated: string;
  intro: string;
  sections: LegalSection[];
}

@Component({
  selector: 'app-legal-document',
  standalone: true,
  imports: [CommonModule, RouterModule, MatIconModule],
  templateUrl: './legal-document.component.html',
  styleUrls: ['./legal-document.component.scss']
})
export class LegalDocumentComponent implements OnInit, OnDestroy {
  doc!: LegalDoc;
  backLink = '/register-tenant';

  readonly docs: Record<'terms' | 'privacy', LegalDoc> = {
    terms: {
      title: 'Terms & Conditions',
      updated: 'October 2026',
      intro: 'These Terms & Conditions govern your use of the AcchaSchool school management platform. By creating a school or using the service, you agree to them.',
      sections: [
        {
          heading: '1. About the Service',
          body: [
            'AcchaSchool is a multi-tenant school management platform. Each school (also called a "tenant") gets its own isolated workspace identified by a unique School Code.',
            'The service lets administrators, staff and parents manage academic information, students, staff, attendance, fees and other school operations.'
          ]
        },
        {
          heading: '2. Your Account & Credentials',
          body: [
            'When you register a school you receive a School Code and create an administrator account. The School Code plus your username and password are required to sign in.',
            'You are responsible for keeping your credentials confidential and for all activity that happens under your administrator account.',
            'Administrators are responsible for the staff, student and parent accounts they create within their school.'
          ]
        },
        {
          heading: '3. Acceptable Use',
          body: [
            'You agree to use the service only for lawful purposes of running a school, and not to attempt to access other tenants\' data, disrupt the service, or use it to process unlawful content.',
            'You must have the proper rights before uploading any student, staff or parent information into the platform.'
          ]
        },
        {
          heading: '4. Plans, Fees & Free Tier',
          body: [
            'A school may be used free of charge within the limits of the current free tier (for example, up to the advertised number of active students).',
            'If a paid plan applies and a subscription expires or remains unpaid, access to premium features may be reduced or the school workspace deactivated after prior notice.',
          ]
        },
        {
          heading: '5. Your Data',
          body: [
            'You retain ownership of all data your school enters into the platform. We use it only to operate and support the service for your school.',
            'On request we can export your school\'s data, and when a school is permanently closed we delete its data as described in the Privacy Policy.'
          ]
        },
        {
          heading: '6. Availability & Changes',
          body: [
            'We aim for the service to be continuously available, but scheduled maintenance, service interruptions and feature changes may occur. We will communicate significant changes or planned downtime in the app or by email.',
            'These terms may be updated from time to time; continued use of the service after an update means you accept the revised terms.'
          ]
        },
        {
          heading: '7. Limitation of Liability',
          body: [
            'To the extent permitted by law, AcchaSchool is provided "as is" without warranties of uninterrupted availability, and our liability for any claims connected to the service is limited to the fees (if any) paid by your school in the preceding 12 months.'
          ]
        },
        {
          heading: '8. Contact',
          body: [
            'Questions about these terms can be sent to support@acchaschool.com.'
          ]
        }
      ]
    },
    privacy: {
      title: 'Privacy Policy',
      updated: 'October 2026',
      intro: 'This Privacy Policy describes how AcchaSchool handles personal data that is stored or processed through our school management platform.',
      sections: [
        {
          heading: '1. Data We Process',
          body: [
            'School data: information your school enters about itself — name, contact details, academic setup, fee structures and similar operational information.',
            'Personal data: records about students, staff, parents/guardians that your school chooses to store, such as names, enrolment/roll numbers, class and section, contact details and fees, attendance and examination results.',
            'Account data: data needed to operate accounts — school codes, usernames, email addresses, hashed passwords, roles and permissions.',
            'Usage data: technical logs such as device, browser and activity information needed to keep the service secure and reliable.'
          ]
        },
        {
          heading: '2. How We Use Data',
          body: [
            'To operate the platform for your school — displaying and calculating the features your school uses (students, fees, attendance, examinations, notifications).',
            'To administer accounts, authentication and access control.',
            'To provide support and communicate service updates.',
            'We do not sell personal data, and we do not use student data for advertising or profiling.'
          ]
        },
        {
          heading: '3. Cookies & Local Storage',
          body: [
            'The platform uses browser storage (such as localStorage and session cookies) to keep you signed in and remember preferences like the selected academic year. These are strictly functional and required for the service to work.'
          ]
        },
        {
          heading: '4. Sharing of Data',
          body: [
            'Data is visible only within your school\'s tenant, according to the roles and permissions your school\'s administrators assign.',
            'We share data with service providers only where needed to run parts of the service (for example hosting or email delivery), under obligations that protect the data, and with regulators or law enforcement only when legally required.'
          ]
        },
        {
          heading: '5. Children\'s Data',
          body: [
            'Student records often relate to minors. Our service is designed so that a school (the educational institution) controls the collection and use of student data and obtains any necessary consent from parents/guardians. We process student data solely on the school\'s instructions for educational purposes.'
          ]
        },
        {
          heading: '6. Security',
          body: [
            'We protect data in transit using encryption, store passwords only in hashed form, enforce per-tenant isolation, and apply access control so that accounts only reach the data their permissions allow.',
            'No system is perfectly secure; if a data incident ever affects your school, we will inform you and help with any required notifications.'
          ]
        },
        {
          heading: '7. Retention & Deletion',
          body: [
            'Your school\'s data is retained while the school workspace is active. When a school signs up and later requests deletion, or an account is removed, we delete or anonymize the corresponding data within a reasonable operational window, except where law requires a longer retention.'
          ]
        },
        {
          heading: '8. Your Rights',
          body: [
            'Depending on your jurisdiction, you may have rights to access, correct, export or delete personal data, and to object to or restrict certain processing.',
            'Administrators of a school can exercise most of these rights inside the platform for their school\'s records. For anything else — or if you are a parent/student with a request — contact us at support@acchaschool.com or through your school\'s administrators.'
          ]
        },
        {
          heading: '9. Contact',
          body: [
            'Questions about this policy or how your data is handled can be sent to support@acchaschool.com.'
          ]
        }
      ]
    }
  };

  constructor(private route: ActivatedRoute, private router: Router) {}

  ngOnInit(): void {
    // Same component serves both /terms and /privacy — re-render on route change.
    this.setDocFromRoute();
    this.router.events
      .pipe(filter((e): e is NavigationEnd => e instanceof NavigationEnd))
      .subscribe(() => this.setDocFromRoute());
  }

  ngOnDestroy(): void {
    document.title = 'AcchaSchool';
  }

  private setDocFromRoute(): void {
    const which = this.route.snapshot.data['doc'] === 'privacy' ? 'privacy' : 'terms';
    this.doc = this.docs[which];
    document.title = `${this.doc.title} — AcchaSchool`;
  }
}
