import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnInit, signal } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { TransportService, Vehicle } from '../../services/transport.service';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { CommonModule } from '@angular/common';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatSelectModule } from '@angular/material/select';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSnackBarModule, MatSnackBar } from '@angular/material/snack-bar';
import { MatDividerModule } from '@angular/material/divider';
import { MatChipsModule } from '@angular/material/chips';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatStepperModule } from '@angular/material/stepper';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { PageHeaderComponent } from '../../shared/components/page-patterns/index';

@Component({
  selector: 'app-transport-form',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    CommonModule, 
    ReactiveFormsModule, 
    MatFormFieldModule, 
    MatInputModule, 
    MatButtonModule, 
    MatCardModule,
    MatIconModule,
    MatSelectModule,
    MatProgressSpinnerModule,
    MatSnackBarModule,
    MatDividerModule,
    MatChipsModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatStepperModule,
    RouterModule,
    PageHeaderComponent
  ],
  templateUrl: './transport-form.component.html',
  styleUrls: ['./transport-form.component.scss']
})
export class TransportFormComponent implements OnInit {
  transportForm: FormGroup;
  success = signal<any>(null);
  error = signal<any>(null);
  loading = signal(false);
  isEditMode = signal(false);
  vehicleId = signal<any>(null);
  availableRoutes = signal<any[]>([]);

  vehicleTypes = [
    { value: 'bus', label: 'School Bus', icon: 'directions_bus', capacity: 50 },
    { value: 'van', label: 'Van', icon: 'airport_shuttle', capacity: 15 },
    { value: 'car', label: 'Car', icon: 'directions_car', capacity: 4 },
    { value: 'minibus', label: 'Mini Bus', icon: 'commute', capacity: 25 }
  ];

  vehicleStatuses = [
    { value: 'active', label: 'Active', icon: 'check_circle', color: 'var(--md-success)' },
    { value: 'maintenance', label: 'Under Maintenance', icon: 'build', color: 'var(--md-warning)' },
    { value: 'inactive', label: 'Inactive', icon: 'cancel', color: 'var(--md-error)' },
    { value: 'reserved', label: 'Reserved', icon: 'schedule', color: 'var(--md-primary-light)' }
  ];

  fuelTypes = [
    { value: 'petrol', label: 'Petrol', icon: 'local_gas_station' },
    { value: 'diesel', label: 'Diesel', icon: 'local_gas_station' },
    { value: 'cng', label: 'CNG', icon: 'eco' },
    { value: 'electric', label: 'Electric', icon: 'electric_car' }
  ];

  constructor(
    private fb: FormBuilder, 
    private transportService: TransportService,
    private snackBar: MatSnackBar,
    private cdr: ChangeDetectorRef,
    private route: ActivatedRoute,
    private router: Router,
    private http: HttpClient
  ) {
    this.transportForm = this.fb.group({
      vehicleNumber: ['', [Validators.required]],
      vehicleType: [''],
      model: ['', [Validators.required, Validators.minLength(2)]],
      manufacturer: [''],
      capacity: [0, [Validators.required, Validators.min(1), Validators.max(100)]],
      status: ['active', Validators.required],
      driverName: [''],
      driverContact: ['', [Validators.pattern(/^[0-9]{10}$/)]],
      driverLicense: [''],
      fuelType: [''],
      purchaseDate: [null],
      insuranceExpiry: [null],
      fitnessExpiry: [null],
      route: [''],
      description: ['']
    });
  }

  ngOnInit() {
    // Set default insurance and fitness expiry dates
    const defaultInsuranceExpiry = new Date();
    defaultInsuranceExpiry.setFullYear(defaultInsuranceExpiry.getFullYear() + 1);
    
    const defaultFitnessExpiry = new Date();
    defaultFitnessExpiry.setFullYear(defaultFitnessExpiry.getFullYear() + 1);
    
    this.transportForm.patchValue({ 
      insuranceExpiry: defaultInsuranceExpiry,
      fitnessExpiry: defaultFitnessExpiry
    });

    this.route.paramMap.subscribe(params => {
      const id = params.get('id');
      if (id) {
        this.isEditMode.set(true);
        this.vehicleId.set(+id);
        this.loadVehicle(this.vehicleId());
      }
    });

    this.loadAvailableRoutes();
  }

  loadVehicle(id: number) {
    this.loading.set(true);
    this.cdr.markForCheck();
    this.transportService.getVehicleById(id).subscribe({
      next: (vehicle) => {
        this.transportForm.patchValue({
          ...vehicle,
          route: vehicle.routeId || ''
        });
        this.loading.set(false);
        this.cdr.markForCheck();
      },
      error: (err) => {
        this.error.set('Failed to load vehicle details.');
        this.loading.set(false);
        this.cdr.markForCheck();
      }
    });
  }

  loadAvailableRoutes() {
    this.transportService.getRoutes().subscribe({
      next: (routes) => {
        this.availableRoutes.set(routes || []);
        this.cdr.markForCheck();
      },
      error: (err) => console.error('Failed to load routes', err)
    });
  }

  onVehicleTypeChange() {
    const selectedType = this.transportForm.get('vehicleType')?.value;
    const vehicleTypeInfo = this.vehicleTypes.find(type => type.value === selectedType);
    
    if (vehicleTypeInfo) {
      this.transportForm.patchValue({ capacity: vehicleTypeInfo.capacity });
    }
  }

  onSubmit() {
    if (this.transportForm.invalid) {
      this.markFormGroupTouched();
      return;
    }

    this.loading.set(true);
    this.error.set(null);
    this.success.set(null);
    this.cdr.markForCheck();

    const formValue = this.transportForm.value;
    const vehicleData: Vehicle = {
      vehicleNumber: formValue.vehicleNumber,
      model: formValue.model,
      capacity: Number(formValue.capacity),
      status: formValue.status,
      vehicleType: formValue.vehicleType,
      manufacturer: formValue.manufacturer,
      driverName: formValue.driverName,
      driverContact: formValue.driverContact,
      driverLicense: formValue.driverLicense,
      fuelType: formValue.fuelType,
      purchaseDate: formValue.purchaseDate,
      insuranceExpiry: formValue.insuranceExpiry,
      fitnessExpiry: formValue.fitnessExpiry,
      description: formValue.description,
      routeId: formValue.route ? Number(formValue.route) : undefined
    };
    
    if (this.isEditMode() && this.vehicleId()) {
      vehicleData.id = this.vehicleId();
    }

    const request$: Observable<any> = this.isEditMode() && this.vehicleId() 
      ? this.transportService.update(this.vehicleId(), vehicleData)
      : this.transportService.create(vehicleData);

    request$.subscribe({
      next: () => {
        this.loading.set(false);
        this.showSuccessMessage(`Vehicle ${this.isEditMode() ? 'updated' : 'added'} successfully!`);
        this.cdr.markForCheck();
        this.router.navigate(['/app/transport']);
      },
      error: (error: any) => {
        this.loading.set(false);
        console.error(`Error ${this.isEditMode() ? 'updating' : 'creating'} vehicle:`, error);
        this.error.set(error?.error?.message || error?.error?.title || `Failed to ${this.isEditMode() ? 'update' : 'add'} vehicle. Please try again.`);
        this.cdr.markForCheck();
      }
    });
  }

  private markFormGroupTouched() {
    Object.keys(this.transportForm.controls).forEach(key => {
      const control = this.transportForm.get(key);
      control?.markAsTouched();
    });
  }

  private resetForm() {
    this.transportForm.reset();
    this.resetValidationState();
    
    // Reset default values
    const defaultInsuranceExpiry = new Date();
    defaultInsuranceExpiry.setFullYear(defaultInsuranceExpiry.getFullYear() + 1);
    
    const defaultFitnessExpiry = new Date();
    defaultFitnessExpiry.setFullYear(defaultFitnessExpiry.getFullYear() + 1);
    
    this.transportForm.patchValue({ 
      status: 'active',
      capacity: 0,
      insuranceExpiry: defaultInsuranceExpiry,
      fitnessExpiry: defaultFitnessExpiry
    });
  }

  private resetValidationState() {
    Object.keys(this.transportForm.controls).forEach(key => {
      const control = this.transportForm.get(key);
      control?.markAsUntouched();
      control?.markAsPristine();
    });
  }

  private showSuccessMessage(message: string) {
    this.success.set(message);
    this.snackBar.open(message, 'Close', {
      duration: 3000,
      panelClass: ['success-snackbar']
    });
  }

  getErrorMessage(fieldName: string): string {
    const control = this.transportForm.get(fieldName);
    if (control?.hasError('required')) {
      return `${this.capitalize(fieldName)} is required`;
    }
    if (control?.hasError('minlength')) {
      const minLength = control.errors?.['minlength']?.requiredLength;
      return `${this.capitalize(fieldName)} must be at least ${minLength} characters`;
    }
    if (control?.hasError('min')) {
      return `${this.capitalize(fieldName)} must be greater than ${control.errors?.['min']?.min}`;
    }
    if (control?.hasError('max')) {
      return `${this.capitalize(fieldName)} must be less than ${control.errors?.['max']?.max}`;
    }
    if (control?.hasError('pattern')) {
      if (fieldName === 'driverContact') {
        return 'Please enter a valid 10-digit phone number';
      }
    }
    return '';
  }

  private capitalize(str: string): string {
    return str.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase());
  }

  getStatusColor(status: string): string {
    const statusObj = this.vehicleStatuses.find(s => s.value === status);
    return statusObj?.color || 'var(--color-text-secondary)';
  }

  getVehicleIcon(type: string): string {
    const vehicleType = this.vehicleTypes.find(t => t.value === type);
    return vehicleType?.icon || 'commute';
  }

  getStatusIcon(status: string): string {
    const statusObj = this.vehicleStatuses.find(s => s.value === status);
    return statusObj?.icon || 'info';
  }

  onCancel() {
    this.router.navigate(['/app/transport']);
  }

  isExpiryWarning(dateField: string): boolean {
    const date = this.transportForm.get(dateField)?.value;
    if (!date) return false;
    
    const today = new Date();
    const expiryDate = new Date(date);
    const daysUntilExpiry = Math.ceil((expiryDate.getTime() - today.getTime()) / (1000 * 3600 * 24));
    
    return daysUntilExpiry <= 30; // Warning if expiring in 30 days or less
  }
}
