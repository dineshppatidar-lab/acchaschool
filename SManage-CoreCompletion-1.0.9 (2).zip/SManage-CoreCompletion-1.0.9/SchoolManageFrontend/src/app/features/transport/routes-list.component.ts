import { ChangeDetectionStrategy, ChangeDetectorRef, Component, Inject, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatTableModule } from '@angular/material/table';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatDialog, MatDialogModule, MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { DialogUtils } from '../../shared/dialog-utils';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { ReactiveFormsModule, FormControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Observable, combineLatest, BehaviorSubject } from 'rxjs';
import { map, startWith, debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { TransportService, BusRoute, RouteStop } from '../../services/transport.service';
import { PageHeaderComponent } from '../../shared/components/page-patterns/index';
import { Router, RouterModule } from '@angular/router';

@Component({
  selector: 'app-routes-list',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    CommonModule,
    MatTableModule,
    MatButtonModule,
    MatIconModule,
    MatCardModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatDialogModule,
    MatSnackBarModule,
  MatProgressSpinnerModule,
    ReactiveFormsModule,
    RouterModule,
    PageHeaderComponent
  ],
  templateUrl: './routes-list.component.html',
  styleUrls: ['./routes-list.component.scss']
})
export class RoutesListComponent implements OnInit {
  private routesSubject = new BehaviorSubject<BusRoute[]>([]);
  filteredRoutes$?: Observable<BusRoute[]>;
  isLoading = signal(false);
  routesData: BusRoute[] = []
  searchControl = new FormControl('');

  displayedColumns: string[] = ['name', 'window', 'vehicle', 'students', 'stops', 'actions'];

  constructor(
    private transport: TransportService,
    private snack: MatSnackBar,
    private dialog: MatDialog,
    private dialogUtils: DialogUtils,
    private router: Router,
    private cdr: ChangeDetectorRef,
  ) {}

  ngOnInit(): void {
    this.loadRoutes();
    this.setupFiltering();
  }

  loadRoutes() {
    // Break synchronous change detection cycle to prevent NG0100 error
    setTimeout(() => {
      this.isLoading.set(true);
      this.cdr.markForCheck();
    });

    this.transport.getRoutes().subscribe({
      next: (data) => {
        console.log('Loaded routes from API:', data);
        this.routesData = data || [];
        this.routesSubject.next(this.routesData); // Safely broadcast data
        this.isLoading.set(false);
        this.cdr.markForCheck();
      },
      error: (err) => {
        console.error('Failed to load routes', err);
        this.isLoading.set(false);
        this.cdr.markForCheck();
      }
    });
  }

  setupFiltering() {
    this.filteredRoutes$ = combineLatest([
      this.routesSubject, // Always tracks latest API data properly
      this.searchControl.valueChanges.pipe(startWith(''), debounceTime(300), distinctUntilChanged()),
    ]).pipe(
      map(([routes, search]) => {
        return routes.filter(r => {
          const name = r?.routeName || (r as any)?.RouteName || '';
          return !search || name.toLowerCase().includes((search || '').toLowerCase());
        });
      })
    );
  }

  openRouteDialog(route?: BusRoute) {
    const dialogRef = this.dialog.open(RouteFormDialogComponent, {
        ...this.dialogUtils.getMobileConfig({ width: '500px' }),
        data: route || null,
        panelClass: 'route-form-dialog-container'
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.snack.open(`Route ${route ? 'updated' : 'added'} successfully`, 'Close', { duration: 3000 });
        this.loadRoutes(); // Reload data reflecting new/updated route!
      }
    });
  }

  editRoute(route: BusRoute) {
    this.openRouteDialog(route);
  }

  manageStops(route: BusRoute) {
    this.router.navigate(['/app/transport/routes', route.id, 'stops']);
  }

  deleteRoute(route: BusRoute) {
    const name = route.routeName || (route as any).RouteName;
    if (!confirm(`Delete route ${name}?`)) return;
    this.transport.deleteRoute(route.id || (route as any).Id).subscribe({
      next: () => {
        this.snack.open('Route deleted', 'Close', { duration: 2000 });
        this.loadRoutes();
      },
      error: () => this.snack.open('Failed to delete route', 'Close', { duration: 3000 })
    });
  }
}

@Component({
  selector: 'app-route-form-dialog',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, ReactiveFormsModule, MatFormFieldModule, MatInputModule, MatButtonModule, MatDialogModule, MatSelectModule],
  template: `
    <h2 mat-dialog-title>{{ data?.id || data?.Id ? 'Edit' : 'Add' }} Route</h2>
    <mat-dialog-content>
      <form [formGroup]="form" style="display: flex; flex-direction: column; gap: 1rem; margin-top: 1rem;">
        <mat-form-field appearance="outline">
          <mat-label>Route Name</mat-label>
          <input matInput formControlName="routeName" placeholder="e.g. Morning Express">
          <mat-error>Route name is required</mat-error>
        </mat-form-field>
        <mat-form-field appearance="outline">
          <mat-label>Description</mat-label>
          <textarea matInput formControlName="description" rows="2"></textarea>
        </mat-form-field>
        <div style="display: flex; gap: 1rem;">
          <mat-form-field appearance="outline" style="flex: 1">
            <mat-label>Start Time (HH:mm)</mat-label>
            <input matInput type="time" formControlName="startTime">
            <mat-error>Start time is required</mat-error>
          </mat-form-field>
          <mat-form-field appearance="outline" style="flex: 1">
            <mat-label>End Time (HH:mm)</mat-label>
            <input matInput type="time" formControlName="endTime">
            <mat-error>End time is required</mat-error>
          </mat-form-field>
        </div>
        <div style="display: flex; gap: 1rem;">
          <mat-form-field appearance="outline" style="flex: 1">
            <mat-label>Vehicle</mat-label>
            <mat-select formControlName="vehicleId">
              <mat-option *ngFor="let v of vehicles$ | async" [value]="v.id || v.Id">{{ v.vehicleNumber || v.VehicleNumber }}</mat-option>
            </mat-select>
            <mat-error>Vehicle is required</mat-error>
          </mat-form-field>
          <mat-form-field appearance="outline" style="flex: 1">
            <mat-label>Driver ID</mat-label>
            <input matInput type="number" formControlName="driverId" placeholder="e.g. 1">
          </mat-form-field>
        </div>
      </form>
    </mat-dialog-content>
    <mat-dialog-actions align="end">
      <button mat-button mat-dialog-close>Cancel</button>
      <button mat-raised-button color="primary" [disabled]="form.invalid || isLoading()" (click)="save()">Save</button>
    </mat-dialog-actions>
  `
})
export class RouteFormDialogComponent implements OnInit {
  form: FormGroup;
  isLoading = signal(false);
  vehicles$!: Observable<any[]>;

  constructor(
    public dialogRef: MatDialogRef<RouteFormDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private fb: FormBuilder,
    private transport: TransportService,
    private cdr: ChangeDetectorRef
  ) {
    // C# TimeSpan defaults to "HH:mm:ss", HTML input needs "HH:mm"
    const start = data?.startTime?.substring(0, 5) || data?.StartTime?.substring(0, 5) || '';
    const end = data?.endTime?.substring(0, 5) || data?.EndTime?.substring(0, 5) || '';

    this.form = this.fb.group({
      routeName: [data?.routeName || data?.RouteName || '', Validators.required],
      description: [data?.description || data?.Description || ''],
      startTime: [start, Validators.required],
      endTime: [end, Validators.required],
      vehicleId: [data?.vehicleId || data?.VehicleId || null, [Validators.required, Validators.min(1)]],
      driverId: [data?.driverId ?? data?.DriverId ?? null]
    });
  }

  ngOnInit() {
    // Load ALL vehicles (not just the default first page of 10): with more than 10
    // vehicles, page-1-only made some vehicles impossible to select in this dialog.
    this.vehicles$ = this.transport.getVehicles({ pageSize: 1000 });
  }

  save() {
    if (this.form.invalid) return;
    this.isLoading.set(true);
    this.cdr.markForCheck();
    
    const payload = { ...this.form.value };
    // Convert "HH:mm" back to valid C# TimeSpan "HH:mm:ss"
    if (payload.startTime && payload.startTime.length === 5) payload.startTime += ':00';
    if (payload.endTime && payload.endTime.length === 5) payload.endTime += ':00';

    const routeId = this.data?.id || this.data?.Id;

    const request$: Observable<any> = routeId
      ? this.transport.updateRoute(routeId, { ...payload, id: routeId })
      : this.transport.createRoute(payload);

    request$.subscribe({
      next: () => {
        this.isLoading.set(false);
        this.cdr.markForCheck();
        this.dialogRef.close(true);
      },
      error: (err: any) => {
        this.isLoading.set(false);
        this.cdr.markForCheck();
        console.error('Save route failed', err);
      }
    });
  }
}
