import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnInit, signal } from '@angular/core';
import { TransportService, Vehicle } from '../../services/transport.service';
import { CommonModule } from '@angular/common';
import { MatTableModule } from '@angular/material/table';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatChipsModule } from '@angular/material/chips';
import { MatMenuModule } from '@angular/material/menu';
import { MatDialogModule } from '@angular/material/dialog';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSortModule } from '@angular/material/sort';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatDividerModule } from '@angular/material/divider';
import { RouterModule, Router } from '@angular/router';
import { ReactiveFormsModule, FormControl } from '@angular/forms';
import { Observable, combineLatest } from 'rxjs';
import { map, startWith, debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { CanWriteDirective, CanDeleteDirective } from '../../core/directives/permission.directive';
import { Permission } from '../../core/models/permission.model';
import { PageHeaderComponent, KpiCardComponent } from '../../shared/components/page-patterns/index';

@Component({
  selector: 'app-transport-list',
  standalone: true,
  imports: [
    CommonModule, 
    MatTableModule, 
    MatButtonModule, 
    MatIconModule, 
    MatCardModule, 
    MatFormFieldModule, 
    MatInputModule, 
    MatSelectModule, 
    MatChipsModule, 
    MatMenuModule, 
    MatDialogModule, 
    MatSnackBarModule, 
    MatPaginatorModule, 
    MatSortModule, 
    MatProgressSpinnerModule, 
    MatProgressBarModule,
    MatTooltipModule, 
    MatDatepickerModule,
    MatDividerModule,
    RouterModule, 
    ReactiveFormsModule,
    CanWriteDirective,
    CanDeleteDirective,
    PageHeaderComponent,
    KpiCardComponent
  ],
  templateUrl: './transport-list.component.html',
  styleUrls: ['./transport-list.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class TransportListComponent implements OnInit {
  Permission = Permission;
  vehicles$?: Observable<Vehicle[]>;
  filteredVehicles$?: Observable<Vehicle[]>;
  displayedColumns: string[] = ['vehicle', 'capacity', 'driver', 'route', 'status', 'maintenance', 'actions'];
  private vehiclesData = signal<any[]>([]);

  /** Real assigned-student counts keyed by vehicle id (issue #7) */
  assignedStudentsByVehicle = signal<Record<number, any>>({});
  
  // View Controls
  viewMode: 'card' | 'table' = 'card';
  isLoading = signal(false);
  
  // Filter Controls
  searchControl = new FormControl('');
  typeFilterControl = new FormControl('');
  statusFilterControl = new FormControl('');
  routeFilterControl = new FormControl('');
  
  // Vehicle Types and Statuses
  vehicleTypes = ['Bus', 'Van', 'Car', 'Truck', 'Minibus', 'Tempo'];
  vehicleStatuses = ['Active', 'Inactive', 'Maintenance', 'Out of Service'];
  routes = signal<any[]>([]);

  constructor(
    private transportService: TransportService,
    private router: Router,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit() {
    this.loadVehicles();
    this.loadRoutes();
    this.setupFiltering();
  }

  loadVehicles() {
    // Break synchronous change detection cycle to prevent NG0100 error
    setTimeout(() => {
      this.isLoading.set(true);
      this.cdr.markForCheck();
    });

    this.vehicles$ = this.transportService.getVehicles();
    this.vehicles$.subscribe({
      next: (data) => {
        console.log('Vehicles loaded:', data);
        this.vehiclesData.set(data || []);
        this.isLoading.set(false);
        this.cdr.markForCheck();
      },
      error: (err) => {
        console.error('Error loading vehicles:', err);
        this.isLoading.set(false);
        this.cdr.markForCheck();
      }
    });

    // Real assigned-student counts per vehicle (issue #7) — replaces the mock
    // `assignedStudentsCount` that was always 0.
    this.transportService.getVehicleStatistics().subscribe({
      next: (assignedByVehicle) => {
        this.assignedStudentsByVehicle.set(assignedByVehicle);
        this.vehiclesData.set(this.vehiclesData().map(v => ({
          ...v,
          assignedStudentsCount: assignedByVehicle[v.id ?? -1] ?? 0
        })));
        if (this.vehicles$) {
          this.vehicles$ = this.vehicles$.pipe(
            map(vehicles => vehicles.map(v => ({
              ...v,
              assignedStudentsCount: assignedByVehicle[v.id ?? -1] ?? 0
            })))
          );
        }
        this.cdr.markForCheck();
      },
      error: (err) => console.error('Error loading vehicle statistics:', err)
    });
  }

  loadRoutes() {
    this.transportService.getRoutes().subscribe({
      next: (data) => {
        this.routes.set(data.map(r => r.routeName));
        this.cdr.markForCheck();
      },
      error: (err) => console.error('Error loading routes:', err)
    });
  }

  setupFiltering() {
    if (!this.vehicles$) return;

    this.filteredVehicles$ = combineLatest([
      this.vehicles$,
      this.searchControl.valueChanges.pipe(startWith(''), debounceTime(300), distinctUntilChanged()),
      this.typeFilterControl.valueChanges.pipe(startWith('')),
      this.statusFilterControl.valueChanges.pipe(startWith('')),
      this.routeFilterControl.valueChanges.pipe(startWith(''))
    ]).pipe(
      map(([vehicles, search, type, status, route]) => {
        return vehicles.filter(vehicle => {
          const matchesSearch = !search || 
            vehicle.vehicleNumber?.toLowerCase().includes(search.toLowerCase()) ||
            vehicle.model?.toLowerCase().includes(search.toLowerCase());
          
          const matchesType = !type || vehicle.model?.includes(type);
          const matchesStatus = !status || vehicle.status === status;
          const matchesRoute = !route || (vehicle as any).route === route;

          return matchesSearch && matchesType && matchesStatus && matchesRoute;
        });
      })
    );
  }

  // Statistics Methods
  getTotalVehicles(): number {
    return this.vehiclesData().length;
  }

  getActiveVehicles(): number {
    return this.vehiclesData().filter(x => (x.status || '').toLowerCase() === 'active').length;
  }

  getMaintenanceVehicles(): number {
    return this.vehiclesData().filter(x => (x.status || '').toLowerCase() === 'maintenance').length;
  }

  getCapacityUtilizationTotal(): number {
    const totalCapacity = this.getTotalCapacity();
    if (totalCapacity === 0) return 0;
    // Real assigned counts fetched from /api/transport/vehicles/statistics (issue #7)
    const totalAssigned = this.vehiclesData().reduce((sum, x) => sum + ((x as any).assignedStudentsCount || 0), 0);
    return Math.floor((totalAssigned / totalCapacity) * 100);
  }

  getTotalCapacity(): number {
    return this.vehiclesData().reduce((sum, x) => sum + (x.capacity || 0), 0);
  }

  // View Methods
  toggleView(mode: 'card' | 'table') {
    this.viewMode = mode;
    this.cdr.markForCheck();
  }

  clearFilters() {
    this.searchControl.setValue('');
    this.typeFilterControl.setValue('');
    this.statusFilterControl.setValue('');
    this.routeFilterControl.setValue('');
  }

  // Vehicle Actions
  editVehicle(vehicle: Vehicle) {
    if (vehicle.id) {
      this.router.navigate(['/app/transport/edit', vehicle.id]);
    }
  }

  deleteVehicle(vehicle: Vehicle) {
    if (confirm(`Are you sure you want to delete vehicle ${vehicle.vehicleNumber}?`)) {
      this.transportService.delete(vehicle.id!).subscribe(() => {
        this.loadVehicles();
      });
    }
  }

  viewVehicleDetails(vehicle: Vehicle) {
    console.log('View vehicle details:', vehicle);
  }

  scheduleMaintenanceVehicle(vehicle: Vehicle) {
    console.log('Schedule maintenance for vehicle:', vehicle);
  }

  assignRouteVehicle(vehicle: Vehicle) {
    console.log('Assign route to vehicle:', vehicle);
  }

  viewMaintenanceHistory(vehicle: Vehicle) {
    console.log('View maintenance history for vehicle:', vehicle);
  }

  // Helper Methods
  getStatusColor(status: string): string {
    switch (status?.toLowerCase()) {
      case 'active': return 'var(--md-success)';
      case 'inactive': return 'var(--color-text-secondary)';
      case 'maintenance': return 'var(--md-warning)';
      case 'reserved': return 'var(--md-primary-light)';
      case 'out of service': return 'var(--md-error)';
      default: return 'var(--color-text-secondary)';
    }
  }

  getStatusIcon(status: string): string {
    switch (status?.toLowerCase()) {
      case 'active': return 'check_circle';
      case 'inactive': return 'cancel';
      case 'maintenance': return 'build';
      case 'reserved': return 'schedule';
      default: return 'info';
    }
  }

  getStatusChipClass(status: string): string {
    return status?.toLowerCase().replace(/\s/g, '-') || 'inactive';
  }

  getVehicleTypeIcon(type: string): string {
    switch (type?.toLowerCase()) {
      case 'bus':
      case 'school bus': return 'directions_bus';
      case 'van': return 'airport_shuttle';
      case 'car': return 'directions_car';
      case 'minibus': return 'commute';
      default: return 'directions_car';
    }
  }

  getCapacityUtilization(vehicle: Vehicle): number {
    // Real assigned count per vehicle (issue #7); falls back to the enriched row value
    const assigned = (vehicle as any).assignedStudentsCount
      ?? this.assignedStudentsByVehicle()[vehicle.id ?? -1]
      ?? 0;
    if (!vehicle.capacity || vehicle.capacity === 0) return 0;
    return Math.floor((assigned / vehicle.capacity) * 100);
  }

  isMaintenanceDue(vehicle: Vehicle): boolean {
    // Check if maintenance is due based on fitness expiry date
    const fitnessExpiry = vehicle.fitnessExpiry;
    if (!fitnessExpiry) return false;
    const days = Math.ceil((new Date(fitnessExpiry).getTime() - new Date().getTime()) / (1000 * 3600 * 24));
    return days <= 30; // Due if expiring in 30 days or less
  }

  getDaysUntilMaintenance(vehicle: Vehicle): number {
    const fitnessExpiry = vehicle.fitnessExpiry;
    if (!fitnessExpiry) return 0;
    const days = Math.ceil((new Date(fitnessExpiry).getTime() - new Date().getTime()) / (1000 * 3600 * 24));
    return days > 0 ? days : 0;
  }

  getRouteDistance(route: string): string {
    // Get route distance information
    const distances: { [key: string]: string } = {
      'Route A': '15 km',
      'Route B': '22 km',
      'Route C': '18 km',
      'Route D': '25 km',
      'Route E': '12 km',
      'City Route': '35 km',
      'Express Route': '45 km'
    };
    return distances[route] || 'N/A';
  }

  exportVehiclesCsv() {
    this.transportService.exportVehicles({ format: 'csv' }).subscribe(blob => {
      this.downloadBlob(blob, 'vehicles_roster.csv');
    });
  }

  private downloadBlob(blob: Blob, filename: string) {
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    window.URL.revokeObjectURL(url);
  }
}
