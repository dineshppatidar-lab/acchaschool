import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { PageHeaderComponent } from '../../shared/components/page-patterns/index';
import { MatCardModule } from '@angular/material/card';
import { MatTableModule } from '@angular/material/table';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { DragDropModule, CdkDragDrop, moveItemInArray } from '@angular/cdk/drag-drop';
import { TransportService, RouteStop } from '../../services/transport.service';

@Component({
  selector: 'app-route-stops',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterModule,
    MatCardModule,
    MatTableModule,
    MatIconModule,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    MatSnackBarModule,
    DragDropModule,
    PageHeaderComponent
  ],
  templateUrl: './route-stops.component.html',
  styleUrls: ['./route-stops.component.scss']
})
export class RouteStopsComponent implements OnInit {
  routeId!: number;
  isLoading = signal(false);
  stops = signal<any[]>([]);

  addForm: FormGroup;
  editingStopId = signal<any>(null);
  editForm: FormGroup;

  displayedColumns: string[] = ['sequence', 'name', 'arrival', 'coords', 'actions'];

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private fb: FormBuilder,
    private transport: TransportService,
    private snack: MatSnackBar
  ) {
    this.addForm = this.fb.group({
      stopName: ['', Validators.required],
      arrivalTime: [''], // HH:mm optional
      latitude: [''],
      longitude: ['']
    });
    this.editForm = this.fb.group({
      stopName: ['', Validators.required],
      arrivalTime: [''],
      latitude: [''],
      longitude: ['']
    });
  }

  ngOnInit(): void {
    this.routeId = Number(this.route.snapshot.paramMap.get('routeId'));
    if (!this.routeId) {
      this.snack.open('Invalid route', 'Close', { duration: 2000 });
      this.router.navigate(['/app/transport/routes']);
      return;
    }
    this.loadStops();
  }

  loadStops() {
    this.isLoading.set(true);
    this.transport.getRouteStops(this.routeId).subscribe({
      next: (stops) => { this.stops.set([...stops].sort((a,b) => a.sequenceNumber - b.sequenceNumber)); this.isLoading.set(false); },
      error: () => { this.snack.open('Failed to load stops', 'Close', { duration: 3000 }); this.isLoading.set(false); }
    });
  }

  addStop() {
    if (this.addForm.invalid) { this.addForm.markAllAsTouched(); return; }
    const payload = {
      stopName: this.addForm.value.stopName,
      arrivalTime: this.addForm.value.arrivalTime,
      latitude: this.addForm.value.latitude ? Number(this.addForm.value.latitude) : undefined,
      longitude: this.addForm.value.longitude ? Number(this.addForm.value.longitude) : undefined,
      sequenceNumber: (this.stops()[this.stops().length - 1]?.sequenceNumber || 0) + 1
    } as Partial<RouteStop>;
    this.transport.addRouteStop(this.routeId, payload).subscribe({
      next: () => { this.snack.open('Stop added', 'Close', { duration: 2000 }); this.addForm.reset(); this.loadStops(); },
      error: () => this.snack.open('Failed to add stop', 'Close', { duration: 3000 })
    });
  }

  startEdit(stop: RouteStop) {
    this.editingStopId.set(stop.id);
    this.editForm.setValue({
      stopName: stop.stopName,
      arrivalTime: stop.arrivalTime || '',
      latitude: stop.latitude ?? '',
      longitude: stop.longitude ?? ''
    });
  }

  cancelEdit() { this.editingStopId.set(null); }

  saveEdit(stop: RouteStop) {
    if (this.editForm.invalid) { this.editForm.markAllAsTouched(); return; }
    const updated: RouteStop = {
      ...stop,
      stopName: this.editForm.value.stopName,
      arrivalTime: this.editForm.value.arrivalTime,
      latitude: this.editForm.value.latitude ? Number(this.editForm.value.latitude) : undefined as any,
      longitude: this.editForm.value.longitude ? Number(this.editForm.value.longitude) : undefined as any
    };
    this.transport.updateRouteStop(this.routeId, updated).subscribe({
      next: () => { this.snack.open('Stop updated', 'Close', { duration: 2000 }); this.editingStopId.set(null); this.loadStops(); },
      error: () => this.snack.open('Failed to update stop', 'Close', { duration: 3000 })
    });
  }

  deleteStop(stop: RouteStop) {
    if (!confirm(`Delete stop ${stop.stopName}?`)) return;
    this.transport.deleteRouteStop(this.routeId, stop.id).subscribe({
      next: () => { this.snack.open('Stop deleted', 'Close', { duration: 2000 }); this.loadStops(); },
      error: () => this.snack.open('Failed to delete stop', 'Close', { duration: 3000 })
    });
  }

  drop(event: CdkDragDrop<RouteStop[]>) {
    moveItemInArray(this.stops(), event.previousIndex, event.currentIndex);
    // Recompute sequence numbers starting at 1
    const order = this.stops().map((s, idx) => ({ stopId: s.id, sequenceNumber: idx + 1 }));
    this.transport.reorderRouteStops(this.routeId, order).subscribe({
      next: () => this.snack.open('Stops reordered', 'Close', { duration: 1500 }),
      error: () => this.snack.open('Failed to reorder stops', 'Close', { duration: 3000 })
    });
  }
}
