import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { PageHeaderComponent } from '../../shared/components/page-patterns/index';
import { FormControl, ReactiveFormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { Observable } from 'rxjs';
import { map, startWith, debounceTime } from 'rxjs/operators';
import { TransportService } from '../../services/transport.service';
import { StudentService, Student } from '../../services/student.service';

@Component({
  selector: 'app-route-assignment',
  standalone: true,
  imports: [
    CommonModule,
    RouterModule,
    ReactiveFormsModule,
    MatCardModule,
    MatIconModule,
    MatButtonModule,
    MatSnackBarModule,
    MatFormFieldModule,
    MatInputModule,
    MatAutocompleteModule,
    PageHeaderComponent
  ],
  templateUrl: './route-assignment.component.html',
  styleUrls: ['./route-assignment.component.scss']
})
export class RouteAssignmentComponent implements OnInit {
  routeId!: number;
  students = signal<any[]>([]);
  assigned = signal<any[]>([]);
  search = new FormControl('');
  selectedStudent = new FormControl<number | null>(null);
  filteredStudents$!: Observable<Student[]>;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private transport: TransportService,
    private studentsApi: StudentService,
    private snack: MatSnackBar
  ) {}

  ngOnInit(): void {
    this.routeId = Number(this.route.snapshot.paramMap.get('routeId'));
    this.load();
    this.filteredStudents$ = this.search.valueChanges.pipe(
      startWith(''),
      debounceTime(300),
      map(val => {
        const searchStr = (typeof val === 'string' ? val : '').toLowerCase().trim();
        if (!searchStr) return this.students();
        return this.students().filter(s =>
          `${s.firstName} ${s.lastName}`.toLowerCase().includes(searchStr) ||
          (s.rollNumber || '').toLowerCase().includes(searchStr)
        );
      })
    );
  }

  load() {
    this.studentsApi.getAll().subscribe(s => {
      this.students.set(s || []);
      // Trigger re-filter after students load
      this.search.setValue(this.search.value || '');
    });
    this.transport.getRouteStudents(this.routeId).subscribe(a => this.assigned.set(a || []));
  }

  displayStudent(student: Student): string {
    return student ? `${student.firstName} ${student.lastName}` : '';
  }

  onStudentSelected(event: any) {
    const student = event.option.value as Student;
    if (student && student.id) {
      this.selectedStudent.setValue(student.id);
    }
  }

  assign() {
    const sid = this.selectedStudent.value;
    if (!sid) return;
    this.transport.assignStudentToRoute(sid, this.routeId).subscribe({
      next: () => { this.snack.open('Assigned', 'Close', { duration: 1500 }); this.selectedStudent.setValue(null); this.search.setValue(''); this.load(); },
      error: () => this.snack.open('Failed to assign', 'Close', { duration: 2500 })
    });
  }

  unassign(studentId: number) {
    this.transport.unassignStudentFromRoute(studentId).subscribe({
      next: () => { this.snack.open('Unassigned', 'Close', { duration: 1500 }); this.load(); },
      error: () => this.snack.open('Failed to unassign', 'Close', { duration: 2500 })
    });
  }
}
