import { Component, computed, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { MatIconModule } from '@angular/material/icon';
import { PageHeaderComponent } from '../../shared/components/page-patterns/page-header.component';

interface HelpArticle {
  category: string;
  question: string;
  answer: string;
  route?: string;
  routeLabel?: string;
}

@Component({
  selector: 'app-help-support',
  standalone: true,
  imports: [CommonModule, RouterLink, MatIconModule, PageHeaderComponent],
  templateUrl: './help-support.component.html',
  styleUrl: './help-support.component.scss'
})
export class HelpSupportComponent {
  searchTerm = signal('');

  readonly articles: HelpArticle[] = [
    {
      category: 'Students',
      question: 'How do I add or update a student?',
      answer: 'Open the student list and choose Add Student to create a record. Use the row actions to view or edit an existing student.',
      route: '/app/students/full-details',
      routeLabel: 'Open Students'
    },
    {
      category: 'Fees',
      question: 'Where can I review a student’s fee balance?',
      answer: 'Open the Fees dashboard and search for the student. The dashboard shows collections, outstanding balances, installments and payment history.',
      route: '/app/fees/dashboard',
      routeLabel: 'Open Fees'
    },
    {
      category: 'Staff',
      question: 'How do I manage staff details?',
      answer: 'Use the Staff Directory to review staff profiles. Authorized users can add, update, or remove staff records from the directory.',
      route: '/app/staff/list',
      routeLabel: 'Open Staff'
    },
    {
      category: 'Academics',
      question: 'Where are classes and examination settings managed?',
      answer: 'Academic setup pages are available from the navigation menu. Access depends on your account permissions.',
      route: '/app/academic',
      routeLabel: 'Open Academics'
    },
    {
      category: 'Account',
      question: 'Why can’t I open a page or use an action?',
      answer: 'Your account may not have the required permission. Ask your school administrator to review your role and access settings.',
      route: '/app/settings',
      routeLabel: 'Open Settings'
    }
  ];

  filteredArticles = computed(() => {
    const query = this.searchTerm().trim().toLowerCase();
    if (!query) return this.articles;
    return this.articles.filter(article =>
      `${article.category} ${article.question} ${article.answer}`.toLowerCase().includes(query)
    );
  });

  updateSearch(event: Event): void {
    this.searchTerm.set((event.target as HTMLInputElement).value);
  }
}