import { ChangeDetectionStrategy, ChangeDetectorRef, Component, Inject, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatDialogModule, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatStepperModule } from '@angular/material/stepper';
import { MatIconModule } from '@angular/material/icon';
import { MatCardModule } from '@angular/material/card';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { AdvancedFinanceService } from '../../services/advanced-finance.service';
import { StudentService } from '../../services/student.service';
import { StudentManagementService } from '../../shared/services/student-management.service';
import { PaymentRefreshService } from '../../services/payment-refresh.service';
import { mapPaymentMethodToEnum, requiresTransactionId } from '../../shared/payment-method.util';
import { catchError, map, debounceTime, distinctUntilChanged, switchMap, startWith, tap } from 'rxjs/operators';
import { of, Observable } from 'rxjs';

interface Student {
  id: number;
  name: string;
  class: string;
  section: string;
  rollNumber: string;
  feesDue: number;
  email?: string;
}

interface PaymentDialogData {
  students: Student[];
  paymentMethods: string[];
  feeInstallments?: Array<{ installmentId: number; name: string; amount: number; dueDate: string }>;
  editMode?: boolean;
  paymentToEdit?: any;
}

interface PaymentFormData {
  studentId: number;
  studentName: string;
  amount: number;
  paymentMethod: string;
  feeType: number;
  description: string;
  receiptNumber: string;
  transactionId?: string;
}

@Component({
  selector: 'app-process-payment-dialog',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatDialogModule,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatAutocompleteModule,
    MatStepperModule,
    MatIconModule,
    MatCardModule,
    MatCheckboxModule,
    MatSnackBarModule,
  ],
  template: `
    <h2 mat-dialog-title>
      <mat-icon>{{data.editMode ? 'edit' : 'attach_money'}}</mat-icon>
      {{data.editMode ? 'Edit Payment' : 'Process Payment'}}
    </h2>
    
    <mat-dialog-content class="payment-dialog-content">
      <mat-stepper [linear]="true" #stepper>
        <!-- Step 1: Student Selection -->
        <mat-step [stepControl]="studentForm" label="Select Student">
          <form [formGroup]="studentForm">
            <div class="step-content">
              <mat-form-field appearance="outline" class="full-width">
                <mat-label>Search Student (Type name...)</mat-label>
                <input type="text"
                       placeholder="Start typing student name..."
                       aria-label="Student"
                       matInput
                       formControlName="studentSearch"
                       [matAutocomplete]="auto"
                       autocomplete="off">
                <mat-autocomplete #auto="matAutocomplete" [displayWith]="displayFn" (optionSelected)="onStudentSelected($event)" autoActiveFirstOption>
                  <mat-option *ngFor="let student of filteredStudents$ | async" [value]="student">
                    {{student.name}} - {{student.class}}{{student.section}} (Roll: {{student.rollNumber}})
                  </mat-option>
                </mat-autocomplete>
                <mat-hint>Type at least 2 characters to search</mat-hint>
                <mat-error *ngIf="studentForm.get('studentId')?.hasError('required')">
                  Please select a student from the list
                </mat-error>
              </mat-form-field>

              <mat-card *ngIf="selectedStudent()" class="student-info-card">
                <mat-card-header>
                  <mat-card-title>{{selectedStudent().name}}</mat-card-title>
                  <mat-card-subtitle>
                    Class: {{selectedStudent().class}}{{selectedStudent().section}} | Roll: {{selectedStudent().rollNumber}}
                  </mat-card-subtitle>
                </mat-card-header>
                <mat-card-content>
                  <p><strong>Outstanding Fees:</strong> ₹{{selectedStudent().feesDue | number:'1.2-2'}}</p>
                </mat-card-content>
              </mat-card>

              <div class="step-actions">
                <button mat-button matStepperNext [disabled]="!studentForm.valid">Next</button>
              </div>
            </div>
          </form>
        </mat-step>

        <!-- Step 2: Payment Details -->
        <mat-step [stepControl]="paymentForm" label="Payment Details">
          <form [formGroup]="paymentForm">
            <div class="step-content">
              <div class="form-row">
                <mat-form-field appearance="outline" class="half-width">
                  <mat-label>Amount</mat-label>
                  <input matInput type="number" formControlName="amount" placeholder="Enter amount">
                  <span matSuffix>₹</span>
                  <mat-error *ngIf="paymentForm.get('amount')?.hasError('required')">
                    Amount is required
                  </mat-error>
                  <mat-error *ngIf="paymentForm.get('amount')?.hasError('min')">
                    Amount must be greater than 0
                  </mat-error>
                  <mat-error *ngIf="paymentForm.get('amount')?.hasError('max')">
                    Amount cannot exceed outstanding fees
                  </mat-error>
                </mat-form-field>

                <mat-form-field appearance="outline" class="half-width">
                  <mat-label>Fee Type</mat-label>
                  <mat-select formControlName="feeType">
                    <mat-option *ngFor="let installment of availableFeeInstallments" [value]="installment.installmentId">
                      {{installment.name}} - ₹{{installment.amount}} (due: {{installment.dueDate | date:'shortDate'}})
                    </mat-option>
                  </mat-select>
                  <mat-error *ngIf="paymentForm.get('feeType')?.hasError('required')">
                    Please select fee type
                  </mat-error>
                </mat-form-field>
              </div>

              <div class="form-row">
                <mat-form-field appearance="outline" class="half-width">
                  <mat-label>Payment Method</mat-label>
                  <mat-select formControlName="paymentMethod" (selectionChange)="onPaymentMethodChange($event.value)">
                    <mat-option *ngFor="let method of paymentMethods()" [value]="method">
                      {{method}}
                    </mat-option>
                  </mat-select>
                  <mat-error *ngIf="paymentForm.get('paymentMethod')?.hasError('required')">
                    Please select payment method
                  </mat-error>
                </mat-form-field>

                <mat-form-field appearance="outline" class="half-width" 
                               *ngIf="showTransactionField">
                  <mat-label>Transaction ID</mat-label>
                  <input matInput formControlName="transactionId" 
                         placeholder="Enter transaction/reference ID">
                  <mat-hint>Required for digital payments</mat-hint>
                </mat-form-field>
              </div>

              <mat-form-field appearance="outline" class="full-width">
                <mat-label>Description/Note</mat-label>
                <textarea matInput formControlName="description" 
                         placeholder="Payment description (optional)" rows="3"></textarea>
              </mat-form-field>

              <mat-form-field appearance="outline" class="full-width">
                <mat-label>Receipt Number</mat-label>
                <input matInput formControlName="receiptNumber" readonly>
                <mat-hint>Auto-generated receipt number</mat-hint>
              </mat-form-field>

              <div class="step-actions">
                <button mat-button matStepperPrevious>Back</button>
                <button mat-button matStepperNext [disabled]="!paymentForm.valid">Next</button>
              </div>
            </div>
          </form>
        </mat-step>

        <!-- Step 3: Confirmation -->
        <mat-step label="Confirmation">
          <div class="step-content">
            <mat-card class="confirmation-card">
              <mat-card-header>
                <mat-card-title>Payment Confirmation</mat-card-title>
                <mat-card-subtitle>Please review the payment details</mat-card-subtitle>
              </mat-card-header>
              <mat-card-content>
                <div class="confirmation-details">
                  <div class="detail-row">
                    <span class="label">Student:</span>
                    <span class="value">{{selectedStudent()?.name}}</span>
                  </div>
                  <div class="detail-row">
                    <span class="label">Class:</span>
                    <span class="value">{{selectedStudent()?.class}}{{selectedStudent()?.section}}</span>
                  </div>
                  <div class="detail-row">
                    <span class="label">Amount:</span>
                    <span class="value">₹{{paymentForm.get('amount')?.value | number:'1.2-2'}}</span>
                  </div>
                  <div class="detail-row">
                    <span class="label">Fee Type:</span>
                    <span class="value">
                      {{ selectedInstallmentName }}
                    </span>
                  </div>
                  <div class="detail-row">
                    <span class="label">Payment Method:</span>
                    <span class="value">{{paymentForm.get('paymentMethod')?.value}}</span>
                  </div>
                  <div class="detail-row" *ngIf="paymentForm.get('transactionId')?.value">
                    <span class="label">Transaction ID:</span>
                    <span class="value">{{paymentForm.get('transactionId')?.value}}</span>
                  </div>
                  <div class="detail-row">
                    <span class="label">Receipt Number:</span>
                    <span class="value">{{paymentForm.get('receiptNumber')?.value}}</span>
                  </div>
                  <div class="detail-row" *ngIf="paymentForm.get('description')?.value">
                    <span class="label">Description:</span>
                    <span class="value">{{paymentForm.get('description')?.value}}</span>
                  </div>
                </div>
              </mat-card-content>
            </mat-card>

            <div class="confirmation-checkbox">
              <mat-checkbox [(ngModel)]="confirmPayment">
                I confirm that the payment details are correct
              </mat-checkbox>
            </div>

            <div class="step-actions">
              <button mat-button matStepperPrevious>Back</button>
              <button mat-raised-button color="primary" 
                      [disabled]="!confirmPayment || processing()"
                      (click)="processPayment()">
                <mat-icon *ngIf="processing()">hourglass_empty</mat-icon>
                <mat-icon *ngIf="!processing()">{{data.editMode ? 'save' : 'attach_money'}}</mat-icon>
                {{processing() ? (data.editMode ? 'Updating...' : 'Processing...') : (data.editMode ? 'Update Payment' : 'Process Payment')}}
              </button>
            </div>
          </div>
        </mat-step>
      </mat-stepper>
    </mat-dialog-content>

    <mat-dialog-actions align="end" class="dialog-actions">
      <button mat-button (click)="onCancel()" [disabled]="processing()">Cancel</button>
    </mat-dialog-actions>
  `,
  styles: [`
    .payment-dialog-content {
      width: 100%;
      min-height: 400px;
      padding: 20px 0;
    }

    .step-content {
      padding: 20px 0;
      min-height: 300px;
    }

    .full-width {
      width: 100%;
      margin-bottom: 16px;
    }

    .half-width {
      width: 48%;
      margin-bottom: 16px;
    }

    .form-row {
      display: flex;
      gap: 16px;
      align-items: flex-start;
    }

    .student-info-card {
      margin: 16px 0;
      background-color: var(--md-surface-container-low);
    }

    .confirmation-card {
      margin-bottom: 20px;
    }

    .confirmation-details .detail-row {
      display: flex;
      justify-content: space-between;
      padding: 8px 0;
      border-bottom: 1px solid var(--color-border);
    }

    .confirmation-details .label {
      font-weight: 500;
      color: var(--color-text-secondary);
    }

    .confirmation-details .value {
      font-weight: 400;
      color: var(--md-on-surface);
    }

    .confirmation-checkbox {
      margin: 20px 0;
    }

    .step-actions {
      margin-top: 20px;
      display: flex;
      gap: 12px;
    }

    .dialog-actions {
      padding: 16px 24px;
      border-top: 1px solid var(--color-border);
    }

    @media (max-width: 600px) {
      .form-row {
        flex-direction: column;
      }
      
      .half-width {
        width: 100%;
      }
    }
  `]
})
export class ProcessPaymentDialogComponent implements OnInit {
  studentForm: FormGroup;
  paymentForm: FormGroup;
  selectedStudent = signal<any>(null);
  confirmPayment = false;
  processing = signal(false);
  showTransactionField = false;
  availableFeeInstallments: Array<{ installmentId: number; name: string; amount: number; dueDate: string }> = [];
  filteredStudents$!: Observable<Student[]>;
  paymentMethods = signal<any[]>([]);

  constructor(
    private fb: FormBuilder,
    private dialogRef: MatDialogRef<ProcessPaymentDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: PaymentDialogData,
    private snackBar: MatSnackBar,
    private financeService: AdvancedFinanceService,
    private studentService: StudentService,
    private studentManagementService: StudentManagementService,
    private paymentRefreshService: PaymentRefreshService,
    private cdr: ChangeDetectorRef
  ) {
    this.studentForm = this.fb.group({
      studentId: [null, Validators.required],
      studentSearch: ['']
    });

    this.paymentForm = this.fb.group({
      amount: ['', [Validators.required, Validators.min(1)]],
      paymentMethod: ['', Validators.required],
      feeType: ['', Validators.required],
      description: [''],
      receiptNumber: [this.generateReceiptNumber(), Validators.required],
      transactionId: ['']
    });
  }

  ngOnInit(): void {
    this.paymentMethods.set(Array.isArray(this.data?.paymentMethods) ? this.data.paymentMethods : []);

    if (!this.paymentMethods().length) {
      this.loadPaymentMethods();
    }

    // Set up search-as-you-type logic
    this.filteredStudents$ = this.studentForm.get('studentSearch')!.valueChanges.pipe(
      startWith(''),
      debounceTime(250),
      distinctUntilChanged((prev, curr) => String(prev).trim() === String(curr).trim()),
      switchMap(value => {
        const searchStr = typeof value === 'string' ? value.trim() : '';
        if (searchStr.length < 2 && !this.data.editMode) {
          return of([]);
        }

        return this.studentManagementService.getAllStudentFullDetails(searchStr, 1, 10).pipe(
          map(list => (list || []).map((s: any) => {
            let feesDue = s.feesDue ?? s.FeesDue;
            if (feesDue === undefined || feesDue === null) {
              feesDue = s.fees?.reduce((acc: number, fee: any) => {
                const feeStatus = fee.status ?? fee.Status ?? '';
                const feeAmount = fee.amount ?? fee.Amount ?? 0;
                const isPaid = String(feeStatus).toLowerCase() === 'paid';
                return acc + (isPaid ? 0 : feeAmount);
              }, 0) ?? 0;
            }

            return {
              id: s.id,
              name: `${s.firstName ?? ''} ${s.lastName ?? ''}`.trim(),
              class: s.class?.name || s.className || (s.classId ? String(s.classId) : ''),
              section: s.section?.name || s.sectionName || (s.sectionId ? String(s.sectionId) : ''),
              rollNumber: s.rollNumber ?? '',
              feesDue: Number(feesDue) || 0,
              email: s.email ?? ''
            };
          })),
          catchError((err) => { console.error('Failed to search students for payment', err); return of([]); })
        );
      }),
      tap(() => this.cdr.markForCheck())
    );

    // Update amount validator when student is selected
    this.studentForm.get('studentId')?.valueChanges.subscribe(() => {
      this.updateAmountValidator();
    });

    // Auto-fill amount when a fee type (installment) is selected
    this.paymentForm.get('feeType')?.valueChanges.subscribe((installmentId) => {
      const selected = this.availableFeeInstallments.find(i => i.installmentId === installmentId);
      if (selected) {
        this.paymentForm.patchValue({ amount: selected.amount });
        this.cdr.markForCheck();
      }
    });

    // If in edit mode, pre-populate
    if (this.data.editMode && this.data.paymentToEdit) {
      this.populateFormForEdit();
    }
  }

  displayFn(student: Student): string {
    return student ? student.name : '';
  }

  onStudentSelected(event: any): void {
    const student = event.option.value as Student;
    this.selectedStudent.set(student);
    this.studentForm.patchValue({ studentId: student.id });
    this.onStudentSelect(student.id);
  }

  populateFormForEdit(): void {
    const payment = this.data.paymentToEdit;
    
    // Create a minimal student object for edit mode
    const student: Student = {
      id: payment.studentId,
      name: payment.studentName || `ID ${payment.studentId}`,
      class: '',
      section: '',
      rollNumber: '',
      feesDue: 999999 // Allow edit even if we don't know exact due
    };

    this.selectedStudent.set(student);
    this.studentForm.patchValue({
      studentId: student.id,
      studentSearch: student
    });
    
    this.paymentForm.patchValue({
      amount: payment.amountPaid,
      paymentMethod: payment.paymentMethod,
      feeType: 'Tuition Fee',
      description: `Edit of payment ${payment.receiptNumber}`,
      receiptNumber: payment.receiptNumber,
      transactionId: ''
    });

    this.onPaymentMethodChange(payment.paymentMethod);
    this.onStudentSelect(student.id);
  }

  onStudentSelect(studentId: number): void {
    if (studentId) {
      this.financeService.getStudentFeeInstallments(studentId).subscribe({
        next: (res: any) => {
          const list = Array.isArray(res) ? res : (res?.data ?? res);
          this.availableFeeInstallments = (list || []).map((installment: any) => ({
            installmentId: installment.installmentId ?? installment.InstallmentId ?? installment.id,
            name: installment.name ?? installment.Name ?? 'Fee Installment',
            amount: installment.balance ?? installment.Balance ?? installment.amount ?? installment.Amount ?? 0,
            dueDate: installment.dueDate ?? installment.DueDate
          })).filter((i: any) => i.amount > 0); // Only show installments with balance > 0
          
          // Calculate outstanding fees from actual installment balances
          const totalOutstanding = this.availableFeeInstallments.reduce((sum, inst) => sum + inst.amount, 0);
          
          if (this.selectedStudent()) {
            // Update reference to trigger change detection (especially for OnPush)
            this.selectedStudent.set({
              ...this.selectedStudent(),
              feesDue: totalOutstanding
            });
            console.log('✅ Updated selectedStudent with new feesDue:', totalOutstanding);
          }
          
          this.updateAmountValidator();

          // If no installments found, show warning
          if (this.availableFeeInstallments.length === 0) {
            console.warn('⚠️ No pending fee installments found for student:', studentId);
            this.snackBar.open(
              'No pending fee installments found for this student.',
              'Dismiss',
              { duration: 3000 }
            );
          }
          console.log('📋 Loaded installments:', this.availableFeeInstallments);
          this.cdr.markForCheck();
        },
        error: (err: any) => {
          console.error('Failed to load fee installments:', err);
          this.availableFeeInstallments = [];
          this.snackBar.open(
            'Failed to load fee installments. Please try again.',
            'Dismiss',
            { duration: 3000 }
          );
          this.cdr.markForCheck();
        }
      });
    } else {
      this.availableFeeInstallments = [];
      this.cdr.markForCheck();
    }
  }

  private loadPaymentMethods(): void {
    this.financeService.getPaymentMethods().subscribe({
      next: (res: any) => {
        const list = Array.isArray(res) ? res : (res?.data ?? res);
        this.paymentMethods.set((list || []).map((m: any) => {
          if (!m) return '';
          if (typeof m === 'string') return m;
          // Handle database model (methodName/MethodName) and lookup DTOs (name/Name)
          return m.methodName ?? m.MethodName ?? m.name ?? m.Name ?? m.label ?? m.Label ?? String(m);
        }).filter(Boolean));
        
        // If no methods loaded, use fallback that matches backend PaymentMethodType enum
        if (this.paymentMethods().length === 0) {
          this.paymentMethods.set(['Cash', 'Cheque', 'Credit Card', 'Debit Card', 'Online Transfer', 'UPI', 'Net Banking', 'EMI']);
        }
        console.log('✅ Loaded dynamic payment methods from DB:', this.paymentMethods());
        this.cdr.markForCheck();
      },
      error: (err: any) => {
        console.error('❌ Failed to load payment methods:', err);
        // Use display-friendly default payment methods as fallback
        this.paymentMethods.set(['Cash', 'Cheque', 'Credit Card', 'Debit Card', 'Online Transfer', 'UPI', 'Net Banking', 'EMI']);
        this.cdr.markForCheck();
      }
    });
  }

  onPaymentMethodChange(paymentMethod: string): void {
    this.showTransactionField = requiresTransactionId(paymentMethod);
    
    // Update transaction ID field requirement
    const transactionIdControl = this.paymentForm.get('transactionId');
    if (this.showTransactionField) {
      transactionIdControl?.setValidators([Validators.required]);
    } else {
      transactionIdControl?.clearValidators();
    }
    transactionIdControl?.updateValueAndValidity();
    this.cdr.markForCheck();
  }

  updateAmountValidator(): void {
    const amountControl = this.paymentForm.get('amount');
    if (this.selectedStudent() && amountControl) {
      amountControl.setValidators([
        Validators.required,
        Validators.min(1),
        Validators.max(this.selectedStudent().feesDue)
      ]);
      amountControl.updateValueAndValidity();
    }
  }

  generateReceiptNumber(): string {
    const date = new Date();
    const timestamp = date.getTime().toString().slice(-6);
    return `RCP-${timestamp}`;
  }

  processPayment(): void {
    if (!this.selectedStudent()) return;

    this.processing.set(true);
    this.cdr.markForCheck();

    // Prepare payment data for API - must match ProcessPaymentRequest DTO
    const paymentData = {
      studentId: this.selectedStudent()!.id,
      feeInstallmentId: Number(this.paymentForm.get('feeType')?.value),
      amountPaid: this.paymentForm.get('amount')?.value,
      lateFeeAmount: 0, // Set to 0 by default, can be updated via dedicated endpoint
      discountAmount: 0, // Set to 0 by default, can be updated via dedicated endpoint
      paymentMethod: mapPaymentMethodToEnum(this.paymentForm.get('paymentMethod')?.value || 'Cash'),
      transactionId: this.paymentForm.get('transactionId')?.value || '',
      remarks: this.paymentForm.get('description')?.value
    };

    this.financeService.processPayment({
      studentId: paymentData.studentId,
      studentName: this.selectedStudent()!.name,
      studentEmail: this.selectedStudent()!.email ?? '',
      feeInstallmentId: paymentData.feeInstallmentId,
      amountPaid: paymentData.amountPaid,
      lateFeeAmount: paymentData.lateFeeAmount,
      discountAmount: paymentData.discountAmount,
      paymentMethod: paymentData.paymentMethod,
      transactionId: paymentData.transactionId,
      remarks: paymentData.remarks
    }).subscribe({
      next: (res: any) => {
        this.processing.set(false);
        const successMessage = this.data.editMode ? 'Payment updated successfully!' : 'Payment processed successfully!';
        this.cdr.markForCheck();
        this.snackBar.open(successMessage, 'Close', {
          duration: 3000,
          panelClass: ['success-snackbar']
        });
        // Trigger payment list refresh in parent component and close dialog with success
        this.paymentRefreshService.triggerRefresh();
        this.dialogRef.close({ success: true, data: res });
      },
      error: (err: any) => {
        this.processing.set(false);
        this.cdr.markForCheck();
        
        // Extract error message from backend response if available
        let errorMessage = 'Failed to process payment. Please try again.';
        if (err?.error?.message) {
          errorMessage = err.error.message;
        } else if (err?.error?.errors && Array.isArray(err.error.errors) && err.error.errors.length > 0) {
          errorMessage = err.error.errors[0];
        } else if (typeof err?.error === 'string') {
          errorMessage = err.error;
        }
        
        this.snackBar.open(errorMessage, 'Close', {
          duration: 7000,
          panelClass: ['error-snackbar']
        });
      }
    });
  }

  get selectedInstallmentName(): string {
    const feeTypeValue = this.paymentForm.get('feeType')?.value;
    if (!feeTypeValue || !this.availableFeeInstallments.length) {
      return 'N/A';
    }

    const selectedId = Number(feeTypeValue);
    const selected = this.availableFeeInstallments.find(i => i.installmentId === selectedId);
    return selected ? selected.name : 'N/A';
  }


  onCancel(): void {
    this.dialogRef.close();
  }
}