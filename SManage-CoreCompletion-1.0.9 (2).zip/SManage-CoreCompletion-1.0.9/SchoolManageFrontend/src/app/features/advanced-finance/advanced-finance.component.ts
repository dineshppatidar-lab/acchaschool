import { AfterViewInit, ChangeDetectorRef, Component, OnDestroy, OnInit, ViewChild, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { MatTableModule, MatTableDataSource } from '@angular/material/table';
import { MatPaginatorModule, MatPaginator } from '@angular/material/paginator';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatDialogModule, MatDialog } from '@angular/material/dialog';
import { DialogUtils } from '../../shared/dialog-utils';
import { MatSnackBarModule, MatSnackBar } from '@angular/material/snack-bar';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatCardModule } from '@angular/material/card';
import { MatTabsModule } from '@angular/material/tabs';
import { MatChipsModule } from '@angular/material/chips';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatStepperModule } from '@angular/material/stepper';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { ProcessPaymentDialogComponent } from './process-payment-dialog.component';
import { FeeAssignmentDialogComponent } from '../student-management/fee-assignment-dialog.component';
import { StudentDiscountDialogComponent } from '../fees/student-discount-dialog.component';
import { AdvancedFinanceService } from '../../services/advanced-finance.service';
import { StudentService } from '../../services/student.service';
import { StudentManagementService } from '../../shared/services/student-management.service';
import { SubnavService } from '../../shared/services/subnav.service';
import { MasterDataService } from '../../services/master-data.service';
import { PaymentRefreshService } from '../../services/payment-refresh.service';
import { BackButtonComponent } from '../../shared/components/back-button.component';
import { FeeManagementService } from '../../shared/services/fee-management.service';
import { ReceiptPrinterService } from '../../shared/services/receipt-printer.service';
import { CanWriteDirective, CanDeleteDirective } from '../../core/directives/permission.directive';
import { Permission } from '../../core/models/permission.model';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable, of, Subject } from 'rxjs';
import { catchError, map, takeUntil, debounceTime, distinctUntilChanged, switchMap, startWith, tap } from 'rxjs/operators';

interface FeePayment {
  paymentId: number;
  studentId: number;
  studentName: string;
  amountPaid: number;
  paymentDate: Date;
  paymentMethod: string;
  status: string;
  receiptNumber: string;
}

interface Scholarship {
  scholarshipId: number;
  name: string;
  description: string;
  amount: number;
  type: string;
  eligibilityCriteria: string;
  isActive: boolean;
}

interface FinancialSummary {
  totalRevenue: number;
  totalExpenses: number;
  pendingPayments: number;
  scholarshipsAwarded: number;
}

interface Expense {
  id: number;
  title: string;
  description: string;
  category: number | string;
  amount: number;
  expenseDate: string | Date;
  voucherNumber?: string;
  vendorName?: string;
  status: number | string;
}

interface Budget {
  id: number;
  name: string;
  academicYearId: number;
  category: number | string;
  allocatedAmount: number;
  utilizedAmount: number;
  status: number | string;
}

interface Student {
  id: number;
  name: string;
  class: string;
  section: string;
  rollNumber: string;
  feesDue: number;
  email?: string;
}

interface PaymentFormData {
  studentId: number;
  studentName: string;
  amount: number;
  paymentMethod: string;
  description: string;
  receiptNumber: string;
}

interface RefundRecord {
  id: number;
  paymentId: number;
  studentId: number;
  refundAmount: number;
  refundDate: string;
  refundMode: string;
  refundReason: string;
  referenceNumber: string;
  remarks: string;
  status: string;
}

@Component({
  selector: 'app-advanced-finance',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    MatButtonModule,
    MatIconModule,
    MatDialogModule,
    MatSnackBarModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatCardModule,
    MatTabsModule,
    MatChipsModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatProgressBarModule,
    MatCheckboxModule,
    MatStepperModule,
    MatTooltipModule,
    MatAutocompleteModule,
    CanWriteDirective,
    CanDeleteDirective,
    BackButtonComponent
  ],
  templateUrl: './advanced-finance.component.html',
  styleUrls: ['./advanced-finance.component.scss']
})
export class AdvancedFinanceComponent implements OnInit, AfterViewInit, OnDestroy {
  Permission = Permission;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;
  
  private destroy$ = new Subject<void>();
  
  paymentDataSource = new MatTableDataSource<FeePayment>();
  paymentColumns: string[] = ['receiptNumber', 'studentName', 'amount', 'paymentMethod', 'paymentDate', 'status', 'actions'];
  
  scholarships = signal<any[]>([]);
  expenses = signal<any[]>([]);
  budgets = signal<any[]>([]);
  expenseColumns: string[] = ['title', 'category', 'amount', 'date', 'status', 'actions'];
  budgetColumns: string[] = ['name', 'category', 'allocated', 'utilized', 'remaining', 'status'];
  
  expenseForm!: FormGroup;
  budgetForm!: FormGroup;
  expenseCategories: any[] = [];
  expenseCategories$!: Observable<any[]>;
  
  selectedReportType: string = 'revenue';
  fromDate: Date | undefined = undefined;
  toDate: Date | undefined = undefined;
  reportData = signal<any>(null);
  loading = false;

  financialSummary: FinancialSummary = {
    totalRevenue: 0,
    totalExpenses: 0,
    pendingPayments: 0,
    scholarshipsAwarded: 0
  };

  payments = signal<any[]>([]);
  students = signal<any[]>([]);
  selectedStudentId: number | null = null;
  paymentMethods: { id: number; name: string }[] = [];

  // Student filter autocomplete
  studentFilterControl = new FormControl('');
  filteredStudents$!: Observable<Student[]>;

  // Refund state
  refundStudentId: number | null = null;
  selectedRefundStudent: Student | null = null;
  refundableBalance = signal<any>(null);
  refundFeeSummary = signal<any>(null);
  refundHistory = signal<any[]>([]);
  refundLoading = signal(false);
  refundForm!: FormGroup;
  refundColumns: string[] = ['refundDate', 'studentInfo', 'refundAmount', 'refundMode', 'refundReason', 'status'];
  refundSearchControl = new FormControl('');
  filteredRefundStudents$!: Observable<Student[]>;
  studentPayments = signal<any[]>([]);
  selectedPayment = signal<any>(null);
  refundPaymentsLoading = signal(false);

  /** Tab indexes of the Advanced Finance tab group (Payments/Expenses/Budgets/Scholarships/Refunds/Reports). */
  readonly TAB_QUERY_PARAM = 'tab';
  selectedTabIndex = 0;

  constructor(
    private dialog: MatDialog,
    private dialogUtils: DialogUtils,
    private snackBar: MatSnackBar,
    private finance: AdvancedFinanceService,
    private studentService: StudentService,
    private studentManagementService: StudentManagementService,
    private fb: FormBuilder,
    private subnav: SubnavService,
    private masterDataService: MasterDataService,
    private paymentRefreshService: PaymentRefreshService,
    private feeService: FeeManagementService,
    private receiptPrinter: ReceiptPrinterService,
    private route: ActivatedRoute,
    private router: Router,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.subnav.show('Advanced Finance', [
      // Deep links into this page's tab group — /app/finance/payments etc. do not exist.
      // The component reads ?tab=<n> on init and selects the matching tab.
      { label: 'Payments', icon: 'attach_money', route: '/app/advanced-finance', queryParams: { tab: 0 } },
      { label: 'Expenses', icon: 'receipt_long', route: '/app/advanced-finance', queryParams: { tab: 1 } },
      { label: 'Budgets', icon: 'account_balance_wallet', route: '/app/advanced-finance', queryParams: { tab: 2 } },
      { label: 'Scholarships', icon: 'school', route: '/app/advanced-finance', queryParams: { tab: 3 } },
      { label: 'Refunds', icon: 'undo', route: '/app/advanced-finance', queryParams: { tab: 4 } },
      { label: 'Reports', icon: 'assessment', route: '/app/finance/reports' }
    ]);

    // Honor ?tab= deep links (from the subnav) — became writable via [(selectedIndex)] binding.
    const tabParam = Number(this.route.snapshot.queryParamMap.get('tab'));
    if (!isNaN(tabParam) && tabParam >= 0 && Number.isInteger(tabParam)) {
      this.selectedTabIndex = tabParam;
    }

    this.initForms();
    this.setupRefundStudentSearch();
    this.setupStudentFilter();
    this.fetchAllData();
    
    this.paymentRefreshService.onPaymentProcessed$
      .pipe(takeUntil(this.destroy$))
      .subscribe(() => {
        this.fetchPayments();
      });
  }

  ngAfterViewInit(): void {
    this.paymentDataSource.paginator = this.paginator;
    this.paymentDataSource.sort = this.sort;
    this.cdr.detectChanges();
  }

  onTabSelected(event: any): void {
    // Keep the tab in the URL so subnav deep links (?tab=n) land on the right tab.
    this.router.navigate([], {
      relativeTo: this.route,
      queryParams: { [this.TAB_QUERY_PARAM]: event.index },
      queryParamsHandling: 'merge',
      replaceUrl: true,
    });
  }

  private initForms(): void {
    this.fromDate = new Date(new Date().setMonth(new Date().getMonth() - 1));
    this.toDate = new Date();
    this.expenseForm = this.fb.group({
      title: ['', Validators.required],
      category: [1, Validators.required],
      amount: [0, [Validators.required, Validators.min(0.01)]],
      expenseDate: [new Date(), Validators.required]
    });
    this.budgetForm = this.fb.group({
      name: ['', Validators.required],
      academicYearId: [new Date().getFullYear(), Validators.required],
      category: [1, Validators.required],
      allocatedAmount: [0, [Validators.required, Validators.min(0.01)]]
    });
    this.refundForm = this.fb.group({
      paymentId: [null as number | null, [Validators.required, Validators.min(1)]],
      refundAmount: [null as number | null, [Validators.required, Validators.min(0.01)]],
      refundMode: [1, Validators.required],
      refundReason: ['', Validators.required],
      referenceNumber: [''],
      remarks: ['']
    });
    this.refundSearchControl = this.fb.control('');
  }

  private fetchAllData(): void {
    this.fetchFinancialSummary();
    this.fetchPayments();
    this.fetchStudents();
    this.fetchPaymentMethods();
    this.fetchScholarships();
    this.fetchExpenses();
    this.fetchBudgets();
    this.loadLookups();
  }

  private fetchStudents(): void {
    this.studentManagementService.getAllStudentFullDetails().pipe(
      catchError(err => {
        console.error('Error fetching full student details, falling back to basic list', err);
        return this.studentService.getAll().pipe(
          map((res: any) => {
            if (Array.isArray(res)) return res;
            if (res && Array.isArray(res.data)) return res.data;
            return [];
          })
        );
      }),
      takeUntil(this.destroy$)
    ).subscribe((list: any) => {
      const studentList = Array.isArray(list) ? list : [];
      this.students.set(studentList.map((s: any) => ({
        id: s.id,
        name: `${s.firstName ?? ''} ${s.lastName ?? ''}`.trim(),
        class: s.class?.name ?? (s.classId ? String(s.classId) : ''),
        section: s.section?.name ?? (s.sectionId ? String(s.sectionId) : ''),
        rollNumber: s.rollNumber ?? '',
        email: s.email ?? '',
        feesDue: s.fees?.reduce((acc: number, fee: any) => acc + (fee.status !== 'Paid' ? fee.amount : 0), 0) ?? 0
      })));
      // Trigger re-filter for student autocomplete after students load
      this.studentFilterControl.setValue(this.studentFilterControl.value || '');
      this.cdr.detectChanges();
    });
  }

  private fetchPayments(): void {
    const params: any = {};
    if (this.fromDate) params.startDate = this.fromDate.toISOString();
    if (this.toDate) params.endDate = this.toDate.toISOString();
    if (this.selectedStudentId) params.studentId = this.selectedStudentId;

    this.finance.getPayments(params).pipe(takeUntil(this.destroy$)).subscribe((res: any) => {
      const list = Array.isArray(res) ? res : (res?.data ?? []);
      this.payments.set(list.map((p: any, idx: number) => ({
        paymentId: p.id ?? idx + 1,
        studentId: p.studentId,
        studentName: this.mapStudentName(p),
        amountPaid: p.amountPaid,
        paymentDate: new Date(p.paymentDate ?? Date.now()),
        paymentMethod: (typeof p.paymentMethod === 'string') ? p.paymentMethod : this.mapPaymentMethod(p.paymentMethod),
        status: (typeof p.status === 'string') ? p.status : this.mapPaymentStatus(p.status),
        receiptNumber: p.receiptNumber
      })));
      this.loadPayments();
    });
  }

  loadPayments(): void {
    this.initializePaymentFilter();
    this.paymentDataSource.data = [...this.payments()];
    this.applyStudentFilter(this.selectedStudentId);
    this.cdr.detectChanges();
  }

  private initializePaymentFilter(): void {
    this.paymentDataSource.filterPredicate = (data: FeePayment, filter: string) => {
      if (!filter) return true;
      return data.studentId === Number(filter);
    };
  }

  private fetchFinancialSummary(): void {
    this.finance.getFinancialSummary().pipe(takeUntil(this.destroy$)).subscribe((res: any) => {
      const data = res?.data ?? res;
      if (!data) return;
      this.financialSummary = {
        ...this.financialSummary,
        totalRevenue: data.totalRevenue ?? 0,
        totalExpenses: data.totalExpenses ?? 0
      };
      this.cdr.detectChanges();
    });
  }

  private fetchPaymentMethods(): void {
    this.masterDataService.getPaymentMethods().pipe(takeUntil(this.destroy$)).subscribe((res: any) => {
      const list = Array.isArray(res) ? res : (res?.data ?? res);
      this.paymentMethods = (list || []).map((m: any) => ({ 
        id: m.id ?? m.Id ?? m.value, 
        name: m.methodName ?? m.MethodName ?? m.name ?? m.Name ?? m.label 
      })).filter((item: any) => item.name);
      this.cdr.detectChanges();
    });
  }

  private loadLookups(): void {
    this.expenseCategories$ = this.masterDataService.getExpenseCategories().pipe(
      map((res: any) => {
        const data = Array.isArray(res) ? res : (res?.data ?? res) || [];
        this.expenseCategories = data;
        this.cdr.detectChanges();
        return data;
      }),
      // Issue #14: log instead of silently degrading to an empty list so a
      // failing API (500/timeout/permission) is diagnosable.
      catchError((err) => { console.error('Failed to load expense categories', err); return of([]); }),
      takeUntil(this.destroy$)
    );
    this.expenseCategories$.subscribe();
  }

  private fetchScholarships(): void {
    this.finance.getScholarships().pipe(takeUntil(this.destroy$)).subscribe((res: any) => {
      const list = Array.isArray(res) ? res : (res?.data ?? []);
      this.scholarships.set(list.map((s: any) => ({
        scholarshipId: s.id,
        name: s.name,
        description: s.description,
        amount: s.amount,
        type: typeof s.type === 'string' ? s.type : this.mapScholarshipType(s.type),
        eligibilityCriteria: s.criteria ?? '',
        isActive: !!s.isActive
      })));
      this.cdr.detectChanges();
    });
  }

  private fetchExpenses(): void {
    this.finance.getExpenses().pipe(takeUntil(this.destroy$)).subscribe((res: any) => {
      const list = Array.isArray(res) ? res : (res?.data ?? []);
      this.expenses.set(list.map((e: any) => ({
        id: e.id,
        title: e.title,
        description: e.description,
        category: typeof e.category === 'string' ? e.category : this.mapExpenseCategory(e.category),
        amount: e.amount,
        expenseDate: e.expenseDate ?? new Date(),
        voucherNumber: e.voucherNumber,
        vendorName: e.vendorName,
        status: typeof e.status === 'string' ? e.status : this.mapExpenseStatus(e.status)
      })));
      this.cdr.detectChanges();
    });
  }

  private fetchBudgets(): void {
    this.finance.getBudgets().pipe(takeUntil(this.destroy$)).subscribe((res: any) => {
      const list = Array.isArray(res) ? res : (res?.data ?? []);
      this.budgets.set(list.map((b: any) => ({
        id: b.id,
        name: b.name,
        academicYearId: b.academicYearId,
        category: typeof b.category === 'string' ? b.category : this.mapExpenseCategory(b.category),
        allocatedAmount: b.allocatedAmount,
        utilizedAmount: b.utilizedAmount ?? 0,
        status: b.status ?? 'Active'
      })));
      this.cdr.detectChanges();
    });
  }

  refreshPayments(): void {
    this.fetchPayments();
  }

  createExpense(): void {
    if (this.expenseForm.invalid) return;
    this.finance.createExpense(this.expenseForm.value).subscribe(() => {
      this.showSuccess('Expense created successfully');
      this.expenseForm.reset({ title: '', category: 1, amount: 0, expenseDate: new Date() });
      this.fetchExpenses();
      this.fetchFinancialSummary();
    });
  }

  approveExpense(expense: Expense): void {
    this.finance.approveExpense(expense.id, { remarks: 'Approved via UI' }).subscribe(() => {
      this.showSuccess('Expense approved');
      this.fetchExpenses();
    });
  }

  createBudget(): void {
    if (this.budgetForm.invalid) return;
    this.finance.createBudget(this.budgetForm.value).subscribe(() => {
      this.showSuccess('Budget created successfully');
      this.budgetForm.reset({ name: '', academicYearId: new Date().getFullYear(), category: 1, allocatedAmount: 0 });
      this.fetchBudgets();
    });
  }

  applyPaymentFilter(event: Event): void {
    const filterValue = (event.target as HTMLInputElement).value;
    this.paymentDataSource.filter = filterValue.trim().toLowerCase();
  }

  applyStudentFilter(studentId: number | null): void {
    this.selectedStudentId = studentId;
    this.paymentDataSource.filter = studentId ? String(studentId) : '';
  }

  displayStudentFilter(student: Student): string {
    if (!student) return '';
    const roll = student.rollNumber ? ` (${student.rollNumber})` : '';
    return `${student.name}${roll}`;
  }

  onStudentFilterSelected(event: any): void {
    const student = event.option.value as Student;
    if (student) {
      this.selectedStudentId = student.id;
      this.refreshPayments();
    }
  }

  clearStudentFilter(): void {
    this.studentFilterControl.setValue('');
    this.selectedStudentId = null;
    this.refreshPayments();
  }

  private setupStudentFilter(): void {
    this.filteredStudents$ = this.studentFilterControl.valueChanges.pipe(
      startWith(''),
      debounceTime(300),
      map(val => {
        const searchStr = (typeof val === 'string' ? val : '').toLowerCase().trim();
        if (!searchStr) return this.students();
        return this.students().filter(s =>
          s.name.toLowerCase().includes(searchStr) ||
          (s.rollNumber || '').toLowerCase().includes(searchStr) ||
          (s.class || '').toLowerCase().includes(searchStr)
        );
      })
    );
  }

  getStatusColor(status: string): string {
    const s = status.toLowerCase();
    if (s === 'completed') return 'primary';
    if (s === 'pending' || s === 'failed') return 'warn';
    return 'basic';
  }

  openPaymentDialog(): void {
    const dialogRef = this.dialog.open(ProcessPaymentDialogComponent, {
      ...this.dialogUtils.getMobileConfig(),
      disableClose: true,
      data: { students: this.students(), paymentMethods: this.paymentMethods.map(m => m.name), feeInstallments: [] }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result?.success) {
        this.showSuccess('Payment processed successfully');
        this.fetchPayments();
        this.fetchFinancialSummary();
      }
    });
  }

  openFeeAssignmentDialog(): void {
    const dialogRef = this.dialog.open(FeeAssignmentDialogComponent, {
      ...this.dialogUtils.getMobileConfig(), });
    dialogRef.afterClosed().subscribe(result => {
      if (result?.success) {
        this.showSuccess('Fees assigned successfully');
        this.fetchFinancialSummary();
        this.fetchStudents();
      }
    });
  }

  openFeeAssignmentDialogForSelected(): void {
    const selectedStudent = this.students().find(s => s.id === this.selectedStudentId);
    if (!selectedStudent) {
      this.snackBar.open('Please select a student from the filter first', 'Close', { duration: 3000 });
      return;
    }

    const dialogRef = this.dialog.open(FeeAssignmentDialogComponent, {
      ...this.dialogUtils.getMobileConfig(),
      width: '600px',
      maxHeight: '90vh',
      data: {
        studentId: this.selectedStudentId,
        studentName: `${selectedStudent.name} (${selectedStudent.rollNumber})`
      }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result?.success) {
        this.showSuccess('Fees assigned successfully');
        this.fetchFinancialSummary();
        this.fetchStudents();
      }
    });
  }

  openDiscountDialog(): void {
    const selectedStudent = this.students().find(s => s.id === this.selectedStudentId);
    if (!selectedStudent) {
      this.snackBar.open('Please select a student from the filter first', 'Close', { duration: 3000 });
      return;
    }

    const dialogRef = this.dialog.open(StudentDiscountDialogComponent, {
      ...this.dialogUtils.getMobileConfig(),
      width: '600px',
      data: {
        studentId: this.selectedStudentId,
        studentName: selectedStudent.name,
        studentRollNumber: selectedStudent.rollNumber
      }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result?.success) {
        this.showSuccess('Discount applied successfully');
        this.fetchFinancialSummary();
        this.fetchPayments();
      }
    });
  }

  printReceipt(payment: FeePayment): void {
    const student = this.students().find(s => s.id === payment.studentId);
    const displayName = student?.rollNumber ? `${payment.studentName} (Roll: ${student.rollNumber})` : payment.studentName;
    const paymentDate = payment.paymentDate ? new Date(payment.paymentDate) : null;
    const date = paymentDate && !Number.isNaN(paymentDate.getTime())
      ? paymentDate.toISOString().slice(0, 10)
      : '';
    this.receiptPrinter.print({
      title: 'School Fee',
      receiptNo: payment.receiptNumber,
      studentName: displayName,
      date,
      items: [{ description: 'Fee Payment', unitPrice: payment.amountPaid, total: payment.amountPaid }],
      paymentMethod: ReceiptPrinterService.humanizeMethod(payment.paymentMethod),
      ref: payment.receiptNumber
    }).catch(error => {
      console.error('Failed to print fee payment receipt', error);
      this.snackBar.open('Unable to prepare the receipt. Please try again.', 'Close', { duration: 4000 });
    });
  }

  editPayment(payment: FeePayment): void {
    const dialogRef = this.dialog.open(ProcessPaymentDialogComponent, {
      ...this.dialogUtils.getMobileConfig(),
      data: { students: this.students(), paymentMethods: this.paymentMethods.map(m => m.name), editMode: true, paymentToEdit: payment }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.updatePayment(payment.paymentId, result);
        this.refreshPaymentTable();
      }
    });
  }

  updatePayment(paymentId: number, updatedData: PaymentFormData): void {
    const index = this.payments().findIndex(p => p.paymentId === paymentId);
    if (index !== -1) {
      this.payments()[index] = { ...this.payments()[index], ...updatedData, amountPaid: updatedData.amount };
      this.showSuccess('Payment updated successfully');
      this.cdr.detectChanges();
    }
  }

  refreshPaymentTable(): void {
    this.paymentDataSource.data = [...this.payments()];
    this.cdr.detectChanges();
  }

  generateReport(): void {
    const params = { startDate: this.fromDate?.toISOString(), endDate: this.toDate?.toISOString() };
    this.finance.getCollectionReport(params).subscribe(res => {
      this.reportData.set(Array.isArray(res) ? res : (res?.data ?? res));
      this.showSuccess('Report generated successfully');
      this.cdr.detectChanges();
    });
  }

  viewPaymentDetails(payment: FeePayment): void {
    this.showInfo(`Viewing details for payment ${payment.receiptNumber}`);
  }

  openScholarshipDialog(): void {
    this.showInfo('Add scholarship dialog would open here');
  }

  editScholarship(scholarship: Scholarship): void {
    this.showInfo(`Editing scholarship: ${scholarship.name}`);
  }

  viewScholarshipApplicants(scholarship: Scholarship): void {
    this.showInfo(`Viewing applicants for ${scholarship.name}`);
  }

  deleteScholarship(scholarship: Scholarship): void {
    if (confirm(`Are you sure you want to delete ${scholarship.name}?`)) {
      const index = this.scholarships().findIndex(s => s.scholarshipId === scholarship.scholarshipId);
      if (index !== -1) {
        this.scholarships.update(arr => { arr.splice(index, 1); return arr; });
        this.showSuccess('Scholarship deleted successfully');
        this.cdr.detectChanges();
      }
    }
  }

  public showSuccess(m: string): void { this.snackBar.open(m, 'Close', { duration: 3000, panelClass: ['success-snackbar'] }); }
  public showInfo(m: string): void { this.snackBar.open(m, 'Close', { duration: 3000, panelClass: ['info-snackbar'] }); }

  // ---- Refund methods ----
  displayRefundStudent(student: Student): string {
    return student ? `${student.name} — ${student.class} (Roll: ${student.rollNumber})` : '';
  }

  setupRefundStudentSearch(): void {
    this.filteredRefundStudents$ = this.refundSearchControl.valueChanges.pipe(
      startWith(''),
      debounceTime(300),
      distinctUntilChanged((prev, curr) => String(prev).trim() === String(curr).trim()),
      switchMap(value => {
        const searchStr = typeof value === 'string' ? value.trim() : '';
        if (searchStr.length < 2) return of([]);
        return this.studentManagementService.getAllStudentFullDetails(searchStr, 1, 10).pipe(
          map(list => (list || []).map((s: any) => ({
            id: s.id,
            name: `${s.firstName ?? ''} ${s.lastName ?? ''}`.trim(),
            class: s.class?.name || s.className || (s.classId ? String(s.classId) : ''),
            section: s.section?.name || s.sectionName || (s.sectionId ? String(s.sectionId) : ''),
            rollNumber: s.rollNumber ?? '',
            feesDue: 0,
            email: s.email ?? ''
          }))),
          catchError((err) => { console.error('Failed to search students for refund', err); return of([]); })
        );
      }),
      tap(() => this.cdr.markForCheck())
    );
  }

  onRefundStudentSelected(event: any): void {
    const student = event.option.value as Student;
    this.selectedRefundStudent = student;
    this.refundStudentId = student.id;
    this.refundableBalance.set(null);
    this.refundFeeSummary.set(null);
    this.refundHistory.set([]);
    this.studentPayments.set([]);
    this.selectedPayment.set(null);
    this.refundForm.patchValue({ paymentId: null, refundAmount: null });
    this.loadRefundData(student.id);
    this.loadStudentPaymentsForRefund(student.id);
  }

  clearRefundStudent(): void {
    this.selectedRefundStudent = null;
    this.refundStudentId = null;
    this.refundableBalance.set(null);
    this.refundFeeSummary.set(null);
    this.refundHistory.set([]);
    this.studentPayments.set([]);
    this.selectedPayment.set(null);
    this.refundPaymentsLoading.set(false);
    this.refundSearchControl.setValue('');
    this.refundForm.reset({ refundMode: 1, paymentId: null, refundAmount: null, refundReason: '', referenceNumber: '', remarks: '' });
  }

  cancelRefundSelection(): void {
    this.selectedPayment.set(null);
    this.refundForm.reset({ refundMode: 1, paymentId: null, refundAmount: null, refundReason: '', referenceNumber: '', remarks: '' });
  }

  private loadRefundData(studentId: number): void {
    this.refundLoading.set(true);
    this.feeService.getRefundableBalance(studentId).pipe(takeUntil(this.destroy$)).subscribe({
      next: (res) => { this.refundableBalance.set(res?.data ?? res); this.refundLoading.set(false); this.cdr.detectChanges(); },
      error: () => { this.refundableBalance.set(null); this.refundLoading.set(false); this.cdr.detectChanges(); }
    });
    this.feeService.getRefundHistory(studentId).pipe(takeUntil(this.destroy$)).subscribe({
      next: (res) => {
        const list = Array.isArray(res?.data ?? res) ? (res?.data ?? res) : [];
        // Client-side filter: only show refunds belonging to this student
        this.refundHistory.set(list.filter((r: any) => r.studentId === studentId || r.StudentId === studentId));
        this.cdr.detectChanges();
      },
      error: () => { this.refundHistory.set([]); this.cdr.detectChanges(); }
    });
    // Load fee summary for context (total fees, paid, outstanding, refund due)
    this.feeService.getOutstandingFees(studentId).pipe(takeUntil(this.destroy$)).subscribe({
      next: (res) => {
        const data = res?.data ?? res;
        if (data && data.hasAssignedFees) {
          const totalFee = data.totalFees || data.TotalFees || 0;
          const paidAmount = data.paidAmount || data.PaidAmount || 0;
          const outstandingAmount = data.outstandingAmount || data.OutstandingAmount || 0;
          const discountAmount = data.discountAmount || data.DiscountAmount || 0;
          const netFee = totalFee - discountAmount;
          this.refundFeeSummary.set({
            totalFee,
            paidAmount,
            outstandingAmount,
            discountAmount,
            refundAmount: Math.max(0, paidAmount - netFee),
          });
        } else {
          this.refundFeeSummary.set(null);
        }
        this.cdr.detectChanges();
      },
      error: () => { this.refundFeeSummary.set(null); this.cdr.detectChanges(); }
    });
  }

  private loadStudentPaymentsForRefund(studentId: number): void {
    this.refundPaymentsLoading.set(true);
    this.finance.getPayments({ studentId }).pipe(takeUntil(this.destroy$)).subscribe({
      next: (res: any) => {
        const list = Array.isArray(res) ? res : (res?.data ?? []);
        this.studentPayments.set(list.filter((p: any) => {
          // Client-side filter: only show payments belonging to this student
          if (p.studentId !== studentId) return false;
          const status = typeof p.status === 'string' ? p.status : this.mapPaymentStatus(p.status);
          return status.toLowerCase() === 'completed';
        }).map((p: any, idx: number) => ({
          paymentId: p.id ?? idx + 1,
          studentId: p.studentId,
          studentName: this.mapStudentName(p),
          amountPaid: p.amountPaid,
          paymentDate: new Date(p.paymentDate ?? Date.now()),
          paymentMethod: (typeof p.paymentMethod === 'string') ? p.paymentMethod : this.mapPaymentMethod(p.paymentMethod),
          status: (typeof p.status === 'string') ? p.status : this.mapPaymentStatus(p.status),
          receiptNumber: p.receiptNumber
        })));
        this.refundPaymentsLoading.set(false);
        this.cdr.detectChanges();
      },
      error: () => { this.studentPayments.set([]); this.refundPaymentsLoading.set(false); this.cdr.detectChanges(); }
    });
  }

  selectPaymentForRefund(payment: FeePayment): void {
    this.selectedPayment.set(payment);
    this.refundForm.patchValue({
      paymentId: payment.paymentId,
      refundAmount: null
    });
    const maxRefund = this.refundableBalance()?.remainingRefundable ?? payment.amountPaid;
    this.refundForm.get('refundAmount')?.setValidators([Validators.required, Validators.min(0.01), Validators.max(maxRefund)]);
    this.refundForm.get('refundAmount')?.updateValueAndValidity();
    this.cdr.detectChanges();
  }

  submitRefund(): void {
    if (this.refundForm.invalid || !this.refundStudentId) return;
    const val = this.refundForm.getRawValue();
    this.feeService.createRefund({
      paymentId: Number(val.paymentId),
      studentId: this.refundStudentId,
      refundAmount: Number(val.refundAmount),
      refundMode: Number(val.refundMode),
      refundReason: String(val.refundReason || ''),
      referenceNumber: String(val.referenceNumber || ''),
      remarks: String(val.remarks || '')
    }).pipe(takeUntil(this.destroy$)).subscribe({
      next: () => {
        this.showSuccess('Refund processed successfully');
        this.selectedPayment.set(null);
        this.refundForm.reset({ refundMode: 1, paymentId: null, refundAmount: null, refundReason: '', referenceNumber: '', remarks: '' });
        this.loadRefundData(this.refundStudentId!);
        this.loadStudentPaymentsForRefund(this.refundStudentId!);
      },
      error: (err) => {
        this.snackBar.open(err?.error?.message || 'Failed to process refund', 'Close', { duration: 5000 });
      }
    });
  }

  private mapStudentName(p: any): string {
    const firstName = p.student?.firstName ?? p.student?.FirstName ?? '';
    const lastName = p.student?.lastName ?? p.student?.LastName ?? '';
    const name = `${firstName} ${lastName}`.trim();
    const rollNo = p.student?.rollNumber ?? p.student?.RollNumber ?? '';
    if (name && rollNo) return `${name} (${rollNo})`;
    if (name) return name;
    return `ID ${p.studentId}`;
  }

  private mapPaymentMethod(m: number): string { return {1:'Cash', 2:'Cheque', 3:'Credit Card', 4:'Debit Card', 5:'Online Transfer', 6:'UPI', 7:'Net Banking', 8:'EMI'}[m] || 'Unknown'; }
  private mapPaymentStatus(s: number): string { return {1:'Pending', 2:'Completed', 3:'Failed', 4:'Refunded', 5:'Cancelled'}[s] || 'Unknown'; }
  private mapScholarshipType(t: number): string { return {1:'Merit', 2:'Need Based', 3:'Sports', 4:'Cultural', 5:'Minority', 6:'Disability', 7:'Other'}[t] || 'Other'; }
  mapExpenseCategory(c: any): string { return this.expenseCategories.find(i => i.value === Number(c))?.label || 'Other'; }
  mapExpenseStatus(s: any): string { return {1:'Pending', 2:'Approved', 3:'Rejected', 4:'Paid'}[Number(s)] || 'Pending'; }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }
}
