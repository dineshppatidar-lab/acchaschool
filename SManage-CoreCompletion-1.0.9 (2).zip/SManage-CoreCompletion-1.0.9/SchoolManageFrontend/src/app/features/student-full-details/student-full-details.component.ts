import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnDestroy, OnInit, signal } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule, FormArray, FormControl } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { MatTabsModule } from '@angular/material/tabs';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatSelectModule } from '@angular/material/select';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatChipsModule } from '@angular/material/chips';
import { MatDividerModule } from '@angular/material/divider';
import { MatStepperModule } from '@angular/material/stepper';
import { StudentManagementService } from '../../shared/services/student-management.service';
import { StudentFullDetailsDto, ParentDto } from '../../shared/models/student-full-details-dto';
import { FeeAssignmentDialogComponent } from '../student-management/fee-assignment-dialog.component';
import { MasterDataService, DropdownItem } from '../../core/services/master-data.service';
import { AcademicYearContextService } from '../../shared/services/academic-year-context.service';
import { Subject, Subscription, debounceTime, distinctUntilChanged } from 'rxjs';
import { StudentPageHeaderComponent } from '../../shared/components/students-module/student-page-header.component';
import { DialogUtils } from '../../shared/dialog-utils';

@Component({
  selector: 'app-student-full-details',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatTabsModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatSelectModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatCardModule,
    MatIconModule,
    MatCheckboxModule,
    MatTooltipModule,
    MatSnackBarModule,
    MatProgressSpinnerModule,
    MatDialogModule,
    MatChipsModule,
    MatDividerModule,
    MatStepperModule,
    StudentPageHeaderComponent
  ],
  templateUrl: './student-full-details.component.html',
  styleUrls: ['./student-full-details.component.scss']
})
export class StudentFullDetailsComponent implements OnInit, OnDestroy {
  studentForm!: FormGroup;
  isEditMode = signal(false);
  studentId = signal<any>(null);
  isLoading = signal(false);
  
  // Search
  searchControl = new FormControl('');
  searchResults = signal<any[]>([]);
  private searchSubject = new Subject<string>();
  private subscriptions = signal<any[]>([]);

  // Dropdown Options (Dynamic)
  classes = signal<any[]>([]);
  sections = signal<any[]>([]);
  academicYears = signal<any[]>([]);
  parents: any[] = [];
  busRoutes = [
    { id: 1, name: 'Route A - Downtown' },
    { id: 2, name: 'Route B - Suburbs' },
    { id: 3, name: 'Route C - North District' }
  ];

  genders: string[] = ['Male', 'Female', 'Other'];
  bloodGroups = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];
  disabilityTypes = ['None', 'Hearing', 'Visual', 'Physical', 'Learning', 'Developmental', 'Other'];
  disabilitySeverity = ['N/A', 'Mild', 'Moderate', 'Severe'];

  constructor(
    private fb: FormBuilder,
    private route: ActivatedRoute,
    public router: Router,
    private studentManagementService: StudentManagementService,
    private masterDataService: MasterDataService,
    private snackBar: MatSnackBar,
    private cdr: ChangeDetectorRef,
    private dialog: MatDialog,
    private dialogUtils: DialogUtils,
    private yearContext: AcademicYearContextService
  ) {}

  ngOnInit(): void {
    this.initForm();
    this.setupSearch();
    this.loadMasterData();

    this.route.params.subscribe(params => {
      this.studentId.set(params['id'] ? +params['id'] : null);
      this.isEditMode.set(!!this.studentId());
      
      if (this.isEditMode() && this.studentId()) {
        this.loadStudentDetails();
      } else {
        this.studentForm.reset();
        this.studentId.set(null);
        this.isEditMode.set(false);
        this.cdr.markForCheck();
      }
    });
  }

  ngOnDestroy(): void {
    this.subscriptions().forEach(sub => sub.unsubscribe());
  }

  loadMasterData(): void {
    // Load Academic Years from centralized context
    this.yearContext.loadAcademicYears().subscribe(() => {
      this.academicYears.set(this.yearContext.yearsSnapshot.map(y => ({ id: y.id, name: y.name })));
      // Pre-fill form with selected year from context
      const selectedId = this.yearContext.selectedYearId;
      if (selectedId && !this.isEditMode()) {
        this.studentForm.patchValue({ academicYearId: selectedId });
      }
      this.cdr.markForCheck();
    });

    // Load Classes
    this.masterDataService.getClasses().subscribe(classes => {
      this.classes.set(classes);
      this.cdr.markForCheck();
    });
  }

  onClassChange(classId: number): void {
    if (classId) {
      this.studentForm.patchValue({ sectionId: null });
      this.masterDataService.getSectionsByClass(classId).subscribe(sections => {
        this.sections.set(sections);
        this.cdr.markForCheck();
      });
    } else {
      this.sections.set([]);
      this.cdr.markForCheck();
    }
  }

  setupSearch(): void {
    const searchSub = this.searchSubject
      .pipe(debounceTime(300), distinctUntilChanged())
      .subscribe(searchTerm => {
        if (searchTerm.length >= 2) {
          this.isLoading.set(true);
          this.cdr.markForCheck();
          this.studentManagementService.getAllStudentFullDetails(searchTerm, 1, 10).subscribe({
            next: (results) => {
              this.searchResults.set(results || []);
              this.isLoading.set(false);
              this.cdr.markForCheck();
            },
            error: () => {
              this.searchResults.set([]);
              this.isLoading.set(false);
              this.cdr.markForCheck();
            }
          });
        } else {
          this.searchResults.set([]);
          this.cdr.markForCheck();
        }
      });
    
    this.subscriptions.update(arr => { arr.push(searchSub); return arr; });
    
    const searchInput = this.searchControl.valueChanges
      .subscribe(value => {
        this.searchSubject.next(value || '');
      });
    this.subscriptions.update(arr => { arr.push(searchInput); return arr; });
  }

  initForm(): void {
    this.studentForm = this.fb.group({
      id: [null],
      firstName: ['', [Validators.required, Validators.minLength(2)]],
      lastName: ['', [Validators.required, Validators.minLength(2)]],
      dateOfBirth: ['', Validators.required],
      gender: ['', Validators.required],
      address: ['', [Validators.required, Validators.minLength(5)]],
      contactNumber: ['', [Validators.required, Validators.pattern(/^[0-9]{10}$/)]],
      email: ['', [Validators.required, Validators.email]],
      admissionDate: ['', Validators.required],
      academicYearId: [null, Validators.required],
      classId: [null, Validators.required],
      sectionId: [null, Validators.required],
      rollNumber: ['', [Validators.required, Validators.minLength(1)]],
      scholarNumber: [''],
      parentId: [null],
      busRouteId: [null],
      
      // Extended student details
      addressInfo: this.fb.group({
        currentHouseNumber: [''], currentStreetName: [''], currentCity: [''],
        currentState: [''], currentPostalCode: [''], currentCountry: [''],
        sameAsPermanent: [true],
        permanentHouseNumber: [''], permanentStreetName: [''], permanentCity: [''],
        permanentState: [''], permanentPostalCode: [''], permanentCountry: ['']
      }),
      academicHistory: this.fb.group({
        previousSchoolName: [''], previousSchoolBoard: [''], previousSchoolAddress: [''],
        yearPassedFrom: [null], lastGradeAttended: [''], academicPercentage: [null],
        transferCertificateNumber: [''], reasonForTransfer: ['']
      }),
      medicalInfo: this.fb.group({
        bloodGroup: [''], lastHealthCheckDate: [''], knownAllergies: [''],
        hasAsthma: [false], hasDiabetes: [false], hasHeartCondition: [false], hasEpilepsy: [false],
        isVaccinatedPolio: [false], isVaccinatedMeasles: [false], isVaccinatedBCG: [false], isVaccinatedTCV: [false]
      }),
      documentInfo: this.fb.group({
        idProofType: [''], idProofNumber: [''], idExpiryDate: [''],
        passportNumber: [''], birthCertificateNumber: [''], documentVerificationStatus: ['Pending']
      }),
      specialNeeds: this.fb.group({
        hasSpecialNeeds: [false], disabilityType: [''], disabilitySeverity: [''], auxiliaryAidsRequired: ['']
      }),
      hostelInfo: this.fb.group({
        hostelRequired: [false], preferredHostel: [''], roomType: [''], travelMode: [''], distanceFromHome: [null]
      }),
      scholarshipInfo: this.fb.group({
        eligibleForScholarship: [false], scholarshipType: [''], scholarshipPercentage: [null]
      }),
      newParentDetails: this.fb.group({
        firstName: [''], lastName: [''], contactNumber: ['', [Validators.pattern(/^[0-9]{10}$/)]],
        email: ['', [Validators.email]], occupation: ['']
      })
    });
  }

  loadStudentDetails(): void {
    if (this.studentId()) {
      this.isLoading.set(true);
      this.cdr.markForCheck();
      this.studentManagementService.getStudentFullDetails(this.studentId()).subscribe({
        next: (data: StudentFullDetailsDto) => {
          // If editing, we need to load sections for the student's class
          if (data.classId) {
            this.masterDataService.getSectionsByClass(data.classId).subscribe(sections => {
              this.sections.set(sections);
              this.patchForm(data);
              this.isLoading.set(false);
              this.cdr.markForCheck();
            });
          } else {
            this.patchForm(data);
            this.isLoading.set(false);
            this.cdr.markForCheck();
          }
        },
        error: (err: any) => {
          console.error('Error loading student details', err);
          this.snackBar.open('Error loading student details', 'Close', { duration: 5000 });
          this.isLoading.set(false);
          this.cdr.markForCheck();
        }
      });
    }
  }

  private patchForm(data: StudentFullDetailsDto): void {
    this.studentForm.patchValue({
      id: data.id,
      firstName: data.firstName,
      lastName: data.lastName,
      dateOfBirth: data.dateOfBirth ? new Date(data.dateOfBirth).toISOString().split('T')[0] : '',
      gender: data.gender,
      address: data.address,
      contactNumber: data.contactNumber,
      email: data.email,
      admissionDate: data.admissionDate ? new Date(data.admissionDate).toISOString().split('T')[0] : '',
      academicYearId: data.academicYearId,
      classId: data.classId,
      sectionId: data.sectionId,
      rollNumber: data.rollNumber,
      scholarNumber: data.scholarNumber,
      parentId: data.parentId,
      busRouteId: data.busRouteId
    });

    if (data.addressInfo) this.studentForm.get('addressInfo')?.patchValue(data.addressInfo);
    if (data.academicHistory) this.studentForm.get('academicHistory')?.patchValue(data.academicHistory);
    if (data.medicalInfo) this.studentForm.get('medicalInfo')?.patchValue(data.medicalInfo);
    if (data.documentInfo) this.studentForm.get('documentInfo')?.patchValue(data.documentInfo);
    if (data.specialNeeds) this.studentForm.get('specialNeeds')?.patchValue(data.specialNeeds);
    if (data.hostelInfo) this.studentForm.get('hostelInfo')?.patchValue(data.hostelInfo);
    if (data.scholarshipInfo) this.studentForm.get('scholarshipInfo')?.patchValue(data.scholarshipInfo);
    if (data.newParentDetails) this.studentForm.get('newParentDetails')?.patchValue(data.newParentDetails);
  }

  onSelectStudent(student: StudentFullDetailsDto): void {
    this.router.navigate(['/app/students/full-details/edit', student.id]);
    this.searchResults.set([]);
    this.searchControl.setValue('');
  }

  onSubmit(): void {
    if (this.studentForm.valid) {
      this.isLoading.set(true);
      this.cdr.markForCheck();
      
      const formValue = this.studentForm.value;
      
      // Construct a clean DTO payload to ensure correct types
      const payload: StudentFullDetailsDto = {
        ...formValue,
        // Ensure booleans are explicitly boolean and not null/undefined
        addressInfo: formValue.addressInfo ? {
          ...formValue.addressInfo,
          sameAsPermanent: !!formValue.addressInfo.sameAsPermanent
        } : undefined,
        medicalInfo: formValue.medicalInfo ? {
          ...formValue.medicalInfo,
          hasAsthma: !!formValue.medicalInfo.hasAsthma,
          hasDiabetes: !!formValue.medicalInfo.hasDiabetes,
          hasHeartCondition: !!formValue.medicalInfo.hasHeartCondition,
          hasEpilepsy: !!formValue.medicalInfo.hasEpilepsy,
          isVaccinatedPolio: !!formValue.medicalInfo.isVaccinatedPolio,
          isVaccinatedMeasles: !!formValue.medicalInfo.isVaccinatedMeasles,
          isVaccinatedBCG: !!formValue.medicalInfo.isVaccinatedBCG,
          isVaccinatedTCV: !!formValue.medicalInfo.isVaccinatedTCV
        } : undefined,
        specialNeeds: formValue.specialNeeds ? {
          ...formValue.specialNeeds,
          hasSpecialNeeds: !!formValue.specialNeeds.hasSpecialNeeds
        } : undefined,
        hostelInfo: formValue.hostelInfo ? {
          ...formValue.hostelInfo,
          hostelRequired: !!formValue.hostelInfo.hostelRequired
        } : undefined,
        scholarshipInfo: formValue.scholarshipInfo ? {
          ...formValue.scholarshipInfo,
          eligibleForScholarship: !!formValue.scholarshipInfo.eligibleForScholarship
        } : undefined,
        // Ensure dates are valid
        dateOfBirth: new Date(formValue.dateOfBirth),
        admissionDate: new Date(formValue.admissionDate)
      };
      
      if (this.isEditMode() && this.studentId()) {
        this.studentManagementService.updateStudentFullDetails(this.studentId(), payload).subscribe({
          next: () => {
            this.snackBar.open('Student record updated successfully!', 'Close', { duration: 3000 });
            this.isLoading.set(false);
            this.cdr.markForCheck();
            this.router.navigate(['/app/students/full-details']);
          },
          error: (err) => {
            const errorMessage = this.getErrorMessage(err);
            this.snackBar.open(`Update failed: ${errorMessage}`, 'Close', { duration: 5000 });
            this.isLoading.set(false);
            this.cdr.markForCheck();
          }
        });
      } else {
        this.studentManagementService.createStudentFullDetails(payload).subscribe({
          next: (response: any) => {
            this.snackBar.open('Student admitted successfully!', 'Close', { duration: 3000 });
            this.isLoading.set(false);
            this.cdr.markForCheck();
            
            if (response.data?.id) {
              this.openFeeAssignmentDialog(response.data.id, `${payload.firstName} ${payload.lastName}`, payload.classId);
            } else {
              this.router.navigate(['/app/students/full-details']);
            }
          },
          error: (err) => {
            const errorMessage = this.getErrorMessage(err);
            this.snackBar.open(`Admission failed: ${errorMessage}`, 'Close', { duration: 5000 });
            this.isLoading.set(false);
            this.cdr.markForCheck();
          }
        });
      }
    } else {
      this.markFormGroupTouched(this.studentForm);
      this.snackBar.open('Please correct the errors in the form', 'Close', { duration: 4000 });
    }
  }

  private openFeeAssignmentDialog(studentId: number, studentName: string, classId?: number): void {
    const dialogRef = this.dialog.open(FeeAssignmentDialogComponent, {
        ...this.dialogUtils.getMobileConfig({ width: '600px', data: { studentId, studentName, classId } }),
            });

    dialogRef.afterClosed().subscribe(() => {
      this.router.navigate(['/app/students/full-details']);
    });
  }

  private markFormGroupTouched(formGroup: FormGroup): void {
    Object.values(formGroup.controls).forEach(control => {
      control.markAsTouched();
      if (control instanceof FormGroup) this.markFormGroupTouched(control);
    });
  }

  private getErrorMessage(error: any): string {
    return error.error?.message || error.message || 'An unexpected error occurred';
  }

  getInitials(firstName: string, lastName: string): string {
    return (firstName?.charAt(0) || '') + (lastName?.charAt(0) || '');
  }

  onCancel(): void {
    this.router.navigate(['/app/students/full-details']);
  }

  get submitButtonText(): string {
    return this.isEditMode() ? 'Save Changes' : 'Complete Admission';
  }
}
