import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnDestroy, OnInit, signal } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators, ReactiveFormsModule, FormArray } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { MatTabsModule } from '@angular/material/tabs';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatSelectModule } from '@angular/material/select';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatStepperModule } from '@angular/material/stepper';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatChipsModule } from '@angular/material/chips';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatListModule } from '@angular/material/list';
import { MatDividerModule } from '@angular/material/divider';
import { debounceTime, distinctUntilChanged, Subject, Subscription, Observable } from 'rxjs';
import { StudentManagementService } from '../../shared/services/student-management.service';
import { AdvancedAcademicService } from '../../services/advanced-academic.service';
import { AcademicYearContextService } from '../../shared/services/academic-year-context.service';
import { StudentFullDetailsDto, ParentDto, DocumentDto } from '../../shared/models/student-full-details-dto';
import { StudentPageHeaderComponent } from '../../shared/components/students-module/student-page-header.component';

@Component({
  selector: 'app-student-enterprise-form',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatTabsModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatSelectModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatCardModule,
    MatIconModule,
    MatCheckboxModule,
    MatTooltipModule,
    MatSnackBarModule,
    MatProgressSpinnerModule,
    MatDialogModule,
    MatStepperModule,
    MatExpansionModule,
    MatChipsModule,
    MatAutocompleteModule,
    MatListModule,
    MatDividerModule,
    StudentPageHeaderComponent
  ],
  templateUrl: './student-enterprise-form.component.html',
  styleUrls: ['./student-enterprise-form.component.scss']
})
export class StudentEnterpriseFormComponent implements OnInit, OnDestroy {
  studentForm!: FormGroup;
  isEditMode = signal(false);
  /** True when opened via the "View Details" action — the form is rendered read-only. */
  isViewMode: boolean = false;
  studentId: number | null = null;
  isLoading = signal(false);
  currentTabIndex: number = 0;

  // Search properties
  searchControl = new FormControl('');
  searchResults = signal<any[]>([]);
  activeSectionId = 'sec-personal';
  selectedStudent = signal<any>(null);
  isSearching = signal(false);
  private searchSubject = new Subject<string>();
  private subscriptions: Subscription = new Subscription();

  // Dropdown options
  academicYears = signal<any[]>([]);
  classes = signal<any[]>([]);
  sections = signal<any[]>([]);

  genders = ['Male', 'Female', 'Other'];
  boardTypes = ['CBSE', 'ICSE', 'State Board', 'Other'];
  bloodGroups = ['A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-'];
  disabilityTypes = ['None', 'Visual Impairment', 'Hearing Impairment', 'Physical Disability', 'Learning Disability', 'Autism Spectrum', 'Speech/Language Disorder'];
  disabilitySeverity = ['Mild', 'Moderate', 'Severe'];
  relationshipTypes = ['Mother', 'Father', 'Grandparent', 'Guardian', 'Aunt', 'Uncle', 'Sibling'];
  docTypes = ['Aadhar', 'Passport', 'Birth Certificate', 'PAN', 'Voter ID'];
  scholarshipTypes = ['Merit-based', 'Need-based', 'Sports', 'Minority', 'None'];
  behaviorRecords = ['Excellent', 'Good', 'Satisfactory', 'Poor'];
  enrollmentStatuses = ['Active', 'Suspended', 'Graduated', 'Transferred', 'On Leave'];
  
  religions = ['Hindu', 'Muslim', 'Christian', 'Sikh', 'Buddhist', 'Jain', 'Other'];
  casteCategories = ['General', 'OBC', 'SC', 'ST', 'EWS', 'Other'];

  // File upload properties
  uploadedDocuments: Array<{ fileName: string; fileSize: number; file: File; documentType?: string; fileContent?: string }> = [];

  constructor(
    private fb: FormBuilder,
    private route: ActivatedRoute,
    public router: Router,
    private studentManagementService: StudentManagementService,
    private academicService: AdvancedAcademicService,
    private snackBar: MatSnackBar,
    private cdr: ChangeDetectorRef,
    private dialog: MatDialog,
    private yearContext: AcademicYearContextService
  ) {}

  ngOnInit(): void {
    this.studentId = this.route.snapshot.params['id'];
    this.isEditMode.set(!!this.studentId);
    // "View Details" opens this same admission form read-only via route data.
    this.isViewMode = this.route.snapshot.data['mode'] === 'view';
    this.initForm();
    if (this.isViewMode) {
      // Disable every control so the whole form is read-only in view mode.
      this.studentForm.disable();
    }
    this.loadAcademicYears();

    // Set up debounced search
    const searchSub = this.searchSubject.pipe(
      debounceTime(300),
      distinctUntilChanged()
    ).subscribe(searchTerm => {
      this.performSearch(searchTerm);
    });
    this.subscriptions.add(searchSub);

    // Listen to search control changes
    const controlSub = this.searchControl.valueChanges.subscribe(value => {
      if (value) {
        this.searchSubject.next(value);
      } else {
        this.searchResults.set([]);
        this.selectedStudent.set(null);
      }
    });
    this.subscriptions.add(controlSub);      if (this.isEditMode()) {
      this.loadStudentDetails();
    }
  }

  /** Template helper — view mode is read-only and never shows editing actions. */
  get isReadOnly(): boolean {
    return this.isViewMode;
  }

  ngOnDestroy(): void {
    this.subscriptions.unsubscribe();
  }

  initForm(): void {
    this.studentForm = this.fb.group({
      // TAB 1: Personal Information
      personalInfo: this.fb.group({
        id: [null],
        scholarNumber: ['', [Validators.required]],
        firstName: ['', [Validators.required, Validators.minLength(2)]],
        lastName: ['', [Validators.required, Validators.minLength(2)]],
        dateOfBirth: ['', Validators.required],
        gender: ['', Validators.required],
        religion: [''],
        casteCategory: [''],
        photoPath: [''],
        email: ['', [Validators.required, Validators.email]],
        contactNumber: ['', [Validators.required, Validators.pattern(/^[0-9]{10}$/)]]
      }),

      // TAB 2: Structured Address
      address: this.fb.group({
        currentAddress: this.fb.group({
          houseNumber: [''],
          streetName: [''],
          city: ['', Validators.required],
          state: ['', Validators.required],
          postalCode: ['', [Validators.pattern(/^[0-9]{5,6}$/)]],
          country: ['India'],
          addressType: ['Residential']
        }),
        permanentAddress: this.fb.group({
          houseNumber: [''],
          streetName: [''],
          city: [''],
          state: [''],
          postalCode: ['', [Validators.pattern(/^[0-9]{5,6}$/)]],
          country: ['India'],
          addressType: ['Residential']
        }),
        sameAsCurrent: [false]
      }),

      // TAB 3: Academic Information
      academicInfo: this.fb.group({
        academicYearId: [null, Validators.required],
        classId: [null, Validators.required],
        sectionId: [null, Validators.required],
        rollNumber: ['', [Validators.required, Validators.minLength(1)]],
        admissionDate: [new Date(), Validators.required],
        enrollmentStatus: ['Active']
      }),

      // TAB 4: Academic History
      academicHistory: this.fb.group({
        previousSchoolName: [''],
        previousSchoolBoard: [''],
        previousSchoolAddress: [''],
        yearPassedFrom: [null],
        lastGradeAttended: [''],
        reasonForTransfer: [''],
        academicPercentage: [null, [Validators.min(0), Validators.max(100)]],
        transferCertificateNumber: [''],
        transferCertificateDate: [null]
      }),

      // TAB 5: Parent/Guardian Details
      parentInfo: this.fb.group({
        primaryParent: this.fb.group({
          id: [null],
          firstName: ['', Validators.required],
          lastName: ['', Validators.required],
          contactNumber: ['', [Validators.required, Validators.pattern(/^[0-9]{10}$/)]],
          email: ['', [Validators.required, Validators.email]],
          relationship: ['Father'],
          occupation: ['']
        }),
        secondaryParent: this.fb.group({
          firstName: [''],
          lastName: [''],
          contactNumber: ['', [Validators.pattern(/^[0-9]{10}$/)]],
          email: ['', [Validators.email]],
          relationship: ['Mother'],
          occupation: ['']
        })
      }),

      // TAB 6: Emergency Contact
      emergencyContact: this.fb.group({
        contactName: ['', Validators.required],
        relationship: ['', Validators.required],
        primaryPhone: ['', [Validators.required, Validators.minLength(8)]],
        secondaryPhone: [''],
        address: [''],
        preferredContactOrder: ['Parent']
      }),

      // TAB 7: Medical Information
      medicalInfo: this.fb.group({
        bloodGroup: [''],
        allergies: [''],
        medicalConditions: this.fb.group({
          asthma: [false],
          diabetes: [false],
          heartCondition: [false],
          epilepsy: [false],
          otherConditions: ['']
        }),
        vaccinations: this.fb.group({
          polio: [false],
          measles: [false],
          bcg: [false],
          tcv: [false],
          otherVaccines: ['']
        }),
        lastHealthCheckDate: [null],
        physicalDisability: ['None'],
        medicinesCurrent: ['']
      }),

      // TAB 8: Identity & Documents
      documents: this.fb.group({
        idProofType: ['Aadhar'],
        idProofNumber: ['', [Validators.required, Validators.minLength(2)]],
        idExpiryDate: [null],
        passportNumber: [''],
        birthCertificateNumber: [''],
        documentVerificationStatus: ['Pending'],
        verifiedBy: [''],
        verificationDate: [null],
        documentNotes: [''],
        documentCategory: ['ID Proof']
      }),

      // TAB 9: Special Needs (Optional)
      specialNeeds: this.fb.group({
        hasSpecialNeeds: [false],
        disabilityType: ['None'],
        disabilitySeverity: ['Mild'],
        auxiliaryAidsRequired: [''],
        specialResourcesNeeded: [''],
        iepDocumentPath: [''],
        parentConsentForSnE: [false]
      }),

      // TAB 10: Hostel Information (Optional)
      hostelInfo: this.fb.group({
        hostelRequired: [false],
        preferredHostel: [null],
        roomType: ['Single'],
        hostelAllocationDate: [null],
        hostelGuardianName: [''],
        hostelGuardianContact: ['', [Validators.pattern(/^[0-9]{10}$/)]],
        distanceFromHome: [null],
        travelMode: ['Bus']
      }),

      // TAB 11: Scholarship & Concession
      scholarshipInfo: this.fb.group({
        eligibleForScholarship: [false],
        scholarshipType: ['None'],
        scholarshipPercentage: [0, [Validators.min(0), Validators.max(100)]],
        scholarshipApplicationDate: [null],
        scholarshipApprovalDate: [null],
        concessionType: ['None'],
        concessionAmount: [0],
        concessionApprovedBy: ['']
      }),

      // TAB 12: Behavioral & Conduct + System Info
      behavioralInfo: this.fb.group({
        behaviorRecord: ['Excellent'],
        disciplinaryHistory: [''],
        lastDisciplinaryActionDate: [null],
        counselingSessionCount: [0],
        behavioralConcerns: [''],
        teacherNotes: [''],
        parentTeacherMeetingAttendance: [0]
      }),

      // System Fields
      systemInfo: this.fb.group({
        CreatedOn: [new Date()],
        lastModifiedDate: [new Date()],
        createdBy: ['System'],
        lastModifiedBy: ['System'],
        studentStatus: ['Active'],
        studentPortalUsername: [''],
        studentUniqueId: [this.generateUniqueId()]
      })
    });
  }

  loadAcademicYears(): void {
    this.yearContext.loadAcademicYears().subscribe({
      next: () => {
        this.academicYears.set(this.yearContext.yearsSnapshot as any[]);
        // Pre-fill form with selected year from context
        const selectedId = this.yearContext.selectedYearId;
        if (selectedId && !this.isEditMode()) {
          this.studentForm.get('academicInfo.academicYearId')?.setValue(selectedId);
          // Programmatic setValue() does not emit the template's (selectionChange)
          // event, so the class list must be loaded explicitly here. Otherwise the
          // Class dropdown stays empty whenever the year is auto-selected
          // (e.g. only one academic year exists).
          this.onAcademicYearChange(selectedId);
        }
        this.cdr.markForCheck();
      },
      error: () => {}
    });
  }

  onAcademicYearChange(yearId: number): void {
    if (yearId) {
      this.academicService.getClassesByAcademicYear(yearId).subscribe({
        next: (classes) => {
          this.classes.set(classes);
          this.sections.set([]);
          this.studentForm.get('academicInfo.classId')?.reset();
          this.studentForm.get('academicInfo.sectionId')?.reset();
          this.cdr.markForCheck();
        },
        error: (err) => {
          console.error('Error loading classes', err);
          this.classes.set([]);
        }
      });
    } else {
      this.classes.set([]);
      this.sections.set([]);
    }
  }

  onClassChange(classId: number): void {
    if (classId) {
      this.academicService.getSectionsByClass(classId).subscribe({
        next: (sections) => {
          this.sections.set(sections);
          this.studentForm.get('academicInfo.sectionId')?.reset();
          this.cdr.markForCheck();
        },
        error: (err) => {
          console.error('Error loading sections', err);
          this.sections.set([]);
        }
      });
    } else {
      this.sections.set([]);
    }
  }

  private generateUniqueId(): string {
    return 'STU-' + Date.now() + '-' + Math.random().toString(36).substr(2, 9);
  }

  loadStudentDetails(): void {
    if (this.studentId) {
      this.isLoading.set(true);
      this.cdr.markForCheck();

      this.studentManagementService.getStudentFullDetails(this.studentId).subscribe({
        next: (data: StudentFullDetailsDto) => {
          this.populateFormWithData(data);
          this.isLoading.set(false);
          this.cdr.markForCheck();
        },
        error: (err: any) => {
          console.error('Error loading student details', err);
          this.snackBar.open('Error loading student details', 'Close', { duration: 5000 });
          this.isLoading.set(false);
          this.cdr.markForCheck();
        }
      });
    }
  }

  private populateFormWithData(data: StudentFullDetailsDto): void {
    // Populate all tabs with existing data
    const personalForm = this.studentForm.get('personalInfo');
    if (personalForm) {
      personalForm.patchValue({
        id: data.id,
        scholarNumber: data.scholarNumber || '',
        firstName: data.firstName,
        lastName: data.lastName,
        dateOfBirth: data.dateOfBirth,
        gender: data.gender,
        religion: data.religion || '',
        casteCategory: data.casteCategory || '',
        photoPath: data.photoPath || '',
        email: data.email,
        contactNumber: data.contactNumber
      });
    }

    const academicForm = this.studentForm.get('academicInfo');
    if (academicForm) {
      if (data.academicYearId) {
        this.academicService.getClassesByAcademicYear(data.academicYearId).subscribe(classes => {
          this.classes.set(classes);
          if (data.classId) {
            this.academicService.getSectionsByClass(data.classId).subscribe(sections => {
              this.sections.set(sections);
              academicForm.patchValue({
                academicYearId: data.academicYearId,
                classId: data.classId,
                sectionId: data.sectionId,
                rollNumber: data.rollNumber,
                admissionDate: data.admissionDate,
                enrollmentStatus: data.enrollmentStatus || 'Active'
              });
              this.cdr.markForCheck();
            });
          } else {
            academicForm.patchValue({
              academicYearId: data.academicYearId,
              rollNumber: data.rollNumber,
              admissionDate: data.admissionDate,
              enrollmentStatus: data.enrollmentStatus || 'Active'
            });
            this.cdr.markForCheck();
          }
        });
      } else {
        academicForm.patchValue({
          rollNumber: data.rollNumber,
          admissionDate: data.admissionDate,
          enrollmentStatus: data.enrollmentStatus || 'Active'
        });
      }
    }

    if (data.newParentDetails) {
      const parentForm = this.studentForm.get('parentInfo');
      if (parentForm) {
        parentForm.patchValue({
          primaryParent: {
            id: data.newParentDetails.id,
            firstName: data.newParentDetails.firstName,
            lastName: data.newParentDetails.lastName,
            contactNumber: data.newParentDetails.contactNumber,
            email: data.newParentDetails.email,
            occupation: data.newParentDetails.occupation
          }
        });
      }
    }
    
    // Populating uploaded documents from fetched data
    if (data.documents && data.documents.length > 0) {
      this.uploadedDocuments = data.documents.map((doc: any) => ({
        fileName: doc.fileName || doc.filePath,
        fileSize: doc.fileSize || 0,
        file: null as any,
        documentType: doc.documentType,
        fileContent: doc.fileContent
      }));
      this.cdr.markForCheck();
    } else {
      this.uploadedDocuments = [];
    }

    if (data.addressInfo) {
      this.studentForm.get('address')?.patchValue({
        currentAddress: {
          houseNumber: data.addressInfo.currentHouseNumber,
          streetName: data.addressInfo.currentStreetName,
          city: data.addressInfo.currentCity,
          state: data.addressInfo.currentState,
          postalCode: data.addressInfo.currentPostalCode,
          country: data.addressInfo.currentCountry
        },
        permanentAddress: {
          houseNumber: data.addressInfo.permanentHouseNumber,
          streetName: data.addressInfo.permanentStreetName,
          city: data.addressInfo.permanentCity,
          state: data.addressInfo.permanentState,
          postalCode: data.addressInfo.permanentPostalCode,
          country: data.addressInfo.permanentCountry
        },
        sameAsCurrent: data.addressInfo.sameAsPermanent
      });
    }

    if (data.academicHistory) {
      this.studentForm.get('academicHistory')?.patchValue(data.academicHistory);
    }

    if (data.medicalInfo) {
      this.studentForm.get('medicalInfo')?.patchValue({
        bloodGroup: data.medicalInfo.bloodGroup,
        allergies: data.medicalInfo.knownAllergies,
        medicalConditions: {
          asthma: data.medicalInfo.hasAsthma,
          diabetes: data.medicalInfo.hasDiabetes,
          heartCondition: data.medicalInfo.hasHeartCondition,
          epilepsy: data.medicalInfo.hasEpilepsy,
          otherConditions: data.medicalInfo.otherMedicalConditions
        },
        vaccinations: {
          polio: data.medicalInfo.isVaccinatedPolio,
          bcg: data.medicalInfo.isVaccinatedBCG,
          measles: data.medicalInfo.isVaccinatedMeasles,
          tcv: data.medicalInfo.isVaccinatedTCV
        },
        lastHealthCheckDate: data.medicalInfo.lastHealthCheckDate,
        physicalDisability: data.medicalInfo.physicalDisability,
        medicinesCurrent: data.medicalInfo.currentMedicines
      });
    }

    if (data.documentInfo) {
      this.studentForm.get('documents')?.patchValue({
        idProofType: data.documentInfo.idProofType,
        idProofNumber: data.documentInfo.idProofNumber,
        idExpiryDate: data.documentInfo.idExpiryDate,
        passportNumber: data.documentInfo.passportNumber,
        birthCertificateNumber: data.documentInfo.birthCertificateNumber,
        documentVerificationStatus: data.documentInfo.documentVerificationStatus,
        verifiedBy: data.documentInfo.verifiedBy,
        verificationDate: data.documentInfo.verificationDate,
        documentNotes: data.documentInfo.documentNotes
      });
    }

    if (data.emergencyContact) {
      this.studentForm.get('emergencyContact')?.patchValue({
        contactName: data.emergencyContact.contactName,
        relationship: data.emergencyContact.relationship,
        primaryPhone: data.emergencyContact.primaryPhone,
        secondaryPhone: data.emergencyContact.secondaryPhone,
        address: data.emergencyContact.address,
        preferredContactOrder: data.emergencyContact.preferredContactOrder
      });
    }

    if (data.specialNeeds) {
      this.studentForm.get('specialNeeds')?.patchValue(data.specialNeeds);
    }

    if (data.hostelInfo) {
      this.studentForm.get('hostelInfo')?.patchValue(data.hostelInfo);
    }

    if (data.scholarshipInfo) {
      this.studentForm.get('scholarshipInfo')?.patchValue(data.scholarshipInfo);
    }

    if (data.behavioralInfo) {
      this.studentForm.get('behavioralInfo')?.patchValue(data.behavioralInfo);
    }

    if (data.systemInfo) {
      this.studentForm.get('systemInfo')?.patchValue(data.systemInfo);
    }
  }

  onSubmit(): void {
    console.log('🚀 Submit triggered. Form valid:', this.studentForm.valid);
    if (!this.studentForm.valid) {
      console.warn('⚠️ Form invalid. Errors:', this.getFormErrors(this.studentForm));
    }

    if (this.studentForm.valid) {
      this.isLoading.set(true);
      this.cdr.markForCheck();

      const formValue = this.studentForm.value;
      
      // Handle documents conversion if needed
      if (this.uploadedDocuments.some(d => d.file)) {
        this.convertDocumentsToBase64();
        return;
      }

      this.submitFinalPayload();
    } else {
      this.markFormGroupTouched(this.studentForm);
      this.snackBar.open('Please fill all required fields marked in red across all sections', 'Close', { duration: 5000 });
      this.cdr.markForCheck();
    }
  }

  private submitFinalPayload(): void {
    const formValue = this.studentForm.value;
    const currentAddr = formValue.address?.currentAddress || {};
    const permAddr = formValue.address?.permanentAddress || {};

    const payload: StudentFullDetailsDto = {
      id: formValue.personalInfo.id || 0,
      firstName: formValue.personalInfo.firstName,
      lastName: formValue.personalInfo.lastName,
      dateOfBirth: formValue.personalInfo.dateOfBirth,
      gender: formValue.personalInfo.gender,
      email: formValue.personalInfo.email,
      contactNumber: formValue.personalInfo.contactNumber,
      address: `${currentAddr.houseNumber || ''} ${currentAddr.streetName || ''}, ${currentAddr.city || ''}, ${currentAddr.state || ''}`.trim(),
      academicYearId: formValue.academicInfo.academicYearId,
      classId: formValue.academicInfo.classId,
      sectionId: formValue.academicInfo.sectionId,
      rollNumber: formValue.academicInfo.rollNumber,
      scholarNumber: formValue.personalInfo.scholarNumber,
      photoPath: formValue.personalInfo.photoPath,
      casteCategory: formValue.personalInfo.casteCategory,
      religion: formValue.personalInfo.religion,
      admissionDate: formValue.academicInfo.admissionDate,
      enrollmentStatus: formValue.academicInfo.enrollmentStatus,

      addressInfo: {
        currentHouseNumber: currentAddr.houseNumber || '',
        currentStreetName: currentAddr.streetName || '',
        currentCity: currentAddr.city || '',
        currentState: currentAddr.state || '',
        currentPostalCode: currentAddr.postalCode || '',
        currentCountry: currentAddr.country || 'India',
        permanentHouseNumber: permAddr.houseNumber || '',
        permanentStreetName: permAddr.streetName || '',
        permanentCity: permAddr.city || currentAddr.city || '',
        permanentState: permAddr.state || currentAddr.state || '',
        permanentPostalCode: permAddr.postalCode || '',
        permanentCountry: permAddr.country || 'India',
        sameAsPermanent: !!(formValue.address?.sameAsCurrent)
      },

      academicHistory: {
        previousSchoolName: formValue.academicHistory?.previousSchoolName || '',
        previousSchoolBoard: formValue.academicHistory?.previousSchoolBoard || '',
        previousSchoolAddress: formValue.academicHistory?.previousSchoolAddress || '',
        yearPassedFrom: this.toNumber(formValue.academicHistory?.yearPassedFrom),
        lastGradeAttended: formValue.academicHistory?.lastGradeAttended || '',
        academicPercentage: this.toNumber(formValue.academicHistory?.academicPercentage),
        transferCertificateNumber: formValue.academicHistory?.transferCertificateNumber || '',
        reasonForTransfer: formValue.academicHistory?.reasonForTransfer || ''
      },

      newParentDetails: {
        firstName: formValue.parentInfo.primaryParent.firstName || '',
        lastName: formValue.parentInfo.primaryParent.lastName || '',
        contactNumber: formValue.parentInfo.primaryParent.contactNumber || '',
        email: formValue.parentInfo.primaryParent.email || '',
        relationship: formValue.parentInfo.primaryParent.relationship || 'Father',
        occupation: formValue.parentInfo.primaryParent.occupation || ''
      },

      emergencyContact: {
        contactName: formValue.emergencyContact?.contactName || '',
        relationship: formValue.emergencyContact?.relationship || '',
        primaryPhone: formValue.emergencyContact?.primaryPhone || '',
        secondaryPhone: formValue.emergencyContact?.secondaryPhone || '',
        address: formValue.emergencyContact?.address || '',
        preferredContactOrder: formValue.emergencyContact?.preferredContactOrder || 'Parent'
      },

      medicalInfo: {
        bloodGroup: formValue.medicalInfo?.bloodGroup || '',
        lastHealthCheckDate: formValue.medicalInfo?.lastHealthCheckDate || null,
        knownAllergies: formValue.medicalInfo?.allergies || '',
        hasAsthma: !!(formValue.medicalInfo?.medicalConditions?.asthma),
        hasDiabetes: !!(formValue.medicalInfo?.medicalConditions?.diabetes),
        hasHeartCondition: !!(formValue.medicalInfo?.medicalConditions?.heartCondition),
        hasEpilepsy: !!(formValue.medicalInfo?.medicalConditions?.epilepsy),
        otherMedicalConditions: formValue.medicalInfo?.medicalConditions?.otherConditions || '',
        isVaccinatedPolio: !!(formValue.medicalInfo?.vaccinations?.polio),
        isVaccinatedBCG: !!(formValue.medicalInfo?.vaccinations?.bcg),
        isVaccinatedMeasles: !!(formValue.medicalInfo?.vaccinations?.measles),
        isVaccinatedTCV: !!(formValue.medicalInfo?.vaccinations?.tcv),
        physicalDisability: formValue.medicalInfo?.physicalDisability || '',
        currentMedicines: formValue.medicalInfo?.medicinesCurrent || ''
      },

      documentInfo: {
        idProofType: formValue.documents?.idProofType || '',
        idProofNumber: formValue.documents?.idProofNumber || '',
        idExpiryDate: formValue.documents?.idExpiryDate || null,
        passportNumber: formValue.documents?.passportNumber || '',
        birthCertificateNumber: formValue.documents?.birthCertificateNumber || '',
        documentVerificationStatus: formValue.documents?.documentVerificationStatus || 'Pending',
        verifiedBy: formValue.documents?.verifiedBy || '',
        verificationDate: formValue.documents?.verificationDate || null,
        documentNotes: formValue.documents?.documentNotes || ''
      },

      specialNeeds: {
        hasSpecialNeeds: !!(formValue.specialNeeds?.hasSpecialNeeds),
        disabilityType: formValue.specialNeeds?.disabilityType || '',
        disabilitySeverity: formValue.specialNeeds?.disabilitySeverity || '',
        auxiliaryAidsRequired: formValue.specialNeeds?.auxiliaryAidsRequired || '',
        specialResourcesNeeded: formValue.specialNeeds?.specialResourcesNeeded || '',
        iepDocumentPath: formValue.specialNeeds?.iepDocumentPath || '',
        parentConsentForSnE: !!(formValue.specialNeeds?.parentConsentForSnE)
      },

      hostelInfo: {
        hostelRequired: !!(formValue.hostelInfo?.hostelRequired),
        preferredHostel: formValue.hostelInfo?.preferredHostel || '',
        roomType: formValue.hostelInfo?.roomType || '',
        travelMode: formValue.hostelInfo?.travelMode || '',
        distanceFromHome: this.toNumber(formValue.hostelInfo?.distanceFromHome),
        hostelGuardianName: formValue.hostelInfo?.hostelGuardianName || '',
        hostelGuardianContact: formValue.hostelInfo?.hostelGuardianContact || '',
        hostelAllocationDate: formValue.hostelInfo?.hostelAllocationDate || null
      },

      scholarshipInfo: {
        eligibleForScholarship: !!(formValue.scholarshipInfo?.eligibleForScholarship),
        scholarshipType: formValue.scholarshipInfo?.scholarshipType || '',
        scholarshipPercentage: this.toNumber(formValue.scholarshipInfo?.scholarshipPercentage),
        scholarshipApplicationDate: formValue.scholarshipInfo?.scholarshipApplicationDate || null,
        scholarshipApprovalDate: formValue.scholarshipInfo?.scholarshipApprovalDate || null,
        concessionType: formValue.scholarshipInfo?.concessionType || '',
        concessionAmount: this.toNumber(formValue.scholarshipInfo?.concessionAmount),
        concessionApprovedBy: formValue.scholarshipInfo?.concessionApprovedBy || ''
      },

      behavioralInfo: {
        behaviorRecord: formValue.behavioralInfo?.behaviorRecord || '',
        counselingSessionCount: this.toNumber(formValue.behavioralInfo?.counselingSessionCount),
        disciplinaryHistory: formValue.behavioralInfo?.disciplinaryHistory || '',
        lastDisciplinaryActionDate: formValue.behavioralInfo?.lastDisciplinaryActionDate || null,
        parentTeacherMeetingAttendance: this.toNumber(formValue.behavioralInfo?.parentTeacherMeetingAttendance),
        behavioralConcerns: formValue.behavioralInfo?.behavioralConcerns || '',
        teacherNotes: formValue.behavioralInfo?.teacherNotes || ''
      },

      systemInfo: {
        studentUniqueId: formValue.systemInfo?.studentUniqueId || this.generateUniqueId(),
        studentPortalUsername: formValue.systemInfo?.studentPortalUsername || '',
        studentStatus: formValue.systemInfo?.studentStatus || 'Active',
        CreatedOn: formValue.systemInfo?.CreatedOn || new Date(),
        lastModifiedDate: new Date(),
        createdBy: formValue.systemInfo?.createdBy || 'System',
        modifiedBy: 'System'
      },

      documents: this.uploadedDocuments.length > 0 
        ? this.uploadedDocuments.map(doc => ({
            documentType: doc.documentType || 'Document',
            fileName: doc.fileName,
            filePath: doc.fileName,
            fileContent: doc.fileContent,
            fileSize: doc.fileSize,
            uploadDate: new Date()
          } as DocumentDto))
        : undefined
    };

    const action: Observable<any> = this.isEditMode() 
      ? this.studentManagementService.updateStudentFullDetails(this.studentId!, payload)
      : this.studentManagementService.createStudentFullDetails(payload);

    action.subscribe({
      next: () => {
        this.snackBar.open(`Student ${this.isEditMode() ? 'updated' : 'created'} successfully!`, 'Close', { duration: 5000 });
        this.isLoading.set(false);
        this.cdr.markForCheck();
        setTimeout(() => this.router.navigate(['/app/students']), 1500);
      },
      error: (err: any) => {
        console.error('Error saving student:', err);
        this.snackBar.open('Error saving student details', 'Close', { duration: 5000 });
        this.isLoading.set(false);
        this.cdr.markForCheck();
      }
    });
  }

  getFileIcon(fileName: string): string {
    if (!fileName) return 'insert_drive_file';
    const extension = fileName.split('.').pop()?.toLowerCase();
    switch (extension) {
      case 'pdf': return 'picture_as_pdf';
      case 'doc':
      case 'docx': return 'description';
      case 'jpg':
      case 'jpeg':
      case 'png': return 'image';
      default: return 'insert_drive_file';
    }
  }

  private toNumber(value: any): number | undefined {
    if (value === null || value === undefined || value === '') return undefined;
    const num = Number(value);
    return isNaN(num) ? undefined : num;
  }

  private performSearch(searchTerm: string): void {
    if (searchTerm.length < 2) {
      this.searchResults.set([]);
      this.cdr.markForCheck();
      return;
    }

    this.isSearching.set(true);
    this.cdr.markForCheck();

    this.studentManagementService.getAllStudentFullDetails(searchTerm, 1, 10).subscribe({
      next: (data: any) => {
        this.searchResults.set(data.items || data || []);
        this.isSearching.set(false);
        this.cdr.markForCheck();
      },
      error: () => {
        this.searchResults.set([]);
        this.isSearching.set(false);
        this.cdr.markForCheck();
      }
    });
  }

  private async convertDocumentsToBase64(): Promise<void> {
    try {
      for (const doc of this.uploadedDocuments) {
        if (doc.file) {
          doc.fileContent = await this.fileToBase64(doc.file);
        }
      }
      this.submitFinalPayload();
    } catch (error) {
      this.snackBar.open('Error processing files', 'Close', { duration: 5000 });
      this.isLoading.set(false);
      this.cdr.markForCheck();
    }
  }

  private fileToBase64(file: File): Promise<string> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve((reader.result as string).split(',')[1]);
      reader.onerror = error => reject(error);
      reader.readAsDataURL(file);
    });
  }

  onFileSelected(event: Event): void {
    const files = (event.target as HTMLInputElement).files;
    if (!files) return;

    Array.from(files).forEach(file => {
      if (this.uploadedDocuments.length < 10 && file.size <= 10 * 1024 * 1024) {
        if (!this.uploadedDocuments.some(d => d.fileName === file.name)) {
          this.uploadedDocuments.push({ fileName: file.name, fileSize: file.size, file: file, documentType: 'Document' });
        }
      }
    });
    this.cdr.markForCheck();
  }

  removeDocument(index: number): void {
    this.uploadedDocuments.splice(index, 1);
    this.cdr.markForCheck();
  }

  async onPhotoSelected(event: Event): Promise<void> {
    const file = (event.target as HTMLInputElement).files?.[0];
    if (!file) return;

    if (file.size > 2 * 1024 * 1024) {
      this.snackBar.open('Photo size should be less than 2MB', 'Close', { duration: 3000 });
      return;
    }

    try {
      const base64 = await this.fileToBase64(file);
      this.studentForm.get('personalInfo.photoPath')?.setValue(`data:${file.type};base64,${base64}`);
      this.cdr.markForCheck();
    } catch (error) {
      this.snackBar.open('Error processing photo', 'Close', { duration: 3000 });
    }
  }

  formatFileSize(bytes: number): string {
    if (bytes === 0) return '0 Bytes';
    const k = 1024, sizes = ['Bytes', 'KB', 'MB'], i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  }

  getTabTitle(index: number): string {
    return ['Personal', 'Address', 'Academic', 'History', 'Parents', 'Emergency', 'Medical', 'Documents', 'Special Needs', 'Hostel', 'Scholarship', 'System'][index] || '';
  }

  /** Scroll a section into view inside the layout's .content-viewport scroller.
   *  Uses scrollIntoView with a block offset via scroll-margin-top (set in SCSS);
   *  never touches the URL, so the Angular Router stays untouched. */
  scrollToSection(sectionId: string): void {
    this.activeSectionId = sectionId;
    const el = document.getElementById(sectionId);
    el?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  onCancel(): void { this.router.navigate(['/app/students']); }
  nextTab(): void { this.currentTabIndex = Math.min(this.currentTabIndex + 1, 11); this.cdr.markForCheck(); }
  previousTab(): void { this.currentTabIndex = Math.max(this.currentTabIndex - 1, 0); this.cdr.markForCheck(); }

  isStepInvalid(stepIndex: number): boolean {
    if (!this.studentForm) return false;

    switch (stepIndex) {
      case 0: // Personal
        return (this.studentForm.get('personalInfo')?.invalid || this.studentForm.get('address')?.invalid) ?? false;
      case 1: // Academic
        return (this.studentForm.get('academicInfo')?.invalid || this.studentForm.get('academicHistory')?.invalid) ?? false;
      case 2: // Family
        return (this.studentForm.get('parentInfo')?.invalid || this.studentForm.get('emergencyContact')?.invalid) ?? false;
      case 3: // Health
        return (this.studentForm.get('medicalInfo')?.invalid || this.studentForm.get('specialNeeds')?.invalid) ?? false;
      case 4: // Logistics
        return (this.studentForm.get('documents')?.invalid || this.studentForm.get('hostelInfo')?.invalid || this.studentForm.get('scholarshipInfo')?.invalid) ?? false;
      case 5: // Finish
        return (this.studentForm.get('behavioralInfo')?.invalid || this.studentForm.get('systemInfo')?.invalid) ?? false;
      default:
        return false;
    }
  }

  /** Trimmed applicant display name for the verified band. */
  applicantName(): string {
    const first = (this.studentForm?.get('personalInfo.firstName')?.value ?? '') as string;
    const last = (this.studentForm?.get('personalInfo.lastName')?.value ?? '') as string;
    return `${first} ${last}`.trim();
  }

  /** “Grade X • YYYY–YY” context line under the applicant name. */
  personalSummaryLine(): string {
    const cls = (this.studentForm?.get('academicInfo.className')?.value ?? '') as string;
    const yearId = this.studentForm?.get('academicInfo.academicYearId')?.value;
    const yearName = yearId ? (this.yearContext?.yearsSnapshot ?? []).find((y: any) => String(y.id) === String(yearId))?.name : null;
    const parts = [cls, yearName].filter(Boolean);
    return parts.length ? parts.join(' • ') : 'Personal details';
  }

  private getFormErrors(form: FormGroup | FormArray): any {
    const errors: any = {};
    Object.keys(form.controls).forEach(key => {
      const control = (form.controls as any)[key];
      if (control instanceof FormGroup || control instanceof FormArray) {
        errors[key] = this.getFormErrors(control);
      } else if (control.errors) {
        errors[key] = control.errors;
      }
    });
    return errors;
  }

  private markFormGroupTouched(formGroup: FormGroup) {
    Object.values(formGroup.controls).forEach(control => {
      control.markAsTouched();
      if (control instanceof FormGroup) {
        this.markFormGroupTouched(control);
      } else if (control instanceof FormControl) {
        control.markAsTouched();
      }
    });
  }

  onSelectStudent(student: StudentFullDetailsDto): void {
    this.selectedStudent.set(student);
    this.searchControl.setValue('', { emitEvent: false });
    this.searchResults.set([]);
    
    if (student) {
      this.studentId = student.id;
      this.isEditMode.set(true);
      this.populateFormWithData(student);
      this.cdr.markForCheck();
    }
  }
}
