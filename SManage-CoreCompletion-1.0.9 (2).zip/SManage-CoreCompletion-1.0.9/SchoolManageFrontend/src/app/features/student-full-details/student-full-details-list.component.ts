import { ChangeDetectorRef, Component, OnDestroy, OnInit, signal } from '@angular/core';
import { StudentFullDetailsDto } from '../../shared/models/student-full-details-dto';
import { StudentManagementService } from '../../shared/services/student-management.service';
import { Router, NavigationEnd } from '@angular/router';

import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatTableModule } from '@angular/material/table';
import { MatIconModule } from '@angular/material/icon';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatChipsModule } from '@angular/material/chips';
import { MatMenuModule } from '@angular/material/menu';
import { MatDialogModule } from '@angular/material/dialog';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSortModule } from '@angular/material/sort';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatDividerModule } from '@angular/material/divider';
import { RouterModule } from '@angular/router';
import { ReactiveFormsModule, FormControl } from '@angular/forms';
import { CanWriteDirective, CanDeleteDirective } from '../../core/directives/permission.directive';
import { Permission } from '../../core/models/permission.model';
import { Observable, combineLatest, BehaviorSubject, Subscription } from 'rxjs';
import { map, startWith, debounceTime, distinctUntilChanged, filter } from 'rxjs/operators';
import { StudentPageHeaderComponent } from '../../shared/components/students-module/student-page-header.component';
import { StudentKpiCardComponent } from '../../shared/components/students-module/student-kpi-card.component';

@Component({
  selector: 'app-student-full-details-list',
  standalone: true,
  imports: [
    CommonModule, 
    MatCardModule, 
    MatButtonModule, 
    MatTableModule, 
    MatIconModule, 
    MatFormFieldModule, 
    MatInputModule, 
    MatSelectModule, 
    MatChipsModule, 
    MatMenuModule, 
    MatDialogModule, 
    MatSnackBarModule, 
    MatPaginatorModule, 
    MatSortModule, 
    MatProgressSpinnerModule,
    MatProgressBarModule, 
    MatTooltipModule, 
    MatDatepickerModule,
    MatDividerModule,
    RouterModule, 
    ReactiveFormsModule,
    CanWriteDirective,
    CanDeleteDirective,
    StudentPageHeaderComponent,
    StudentKpiCardComponent
  ],
  templateUrl: './student-full-details-list.component.html',
  styleUrls: ['./student-full-details-list.component.scss']
})
export class StudentFullDetailsListComponent implements OnInit, OnDestroy {
  // Expose Permission enum to template for permission directives
  Permission = Permission;

  private studentsSubject = new BehaviorSubject<StudentFullDetailsDto[]>([]);
  students$ = this.studentsSubject.asObservable();
  filteredStudents$?: Observable<StudentFullDetailsDto[]>;
  
  stats$ = this.students$.pipe(
    map(students => {
      const total = students.length;
      const male = students.filter(s => s.gender === 'Male').length;
      const female = students.filter(s => s.gender === 'Female').length;
      // Real status from backend (issue #7) — no longer assume everyone is active
      const active = students.filter(s =>
        (s.status ? s.status === 'Active' : (s.isActive ?? true))
      ).length;

      return {
        total,
        male,
        female,
        active,
        malePercentage: total > 0 ? Math.round((male / total) * 100) : 0,
        femalePercentage: total > 0 ? Math.round((female / total) * 100) : 0,
        activePercentage: total > 0 ? Math.round((active / total) * 100) : 0
      };
    })
  );
  
  displayedColumns: string[] = ['student', 'class', 'rollNumber', 'parent', 'contact', 'status', 'actions'];
  
  // Table view is the default on all screen sizes; users can switch to cards.
  viewMode: 'card' | 'table' = 'table';
  isLoading = signal(false);
  
  // Filter Controls
  searchControl = new FormControl('');
  classFilterControl = new FormControl('');
  statusFilterControl = new FormControl('');
  genderFilterControl = new FormControl('');
  
  // Student Data - loaded dynamically from students
  classes = signal<any[]>([]);
  studentStatuses = ['Active', 'Inactive', 'Suspended', 'Graduated', 'Transferred'];
  genders = ['Male', 'Female', 'Other'];

  private routerSubscription?: Subscription;

  constructor(
    private studentManagementService: StudentManagementService, 
    public router: Router,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    // Setup filtering first so it's ready when data loads
    this.setupFiltering();
    
    // Then load initial data
    this.loadStudents();
    
    // Listen to router events to refresh data when navigating back to this component
    this.routerSubscription = this.router.events
      .pipe(filter(event => event instanceof NavigationEnd))
      .subscribe((event: NavigationEnd) => {
        // If navigating to this component's route, refresh the data
        if (event.url.includes('/app/students/full-details') && event.url === '/app/students/full-details') {
          console.log('🔄 Navigation detected, refreshing student list...');
          this.loadStudents();
        }
      });
  }

  ngOnDestroy(): void {
    this.routerSubscription?.unsubscribe();
  }

  refreshStudentList(): void {
    console.log('🔄 Manually refreshing student list...');
    this.loadStudents();
  }

  loadStudents(): void {
    this.isLoading.set(true);
    console.log('👨‍🎓 Loading student full details list...');
    
    this.studentManagementService.getAllStudentFullDetails().subscribe({
      next: (data) => {
        console.log('👨‍🎓 Student full details loaded successfully:', data);
        const studentsArray = Array.isArray(data) ? data : [];
        this.studentsSubject.next(studentsArray);
        // Populate class filter options dynamically from actual student data
        this.classes.set([...new Set(studentsArray.map(s => s.className).filter((c): c is string => !!c))]);
        this.isLoading.set(false);
        this.cdr.markForCheck();
      },
      error: (err) => {
        console.error('❌ Error loading student full details:', err);
        this.studentsSubject.next([]);
        this.isLoading.set(false);
        this.cdr.markForCheck();
      }
    });
  }

  setupFiltering(): void {
    this.filteredStudents$ = combineLatest([
      this.students$,
      this.searchControl.valueChanges.pipe(startWith(''), debounceTime(300), distinctUntilChanged()),
      this.classFilterControl.valueChanges.pipe(startWith('')),
      this.statusFilterControl.valueChanges.pipe(startWith('')),
      this.genderFilterControl.valueChanges.pipe(startWith(''))
    ]).pipe(
      map(([students, search, classFilter, status, gender]) => {
        return students.filter(student => {
          const matchesSearch = !search || 
            student.firstName?.toLowerCase().includes(search.toLowerCase()) ||
            student.lastName?.toLowerCase().includes(search.toLowerCase()) ||
            student.rollNumber?.toLowerCase().includes(search.toLowerCase()) ||
            student.email?.toLowerCase().includes(search.toLowerCase());
          
          const matchesClass = !classFilter || student.className === classFilter;
          
          const matchesStatus = !status || (student.status || 'Active') === status; // Real status now flows from the backend DTO (issue #7)
          const matchesGender = !gender || student.gender === gender;

          return matchesSearch && matchesClass && matchesStatus && matchesGender;
        });
      })
    );
  }

  // View Methods
  toggleView(mode: 'card' | 'table') {
    this.viewMode = mode;
  }

  clearFilters() {
    this.searchControl.setValue('');
    this.classFilterControl.setValue('');
    this.statusFilterControl.setValue('');
    this.genderFilterControl.setValue('');
  }

  // Student Actions
  editStudent(student: StudentFullDetailsDto): void {
    // Open the main Student Admission Form (enterprise form) in edit mode.
    // It supports loading existing data via the :id route param.
    this.router.navigate(['/app/students/full-details/enterprise/edit', student.id]);
  }

  deleteStudent(student: StudentFullDetailsDto): void {
    if (confirm(`Are you sure you want to delete student ${student.firstName} ${student.lastName}?`)) {
      this.studentManagementService.deleteStudentFullDetails(student.id!).subscribe(() => {
        this.loadStudents(); // Reload students after deletion
      });
    }
  }

  viewStudentProfile(student: StudentFullDetailsDto): void {
    this.router.navigate(['/app/students/full-details/view', student.id]);
  }

  contactParent(student: StudentFullDetailsDto): void {
    console.log('Contact parent for student:', student);
  }

  generateReport(student: StudentFullDetailsDto): void {
    console.log('Generate report for student:', student);
  }

  markAttendance(student: StudentFullDetailsDto): void {
    console.log('Mark attendance for student:', student);
  }

  // Helper Methods
  getStatusColor(status: string): string {
    switch (status?.toLowerCase()) {
      case 'active': return 'var(--md-success)';
      case 'inactive': return 'var(--color-text-secondary)';
      case 'suspended': return 'var(--md-error)';
      case 'graduated': return 'var(--md-primary-light)';
      case 'transferred': return 'var(--md-warning)';
      default: return 'var(--color-text-secondary)';
    }
  }

  getStatusChipClass(status: string): string {
    return status?.toLowerCase() || 'inactive';
  }

  getStudentAge(dateOfBirth: string): number {
    if (!dateOfBirth) return 0;
    const today = new Date();
    const birthDate = new Date(dateOfBirth);
    let age = today.getFullYear() - birthDate.getFullYear();
    const monthDiff = today.getMonth() - birthDate.getMonth();
    
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    
    return age;
  }

  getGenderIcon(gender: string): string {
    switch (gender?.toLowerCase()) {
      case 'male': return 'boy';
      case 'female': return 'girl';
      default: return 'person';
    }
  }

  formatPhoneNumber(phone: string): string {
    if (!phone) return 'N/A';
    // Format phone number (adjust based on your locale)
    return phone.replace(/(\d{3})(\d{3})(\d{4})/, '($1) $2-$3');
  }

  getInitials(firstName: string, lastName: string): string {
    const first = firstName ? firstName.charAt(0).toUpperCase() : '';
    const last = lastName ? lastName.charAt(0).toUpperCase() : '';
    return first + last;
  }
}
