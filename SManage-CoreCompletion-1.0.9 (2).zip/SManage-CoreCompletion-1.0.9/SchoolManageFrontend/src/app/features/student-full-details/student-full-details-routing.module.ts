import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { StudentFullDetailsListComponent } from './student-full-details-list.component';
import { StudentFullDetailsComponent } from './student-full-details.component';
import { StudentEnterpriseFormComponent } from './student-enterprise-form.component';

const routes: Routes = [
  { path: '', component: StudentFullDetailsListComponent },
  { path: 'add', component: StudentFullDetailsComponent },
  // Edit always opens the main Student Admission Form (enterprise form) in edit
  // mode — the :id param makes it load the existing student data.
  { path: 'edit/:id', component: StudentEnterpriseFormComponent },
  // View opens the main admission (enterprise) form in read-only mode.
  { path: 'view/:id', component: StudentEnterpriseFormComponent, data: { mode: 'view' } },
  { path: 'enterprise/add', component: StudentEnterpriseFormComponent },
  { path: 'enterprise/edit/:id', component: StudentEnterpriseFormComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class StudentFullDetailsRoutingModule { }
