import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';

import { StudentFullDetailsRoutingModule } from './student-full-details-routing.module';
import { StudentFullDetailsComponent } from './student-full-details.component';
import { StudentFullDetailsListComponent } from './student-full-details-list.component';
import { StudentEnterpriseFormComponent } from './student-enterprise-form.component';


@NgModule({
  imports: [
    CommonModule,
    ReactiveFormsModule,
    StudentFullDetailsRoutingModule,
    StudentFullDetailsComponent,
    StudentFullDetailsListComponent,
    StudentEnterpriseFormComponent
  ]
})
export class StudentFullDetailsModule { }
