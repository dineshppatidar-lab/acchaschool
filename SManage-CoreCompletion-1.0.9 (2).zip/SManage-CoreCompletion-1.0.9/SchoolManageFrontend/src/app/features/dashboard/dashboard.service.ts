import { inject, Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of, delay } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class DashboardService {
   private http = inject(HttpClient);

  getDashboardData(): Observable<any> {
    return this.http.get<any>('/api/dashboard');
  }
}
