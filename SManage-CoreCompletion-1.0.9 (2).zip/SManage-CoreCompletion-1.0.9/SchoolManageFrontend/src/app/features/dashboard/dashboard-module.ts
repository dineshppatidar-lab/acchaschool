import { NgModule } from '@angular/core';
import { CommonModule, DecimalPipe, CurrencyPipe } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatListModule } from '@angular/material/list';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatButtonModule } from '@angular/material/button';
import { MatInputModule } from '@angular/material/input';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatFormFieldModule } from '@angular/material/form-field';
// import { NgChartsModule } from 'ng2-charts'; // Commented out due to import error
// import { ChartsModule } from 'ng2-charts'; // Commented out due to import error
import { DashboardRoutingModule } from './dashboard-routing.module';

import { DashboardComponent } from './dashboard.component';
import { AnalyticsWidgetsComponent } from './analytics-widgets.component';
import { AssistantChatComponent } from './assistant-chat.component';
// import { ActivityFeedComponent } from './activity-feed.component'; // Uncomment if exists
import { DashboardService } from './dashboard.service';

@NgModule({
  
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule,
    MatCardModule,
    MatListModule,
    MatIconModule,
    MatProgressSpinnerModule,
    MatToolbarModule,
    MatButtonModule,
    MatInputModule,
    MatTooltipModule,
    MatFormFieldModule,
    // NgChartsModule, // Commented out due to import error
    // ChartsModule,   // Commented out due to import error
    DashboardRoutingModule,
    DashboardComponent,
    AnalyticsWidgetsComponent,
    AssistantChatComponent
  ],
  providers: [DashboardService, DecimalPipe, CurrencyPipe],
  exports: [DashboardComponent]
})
export class DashboardModule { }
