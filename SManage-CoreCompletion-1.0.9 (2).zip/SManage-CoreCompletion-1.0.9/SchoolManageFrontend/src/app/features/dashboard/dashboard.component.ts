import { ChangeDetectorRef, Component, OnDestroy, OnInit, inject, signal } from '@angular/core';
import { DashboardService } from './dashboard.service';
import { RouterModule } from '@angular/router';

import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatChipsModule } from '@angular/material/chips';
import { MatBadgeModule } from '@angular/material/badge';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatDividerModule } from '@angular/material/divider';
import { SetupProgressCardComponent } from './setup-progress-card.component';
import { SetupStatusService } from '../../core/services/setup-status.service';
import { CanWriteDirective } from '../../core/directives/permission.directive';
import { Permission } from '../../core/models/permission.model';
import { AcademicYearContextService, AcademicYearItem } from '../../shared/services/academic-year-context.service';
import { AuthService } from '../../services/auth.service';
import { DynamicMenuService, MenuItem } from '../../services/dynamic-menu.service';
import { menuAuthorizesRoute } from '../../layout/main-layout.component';
import { interval, Subscription } from 'rxjs';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [
    CommonModule,
    RouterModule,
    FormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatCardModule,
    MatButtonModule,
    MatIconModule,
    MatProgressSpinnerModule,
    MatChipsModule,
    MatBadgeModule,
    MatTooltipModule,
    MatDividerModule,
    HttpClientModule,
    SetupProgressCardComponent
  ],
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit, OnDestroy {
  Permission = Permission;
  private yearContext = inject(AcademicYearContextService);
  private auth = inject(AuthService);
  private menuService = inject(DynamicMenuService);

  /** Permission-filtered menu tree served by the backend — the same source the
   *  sidebar and bottom nav render. Stat-card shortcuts that navigate to a
   *  protected module are only rendered when this tree authorizes their route,
   *  so an unauthorized module never shows a shortcut that ends in an
   *  "access denied" page. */
  private readonly menuTree = signal<MenuItem[]>([]);

  /** True when the effective-permission menu authorizes the given shortcut route. */
  shortcutAuthorized(route: string): boolean {
    return menuAuthorizesRoute(this.menuTree(), route);
  }

  kpis: any = {
    students: 0, staff: 0, presentToday: 0, staffPresentToday: 0,
    attendance: 0, fees: 0, todayCollection: 0, outstanding: 0, overdueFees: 0
  };
  charts: any = {
    admissions: { labels: [], values: [] },
    feeCollection: { labels: [], values: [] },
    attendanceTrend: { labels: [], values: [] }
  };
  announcements = signal<any[]>([]);
  upcomingEvents = signal<any[]>([]);
  notifications = signal<any[]>([]);
  loading = signal(false);
  currentDate = new Date();
  currentTime = new Date();

  // Academic year selection lives in the app header (main-layout), so the
  // dashboard no longer binds its own selector.
  selectedYearId = signal<any>(null);

  /** Signed-in user for the header greeting; read-only from AuthService. */
  readonly user = signal<any>(null);

  private timeSubscription?: Subscription;

  /** Display name for the subtitle (falls back to the generic line). */
  userProfile(): any { return this.user(); }

  /** Selected academic-year label for the header context pill. */
  yearLabel(): string {
    const id = this.selectedYearId();
    if (id == null) return '';
    return (this.yearContext.yearsSnapshot ?? [])
      .find(y => String(y.id) === String(id))?.name ?? '';
  }

  /**
   * First unread urgent/high-priority notification for the hero banner,
   * as in the reference design (reference-design priority alert pattern).
   */
  priorityAlert(): any | null {
    const urgent = this.notifications().find(n => {
      const t = String(n?.type ?? '').toLowerCase();
      const p = String(n?.priority ?? '').toLowerCase();
      return ((t.includes('urgent') || t.includes('alert') || t.includes('critical')) || p === 'high' || p === 'urgent'
        || p === 'important' || p === 'medium') && !n.dismissed;
    });
    return urgent ?? null;
  }

  constructor(
    private dashboardService: DashboardService,
    private cdr: ChangeDetectorRef,
    public setupStatus: SetupStatusService
  ) {}

  ngOnInit(): void {
    this.startTimeUpdater();

    // Drive shortcut visibility from the shared permission-filtered menu.
    this.menuService.mainMenu$.subscribe(menu => {
      if (menu && menu.length > 0) { this.menuTree.set(menu); }
    });
    this.menuService.loadMainMenu().subscribe({ error: () => { /* menu stays empty → shortcuts stay hidden */ } });

    // Onboarding card: reuse the cached setup status (loaded once per session
    // by the main layout; this is a no-op if already fetched).
    this.setupStatus.load();

    // Current user for the greeting
    const user = this.auth.user ?? this.auth.getCurrentUser();
    this.user.set(user);

    this.yearContext.academicYears$.subscribe(_ => {
      this.selectedYearId.set(this.yearContext.selectedYearId);
      this.cdr.detectChanges();
    });
    this.yearContext.loadAcademicYears().subscribe();

    setTimeout(() => this.loadDashboard());
  }

  loadDashboard() {
    this.loading.set(true);
    this.cdr.detectChanges();

    this.dashboardService.getDashboardData().subscribe({
      next: (res) => {
        const data = res?.data ?? res ?? {};
        this.kpis = { ...this.kpis, ...(data.kpis ?? {}) };
        this.charts = data.charts ?? this.charts;
        this.announcements.set(data.announcements ?? []);
        this.upcomingEvents.set(data.upcomingEvents ?? []);
        this.notifications.set((data.notifications ?? []).map((n: any) => ({
          ...n,
          timestamp: n.timestamp ? new Date(n.timestamp) : new Date(),
          type: n.type || 'info',
          priority: n.priority || 'low'
        })));
        this.loading.set(false);
        this.cdr.detectChanges();
      },
      error: (err) => {
        console.error('Error loading dashboard data', err);
        this.loading.set(false);
        this.cdr.detectChanges();
      }
    });
  }

  onYearChange(yearId: number) {
    this.selectedYearId.set(yearId);
    this.yearContext.setYear(yearId);
    // Re-pull to reflect any year-scoped data
    this.loadDashboard();
  }

  /** Kept for backward compatibility; the selector itself is rendered in the app header. */
  getAcademicYears(): AcademicYearItem[] {
    return this.yearContext.yearsSnapshot;
  }

  /** Max of a numeric series – used to scale CSS bar charts */
  maxOf(values: number[]): number {
    return Math.max(1, ...(values ?? []).map(v => Number(v) || 0));
  }

  formatMoney(v: number): string {
    const n = Number(v) || 0;
    if (n >= 10000000) return `₹${(n / 10000000).toFixed(2)} Cr`;
    if (n >= 100000) return `₹${(n / 100000).toFixed(2)} L`;
    if (n >= 1000) return `₹${(n / 1000).toFixed(1)}K`;
    return `₹${n}`;
  }

  getEventDay(date: string): string { return new Date(date).getDate().toString().padStart(2, '0'); }
  getEventMonth(date: string): string { return new Date(date).toLocaleString('en', { month: 'short' }); }
  getEventTime(date: string): string { return new Date(date).toLocaleTimeString('en', { hour: '2-digit', minute: '2-digit' }); }

  ngOnDestroy(): void {
    this.timeSubscription?.unsubscribe();
  }

  private startTimeUpdater(): void {
    this.timeSubscription = interval(1000).subscribe(() => {
      this.currentTime = new Date();
    });
  }

  getNotificationIcon(type: string): string {
    switch (type) {
      case 'warning': return 'warning';
      case 'error': return 'error';
      case 'success': return 'check_circle';
      case 'event': return 'event';
      default: return 'campaign';
    }
  }

  getNotificationColor(priority: string): string {
    switch (priority) {
      case 'Critical':
      case 'High': return 'warn';
      case 'Medium': return 'accent';
      default: return 'primary';
    }
  }

  dismissNotification(index: number): void {
    this.notifications.update(arr => { arr.splice(index, 1); return arr; });
  }

  getTimeOfDay(): string {
    const hour = new Date().getHours();
    if (hour < 12) return 'Morning';
    if (hour < 17) return 'Afternoon';
    return 'Evening';
  }
}
