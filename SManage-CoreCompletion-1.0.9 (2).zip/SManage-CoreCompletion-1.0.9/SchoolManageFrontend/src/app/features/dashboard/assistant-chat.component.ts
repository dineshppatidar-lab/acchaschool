import { Component, signal } from '@angular/core';
import { AssistantService } from '../../services/assistant.service';
import { VoiceService } from '../../services/voice.service';
import { Router } from '@angular/router';

import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';

@Component({
  selector: 'app-assistant-chat',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatCardModule,
    MatButtonModule,
    MatIconModule,
    MatProgressSpinnerModule
  ],
  templateUrl: './assistant-chat.component.html',
  styleUrls: ['./assistant-chat.component.scss']
})
export class AssistantChatComponent {
  messages: { from: 'user' | 'ai', text: string }[] = [
    { from: 'ai', text: 'Hi! I am your Campus AI assistant. I can help you look up student records, analyse attendance discrepancies, send fee reminder broadcasts, or draft announcements. How can I assist you today?' }
  ];
  input = signal('');
  loading = signal(false);
  listening = signal(false);

  suggestionChips = [
    { emoji: '📊', prompt: 'Who has overdue fees in Grade 10?' },
    { emoji: '🚌', prompt: 'Track route #4 bus location' },
    { emoji: '📅', prompt: 'What events are scheduled today?' },
    { emoji: '📝', prompt: 'Draft an urgent weather announcement' }
  ];

  constructor(private assistant: AssistantService, private voice: VoiceService, private router: Router) {}

  send() {
    if (!this.input().trim() || this.loading()) return;
    this.messages.push({ from: 'user', text: this.input() });
    this.loading.set(true);
    this.assistant.ask(this.input()).subscribe(res => {
      this.messages.push({ from: 'ai', text: res });
      this.loading.set(false);
      // Trigger actions based on AI response or user input
      if (this.input().toLowerCase().includes('dashboard')) this.router.navigate(['/dashboard']);
      if (this.input().toLowerCase().includes('import students')) this.router.navigate(['/students/import-export']);
    });
    this.input.set('');
  }

  startVoice() {
    if (this.listening()) return;
    this.listening.set(true);
    this.voice.listen((command) => {
      // Zoneless: signal-based state schedules its own change detection.
      this.listening.set(false);
      this.input.set(command);
      this.send();
    });
  }

  useSuggestion(prompt: string) {
    this.input.set(prompt);
    this.send();
  }

  clearInput() {
    this.input.set('');
  }

  currentTime(): string {
    return new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  }
}
