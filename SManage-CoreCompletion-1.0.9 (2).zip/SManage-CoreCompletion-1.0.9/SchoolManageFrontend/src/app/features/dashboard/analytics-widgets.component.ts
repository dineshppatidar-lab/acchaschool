import { ChangeDetectorRef, Component, OnInit, signal } from '@angular/core';
import { AnalyticsService } from '../../services/analytics.service';
import { Router } from '@angular/router';

import { MatCardModule } from '@angular/material/card';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatTooltipModule } from '@angular/material/tooltip';
import { NgIf, NgFor, DecimalPipe, CommonModule } from '@angular/common';

interface PerformanceTrend {
  month: string;
  avg: number;
  change: number;
  grade?: string;
}

interface AbsenteeismRisk {
  id: string;
  name: string;
  grade?: string;
  absenceRate: number;
  totalAbsences?: number;
  riskLevel?: 'low' | 'medium' | 'high';
}

@Component({
  selector: 'app-analytics-widgets',
  standalone: true,
  imports: [
    CommonModule, 
    MatCardModule, 
    MatProgressSpinnerModule,
    MatIconModule,
    MatButtonModule,
    MatTooltipModule,
    NgIf, 
    NgFor, 
    DecimalPipe
  ],
  templateUrl: './analytics-widgets.component.html',
  styleUrls: ['./analytics-widgets.component.scss']
})
export class AnalyticsWidgetsComponent implements OnInit {
  trends = signal<any[]>([]);
  risk = signal<any[]>([]);
  loading = signal(false);

  constructor(
    private analytics: AnalyticsService,
    private router: Router,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    // Wrap in setTimeout to avoid ExpressionChangedAfterItHasBeenCheckedError on initial load
    setTimeout(() => {
      this.loadInsights();
    });
  }

  private loadInsights(): void {
    this.loading.set(true);
    this.cdr.markForCheck();
    
    this.analytics.getPerformanceTrends().subscribe({
      next: (trends) => {
        // Add mock change data if not provided
        this.trends.set(trends.map((trend: any, index: number) => ({
          ...trend,
          change: trend.change || (Math.random() * 10 - 5) // Random change between -5% and +5%
        })));
        
        this.analytics.getAbsenteeismRisk().subscribe({
          next: (riskData) => {
            this.risk.set(riskData.map((student: any) => ({
              ...student,
              id: student.id || `student-${Math.random()}`,
              grade: student.grade || Math.floor(Math.random() * 12 + 1).toString(),
              riskLevel: this.getRiskLevel(student.absenceRate)
            })));
            this.loading.set(false);
            this.cdr.markForCheck();
          },
          error: (error) => {
            console.error('Error loading absenteeism risk data:', error);
            this.loading.set(false);
            this.cdr.markForCheck();
          }
        });
      },
      error: (error) => {
        console.error('Error loading performance trends:', error);
        this.loading.set(false);
        this.cdr.markForCheck();
      }
    });
  }

  private getRiskLevel(absenceRate: number): 'low' | 'medium' | 'high' {
    if (absenceRate > 0.15) return 'high';
    if (absenceRate > 0.10) return 'medium';
    return 'low';
  }

  refreshInsights(): void {
    this.loadInsights();
  }

  contactStudent(student: AbsenteeismRisk): void {
    // Navigate to communication with pre-filled student info
    this.router.navigate(['/communication/messages'], {
      queryParams: { studentId: student.id, action: 'compose' }
    });
  }

  viewStudentDetails(student: AbsenteeismRisk): void {
    // Navigate to student profile
    this.router.navigate(['/students', student.id]);
  }

  viewDetailedReport(): void {
    // Navigate to detailed analytics page
    this.router.navigate(['/analytics/detailed-report']);
  }

  exportInsights(): void {
    // Implement insights export functionality
    const insightsData = {
      performanceTrends: this.trends(),
      absenteeismRisk: this.risk(),
      generatedAt: new Date().toISOString()
    };
    
    const blob = new Blob([JSON.stringify(insightsData, null, 2)], {
      type: 'application/json'
    });
    
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `ai-insights-${new Date().getTime()}.json`;
    link.click();
    window.URL.revokeObjectURL(url);
  }

  // Track functions for ngFor performance
  trackByTrend(index: number, trend: PerformanceTrend): string {
    return trend.month;
  }

  trackByRisk(index: number, student: AbsenteeismRisk): string {
    return student.id;
  }
}
