import { Component, ChangeDetectorRef, inject, signal } from '@angular/core';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { SetupStatusService } from '../../core/services/setup-status.service';

/**
 * Dashboard "Complete Your School Setup" card for newly created schools.
 * Shows required-only progress plus the remaining items; hides itself
 * automatically once setup reaches 100% (all required steps completed).
 */
@Component({
  selector: 'app-setup-progress-card',
  standalone: true,
  imports: [CommonModule, MatButtonModule, MatIconModule, MatProgressBarModule],
  template: `
    @if (setup.canViewSetupStatus() && setup.showSetupUi() && setup.status(); as s) {
      <section class="setup-card animate-fadeIn">
        <div class="setup-card-head">
          <div class="setup-card-icon"><mat-icon>school</mat-icon></div>
          <div class="setup-card-title">
            <h2>Complete Your School Setup</h2>
            <p>Your school is almost ready.</p>
          </div>
          <span class="setup-card-pct">{{ s.completionPercentage }}%</span>
        </div>

        <mat-progress-bar mode="determinate" [value]="s.completionPercentage" class="setup-card-bar"></mat-progress-bar>
        <p class="setup-card-count">{{ s.completedCount }} of {{ s.requiredCount }} required configurations completed</p>

        @if (remaining().length > 0) {
          <div class="setup-card-remaining">
            <span class="remaining-label">Remaining:</span>
            <ul>
              @for (item of remaining(); track item.key) {
                <li>
                  <a (click)="goTo(item, $event)">{{ item.name }}</a>
                  @if (!item.isRequired) { <span class="opt-tag">Optional</span> }
                </li>
              }
            </ul>
          </div>
        }

        <button mat-flat-button color="primary" class="setup-card-cta" (click)="continueSetup()">
          <mat-icon>play_arrow</mat-icon> Continue Setup
        </button>
      </section>
    }
  `,
  styles: [`
    :host { display: block; }
    .setup-card {
      background: linear-gradient(135deg, var(--md-primary-container, #D1E4FF), #EAF2FF);
      border: 1px solid rgba(13, 71, 161, .14);
      border-radius: 16px;
      padding: 18px 20px;
      margin: 0 16px 16px;
    }
    .setup-card-head { display: flex; align-items: center; gap: 12px; }
    .setup-card-icon {
      width: 42px; height: 42px; border-radius: 12px; flex-shrink: 0;
      background: var(--md-primary, var(--md-primary)); color: #fff;
      display: flex; align-items: center; justify-content: center;
    }
    .setup-card-title { flex: 1; min-width: 0; }
    .setup-card-title h2 { margin: 0; font-size: 16px; font-weight: 800; color: var(--md-on-primary-container, #001D36); }
    .setup-card-title p { margin: 2px 0 0; font-size: 12.5px; opacity: .75; }
    .setup-card-pct { font-size: var(--font-size-xl); font-weight: 800; color: var(--md-primary, var(--md-primary)); }
    .setup-card-bar { margin-top: 12px; border-radius: 4px; }
    .setup-card-count { margin: 8px 0 0; font-size: 12.5px; opacity: .8; }
    .setup-card-remaining { margin-top: 10px; display: flex; gap: 8px; align-items: baseline; flex-wrap: wrap; }
    .remaining-label { font-size: 12.5px; font-weight: 700; opacity: .7; }
    .setup-card-remaining ul { list-style: none; display: flex; gap: 8px; flex-wrap: wrap; margin: 0; padding: 0; }
    .setup-card-remaining li { font-size: 12.5px; }
    .setup-card-remaining a { color: var(--md-primary, var(--md-primary)); font-weight: 700; cursor: pointer; text-decoration: none; }
    .setup-card-remaining a:hover { text-decoration: underline; }
    .opt-tag {
      font-size: 10px; font-weight: 700; text-transform: uppercase; letter-spacing: .4px;
      background: rgba(0,0,0,.08); color: rgba(0,0,0,.55); border-radius: 8px; padding: 1px 6px; margin-left: 4px;
    }
    .setup-card-cta { margin-top: 14px; }
    @media (max-width: 600px) {
      .setup-card { margin: 0 12px 12px; padding: 14px 16px; }
      .setup-card-pct { font-size: 18px; }
    }
  `]
})
export class SetupProgressCardComponent {
  readonly setup = inject(SetupStatusService);
  private readonly router = inject(Router);
  private readonly cdr = inject(ChangeDetectorRef);

  /** Incomplete steps to list (required first, then optional). */
  readonly remaining = () => {
    const s = this.setup.status();
    if (!s) return [];
    return s.items
      .filter(i => !i.isCompleted)
      .sort((a, b) => (a.isRequired === b.isRequired) ? a.displayOrder - b.displayOrder : (a.isRequired ? -1 : 1));
  };

  continueSetup(): void {
    this.router.navigate(['/app/setup']);
  }

  goTo(item: { route: string; isCompleted: boolean }, event: Event): void {
    event.preventDefault();
    if (item.isCompleted) return;
    this.router.navigateByUrl(item.route || '/app/setup');
  }
}
