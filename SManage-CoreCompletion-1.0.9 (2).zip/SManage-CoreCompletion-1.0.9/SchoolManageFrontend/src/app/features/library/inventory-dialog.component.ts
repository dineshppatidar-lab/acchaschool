import { Component, OnInit, Inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatDialogModule, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatIconModule } from '@angular/material/icon';
import { MatCardModule } from '@angular/material/card';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { InventoryItem } from '../../services/library.service';

interface InventoryDialogData {
  inventoryItem?: InventoryItem;
  mode: 'add' | 'edit' | 'view' | 'stock-update';
}

@Component({
  selector: 'app-inventory-dialog',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatDialogModule,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatIconModule,
    MatCardModule,
    MatDatepickerModule,
    MatNativeDateModule
  ],
  templateUrl: './inventory-dialog.component.html',
  styleUrls: ['./inventory-dialog.component.scss']
})
export class InventoryDialogComponent implements OnInit {
  inventoryForm: FormGroup;
  isViewMode: boolean = false;

  constructor(
    private fb: FormBuilder,
    public dialogRef: MatDialogRef<InventoryDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: InventoryDialogData
  ) {
    this.isViewMode = data.mode === 'view';
    this.inventoryForm = this.createForm();
  }

  ngOnInit(): void {
    if (this.data.inventoryItem) {
      this.inventoryForm.patchValue(this.data.inventoryItem);
    }
  }

  private createForm(): FormGroup {
    const form = this.fb.group({
      name: ['', Validators.required],
      category: ['', Validators.required],
      quantity: ['', [Validators.required, Validators.min(0)]],
      minStockLevel: ['', Validators.required],
      unit: ['Pieces'],
      unitPrice: [0],
      supplier: ['', Validators.required],
      location: [''],
      expiryDate: [null],
      description: [''],
      lastUpdated: [new Date()]
    });

    // For stock update mode, make certain fields not required
    if (this.data.mode === 'stock-update') {
      form.get('supplier')?.clearValidators();
      form.get('minStockLevel')?.clearValidators();
      form.get('supplier')?.updateValueAndValidity();
      form.get('minStockLevel')?.updateValueAndValidity();
    }

    return form;
  }

  getDialogTitle(): string {
    switch (this.data.mode) {
      case 'add': return 'Add New Inventory Item';
      case 'edit': return 'Edit Inventory Item';
      case 'view': return 'Inventory Item Details';
      case 'stock-update': return 'Update Stock Quantity';
      default: return 'Inventory Dialog';
    }
  }

  getDialogIcon(): string {
    switch (this.data.mode) {
      case 'add': return 'add_box';
      case 'edit': return 'edit';
      case 'view': return 'visibility';
      case 'stock-update': return 'update';
      default: return 'inventory';
    }
  }

  getButtonText(): string {
    switch (this.data.mode) {
      case 'add': return 'Add Item';
      case 'edit': return 'Update Item';
      case 'stock-update': return 'Update Stock';
      default: return 'Save';
    }
  }

  getTotalValue(): string {
    const quantity = this.inventoryForm?.get('quantity')?.value || 0;
    const unitPrice = this.inventoryForm?.get('unitPrice')?.value || 0;
    return (quantity * unitPrice).toFixed(2);
  }

  onCancel(): void {
    this.dialogRef.close();
  }

  onSave(): void {
    if (this.inventoryForm.valid) {
      const inventoryData: Partial<InventoryItem> = {
        ...this.inventoryForm.value,
        lastUpdated: new Date()
      };
      
      if (this.data.inventoryItem?.itemId) {
        inventoryData.itemId = this.data.inventoryItem.itemId;
      }
      
      this.dialogRef.close(inventoryData);
    }
  }
}