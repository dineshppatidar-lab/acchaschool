import { Component, OnInit, Inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatDialogModule, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatIconModule } from '@angular/material/icon';
import { MatCardModule } from '@angular/material/card';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { Book } from '../../services/library.service';

interface BookDialogData {
  book?: Book;
  mode: 'add' | 'edit' | 'view';
}

@Component({
  selector: 'app-book-dialog',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatDialogModule,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatIconModule,
    MatCardModule,
    MatDatepickerModule,
    MatNativeDateModule
  ],
  templateUrl: './book-dialog.component.html',
  styleUrls: ['./book-dialog.component.scss']
})
export class BookDialogComponent implements OnInit {
  bookForm: FormGroup;
  isViewMode: boolean = false;

  constructor(
    private fb: FormBuilder,
    public dialogRef: MatDialogRef<BookDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: BookDialogData
  ) {
    this.isViewMode = data.mode === 'view';
    this.bookForm = this.createForm();
  }

  ngOnInit(): void {
    if (this.data.book) {
      this.bookForm.patchValue(this.data.book);
    }
  }

  private createForm(): FormGroup {
    return this.fb.group({
      title: ['', Validators.required],
      author: ['', Validators.required],
      isbn: ['', Validators.required],
      category: ['', Validators.required],
      subject: [''],
      status: ['Available'],
      publisher: [''],
      edition: [''],
      pages: [''],
      price: [0],
      location: [''],
      language: ['English'],
      description: [''],
      addedDate: [new Date()]
    });
  }

  getDialogTitle(): string {
    switch (this.data.mode) {
      case 'add': return 'Add New Book';
      case 'edit': return 'Edit Book Details';
      case 'view': return 'Book Details';
      default: return 'Book Dialog';
    }
  }

  getDialogIcon(): string {
    switch (this.data.mode) {
      case 'add': return 'library_add';
      case 'edit': return 'edit';
      case 'view': return 'visibility';
      default: return 'book';
    }
  }

  onCancel(): void {
    this.dialogRef.close();
  }

  onSave(): void {
    if (this.bookForm.valid) {
      const bookData: Partial<Book> = {
        ...this.bookForm.value
      };
      
      if (this.data.book?.bookId) {
        bookData.bookId = this.data.book.bookId;
      }
      
      this.dialogRef.close(bookData);
    }
  }
}