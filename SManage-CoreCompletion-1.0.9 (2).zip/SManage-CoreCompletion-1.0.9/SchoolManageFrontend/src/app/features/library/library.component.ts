import { Component, OnInit, ViewChild, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatTableModule, MatTableDataSource } from '@angular/material/table';
import { MatPaginatorModule, MatPaginator } from '@angular/material/paginator';
import { MatSortModule } from '@angular/material/sort';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatDialogModule, MatDialog } from '@angular/material/dialog';
import { MatSnackBarModule, MatSnackBar } from '@angular/material/snack-bar';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatCardModule } from '@angular/material/card';
import { MatTabsModule } from '@angular/material/tabs';
import { MatChipsModule } from '@angular/material/chips';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatTooltipModule } from '@angular/material/tooltip';
import { PageHeaderComponent, KpiCardComponent } from '../../shared/components/page-patterns/index';
import { BookDialogComponent } from './book-dialog.component';
import { AssetDialogComponent } from './asset-dialog.component';
import { InventoryDialogComponent } from './inventory-dialog.component';
import { LibraryService, Book, Asset, InventoryItem } from '../../services/library.service';
import { CanWriteDirective, CanDeleteDirective } from '../../core/directives/permission.directive';
import { Permission } from '../../core/models/permission.model';
import { DialogUtils } from '../../shared/dialog-utils';

@Component({
  selector: 'app-library-inventory',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    MatButtonModule,
    MatIconModule,
    MatDialogModule,
    MatSnackBarModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatCardModule,
    MatTabsModule,
    MatChipsModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatCheckboxModule,
    MatTooltipModule,
    CanWriteDirective,
    CanDeleteDirective,
    PageHeaderComponent,
    KpiCardComponent
  ],
  template: `
    <div class="library-inventory-container">
      <app-page-header
        title="Library & Inventory"
        subtitle="Manage books, assets, and inventory items"
        [actions]="false" />
      <mat-card>
          <mat-tab-group (selectedTabChange)="onTabChange($event)">
            <!-- Books Tab -->
            <mat-tab label="Books">
              <div class="tab-content">
                <div class="actions-bar">
                  <button mat-raised-button color="primary" (click)="openBookDialog()" *appCanWrite="Permission.LibraryManageInventory">
                    <mat-icon>library_add</mat-icon>
                    Add Book
                  </button>
                  <button mat-button color="accent" (click)="issueBook()" *appCanWrite="Permission.LibraryIssueBooks">
                    <mat-icon>assignment_return</mat-icon>
                    Issue Book
                  </button>
                  <mat-form-field appearance="outline" class="search-field">
                    <mat-label>Search Books</mat-label>
                    <mat-icon matPrefix>search</mat-icon>
                    <input matInput (keyup)="applyBookFilter($event)" placeholder="Search by title, author, ISBN...">
                  </mat-form-field>
                </div>

                <div class="table-container">
                  <table mat-table [dataSource]="bookDataSource" matSort class="books-table">
                    <ng-container matColumnDef="title">
                      <th mat-header-cell *matHeaderCellDef mat-sort-header>Title</th>
                      <td mat-cell *matCellDef="let book">{{book.title}}</td>
                    </ng-container>

                    <ng-container matColumnDef="author">
                      <th mat-header-cell *matHeaderCellDef mat-sort-header>Author</th>
                      <td mat-cell *matCellDef="let book">{{book.author}}</td>
                    </ng-container>

                    <ng-container matColumnDef="isbn">
                      <th mat-header-cell *matHeaderCellDef>ISBN</th>
                      <td mat-cell *matCellDef="let book">{{book.isbn}}</td>
                    </ng-container>

                    <ng-container matColumnDef="category">
                      <th mat-header-cell *matHeaderCellDef>Category</th>
                      <td mat-cell *matCellDef="let book">
                        <mat-chip>{{book.category}}</mat-chip>
                      </td>
                    </ng-container>

                    <ng-container matColumnDef="status">
                      <th mat-header-cell *matHeaderCellDef>Status</th>
                      <td mat-cell *matCellDef="let book">
                        <mat-chip [color]="getBookStatusColor(book.status)">{{book.status}}</mat-chip>
                      </td>
                    </ng-container>

                    <ng-container matColumnDef="dueDate">
                      <th mat-header-cell *matHeaderCellDef>Due Date</th>
                      <td mat-cell *matCellDef="let book">
                        <span *ngIf="book.dueDate">{{book.dueDate | date:'shortDate'}}</span>
                        <span *ngIf="!book.dueDate">-</span>
                      </td>
                    </ng-container>

                    <ng-container matColumnDef="actions">
                      <th mat-header-cell *matHeaderCellDef>Actions</th>
                      <td mat-cell *matCellDef="let book">
                        <button mat-icon-button color="primary" (click)="editBook(book)" matTooltip="Edit Book" *appCanWrite="Permission.LibraryManageInventory">
                          <mat-icon>edit</mat-icon>
                        </button>
                        <button mat-icon-button color="accent" (click)="viewBookDetails(book)" matTooltip="View Details">
                          <mat-icon>visibility</mat-icon>
                        </button>
                        <button mat-icon-button color="warn" (click)="deleteBook(book)" matTooltip="Delete Book" *appCanDelete="Permission.LibraryManageInventory">
                          <mat-icon>delete</mat-icon>
                        </button>
                      </td>
                    </ng-container>

                    <tr mat-header-row *matHeaderRowDef="bookColumns"></tr>
                    <tr mat-row *matRowDef="let row; columns: bookColumns;"></tr>
                  </table>

                  <mat-paginator #bookPaginator [pageSizeOptions]="[5, 10, 20]" showFirstLastButtons></mat-paginator>
                </div>
              </div>
            </mat-tab>

            <!-- Assets Tab -->
            <mat-tab label="Assets">
              <div class="tab-content">
                <div class="actions-bar">
                  <button mat-raised-button color="primary" (click)="openAssetDialog()" *appCanWrite="Permission.LibraryManageInventory">
                    <mat-icon>add_box</mat-icon>
                    Add Asset
                  </button>
                  <button mat-button color="accent" (click)="scheduleMaintenance()">
                    <mat-icon>build</mat-icon>
                    Schedule Maintenance
                  </button>
                  <mat-form-field appearance="outline" class="search-field">
                    <mat-label>Search Assets</mat-label>
                    <mat-icon matPrefix>search</mat-icon>
                    <input matInput (keyup)="applyAssetFilter($event)" placeholder="Search by name, tag...">
                  </mat-form-field>
                </div>

                <div class="assets-grid">
                  <mat-card *ngFor="let asset of assets()" class="asset-card">
                    <mat-card-header>
                      <mat-card-title>{{asset.name}}</mat-card-title>
                      <mat-card-subtitle>{{asset.type}} - {{asset.location}}</mat-card-subtitle>
                    </mat-card-header>
                    
                    <mat-card-content>
                      <div class="asset-details">
                        <div class="detail-row">
                          <strong>Status:</strong>
                          <mat-chip [color]="getAssetStatusColor(asset.status)">{{asset.status}}</mat-chip>
                        </div>
                        <div class="detail-row">
                          <strong>Condition:</strong> {{asset.condition}}
                        </div>
                        <div class="detail-row">
                          <strong>Acquired:</strong> {{asset.acquisitionDate | date:'shortDate'}}
                        </div>
                        <div class="detail-row" *ngIf="asset.maintenanceSchedule">
                          <strong>Next Maintenance:</strong> {{asset.maintenanceSchedule | date:'shortDate'}}
                        </div>
                      </div>
                    </mat-card-content>
                    
                    <mat-card-actions>
                      <button mat-button color="primary" (click)="editAsset(asset)" *appCanWrite="Permission.LibraryManageInventory">
                        <mat-icon>edit</mat-icon>
                        Edit
                      </button>
                      <button mat-button color="accent" (click)="recordMaintenance(asset)">
                        <mat-icon>build</mat-icon>
                        Maintenance
                      </button>
                      <button mat-button color="warn" (click)="deleteAsset(asset)" *appCanDelete="Permission.LibraryManageInventory">
                        <mat-icon>delete</mat-icon>
                        Delete
                      </button>
                    </mat-card-actions>
                  </mat-card>
                </div>
              </div>
            </mat-tab>

            <!-- Inventory Tab -->
            <mat-tab label="Inventory">
              <div class="tab-content">
                <div class="actions-bar">
                  <button mat-raised-button color="primary" (click)="openInventoryDialog()" *appCanWrite="Permission.LibraryManageInventory">
                    <mat-icon>inventory</mat-icon>
                    Add Item
                  </button>
                  <button mat-button color="accent" (click)="generateInventoryReport()">
                    <mat-icon>assessment</mat-icon>
                    Generate Report
                  </button>
                  <mat-form-field appearance="outline" class="search-field">
                    <mat-label>Search Inventory</mat-label>
                    <mat-icon matPrefix>search</mat-icon>
                    <input matInput (keyup)="applyInventoryFilter($event)" placeholder="Search by name, code...">
                  </mat-form-field>
                </div>

                <div class="inventory-summary" *ngIf="lowStockItems().length > 0">
                  <div class="stu-kpi-grid">
                    <app-kpi-card icon="warning" tone="warn" [value]="lowStockItems().length" label="Items Low in Stock" />
                  </div>
                </div>

                <div class="table-container">
                  <table mat-table [dataSource]="inventoryDataSource" matSort class="inventory-table">
                    <ng-container matColumnDef="name">
                      <th mat-header-cell *matHeaderCellDef mat-sort-header>Item Name</th>
                      <td mat-cell *matCellDef="let item">{{item.name}}</td>
                    </ng-container>

                    <ng-container matColumnDef="category">
                      <th mat-header-cell *matHeaderCellDef>Category</th>
                      <td mat-cell *matCellDef="let item">
                        <mat-chip>{{item.category}}</mat-chip>
                      </td>
                    </ng-container>

                    <ng-container matColumnDef="quantity">
                      <th mat-header-cell *matHeaderCellDef mat-sort-header>Quantity</th>
                      <td mat-cell *matCellDef="let item">
                        <span [class.low-stock]="item.quantity <= item.minStockLevel">
                          {{item.quantity}} {{item.unit}}
                        </span>
                      </td>
                    </ng-container>

                    <ng-container matColumnDef="minStockLevel">
                      <th mat-header-cell *matHeaderCellDef>Min Stock</th>
                      <td mat-cell *matCellDef="let item">{{item.minStockLevel}} {{item.unit}}</td>
                    </ng-container>

                    <ng-container matColumnDef="supplier">
                      <th mat-header-cell *matHeaderCellDef>Supplier</th>
                      <td mat-cell *matCellDef="let item">{{item.supplier}}</td>
                    </ng-container>

                    <ng-container matColumnDef="lastUpdated">
                      <th mat-header-cell *matHeaderCellDef mat-sort-header>Last Updated</th>
                      <td mat-cell *matCellDef="let item">{{item.lastUpdated | date:'shortDate'}}</td>
                    </ng-container>

                    <ng-container matColumnDef="actions">
                      <th mat-header-cell *matHeaderCellDef>Actions</th>
                      <td mat-cell *matCellDef="let item">
                        <button mat-icon-button color="primary" (click)="editInventoryItem(item)" matTooltip="Edit Item" *appCanWrite="Permission.LibraryManageInventory">
                          <mat-icon>edit</mat-icon>
                        </button>
                        <button mat-icon-button color="accent" (click)="updateStock(item)" matTooltip="Update Stock">
                          <mat-icon>update</mat-icon>
                        </button>
                        <button mat-icon-button (click)="viewInventoryHistory(item)" matTooltip="View Details">
                          <mat-icon>visibility</mat-icon>
                        </button>
                        <button mat-icon-button color="warn" (click)="deleteInventoryItem(item)" matTooltip="Delete Item" *appCanDelete="Permission.LibraryManageInventory">
                          <mat-icon>delete</mat-icon>
                        </button>
                      </td>
                    </ng-container>

                    <tr mat-header-row *matHeaderRowDef="inventoryColumns"></tr>
                    <tr mat-row *matRowDef="let row; columns: inventoryColumns;"></tr>
                  </table>

                  <mat-paginator #inventoryPaginator [pageSizeOptions]="[5, 10, 20]" showFirstLastButtons></mat-paginator>
                </div>
              </div>
            </mat-tab>
          </mat-tab-group>
      </mat-card>
    </div>
  `,
  styleUrls: ['./library.component.scss']
})
export class LibraryComponent implements OnInit {
  Permission = Permission;
  @ViewChild('bookPaginator') bookPaginator!: MatPaginator;
  @ViewChild('inventoryPaginator') inventoryPaginator!: MatPaginator;
  
  bookDataSource = new MatTableDataSource<Book>();
  inventoryDataSource = new MatTableDataSource<InventoryItem>();
  
  bookColumns: string[] = ['title', 'author', 'isbn', 'category', 'status', 'dueDate', 'actions'];
  inventoryColumns: string[] = ['name', 'category', 'quantity', 'minStockLevel', 'supplier', 'lastUpdated', 'actions'];
  
  books = signal<any[]>([]);
  assets = signal<any[]>([]);
  inventory = signal<any[]>([]);
  lowStockItems = signal<any[]>([]);

  constructor(
    private dialog: MatDialog,
    private dialogUtils: DialogUtils,
    private snackBar: MatSnackBar,
    private libraryService: LibraryService
  ) {}

  ngOnInit(): void {
    this.loadBooks();
    this.loadAssets();
    this.loadInventory();
  }

  onTabChange(event: any): void {
    if (event.index === 0) this.loadBooks();
    else if (event.index === 1) this.loadAssets();
    else if (event.index === 2) this.loadInventory();
  }

  loadBooks(): void {
    this.libraryService.getBooks(1, 100).subscribe({
      next: (result) => {
        this.books.set(result.data);
        this.bookDataSource.data = this.books();
        if (this.bookPaginator) this.bookDataSource.paginator = this.bookPaginator;
      },
      error: (err) => this.showError(err.error?.message || 'Failed to load books')
    });
  }

  loadAssets(): void {
    this.libraryService.getAssets(1, 100).subscribe({
      next: (result) => {
        this.assets.set(result.data);
      },
      error: (err) => this.showError(err.error?.message || 'Failed to load assets')
    });
  }

  loadInventory(): void {
    this.libraryService.getInventory(1, 100).subscribe({
      next: (result) => {
        this.inventory.set(result.data);
        this.inventoryDataSource.data = this.inventory();
        if (this.inventoryPaginator) this.inventoryDataSource.paginator = this.inventoryPaginator;
        this.checkLowStock();
      },
      error: (err) => this.showError(err.error?.message || 'Failed to load inventory')
    });
  }

  checkLowStock(): void {
    this.libraryService.getLowStockItems().subscribe({
      next: (items) => this.lowStockItems.set(items),
      error: (err) => console.error('Error checking low stock', err)
    });
  }

  applyBookFilter(event: Event): void {
    const filterValue = (event.target as HTMLInputElement).value;
    this.libraryService.getBooks(1, 100, filterValue).subscribe(result => {
      this.bookDataSource.data = result.data;
    });
  }

  applyAssetFilter(event: Event): void {
    const filterValue = (event.target as HTMLInputElement).value;
    this.libraryService.getAssets(1, 100, filterValue).subscribe(result => {
      this.assets.set(result.data);
    });
  }

  applyInventoryFilter(event: Event): void {
    const filterValue = (event.target as HTMLInputElement).value;
    this.libraryService.getInventory(1, 100, filterValue).subscribe(result => {
      this.inventoryDataSource.data = result.data;
    });
  }

  getBookStatusColor(status: string): string {
    if (!status) return 'basic';
    switch (status.toLowerCase()) {
      case 'available': return 'primary';
      case 'issued': return 'warn';
      case 'overdue': return 'warn';
      default: return 'basic';
    }
  }

  getAssetStatusColor(status: string): string {
    if (!status) return 'basic';
    switch (status.toLowerCase()) {
      case 'available': return 'primary';
      case 'in use': return 'accent';
      case 'maintenance': return 'warn';
      default: return 'basic';
    }
  }

  // Book operations
  openBookDialog(): void {
    const dialogRef = this.dialog.open(BookDialogComponent, {
        ...this.dialogUtils.getMobileConfig({ width: '700px', data: { mode: 'add' } }),
            });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.libraryService.createBook(result).subscribe({
          next: () => {
            this.loadBooks();
            this.showSuccess('Book added successfully');
          },
          error: (err) => {
            console.error('Create book error:', err);
            let errorMessage = err.error?.message || 'Failed to add book';
            if (err.error?.errors) {
              if (Array.isArray(err.error.errors)) {
                errorMessage += ': ' + err.error.errors.join(', ');
              } else if (typeof err.error.errors === 'object') {
                const details = Object.values(err.error.errors).flat().join(', ');
                errorMessage += ': ' + details;
              }
            }
            this.showError(errorMessage);
          }
        });
      }
    });
  }

  editBook(book: Book): void {
    const dialogRef = this.dialog.open(BookDialogComponent, {
        ...this.dialogUtils.getMobileConfig({ width: '700px', data: { book: {...book}, mode: 'edit' } }),
            });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.libraryService.updateBook(book.bookId, result).subscribe({
          next: () => {
            this.loadBooks();
            this.showSuccess('Book updated successfully');
          },
          error: (err) => this.showError(err.error?.message || 'Failed to update book')
        });
      }
    });
  }

  viewBookDetails(book: Book): void {
    this.dialog.open(BookDialogComponent, {
        ...this.dialogUtils.getMobileConfig({ width: '700px', data: { book: {...book}, mode: 'view' } }),
            });
  }

  deleteBook(book: Book): void {
    if (confirm(`Are you sure you want to delete "${book.title}"?`)) {
      this.showSuccess('Book deletion requested');
    }
  }

  issueBook(): void {
    this.snackBar.open('Issue book dialog coming soon', 'Close', { duration: 3000 });
  }

  // Asset operations
  openAssetDialog(): void {
    const dialogRef = this.dialog.open(AssetDialogComponent, {
        ...this.dialogUtils.getMobileConfig({ width: '600px', data: { mode: 'add' } }),
            });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.libraryService.createAsset(result).subscribe({
          next: () => {
            this.loadAssets();
            this.showSuccess('Asset added successfully');
          },
          error: (err) => this.showError('Failed to add asset')
        });
      }
    });
  }

  editAsset(asset: Asset): void {
    const dialogRef = this.dialog.open(AssetDialogComponent, {
        ...this.dialogUtils.getMobileConfig({ width: '600px', data: { asset: {...asset}, mode: 'edit' } }),
            });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.showSuccess('Asset update requested');
      }
    });
  }

  deleteAsset(asset: Asset): void {
    if (confirm(`Are you sure you want to delete "${asset.name}"?`)) {
      this.showSuccess('Asset deletion requested');
    }
  }

  scheduleMaintenance(): void {
    this.snackBar.open('Schedule maintenance dialog coming soon', 'Close', { duration: 3000 });
  }

  recordMaintenance(asset: Asset): void {
    this.snackBar.open(`Recording maintenance for ${asset.name}`, 'Close', { duration: 3000 });
  }

  // Inventory operations
  openInventoryDialog(): void {
    const dialogRef = this.dialog.open(InventoryDialogComponent, {
        ...this.dialogUtils.getMobileConfig({ width: '600px', data: { mode: 'add' } }),
            });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.showSuccess('Inventory item addition requested');
      }
    });
  }

  editInventoryItem(item: InventoryItem): void {
    const dialogRef = this.dialog.open(InventoryDialogComponent, {
        ...this.dialogUtils.getMobileConfig({ width: '600px', data: { item: {...item}, mode: 'edit' } }),
            });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.showSuccess('Inventory item update requested');
      }
    });
  }

  updateStock(item: InventoryItem): void {
    this.snackBar.open(`Updating stock for ${item.name}`, 'Close', { duration: 3000 });
  }

  viewInventoryHistory(item: InventoryItem): void {
    this.snackBar.open(`Viewing history for ${item.name}`, 'Close', { duration: 3000 });
  }

  deleteInventoryItem(item: InventoryItem): void {
    if (confirm(`Are you sure you want to delete "${item.name}"?`)) {
      this.showSuccess('Inventory item deletion requested');
    }
  }

  generateInventoryReport(): void {
    this.libraryService.getLibraryUsageReport().subscribe({
      next: (report) => {
        console.log('Report generated', report);
        this.showSuccess('Report generated and logged to console');
      },
      error: (err) => this.showError('Failed to generate report')
    });
  }

  private showSuccess(message: string): void {
    this.snackBar.open(message, 'Close', { duration: 3000, panelClass: ['success-snackbar'] });
  }

  private showError(message: string): void {
    this.snackBar.open(message, 'Close', { duration: 3000, panelClass: ['error-snackbar'] });
  }
}
