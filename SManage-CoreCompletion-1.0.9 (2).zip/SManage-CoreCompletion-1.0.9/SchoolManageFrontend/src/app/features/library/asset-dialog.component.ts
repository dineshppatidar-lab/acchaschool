import { Component, OnInit, Inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatDialogModule, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatIconModule } from '@angular/material/icon';
import { MatCardModule } from '@angular/material/card';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { Asset } from '../../services/library.service';

interface AssetDialogData {
  asset?: Asset;
  mode: 'add' | 'edit' | 'view';
}

@Component({
  selector: 'app-asset-dialog',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatDialogModule,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatIconModule,
    MatCardModule,
    MatDatepickerModule,
    MatNativeDateModule
  ],
  templateUrl: './asset-dialog.component.html',
  styleUrls: ['./asset-dialog.component.scss']
})
export class AssetDialogComponent implements OnInit {
  assetForm: FormGroup;
  isViewMode: boolean = false;

  constructor(
    private fb: FormBuilder,
    public dialogRef: MatDialogRef<AssetDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: AssetDialogData
  ) {
    this.isViewMode = data.mode === 'view';
    this.assetForm = this.createForm();
  }

  ngOnInit(): void {
    if (this.data.asset) {
      this.assetForm.patchValue(this.data.asset);
    }
  }

  private createForm(): FormGroup {
    return this.fb.group({
      name: ['', Validators.required],
      type: ['', Validators.required],
      status: ['Available'],
      location: ['', Validators.required],
      condition: ['Good'],
      serialNumber: [''],
      purchasePrice: [''],
      acquisitionDate: [new Date()],
      maintenanceSchedule: [''],
      assignedDepartment: [''],
      description: ['']
    });
  }

  getDialogTitle(): string {
    switch (this.data.mode) {
      case 'add': return 'Add New Asset';
      case 'edit': return 'Edit Asset Details';
      case 'view': return 'Asset Details';
      default: return 'Asset Dialog';
    }
  }

  getDialogIcon(): string {
    switch (this.data.mode) {
      case 'add': return 'add_box';
      case 'edit': return 'edit';
      case 'view': return 'visibility';
      default: return 'inventory';
    }
  }

  onCancel(): void {
    this.dialogRef.close();
  }

  onSave(): void {
    if (this.assetForm.valid) {
      const assetData: Partial<Asset> = {
        ...this.assetForm.value
      };
      
      if (this.data.asset?.assetId) {
        assetData.assetId = this.data.asset.assetId;
      }
      
      this.dialogRef.close(assetData);
    }
  }
}