import { Component } from '@angular/core';
import { AuthService } from '../../services/auth.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-debug',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './debug.component.html'
})
export class DebugComponent {
  user: any;
  token: string | null;
  currentUrl: string;

  constructor(private authService: AuthService) {
    this.user = this.authService.user;
    this.token = this.authService.token;
    this.currentUrl = window.location.pathname;
  }

  get isAuthenticated() {
    return !!this.user;
  }
}