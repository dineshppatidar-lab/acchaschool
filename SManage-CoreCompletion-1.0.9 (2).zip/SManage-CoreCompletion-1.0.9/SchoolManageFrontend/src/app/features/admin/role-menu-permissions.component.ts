import { ChangeDetectorRef, Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatSelectModule } from '@angular/material/select';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatChipsModule } from '@angular/material/chips';
import { catchError, of } from 'rxjs';
import { UserRole, RoleLabels } from '../../core/models/permission.model';
import { RoleMenuPermissionsService, RoleMenuPermissionItem, SetRoleMenuPermissionRequest } from '../../services/role-menu-permissions.service';
import { firstValueFrom } from 'rxjs';


interface MenuItemNode {
  id: number;
  label: string;
  icon: string;
  route: string;
  category: string;
  displayOrder: number;
  canView: boolean;
  hasOverride: boolean;
  isActive: boolean;
  children: MenuItemNode[];
  expanded?: boolean;
}

@Component({
  selector: 'app-role-menu-permissions',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    MatCardModule,
    MatButtonModule,
    MatIconModule,
    MatSelectModule,
    MatFormFieldModule,
    MatSlideToggleModule,
    MatProgressSpinnerModule,
    MatSnackBarModule,
    MatTooltipModule,
    MatChipsModule,
  ],
  template: `
    <!-- ══════════════ MOBILE (≤767px): reference-faithful layout ══════════════ -->
    <!-- Mirrors the Roles & Permissions phone UI (permission-management.component):
         pill role selector, overview card, category accordion cards and a sticky
         save bar. The desktop layout below is hidden on phones and vice versa. -->
    <div class="mpm-mobile">
      <div class="mpm-section-label">
        <span class="mpm-label-caps">Select Role to Configure</span>
      </div>
      <div class="mpm-role-scroller">
        <div class="mpm-role-row" role="tablist" aria-label="Roles">
          <button type="button" role="tab"
                  *ngFor="let role of availableRoles"
                  class="mpm-role-pill"
                  [class.selected]="selectedRole === role"
                  (click)="selectedRole = role; onRoleChange()">
            <span class="mpm-pill-dot" *ngIf="selectedRole === role"></span>
            {{ getRoleLabel(role) }}
          </button>
        </div>
      </div>

      <ng-container *ngIf="selectedRole !== null">
        <!-- All / Visible / Hidden filter chips -->
        <div class="mpm-filter-row" *ngIf="!loading()">
          <button type="button" class="mpm-filter-pill" [class.selected]="filterMode === 'all'" (click)="showAll()">
            <mat-icon>list</mat-icon> All
          </button>
          <button type="button" class="mpm-filter-pill" [class.selected]="filterMode === 'visible'" (click)="showVisible()">
            <mat-icon>visibility</mat-icon> Visible
          </button>
          <button type="button" class="mpm-filter-pill" [class.selected]="filterMode === 'hidden'" (click)="showHidden()">
            <mat-icon>visibility_off</mat-icon> Hidden
          </button>
        </div>

        <!-- Active role overview card -->
        <div class="mpm-overview" *ngIf="!loading()">
          <div class="mpm-overhead">
            <h2>{{ getRoleLabel(selectedRole) }}</h2>
            <mat-icon class="mpm-verified">verified</mat-icon>
          </div>
          <p class="mpm-overdesc">Control which menu items this role sees in the sidebar. Changes apply on Save.</p>
          <div class="mpm-overbadges">
            <span class="mpm-level-badge">
              <mat-icon>menu</mat-icon>
              {{ totalVisibleItems() }}/{{ totalMenuItems() }} menus visible
            </span>
            <span class="mpm-level-badge warn" *ngIf="hasChanges()">
              <mat-icon>error</mat-icon>
              {{ getChangedCount() }} unsaved
            </span>
          </div>
        </div>

        <!-- Loading -->
        <div class="mpm-loading" *ngIf="loading()">
          <mat-progress-spinner mode="indeterminate" diameter="28"></mat-progress-spinner>
          <span>Loading menu permissions…</span>
        </div>

        <!-- Categories summary bar -->
        <div class="mpm-countbar" *ngIf="!loading()">
          <div class="mpm-countbar-left">
            <span class="mpm-label-caps">Menu Categories</span>
            <span class="mpm-active-badge">{{ activeCategoriesCount() }} Active</span>
          </div>
          <button type="button" class="mpm-toggleall" (click)="toggleAllMobileCategories()">
            {{ allCategoriesExpanded() ? 'Collapse All' : 'Expand All' }}
            <mat-icon>unfold_more</mat-icon>
          </button>
        </div>

        <!-- Category accordion cards -->
        <div class="mpm-modules" *ngIf="!loading()">
          <div class="mpm-module"
               *ngFor="let category of categories"
               [style.display]="getFilteredCategoryItems(category).length > 0 ? '' : 'none'">
            <button type="button" class="mpm-module-head" (click)="toggleMobileCategory(category)">
              <div class="mpm-module-icon" [class.granted]="getVisibleCountInCategory(category) > 0">
                <mat-icon>{{ getCategoryIcon(category) }}</mat-icon>
              </div>
              <div class="mpm-module-titles">
                <div class="mpm-module-title-row">
                  <h3>{{ category }}</h3>
                </div>
                <span class="mpm-module-sub">{{ getVisibleCountInCategory(category) }} of {{ getCategoryItemCount(category) }} visible</span>
              </div>
              <div class="mpm-module-side">
                <span class="mpm-count" [class.granted]="getVisibleCountInCategory(category) > 0">{{ getVisibleCountInCategory(category) }}/{{ getCategoryItemCount(category) }}</span>
                <mat-icon class="mpm-chev" [class.open]="isCategoryExpanded(category)">expand_more</mat-icon>
              </div>
            </button>

            <div class="mpm-module-body" *ngIf="isCategoryExpanded(category)">
              <!-- Category bulk actions -->
              <div class="mpm-cat-actions">
                <button type="button" class="mpm-cat-action on" (click)="toggleCategoryVisibility(category, true)">
                  <mat-icon>visibility</mat-icon> Show all
                </button>
                <button type="button" class="mpm-cat-action" (click)="toggleCategoryVisibility(category, false)">
                  <mat-icon>visibility_off</mat-icon> Hide all
                </button>
              </div>

              <!-- Menu item rows (parents + expandable children),
                   same state (item.expanded / canView) as the desktop layout -->
              <div class="mpm-item"
                   *ngFor="let item of getFilteredCategoryItems(category)"
                   [class.state-hidden]="!item.canView && item.isActive"
                   [class.state-disabled]="!item.isActive">
                <div class="mpm-item-row">
                  <button type="button" mat-icon-button class="mpm-expand"
                          *ngIf="item.children.length > 0"
                          (click)="item.expanded = !item.expanded"
                          [attr.aria-label]="(item.expanded ? 'Collapse ' : 'Expand ') + item.label">
                    <mat-icon>{{ item.expanded ? 'expand_more' : 'chevron_right' }}</mat-icon>
                  </button>
                  <mat-icon class="mpm-item-icon">{{ item.icon }}</mat-icon>
                  <div class="mpm-item-info">
                    <span class="mpm-item-label">
                      {{ item.label }}
                      <span class="mpm-custom-chip" *ngIf="item.hasOverride">Custom</span>
                    </span>
                    <span class="mpm-item-route">{{ item.route }}</span>
                  </div>
                  <mat-slide-toggle *ngIf="item.isActive"
                                    class="mpm-toggle"
                                    [checked]="item.canView"
                                    (change)="toggleVisibility(item, $event.checked)"
                                    color="primary">
                  </mat-slide-toggle>
                  <button type="button" *ngIf="!item.isActive" class="mpm-disabled-chip"
                          (click)="toggleGlobalActive(item)">
                    <mat-icon>block</mat-icon> Disabled
                  </button>
                </div>

                <div class="mpm-children" *ngIf="item.children.length > 0 && item.expanded">
                  <div class="mpm-item child"
                       *ngFor="let child of item.children"
                       [class.state-hidden]="!child.canView && child.isActive"
                       [class.state-disabled]="!child.isActive">
                    <div class="mpm-item-row">
                      <mat-icon class="mpm-item-icon small">{{ child.icon }}</mat-icon>
                      <div class="mpm-item-info">
                        <span class="mpm-item-label">
                          {{ child.label }}
                          <span class="mpm-custom-chip" *ngIf="child.hasOverride">Custom</span>
                        </span>
                        <span class="mpm-item-route">{{ child.route }}</span>
                      </div>
                      <mat-slide-toggle *ngIf="child.isActive"
                                        class="mpm-toggle"
                                        [checked]="child.canView"
                                        (change)="toggleVisibility(child, $event.checked)"
                                        color="primary">
                      </mat-slide-toggle>
                      <button type="button" *ngIf="!child.isActive" class="mpm-disabled-chip"
                              (click)="toggleGlobalActive(child)">
                        <mat-icon>block</mat-icon> Disabled
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Empty state (filter hides everything) -->
        <div class="mpm-empty" *ngIf="!loading() && categories.length > 0 && allItemsHiddenByFilter()">
          <mat-icon>visibility_off</mat-icon>
          <p>No menu items match this filter for {{ getRoleLabel(selectedRole) }}.</p>
        </div>
      </ng-container>

      <!-- Select-a-role prompt -->
      <div class="mpm-empty" *ngIf="selectedRole === null">
        <mat-icon>menu_open</mat-icon>
        <p>Select a role above to configure its menu visibility.</p>
      </div>

      <!-- Sticky save bar -->
      <div class="mpm-savebar" *ngIf="selectedRole !== null">
        <button type="button" class="mpm-reset" (click)="discardChanges()" [disabled]="saving() || !hasChanges()">Discard</button>
        <button type="button" class="mpm-save" (click)="saveChanges()" [disabled]="!hasChanges() || saving()">
          {{ saving() ? 'Saving…' : (hasChanges() ? 'Save ' + getChangedCount() + ' Change' + (getChangedCount() !== 1 ? 's' : '') : 'Saved') }}
        </button>
      </div>
    </div>

    <div class="menu-permissions-container">
      <div class="page-header">
        <h1>
          <mat-icon>menu_open</mat-icon>
          Menu Visibility Control
        </h1>
        <p class="page-description">
          Fine-grained control over which menu items each role can see.
          Overrides the default permission-based filtering.
        </p>
      </div>

      <mat-card class="selector-card">
        <mat-card-content>
          <div class="role-selector-row">
            <mat-form-field appearance="outline">
              <mat-label>Select Role</mat-label>
              <mat-select [(value)]="selectedRole" (selectionChange)="onRoleChange()">
                <mat-option *ngFor="let role of availableRoles" [value]="role">
                  {{ getRoleLabel(role) }}
                </mat-option>
              </mat-select>
            </mat-form-field>

            <div class="selector-actions" *ngIf="selectedRole !== null">
              <button mat-stroked-button (click)="showAll()" [class.active]="filterMode === 'all'">
                <mat-icon>list</mat-icon> All
              </button>
              <button mat-stroked-button (click)="showVisible()" [class.active]="filterMode === 'visible'">
                <mat-icon>visibility</mat-icon> Visible
              </button>
              <button mat-stroked-button (click)="showHidden()" [class.active]="filterMode === 'hidden'">
                <mat-icon>visibility_off</mat-icon> Hidden
              </button>
            </div>
          </div>

          <div class="bulk-actions" *ngIf="selectedRole !== null && hasChanges()">
            <span class="unsaved-badge">
              <mat-icon color="warn">warning</mat-icon>
              {{ getChangedCount() }} unsaved change{{ getChangedCount() !== 1 ? 's' : '' }}
            </span>
            <button mat-raised-button color="primary" (click)="saveChanges()" [disabled]="saving()">
              <mat-icon>save</mat-icon>
              {{ saving() ? 'Saving...' : 'Save Changes' }}
            </button>
            <button mat-stroked-button (click)="discardChanges()" [disabled]="saving()">
              <mat-icon>undo</mat-icon>
              Discard
            </button>
          </div>
        </mat-card-content>
      </mat-card>

      <div *ngIf="loading()" class="loading-spinner">
        <mat-progress-spinner mode="indeterminate" diameter="40"></mat-progress-spinner>
        <span>Loading menu permissions...</span>
      </div>

      <div class="menu-tree" *ngIf="!loading() && selectedRole !== null">
        <mat-card *ngFor="let category of categories" class="category-card">
          <mat-card-header>
            <mat-card-title>
              <mat-icon>{{ getCategoryIcon(category) }}</mat-icon>
              {{ category }}
              <mat-chip class="visible-count">
                {{ getVisibleCountInCategory(category) }} / {{ getCategoryItemCount(category) }} visible
              </mat-chip>
            </mat-card-title>
            <div class="category-actions">
              <button mat-stroked-button (click)="toggleCategoryVisibility(category, true)"
                      matTooltip="Show all in {{ category }}">
                <mat-icon>visibility</mat-icon> Show All
              </button>
              <button mat-stroked-button (click)="toggleCategoryVisibility(category, false)"
                      matTooltip="Hide all in {{ category }}">
                <mat-icon>visibility_off</mat-icon> Hide All
              </button>
            </div>
          </mat-card-header>
          <mat-card-content>
            <div class="menu-items-list">
              <ng-container *ngFor="let item of getFilteredCategoryItems(category)">
                <!-- Parent item (has children) -->
                <div class="menu-item parent-item" *ngIf="item.children.length > 0" [class.hidden-item]="!item.canView">
                  <div class="item-row">
                    <button mat-icon-button (click)="item.expanded = !item.expanded" class="expand-btn">
                      <mat-icon>{{ item.expanded ? 'expand_more' : 'chevron_right' }}</mat-icon>
                    </button>
                    <mat-icon class="item-icon">{{ item.icon }}</mat-icon>
                    <div class="item-info">
                      <span class="item-label">{{ item.label }}</span>
                      <span class="item-route">{{ item.route }}</span>
                    </div>
                    <div class="item-status">
                      <mat-chip *ngIf="!item.isActive" class="disabled-chip" (click)="toggleGlobalActive(item)"
                                matTooltip="Menu is disabled for all roles — click to enable for everyone">
                        <mat-icon class="chip-icon">block</mat-icon>
                        Disabled
                      </mat-chip>
                      <mat-chip *ngIf="item.hasOverride" color="accent" selected>
                        <mat-icon class="chip-icon">edit</mat-icon>
                        Custom
                      </mat-chip>
                    </div>
                    <mat-slide-toggle
                      [checked]="item.canView"
                      (change)="toggleVisibility(item, $event.checked)"
                      color="primary"
                      [disabled]="!item.isActive"
                      [matTooltip]="!item.isActive ? 'Menu is disabled for all roles — click the Disabled chip to enable' : (item.canView ? 'Visible - click to hide' : 'Hidden - click to show')"
                    >
                      {{ item.canView ? 'Visible' : 'Hidden' }}
                    </mat-slide-toggle>
                  </div>
                  <!-- Children -->
                  <div class="children-list" *ngIf="item.expanded">
                    <div class="menu-item child-item" *ngFor="let child of item.children"
                         [class.hidden-item]="!child.canView">
                      <div class="item-row child-row">
                        <mat-icon class="item-icon small">{{ child.icon }}</mat-icon>
                        <div class="item-info">
                          <span class="item-label">{{ child.label }}</span>
                          <span class="item-route">{{ child.route }}</span>
                        </div>
                        <div class="item-status">
                          <mat-chip *ngIf="!child.isActive" class="disabled-chip" (click)="toggleGlobalActive(child)"
                                    matTooltip="Menu is disabled for all roles — click to enable for everyone">
                            <mat-icon class="chip-icon">block</mat-icon>
                            Disabled
                          </mat-chip>
                          <mat-chip *ngIf="child.hasOverride" color="accent" selected>
                            <mat-icon class="chip-icon">edit</mat-icon>
                            Custom
                          </mat-chip>
                        </div>
                        <mat-slide-toggle
                          [checked]="child.canView"
                          (change)="toggleVisibility(child, $event.checked)"
                          color="primary"
                          [disabled]="!child.isActive"
                          [matTooltip]="!child.isActive ? 'Menu is disabled for all roles — click the Disabled chip to enable' : undefined"
                        >
                          {{ child.canView ? 'Visible' : 'Hidden' }}
                        </mat-slide-toggle>
                      </div>
                    </div>
                  </div>
                </div>
                <!-- Leaf item (no children) -->
                <div class="menu-item leaf-item" *ngIf="item.children.length === 0" [class.hidden-item]="!item.canView">
                  <div class="item-row">
                    <mat-icon class="item-icon small indent-icon">{{ item.icon }}</mat-icon>
                    <div class="item-info">
                      <span class="item-label">{{ item.label }}</span>
                      <span class="item-route">{{ item.route }}</span>
                    </div>
                    <div class="item-status">
                      <mat-chip *ngIf="!item.isActive" class="disabled-chip" (click)="toggleGlobalActive(item)"
                                matTooltip="Menu is disabled for all roles — click to enable for everyone">
                        <mat-icon class="chip-icon">block</mat-icon>
                        Disabled
                      </mat-chip>
                      <mat-chip *ngIf="item.hasOverride" color="accent" selected>
                        <mat-icon class="chip-icon">edit</mat-icon>
                        Custom
                      </mat-chip>
                    </div>
                    <mat-slide-toggle
                      [checked]="item.canView"
                      (change)="toggleVisibility(item, $event.checked)"
                      color="primary"
                      [disabled]="!item.isActive"
                      [matTooltip]="!item.isActive ? 'Menu is disabled for all roles — click the Disabled chip to enable' : (item.canView ? 'Visible - click to hide' : 'Hidden - click to show')"
                    >
                      {{ item.canView ? 'Visible' : 'Hidden' }}
                    </mat-slide-toggle>
                  </div>
                </div>
              </ng-container>
            </div>
          </mat-card-content>
        </mat-card>
      </div>

      <mat-card *ngIf="selectedRole === null && !loading()" class="empty-state">
        <mat-card-content>
          <mat-icon class="empty-icon">menu_open</mat-icon>
          <h2>Select a Role</h2>
          <p>Choose a role above to configure its menu visibility.</p>
        </mat-card-content>
      </mat-card>
    </div>
  `,
  styles: [`
    .menu-permissions-container {
      padding: 24px;
      max-width: 1200px;
      margin: 0 auto;
    }
    .page-header {
      margin-bottom: 24px;
    }
    .page-header h1 {
      display: flex;
      align-items: center;
      gap: 12px;
      margin: 0 0 8px 0;
      font-size: 28px;
      font-weight: 500;
      color: var(--md-on-surface);
    }
    .page-description {
      color: var(--color-text-secondary);
      margin: 0;
      font-size: 14px;
    }
    .selector-card {
      margin-bottom: 24px;
    }
    .role-selector-row {
      display: flex;
      align-items: flex-start;
      gap: 24px;
      flex-wrap: wrap;
    }
    .role-selector-row mat-form-field {
      min-width: 250px;
    }
    .selector-actions {
      display: flex;
      gap: 8px;
      align-items: center;
      padding-top: 6px;
    }
    .selector-actions button.active {
      background: var(--md-primary-container);
      border-color: var(--md-primary);
    }
    .bulk-actions {
      display: flex;
      align-items: center;
      gap: 12px;
      margin-top: 16px;
      padding-top: 16px;
      border-top: 1px solid var(--color-border);
    }
    .unsaved-badge {
      display: flex;
      align-items: center;
      gap: 4px;
      color: var(--md-warning);
      font-weight: 500;
      flex: 1;
    }
    .loading-spinner {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 16px;
      padding: 60px 0;
      color: var(--color-text-secondary);
    }
    .category-card {
      margin-bottom: 16px;
    }
    .category-card mat-card-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 12px 16px;
      background: var(--md-surface-container-low);
      border-radius: 4px;
    }
    .category-card mat-card-title {
      display: flex;
      align-items: center;
      gap: 8px;
      margin: 0;
      font-size: 16px;
    }
    .category-actions {
      display: flex;
      gap: 8px;
    }
    .visible-count {
      margin-left: 8px;
    }
    .menu-items-list {
      padding: 8px 0;
    }
    .menu-item {
      border-bottom: 1px solid var(--md-surface-container-low);
    }
    .menu-item:last-child {
      border-bottom: none;
    }
    .item-row {
      display: flex;
      align-items: center;
      padding: 10px 16px;
      gap: 8px;
      transition: background 0.15s;
    }
    .item-row:hover {
      background: var(--md-surface-container-low);
    }
    .child-row {
      padding-left: 48px;
    }
    .hidden-item {
      opacity: 0.5;
    }
    .hidden-item .item-row {
      background: var(--md-warning-container);
    }
    .disabled-chip {
      cursor: pointer;
    }
    .disabled-chip:hover {
      opacity: 0.8;
    }
    .expand-btn {
      width: 32px;
      height: 32px;
    }
    .item-icon {
      color: var(--color-text-secondary);
      font-size: 20px;
      width: 24px;
      height: 24px;
    }
    .item-icon.small {
      font-size: 18px;
    }
    .indent-icon {
      margin-left: 40px;
    }
    .item-info {
      flex: 1;
      display: flex;
      flex-direction: column;
      min-width: 0;
    }
    .item-label {
      font-weight: 500;
      font-size: 14px;
      color: var(--md-on-surface);
    }
    .item-route {
      font-size: 12px;
      color: var(--md-outline);
      font-family: monospace;
    }
    .item-status {
      margin-right: 8px;
    }
    .chip-icon {
      font-size: 14px;
      width: 14px;
      height: 14px;
      margin-right: 4px;
    }
    .empty-state {
      text-align: center;
      padding: 60px 24px;
    }
    .empty-icon {
      font-size: 64px;
      width: 64px;
      height: 64px;
      color: var(--color-border);
    }
    .empty-state h2 {
      margin: 16px 0 8px;
      color: var(--color-text-secondary);
    }
    .empty-state p {
      color: var(--md-outline);
    }
    @media (max-width: 768px) {
      .menu-permissions-container { padding: 16px; }
      .role-selector-row { flex-direction: column; }
      .category-card mat-card-header { flex-direction: column; gap: 8px; }
      .item-row { flex-wrap: wrap; }
    }

    /* Default: the phone layout stays off on desktop */
    .mpm-mobile { display: none; }

    /* ============================================================
       MOBILE (≤767px) — Menu Visibility Control, reference-faithful.
       Same design language as Roles & Permissions phone layout
       (rpm-* styles in permission-management.component.scss):
       the desktop card stack is hidden below and this becomes the
       whole screen. All business logic (toggles, bulk show/hide,
       save, discard, global enable) is the same component instance.
       ============================================================ */
    @media (max-width: 767px) {
      .menu-permissions-container { display: none; }
      .mpm-mobile { display: block; padding: 8px 12px 4px; }

      .mpm-section-label { padding: 4px 2px 8px; }
      .mpm-label-caps {
        font-size: 11px;
        font-weight: 700;
        letter-spacing: 0.08em;
        text-transform: uppercase;
        color: var(--color-text-secondary, #64748b);
      }

      /* ── Role pill chips (horizontal scroller) ── */
      .mpm-role-scroller {
        overflow-x: auto;
        scrollbar-width: none;
        margin: 0 -8px;
        padding: 0 8px 6px;
        &::-webkit-scrollbar { display: none; }
      }
      .mpm-role-row {
        display: flex;
        gap: 8px;
        min-width: max-content;
      }
      .mpm-role-pill {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        min-height: 42px;
        padding: 0 16px;
        border: none;
        border-radius: var(--radius-full, 9999px);
        background: var(--color-card, #fff);
        color: var(--color-text-secondary, #334155);
        font-family: var(--font-family);
        font-size: 12px;
        font-weight: 600;
        letter-spacing: 0.02em;
        cursor: pointer;
        box-shadow: var(--shadow-sm);
        white-space: nowrap;
        transition: background 0.15s, color 0.15s;

        &.selected {
          background: var(--md-primary-container, #dde1ff);
          color: var(--md-on-primary-container);
          font-weight: 700;
          box-shadow: var(--shadow-md);
        }
      }
      .mpm-pill-dot {
        width: 8px;
        height: 8px;
        border-radius: 50%;
        background: var(--md-success, #047857);
        animation: mpmPulse 2s ease-in-out infinite;
      }
      @keyframes mpmPulse {
        0%, 100% { opacity: 1; }
        50% { opacity: 0.45; }
      }

      /* All / Visible / Hidden filter chips */
      .mpm-filter-row {
        display: flex;
        align-items: center;
        gap: 6px;
        overflow-x: auto;
        scrollbar-width: none;
        padding-bottom: 6px;
        &::-webkit-scrollbar { display: none; }
      }
      .mpm-filter-pill {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        min-height: 36px;
        padding: 0 12px;
        border: 1px solid var(--color-border, #e2e8f0);
        border-radius: var(--radius-full, 9999px);
        background: var(--color-card, #fff);
        color: var(--color-text-secondary, #334155);
        font-family: var(--font-family);
        font-size: 11px;
        font-weight: 600;
        cursor: pointer;
        white-space: nowrap;

        mat-icon { font-size: var(--font-size-base); width: 15px; height: 15px; }

        &.selected {
          border-color: var(--md-primary);
          background: var(--md-primary-container, #dde1ff);
          color: var(--md-on-primary-container);
        }
      }

      /* ── Active role overview card ── */
      .mpm-overview {
        background: var(--color-card, #fff);
        border-radius: var(--radius-lg, 12px);
        box-shadow: var(--shadow-sm);
        padding: 14px 16px 0;
        margin-bottom: 12px;
        overflow: hidden;
      }
      .mpm-overhead {
        display: flex;
        align-items: center;
        gap: 6px;

        h2 {
          margin: 0;
          font-size: 18px;
          font-weight: 700;
          color: var(--md-on-surface, #131b2e);
        }
      }
      .mpm-verified {
        color: var(--md-primary);
        font-size: 20px;
        width: 20px;
        height: 20px;
      }
      .mpm-overdesc {
        margin: 4px 0 0;
        font-size: 13px;
        line-height: 1.5;
        color: var(--color-text-muted, #64748b);
      }
      .mpm-overbadges {
        display: flex;
        flex-wrap: wrap;
        gap: 8px;
        margin: 12px -16px 0;
        padding: 10px 16px 12px;
        background: color-mix(in srgb, var(--md-surface-container-low) 60%, transparent);
      }
      .mpm-level-badge {
        display: inline-flex;
        align-items: center;
        gap: 5px;
        padding: 4px 10px;
        border-radius: var(--radius-full, 9999px);
        background: var(--color-card, #fff);
        box-shadow: var(--shadow-sm);
        font-size: 11px;
        font-weight: 600;
        color: var(--color-text-secondary, #334155);

        mat-icon { font-size: var(--font-size-base); width: 15px; height: 15px; color: var(--md-tertiary, #003c36); }
        &.warn mat-icon { color: var(--md-warning, #b45309); }
      }

      .mpm-loading {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 24px 4px;

        span { font-size: 13px; color: var(--color-text-secondary); }
      }

      /* ── Categories summary bar ── */
      .mpm-countbar {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 0 2px 8px;
      }
      .mpm-countbar-left {
        display: flex;
        align-items: center;
        gap: 8px;
      }
      .mpm-active-badge {
        padding: 2px 8px;
        border-radius: var(--radius-full, 9999px);
        background: rgba(0, 40, 142, 0.1);
        color: var(--md-primary);
        font-size: 11px;
        font-weight: 700;
      }
      .mpm-toggleall {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        border: none;
        background: transparent;
        color: var(--color-text-muted, #64748b);
        font-family: var(--font-family);
        font-size: 11px;
        font-weight: 600;
        cursor: pointer;
        padding: 8px 4px;

        mat-icon { font-size: 16px; width: 16px; height: 16px; }
        &:hover { color: var(--md-on-surface); }
      }

      /* ── Category accordion cards ── */
      .mpm-modules {
        display: flex;
        flex-direction: column;
        gap: 10px;
        padding-bottom: calc(72px + env(safe-area-inset-bottom, 0px));
      }
      .mpm-module {
        background: var(--color-card, #fff);
        border-radius: var(--radius-lg, 12px);
        box-shadow: var(--shadow-sm);
        overflow: hidden;
      }
      .mpm-module-head {
        display: flex;
        align-items: center;
        gap: 10px;
        width: 100%;
        padding: 12px;
        border: none;
        background: transparent;
        text-align: left;
        cursor: pointer;
        font-family: var(--font-family);

        &:hover { background: var(--md-surface-container-low); }
      }
      .mpm-module-icon {
        width: 36px;
        height: 36px;
        border-radius: var(--radius-md, 8px);
        display: flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
        background: var(--md-surface-container, #eaedff);
        color: var(--md-on-surface-variant, #444653);

        mat-icon { font-size: 20px; width: 20px; height: 20px; }

        &.granted {
          background: var(--md-success-container, var(--md-success-container));
          color: var(--md-success, #047857);
        }
      }
      .mpm-module-titles {
        flex: 1;
        min-width: 0;
      }
      .mpm-module-title-row {
        display: flex;
        align-items: center;
        gap: 6px;
        min-width: 0;

        h3 {
          margin: 0;
          font-size: 14px;
          font-weight: 600;
          color: var(--md-on-surface, #131b2e);
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
        }
      }
      .mpm-module-sub {
        display: block;
        font-size: 12px;
        color: var(--color-text-muted, #64748b);
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
      .mpm-module-side {
        display: flex;
        align-items: center;
        gap: 4px;
        flex-shrink: 0;
      }
      .mpm-count {
        font-size: 11px;
        font-weight: 700;
        color: var(--color-text-muted, #64748b);

        &.granted { color: var(--md-success, #047857); }
      }
      .mpm-chev {
        color: var(--color-text-muted, #64748b);
        font-size: 20px;
        width: 20px;
        height: 20px;
        transition: transform 0.2s;

        &.open { transform: rotate(180deg); }
      }

      /* Category body */
      .mpm-module-body {
        display: flex;
        flex-direction: column;
        padding: 4px 12px 10px;
      }
      .mpm-cat-actions {
        display: flex;
        gap: 6px;
        padding: 4px 0 8px;
      }
      .mpm-cat-action {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        min-height: 32px;
        padding: 0 10px;
        border: 1px solid var(--color-border, #e2e8f0);
        border-radius: var(--radius-full, 9999px);
        background: var(--color-card, #fff);
        color: var(--color-text-secondary, #334155);
        font-family: var(--font-family);
        font-size: 11px;
        font-weight: 600;
        cursor: pointer;

        mat-icon { font-size: 14px; width: 14px; height: 14px; }
        &.on { border-color: var(--md-success, #047857); color: var(--md-success, #047857); }
      }

      /* Menu item rows */
      .mpm-item {
        border-bottom: 1px solid var(--color-border, #e2e8f0);
        transition: background 0.15s;

        &:last-child { border-bottom: none; }
        &.state-hidden { background: color-mix(in srgb, var(--md-warning-container) 35%, transparent); }
      }
      .mpm-item-row {
        display: flex;
        align-items: center;
        gap: 6px;
        padding: 8px 0;
      }
      .mpm-expand {
        width: 28px;
        height: 28px;
        flex-shrink: 0;

        mat-icon { font-size: 20px; width: 20px; height: 20px; }
      }
      .mpm-item-icon {
        color: var(--color-text-secondary, #64748b);
        font-size: 18px;
        width: 18px;
        height: 18px;
        flex-shrink: 0;

        &.small { font-size: 16px; width: 16px; height: 16px; }
      }
      .mpm-item-info {
        flex: 1;
        min-width: 0;
        display: flex;
        flex-direction: column;
        gap: 1px;
      }
      .mpm-item-label {
        display: flex;
        align-items: center;
        gap: 6px;
        min-width: 0;
        font-size: 13px;
        font-weight: 600;
        color: var(--md-on-surface, #131b2e);
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }
      .mpm-custom-chip {
        flex-shrink: 0;
        padding: 1px 6px;
        border-radius: var(--radius-sm, 6px);
        background: var(--md-warning-container, var(--md-warning-container));
        color: var(--md-warning, #b45309);
        font-size: 9px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.03em;
      }
      .mpm-item-route {
        font-size: 11px;
        color: var(--md-outline, #79747e);
        font-family: monospace;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }
      .mpm-toggle {
        flex-shrink: 0;
      }
      .mpm-disabled-chip {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        min-height: 32px;
        padding: 0 10px;
        border: 1px solid var(--md-warning, #b45309);
        border-radius: var(--radius-full, 9999px);
        background: var(--md-warning-container, var(--md-warning-container));
        color: var(--md-warning, #b45309);
        font-family: var(--font-family);
        font-size: 10px;
        font-weight: 700;
        cursor: pointer;
        flex-shrink: 0;

        mat-icon { font-size: 14px; width: 14px; height: 14px; }
      }

      /* Children (indented under the expanded parent) */
      .mpm-children {
        display: flex;
        flex-direction: column;
        margin: 0 0 4px 40px;
      }
      .mpm-item.child .mpm-item-row { padding: 6px 0; }

      /* Empty state */
      .mpm-empty {
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 8px;
        padding: 48px 24px;
        text-align: center;

        mat-icon { font-size: 48px; width: 48px; height: 48px; color: var(--color-border, #c7ccd0); }
        p { margin: 0; font-size: 13px; color: var(--color-text-secondary, #64748b); }
      }

      /* ── Sticky save bar ── */
      .mpm-savebar {
        display: flex;
        gap: 8px;
        position: fixed;
        bottom: calc(var(--bottom-nav-height, 64px) + env(safe-area-inset-bottom, 0px));
        left: 0;
        right: 0;
        z-index: 95;
        padding: 10px 12px 12px;
        background: var(--color-card, #fff);
        border-top: 1px solid var(--color-border, #e2e8f0);
        box-shadow: 0 -4px 14px rgba(0, 0, 0, 0.08);
      }
      .mpm-reset {
        flex: 0 0 auto;
        min-height: 44px;
        padding: 0 18px;
        border: 1px solid var(--color-border, #e2e8f0);
        border-radius: var(--radius-full, 9999px);
        background: var(--md-surface-container-low, var(--md-surface-container-low));
        color: var(--color-text-secondary, #334155);
        font-family: var(--font-family);
        font-size: 12px;
        font-weight: 600;
        cursor: pointer;

        &:disabled { opacity: 0.5; cursor: default; }
      }
      .mpm-save {
        flex: 1;
        min-height: 44px;
        border: none;
        border-radius: var(--radius-full, 9999px);
        background: var(--md-primary, #00288e);
        color: var(--md-on-primary, #fff);
        font-family: var(--font-family);
        font-size: 12px;
        font-weight: 700;
        letter-spacing: 0.02em;
        cursor: pointer;

        &:disabled {
          background: var(--md-surface-container-high, #e2e7ff);
          color: var(--md-on-surface-variant, #444653);
          cursor: default;
        }
      }
    }
  `]
})
export class RoleMenuPermissionsComponent implements OnInit {
  selectedRole: UserRole | null = null;
  loading = signal(false);
  saving = signal(false);
  hasChanges = signal(false);
  filterMode: 'all' | 'visible' | 'hidden' = 'all';

  availableRoles: UserRole[] = Object.values(UserRole).filter(v => typeof v === 'number') as UserRole[];

  // Zoneless app: mobile accordion state must be signal-backed so the
  // phone layout re-renders when categories expand/collapse.
  /** Mobile (≤767px) accordion state — which menu categories are expanded. */
  readonly mobileExpandedCategories = signal<Set<string>>(new Set());

  /** Flat list of all menu items with their original visibility */
  private allItems = signal<any[]>([]);
  /** Tree structure for rendering */
  menuTree: MenuItemNode[] = [];
  /** Categories extracted from items */
  categories: string[] = [];
  /** Track original values for dirty checking */
  private originalState: Map<number, boolean> = new Map();

  constructor(
    private service: RoleMenuPermissionsService,
    private snackBar: MatSnackBar,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {}

  onRoleChange(): void {
    if (this.selectedRole === null) return;
    this.loading.set(true);
    this.hasChanges.set(false);
    this.originalState.clear();

    this.service.getRoleMenuPermissions(this.selectedRole).pipe(
      catchError(err => {
        console.error(err);
        this.snackBar.open('Failed to load menu permissions', 'Close', { duration: 3000 });
        this.loading.set(false);
        this.cdr.markForCheck();
        return of([]);
      })
    ).subscribe((items: RoleMenuPermissionItem[]) => {
      this.allItems.set(items);
      this.buildTree();
      this.extractCategories();
      this.loading.set(false);
      this.cdr.markForCheck();
    });
  }

  /** Build parent-child tree from flat list */
  private buildTree(): void {
    const itemMap = new Map<number, MenuItemNode>();
    this.menuTree = [];

    // First pass: create nodes
    for (const item of this.allItems()) {
      itemMap.set(item.menuItemId, {
        id: item.menuItemId,
        label: item.menuItemLabel,
        icon: this.getItemIcon(item),
        route: item.menuItemRoute,
        category: item.category,
        displayOrder: item.displayOrder,
        canView: item.canView,
        hasOverride: item.hasOverride,
        isActive: item.isActive !== false,
        children: [],
        expanded: true
      });
      this.originalState.set(item.menuItemId, item.canView);
    }

    // Second pass: build tree
    for (const item of this.allItems()) {
      const node = itemMap.get(item.menuItemId)!;
      if (item.parentId && itemMap.has(item.parentId)) {
        itemMap.get(item.parentId)!.children.push(node);
      } else {
        this.menuTree.push(node);
      }
    }

    // Sort by display order
    this.menuTree.sort((a, b) => a.displayOrder - b.displayOrder);
    for (const parent of this.menuTree) {
      parent.children.sort((a, b) => a.displayOrder - b.displayOrder);
    }
  }

  private extractCategories(): void {
    const catSet = new Set<string>();
    for (const item of this.allItems()) {
      if (item.category) catSet.add(item.category);
    }
    this.categories = Array.from(catSet).sort();
  }

  private getItemIcon(item: RoleMenuPermissionItem): string {
    // Derive a reasonable icon from the menu label
    const label = (item.menuItemLabel || '').toLowerCase();
    if (label.includes('dashboard')) return 'dashboard';
    if (label.includes('academic') || label.includes('class')) return 'auto_stories';
    if (label.includes('student')) return 'school';
    if (label.includes('fee') || label.includes('finance') || label.includes('payroll')) return 'account_balance_wallet';
    if (label.includes('staff') || label.includes('hr') || label.includes('human')) return 'badge';
    if (label.includes('communication') || label.includes('message')) return 'campaign';
    if (label.includes('hostel') || label.includes('infrastructure')) return 'corporate_fare';
    if (label.includes('report') || label.includes('analytics')) return 'analytics';
    if (label.includes('admin') || label.includes('system')) return 'admin_panel_settings';
    if (label.includes('library')) return 'local_library';
    if (label.includes('transport')) return 'directions_bus';
    if (label.includes('exam')) return 'quiz';
    if (label.includes('attendance')) return 'how_to_reg';
    if (label.includes('subject')) return 'library_books';
    if (label.includes('timetable')) return 'schedule';
    return item.menuItemLabel ? item.menuItemLabel[0].toLowerCase() : 'circle';
  }

  getCategoryIcon(category: string): string {
    const map: { [k: string]: string } = {
      'General': 'dashboard',
      'Academic': 'auto_stories',
      'Students': 'school',
      'Finance': 'account_balance_wallet',
      'HR': 'badge',
      'Communication': 'campaign',
      'Infrastructure': 'corporate_fare',
      'Reports': 'analytics',
      'Admin': 'admin_panel_settings'
    };
    return map[category] || 'folder';
  }

  toggleVisibility(item: MenuItemNode, visible: boolean): void {
    item.canView = visible;
    // Also update children
    this.setChildrenVisibility(item, visible);
    this.checkDirty();
  }

  /**
   * Global (all-roles) on/off switch. Persists immediately — unlike the per-role
   * toggles, which are batched until Save Changes.
   */
  async toggleGlobalActive(item: MenuItemNode): Promise<void> {
    const enable = !item.isActive;
    if (!confirm(`Make "${item.label}" ${enable ? 'visible to all roles (enabled)' : 'hidden for all roles (disabled)'}?`)) {
      return;
    }
    try {
      await firstValueFrom(this.service.setMenuItemActive(item.id, enable));
      item.isActive = enable;
      if (enable) {
        // Newly enabled menus start visible for the selected role
        item.canView = true;
        this.originalState.set(item.id, true);
      }
      this.snackBar.open(`"${item.label}" ${enable ? 'enabled' : 'disabled'} for all roles`, 'OK', { duration: 3000 });
      this.cdr.markForCheck();
    } catch (err) {
      console.error('Failed to toggle global menu state', err);
      this.snackBar.open('Failed to update menu state', 'Dismiss', { duration: 3000 });
    }
  }

  private setChildrenVisibility(item: MenuItemNode, visible: boolean): void {
    for (const child of item.children) {
      child.canView = visible;
      this.setChildrenVisibility(child, visible);
    }
  }

  toggleCategoryVisibility(category: string, visible: boolean): void {
    for (const item of this.menuTree) {
      if (item.category === category) {
        item.canView = visible;
        this.setChildrenVisibility(item, visible);
      }
    }
    this.checkDirty();
  }

  private findNode(id: number, nodes: MenuItemNode[] = this.menuTree): MenuItemNode | undefined {
    for (const node of nodes) {
      if (node.id === id) return node;
      const found = this.findNode(id, node.children);
      if (found) return found;
    }
    return undefined;
  }

  showAll(): void { this.filterMode = 'all'; }
  showVisible(): void { this.filterMode = 'visible'; }
  showHidden(): void { this.filterMode = 'hidden'; }

  getFilteredCategoryItems(category: string): MenuItemNode[] {
    let items = this.menuTree.filter(i => i.category === category);
    if (this.filterMode === 'visible') items = items.filter(i => i.canView);
    if (this.filterMode === 'hidden') items = items.filter(i => !i.canView);
    return items;
  }

  getVisibleCountInCategory(category: string): number {
    // Inactive (globally disabled) items can never be visible.
    return this.allItems().filter(i => i.category === category && i.canView && i.isActive !== false).length;
  }

  getCategoryItemCount(category: string): number {
    return this.allItems().filter(i => i.category === category).length;
  }

  getRoleLabel(role: UserRole): string {
    return RoleLabels[role] || role.toString();
  }

  getChangedCount(): number {
    let count = 0;
    for (const item of this.allItems()) {
      const orig = this.originalState.get(item.menuItemId);
      const node = this.findNode(item.menuItemId);
      if (node && orig !== undefined && orig !== node.canView) count++;
    }
    return count;
  }

  private checkDirty(): void {
    this.hasChanges.set(this.getChangedCount() > 0);
  }

  saveChanges(): void {
    if (this.selectedRole === null || !this.hasChanges()) return;
    this.saving.set(true);

    const permissions: SetRoleMenuPermissionRequest[] = this.allItems().map(item => {
      const node = this.findNode(item.menuItemId);
      return {
        menuItemId: item.menuItemId,
        canView: node ? node.canView : item.canView
      };
    });

    this.service.bulkSetRoleMenuPermissions(this.selectedRole, permissions).subscribe({
      next: () => {
        this.saving.set(false);
        this.hasChanges.set(false);
        // Update original state
        this.originalState.clear();
        for (const item of this.allItems()) {
          const node = this.findNode(item.menuItemId);
          if (node) this.originalState.set(item.menuItemId, node.canView);
        }
        this.snackBar.open('Menu permissions saved successfully', 'Close', { duration: 3000 });
        this.cdr.markForCheck();
      },
      error: () => {
        this.saving.set(false);
        this.snackBar.open('Failed to save menu permissions', 'Close', { duration: 3000 });
        this.cdr.markForCheck();
      }
    });
  }

  discardChanges(): void {
    // Reset all items to original state
    for (const item of this.allItems()) {
      const node = this.findNode(item.menuItemId);
      const orig = this.originalState.get(item.menuItemId);
      if (node && orig !== undefined) {
        node.canView = orig;
      }
    }
    this.hasChanges.set(false);
    this.cdr.markForCheck();
  }

  // ── Mobile (≤767px) layout helpers — reuse the same business state ──

  isCategoryExpanded(category: string): boolean {
    return this.mobileExpandedCategories().has(category);
  }

  toggleMobileCategory(category: string): void {
    const set = new Set(this.mobileExpandedCategories());
    set.has(category) ? set.delete(category) : set.add(category);
    this.mobileExpandedCategories.set(set);
  }

  allCategoriesExpanded(): boolean {
    return this.categories.length > 0 && this.mobileExpandedCategories().size >= this.categories.length;
  }

  toggleAllMobileCategories(): void {
    this.mobileExpandedCategories.set(
      this.allCategoriesExpanded() ? new Set() : new Set(this.categories)
    );
  }

  activeCategoriesCount(): number {
    let count = 0;
    for (const category of this.categories) {
      if (this.getVisibleCountInCategory(category) > 0) count++;
    }
    return count;
  }

  totalVisibleItems(): number {
    return this.allItems().filter(i => {
      const node = this.findNode(i.menuItemId);
      const canView = node ? node.canView : i.canView;
      return canView && i.isActive !== false;
    }).length;
  }

  totalMenuItems(): number {
    return this.allItems().length;
  }

  /** True when the current All/Visible/Hidden filter leaves every category empty. */
  allItemsHiddenByFilter(): boolean {
    return this.categories.every(c => this.getFilteredCategoryItems(c).length === 0);
  }
}
