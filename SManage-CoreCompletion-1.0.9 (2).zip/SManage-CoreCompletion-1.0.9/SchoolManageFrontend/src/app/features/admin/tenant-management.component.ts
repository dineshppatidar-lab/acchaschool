import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TenantService, TenantDto } from '../../services/tenant.service';
import { MatCardModule } from '@angular/material/card';
import { MatTableModule } from '@angular/material/table';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatTooltipModule } from '@angular/material/tooltip';
import { FormsModule, ReactiveFormsModule, FormBuilder, Validators, AbstractControl, ValidationErrors } from '@angular/forms';
import { PermissionService } from '../../core/services/permission.service';
import { UserRole, Permission } from '../../core/models/permission.model';
import { PageHeaderComponent } from '../../shared/components/page-patterns/page-header.component';
import { debounceTime, distinctUntilChanged, switchMap, catchError, tap, of, Subject } from 'rxjs';

@Component({
  selector: 'app-tenant-management',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatCardModule,
    MatTableModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatSlideToggleModule,
    MatIconModule,
    MatProgressSpinnerModule,
    MatTooltipModule,
    PageHeaderComponent
  ],
  templateUrl: './tenant-management.component.html',
  styleUrls: ['./tenant-management.component.scss']
})
export class TenantManagementComponent implements OnInit {
  tenants = signal<any[]>([]);
  loading = signal(false);
  error = signal('');
  isSuperAdmin = false;
  domainHint = signal('');
  testingBinding = signal(false);
  isEditMode = signal(false);
  editingTenantId: number | null = null;  form = {} as ReturnType<FormBuilder['group']>;
  private domainValueChanges$ = new Subject<string>();

  displayedColumns = ['id', 'name', 'domain', 'logoUrl', 'isActive', 'actions'];

  constructor(
    private tenantService: TenantService, 
    private fb: FormBuilder, 
    private cdr: ChangeDetectorRef,
    private permissionService: PermissionService
  ) {
    this.form = this.fb.group({
      name: this.fb.control('', [Validators.required, Validators.minLength(3)]),
      domain: this.fb.control('', this.domainValidator()),
      logoUrl: this.fb.control(''),
      welcomeText: this.fb.control(''),
      isActive: this.fb.control(true)
    });

    // Live "Test binding" preview while typing a domain
    this.domainValueChanges$
      .pipe(
        debounceTime(600),
        distinctUntilChanged(),
        switchMap(domain => {
          const d = (domain || '').trim().toLowerCase();
          if (!d) { this.domainHint.set(''); return of(null); }
          this.testingBinding.set(true);
          return this.tenantService.resolveDomain(d).pipe(
            catchError(() => of(null)),
            tap(() => { this.testingBinding.set(false); })
          );
        })
      )
      .subscribe((res: any) => {
        this.testingBinding.set(false);
        const d = (this.form.get('domain')?.value || '').trim().toLowerCase();
        if (!d) { this.domainHint.set(''); }
        else if (res?.matched) {
          this.domainHint.set(`Currently bound to: ${res.tenantName} (code ${res.tenantCode})`);
        } else {
          this.domainHint.set('Not bound to any school yet — saving will bind it to this tenant.');
        }
        this.cdr.markForCheck();
      });
  }

  ngOnInit(): void {
    // Check if user is SuperAdmin or has SystemManage permission
    this.isSuperAdmin = this.permissionService.hasRole(UserRole.SuperAdmin) || 
                      this.permissionService.hasPermission(Permission.SystemManage);

    // Feed domain edits into the live binding-preview stream
    this.form.get('domain')?.valueChanges.subscribe(v => this.domainValueChanges$.next(v));

    this.refresh();
  }

  /** Hostname-only validator: no scheme, no path, no spaces. Normalized server-side. */
  private domainValidator() {
    return (control: AbstractControl): ValidationErrors | null => {
      const v = (control.value || '').trim();
      if (!v) return null; // optional field
      if (v.includes('://') || v.includes('/') || v.includes('?') || v.includes(' ') || v.includes(':')) {
        return { domain: 'Enter just the hostname, e.g. schoolname.edu (no https:// or paths)' };
      }
      if (v.length > 253 || !v.includes('.') || v.startsWith('.') || v.endsWith('.') ||
          !/^[a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+$/.test(v)) {
        return { domain: 'Not a valid hostname (e.g. schoolname.edu)' };
      }
      return null;
    };
  }

  refresh() {
    this.loading.set(true);
    this.error.set('');
    this.cdr.markForCheck();
    this.tenantService.getAllTenants().subscribe({
      next: res => {
        this.loading.set(false);
        const data = Array.isArray(res?.data) ? res.data : res;
        this.tenants.set(data || []);
        this.cdr.markForCheck();
      },
      error: err => {
        this.loading.set(false);
        this.error.set(err?.error?.message || 'Failed to load tenants');
        this.cdr.markForCheck();
      }
    });
  }

  onSubmit() {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }

    if (this.isEditMode() && this.editingTenantId) {
      this.updateTenant();
    } else {
      this.create();
    }
  }

  create() {
    const payload = this.form.value as any;
    this.loading.set(true);
    this.error.set('');
    this.cdr.markForCheck();
    this.tenantService.createTenant(payload).subscribe({
      next: res => {
        this.loading.set(false);
        this.resetForm();
        this.cdr.markForCheck();
        this.refresh();
      },
      error: err => {
        this.loading.set(false);
        this.error.set(err?.error?.message || 'Failed to create tenant');
        this.cdr.markForCheck();
      }
    });
  }

  edit(t: TenantDto) {
    this.isEditMode.set(true);
    this.editingTenantId = t.id;
    this.domainHint.set((t.domain || '') ? `Bound URL: https://${t.domain} → ${t.name}` : '');
    this.form.patchValue({
      name: t.name,
      domain: t.domain || '',
      logoUrl: (t as any).logoUrl || '',
      welcomeText: (t as any).welcomeText || '',
      isActive: t.isActive
    });
    // Scroll to form
    window.scrollTo({ top: 0, behavior: 'smooth' });
    this.cdr.markForCheck();
  }

  cancelEdit() {
    this.resetForm();
    this.cdr.markForCheck();
  }

  private updateTenant() {
    if (!this.editingTenantId) return;

    const payload = this.form.value as any;
    this.loading.set(true);
    this.error.set('');
    this.cdr.markForCheck();
    
    this.tenantService.updateTenant(this.editingTenantId, payload).subscribe({
      next: () => {
        this.loading.set(false);
        this.resetForm();
        this.cdr.markForCheck();
        this.refresh();
      },
      error: (err) => {
        this.loading.set(false);
        this.error.set(err?.error?.message || 'Failed to update tenant');
        this.cdr.markForCheck();
      }
    });
  }

  private resetForm() {
    this.isEditMode.set(false);
    this.editingTenantId = null;
    this.domainHint.set('');
    this.form.reset({ name: '', domain: '', logoUrl: '', welcomeText: '', isActive: true });
  }
}
