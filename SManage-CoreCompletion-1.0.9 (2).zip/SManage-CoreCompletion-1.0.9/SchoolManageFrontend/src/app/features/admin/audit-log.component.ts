import { Component, OnInit, OnDestroy, ViewChild, signal } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { AuditLogService, AuditLogFilters } from '../../services/audit-log.service';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatCardModule } from '@angular/material/card';
import { MatTableModule } from '@angular/material/table';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatChipsModule } from '@angular/material/chips';
import { CommonModule } from '@angular/common';
import { Subject } from 'rxjs';
import { debounceTime, takeUntil } from 'rxjs/operators';

interface AuditLogRow {
  id: number;
  userName: string;
  action: string;
  entity: string;
  entityId: string;
  timestamp: string;
  details: string;
  ipAddress: string;
}

@Component({
  selector: 'app-audit-log',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatProgressSpinnerModule,
    MatCardModule,
    MatTableModule,
    MatIconModule,
    MatButtonModule,
    MatTooltipModule,
    MatPaginatorModule,
    MatChipsModule
  ],
  templateUrl: './audit-log.component.html',
  styleUrls: ['./audit-log.component.scss']
})
export class AuditLogComponent implements OnInit, OnDestroy {
  @ViewChild(MatPaginator) paginator!: MatPaginator;

  // Zoneless app: all state mutated by async callbacks lives in signals,
  // so template bindings never change "after it was checked" (NG0100).
  readonly logs = signal<AuditLogRow[]>([]);
  readonly loading = signal(true);
  readonly totalRecords = signal(0);

  pageSize = 20;
  pageIndex = signal(0);
  readonly filterOptions = signal<AuditLogFilters>({ actions: [], entities: [], users: [] });

  filterForm: FormGroup;
  private searchSubject = new Subject<string>();
  private lastNonSearchSnapshot: { action: string; entity: string; user: string; range: any } | null = null;
  private destroy$ = new Subject<void>();

  displayedColumns: string[] = [
    'timestamp',
    'userName',
    'action',
    'entity',
    'entityId',
    'details',
    'ipAddress'
  ];

  // Plain getters: re-evaluated on every change-detection pass, which in a
  // zoneless app runs after each user event — exactly when these need updating.
  get hasActiveFilters(): boolean {
    const v = this.filterForm.value;
    return !!(v.search || v.action || v.entity || v.user || v.range?.start || v.range?.end);
  }

  get rangeGroup(): FormGroup {
    return this.filterForm.get('range') as FormGroup;
  }

  constructor(private auditLogService: AuditLogService, private fb: FormBuilder) {
    // The date range lives in a nested group bound via [formGroup] on
    // mat-date-range-input (mat-date-range-input itself is NOT a control-value
    // accessor; binding formControlName directly on it throws NG01203).
    this.filterForm = this.fb.group({
      search: [''],
      action: [''],
      entity: [''],
      user: [''],
      range: this.fb.group({ start: [null], end: [null] })
    });
  }

  ngOnInit(): void {
    // Debounced search: typing resets to page 1 and reloads
    this.searchSubject
      .pipe(debounceTime(400), takeUntil(this.destroy$))
      .subscribe(() => {
        this.pageIndex.set(0);
        if (this.paginator) this.paginator.pageIndex = 0;
        this.loadLogs();
      });

    this.filterForm.get('search')!.valueChanges
      .pipe(takeUntil(this.destroy$))
      .subscribe((v: string) => this.searchSubject.next(v));

    // Any dropdown/date change reloads immediately
    this.filterForm.valueChanges
      .pipe(takeUntil(this.destroy$))
      .subscribe((curr: any) => {
        // Reload only when a non-search value changed (search handled above)
        if (this.lastNonSearchSnapshot !== null &&
            curr.action === this.lastNonSearchSnapshot.action &&
            curr.entity === this.lastNonSearchSnapshot.entity &&
            curr.user === this.lastNonSearchSnapshot.user &&
            curr.range === this.lastNonSearchSnapshot.range) {
          return;
        }
        this.lastNonSearchSnapshot = { action: curr.action, entity: curr.entity, user: curr.user, range: curr.range };
        this.pageIndex.set(0);
        if (this.paginator) this.paginator.pageIndex = 0;
        this.loadLogs();
      });

    this.loadFilterOptions();
    this.loadLogs();
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  clearFilters(): void {
    this.filterForm.reset({ search: '', action: '', entity: '', user: '', range: { start: null, end: null } });
    this.pageIndex.set(0);
    if (this.paginator) this.paginator.pageIndex = 0;
    this.loadLogs();
  }

  onPageChange(e: { pageIndex: number; pageSize: number }): void {
    this.pageIndex.set(e.pageIndex);
    this.pageSize = e.pageSize;
    this.loadLogs();
  }

  refresh(): void {
    this.loadLogs();
    this.loadFilterOptions();
  }

  getActionClass(action: string): string {
    const a = (action || '').toLowerCase();
    if (a.includes('delete') || a.includes('remove')) return 'action-danger';
    if (a.includes('create') || a.includes('add')) return 'action-success';
    if (a.includes('update') || a.includes('edit')) return 'action-info';
    if (a.includes('login')) return 'action-login';
    return 'action-neutral';
  }

  private loadFilterOptions(): void {
    this.auditLogService.getFilterOptions().subscribe({
      next: res => { this.filterOptions.set(res?.data ?? { actions: [], entities: [], users: [] }); },
      error: () => { /* non-critical */ }
    });
  }

  private loadLogs(): void {
    this.loading.set(true);
    const v = this.filterForm.value;

    this.auditLogService.getLogs({
      page: this.pageIndex() + 1,
      pageSize: this.pageSize,
      search: v.search || undefined,
      action: v.action || undefined,
      entity: v.entity || undefined,
      user: v.user || undefined,
      from: v.range?.start ? this.toIso(v.range.start) : undefined,
      to: v.range?.end ? this.toIso(v.range.end) : undefined
    }).subscribe({
      next: res => {
        this.logs.set(res?.data ?? []);
        this.totalRecords.set(res?.pagination?.totalRecords ?? 0);
        this.loading.set(false);
      },
      error: () => {
        this.logs.set([]);
        this.totalRecords.set(0);
        this.loading.set(false);
      }
    });
  }

  private toIso(d: Date): string {
    const dt = new Date(d);
    dt.setMinutes(dt.getMinutes() - dt.getTimezoneOffset());
    return dt.toISOString().slice(0, 10);
  }
}
