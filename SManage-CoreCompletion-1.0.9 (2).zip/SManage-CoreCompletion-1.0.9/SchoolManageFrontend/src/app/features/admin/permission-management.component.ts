import { Component, OnInit, ChangeDetectorRef, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatTabsModule } from '@angular/material/tabs';
import { MatCardModule } from '@angular/material/card';
import { MatTableModule } from '@angular/material/table';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatSelectModule } from '@angular/material/select';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatChipsModule } from '@angular/material/chips';
import { MatDialogModule, MatDialog } from '@angular/material/dialog';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatTooltipModule } from '@angular/material/tooltip';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormGroup } from '@angular/forms';
import { catchError, map } from 'rxjs/operators';
import { of, firstValueFrom } from 'rxjs';
import { PermissionService, RoleSummary, MenuVisibilityDto, ModulePermissionSummaryDto } from '../../core/services/permission.service';
import { DynamicMenuService } from '../../services/dynamic-menu.service';
import { Permission, UserRole, RoleLabels, PermissionLabels, RolePermission } from '../../core/models/permission.model';
import { UserManagementService } from '../user-management/user-management.service';
import { User } from '../user-management/user.model';
import { ConfirmDialogComponent, ConfirmDialogData } from '../../shared/confirm-dialog.component';


@Component({
  selector: 'app-permission-management',
  standalone: true,
  imports: [
    CommonModule,
    MatTabsModule,
    MatCardModule,
    MatTableModule,
    MatButtonModule,
    MatIconModule,
    MatSelectModule,
    MatFormFieldModule,
    MatInputModule,
    MatSlideToggleModule,
    MatChipsModule,
    MatDialogModule,
    MatSnackBarModule,
    MatProgressSpinnerModule,
    MatTooltipModule,
    FormsModule,
  ReactiveFormsModule,
  ],
  templateUrl: './permission-management.component.html',
  styleUrls: ['./permission-management.component.scss']
})
export class PermissionManagementComponent implements OnInit {
  selectedRole: UserRole | null = null;
  selectedUser: User | null = null;
  userSearchTerm: string = '';
  permissionSearchTerm = '';
  // Zoneless app: async UI state lives in signals so template updates can never
  // race change detection (NG0100). Plain fields mutated inside HTTP callbacks
  // were triggering ExpressionChangedAfterItHasBeenChecked on this page.
  readonly isLoading = signal(false);
  readonly saveInProgress = signal(false);
  readonly menuVisibilityData = signal<MenuVisibilityDto[]>([]);
  readonly modulePermissionSummaries = signal<ModulePermissionSummaryDto[]>([]);
  readonly roleSummaryStats = signal({ totalPermissions: 0, visibleMenuItems: 0, totalMenuItems: 0 });
  readonly showMenuVisibilityDetail = signal(false);

  /**
   * Mobile (≤767px) accordion state — which modules are expanded.
   * Desktop tabs are unaffected; this only powers the phone layout.
   */
  readonly expandedModules = signal<Set<string>>(new Set());

  isExpanded(moduleName: string): boolean {
    return this.expandedModules().has(moduleName);
  }

  toggleModule(moduleName: string): void {
    const set = new Set(this.expandedModules());
    set.has(moduleName) ? set.delete(moduleName) : set.add(moduleName);
    this.expandedModules.set(set);
  }

  allExpanded(): boolean {
    const modules = this.permissionModules();
    return modules.length > 0 && this.expandedModules().size >= modules.length;
  }

  toggleAllModules(): void {
    this.expandedModules.set(this.allExpanded() ? new Set() : new Set(this.permissionModules().map(m => m.name)));
  }

  /** Modules with at least one granted permission — the “N Active” badge. */
  activeModulesCount(): number {
    if (this.selectedRole === null) return 0;
    return this.permissionModules().filter(m => this.getModuleReadCount(m.permissions) > 0).length;
  }
  readonly isDirty = signal(false);
  readonly filteredUsers = signal<User[]>([]);
  readonly userPermissionOverrides = signal<any[]>([]);
  readonly totalOverrides = computed(() => this.userPermissionOverrides().length);
  readonly moduleDirtyCounts: Map<string, number> = new Map();
  
  availableRoles: UserRole[] = Object.values(UserRole).filter(v => typeof v === 'number') as UserRole[];
  allPermissions: Permission[] = Object.values(Permission).filter(v => typeof v === 'number') as Permission[];
  
  rolePermissions: Map<UserRole, Map<Permission, any>> = new Map();
  newOverridePermission: Permission | null = null;
  newOverrideRead = false;
  newOverrideWrite = false;
  newOverrideDelete = false;

  permissionMatrixData: any[] = [];
  matrixDisplayedColumns: string[] = [];
  permissionModules = signal<any[]>([]);

  private originalRolePermissions: Map<UserRole, Map<Permission, any>> = new Map();

  constructor(
    private permissionService: PermissionService,
    private menuService: DynamicMenuService,
    private userManagementService: UserManagementService,
    private snackBar: MatSnackBar,
    private dialog: MatDialog,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    // Defer loading role permissions until a role is selected to avoid noisy API errors
    this.loadUsers();
    this.generatePermissionMatrix();
    
    // Explicitly trigger change detection to avoid NG0100 error with initial state
    this.cdr.detectChanges();
  }

  private initializePermissionModules(): void {
    this.permissionModules.set([
      {
        name: 'User Management',
        permissions: [Permission.UsersView, Permission.UsersCreate, Permission.UsersEdit, Permission.UsersDelete, Permission.UsersManageRoles]
      },
      {
        name: 'Student Management',
        permissions: [Permission.StudentsView, Permission.StudentsCreate, Permission.StudentsEdit, Permission.StudentsDelete, Permission.StudentsViewDetails, Permission.StudentsManageAdmissions]
      },
      {
        name: 'Staff Management',
        permissions: [Permission.StaffView, Permission.StaffCreate, Permission.StaffEdit, Permission.StaffDelete, Permission.StaffManagePayroll]
      },
      {
        name: 'Academic Management',
        permissions: [Permission.ClassesView, Permission.ClassesCreate, Permission.ClassesEdit, Permission.ClassesDelete, Permission.SubjectsView, Permission.SubjectsManage, Permission.TimetablesView, Permission.TimetablesManage]
      },
      {
        name: 'Examination Management',
        permissions: [Permission.ExaminationsView, Permission.ExaminationsCreate, Permission.ExaminationsEdit, Permission.ExaminationsDelete, Permission.ResultsView, Permission.ResultsEnter, Permission.ResultsPublish]
      },
      {
        name: 'Finance Management',
        permissions: [Permission.FeesView, Permission.FeesCollect, Permission.FeesManageStructure, Permission.FeesReports, Permission.PaymentsView, Permission.PaymentsProcess]
      },
      {
        name: 'Library Management',
        permissions: [Permission.LibraryView, Permission.LibraryIssueBooks, Permission.LibraryReturnBooks, Permission.LibraryManageInventory]
      },
      {
        name: 'Transport Management',
        permissions: [Permission.TransportView, Permission.TransportManageRoutes, Permission.TransportManageVehicles, Permission.TransportTrackAttendance]
      },
      {
        name: 'Hostel Management',
        permissions: [Permission.HostelView, Permission.HostelManageRooms, Permission.HostelManageAllocations, Permission.HostelManageLeaves]
      },
      {
        name: 'Communication',
        permissions: [Permission.MessagesView, Permission.MessagesSend, Permission.AnnouncementsSend, Permission.EventsManage]
      },
      {
        name: 'Reports & Analytics',
        permissions: [Permission.ReportsView, Permission.ReportsGenerate, Permission.AnalyticsView, Permission.DashboardView]
      },
      {
        name: 'System Administration',
        permissions: [Permission.SystemSettings, Permission.SystemBackupRestore, Permission.SystemAuditLogs, Permission.SystemManage]
      }
    ]);
  }

  private loadRolePermissions(role: UserRole): void {
    // Schedule load after the current change detection cycle.
    setTimeout(() => {
      this.isLoading.set(true);

      // Use the unified role-summary endpoint (single API call for permissions + menu visibility)
      this.permissionService.getRoleSummary(role)
      .pipe(
        catchError(err => {
          console.error(`Failed to load role summary for role ${role}:`, err);
          // Fallback to legacy endpoint if role-summary is unavailable
          return this.permissionService.getRolePermissions(role).pipe(
            map((permissions: any[]) => ({
              role: role,
              roleName: RoleLabels[role] || role.toString(),
              rolePermissions: permissions.map((p: any) => ({
                permission: this.permissionService.normalizePermissionKey(p.permission) ?? p.permission,
                permissionName: p.permission,
                canRead: !!p.canRead,
                canWrite: !!p.canWrite,
                canDelete: !!p.canDelete
              })),
              menuVisibility: [],
              modulePermissions: [],
              totalPermissions: permissions.length,
              visibleMenuItems: 0,
              totalMenuItems: 0
            } as RoleSummary))
          );
        })
      )
      .subscribe((summary: RoleSummary) => {
        const permissionMap = new Map();
        summary.rolePermissions.forEach(p => {
          const permKey = this.permissionService.normalizePermissionKey(p.permission);
          if (permKey !== null) {
            permissionMap.set(permKey, { canRead: !!p.canRead, canWrite: !!p.canWrite, canDelete: !!p.canDelete });
          }
        });
        this.rolePermissions.set(role, permissionMap);

        // Store unified summary data for menu visibility indicators
        this.menuVisibilityData.set(summary.menuVisibility || []);
        this.modulePermissionSummaries.set(summary.modulePermissions || []);
        this.roleSummaryStats.set({
          totalPermissions: summary.totalPermissions || 0,
          visibleMenuItems: summary.visibleMenuItems || 0,
          totalMenuItems: summary.totalMenuItems || 0
        });

        // Build permissionModules from backend modulePermissionSummaries (data-driven, no hardcoding)
        if (this.modulePermissionSummaries().length > 0) {
          this.permissionModules.set(this.modulePermissionSummaries().map((mpm: any) => ({
            name: mpm.moduleName,
            permissions: mpm.permissions.map((p: any) => {
              const key = this.permissionService.normalizePermissionKey(p.permission);
              return key !== null ? key : p.permission;
            }).filter((p: any): p is Permission => p !== null)
          })));
        } else {
          // Fallback: use hardcoded modules if role-summary endpoint returned empty
          this.initializePermissionModules();
        }

        // Defer change-heavy UI updates to next tick
        setTimeout(() => {
          this.originalRolePermissions.set(role, new Map(Array.from(permissionMap.entries()).map(([k,v]) => [k, { ...v }])));
          this.isDirty.set(false);
          this.updateModuleDirtyCounts();
          this.generatePermissionMatrix();
          this.isLoading.set(false);
        }, 0);
      });
    }, 0);
  }

  private updateModuleDirtyCounts(): void {
    this.moduleDirtyCounts.clear();
    if (this.selectedRole === null) return;
    const baseline = this.originalRolePermissions.get(this.selectedRole);
    const current = this.rolePermissions.get(this.selectedRole);
    if (!baseline || !current) return;

    for (const module of this.permissionModules()) {
      let count = 0;
      for (const perm of module.permissions) {
        const a = baseline.get(perm);
        const b = current.get(perm);
        if (!a && b) { count++; continue; }
        if (!b && a) { count++; continue; }
        if (a && b && (a.canRead !== b.canRead || a.canWrite !== b.canWrite || a.canDelete !== b.canDelete)) {
          count++;
        }
      }
      if (count > 0) this.moduleDirtyCounts.set(module.name, count);
    }
  }

  private markDirty(role: UserRole): void {
    const current = this.rolePermissions.get(role);
    const baseline = this.originalRolePermissions.get(role);
    if (!current || !baseline) { this.isDirty.set(false); return; }
    if (current.size !== baseline.size) { this.isDirty.set(true); this.updateModuleDirtyCounts(); return; }
    for (const [perm, val] of current.entries()) {
      const b = baseline.get(perm);
      if (!b || b.canRead !== val.canRead || b.canWrite !== val.canWrite || b.canDelete !== val.canDelete) {
        this.isDirty.set(true);
        this.updateModuleDirtyCounts();
        return;
      }
    }
    this.isDirty.set(false);
    this.updateModuleDirtyCounts();
  }

  applyPreset(preset: 'view' | 'editor' | 'manager' | 'full'): void {
    if (this.selectedRole === null) return;
    const map = this.rolePermissions.get(this.selectedRole) || new Map();
    const setPerm = (perm: Permission, r: boolean, w: boolean, d: boolean) => {
      const v = map.get(perm) || { canRead: false, canWrite: false, canDelete: false };
      v.canRead = r; v.canWrite = w; v.canDelete = d;
      map.set(perm, v);
    };
    const all = this.allPermissions as Permission[];
    all.forEach(p => {
      switch (preset) {
        case 'view': setPerm(p, true, false, false); break;
        case 'editor': setPerm(p, true, true, false); break;
        case 'manager': setPerm(p, true, true, true); break;
        case 'full': setPerm(p, true, true, true); break;
      }
    });
    this.rolePermissions.set(this.selectedRole, map);
    this.generatePermissionMatrix();
    this.markDirty(this.selectedRole);
  }

  filterMatches(permission: Permission): boolean {
    const t = (this.permissionSearchTerm || '').trim().toLowerCase();
    if (!t) return true;
    const label = this.getPermissionLabel(permission).toLowerCase();
    return label.includes(t);
  }

  async saveRolePermissions(): Promise<void> {
    if (this.selectedRole !== null) {
      const rolePermissionMap = this.rolePermissions.get(this.selectedRole);
      if (rolePermissionMap) {
        this.saveInProgress.set(true);
        
        const permissionsToUpdate: any[] = [];
        rolePermissionMap.forEach((permissionData, permission) => {
          permissionsToUpdate.push({
            permission,
            canRead: !!permissionData.canRead,
            canWrite: !!permissionData.canWrite,
            canDelete: !!permissionData.canDelete
          });
        });

        if (permissionsToUpdate.length === 0) {
          this.saveInProgress.set(false);
          return;
        }

        this.permissionService.bulkUpdateRolePermissions(this.selectedRole, permissionsToUpdate).subscribe({
          next: () => {
            this.saveInProgress.set(false);
            this.snackBar.open('Role permissions updated successfully', 'Close', { duration: 3000 });
            
            // Update baseline to current
            const map = this.rolePermissions.get(this.selectedRole!);
            if (map) {
              this.originalRolePermissions.set(this.selectedRole!, new Map(Array.from(map.entries()).map(([k,v]) => [k, { ...v }])));
            }
            this.isDirty.set(false);
            this.updateModuleDirtyCounts();
            
            // Refresh local permissions for current user
            this.permissionService.refreshPermissions().subscribe();
            // Invalidate menu cache so sidebar reflects new permissions immediately
            this.menuService.invalidateAndReload().subscribe();
          },
          error: (err) => {
            this.saveInProgress.set(false);
            console.error('Error saving role permissions', err);
            this.snackBar.open('Failed to update role permissions. Please try again.', 'Close', { duration: 5000 });
          }
        });
      }
    }
  }

  confirmResetModule(permissions: Permission[]): void {
    const ref = this.dialog.open(ConfirmDialogComponent, {
      data: {
        title: 'Reset module? ',
        message: 'This will reset permissions in this module to defaults for this role.',
        confirmText: 'Reset',
        cancelText: 'Cancel',
        icon: 'settings_backup_restore'
      } as ConfirmDialogData
    });
    ref.afterClosed().subscribe(ok => { if (ok) this.resetModuleToDefault(permissions); });
  }

  confirmResetRole(): void {
    const ref = this.dialog.open(ConfirmDialogComponent, {
      data: {
        title: 'Reset all permissions? ',
        message: 'This will reset all permissions for this role to defaults.',
        confirmText: 'Reset',
        cancelText: 'Cancel',
        icon: 'settings_backup_restore'
      } as ConfirmDialogData
    });
    ref.afterClosed().subscribe(ok => { if (ok) this.resetRolePermissions(); });
  }

  // ===== Existing logic preserved and enhanced =====
  private loadUsers(): void {
    this.userManagementService.getAllUsers().subscribe({
      next: (users) => {
        this.filteredUsers.set(users);
      },
      error: (error) => {
        console.error('Error loading users:', error);
        this.snackBar.open('Failed to load users', 'Close', { duration: 3000 });
      }
    });
  }

  private generatePermissionMatrix(): void {
    this.matrixDisplayedColumns = ['permission', ...this.availableRoles.map(r => this.getRoleColumnId(r))];
    this.permissionMatrixData = this.allPermissions.map(permission => {
      const roles: any = {};
      this.availableRoles.forEach(role => {
        const rolePermissionMap = this.rolePermissions.get(role);
        const permissionData = rolePermissionMap?.get(permission);
        roles[role] = {
          canRead: permissionData?.canRead || false,
          canWrite: permissionData?.canWrite || false,
          canDelete: permissionData?.canDelete || false
        };
      });
      return { permission, roles };
    });
  }

  onRoleChange(): void {
    if (this.selectedRole !== null) {
      this.loadRolePermissions(this.selectedRole);
    }
  }

  onUserSearch(): void {
    const term = (this.userSearchTerm || '').trim().toLowerCase();
    if (!term) {
      this.loadUsers();
      return;
    }
    this.userManagementService.getAllUsers().subscribe({
      next: (users) => {
        this.filteredUsers.set(users.filter(user => {
          const u = (user.username || '').toLowerCase();
          const e = (user.email || '').toLowerCase();
          return u.includes(term) || e.includes(term);
        }));
      },
      error: (error) => {
        console.error('Error searching users:', error);
      }
    });
  }

  selectUser(user: any): void {
    this.selectedUser = user;
    this.loadUserPermissionOverrides();
  }

  private loadUserPermissionOverrides(): void {
    if (this.selectedUser) {
      this.permissionService.getUserPermissionOverrides(String(this.selectedUser.id)).subscribe({
        next: (overrides) => {
          this.userPermissionOverrides.set((overrides || []).map(o => ({
            ...o,
            permission: this.permissionService.normalizePermissionKey(o.permission)
          })));
        },
        error: (err) => {
          console.error('Failed to load user permission overrides', err);
          this.userPermissionOverrides.set([]);
        }
      });
    }
  }

  hasRolePermission(role: UserRole, permission: Permission, type: 'read' | 'write' | 'delete'): boolean {
    const rolePermissionMap = this.rolePermissions.get(role);
    const permissionData = rolePermissionMap?.get(permission);
    switch (type) {
      case 'read': return permissionData?.canRead || false;
      case 'write': return permissionData?.canWrite || false;
      case 'delete': return permissionData?.canDelete || false;
      default: return false;
    }
  }

  updateRolePermission(role: UserRole, permission: Permission, type: 'read' | 'write' | 'delete', enabled: boolean): void {
    const rolePermissionMap = this.rolePermissions.get(role) || new Map();
    const current = rolePermissionMap.get(permission) || { canRead: false, canWrite: false, canDelete: false };
    switch (type) {
      case 'read': current.canRead = enabled; break;
      case 'write': current.canWrite = enabled; break;
      case 'delete': current.canDelete = enabled; break;
    }
    rolePermissionMap.set(permission, current);
    this.rolePermissions.set(role, rolePermissionMap);
    this.markDirty(role);
    this.generatePermissionMatrix();
  }

  setModuleAccess(permissions: Permission[], type: 'read' | 'write' | 'delete' | 'all', enabled: boolean): void {
    if (this.selectedRole === null) return;
    permissions.forEach(p => {
      if (type === 'all') {
        this.updateRolePermission(this.selectedRole!, p, 'read', enabled);
        this.updateRolePermission(this.selectedRole!, p, 'write', enabled);
        this.updateRolePermission(this.selectedRole!, p, 'delete', enabled);
      } else {
        this.updateRolePermission(this.selectedRole!, p, type as any, enabled);
      }
    });
    this.generatePermissionMatrix();
    this.markDirty(this.selectedRole!);
  }

  resetModuleToDefault(permissions: Permission[]): void {
    if (this.selectedRole === null) return;
    this.permissionService.resetRoleModule(this.selectedRole, permissions).subscribe({
      next: () => {
        this.snackBar.open('Module reset to default', 'Close', { duration: 2500 });
        this.loadRolePermissions(this.selectedRole!);
      },
      error: () => this.snackBar.open('Failed to reset module', 'Close', { duration: 3000 })
    });
  }

  resetRolePermissions(): void {
    if (this.selectedRole !== null) {
      this.loadRolePermissions(this.selectedRole);
      this.snackBar.open('Role permissions reset to default', 'Close', { duration: 3000 });
    }
  }

  grantUserPermission(): void {
    if (this.selectedUser && this.newOverridePermission !== null) {
      this.permissionService.grantUserPermission(
        Number(this.selectedUser.id),
        this.newOverridePermission,
        this.newOverrideRead,
        this.newOverrideWrite,
        this.newOverrideDelete
      ).subscribe({
        next: () => {
          this.snackBar.open('User permission granted successfully', 'Close', { duration: 3000 });
          this.loadUserPermissionOverrides();
          this.resetOverrideForm();
        },
        error: () => {
          this.snackBar.open('Failed to grant user permission', 'Close', { duration: 3000 });
        }
      });
    }
  }

  revokeUserPermission(permission: Permission): void {
    if (this.selectedUser) {
      this.permissionService.revokeUserPermission(Number(this.selectedUser.id), permission).subscribe({
        next: () => {
          this.snackBar.open('User permission revoked successfully', 'Close', { duration: 3000 });
          this.loadUserPermissionOverrides();
        },
        error: () => {
          this.snackBar.open('Failed to revoke user permission', 'Close', { duration: 3000 });
        }
      });
    }
  }

  private resetOverrideForm(): void {
    this.newOverridePermission = null;
    this.newOverrideRead = false;
    this.newOverrideWrite = false;
    this.newOverrideDelete = false;
  }

  getRoleLabel(role: UserRole): string {
    return RoleLabels[role] || role.toString();
  }

  getPermissionLabel(permission: Permission): string {
    return PermissionLabels[permission] || permission.toString();
  }

  getPermissionDescription(permission: Permission): string {
    return 'Permission description';
  }

  getRoleColumnId(role: UserRole): string {
    return `role_${role}`;
  }

  getModuleIcon(moduleName: string): string {
    const iconMap: { [key: string]: string } = {
      'User Management': 'supervisor_account',
      'Student Management': 'school',
      'Staff Management': 'group',
      'Academic Management': 'auto_stories',
      'Examination Management': 'quiz',
      'Finance Management': 'account_balance',
      'Library Management': 'local_library',
      'Communication': 'forum',
      'Reports & Analytics': 'analytics',
      'System Administration': 'admin_panel_settings'
    };
    return iconMap[moduleName] || 'settings';
  }

  getUserRole(roles: unknown): UserRole {
    const roleMapping: { [key: string]: UserRole } = {
      'SuperAdmin': UserRole.SuperAdmin,
      'Administrator': UserRole.Administrator,
      'Principal': UserRole.Principal,
      'Teacher': UserRole.Teacher,
      'Student': UserRole.Student,
      'Parent': UserRole.Parent,
      'Staff': UserRole.Staff,
      'Librarian': UserRole.Librarian,
      'Accountant': UserRole.Accountant,
      'Receptionist': UserRole.Receptionist
    };
    try {
      if (roles == null) return UserRole.Student;
      if (typeof roles === 'number') return (roles as UserRole) || UserRole.Student;
      if (Array.isArray(roles) && roles.length > 0) {
        const first = String(roles[0]).trim();
        if (!isNaN(Number(first))) return (Number(first) as UserRole) || UserRole.Student;
        return roleMapping[first] || UserRole.Student;
      }
      const str = String(roles);
      const firstRole = str.split(',')[0].trim();
      if (!isNaN(Number(firstRole))) return (Number(firstRole) as UserRole) || UserRole.Student;
      if (firstRole in roleMapping) return roleMapping[firstRole];
      if ((UserRole as any)[firstRole] !== undefined) return (UserRole as any)[firstRole] as UserRole;
      return UserRole.Student;
    } catch {
      return UserRole.Student;
    }
  }

  // ===== Menu Visibility Indicators =====

  /**
   * Determines if a module's menu will be visible in the sidebar.
   * A module is visible if ANY of its permissions has CanRead=true.
   * Menu visibility is auto-derived from the Read toggle.
   */
  isModuleMenuVisible(modulePermissions: Permission[]): boolean {
    if (this.selectedRole === null) return false;
    // SuperAdmin always sees all menus
    if (this.selectedRole === UserRole.SuperAdmin) return true;
    const rolePermissionMap = this.rolePermissions.get(this.selectedRole);
    if (!rolePermissionMap) return false;
    // Menu is visible if at least ONE permission in the module has CanRead=true
    return modulePermissions.some(p => {
      const data = rolePermissionMap.get(p);
      return data?.canRead === true;
    });
  }

  /**
   * Generic helper: counts permissions in a module that have a given type=true.
   */
  private getModulePermissionCount(modulePermissions: Permission[], type: 'canRead' | 'canWrite' | 'canDelete'): number {
    if (this.selectedRole === null) return 0;
    const rolePermissionMap = this.rolePermissions.get(this.selectedRole);
    if (!rolePermissionMap) return 0;
    return modulePermissions.filter(p => rolePermissionMap.get(p)?.[type] === true).length;
  }

  getModuleReadCount(modulePermissions: Permission[]): number {
    return this.getModulePermissionCount(modulePermissions, 'canRead');
  }

  getModuleWriteCount(modulePermissions: Permission[]): number {
    return this.getModulePermissionCount(modulePermissions, 'canWrite');
  }

  getModuleDeleteCount(modulePermissions: Permission[]): number {
    return this.getModulePermissionCount(modulePermissions, 'canDelete');
  }

  // ===== Menu Visibility Detail Panel =====

  toggleMenuVisibilityDetail(): void {
    this.showMenuVisibilityDetail.update(v => !v);
  }

  /**
   * Returns only the visible menu items from the backend role-summary response.
   */
  getVisibleMenuItems(): MenuVisibilityDto[] {
    return this.menuVisibilityData().filter(m => m.isVisible);
  }

  /**
   * Returns only the hidden menu items from the backend role-summary response.
   */
  getHiddenMenuItems(): MenuVisibilityDto[] {
    return this.menuVisibilityData().filter(m => !m.isVisible);
  }

  /**
   * Returns menu items that have an explicit override (not auto-derived from permissions).
   */
  getOverriddenMenuItems(): MenuVisibilityDto[] {
    return this.menuVisibilityData().filter(m => m.hasExplicitOverride);
  }

  /**
   * Returns true if the menuVisibilityData has been populated (i.e., role-summary was used).
   */
  hasMenuVisibilityData(): boolean {
    return this.menuVisibilityData().length > 0;
  }

  canShowApiTest(): boolean {
    const role = this.permissionService.getCurrentRole();
    return role === UserRole.SuperAdmin || role === UserRole.Administrator;
  }

  pingApi(): void {
    const start = performance.now();
    this.permissionService.ping().subscribe({
      next: () => {
        const ms = Math.round(performance.now() - start);
        this.snackBar.open(`API POST test: OK (${ms} ms)`, 'Close', { duration: 3000 });
      },
      error: (err) => {
        const ms = Math.round(performance.now() - start);
        console.error('Ping failed', err);
        this.snackBar.open(`API POST test failed (${ms} ms)`, 'Close', { duration: 4000 });
      }
    });
  }
}