export interface DashboardFeeSummary {
  totalFee: number;
  paidAmount: number;
  outstandingAmount: number;
  collectionPercent: number;
  discountAmount: number;
  lateFeeAmount: number;
  refundAmount: number;
}

export interface InstallmentDisplay {
  name: string;
  amount: number;
  paidAmount: number;
  dueDate: string;
  status: string;
  daysOverdue: number;
  lateFee: number;
  discount: number;
  installmentId: number;
}

export interface PaymentDisplay {
  date: string;
  amount: number;
  method: string;
  status: string;
  receipt: string;
  description?: string;
}

export interface StudentInfoDisplay {
  id: number;
  name: string;
  admissionNumber: string;
  rollNumber: string;
  className: string;
  sectionName: string;
  academicYear: string;
  status: string;
  parentName: string;
  contactNumber: string;
  email: string;
  address: string;
  gender: string;
}

export interface RefundDisplay {
  id: number;
  amount: number;
  date: string;
  reason: string;
  status: string;
  referenceNumber?: string;
}

export interface StudentSearchResult {
  id: number;
  firstName: string;
  lastName: string;
  rollNumber?: string;
  scholarNumber?: string;
  className?: string;
  sectionName?: string;
}
