import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatTableModule } from '@angular/material/table';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatChipsModule } from '@angular/material/chips';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatDialogModule, MatDialog } from '@angular/material/dialog';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatDividerModule } from '@angular/material/divider';
import { MatExpansionModule } from '@angular/material/expansion';

import { FeeManagementService } from '../../shared/services/fee-management.service';
import { FeePageHeaderComponent } from '../../shared/components/fees-module/fee-page-header.component';
import { FeeStatusBadgeComponent } from '../../shared/components/fees-module/fee-status-badge.component';
import { FeeStateComponent } from '../../shared/components/fees-module/fee-state.component';

export interface FeeRule {
  id: number;
  name: string;
  description: string;
  ruleType: number;
  ruleTypeName?: string;
  condition: number;
  conditionValue: number;
  actionValue: number;
  isPercentage: boolean;
  priority: number;
  isActive: boolean;
  CreatedOn: string;
}

const RULE_TYPES = [
  { value: 1, label: 'Late Fee',              icon: 'schedule'           },
  { value: 2, label: 'Sibling Discount',      icon: 'people'             },
  { value: 3, label: 'Scholarship Discount',  icon: 'school'             },
  { value: 4, label: 'Early Payment Discount',icon: 'trending_down'      },
  { value: 5, label: 'Waiver Discount',       icon: 'volunteer_activism' },
  { value: 6, label: 'Overdue Fine',          icon: 'gavel'              }
];

const CONDITIONS = [
  { value: 0, label: 'Always (no condition)' },
  { value: 1, label: 'Days Overdue ≥' },
  { value: 2, label: 'Sibling Count ≥' },
  { value: 3, label: 'Score Above (%)' },
  { value: 4, label: 'Days Before Due ≥' }
];

@Component({
  selector: 'app-fee-rules',
  standalone: true,
  imports: [
    CommonModule, ReactiveFormsModule,
    MatCardModule, MatTableModule, MatProgressBarModule, MatIconModule,
    MatButtonModule, MatChipsModule, MatFormFieldModule, MatInputModule,
    MatSelectModule, MatTooltipModule, MatSnackBarModule, MatDialogModule,
    MatSlideToggleModule, MatDividerModule, MatExpansionModule,
    FeePageHeaderComponent, FeeStatusBadgeComponent, FeeStateComponent
  ],
  template: `
    <div class="rules-page compact-screen">
      <app-fee-page-header
        title="Fee Rules Engine"
        subtitle="Configure automatic late fees, discounts, and fines">
        <ng-container headerActions>
          <button mat-flat-button color="primary" (click)="showForm.set(true)">
            <mat-icon>add</mat-icon>
            New Rule
          </button>
        </ng-container>
      </app-fee-page-header>

      <div class="rules-body">
        <!-- New Rule Form -->
        <mat-expansion-panel [expanded]="showForm()" (expandedChange)="showForm.set($event)" class="rule-form-panel">
          <mat-expansion-panel-header>
            <mat-panel-title>
              <mat-icon>{{ editingRule ? 'edit' : 'add' }}</mat-icon>
              {{ editingRule ? 'Edit Rule' : 'Create New Rule' }}
            </mat-panel-title>
          </mat-expansion-panel-header>

          <form [formGroup]="ruleForm" (ngSubmit)="saveRule()" class="rule-form">
            <div class="form-row">
              <mat-form-field appearance="outline" class="field-grow">
                <mat-label>Rule Name *</mat-label>
                <input matInput formControlName="name">
              </mat-form-field>

              <mat-form-field appearance="outline">
                <mat-label>Rule Type *</mat-label>
                <mat-select formControlName="ruleType">
                  <mat-option *ngFor="let rt of ruleTypes" [value]="rt.value">
                    <mat-icon>{{ rt.icon }}</mat-icon> {{ rt.label }}
                  </mat-option>
                </mat-select>
              </mat-form-field>

              <mat-form-field appearance="outline">
                <mat-label>Priority (lower = first)</mat-label>
                <input matInput type="number" formControlName="priority" min="1">
              </mat-form-field>
            </div>

            <div class="form-row">
              <mat-form-field appearance="outline">
                <mat-label>Condition</mat-label>
                <mat-select formControlName="condition">
                  <mat-option *ngFor="let c of conditions" [value]="c.value">{{ c.label }}</mat-option>
                </mat-select>
              </mat-form-field>

              <mat-form-field appearance="outline" *ngIf="ruleForm.get('condition')?.value !== 0">
                <mat-label>Condition Value</mat-label>
                <input matInput type="number" formControlName="conditionValue" min="0">
                <mat-hint>e.g. "7" for ≥7 days overdue</mat-hint>
              </mat-form-field>

              <mat-form-field appearance="outline">
                <mat-label>Action Value *</mat-label>
                <input matInput type="number" formControlName="actionValue" min="0.01">
              </mat-form-field>

              <div class="toggle-field">
                <label class="toggle-label">Value Type</label>
                <mat-slide-toggle formControlName="isPercentage">
                  {{ ruleForm.get('isPercentage')?.value ? 'Percentage (%)' : 'Flat Amount (₹)' }}
                </mat-slide-toggle>
              </div>
            </div>

            <mat-form-field appearance="outline" class="full-width">
              <mat-label>Description</mat-label>
              <textarea matInput formControlName="description" rows="2"></textarea>
            </mat-form-field>

            <div class="form-actions">
              <button mat-raised-button color="primary" type="submit" [disabled]="ruleForm.invalid || saving()">
                <mat-icon>{{ editingRule ? 'update' : 'add' }}</mat-icon>
                {{ saving() ? 'Saving...' : (editingRule ? 'Update Rule' : 'Create Rule') }}
              </button>
              <button mat-button type="button" (click)="cancelEdit()">Cancel</button>
            </div>
          </form>
        </mat-expansion-panel>

        <mat-divider class="list-divider"></mat-divider>

        <mat-progress-bar *ngIf="loading()" mode="indeterminate" class="fee-loading-bar"></mat-progress-bar>

        @if (!loading() && rules().length === 0) {
          <app-fee-state
            kind="empty"
            emptyIcon="rule"
            title="No Fee Rules"
            message="No fee rules configured. Create one to automate late fees and discounts.">
          </app-fee-state>
        }

        <!-- Rules Table -->
        @if (!loading() && rules().length > 0) {
        <div class="fee-table-card">
          <div class="fee-table-scroll">
          <table mat-table [dataSource]="rules()" class="rules-table">

            <ng-container matColumnDef="priority">
              <th mat-header-cell *matHeaderCellDef class="center-col">#</th>
              <td mat-cell *matCellDef="let r" class="center-col priority-col">{{ r.priority }}</td>
            </ng-container>

            <ng-container matColumnDef="name">
              <th mat-header-cell *matHeaderCellDef>Rule</th>
              <td mat-cell *matCellDef="let r">
                <div class="rule-name">{{ r.name }}</div>
                <div class="rule-desc">{{ r.description }}</div>
              </td>
            </ng-container>

            <ng-container matColumnDef="type">
              <th mat-header-cell *matHeaderCellDef>Type</th>
              <td mat-cell *matCellDef="let r">
                <span class="fee-badge" [class.fee-badge-info]="!isDiscountRule(r)" [class.fee-badge-discounted]="isDiscountRule(r)">
                  <mat-icon>{{ getRuleTypeIcon(r.ruleType) }}</mat-icon>
                  {{ getRuleTypeName(r.ruleType) }}
                </span>
              </td>
            </ng-container>

            <ng-container matColumnDef="condition">
              <th mat-header-cell *matHeaderCellDef>When</th>
              <td mat-cell *matCellDef="let r">
                <span *ngIf="r.condition === 0">Always</span>
                <span *ngIf="r.condition !== 0">{{ getConditionName(r.condition) }} {{ r.conditionValue }}</span>
              </td>
            </ng-container>

            <ng-container matColumnDef="action">
              <th mat-header-cell *matHeaderCellDef class="amount-col">Apply</th>
              <td mat-cell *matCellDef="let r" class="amount-col">
                <strong>{{ r.isPercentage ? r.actionValue + '%' : '₹' + r.actionValue }}</strong>
                <span class="action-label">{{ isDiscountRule(r) ? 'discount' : 'charge' }}</span>
              </td>
            </ng-container>

            <ng-container matColumnDef="status">
              <th mat-header-cell *matHeaderCellDef class="center-col">Status</th>
              <td mat-cell *matCellDef="let r" class="center-col">
                <app-fee-status-badge [status]="r.isActive ? 'active' : 'inactive'"></app-fee-status-badge>
              </td>
            </ng-container>

            <ng-container matColumnDef="actions">
              <th mat-header-cell *matHeaderCellDef class="center-col">Actions</th>
              <td mat-cell *matCellDef="let r" class="center-col">
                <button mat-icon-button color="primary" [matTooltip]="'Edit rule'" (click)="editRule(r)">
                  <mat-icon>edit</mat-icon>
                </button>
                <button mat-icon-button color="warn" [matTooltip]="'Deactivate rule'" (click)="deactivateRule(r)"
                        [disabled]="!r.isActive">
                  <mat-icon>block</mat-icon>
                </button>
              </td>
            </ng-container>

            <tr mat-header-row *matHeaderRowDef="displayedColumns"></tr>
            <tr mat-row *matRowDef="let row; columns: displayedColumns;" class="rule-row"
                [class.inactive-row]="!row.isActive"></tr>
          </table>
          </div>
        </div>
        }
      </div>
    </div>
  `,
  styles: [`
    .rules-page { padding: var(--space-sm) var(--space-sm) calc(var(--bottom-nav-height) + var(--space-lg)); }
    @media (min-width: 768px) { .rules-page { padding: var(--space-md) var(--space-lg) var(--space-lg); } }
    .rule-form-panel { margin-bottom: 16px; }
    .rule-form { display: flex; flex-direction: column; gap: 12px; padding-top: 12px; }
    .form-row { display: flex; gap: 12px; flex-wrap: wrap; align-items: flex-start; }
    .field-grow { flex: 1; min-width: 200px; }
    .full-width { width: 100%; }
    .toggle-field { display: flex; flex-direction: column; gap: 8px; justify-content: center; padding: 8px 0; }
    .toggle-label { font-size: 12px; color: var(--color-text-secondary); }
    .form-actions { display: flex; gap: 12px; }
    .list-divider { margin: 16px 0; }
    .rules-table { width: 100%; }
    .center-col { text-align: center !important; }
    .amount-col { text-align: right !important; }
    .priority-col { font-weight: bold; font-size: 16px; color: var(--md-primary); }
    .rule-name { font-weight: 500; }
    .rule-desc { font-size: 12px; color: var(--color-text-secondary); }
    .action-label { font-size: 11px; color: var(--color-text-secondary); margin-left: 4px; }
    .inactive-row { opacity: 0.5; }
  `]
})
export class FeeRulesComponent implements OnInit {
  rules = signal<any[]>([]);
  loading = signal(false);
  saving = signal(false);
  showForm = signal(false);
  editingRule: FeeRule | null = null;

  displayedColumns = ['priority', 'name', 'type', 'condition', 'action', 'status', 'actions'];

  ruleTypes = RULE_TYPES;
  conditions = CONDITIONS;

  ruleForm: FormGroup;

  constructor(
    private feeService: FeeManagementService,
    private fb: FormBuilder,
    private snackBar: MatSnackBar
  ) {
    this.ruleForm = this.fb.group({
      name: ['', Validators.required],
      description: [''],
      ruleType: [1, Validators.required],
      condition: [0],
      conditionValue: [0],
      actionValue: [null, [Validators.required, Validators.min(0.01)]],
      isPercentage: [false],
      priority: [1, [Validators.required, Validators.min(1)]]
    });
  }

  ngOnInit(): void {
    this.loadRules();
  }

  loadRules(): void {
    this.loading.set(true);
    this.feeService.getFeeRules().subscribe({
      next: (res) => {
        this.rules.set((res.data || res) as FeeRule[]);
        this.loading.set(false);
      },
      error: () => {
        this.snackBar.open('Failed to load fee rules', 'Close', { duration: 3000 });
        this.loading.set(false);
      }
    });
  }

  editRule(rule: FeeRule): void {
    this.editingRule = rule;
    this.ruleForm.patchValue(rule);
    this.showForm.set(true);
  }

  cancelEdit(): void {
    this.editingRule = null;
    this.ruleForm.reset({ ruleType: 1, condition: 0, priority: 1, isPercentage: false, conditionValue: 0 });
    this.showForm.set(false);
  }

  saveRule(): void {
    if (this.ruleForm.invalid) return;
    this.saving.set(true);

    const payload = this.ruleForm.value;
    const obs = this.editingRule
      ? this.feeService.updateFeeRule(this.editingRule.id, payload)
      : this.feeService.createFeeRule(payload);

    obs.subscribe({
      next: () => {
        this.snackBar.open(this.editingRule ? 'Rule updated' : 'Rule created', 'Close', { duration: 3000 });
        this.cancelEdit();
        this.saving.set(false);
        this.loadRules();
      },
      error: () => {
        this.snackBar.open('Failed to save rule', 'Close', { duration: 3000 });
        this.saving.set(false);
      }
    });
  }

  deactivateRule(rule: FeeRule): void {
    this.feeService.deleteFeeRule(rule.id).subscribe({
      next: () => {
        this.snackBar.open('Rule deactivated', 'Close', { duration: 3000 });
        this.loadRules();
      },
      error: () => this.snackBar.open('Failed to deactivate rule', 'Close', { duration: 3000 })
    });
  }

  getRuleTypeName(type: number): string {
    return RULE_TYPES.find(r => r.value === type)?.label ?? 'Unknown';
  }

  getRuleTypeIcon(type: number): string {
    return RULE_TYPES.find(r => r.value === type)?.icon ?? 'rule';
  }

  getConditionName(condition: number): string {
    return CONDITIONS.find(c => c.value === condition)?.label ?? '';
  }

  isDiscountRule(rule: FeeRule): boolean {
    return [2, 3, 4, 5].includes(rule.ruleType);
  }
}
