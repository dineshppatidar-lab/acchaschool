import { ChangeDetectorRef, Component, OnDestroy, OnInit, signal } from '@angular/core';
import { CommonModule } from "@angular/common";
import { ReactiveFormsModule, FormControl } from "@angular/forms";
import { ActivatedRoute, Router, RouterModule } from "@angular/router";
import { MatTabsModule } from "@angular/material/tabs";
import { MatCardModule } from "@angular/material/card";
import { MatButtonModule } from "@angular/material/button";
import { MatIconModule } from "@angular/material/icon";
import { MatProgressSpinnerModule } from "@angular/material/progress-spinner";
import { MatProgressBarModule } from "@angular/material/progress-bar";
import { MatSnackBar, MatSnackBarModule } from "@angular/material/snack-bar";
import { MatDividerModule } from "@angular/material/divider";
import { MatChipsModule } from "@angular/material/chips";
import { MatTableModule } from "@angular/material/table";
import { MatAutocompleteModule } from "@angular/material/autocomplete";
import { MatFormFieldModule } from "@angular/material/form-field";
import { MatInputModule } from "@angular/material/input";
import { MatTooltipModule } from "@angular/material/tooltip";
import { Subject, Observable, of } from "rxjs";
import { debounceTime, distinctUntilChanged, switchMap, map, catchError, tap, takeUntil, finalize } from "rxjs/operators";
import { FeeManagementService } from "../../shared/services/fee-management.service";
import { StudentManagementService } from "../../shared/services/student-management.service";
import { ReceiptPrinterService } from "../../shared/services/receipt-printer.service";
import { FeePageHeaderComponent } from "../../shared/components/fees-module/fee-page-header.component";
import { FeeKpiCardComponent } from "../../shared/components/fees-module/fee-kpi-card.component";
import {
  DashboardFeeSummary,
  InstallmentDisplay,
  PaymentDisplay,
  StudentInfoDisplay,
  RefundDisplay,
  StudentSearchResult,
} from "./student-fees-dashboard-demo.models";

/** Days until an installment due date (negative = overdue). */
export function daysUntilDue(dueDate: string): number {
  if (!dueDate) return Number.MAX_SAFE_INTEGER;
  const due = new Date(dueDate).setHours(23, 59, 59, 999);
  const now = Date.now();
  return Math.ceil((due - now) / (1000 * 60 * 60 * 24));
}

@Component({
  selector: "app-student-fees-dashboard",
  standalone: true,
  imports: [
    CommonModule, ReactiveFormsModule, RouterModule,
    MatTabsModule, MatCardModule, MatButtonModule, MatIconModule,
    MatProgressSpinnerModule, MatProgressBarModule, MatSnackBarModule,
    MatDividerModule, MatChipsModule, MatTableModule,
    MatAutocompleteModule, MatFormFieldModule, MatInputModule, MatTooltipModule,
    FeePageHeaderComponent, FeeKpiCardComponent,
  ],
  templateUrl: "./student-fees-dashboard-demo.component.html",
  styleUrls: ["./student-fees-dashboard-demo.component.scss"],
})
export class StudentFeesDashboardComponent implements OnInit, OnDestroy {
  searchControl = new FormControl("");
  filteredStudents$!: Observable<any[]>;
  selectedStudent: StudentSearchResult | null = null;
  searching = signal(false);
  loading = signal(false);
  loadingInstallments = signal(false);
  loadingPayments = signal(false);
  loadingDetails = signal(false);
  loadingRefunds = signal(false);
  error = signal<any>(null);
  lastLoadedStudentId: number | null = null;
  feeSummary = signal<any>(null);
  installmentsData = signal<any[]>([]);
  paymentsData = signal<any[]>([]);
  studentDetails = signal<any>(null);
  refundsData = signal<any[]>([]);
  upcomingDues = signal<any[]>([]);
  installmentColumns = ["name", "amount", "paid", "dueDate", "status", "action"];
  private destroy$ = new Subject<void>();

  constructor(
    private fm: FeeManagementService,
    private sm: StudentManagementService,
    private receiptPrinter: ReceiptPrinterService,
    private snackBar: MatSnackBar,
    private route: ActivatedRoute,
    private cdr: ChangeDetectorRef,
  ) {}

  /** True when any installment is due within 7 days or overdue. */
  get hasUrgentDues(): boolean {
    return this.upcomingDues().some(d => daysUntilDue(d.dueDate) <= 7);
  }

  /** Earliest upcoming due date across pending/overdue installments. */
  get nextDueDate(): string {
    const upcoming = this.upcomingDues()
      .map(d => d.dueDate)
      .filter(Boolean)
      .sort((a, b) => new Date(a).getTime() - new Date(b).getTime());
    return upcoming[0] || "";
  }

  /** Total amount pending across due installments. */
  get nextDueAmount(): number {
    return this.upcomingDues().reduce((sum, d) => sum + Math.max(0, d.amount - d.paidAmount), 0);
  }

  /** Per-installment paid percentage (0-100) for progress bars. */
  installmentPaidPercent(element: InstallmentDisplay): number {
    if (!element.amount) return 0;
    return Math.min(100, Math.round((element.paidAmount / element.amount) * 100));
  }

  /** Days label for an installment, e.g. "Due in 3 days" / "3 days overdue". */
  dueLabel(element: InstallmentDisplay): string {
    const days = daysUntilDue(element.dueDate);
    if (days === Number.MAX_SAFE_INTEGER || element.status === "paid") return "";
    if (days < 0) return `${Math.abs(days)} day${Math.abs(days) === 1 ? "" : "s"} overdue`;
    if (days === 0) return "Due today";
    return `Due in ${days} day${days === 1 ? "" : "s"}`;
  }

  ngOnInit(): void {
    this.route.params.pipe(takeUntil(this.destroy$)).subscribe(params => {
      if (params["studentId"]) {
        var id = +params["studentId"];
        if (!isNaN(id)) this.loadStudentById(id);
      }
    });

    this.filteredStudents$ = this.searchControl.valueChanges.pipe(
      debounceTime(300),
      distinctUntilChanged(),
      switchMap(val => {
        var q = typeof val === "string" ? val.trim() : "";
        if (q.length < 2) {
          this.deferAction(() => {
            this.searching.set(false);
          });
          return of([]);
        }
        this.deferAction(() => {
          this.searching.set(true);
        });
        return this.fm.searchStudents(q).pipe(
          map(r => this.extractArrayData(r)),
          catchError(() => {
            this.deferAction(() => {
              this.searching.set(false);
            });
            return of([]);
          }),
          tap(() => {
            this.deferAction(() => {
              this.searching.set(false);
            });
          })
        );
      }),
      takeUntil(this.destroy$)
    );
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  displayStudentName(s: StudentSearchResult): string {
    return s ? s.firstName + " " + s.lastName : "";
  }

  /** Initials for the banner avatar (falls back to a dot when name is a placeholder). */
  avatarInitials(): string {
    const s = this.selectedStudent;
    if (!s) return "?";
    const first = (s.firstName || "").trim();
    const last = (s.lastName || "").trim();
    // Placeholder rows from deep links look like "Student #123"
    if (/^#\d+$/.test(last) || (!first && !last)) return "?";
    return ((first[0] || "") + (last[0] || "")).toUpperCase() || "?";
  }

  /** Move focus back to the search field (used by the banner swap button). */
  focusSearch(): void {
    document.querySelector<HTMLInputElement>(".sf input")?.focus();
  }

  private markForRefresh(): void {
    this.cdr.markForCheck();
    this.cdr.detectChanges();
  }

  private deferAction(action: () => void): void {
    action();
    this.markForRefresh();
  }

  onStudentSelected(e: any): void {
    var s = e.option.value as StudentSearchResult;
    if (s && s.id) {
      this.selectedStudent = s;
      this.deferAction(() => this.loadStudentData(s.id));
    }
  }

  clearSearch(): void {
    this.searchControl.setValue("");
    this.selectedStudent = null;
    this.deferAction(() => this.clearData());
  }

  clearData(): void {
    this.feeSummary.set(null);
    this.installmentsData.set([]);
    this.paymentsData.set([]);
    this.studentDetails.set(null);
    this.refundsData.set([]);
    this.upcomingDues.set([]);
    this.error.set(null);
    this.lastLoadedStudentId = null;
    this.markForRefresh();
  }

  private extractArrayData(response: any): any[] {
    if (Array.isArray(response)) return response;
    if (Array.isArray(response?.data)) return response.data;
    if (Array.isArray(response?.items)) return response.items;
    if (Array.isArray(response?.entries)) return response.entries;
    if (Array.isArray(response?.data?.entries)) return response.data.entries;
    if (Array.isArray(response?.data?.items)) return response.data.items;
    if (response && typeof response === "object") {
      const nestedValues = Object.values(response).filter((value): value is any => Array.isArray(value));
      return nestedValues.length > 0 ? nestedValues[0] : [];
    }
    return [];
  }

  private extractObjectData(response: any): any | null {
    if (!response || typeof response !== "object") return null;
    if (Array.isArray(response)) return null;
    if (response.data && typeof response.data === "object" && !Array.isArray(response.data)) return response.data;
    if (response.result && typeof response.result === "object" && !Array.isArray(response.result)) return response.result;
    return response;
  }

  private loadStudentById(id: number): void {
    this.loading.set(true);
    this.selectedStudent = { id: id, firstName: "Student", lastName: "#" + id } as StudentSearchResult;
    this.markForRefresh();
    this.loadStudentData(id);
  }

  loadStudentData(id: number): void {
    if (this.lastLoadedStudentId === id) return;
    this.lastLoadedStudentId = id;
    this.deferAction(() => {
      this.loading.set(true);
      this.error.set(null);
      this.loadingInstallments.set(true);
      this.loadingPayments.set(true);
      this.loadingDetails.set(true);
      this.loadingRefunds.set(true);
    });

    this.fm.getOutstandingFees(id).pipe(
      // The summary is the primary payload: surface its failure via the error
      // card so the Retry action works (secondary panels degrade to empty states).
      catchError(e => {
        console.error(e);
        this.deferAction(() => this.error.set("Failed to load fee data for this student. Please try again."));
        return of(null);
      }),
      finalize(() => this.deferAction(() => this.loading.set(false)))
    ).subscribe(r => {
      const summaryPayload = this.extractObjectData(r);
      const summary = summaryPayload || r;
      if (summary) {
        const totalFee = summary.totalFees || summary.totalFee || 0;
        const paidAmount = summary.paidAmount || 0;
        const discountAmount = summary.discountAmount || 0;
        const outstandingAmount = summary.outstandingAmount || 0;
        const netFee = totalFee - discountAmount;
        const refundAmount = Math.max(0, paidAmount - netFee);
        this.feeSummary.set({
          totalFee: totalFee,
          paidAmount: paidAmount,
          outstandingAmount: outstandingAmount,
          collectionPercent: totalFee > 0 ? Math.round((paidAmount / totalFee) * 100) : 0,
          discountAmount: discountAmount,
          lateFeeAmount: summary.lateFeeAmount || 0,
          refundAmount: refundAmount,
        });
        if (summary.dueInstallments && Array.isArray(summary.dueInstallments)) {
          this.upcomingDues.set(summary.dueInstallments
            .filter((d: any) => (d.status || "").toLowerCase() === "pending" || (d.status || "").toLowerCase() === "overdue")
            .map((d: any) => ({
              name: d.name || "",
              amount: d.amount || 0,
              paidAmount: d.paidAmount || 0,
              dueDate: d.dueDate ? new Date(d.dueDate).toLocaleDateString("en-IN", { year: "numeric", month: "short", day: "numeric" }) : "",
              status: d.status || "pending",
              daysOverdue: d.daysOverdue || 0,
              lateFee: d.lateFee || 0,
              discount: 0,
              installmentId: d.installmentId || 0,
            })));
        }
        this.markForRefresh();
      }
    });

    this.fm.getStudentFeeInstallments(id).pipe(
      catchError(e => of([])),
      finalize(() => this.deferAction(() => this.loadingInstallments.set(false)))
    ).subscribe(r => {
      const d = this.extractArrayData(r);
      this.installmentsData.set(d.length > 0 ? d.map((i: any) => ({
        name: i.name || i.installmentName || "",
        amount: i.amount || i.totalAmount || 0,
        paidAmount: i.paidAmount || i.paid || 0,
        dueDate: i.dueDate ? new Date(i.dueDate).toLocaleDateString("en-IN", { year: "numeric", month: "short", day: "numeric" }) : "",
        status: (i.status || "pending").toLowerCase(),
        daysOverdue: i.daysOverdue || 0,
        lateFee: i.lateFee || 0,
        discount: i.discountAmount || 0,
        installmentId: i.installmentId || i.id || 0,
      })) : []);
      this.markForRefresh();
    });

    this.fm.getStudentLedger(id).pipe(
      catchError(e => of([])),
      finalize(() => this.deferAction(() => this.loadingPayments.set(false)))
    ).subscribe(r => {
      const ledgerPayload = this.extractObjectData(r);
      const entries = this.extractArrayData(ledgerPayload?.entries ?? ledgerPayload?.data ?? r);
      this.paymentsData.set(entries.length > 0 ? entries
        .filter((e: any) => (e.amount || e.amountPaid || e.creditAmount) > 0)
        .map((e: any) => ({
          date: (e.transactionDate || e.paymentDate || e.date || e.createdAt)
            ? new Date(e.transactionDate || e.paymentDate || e.date || e.createdAt).toLocaleDateString("en-IN", { year: "numeric", month: "short", day: "numeric" }) : "",
          amount: Math.abs(e.amount || e.amountPaid || e.creditAmount || 0),
          method: e.entryType || e.paymentMethod || e.method || "",
          status: (e.entryType || e.status || "success").toLowerCase(),
          receipt: e.referenceId ? `#${e.referenceId}` : e.receiptNumber || e.receipt || "",
          description: e.description || e.remarks || "",
        })) : []);
      this.markForRefresh();
    });

    this.sm.getStudentFullDetails(id).pipe(
      catchError(e => of(null)),
      finalize(() => this.deferAction(() => this.loadingDetails.set(false)))
    ).subscribe(r => {
      const detailPayload = this.extractObjectData(r);
      const d = detailPayload || r;
      if (d) {
        this.studentDetails.set({
          id: d.id,
          name: `${d.firstName || ""} ${d.lastName || ""}`.trim(),
          admissionNumber: d.scholarNumber || `STU-${d.id}`,
          rollNumber: d.rollNumber || "",
          className: d.className || (d.classId ? `Class ${d.classId}` : ""),
          // Backend now resolves the real section name (A/B/C…) on the DTO;
          // the numeric-id fallbacks were removed because they rendered
          // "Section 3"-style labels on the fees dashboard.
          sectionName: d.sectionName || "",
          academicYear: d.academicYear || (d.academicYearId ? `Year ${d.academicYearId}` : ""),
          status: (this.feeSummary()?.refundAmount || 0) > 0 ? "refunded" : (this.feeSummary()?.outstandingAmount === 0 ? "paid" : "pending"),
          parentName: d.newParentDetails ? `${d.newParentDetails.firstName || ""} ${d.newParentDetails.lastName || ""}`.trim() : "",
          contactNumber: d.contactNumber || "",
          email: d.email || "",
          address: d.address || "",
          gender: d.gender || "",
        });
        this.markForRefresh();
      }
    });

    this.fm.getRefundHistory(id).pipe(
      catchError(e => of([])),
      finalize(() => this.deferAction(() => this.loadingRefunds.set(false)))
    ).subscribe(r => {
      const d = this.extractArrayData(r);
      this.refundsData.set(d.length > 0 ? d.map((rf: any) => ({
        id: rf.id || 0,
        amount: rf.refundAmount || rf.amount || 0,
        date: (rf.refundDate || rf.date || rf.createdAt)
          ? new Date(rf.refundDate || rf.date || rf.createdAt).toLocaleDateString("en-IN", { year: "numeric", month: "short", day: "numeric" }) : "",
        reason: rf.refundReason || rf.reason || "",
        status: (rf.status || "completed").toLowerCase(),
        referenceNumber: rf.referenceNumber || "",
      })) : []);
      this.markForRefresh();
    });
  }

  refreshData(): void {
    if (this.selectedStudent?.id) {
      this.lastLoadedStudentId = null;
      this.deferAction(() => this.loadStudentData(this.selectedStudent!.id));
    }
  }

  retryLoading(): void {
    this.error.set(null);
    if (this.selectedStudent?.id) {
      this.lastLoadedStudentId = null;
      this.deferAction(() => this.loadStudentData(this.selectedStudent!.id));
    }
  }

  /**
   * Fee statement PDF via the shared invoice printer (same flow as payment
   * receipts — school branding, mobile-friendly sheet, save-as-PDF).
   * window.print() was replaced because it prints the empty app shell on
   * mobile and the user sees nothing happen.
   */
  printStatement(): void {
    const fee = this.feeSummary();
    const student = this.selectedStudent;
    if (!student || !fee) {
      this.snackBar.open("Select a student to print their fee statement", "Close", { duration: 3000 });
      return;
    }

    const details = this.studentDetails();
    const studentName = details?.name || `${student.firstName} ${student.lastName}`.trim();
    const roll = details?.rollNumber || (student as any).rollNumber || "";
    const rollSuffix = roll ? ` (Roll: ${roll})` : "";

    // Items: one row per installment (fall back to the summary's due list).
    const source = this.installmentsData().length ? this.installmentsData() : this.upcomingDues();
    const items = source.map(inst => {
      const total = inst.amount || 0;
      const paid = inst.paidAmount || 0;
      const balance = Math.max(0, total - paid);
      const state = balance <= 0 ? "Fully Paid"
        : paid > 0 ? "Partial"
        : ((inst.status || "pending").charAt(0).toUpperCase() + (inst.status || "pending").slice(1));
      return {
        description: [inst.name || "Installment", inst.dueDate ? `Due ${inst.dueDate}` : "", state]
          .filter(Boolean).join(" — "),
        unitPrice: total,
        total: total
      };
    });
    // Never render an empty items table if schedule data hasn't loaded.
    if (items.length === 0) {
      items.push({ description: "Total Fees", unitPrice: fee.totalFee || 0, total: fee.totalFee || 0 });
    }

    const infoLines: string[] = [];
    if (details?.className) {
      infoLines.push(`Class: ${details.className}${details.sectionName ? ` | Section: ${details.sectionName}` : ""}`);
    }
    if (details?.admissionNumber) infoLines.push(`Admission / Scholar No.: ${details.admissionNumber}`);
    infoLines.push(`Total Paid: ${this.formatCurrency(fee.paidAmount)} (${fee.collectionPercent || 0}% collected)`);
    if (fee.outstandingAmount > 0) infoLines.push(`Balance Due: ${this.formatCurrency(fee.outstandingAmount)}`);
    if (fee.discountAmount > 0) infoLines.push(`Discounts Applied: ${this.formatCurrency(fee.discountAmount)}`);
    if (fee.refundAmount > 0) infoLines.push(`Refund Due: ${this.formatCurrency(fee.refundAmount)}`);

    this.receiptPrinter.print({
      title: "Fee Statement",
      receiptNo: `STMT-${Date.now()}`,
      studentName: `${studentName}${rollSuffix}`,
      date: new Date().toISOString().slice(0, 10),
      items,
      paymentMethod: "Fee Statement",
      infoLines
    }).catch(err => {
      console.error("Failed to generate fee statement", err);
      this.snackBar.open("Failed to generate fee statement", "Close", { duration: 3000 });
    });
  }

  formatCurrency(amount: number): string {
    return new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR" }).format(amount);
  }

  getStatusClass(status: string): string {
    return "status-" + (status || "pending").toLowerCase();
  }

  getStatusLabel(status: string): string {
    const labels: Record<string, string> = {
      paid: "Paid",
      pending: "Pending",
      overdue: "Overdue",
      completed: "Completed",
      failed: "Failed",
      refunded: "Refund Due",
    };
    return labels[(status || "").toLowerCase()] || status;
  }
}
