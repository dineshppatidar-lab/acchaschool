import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnInit, ViewChild, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatCardModule } from '@angular/material/card';
import { MatSelectModule } from '@angular/material/select';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatTabsModule } from '@angular/material/tabs';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { ApiService } from '../../services/api.service';
import { NotificationService } from '../../services/notification.service';
import { AdvancedAcademicService } from '../../services/advanced-academic.service';
import { FeeManagementService } from '../../shared/services/fee-management.service';
import { AcademicYear } from '../../shared/models/academic.models';
import { AcademicYearContextService } from '../../shared/services/academic-year-context.service';
import { Observable, of } from 'rxjs';
import { debounceTime, switchMap, catchError, finalize } from 'rxjs/operators';
import { FeeStatusBadgeComponent } from '../../shared/components/fees-module/fee-status-badge.component';
import { FeeKpiCardComponent } from '../../shared/components/fees-module/fee-kpi-card.component';
import { FeePageHeaderComponent } from '../../shared/components/fees-module/fee-page-header.component';

interface WaiverRequest {
  id?: number;
  studentId: number;
  studentName?: string;
  adjustmentType: 'waiver' | 'discount';
  isPercentage: boolean;
  discountPercentage?: number;
  discountAmount?: number;
  maximumCap?: number;
  isFullWaiver: boolean;
  waiverCategory?: string;
  effectiveDate: string;
  expiryDate?: string;
  status: string;
  remarks?: string;
}

@Component({
  selector: 'app-fee-waiver',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule,
    MatCardModule,
    MatSelectModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatProgressSpinnerModule,
    MatSnackBarModule,
    MatTabsModule,
    MatCheckboxModule,
    MatSlideToggleModule,
    MatAutocompleteModule,
    FeeStatusBadgeComponent,
    FeeKpiCardComponent,
    FeePageHeaderComponent
  ],
  templateUrl: './fee-waiver.component.html',
  styleUrls: ['./fee-waiver.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class FeeWaiverComponent implements OnInit {
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  // Form properties
  waiverForm!: FormGroup;
  studentSearchControl = new FormControl('');
  isLoading = signal(false);
  isSubmitting = signal(false);
  isSearching = signal(false);
  activeTab = signal(0);
  selectedStudent = signal<any>(null);

  // Data
  academicYears = signal<any[]>([]);
  filteredStudents = signal<any[]>([]);
  waiverRequests = signal<any[]>([]);
  dataSource = new MatTableDataSource<WaiverRequest>([]);
  displayedColumns: string[] = ['studentName', 'waiverAmount', 'waiverType', 'status', 'appliedDate', 'actions'];

  // Filter properties
  statusFilter = 'all';
  typeFilter = 'all';
  studentSearch = '';

  // Statistics
  totalWaivers = 0;
  totalAmount = 0;
  approvedCount = 0;
  pendingCount = 0;

  constructor(
    private fb: FormBuilder,
    private apiService: ApiService,
    private notificationService: NotificationService,
    private academicService: AdvancedAcademicService,
    private feeService: FeeManagementService,
    private snackBar: MatSnackBar,
    private cdr: ChangeDetectorRef,
    private yearContext: AcademicYearContextService
  ) {
    this.initializeForm();
  }

  ngOnInit(): void {
    this.loadAcademicYearsFromContext();
    this.loadWaiverRequests();
    this.setupStudentSearch();
  }

  private initializeForm(): void {
    this.waiverForm = this.fb.group({
      studentId: ['', Validators.required],
      waiverAmount: [''],
      waiverType: ['partial', Validators.required],
      reason: ['', Validators.required],
      academicYearId: ['', Validators.required],
      remark: ['']
    });

    // Update validators based on waiver type
    this.waiverForm.get('waiverType')?.valueChanges.subscribe(type => {
      const amountControl = this.waiverForm.get('waiverAmount');
      if (type === 'partial') {
        amountControl?.setValidators([Validators.required, Validators.min(0.01)]);
      } else {
        amountControl?.clearValidators();
        amountControl?.setValue(0);
      }
      amountControl?.updateValueAndValidity();
      this.cdr.detectChanges();
    });

    // Set initial validators for 'partial'
    this.waiverForm.get('waiverAmount')?.setValidators([Validators.required, Validators.min(0.01)]);

    // Reset student when academic year changes
    this.waiverForm.get('academicYearId')?.valueChanges.subscribe(() => {
      this.waiverForm.patchValue({ studentId: '' });
      this.studentSearchControl.setValue('');
      this.filteredStudents.set([]);
      this.selectedStudent.set(null);
      this.cdr.detectChanges();
    });
  }

  private setupStudentSearch(): void {
    this.studentSearchControl.valueChanges.pipe(
      debounceTime(300),
      switchMap(value => {
        const val = typeof value === 'string' ? value.trim() : '';
        if (val.length >= 1) {
          this.isSearching.set(true);
          this.cdr.detectChanges();
          const academicYearId = this.waiverForm.get('academicYearId')?.value;
          
          return this.feeService.searchStudents(val, academicYearId).pipe(
            finalize(() => {
              this.isSearching.set(false);
              this.cdr.detectChanges();
            }),
            catchError(() => of({ data: [] }))
          );
        } else {
          return of(null);
        }
      })
    ).subscribe((response: any) => {
      if (response === null) return;

      const data = response?.data || response || [];
      
      if (Array.isArray(data)) {
        this.filteredStudents.set(data.map((s: any) => ({
          ...s,
          displayName: s.displayName || `${s.firstName} ${s.lastName} (${s.rollNumber})`
        })));
      } else {
        this.filteredStudents.set([]);
      }
      this.cdr.detectChanges();
    });
  }

  loadAcademicYearsFromContext(): void {
    this.yearContext.loadAcademicYears().subscribe({
      next: () => {
        this.academicYears.set(this.yearContext.yearsSnapshot as any[]);
        if (this.academicYears().length > 0) {
          const selectedId = this.yearContext.selectedYearId;
          if (selectedId) {
            this.waiverForm.patchValue({ academicYearId: selectedId });
          }
        }
        this.cdr.detectChanges();
      },
      error: () => {
        this.cdr.detectChanges();
      }
    });
  }

  displayStudent(student: any): string {
    if (!student) return '';
    return student.displayName || `${student.firstName} ${student.lastName} (${student.rollNumber})`;
  }

  onStudentSelected(event: any): void {
    this.selectedStudent.set(event.option.value);
    this.waiverForm.patchValue({ studentId: this.selectedStudent().id });
    this.cdr.detectChanges();
  }

  loadWaiverRequests(): void {
    this.isLoading.set(true);
    this.cdr.detectChanges();
    
    this.apiService.get<any>('/fees/waivers').subscribe({
      next: (response: any) => {
        const data = response.data || response;
        this.waiverRequests.set(Array.isArray(data) ? data : []);
        this.updateTableData();
        this.isLoading.set(false);
        this.cdr.detectChanges();
      },
      error: (error: any) => {
        console.error('Error loading waiver requests:', error);
        this.notificationService.error('Failed to load waiver requests');
        this.isLoading.set(false);
        this.cdr.detectChanges();
      }
    });
  }

  submitWaiverRequest(): void {
    if (!this.waiverForm.valid) {
      this.notificationService.warning('Please fill all required fields');
      return;
    }

    this.isSubmitting.set(true);
    this.cdr.detectChanges();
    
    const formValue = this.waiverForm.value;
    const isFullWaiver = formValue.waiverType === 'full';
    
    // Determine which endpoint to use based on adjustment type
    const endpoint = isFullWaiver ? '/fees/waivers' : '/fees/discounts';
    
    let requestPayload: any;
    
    if (isFullWaiver) {
      requestPayload = {
        studentId: formValue.studentId,
        academicYearId: formValue.academicYearId,
        waiverCategory: formValue.reason,
        effectiveDate: new Date().toISOString(),
        remarks: formValue.remark,
        specificInstallmentId: 0,
        approvedBy: 0 
      };
    } else {
      requestPayload = {
        studentId: formValue.studentId,
        academicYearId: formValue.academicYearId,
        isPercentage: false,
        discountValue: formValue.waiverAmount,
        effectiveDate: new Date().toISOString(),
        remarks: formValue.reason + (formValue.remark ? ': ' + formValue.remark : ''),
        specificInstallmentId: 0,
        createdBy: 0
      };
    }

    this.apiService.post(endpoint, requestPayload).subscribe({
      next: () => {
        this.notificationService.success(`${isFullWaiver ? 'Waiver' : 'Discount'} request submitted successfully`);
        this.resetForm();
        this.activeTab.set(1);
        this.loadWaiverRequests();
        this.isSubmitting.set(false);
        this.cdr.detectChanges();
      },
      error: (error) => {
        console.error('Error submitting request:', error);
        this.notificationService.error(`Failed to submit ${isFullWaiver ? 'waiver' : 'discount'} request`);
        this.isSubmitting.set(false);
        this.cdr.detectChanges();
      }
    });
  }

  resetForm(): void {
    const currentYearId = this.waiverForm.get('academicYearId')?.value;
    this.waiverForm.reset();
    this.studentSearchControl.setValue('');
    this.filteredStudents.set([]);
    this.waiverForm.patchValue({
      waiverType: 'partial',
      academicYearId: currentYearId
    });
    this.cdr.detectChanges();
  }

  approveWaiver(waiver: WaiverRequest): void {
    if (!waiver.id) return;

    // Server enum is FeeAdjustmentStatus (PendingApproval/Active/Inactive/Expired/Rejected) —
    // 'approved' was silently ignored by Enum.TryParse.
    this.apiService.put(`/fees/waivers/${waiver.id}`, { status: 'Active' }).subscribe({
      next: () => {
        this.notificationService.success('Waiver approved successfully');
        this.loadWaiverRequests();
        this.cdr.detectChanges();
      },
      error: (error) => {
        console.error('Error approving waiver:', error);
        this.notificationService.error('Failed to approve waiver');
        this.cdr.detectChanges();
      }
    });
  }

  rejectWaiver(waiver: WaiverRequest): void {
    if (!waiver.id) return;

    this.apiService.put(`/fees/waivers/${waiver.id}`, { status: 'Rejected' }).subscribe({
      next: () => {
        this.notificationService.success('Waiver rejected');
        this.loadWaiverRequests();
        this.cdr.detectChanges();
      },
      error: (error) => {
        console.error('Error rejecting waiver:', error);
        this.notificationService.error('Failed to reject waiver');
        this.cdr.detectChanges();
      }
    });
  }

  deleteWaiver(waiver: WaiverRequest): void {
    if (!waiver.id || !confirm('Are you sure you want to delete this waiver request?')) return;

    this.apiService.delete(`/fees/waivers/${waiver.id}`).subscribe({
      next: () => {
        this.notificationService.success('Waiver deleted successfully');
        this.loadWaiverRequests();
        this.cdr.detectChanges();
      },
      error: (error) => {
        console.error('Error deleting waiver:', error);
        this.notificationService.error('Failed to delete waiver');
        this.cdr.detectChanges();
      }
    });
  }

  private updateTableData(): void {
    let filtered = [...this.waiverRequests()];

    // Apply status filter
    if (this.statusFilter !== 'all') {
      filtered = filtered.filter(w => {
        const s = String(w.status).toLowerCase();
        if (this.statusFilter === 'pending') return s === 'pendingapproval' || s === '0' || s === 'pending';
        return s === this.statusFilter.toLowerCase();
      });
    }

    // Apply type filter
    if (this.typeFilter !== 'all') {
      filtered = filtered.filter(w => {
        if (this.typeFilter === 'full') return w.isFullWaiver;
        if (this.typeFilter === 'partial') return !w.isFullWaiver;
        return true;
      });
    }

    // Apply student search
    const searchTerm = this.studentSearch.trim().toLowerCase();
    if (searchTerm) {
      filtered = filtered.filter(w =>
        (w.studentName || '').toLowerCase().includes(searchTerm) ||
        (w.studentId || '').toString().includes(searchTerm)
      );
    }

    this.dataSource = new MatTableDataSource(filtered);
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
    
    this.calculateStatistics();
    this.cdr.detectChanges();
  }

  private calculateStatistics(): void {
    this.totalWaivers = this.waiverRequests().length;
    this.totalAmount = this.waiverRequests().reduce((sum, w) => sum + (w.discountAmount || 0), 0);
    
    this.approvedCount = this.waiverRequests().filter(w => {
      const s = String(w.status).toLowerCase();
      return s === 'approved' || s === '1' || s === 'active';
    }).length;
    
    this.pendingCount = this.waiverRequests().filter(w => {
      const s = String(w.status).toLowerCase();
      return s === 'pendingapproval' || s === '0' || s === 'pending';
    }).length;
  }

  onStatusFilterChange(): void {
    this.updateTableData();
  }

  onTypeFilterChange(): void {
    this.updateTableData();
  }

  onSearchChange(): void {
    this.updateTableData();
  }

  loadWaivers(): void {
    this.loadWaiverRequests();
  }
}
