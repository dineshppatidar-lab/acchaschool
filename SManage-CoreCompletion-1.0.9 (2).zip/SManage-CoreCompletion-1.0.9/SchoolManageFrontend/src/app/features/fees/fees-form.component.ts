import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnInit, signal } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { FeesService } from '../../services/fees.service';
import { StudentService } from '../../services/student.service';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { CommonModule } from '@angular/common';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatSelectModule } from '@angular/material/select';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSnackBarModule, MatSnackBar } from '@angular/material/snack-bar';
import { MatDividerModule } from '@angular/material/divider';
import { MatChipsModule } from '@angular/material/chips'; 
import { MasterDataService } from '../../services/master-data.service';
import { Router, ActivatedRoute, RouterModule } from '@angular/router';
import { Location } from '@angular/common';
import { Observable } from 'rxjs';

export interface Fee {
  id?: number;
  studentId: number;
  feeType: string;
  amount: number;
  dueDate: string;
  status: string;
}

@Component({
  selector: 'app-fees-form',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    CommonModule, 
    ReactiveFormsModule, 
    MatFormFieldModule, 
    MatInputModule, 
    MatButtonModule, 
    MatCardModule,
    MatIconModule,
    MatSelectModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatProgressSpinnerModule,
    MatSnackBarModule,
    MatDividerModule,
    MatChipsModule,
    RouterModule
  ],
  templateUrl: './fees-form.component.html',
  styleUrls: ['./fees-form.component.scss']
})
export class FeesFormComponent implements OnInit {
  feesForm: FormGroup;
  success = signal<any>(null);
  error = signal<any>(null);
  loading = signal(false);
  isEdit = false;
  feeId?: number;

  feeTypes$!: Observable<any[]>;
  feeStatuses$!: Observable<any[]>;
  paymentMethods$!: Observable<any[]>;
  feeTypes = signal<any[]>([]);
  feeStatuses = signal<any[]>([]);
  paymentMethods = signal<any[]>([]);

  constructor(
    private fb: FormBuilder, 
    private feesService: FeesService,
    private snackBar: MatSnackBar,
    private router: Router,
    private route: ActivatedRoute,
    private studentService: StudentService,
    private cdr: ChangeDetectorRef,
    private masterDataService: MasterDataService,
    private location: Location
  ) {
    this.feesForm = this.fb.group({
      studentId: [null, [Validators.required, Validators.min(1)]],
      studentName: [''],
      feeType: ['', Validators.required],
      amount: [null, [Validators.required, Validators.min(0)]],
      dueDate: [null, Validators.required],
      status: ['pending', Validators.required],
      paymentMethod: [''],
      transactionId: [''],
      description: [''],
      lateFeeAmount: [0, [Validators.min(0)]],
      discountAmount: [0, [Validators.min(0)]]
    });
  }

  /** History-aware back navigation for the header back arrow. */
  goBack(): void {
    if (typeof window !== 'undefined' && window.history.length > 1) {
      this.location.back();
    } else {
      this.router.navigate(['/app/fees/list']);
    }
  }

  ngOnInit() {
    this.loadLookups();
    const idParam = this.route.snapshot.paramMap.get('id');
    if (idParam) {
      this.isEdit = true;
      this.feeId = Number(idParam);
      this.loading.set(true);
      this.feesService.getById(this.feeId).subscribe({
        next: (fee) => {
          // Convert dueDate string to Date for datepicker
          const dueDateVal = fee.dueDate ? new Date(fee.dueDate) : null;
          this.feesForm.patchValue({
            studentId: fee.studentId,
            feeType: fee.feeType,
            amount: fee.amount,
            dueDate: dueDateVal,
            status: fee.status,
            paymentMethod: (fee as any).paymentMethod || '',
            transactionId: (fee as any).transactionId || '',
            description: (fee as any).description || '',
            lateFeeAmount: (fee as any).lateFeeAmount ?? 0,
            discountAmount: (fee as any).discountAmount ?? 0
          });
          // Fetch and set student name for display
          this.fetchStudentName(fee.studentId);
          this.loading.set(false);
          this.cdr.markForCheck();
        },
        error: (err) => {
          console.error('Failed to load fee for edit', err);
          this.error.set('Failed to load fee details.');
          this.loading.set(false);
          this.cdr.markForCheck();
        }
      });
    } else {
      // Set default due date to 30 days from now
      const defaultDueDate = new Date();
      defaultDueDate.setDate(defaultDueDate.getDate() + 30);
      this.feesForm.patchValue({ dueDate: defaultDueDate });
      this.cdr.markForCheck();
    }
  }

  loadLookups(): void {
    this.feeTypes$ = this.masterDataService.getFeeTypes();
    this.feeTypes$.subscribe((res: any[]) => {
      this.feeTypes.set(res || []);
    });

    this.feeStatuses$ = this.masterDataService.getFeeStatuses();
    this.feeStatuses$.subscribe((res: any[]) => {
      this.feeStatuses.set(res || []);
    });

    this.paymentMethods$ = this.masterDataService.getPaymentMethods();
    this.paymentMethods$.subscribe((res: any[]) => {
      this.paymentMethods.set(res || []);
    });
  }

  onSubmit() {
    if (this.feesForm.invalid) {
      this.markFormGroupTouched();
      return;
    }

    this.loading.set(true);
    this.error.set(null);
    this.success.set(null);

    const raw = this.feesForm.value as any;
    const dueDateObj = raw.dueDate ? new Date(raw.dueDate) : new Date();
    dueDateObj.setHours(0, 0, 0, 0);

    const feeData: any = {
      studentId: Number(raw.studentId),
      feeType: String(raw.feeType || ''),
      amount: Number(raw.amount || 0),
      dueDate: dueDateObj.toISOString(),
      status: String(raw.status || 'pending')
    };

    // preserve editing id for update endpoint matching route id.
    if (this.isEdit && this.feeId) {
      feeData.id = this.feeId;
    }

    // Optional extra fields that are part of the form but persist via separate payment API / logic.
    feeData.paymentMethod = raw.paymentMethod || '';
    feeData.transactionId = raw.transactionId || '';
    feeData.description = raw.description || '';
    feeData.lateFeeAmount = Number(raw.lateFeeAmount || 0);
    feeData.discountAmount = Number(raw.discountAmount || 0);

    const onSuccess = (message: string) => {
      this.loading.set(false);
      this.showSuccessMessage(message);
      // Navigate back to fees list
      this.router.navigate(['/app/fees/list']);
    };

    if (this.isEdit && this.feeId) {
      this.feesService.update(this.feeId, feeData as any).subscribe({
        next: () => onSuccess('Fee record updated successfully!'),
        error: (error) => {
          this.loading.set(false);
          console.error('Error updating fee:', error);
          this.error.set(this.extractFeeErrorMessage(error) || 'Failed to update fee record. Please try again.');
          this.cdr.markForCheck();
        }
      });
    } else {
      this.feesService.create(feeData as any).subscribe({
        next: () => onSuccess('Fee record created successfully!'),
        error: (error) => {
          this.loading.set(false);
          console.error('Error creating fee:', error);
          this.error.set(this.extractFeeErrorMessage(error) || 'Failed to create fee record. Please try again.');
          this.cdr.markForCheck();
        }
      });
    }
  }

  private extractFeeErrorMessage(error: any): string | null {
    if (!error?.error) {
      return null;
    }
    const payload = error.error;
    if (payload.errors && typeof payload.errors === 'object') {
      const messages: string[] = [];
      for (const key of Object.keys(payload.errors)) {
        const value = payload.errors[key];
        if (Array.isArray(value)) {
          messages.push(...value.map(x => String(x)));
        } else if (typeof value === 'string') {
          messages.push(value);
        }
      }
      if (messages.length) {
        return messages.join('; ');
      }
    }
    if (payload.title) {
      return payload.title;
    }
    return null;
  }

  calculateTotalAmount(): number {
    const amount = this.feesForm.get('amount')?.value || 0;
    const lateFeeAmount = this.feesForm.get('lateFeeAmount')?.value || 0;
    const discountAmount = this.feesForm.get('discountAmount')?.value || 0;
    return Math.max(0, amount + lateFeeAmount - discountAmount);
  }

  onStudentIdChange() {
    const studentId = Number(this.feesForm.get('studentId')?.value);
    if (studentId && !Number.isNaN(studentId)) {
      this.fetchStudentName(studentId);
    } else {
      this.feesForm.patchValue({ studentName: '' });
    }
  }

  private fetchStudentName(studentId: number) {
    this.studentService.getById(studentId).subscribe({
      next: (student) => {
        const name = `${student.firstName ?? ''} ${student.lastName ?? ''}`.trim();
        this.feesForm.patchValue({ studentName: name || `ID ${studentId}` });
        this.cdr.markForCheck();
      },
      error: () => {
        // Do not block, just clear/mark not found
        this.feesForm.patchValue({ studentName: '' });
        this.cdr.markForCheck();
      }
    });
  }

  private markFormGroupTouched() {
    Object.keys(this.feesForm.controls).forEach(key => {
      const control = this.feesForm.get(key);
      control?.markAsTouched();
    });
  }

  private resetForm() {
    this.feesForm.reset();
    this.resetValidationState();
    // Reset default values
    const defaultDueDate = new Date();
    defaultDueDate.setDate(defaultDueDate.getDate() + 30);
    this.feesForm.patchValue({ 
      dueDate: defaultDueDate,
      status: 'pending',
      lateFeeAmount: 0,
      discountAmount: 0
    });
  }

  private resetValidationState() {
    Object.keys(this.feesForm.controls).forEach(key => {
      const control = this.feesForm.get(key);
      control?.markAsUntouched();
      control?.markAsPristine();
    });
  }

  private showSuccessMessage(message: string) {
    this.success.set(message);
    this.snackBar.open(message, 'Close', {
      duration: 3000,
      panelClass: ['success-snackbar']
    });
  }

  getErrorMessage(fieldName: string): string {
    const control = this.feesForm.get(fieldName);
    if (control?.hasError('required')) {
      return `${this.capitalize(fieldName)} is required`;
    }
    if (control?.hasError('min')) {
      const minValue = control.errors?.['min']?.min;
      return `${this.capitalize(fieldName)} must be at least ${minValue}`;
    }
    return '';
  }

  private capitalize(str: string): string {
    return str.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase());
  }

  getStatusColor(status: string): string {
    const statusObj = this.feeStatuses().find(s => s.value === status);
    return statusObj?.color || 'var(--color-text-secondary)';
  }

  onCancel() {
    if (this.isEdit) {
      this.router.navigate(['/app/fees/list']);
    } else {
      this.resetForm();
    }
  }
}