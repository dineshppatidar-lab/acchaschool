import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FeesListComponent } from './fees-list.component';
import { FeesFormComponent } from './fees-form.component';
import { StudentLedgerComponent } from './student-ledger.component';
import { FeeDefaultersComponent } from './fee-defaulters.component';
import { FeeRulesComponent } from './fee-rules.component';

const routes: Routes = [
  { path: '', redirectTo: 'list', pathMatch: 'full' },
  { path: 'list', component: FeesListComponent },
  { path: 'form', component: FeesFormComponent },
  { path: 'edit/:id', component: FeesFormComponent },
  { path: 'ledger/:studentId', component: StudentLedgerComponent },
  { path: 'defaulters', component: FeeDefaultersComponent },
  { path: 'rules', component: FeeRulesComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FeesRoutingModule { }
