import { ChangeDetectionStrategy, ChangeDetectorRef, Component, Inject, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { MatDialogModule, MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatCardModule } from '@angular/material/card';
import { MatSelectModule } from '@angular/material/select';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatDividerModule } from '@angular/material/divider';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';

import { FeeManagementService } from '../../shared/services/fee-management.service';
import { ConfirmDialogComponent, ConfirmDialogData } from '../../shared/confirm-dialog.component';
import { ReceiptPrinterService } from '../../shared/services/receipt-printer.service';
import { MatDialog } from '@angular/material/dialog';

export interface PaymentDialogData {
  studentId: number;
  installment: any;
  remainingBalance: number;
  studentName: string;
  studentRollNumber?: string;
}

@Component({
  selector: 'app-payment-popup',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatDialogModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule,
    MatCardModule,
    MatSelectModule,
    MatProgressSpinnerModule,
    MatSnackBarModule,
    MatDividerModule,
    MatCheckboxModule,
    MatSlideToggleModule
  ],
  templateUrl: './payment-popup.component.html',
  styleUrls: ['./payment-popup.component.scss']
})
export class PaymentPopupComponent implements OnInit {
  paymentForm: FormGroup;
  isProcessing = signal(false);

  // Data from dialog
  studentId: number;
  studentName: string;
  studentRollNumber: string;
  installment: any;
  remainingBalance: number;

  // Calculations
  amountToBeCalculatedRemaining = 0;
  totalPayableAmount = 0;
  paymentMethods = ['cash', 'cheque', 'bank_transfer', 'card', 'online'];

  // Validation
  validationMessages = {
    amountExceedsBalance: 'Payment amount cannot exceed outstanding balance',
    zerosAmount: 'Payment amount must be greater than 0',
    invalidAmount: 'Please enter a valid amount'
  };

  errorMessage = signal<any>(null);

  constructor(
    private fb: FormBuilder,
    private feeService: FeeManagementService,
    private snackBar: MatSnackBar,
    private cdr: ChangeDetectorRef,
    private dialog: MatDialog,
    private receiptPrinter: ReceiptPrinterService,
    public dialogRef: MatDialogRef<PaymentPopupComponent>,
    @Inject(MAT_DIALOG_DATA) public data: PaymentDialogData
  ) {
    this.studentId = data.studentId;
    this.studentName = data.studentName;
    this.studentRollNumber = data.studentRollNumber ?? '';
    this.installment = data.installment;
    this.remainingBalance = data.remainingBalance;

    this.paymentForm = this.fb.group({
      amount: [
        this.remainingBalance,
        [
          Validators.required,
          Validators.min(0.01),
          Validators.max(this.remainingBalance)
        ]
      ],
      paymentMethod: ['cash', Validators.required],
      remarks: [''],
      lateFeeAmount: [0, [Validators.required, Validators.min(0)]],
      discountAmount: [0, [Validators.required, Validators.min(0)]],
      receiptGenerate: [true]
    });
  }

  ngOnInit(): void {
    this.amountToBeCalculatedRemaining = this.remainingBalance;
    this.calculateTotalAmount();

    // Subscribe to amount changes
    this.paymentForm.get('amount')?.valueChanges.subscribe(() => {
      this.updateValidation();
      this.calculateTotalAmount();
      this.cdr.markForCheck();
    });

    // Subscribe to late fee changes
    this.paymentForm.get('lateFeeAmount')?.valueChanges.subscribe(() => {
      this.calculateTotalAmount();
      this.cdr.markForCheck();
    });

    // Subscribe to discount changes
    this.paymentForm.get('discountAmount')?.valueChanges.subscribe(() => {
      this.calculateTotalAmount();
      this.cdr.markForCheck();
    });
  }

  updateValidation(): void {
    const amount = this.paymentForm.get('amount')?.value;
    this.errorMessage.set(null);

    if (!amount) return;

    if (amount <= 0) {
      this.errorMessage.set(this.validationMessages.zerosAmount);
    } else if (amount > this.remainingBalance) {
      this.errorMessage.set(this.validationMessages.amountExceedsBalance);
    }
  }

  calculateTotalAmount(): void {
    const amount = parseFloat(this.paymentForm.get('amount')?.value || 0);
    const lateFee = parseFloat(this.paymentForm.get('lateFeeAmount')?.value || 0);
    const discount = parseFloat(this.paymentForm.get('discountAmount')?.value || 0);

    this.totalPayableAmount = amount + lateFee - discount;
    this.amountToBeCalculatedRemaining = this.remainingBalance - amount;
  }

  getPaymentMethodLabel(method: string): string {
    const labels: { [key: string]: string } = {
      cash: '💵 Cash',
      cheque: '🏦 Cheque',
      bank_transfer: '🔄 Bank Transfer',
      card: '💳 Card',
      online: '🌐 Online Payment'
    };
    return labels[method] || method;
  }

  /** Reference-grid tile metadata: icon + primary label + caption per method. */
  methodTile(method: string): { icon: string; label: string; caption: string } {
    const map: { [key: string]: { icon: string; label: string; caption: string } } = {
      card:          { icon: 'credit_card',   label: 'POS / Card',  caption: 'Swipe or Tap' },
      cash:          { icon: 'payments',      label: 'Cash',        caption: 'Physical Bill' },
      bank_transfer: { icon: 'account_balance', label: 'Bank / UPI', caption: 'Wire / Instant' },
      cheque:        { icon: 'history_edu',   label: 'Cheque',      caption: 'Bank Draft' },
      online:        { icon: 'language',      label: 'Online',      caption: 'Gateway / Portal' }
    };
    return map[method] ?? { icon: 'payments', label: method, caption: 'Method' };
  }

  /** Reference numbered-step heading data for the section markers. */
  readonly steps = [
    { n: 1, title: 'Amount & Fee Items' },
    { n: 2, title: 'Payment Details' },
    { n: 3, title: 'Ledger Reconciliation' }
  ];

  /** “Custom” pill: move focus to the amount input for typing. */
  focusAmount(): void {
    setTimeout(() => document.getElementById('pay-amount')?.focus(), 0);
  }

  /**
   * Guard rail: an explicit confirmation step before money moves.
   * Prevents accidental payments from a single tap on "Pay Now".
   */
  async processPayment(): Promise<void> {
    if (!this.paymentForm.valid || this.errorMessage()) {
      this.snackBar.open('Please fill all required fields correctly', 'Close', { duration: 3000 });
      return;
    }

    const confirmData: ConfirmDialogData = {
      title: 'Confirm Payment',
      message: `Collect ₹${this.totalPayableAmount.toFixed(2)} from ${this.studentName} for installment "${this.installment?.name}"?`,
      confirmText: 'Confirm Payment',
      cancelText: 'Back',
      icon: 'payments',
      severity: 'info'
    };

    const confirmed = await new Promise<boolean>(resolve => {
      this.dialog.open(ConfirmDialogComponent, {
        data: confirmData,
        autoFocus: false,
        restoreFocus: true
      }).afterClosed().subscribe(resolve);
    });

    if (!confirmed) return;

    this.doProcessPayment();
  }

  private doProcessPayment(): void {
    this.isProcessing.set(true);
    this.cdr.markForCheck();

    const paymentData = {
      studentId: this.studentId,
      feeInstallmentId: this.installment.id,
      amountPaid: parseFloat(this.paymentForm.get('amount')?.value || 0),
      lateFeeAmount: parseFloat(this.paymentForm.get('lateFeeAmount')?.value || 0),
      discountAmount: parseFloat(this.paymentForm.get('discountAmount')?.value || 0),
      paymentMethod: this.paymentForm.get('paymentMethod')?.value,
      remarks: this.paymentForm.get('remarks')?.value || '',
      transactionId: this.generateTransactionId()
    };

    this.feeService.processPayment(paymentData).subscribe({
      next: (response) => {
        this.snackBar.open('Payment processed successfully!', 'Close', { duration: 3000 });

        // Print the invoice-style receipt when "receiptGenerate" is ticked.
        if (this.paymentForm.get('receiptGenerate')?.value) {
          this.printReceiptFromResponse(response);
        }

        // Close dialog with success response
        this.dialogRef.close({ success: true, data: response });
        this.isProcessing.set(false);
        this.cdr.markForCheck();
      },
      error: (error) => {
        console.error('Payment error:', error);
        this.snackBar.open('Failed to process payment', 'Close', { duration: 3000 });
        this.isProcessing.set(false);
        this.cdr.markForCheck();
      }
    });
  }

  generateTransactionId(): string {
    return `TXN-${Date.now()}-${Math.random().toString(36).substr(2, 9).toUpperCase()}`;
  }

  /** Receipt shows name + roll number (never the internal student ID). */
  private formatStudentName(name: string): string {
    return this.studentRollNumber ? `${name} (Roll: ${this.studentRollNumber})` : name;
  }

  /**
   * Builds the invoice-style receipt from the process-payment response
   * (shape varies: ApiResponse<FeePayment>, raw FeePayment, or plain object).
   */
  private printReceiptFromResponse(response: any): void {
    try {
      const p = response?.data ?? response ?? {};
      const amount = Number(p.amountPaid ?? this.totalPayableAmount) || 0;
      const items = [{
        description: `Fee Payment - ${this.installment?.name ?? 'School Fee'}`,
        unitPrice: amount,
        total: amount
      }];
      // Late fee / discount lines are itemized when present.
      const lateFee = Number(p.lateFeeAmount ?? (parseFloat(this.paymentForm.get('lateFeeAmount')?.value || '0') || 0));
      const discount = Number(p.discountAmount ?? (parseFloat(this.paymentForm.get('discountAmount')?.value || '0') || 0));
      if (lateFee > 0) items.push({ description: 'Late Fee', unitPrice: lateFee, total: lateFee });
      if (discount > 0) items.push({ description: 'Discount', unitPrice: -discount, total: -discount });

      this.receiptPrinter.print({
        title: 'School Fee',
        receiptNo: p.receiptNumber ?? p.receiptNo ?? '',
        studentName: this.formatStudentName(p.studentName ?? this.studentName),
        date: p.paymentDate ? new Date(p.paymentDate).toISOString().slice(0, 10) : new Date().toISOString().slice(0, 10),
        items,
        paymentMethod: ReceiptPrinterService.humanizeMethod(p.paymentMethod ?? this.paymentForm.get('paymentMethod')?.value),
        ref: this.paymentForm.get('transactionId')?.value || p.transactionId || '',
        infoLines: (this.paymentForm.get('remarks')?.value ? [String(this.paymentForm.get('remarks')?.value)] : [])
      });
    } catch (e) {
      console.warn('Failed to build receipt', e);
    }
  }

  onCancel(): void {
    this.dialogRef.close({ success: false });
  }

  payFullAmount(): void {
    this.paymentForm.patchValue({ amount: this.remainingBalance });
    this.calculateTotalAmount();
    this.cdr.markForCheck();
  }

  payHalfAmount(): void {
    const halfAmount = this.remainingBalance / 2;
    this.paymentForm.patchValue({ amount: halfAmount });
    this.calculateTotalAmount();
    this.cdr.markForCheck();
  }

  resetForm(): void {
    this.paymentForm.reset({
      amount: this.remainingBalance,
      paymentMethod: 'cash',
      remarks: '',
      lateFeeAmount: 0,
      discountAmount: 0,
      receiptGenerate: true
    });
    this.errorMessage.set(null);
    this.cdr.markForCheck();
  }
}
