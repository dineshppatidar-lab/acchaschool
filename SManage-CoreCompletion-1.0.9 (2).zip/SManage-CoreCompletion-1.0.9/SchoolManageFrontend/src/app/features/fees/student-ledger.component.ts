import { Component, Inject, Input, OnChanges, OnInit, SimpleChanges, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatTableModule } from '@angular/material/table';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatChipsModule } from '@angular/material/chips';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatDividerModule } from '@angular/material/divider';
import { MAT_DIALOG_DATA, MatDialog, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { DialogUtils } from '../../shared/dialog-utils';

import { FeeManagementService } from '../../shared/services/fee-management.service';
import { FeePageHeaderComponent } from '../../shared/components/fees-module/fee-page-header.component';
import { FeeStateComponent } from '../../shared/components/fees-module/fee-state.component';

export interface LedgerEntry {
  id: number;
  transactionDate: string;
  entryType: 'Debit' | 'Credit';
  amount: number;
  runningBalance: number;
  description: string;
  referenceType: string;
  referenceId?: number;
  remarks?: string;
}

@Component({
  selector: 'app-student-ledger',
  standalone: true,
  imports: [
    CommonModule, ReactiveFormsModule,
    MatCardModule, MatTableModule, MatProgressBarModule, MatProgressSpinnerModule,
    MatIconModule, MatButtonModule, MatChipsModule, MatFormFieldModule,
    MatInputModule, MatSelectModule, MatSnackBarModule, MatTooltipModule,
    MatDatepickerModule, MatNativeDateModule, MatDividerModule, MatDialogModule,
    FeePageHeaderComponent, FeeStateComponent
  ],
  template: `
    <div class="ledger-page compact-screen">
      <app-fee-page-header
        title="Student Financial Ledger">
        <ng-container headerActions *ngIf="studentId">
          <span class="ledger-balance"
                [class.balance-debit]="currentBalance() > 0"
                [class.balance-credit]="currentBalance() <= 0">
            Balance: ₹{{ currentBalance() | number:'1.2-2' }}
          </span>
        </ng-container>
      </app-fee-page-header>

      <div class="ledger-body">
        <div class="fee-filter-bar" [formGroup]="filterForm">
          <div class="ffe-row">
            <mat-form-field appearance="outline" subscriptSizing="dynamic" class="ffe-field">
              <mat-label>Start Date</mat-label>
              <input matInput [matDatepicker]="startPicker" formControlName="startDate">
              <mat-datepicker-toggle matSuffix [for]="startPicker"></mat-datepicker-toggle>
              <mat-datepicker #startPicker></mat-datepicker>
            </mat-form-field>

            <mat-form-field appearance="outline" subscriptSizing="dynamic" class="ffe-field">
              <mat-label>End Date</mat-label>
              <input matInput [matDatepicker]="endPicker" formControlName="endDate">
              <mat-datepicker-toggle matSuffix [for]="endPicker"></mat-datepicker-toggle>
              <mat-datepicker #endPicker></mat-datepicker>
            </mat-form-field>

            <div class="ffe-actions">
              <button mat-button (click)="clearFilter()" [disabled]="loading()">Clear</button>
              <button mat-flat-button color="primary" (click)="loadLedger()" [disabled]="loading()">
                <mat-icon>filter_list</mat-icon> Filter
              </button>
            </div>
          </div>
        </div>

        <div class="refund-summary" *ngIf="studentId">
          <div>
            <strong>Refundable Balance:</strong>
            <span class="refund-amount">₹{{ refundableBalance() | number:'1.2-2' }}</span>
          </div>
          <button mat-stroked-button color="primary" (click)="openRefundDialog()" [disabled]="refundableBalance() <= 0">
            <mat-icon>undo</mat-icon>
            Process Refund
          </button>
        </div>

        <div *ngIf="refunds().length" class="refund-history">
          <h4>Recent Refunds</h4>
          <div class="refund-item" *ngFor="let refund of refunds()">
            <span>{{ refund.refundDate | date:'dd MMM yyyy' }}</span>
            <span>{{ refund.refundReason }}</span>
            <span class="refund-amount">₹{{ refund.refundAmount | number:'1.2-2' }}</span>
          </div>
        </div>

        <mat-progress-bar *ngIf="loading()" mode="indeterminate" class="fee-loading-bar"></mat-progress-bar>

        @if (!loading() && entries().length === 0) {
          <app-fee-state
            kind="empty"
            emptyIcon="receipt_long"
            title="No Ledger Entries"
            message="No ledger entries found for the selected period.">
          </app-fee-state>
        }

        @if (!loading() && entries().length > 0) {
        <!-- ── Phones: reference-level ledger cards (date/type/amount/balance per event) ── -->
        <div class="ledger-cards-mobile">
          @for (e of entries(); track $index) {
            <div class="lc-m" [class.debit]="e.entryType === 'Debit'" [class.credit]="e.entryType === 'Credit'">
              <div class="lc-m-top">
                <mat-chip [class]="e.entryType === 'Debit' ? 'chip-debit' : 'chip-credit'">
                  <mat-icon>{{ e.entryType === 'Debit' ? 'arrow_upward' : 'arrow_downward' }}</mat-icon>
                  {{ e.entryType }}
                </mat-chip>
                <span class="lc-m-amount" [class.debit]="e.entryType === 'Debit'" [class.credit]="e.entryType === 'Credit'">
                  ₹{{ e.amount | number:'1.2-2' }}
                </span>
              </div>
              <div class="lc-m-desc">
                <span class="lc-m-desc-text">{{ e.description }}</span>
                <span class="ref-tag" *ngIf="e.referenceType">{{ e.referenceType }}</span>
              </div>
              <div class="lc-m-foot">
                <span class="lc-m-date">{{ e.transactionDate | date:'dd MMM yyyy, HH:mm' }}</span>
                <span class="lc-m-balance" [class.balance-debit]="e.runningBalance > 0" [class.balance-credit]="e.runningBalance <= 0">
                  Bal ₹{{ e.runningBalance | number:'1.2-2' }}
                </span>
              </div>
            </div>
          }
        </div>

        <div class="fee-table-card ledger-table-desktop">
          <div class="fee-table-scroll">
          <table mat-table [dataSource]="entries()" class="ledger-table">
            <ng-container matColumnDef="date">
              <th mat-header-cell *matHeaderCellDef>Date</th>
              <td mat-cell *matCellDef="let e">{{ e.transactionDate | date:'dd MMM yyyy HH:mm' }}</td>
            </ng-container>

            <ng-container matColumnDef="type">
              <th mat-header-cell *matHeaderCellDef>Type</th>
              <td mat-cell *matCellDef="let e">
                <mat-chip [class]="e.entryType === 'Debit' ? 'chip-debit' : 'chip-credit'">
                  <mat-icon>{{ e.entryType === 'Debit' ? 'arrow_upward' : 'arrow_downward' }}</mat-icon>
                  {{ e.entryType }}
                </mat-chip>
              </td>
            </ng-container>

            <ng-container matColumnDef="description">
              <th mat-header-cell *matHeaderCellDef>Description</th>
              <td mat-cell *matCellDef="let e">
                <span class="description-text">{{ e.description }}</span>
                <span class="ref-tag" *ngIf="e.referenceType">{{ e.referenceType }}</span>
              </td>
            </ng-container>

            <ng-container matColumnDef="debit">
              <th mat-header-cell *matHeaderCellDef class="amount-col">Debit (₹)</th>
              <td mat-cell *matCellDef="let e" class="amount-col debit-col">
                <span *ngIf="e.entryType === 'Debit'">{{ e.amount | number:'1.2-2' }}</span>
              </td>
            </ng-container>

            <ng-container matColumnDef="credit">
              <th mat-header-cell *matHeaderCellDef class="amount-col">Credit (₹)</th>
              <td mat-cell *matCellDef="let e" class="amount-col credit-col">
                <span *ngIf="e.entryType === 'Credit'">{{ e.amount | number:'1.2-2' }}</span>
              </td>
            </ng-container>

            <ng-container matColumnDef="balance">
              <th mat-header-cell *matHeaderCellDef class="amount-col">Balance (₹)</th>
              <td mat-cell *matCellDef="let e" class="amount-col"
                  [class.balance-debit]="e.runningBalance > 0"
                  [class.balance-credit]="e.runningBalance <= 0">
                {{ e.runningBalance | number:'1.2-2' }}
              </td>
            </ng-container>

            <tr mat-header-row *matHeaderRowDef="displayedColumns"></tr>
            <tr mat-row *matRowDef="let row; columns: displayedColumns;" class="ledger-row"
                [class.debit-row]="row.entryType === 'Debit'"
                [class.credit-row]="row.entryType === 'Credit'"></tr>
          </table>
          </div>
        </div>
        }

        <mat-divider class="form-divider"></mat-divider>
        <div class="manual-entry-section">
          <h4><mat-icon>add_circle</mat-icon> Add Manual Entry</h4>
          <form [formGroup]="entryForm" (ngSubmit)="addManualEntry()" class="entry-form">
            <mat-form-field appearance="outline">
              <mat-label>Entry Type</mat-label>
              <mat-select formControlName="entryType" required>
                <mat-option [value]="1">Debit (Fee Charge)</mat-option>
                <mat-option [value]="2">Credit (Payment / Waiver)</mat-option>
              </mat-select>
            </mat-form-field>

            <mat-form-field appearance="outline">
              <mat-label>Amount (₹)</mat-label>
              <input matInput type="number" formControlName="amount" min="0.01" required>
            </mat-form-field>

            <mat-form-field appearance="outline" class="description-field">
              <mat-label>Description</mat-label>
              <input matInput formControlName="description" required>
            </mat-form-field>

            <mat-form-field appearance="outline">
              <mat-label>Reference Type</mat-label>
              <mat-select formControlName="referenceType">
                <mat-option value="FeeInstallment">Fee Installment</mat-option>
                <mat-option value="FeePayment">Fee Payment</mat-option>
                <mat-option value="Scholarship">Scholarship</mat-option>
                <mat-option value="Waiver">Waiver</mat-option>
                <mat-option value="Manual">Manual</mat-option>
              </mat-select>
            </mat-form-field>

            <button mat-raised-button color="accent" type="submit"
                    [disabled]="entryForm.invalid || savingEntry()">
              <mat-icon>save</mat-icon>
              {{ savingEntry() ? 'Saving...' : 'Add Entry' }}
            </button>
          </form>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .ledger-page { padding: var(--space-sm) var(--space-sm) calc(var(--bottom-nav-height) + var(--space-lg)); }
    @media (min-width: 768px) { .ledger-page { padding: var(--space-md) var(--space-lg) var(--space-lg); } }
    .ledger-balance { font-size: var(--font-size-sm); font-weight: 700; }

    /* ── Phones: ledger cards (reference-level); desktop keeps the table ── */
    .ledger-cards-mobile { display: none; }
    @media (max-width: 767px) {
      .ledger-table-desktop { display: none; }
      .ledger-cards-mobile { display: flex; flex-direction: column; gap: 8px; }

      .lc-m {
        background: var(--color-card);
        border: 1px solid var(--color-border);
        border-radius: var(--radius-lg);
        padding: 10px 12px;
        box-shadow: var(--shadow-sm);
      }
      .lc-m-top {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 8px;
      }
      .lc-m-amount {
        font-size: 16px;
        font-weight: 700;
        font-variant-numeric: tabular-nums;
        &.debit { color: var(--md-error); }
        &.credit { color: var(--md-success); }
      }
      .lc-m-desc {
        display: flex;
        align-items: center;
        gap: 6px;
        min-width: 0;
        margin-top: 4px;
      }
      .lc-m-desc-text {
        font-size: 13px;
        color: var(--md-on-surface);
        overflow-wrap: anywhere;
      }
      .lc-m-foot {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 8px;
        margin-top: 6px;
        padding-top: 6px;
        border-top: 1px solid var(--color-border);
      }
      .lc-m-date { font-size: 11px; color: var(--color-text-muted); }
      .lc-m-balance { font-size: 12px; font-weight: 700; font-variant-numeric: tabular-nums; }
    }

    @media (min-width: 768px) { .ledger-cards-mobile { display: none; } }
    .refund-summary { display: flex; justify-content: space-between; align-items: center; gap: 12px; margin-bottom: 16px; padding: 12px 16px; background: var(--md-surface-container-low); border: 1px solid var(--color-border); border-radius: var(--radius-md); }
    .refund-history { margin-bottom: 16px; }
    .refund-item { display: flex; justify-content: space-between; padding: 8px 0; border-bottom: 1px solid var(--color-border); }
    .refund-amount { font-weight: 600; color: var(--md-error); }
    .ledger-table { width: 100%; }
    .amount-col { text-align: right; min-width: 100px; }
    .debit-col { color: var(--md-error); font-weight: 500; }
    .credit-col { color: var(--md-success); font-weight: 500; }
    .balance-debit { color: var(--md-error); font-weight: bold; }
    .balance-credit { color: var(--md-success); font-weight: bold; }
    .debit-row { background: var(--md-error-container); }
    .credit-row { background: var(--md-success-container); }
    .chip-debit { background: var(--md-error-container) !important; color: var(--md-error) !important; }
    .chip-credit { background: var(--md-success-container) !important; color: var(--md-success) !important; }
    .chip-debit mat-icon, .chip-credit mat-icon { font-size: 14px; }
    .description-text { display: block; }
    .ref-tag { font-size: 11px; color: var(--color-text-secondary); background: var(--md-surface-container-high); padding: 2px 6px; border-radius: 8px; margin-left: 4px; }
    .form-divider { margin: 24px 0; }
    .manual-entry-section h4 { display: flex; align-items: center; gap: 6px; margin-bottom: 12px; }
    .entry-form { display: flex; gap: 12px; align-items: flex-start; flex-wrap: wrap; }
    .description-field { flex: 1; min-width: 200px; }
  `]
})
export class StudentLedgerComponent implements OnInit, OnChanges {
  @Input() studentId!: number;

  entries = signal<any[]>([]);
  refunds = signal<any[]>([]);
  refundableBalance = signal(0);
  currentBalance = signal(0);
  loading = signal(false);
  savingEntry = signal(false);
  displayedColumns = ['date', 'type', 'description', 'debit', 'credit', 'balance'];

  filterForm: FormGroup;
  entryForm: FormGroup;

  constructor(
    private feeService: FeeManagementService,
    private fb: FormBuilder,
    private snackBar: MatSnackBar,
    private dialog: MatDialog,
    private dialogUtils: DialogUtils
  ) {
    this.filterForm = this.fb.group({
      startDate: [null],
      endDate: [null]
    });

    this.entryForm = this.fb.group({
      entryType: [1, Validators.required],
      amount: [null, [Validators.required, Validators.min(0.01)]],
      description: ['', Validators.required],
      referenceType: ['Manual']
    });
  }

  ngOnInit(): void {
    if (this.studentId) this.loadLedger();
  }

  openRefundDialog(): void {
    if (!this.studentId) return;

    const dialogRef = this.dialog.open(RefundDialogComponent, {...this.dialogUtils.getMobileConfig(),
      width: '560px',
      data: { studentId: this.studentId }
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.loadLedger();
      }
    });
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['studentId'] && this.studentId) this.loadLedger();
  }

  loadLedger(): void {
    if (!this.studentId) return;
    this.loading.set(true);

    const startDate = this.filterForm.get('startDate')?.value
      ? new Date(this.filterForm.get('startDate')!.value).toISOString() : undefined;
    const endDate = this.filterForm.get('endDate')?.value
      ? new Date(this.filterForm.get('endDate')!.value).toISOString() : undefined;

    this.feeService.getStudentLedger(this.studentId, startDate, endDate).subscribe({
      next: (res) => {
        const data = res.data || res;
        this.entries.set(data.entries || []);
        this.currentBalance.set(data.currentBalance ?? 0);
        this.loading.set(false);
      },
      error: () => {
        this.snackBar.open('Failed to load ledger', 'Close', { duration: 3000 });
        this.loading.set(false);
      }
    });

    this.feeService.getRefundableBalance(this.studentId).subscribe({
      next: (res) => {
        const data = res.data || res;
        this.refundableBalance.set(data.remainingRefundable ?? 0);
      },
      error: () => {
        this.snackBar.open('Failed to load refund balance', 'Close', { duration: 3000 });
      }
    });

    this.feeService.getRefundHistory(this.studentId).subscribe({
      next: (res) => {
        const data = res.data || res;
        this.refunds.set(Array.isArray(data) ? data : (data || []));
      },
      error: () => {
        this.snackBar.open('Failed to load refund history', 'Close', { duration: 3000 });
      }
    });
  }

  clearFilter(): void {
    this.filterForm.reset();
    this.loadLedger();
  }

  addManualEntry(): void {
    if (this.entryForm.invalid || !this.studentId) return;
    this.savingEntry.set(true);

    const val = this.entryForm.value;
    this.feeService.addLedgerEntry(this.studentId, {
      entryType: val.entryType,
      amount: val.amount,
      description: val.description,
      referenceType: val.referenceType
    }).subscribe({
      next: () => {
        this.snackBar.open('Ledger entry added', 'Close', { duration: 3000 });
        this.entryForm.reset({ entryType: 1, referenceType: 'Manual' });
        this.savingEntry.set(false);
        this.loadLedger();
      },
      error: () => {
        this.snackBar.open('Failed to add ledger entry', 'Close', { duration: 3000 });
        this.savingEntry.set(false);
      }
    });
  }
}

@Component({
  selector: 'app-refund-dialog',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, MatDialogModule, MatFormFieldModule, MatInputModule, MatButtonModule, MatSelectModule, MatIconModule],
  template: `
    <h2 mat-dialog-title>Process Refund</h2>
    <div mat-dialog-content>
      <form [formGroup]="refundForm" class="refund-form">
        <mat-form-field appearance="outline">
          <mat-label>Payment ID</mat-label>
          <input matInput type="number" formControlName="paymentId" required>
        </mat-form-field>

        <mat-form-field appearance="outline">
          <mat-label>Refund Amount</mat-label>
          <input matInput type="number" formControlName="refundAmount" min="0.01" required>
        </mat-form-field>

        <mat-form-field appearance="outline">
          <mat-label>Refund Mode</mat-label>
          <mat-select formControlName="refundMode" required>
            <mat-option [value]="1">Cash</mat-option>
            <mat-option [value]="2">Cheque</mat-option>
            <mat-option [value]="5">Online Transfer</mat-option>
            <mat-option [value]="6">UPI</mat-option>
            <mat-option [value]="8">Other</mat-option>
          </mat-select>
        </mat-form-field>

        <mat-form-field appearance="outline">
          <mat-label>Reason</mat-label>
          <input matInput formControlName="refundReason" required>
        </mat-form-field>

        <mat-form-field appearance="outline">
          <mat-label>Reference Number</mat-label>
          <input matInput formControlName="referenceNumber">
        </mat-form-field>

        <mat-form-field appearance="outline">
          <mat-label>Remarks</mat-label>
          <textarea matInput formControlName="remarks"></textarea>
        </mat-form-field>
      </form>
    </div>
    <div mat-dialog-actions align="end">
      <button mat-button (click)="cancel()">Cancel</button>
      <button mat-raised-button color="primary" (click)="submit()" [disabled]="refundForm.invalid">Submit</button>
    </div>
  `,
  styles: [`.refund-form{display:flex;flex-direction:column;gap:12px;}`]
})
export class RefundDialogComponent {
  refundForm: FormGroup;

  constructor(
    private fb: FormBuilder,
    private feeService: FeeManagementService,
    private snackBar: MatSnackBar,
    private dialogRef: MatDialogRef<RefundDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: { studentId: number }
  ) {
    this.refundForm = this.fb.group({
      paymentId: [null as number | null, [Validators.required, Validators.min(1)]],
      refundAmount: [null as number | null, [Validators.required, Validators.min(0.01)]],
      refundMode: [1, Validators.required],
      refundReason: ['', Validators.required],
      referenceNumber: [''],
      remarks: ['']
    });
  }

  submit(): void {
    if (this.refundForm.invalid) return;
    const value = this.refundForm.getRawValue();
    this.feeService.createRefund({
      paymentId: Number(value.paymentId),
      studentId: this.data.studentId,
      refundAmount: Number(value.refundAmount),
      refundMode: Number(value.refundMode),
      refundReason: String(value.refundReason || ''),
      referenceNumber: String(value.referenceNumber || ''),
      remarks: String(value.remarks || '')
    }).subscribe({
      next: () => {
        this.snackBar.open('Refund created', 'Close', { duration: 3000 });
        this.dialogRef.close(true);
      },
      error: () => {
        this.snackBar.open('Failed to create refund', 'Close', { duration: 3000 });
      }
    });
  }

  cancel(): void {
    this.dialogRef.close(false);
  }
}
