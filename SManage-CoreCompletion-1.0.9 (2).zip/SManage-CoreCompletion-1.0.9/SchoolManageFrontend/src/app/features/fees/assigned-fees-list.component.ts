import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule, PageEvent } from '@angular/material/paginator';
import { MatSortModule } from '@angular/material/sort';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatChipsModule } from '@angular/material/chips';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatDividerModule } from '@angular/material/divider';
import { MatMenuModule } from '@angular/material/menu';
import { MatSelectModule } from '@angular/material/select';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatDialog } from '@angular/material/dialog';
import { DialogUtils } from '../../shared/dialog-utils';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormGroup, FormControl } from '@angular/forms';
import { Observable, of } from 'rxjs';
import { map, startWith, debounceTime } from 'rxjs/operators';
import { StudentManagementService } from '../../shared/services/student-management.service';
import { FeeManagementService } from '../../shared/services/fee-management.service';
import { StudentFullDetailsDto } from '../../shared/models/student-full-details-dto';
import { MatSnackBar } from '@angular/material/snack-bar';
import { PaymentPopupComponent } from './payment-popup.component';

export interface AssignedFeeStructure {
  id: number;
  studentId: number;
  feeStructureId: number;
  feeStructureName: string;
  className: string;
  totalAmount: number;
  annualFee: number;
  registrationFee: number;
  examinationFee: number;
  libraryFee: number;
  computerFee: number;
  laboratoryFee: number;
  sportsFee: number;
  miscellaneousFee: number;
  isActive: boolean;
  assignedDate: Date;
  remarks?: string;
}

@Component({
  selector: 'app-assigned-fees-list',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    CommonModule,
    MatCardModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule,
    MatProgressSpinnerModule,
    MatTooltipModule,
    MatChipsModule,
    MatExpansionModule,
    MatDividerModule,
    MatMenuModule,
    MatSelectModule,
    MatAutocompleteModule,
    FormsModule,
    ReactiveFormsModule
  ],
  templateUrl: './assigned-fees-list.component.html',
  styleUrls: ['./assigned-fees-list.component.scss']
})
export class AssignedFeesListComponent implements OnInit {
  // Data
  students = signal<any[]>([]);
  selectedStudentId: number | null = null;
  assignedFees = signal<any[]>([]);

  // Autocomplete
  studentSearchControl = new FormControl('');
  filteredStudents$!: Observable<StudentFullDetailsDto[]>;

  // UI State
  isLoadingStudents = signal(false);
  isLoadingFees = signal(false);
  isProcessingPayment = false;
  searchForm: FormGroup;

  // Table
  displayedColumns: string[] = [
    'studentName',
    'rollNumber',
    'className',
    'feeStructureName',
    'totalAmount',
    'status',
    'assignedDate',
    'actions'
  ];

  // Pagination
  pageSize = 10;
  pageIndex = 0;
  totalRecords = signal(0);

  // Outstanding Fees
  outstandingFeesMap: Map<number, any> = new Map();

  constructor(
    private studentService: StudentManagementService,
    private feeManagementService: FeeManagementService,
    private fb: FormBuilder,
    private snackBar: MatSnackBar,
    private cdr: ChangeDetectorRef,
    private dialog: MatDialog,
    private dialogUtils: DialogUtils
  ) {
    this.searchForm = this.fb.group({
      searchText: [''],
      classId: [null],
      status: ['all']
    });
  }

  ngOnInit(): void {
    this.loadStudents();
    this.filteredStudents$ = this.studentSearchControl.valueChanges.pipe(
      startWith(''),
      debounceTime(300),
      map(val => {
        const searchStr = (typeof val === 'string' ? val : '').toLowerCase().trim();
        // Require typed text (same behavior as the other fee tabs / dashboard):
        // don't dump the entire student list into the dropdown on focus.
        if (searchStr.length < 2) return [];
        return this.students().filter(s =>
          `${s.firstName} ${s.lastName}`.toLowerCase().includes(searchStr) ||
          (s.rollNumber || '').toLowerCase().includes(searchStr) ||
          (s.className || '').toLowerCase().includes(searchStr)
        );
      })
    );
  }

  /** 'No students found' only once the user actually typed a search (≥2 chars). */
  showNoStudents(query: any): boolean {
    return typeof query === 'string' && query.trim().length >= 2;
  }

  displayStudentName(student: StudentFullDetailsDto): string {
    if (!student) return '';
    const roll = student.rollNumber ? ` (${student.rollNumber})` : '';
    return `${student.firstName} ${student.lastName}${roll}`;
  }

  onStudentSelected(event: any): void {
    const student = event.option.value as StudentFullDetailsDto;
    if (student) {
      this.selectedStudentId = student.id;
      this.onStudentSelectedById();
    }
  }

  private loadStudents(): void {
    this.isLoadingStudents.set(true);
    this.cdr.markForCheck();
    this.studentService.getAllStudentFullDetails('').subscribe({
      next: (response: any) => {
        this.students.set(Array.isArray(response) ? response : []);
        this.isLoadingStudents.set(false);
        // Trigger re-filter after students load
        this.studentSearchControl.setValue(this.studentSearchControl.value || '');
        this.cdr.markForCheck();
      },
      error: () => {
        this.snackBar.open('Failed to load students', 'Close', { duration: 5000 });
        this.isLoadingStudents.set(false);
        this.cdr.markForCheck();
      }
    });
  }

  private onStudentSelectedById(): void {
    if (!this.selectedStudentId) {
      this.assignedFees.set([]);
      this.cdr.markForCheck();
      return;
    }
    const studentId = this.selectedStudentId as number;
    this.isLoadingFees.set(true);
    this.cdr.markForCheck();

    this.feeManagementService.getOutstandingFees(studentId).subscribe({
      next: (response: any) => {
        const data = response.data || response;
        if (data && data.hasAssignedFees) {
          const totalAmount = data.totalFees || data.TotalFees || 0;
          const student = this.getSelectedStudent();
          const assignedFee: AssignedFeeStructure = {
            id: studentId,
            studentId: studentId,
            feeStructureId: 0,
            feeStructureName: 'Current Fee Structure',
            className: this.getClassName(student?.classId || 0),
            totalAmount: totalAmount,
            annualFee: 0, registrationFee: 0, examinationFee: 0,
            libraryFee: 0, computerFee: 0, laboratoryFee: 0, sportsFee: 0, miscellaneousFee: 0,
            isActive: true,
            assignedDate: new Date(),
            remarks: `Paid: ₹${data.paidAmount || data.PaidAmount || 0}, Outstanding: ₹${data.outstandingAmount || data.OutstandingAmount || 0}`
          };
          this.assignedFees.set([assignedFee]);
          this.totalRecords.set(1);
          this.outstandingFeesMap.set(studentId, data);
        } else {
          this.assignedFees.set([]);
          this.totalRecords.set(0);
          this.snackBar.open('No fee structure assigned to this student', 'Close', { duration: 3000 });
        }
        this.isLoadingFees.set(false);
        this.cdr.markForCheck();
      },
      error: () => {
        this.isLoadingFees.set(false);
        this.cdr.markForCheck();
      }
    });
  }

  loadAllAssignedFees(): void {
    this.isLoadingFees.set(true);
    this.cdr.markForCheck();
    const studentIds = this.students().map(s => s.id).filter(id => id !== null && id !== undefined) as number[];
    if (studentIds.length === 0) { this.assignedFees.set([]); this.isLoadingFees.set(false); this.cdr.markForCheck(); return; }

    let completedRequests = 0;
    const allAssignedFees: AssignedFeeStructure[] = [];
    studentIds.forEach(studentId => {
      this.feeManagementService.getOutstandingFees(studentId).subscribe({
        next: (response: any) => {
          const data = response.data || response;
          if (data && data.hasAssignedFees) {
            const student = this.students().find(s => s.id === studentId);
            allAssignedFees.push({
              id: studentId, studentId: studentId, feeStructureId: 0,
              feeStructureName: 'Assigned Fee Structure',
              className: this.getClassName(student?.classId || 0),
              totalAmount: data.totalFees || data.TotalFees || 0,
              annualFee: 0, registrationFee: 0, examinationFee: 0,
              libraryFee: 0, computerFee: 0, laboratoryFee: 0, sportsFee: 0, miscellaneousFee: 0,
              isActive: data.outstandingAmount > 0 || data.OutstandingAmount > 0,
              assignedDate: new Date(),
              remarks: `Paid: ₹${data.paidAmount || data.PaidAmount || 0}, Outstanding: ₹${data.outstandingAmount || data.OutstandingAmount || 0}`
            });
          }
          completedRequests++;
          if (completedRequests === studentIds.length) {
            this.assignedFees.set(allAssignedFees);
            this.totalRecords.set(allAssignedFees.length);
            this.isLoadingFees.set(false);
            this.cdr.markForCheck();
          }
        },
        error: () => { completedRequests++; if (completedRequests === studentIds.length) { this.isLoadingFees.set(false); this.cdr.markForCheck(); } }
      });
    });
  }

  getSelectedStudent(): StudentFullDetailsDto | undefined {
    return this.students().find(s => s.id === this.selectedStudentId);
  }

  getStudentById(studentId: number): StudentFullDetailsDto | undefined {
    return this.students().find(s => s.id === studentId);
  }

  getStudentNameDisplay(studentId: number): string {
    const student = this.getStudentById(studentId);
    return student ? `${student.firstName} ${student.lastName}` : 'Unknown Student';
  }

  getStudentRollNumber(studentId: number): string {
    const student = this.getStudentById(studentId);
    return student?.rollNumber || 'N/A';
  }

  getClassName(classId: number): string {
    const student = this.students().find(s => s.classId === classId);
    return student?.className || (classId > 0 ? `Class ${classId}` : 'N/A');
  }

  getOutstandingFeesDetail(studentId: number): any {
    return this.outstandingFeesMap.get(studentId);
  }

  onPageChange(event: PageEvent): void {
    this.pageIndex = event.pageIndex;
    this.pageSize = event.pageSize;
    this.cdr.markForCheck();
  }

  exportToCSV(): void {
    if (this.assignedFees().length === 0) { this.snackBar.open('No data to export', 'Close', { duration: 3000 }); return; }
    const headers = ['Student Name', 'Roll Number', 'Class', 'Fee Structure', 'Total Amount', 'Status', 'Assigned Date'];
    const rows = this.assignedFees().map(fee => {
      const student = this.students().find(s => s.id === fee.studentId);
      return [`${student?.firstName} ${student?.lastName}`, student?.rollNumber || 'N/A', fee.className, fee.feeStructureName, `₹${fee.totalAmount.toFixed(2)}`, fee.isActive ? 'Active' : 'Inactive', new Date(fee.assignedDate).toLocaleDateString()];
    });
    const csvContent = [headers.join(','), ...rows.map(row => row.map(cell => `"${cell}"`).join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `assigned-fees-${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    this.snackBar.open('Fees exported successfully', 'Close', { duration: 3000 });
  }

  clearFilters(): void {
    this.selectedStudentId = null;
    this.assignedFees.set([]);
    this.studentSearchControl.setValue('');
    this.searchForm.reset();
    this.pageIndex = 0;
    this.cdr.markForCheck();
  }

  payNowInstallment(installment: any): void {
    if (!this.selectedStudentId) { this.snackBar.open('Please select a student first', 'Close', { duration: 3000 }); return; }
    const student = this.getSelectedStudent();
    if (!student) { this.snackBar.open('Student details not found', 'Close', { duration: 3000 }); return; }
    const feesDetail = this.getOutstandingFeesDetail(this.selectedStudentId);
    if (!feesDetail) { this.snackBar.open('Fee details not found', 'Close', { duration: 3000 }); return; }
    const dialogRef = this.dialog.open(PaymentPopupComponent, {
      ...this.dialogUtils.getMobileConfig(),
      disableClose: false,
      data: { studentId: this.selectedStudentId, installment: installment, remainingBalance: feesDetail.outstandingAmount || 0, studentName: `${student.firstName} ${student.lastName}`, studentRollNumber: student.rollNumber }
    });
    dialogRef.afterClosed().subscribe((result: any) => {
      if (result && result.success) { this.snackBar.open('Payment processed successfully!', 'Close', { duration: 3000 }); this.onStudentSelectedById(); }
      this.cdr.markForCheck();
    });
  }
}
