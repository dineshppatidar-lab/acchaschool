import { Component, OnInit, AfterViewInit, ViewChild, inject, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatTableModule, MatTableDataSource } from '@angular/material/table';
import { MatPaginatorModule, MatPaginator } from '@angular/material/paginator';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatTooltipModule } from '@angular/material/tooltip';
import { FormsModule } from '@angular/forms';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment';
import { BackButtonComponent } from '../../shared/components/back-button.component';
import { FeePageHeaderComponent } from '../../shared/components/fees-module/fee-page-header.component';
import { FeeKpiCardComponent } from '../../shared/components/fees-module/fee-kpi-card.component';

interface CollectionReport {
  fromDate: string;
  toDate: string;
  totalCollected: number;
  totalLateFees: number;
  totalDiscounts: number;
  transactionCount: number;
  averageTransaction: number;
  byDay: { date: string; amount: number; count: number }[];
  byMethod: { method: string; amount: number; count: number }[];
  byClass: { className: string; amount: number; count: number }[];
  byFeeType: { feeType: string; amount: number; count: number }[];
  recentTransactions: {
    receiptNumber: string;
    paymentDate: string;
    studentName: string;
    className?: string;
    feeType?: string;
    amount: number;
    method: string;
    transactionId: string;
  }[];
}

@Component({
  selector: 'app-fee-reports',
  standalone: true,
  imports: [
    CommonModule, MatCardModule, MatIconModule, MatButtonModule, MatFormFieldModule,
    MatInputModule, MatTableModule, MatPaginatorModule, MatProgressSpinnerModule, MatSnackBarModule,
    MatTooltipModule, FormsModule, MatDatepickerModule, MatNativeDateModule,
    FeePageHeaderComponent,
    FeeKpiCardComponent
  ],
  templateUrl: './fee-reports.component.html',
  styleUrls: ['./fee-reports.component.scss']
})
export class FeeReportsComponent implements OnInit, AfterViewInit {
  private http = inject(HttpClient);
  private snack = inject(MatSnackBar);

  @ViewChild('recentPaginator', { static: false }) recentPaginator!: MatPaginator;

  loading = signal(false);
  report = signal<CollectionReport | null>(null);
  maxDayAmount = computed(() => Math.max(1, ...(this.report()?.byDay ?? []).map(d => d.amount)));

  // filters
  fromDate: string = new Date(Date.now() - 30 * 86400000).toISOString().slice(0, 10);
  toDate: string = new Date().toISOString().slice(0, 10);

  recentSource = new MatTableDataSource<CollectionReport['recentTransactions'][0]>([]);
  recentColumns = ['receiptNumber', 'paymentDate', 'studentName', 'className', 'feeType', 'method', 'amount'];
  methodColumns = ['method', 'count', 'amount'];
  classColumns = ['className', 'count', 'amount'];
  feeTypeColumns = ['feeType', 'count', 'amount'];

  ngOnInit(): void {
    this.loadReport();
  }

  ngAfterViewInit(): void {
    // Attach once the paginator exists; re-attaching on data reload is unnecessary
    // because assigning recentSource.data keeps the paginator wired.
    if (this.recentPaginator) {
      this.recentSource.paginator = this.recentPaginator;
    }
  }

  /** Quick-range presets: today / last 7 days / last 30 days. */
  applyRange(range: 'today' | '7d' | '30d'): void {
    const today = new Date();
    const fmt = (d: Date) => d.toISOString().slice(0, 10);
    this.toDate = fmt(today);
    if (range === 'today') {
      this.fromDate = this.toDate;
    } else {
      const days = range === '7d' ? 7 : 30;
      this.fromDate = fmt(new Date(Date.now() - days * 86400000));
    }
    this.loadReport();
  }

  loadReport(): void {
    this.loading.set(true);
    const params = `fromDate=${this.fromDate}&toDate=${this.toDate}`;
    this.http.get<any>(`${environment.apiUrl}/api/fees/reports/collection?${params}`).subscribe({
      next: (resp) => {
        const data = (resp?.data ?? resp) as CollectionReport;
        this.report.set(data);
        this.recentSource.data = data.recentTransactions ?? [];
        this.loading.set(false);
        // The paginator renders inside *ngIf="!loading() && report()", so it only
        // exists after the spinner goes away — attach on the next tick.
        setTimeout(() => {
          if (this.recentPaginator) {
            this.recentSource.paginator = this.recentPaginator;
            this.recentPaginator.firstPage();
          }
        });
      },
      error: () => {
        this.loading.set(false);
        this.snack.open('Failed to load fee report', 'Dismiss', { duration: 4000 });
      }
    });
  }

  exportCsv(): void {
    const r = this.report();
    if (!r) return;
    const rows = [
      ['Receipt #', 'Date', 'Student', 'Class', 'Fee Type', 'Method', 'Amount'],
      ...r.recentTransactions.map(t => [
        t.receiptNumber, new Date(t.paymentDate).toLocaleDateString(), t.studentName,
        t.className ?? '', t.feeType ?? '', t.method, String(t.amount)
      ])
    ];
    const csv = rows.map(row => row.map(c => `"${String(c).replace(/"/g, '""')}"`).join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `fee-collection-report_${this.fromDate}_to_${this.toDate}.csv`;
    a.click();
    URL.revokeObjectURL(a.href);
  }

  formatMethod(method: string): string {
    // PaymentMethodType enum-ish values → friendly label
    return method.replace(/([a-z])([A-Z])/g, '$1 $2');
  }

  dayBarWidth(amount: number): string {
    return `${Math.round((amount / this.maxDayAmount()) * 100)}%`;
  }
}
