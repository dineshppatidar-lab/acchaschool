import { ChangeDetectionStrategy, ChangeDetectorRef, Component, Inject, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators, FormControl, FormsModule } from '@angular/forms';
import { MatDialogModule, MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatCardModule } from '@angular/material/card';
import { MatDividerModule } from '@angular/material/divider';
import { MatIconModule } from '@angular/material/icon';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { ApiService } from '../../services/api.service';
import { AcademicYear } from '../../shared/models/academic.models';
import { AcademicYearContextService } from '../../shared/services/academic-year-context.service';
import { debounceTime, finalize, switchMap, catchError, takeUntil } from 'rxjs/operators';
import { of, Subject } from 'rxjs';
import { FeeManagementService } from '../../shared/services/fee-management.service';

interface DialogData {
  studentId?: number;
  studentName?: string;
  studentRollNumber?: string;
  academicYearId?: number;
}

@Component({
  selector: 'app-student-discount-dialog',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatDialogModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatButtonModule,
    MatProgressSpinnerModule,
    MatCardModule,
    MatDividerModule,
    MatIconModule,
    MatSnackBarModule,
    MatAutocompleteModule
  ],
  template: `
    <h2 mat-dialog-title>
      <mat-icon>add_circle</mat-icon>
      Apply Student Discount
    </h2>

    <mat-dialog-content class="discount-dialog-content">
      <form [formGroup]="discountForm" class="discount-form">
        <!-- Student Info (If pre-selected) -->
        <div *ngIf="data.studentId" class="student-info-banner">
          <p>Applying discount for: <strong>{{ data.studentName }}</strong> <span *ngIf="data.studentRollNumber">(Roll: {{ data.studentRollNumber }})</span></p>
        </div>

        <!-- Student Search (If not pre-selected) -->
        <mat-form-field *ngIf="!data.studentId" appearance="outline" class="full-width">
          <mat-label>Search Student</mat-label>
          <input type="text"
                 placeholder="Type student name or roll number"
                 matInput
                 [formControl]="studentSearchControl"
                 [matAutocomplete]="auto">
          <mat-autocomplete #auto="matAutocomplete" [displayWith]="displayStudent" (optionSelected)="onStudentSelected($event)">
            <mat-option *ngIf="isSearching()" class="is-loading">
              <mat-spinner diameter="20"></mat-spinner>
            </mat-option>
            <mat-option *ngFor="let student of filteredStudents()" [value]="student">
              <span>{{ student.displayName }}</span>
              <small style="margin-left: 8px; color: var(--color-text-secondary);">({{ student.className }})</small>
            </mat-option>
          </mat-autocomplete>
          <mat-error *ngIf="discountForm.get('studentId')?.hasError('required')">Student selection is required</mat-error>
        </mat-form-field>

        <div class="form-row">
          <mat-form-field appearance="outline" class="half-width">
            <mat-label>Academic Year</mat-label>
            <mat-select formControlName="academicYearId">
              <mat-option *ngFor="let year of academicYears()" [value]="year.id">
                {{ year.name }}
              </mat-option>
            </mat-select>
          </mat-form-field>

          <mat-form-field appearance="outline" class="half-width">
            <mat-label>Discount Type</mat-label>
            <mat-select formControlName="discountType">
              <mat-option value="percentage">Percentage (%)</mat-option>
              <mat-option value="fixed">Fixed Amount (₹)</mat-option>
            </mat-select>
          </mat-form-field>
        </div>

        <div class="form-row">
          <mat-form-field appearance="outline" class="half-width">
            <mat-label>Discount Value</mat-label>
            <input matInput type="number" formControlName="discountValue" placeholder="0">
            <mat-error>Value is required and must be greater than 0</mat-error>
          </mat-form-field>

          <mat-form-field appearance="outline" class="half-width">
            <mat-label>Applied From</mat-label>
            <input matInput type="date" formControlName="appliedFrom">
          </mat-form-field>
        </div>

        <div class="form-row">
          <mat-form-field appearance="outline" class="half-width">
            <mat-label>Applied To</mat-label>
            <input matInput type="date" formControlName="appliedTo">
          </mat-form-field>

          <mat-form-field appearance="outline" class="half-width">
            <mat-label>Reason for Discount</mat-label>
            <input matInput formControlName="reason" placeholder="Enter reason">
            <mat-error>Reason is required</mat-error>
          </mat-form-field>
        </div>
      </form>

      <div *ngIf="errorMessage()" class="error-message">
        <mat-icon>error</mat-icon>
        <span>{{ errorMessage() }}</span>
      </div>
    </mat-dialog-content>

    <mat-dialog-actions align="end">
      <button mat-button (click)="onCancel()" [disabled]="isSubmitting()">Cancel</button>
      <button mat-raised-button color="primary" (click)="onSubmit()" [disabled]="!discountForm.valid || isSubmitting()">
        <mat-spinner *ngIf="isSubmitting()" diameter="20" class="inline-spinner"></mat-spinner>
        <mat-icon *ngIf="!isSubmitting()">check_circle</mat-icon>
        {{ isSubmitting() ? 'Applying...' : 'Apply Discount' }}
      </button>
    </mat-dialog-actions>
  `,
  styles: [`
    .discount-dialog-content {
      padding: 20px 0;
    }
    .full-width {
      width: 100%;
      margin-bottom: 15px;
    }
    .form-row {
      display: flex;
      gap: 15px;
      margin-bottom: 15px;
    }
    .half-width {
      flex: 1;
    }
    .student-info-banner {
      background-color: var(--md-primary-container);
      padding: 10px 15px;
      border-radius: 4px;
      margin-bottom: 20px;
      border-left: 4px solid var(--md-primary-light);
    }
    .error-message {
      color: var(--md-error);
      display: flex;
      align-items: center;
      gap: 8px;
      margin-top: 15px;
    }
    .inline-spinner {
      margin-right: 8px;
    }
  `]
})
export class StudentDiscountDialogComponent implements OnInit {
  discountForm: FormGroup;
  studentSearchControl = new FormControl('');
  academicYears = signal<any[]>([]);
  filteredStudents = signal<any[]>([]);
  isSearching = signal(false);
  isSubmitting = signal(false);
  errorMessage = signal('');
  private destroy$ = new Subject<void>();

  constructor(
    private fb: FormBuilder,
    private apiService: ApiService,
    private feeService: FeeManagementService,
    private yearContext: AcademicYearContextService,
    private snackBar: MatSnackBar,
    private cdr: ChangeDetectorRef,
    public dialogRef: MatDialogRef<StudentDiscountDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData
  ) {
    const today = new Date();
    const nextYear = new Date();
    nextYear.setFullYear(today.getFullYear() + 1);

    this.discountForm = this.fb.group({
      studentId: [data.studentId || '', Validators.required],
      discountType: ['percentage', Validators.required],
      discountValue: ['', [Validators.required, Validators.min(0)]],
      reason: ['', Validators.required],
      appliedFrom: [today.toISOString().split('T')[0], Validators.required],
      appliedTo: [nextYear.toISOString().split('T')[0], Validators.required],
      academicYearId: [data.academicYearId || '', Validators.required]
    });
  }

  ngOnInit(): void {
    this.loadAcademicYears();
    if (!this.data.studentId) {
      this.setupStudentSearch();
    }
  }

  private loadAcademicYears(): void {
    this.yearContext.loadAcademicYears().pipe(takeUntil(this.destroy$)).subscribe({
      next: () => {
        this.academicYears.set(this.yearContext.yearsSnapshot as any[]);
        if (!this.data.academicYearId && this.academicYears().length > 0) {
          const selectedId = this.yearContext.selectedYearId;
          if (selectedId) {
            this.discountForm.patchValue({ academicYearId: selectedId });
          } else {
            const currentYear = this.academicYears().find((y: any) => y.isCurrent) || this.academicYears()[0];
            this.discountForm.patchValue({ academicYearId: currentYear.id });
          }
        }
        this.cdr.markForCheck();
      }
    });
  }

  private setupStudentSearch(): void {
    this.studentSearchControl.valueChanges.pipe(
      debounceTime(300),
      takeUntil(this.destroy$),
      switchMap(value => {
        const val = typeof value === 'string' ? value.trim() : '';
        if (val.length >= 1) {
          this.isSearching.set(true);
          const academicYearId = this.discountForm.get('academicYearId')?.value;
          return this.feeService.searchStudents(val, academicYearId).pipe(
            finalize(() => {
              this.isSearching.set(false);
              this.cdr.markForCheck();
            }),
            catchError((err) => { console.error('Failed to search students for discount', err); return of([]); })
          );
        } else {
          return of([]);
        }
      })
    ).subscribe((response: any) => {
      this.filteredStudents.set(response?.data || response || []);
      this.cdr.markForCheck();
    });
  }

  displayStudent(student: any): string {
    return student ? student.displayName || `${student.firstName} ${student.lastName}` : '';
  }

  onStudentSelected(event: any): void {
    const student = event.option.value;
    this.discountForm.patchValue({ studentId: student.id });
    this.cdr.markForCheck();
  }

  onCancel(): void {
    this.dialogRef.close();
  }

  onSubmit(): void {
    if (this.discountForm.invalid) return;

    this.isSubmitting.set(true);
    this.errorMessage.set('');
    this.cdr.markForCheck();

    const formValue = this.discountForm.value;
    const requestPayload = {
      studentId: formValue.studentId,
      academicYearId: formValue.academicYearId,
      isPercentage: formValue.discountType === 'percentage',
      discountValue: formValue.discountValue,
      effectiveDate: formValue.appliedFrom,
      expiryDate: formValue.appliedTo,
      remarks: formValue.reason,
      status: 'active'
    };

    this.apiService.post('/fees/discounts', requestPayload).subscribe({
      next: (res) => {
        this.isSubmitting.set(false);
        this.snackBar.open('Discount applied successfully', 'Close', { duration: 3000 });
        this.dialogRef.close({ success: true, data: res });
      },
      error: (err) => {
        this.isSubmitting.set(false);
        this.errorMessage.set(err.error?.message || 'Failed to apply discount');
        this.cdr.markForCheck();
      }
    });
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }
}
