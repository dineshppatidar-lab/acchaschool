import { Component, OnInit, ViewChild, signal } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Location } from '@angular/common';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatCardModule } from '@angular/material/card';
import { MatSelectModule } from '@angular/material/select';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatChipsModule } from '@angular/material/chips';
import { MatStepperModule } from '@angular/material/stepper';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatDividerModule } from '@angular/material/divider';
import { ApiService } from '../../services/api.service';
import { ChangeDetectorRef } from '@angular/core';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { forkJoin, of } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { NotificationService } from '../../services/notification.service';
import { AcademicYearContextService } from '../../shared/services/academic-year-context.service';
import { DialogUtils } from '../../shared/dialog-utils';
import { CreateFamilyDialogComponent } from './family-create-dialog.component';
import { ReceiptPrinterService } from '../../shared/services/receipt-printer.service';
import { FeePageHeaderComponent } from '../../shared/components/fees-module/fee-page-header.component';

interface FamilyMember {
  studentId: string;
  name: string;
  outstandingAmount: number;
  discountAmount: number;
  selected: boolean;
}

interface PaymentAllocation {
  studentId: string;
  studentName: string;
  allocatedAmount: number;
  originalOutstanding: number;
  newBalance: number;
}

@Component({
  selector: 'app-family-payment-processor',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule,
    MatCardModule,
    MatSelectModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatProgressSpinnerModule,
    MatSnackBarModule,
    MatStepperModule,
    MatCheckboxModule,
    MatDividerModule, 
    MatDialogModule, 
    MatTooltipModule, 
    MatChipsModule,
    FeePageHeaderComponent,
  ],
  templateUrl: './family-payment-processor.component.html',
  styleUrls: ['./family-payment-processor.component.scss']
})
export class FamilyPaymentProcessorComponent implements OnInit {
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  // Forms
  familySelectionForm!: FormGroup;
  paymentForm!: FormGroup;

  // State
  isLoading = signal(false);
  isProcessing = signal(false);
  currentStep = signal(0);

  // Family data
  familyMembers = signal<any[]>([]);
  selectedMembers: FamilyMember[] = [];

  // Families for dropdown
  families: { id: number; name: string }[] = [];

  // Payment allocation
  paymentAllocations: PaymentAllocation[] = [];
  totalOutstanding = 0;
  totalPayment = 0;
  allocatableAmount = signal(0);

  // Tracks the last value auto-filled from selection so user edits are preserved
  private lastAutoAmount = signal(0);

  // Display columns
  memberColumns = ['select', 'name', 'studentId', 'outstandingAmount'];
  allocationColumns = ['studentName', 'originalOutstanding', 'allocatedAmount', 'newBalance'];

  dataSource = new MatTableDataSource<FamilyMember>([]);
  allocationDataSource = new MatTableDataSource<PaymentAllocation>([]);

  constructor(
    private fb: FormBuilder,
    private apiService: ApiService,
    private notificationService: NotificationService,
    private snackBar: MatSnackBar
    , private dialog: MatDialog,
    private cd: ChangeDetectorRef,
    private route: ActivatedRoute,
    private router: Router,
    private location: Location,
    private yearContext: AcademicYearContextService,
    private dialogUtils: DialogUtils,
    private receiptPrinter: ReceiptPrinterService
  ) {
    this.initializeForms();
  }

  /** History-aware back navigation for the header back arrow. */
  goBack(): void {
    if (typeof window !== 'undefined' && window.history.length > 1) {
      this.location.back();
    } else {
      this.router.navigate(['/app/fees/list']);
    }
  }

  ngOnInit(): void {
    this.loadFamilies();

    // If a `step` query param is provided (e.g. ?step=3), set the stepper to that index
    this.route.queryParams.subscribe(params => {
      const step = Number(params['step']);
      if (!isNaN(step) && step >= 0) {
        // clamp to available steps (0..3)
        this.currentStep.set(Math.max(0, Math.min(3, step)));
        // markForCheck schedules a coalesced CD tick (zoneless-safe).
        // A synchronous detectChanges() here re-enters an in-flight cycle and triggers NG0100.
        this.cd.markForCheck();
      }
    });
  }

  private loadFamilies(): void {
    this.apiService.get<any>('/fees/families').pipe(catchError((err) => { console.error('Failed to load families', err); return of([]); })).subscribe({
      next: (res: any) => {
        const items = (res && (res.data ?? res)) || [];
        // Expecting array of { id, familyName }
        // Defer assignment to avoid ExpressionChangedAfterItHasBeenCheckedError
        setTimeout(() => {
          this.families = (items || []).map((f: any) => ({ id: f.id ?? f.familyGroupId ?? f.familyId, name: f.familyName ?? f.name ?? f.familyName ?? f.name }));
          this.cd.markForCheck();
        });
      },
      error: (err: any) => {
        console.error('Failed to load families', err);
      }
    });
  }

  /** Opens the Create Family dialog and refreshes the dropdown after a family is created. */
  openCreateFamilyDialog(): void {
    const dialogRef = this.dialog.open(CreateFamilyDialogComponent, {
      ...this.dialogUtils.getMobileConfig(),
      width: '560px',
      maxWidth: '560px',
      maxHeight: '90vh'
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result?.created) {
        // Refresh the families dropdown so the new family appears, then preselect it
        this.loadFamilies();
        const newId = result?.data?.id ?? result?.data?.Id;
        if (newId) {
          setTimeout(() => {
            // Patch with numeric id so it matches the mat-option [value]="f.id" binding
            this.familySelectionForm.patchValue({ familyId: Number(newId) });
            this.selectFamily(String(newId));
          });
        }
      }
    });
  }

  private initializeForms(): void {
    this.familySelectionForm = this.fb.group({
      familyId: ['', Validators.required],
      paymentMethod: ['cash', Validators.required]
    });

    this.paymentForm = this.fb.group({
      totalPayment: ['', [Validators.required, Validators.min(0)]],
      paymentDate: [new Date().toISOString().split('T')[0], Validators.required],
      narration: ['']
    });
  }

  selectFamily(familyId: string): void {
    const url = `${this.apiService.getBaseUrl()}/Fees/${familyId}/members-fees`;
    console.log('selectFamily called with', familyId, 'request url', url);
    this.isLoading.set(true);
    this.apiService.get<any>(`/Fees/families/${familyId}/members-fees`).subscribe({
      next: (res: any) => {
        console.log('Loaded family members response for familyId', familyId, res);
        const data = res?.data ?? res;
        // Backend returns FamilyPaymentSummaryDto: { students: [...], totalFamilyOutstanding, ... }.
        // Accept legacy shapes (members / plain array) for robustness.
        const members = Array.isArray(data)
          ? data
          : (data?.students ?? data?.members ?? []);

        // Defer updates that affect bindings to avoid ExpressionChangedAfterItHasBeenCheckedError
        setTimeout(() => {
          try {
          this.familyMembers.set((members as any[]).map((member: any) => ({
            studentId: (member.studentId ?? member.StudentId ?? member.id)?.toString(),
            name: this.formatMemberName(member),
            outstandingAmount: Number(member.outstandingAmount ?? member.outstanding ?? member.outstandingFees ?? member.Outstanding ?? 0),
            discountAmount: Number(member.discountAmount ?? member.DiscountAmount ?? 0),
            selected: false
          })));

          this.dataSource = new MatTableDataSource<FamilyMember>(this.familyMembers());
          this.dataSource.paginator = this.paginator;
          this.dataSource.sort = this.sort;

          // If backend provides family totals, prefer them
          this.allocatableAmount.set(Number(data?.totalFamilyOutstanding ?? data?.totalFamilyFees ?? this.familyMembers().reduce((s, m) => s + (m.outstandingAmount || 0), 0)));
          this.calculateTotals();

          // Prefill payment amount with total outstanding for the family if user hasn't entered one
          try {
            const current = this.paymentForm.get('totalPayment')?.value;
            if (current === null || current === undefined || Number(current) <= 0) {
              this.paymentForm.patchValue({ totalPayment: this.roundCurrency(this.allocatableAmount()) });
              this.lastAutoAmount.set(this.roundCurrency(this.allocatableAmount()));
            }
          } catch { }

          } catch (e) {
            // Never leave the spinner stuck if mapping fails unexpectedly
            console.error('Failed to parse family members response', e);
            this.familyMembers.set([]);
          }
          this.isLoading.set(false);
          this.cd.markForCheck();
        });
      },
      error: (error: any) => {
        console.error('Error loading family members:', error);
        this.notificationService.error('Failed to load family members');
        this.isLoading.set(false);
      }
    });
  }


  toggleMemberSelection(member: FamilyMember): void {
    member.selected = !member.selected;
    this.updateSelectedMembers();
  }

  selectAllMembers(): void {
    this.familyMembers().forEach(m => m.selected = true);
    this.updateSelectedMembers();
  }

  deselectAllMembers(): void {
    this.familyMembers().forEach(m => m.selected = false);
    this.updateSelectedMembers();
  }

  private updateSelectedMembers(): void {
    this.selectedMembers = this.familyMembers().filter(m => m.selected);
    this.calculateTotals();
    this.syncAmountWithSelection();
  }

  /**
   * Keep the Payment Amount field in sync with the selected members' outstanding
   * total — but never overwrite an amount the user has actively typed.
   */
  private syncAmountWithSelection(): void {
    const control = this.paymentForm.get('totalPayment');
    if (!control) return;

    // A user-typed amount wins until the user changes selection to a different set,
    // presses "Full", or clears the field. We only auto-update when the current value
    // is empty, or equals the previous auto value (i.e. untouched by the user).
    const current = Number(control.value);
    const isPristineAutoValue =
      control.value === null || control.value === undefined || control.value === '' ||
      !isNaN(current) && (current === this.lastAutoAmount());

    if (isPristineAutoValue && this.allocatableAmount() > 0) {
      control.setValue(this.roundCurrency(this.allocatableAmount()));
      this.lastAutoAmount.set(this.roundCurrency(this.allocatableAmount()));
    }
  }

  /** "Full" chip — set amount to the selected members' total outstanding. */
  setFullAmount(): void {
    this.paymentForm.get('totalPayment')?.setValue(this.roundCurrency(this.allocatableAmount()));
    this.lastAutoAmount.set(this.roundCurrency(this.allocatableAmount()));
  }

  /** "Clear" chip — empty the amount field. */
  clearAmount(): void {
    this.paymentForm.get('totalPayment')?.setValue('');
    this.lastAutoAmount.set(0);
  }

  private calculateTotals(): void {
    if (this.selectedMembers && this.selectedMembers.length > 0) {
      this.totalOutstanding = this.selectedMembers.reduce((sum, m) => sum + m.outstandingAmount, 0);
    } else {
      // if no explicit selection, consider all family members for outstanding total
      this.totalOutstanding = (this.familyMembers() || []).reduce((sum, m) => sum + (m.outstandingAmount || 0), 0);
    }
    this.allocatableAmount.set(this.totalOutstanding);
  }

  proceedToPayment(): void {
    // If no members explicitly selected, auto-select all loaded family members
    if (this.selectedMembers.length === 0) {
      if (this.familyMembers() && this.familyMembers().length > 0) {
        this.familyMembers().forEach(m => m.selected = true);
        this.updateSelectedMembers();
      }
    }

    const entered = this.paymentForm.get('totalPayment')?.value;
    if (!entered) {
      // If user hasn't entered an amount, default to full outstanding so they can review allocations
      this.totalPayment = this.allocatableAmount() || 0;
      this.notificationService.info(`No payment amount entered — defaulting to ₹${this.totalPayment.toFixed(2)}`);
    } else {
      this.totalPayment = this.roundCurrency(parseFloat(entered || 0));
    }

    if (!this.totalPayment || this.totalPayment <= 0) {
      this.notificationService.warning('Please enter payment amount');
      return;
    }

    if (this.totalPayment > this.allocatableAmount()) {
      this.notificationService.warning(
        `Payment amount exceeds outstanding fees (Max: $${this.allocatableAmount()})`
      );
      return;
    }

    this.allocatePayment();
    this.currentStep.set(1); // Move to allocation step
  }

  private allocatePayment(): void {
    // Auto-allocate to students in order of outstanding fees
    let remainingPayment = this.totalPayment;
    this.paymentAllocations = [];

    const sortedMembers = [...this.selectedMembers].sort(
      (a, b) => b.outstandingAmount - a.outstandingAmount
    );

    sortedMembers.forEach(member => {
      if (remainingPayment <= 0) return;

      const allocatedAmount = this.roundCurrency(Math.min(remainingPayment, member.outstandingAmount));
      const newBalance = this.roundCurrency(member.outstandingAmount - allocatedAmount);

      this.paymentAllocations.push({
        studentId: member.studentId,
        studentName: member.name,
        originalOutstanding: member.outstandingAmount,
        allocatedAmount,
        newBalance
      });

      remainingPayment = this.roundCurrency(remainingPayment - allocatedAmount);
    });

    this.allocationDataSource = new MatTableDataSource<PaymentAllocation>(this.paymentAllocations);
  }

  adjustAllocation(allocation: PaymentAllocation, newAmount: number): void {
    allocation.allocatedAmount = this.roundCurrency(newAmount);
    allocation.newBalance = this.roundCurrency(allocation.originalOutstanding - allocation.allocatedAmount);
  }

  processPayment(): void {
    // Log key values for debugging when users report "nothing happens"
    console.log('processPayment called', {
      totalPayment: this.totalPayment,
      allocations: this.paymentAllocations
    });

    if (!this.hasValidAllocation()) {
      // Provide clearer feedback including totals so user can see why it failed
      const totalAllocated = this.paymentAllocations.reduce((s, a) => s + Number(a.allocatedAmount || 0), 0);
      this.notificationService.warning(`Invalid allocation: allocated ₹${totalAllocated.toFixed(2)} vs payment ₹${Number(this.totalPayment || 0).toFixed(2)}`);
      return;
    }

    this.isProcessing.set(true);

    const familyId = Number(this.familySelectionForm.get('familyId')?.value);
    const studentIds = this.selectedMembers.map(m => Number(m.studentId));

    // Step 1: get academic year from centralized context
    const academicYearId = this.yearContext.selectedYearId || 0;

    // Step 2: initiate group payment
    const initiateReq = {
      familyGroupId: familyId,
      studentIds: studentIds,
      academicYearId: academicYearId,
      allocationStrategy: 1, // Proportional by default
      paymentGroupName: `Family-${familyId}-${Date.now()}`
    };

    this.apiService.post('/advancedfinance/group-payments/initiate', initiateReq).subscribe({
      next: (initRes: any) => {
        const groupPaymentId = initRes?.data?.groupPaymentId ?? initRes?.data?.GroupPaymentId ?? initRes?.groupPaymentId ?? initRes?.GroupPaymentId ?? initRes?.data;

        // Load installments for each selected student and map allocations to installment-level
        const installmentCalls = studentIds.map(sid => this.apiService.get<any>(`/advancedfinance/students/${sid}/fee-installments`).pipe(catchError((err) => { console.error(`Failed to load installments for student ${sid}`, err); return of([]); })));

        forkJoin(installmentCalls).subscribe((installmentsArray: any[]) => {
          const customAllocations: any[] = [];
          let totalSkipped = 0;

          // For each student, allocate their allocatedAmount across installments (earliest due first)
          this.paymentAllocations.forEach(pa => {
            const sid = Number(pa.studentId);
            let remaining = Number(pa.allocatedAmount) || 0;
            const idx = studentIds.indexOf(sid);
            const installments = (installmentsArray[idx] && (installmentsArray[idx].data ?? installmentsArray[idx])) || [];

            // Normalize installment items to { installmentId, amount/balance, dueDate }
            const normalized = (installments || []).map((it: any) => ({
              installmentId: it.installmentId ?? it.id ?? it.InstallmentId ?? it.Id,
              balance: it.balance ?? it.Balance ?? it.amount ?? it.Amount ?? 0,
              dueDate: new Date(it.dueDate ?? it.DueDate ?? Date.now())
            })).sort((a: any, b: any) => new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime());

            for (const inst of normalized) {
              if (remaining <= 0) break;
              const take = Math.min(remaining, inst.balance || 0);
              if (take > 0) {
                customAllocations.push({ studentId: sid, feeInstallmentId: inst.installmentId, allocatedAmount: take });
                remaining -= take;
              }
            }

            // If still remaining (no installments or insufficient balance), warn the user
            if (remaining > 0) {
              totalSkipped += remaining;
              console.warn(`Skipping ₹${remaining.toFixed(2)} for student ${sid}: no available installment balance`);
            }
          });

          // Warn user if some amount couldn't be applied
          if (totalSkipped > 0) {
            this.notificationService.warning(`₹${totalSkipped.toFixed(2)} could not be allocated to any installment (fully paid or no fee structure). Only ₹${(this.totalPayment - totalSkipped).toFixed(2)} will be applied.`);
          }

          // Use the actual sum of custom allocations as the total, not the original payment amount
          const actualTotal = customAllocations.reduce((sum, a) => sum + (a.allocatedAmount || 0), 0);

          // Build process request
          const processReq = {
            groupPaymentId: groupPaymentId || initRes?.data?.GroupPaymentId || initRes?.data?.groupPaymentId || initRes?.GroupPaymentId || initRes?.groupPaymentId || initRes?.data,
            totalAmountPaid: actualTotal || this.totalPayment,
            paymentMethod: this.familySelectionForm.get('paymentMethod')?.value || 'cash',
            transactionId: '',
            processedByStaffId: 0,
            customAllocations: customAllocations,
            remarks: this.paymentForm.get('narration')?.value || ''
          };

          // Step 3: process the group payment
          this.apiService.post('/advancedfinance/group-payments/process', processReq).subscribe({
            next: (res: any) => {
              this.notificationService.success('Payment processed successfully');
              this.currentStep.set(3); // Move to Complete step
              this.isProcessing.set(false);
              this.cd.markForCheck();
              // Defer navigation to a new turn: navigating in the same tick as the state
              // change makes queryParams emit synchronously and re-enter change detection
              // before this pass finishes (NG0100: 'true' -> 'false' on [disabled]).
              setTimeout(() => {
                try {
                  this.router.navigate([], { relativeTo: this.route, queryParams: { step: 3 }, queryParamsHandling: 'merge' });
                } catch (e) {
                  console.warn('Failed to update query params for completion step', e);
                }
              });
            },
            error: (error: any) => {
              console.error('Error processing group payment:', error);
              // Surface the backend's actual message (validation/failure reason)
              const reason = error?.error?.message || error?.error?.Message || error?.message;
              this.notificationService.error(reason ? `Payment failed: ${reason}` : 'Failed to process group payment');
              this.isProcessing.set(false);
              this.cd.markForCheck();
            }
          });
        }, (err) => {
          console.error('Failed to load installments for allocations', err);
          this.notificationService.error('Failed to load installment details for allocations');
          this.isProcessing.set(false);
          this.cd.markForCheck();
        });
      },
      error: (err: any) => {
        console.error('Failed to initiate group payment', err);
        this.notificationService.error('Failed to initiate group payment');
        this.isProcessing.set(false);
        this.cd.markForCheck();
      }
    });
  }



  private roundCurrency(value: number): number {
    return Math.round((Number(value) + Number.EPSILON) * 100) / 100;
  }

  private hasValidAllocation(): boolean {
    const totalPayment = this.roundCurrency(Number(this.totalPayment || 0));
    const totalAllocated = this.roundCurrency(
      this.paymentAllocations.reduce((sum, a) => sum + Number(a.allocatedAmount || 0), 0)
    );
    const diff = Math.abs(totalAllocated - totalPayment);
    return diff <= 0.01 && this.paymentAllocations.every(a => this.roundCurrency(Number(a.allocatedAmount || 0)) >= 0);
  }

  resetForm(): void {
    this.familySelectionForm.reset({
      paymentMethod: 'cash'
    });
    this.paymentForm.reset({
      paymentDate: new Date().toISOString().split('T')[0]
    });
    this.familyMembers.set([]);
    this.selectedMembers = [];
    this.paymentAllocations = [];
    this.totalPayment = 0;
    this.totalOutstanding = 0;
    this.currentStep.set(0);
    this.dataSource = new MatTableDataSource<FamilyMember>([]);
    this.allocationDataSource = new MatTableDataSource<PaymentAllocation>([]);
  }

  goToStep(step: number): void {
    this.currentStep.set(step);
  }

  /** Display "Name (Roll: 12)" — roll number instead of internal student ID. */
  private formatMemberName(member: any): string {
    const name = member.studentName ?? member.StudentName ?? `${member.firstName ?? ''} ${member.lastName ?? ''}`.trim();
    const roll = member.rollNumber ?? member.RollNumber;
    return roll ? `${name} (Roll: ${roll})` : name;
  }

  downloadReceipt(): void {
    // Invoice-style receipt: each student's paid allocation is a line item.
    const familyName = (this.families.find(f => f.id === Number(this.familySelectionForm.get('familyId')?.value))?.name) || '';
    const paymentMethod = (this.familySelectionForm.get('paymentMethod')?.value || 'Cash');
    const paymentDate = this.paymentForm.get('paymentDate')?.value || new Date().toISOString().split('T')[0];

    try {
      this.receiptPrinter.print({
        title: 'Family Payment',
        receiptNo: `FAM-${Date.now()}`,
        studentName: familyName || 'Family Payment',
        date: String(paymentDate).slice(0, 10),
        items: (this.paymentAllocations || []).map(a => ({
          description: `${a.studentName} — Fee Payment`,
          unitPrice: Number(a.allocatedAmount || 0),
          total: Number(a.allocatedAmount || 0)
        })),
        paymentMethod: ReceiptPrinterService.humanizeMethod(paymentMethod),
        infoLines: (this.paymentAllocations || []).map(a => `${a.studentName}: new balance ₹${Number(a.newBalance || 0).toFixed(2)}`)
      });
    } catch (err) {
      console.error('Failed to generate receipt', err);
      this.notificationService.error('Failed to generate receipt');
    }
  }
}
