import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnDestroy, OnInit, ViewChild, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatCardModule } from '@angular/material/card';
import { MatSelectModule } from '@angular/material/select';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatTabsModule } from '@angular/material/tabs';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatDividerModule } from '@angular/material/divider';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { ApiService } from '../../services/api.service';
import { NotificationService } from '../../services/notification.service';
import { AdvancedAcademicService } from '../../services/advanced-academic.service';
import { FeeManagementService } from '../../shared/services/fee-management.service';
import { AcademicYear } from '../../shared/models/academic.models';
import { AcademicYearContextService } from '../../shared/services/academic-year-context.service';
import { StudentManagementService } from '../../shared/services/student-management.service';
import { Observable, of, Subject } from 'rxjs';
import { debounceTime, switchMap, catchError, finalize, takeUntil } from 'rxjs/operators';
import { FeeStatusBadgeComponent } from '../../shared/components/fees-module/fee-status-badge.component';
import { FeePageHeaderComponent } from '../../shared/components/fees-module/fee-page-header.component';
import { FeeKpiCardComponent } from '../../shared/components/fees-module/fee-kpi-card.component';

interface StudentDiscount {
  id?: number;
  studentId: number;
  studentName?: string;
  discountType: 'percentage' | 'fixed';
  isPercentage: boolean;
  discountPercentage?: number;
  discountAmount?: number;
  discountValue?: number; // Kept for form compatibility
  reason: string;
  appliedFrom: string;
  appliedTo: string;
  status: 'active' | 'inactive' | 'expired';
  CreatedOn: string;
  createdBy?: string;
  academicYear: string;
  academicYearId?: number;
}

@Component({
  selector: 'app-student-discount',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule,
    MatCardModule,
    MatSelectModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatProgressSpinnerModule,
    MatSnackBarModule,
    MatTabsModule,
    MatCheckboxModule,
    MatSlideToggleModule,
    MatDividerModule,
    MatAutocompleteModule,
    FeeStatusBadgeComponent,
    FeePageHeaderComponent,
    FeeKpiCardComponent,
  ],
  templateUrl: './student-discount.component.html',
  styleUrls: ['./student-discount.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class StudentDiscountComponent implements OnInit, OnDestroy {
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  // Form properties
  discountForm!: FormGroup;
  studentSearchControl = new FormControl<any>('');
  isLoading = signal(false);
  isSubmitting = signal(false);
  isSearching = signal(false);
  isEditMode = signal(false);
  editingDiscountId: number | null = null;
  // Tab order: 0 = Active Discounts (default, leftmost), 1 = Apply Discount
  readonly TAB_ACTIVE = 0;
  readonly TAB_APPLY = 1;
  activeTab = signal(this.TAB_ACTIVE);

  /** Jump to a tab from the hero actions. */
  switchToTab(index: number): void {
    this.activeTab.set(index);
  }

  private destroy$ = new Subject<void>();

  // Data
  academicYears = signal<any[]>([]);
  filteredStudents = signal<any[]>([]);
  discounts = signal<any[]>([]);
  dataSource = new MatTableDataSource<StudentDiscount>([]);
  displayedColumns: string[] = ['studentName', 'discountType', 'discountValue', 'discountAmount', 'status', 'appliedFrom', 'actions'];

  // Filter properties
  statusFilter = 'all';
  typeFilter = 'all';
  academicYearFilter = signal('');
  studentSearch = '';

  // Statistics
  totalDiscounts = 0;
  totalDiscountAmount = 0;
  activeDiscounts = 0;
  percentageDiscounts = 0;

  constructor(
    private fb: FormBuilder,
    private apiService: ApiService,
    private notificationService: NotificationService,
    private academicService: AdvancedAcademicService,
    private feeService: FeeManagementService,
    private snackBar: MatSnackBar,
    private cdr: ChangeDetectorRef,
    private yearContext: AcademicYearContextService,
    private studentManagementService: StudentManagementService
  ) {
    this.initializeForm();
  }

  ngOnInit(): void {
    this.loadAcademicYearsFromContext();
    this.loadDiscounts();
    this.setupStudentSearch();
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  private initializeForm(): void {
    const today = new Date();
    this.discountForm = this.fb.group({
      studentId: ['', Validators.required],
      discountType: ['percentage', Validators.required],
      discountValue: ['', [Validators.required, Validators.min(0)]],
      reason: ['', Validators.required],
      appliedFrom: [today.toISOString().split('T')[0], Validators.required],
      appliedTo: ['', Validators.required],
      academicYearId: ['', Validators.required]
    });

    // Reset student when academic year changes
    this.discountForm.get('academicYearId')?.valueChanges.pipe(takeUntil(this.destroy$)).subscribe(() => {
      this.discountForm.patchValue({ studentId: '' });
      this.studentSearchControl.setValue('');
      this.filteredStudents.set([]);
      this.cdr.markForCheck();
    });

    // Validate that appliedTo is after appliedFrom
    this.discountForm.setValidators(() => {
      const from = this.discountForm.get('appliedFrom')?.value;
      const to = this.discountForm.get('appliedTo')?.value;
      if (from && to && from >= to) {
        return { dateRange: true };
      }
      return null;
    });
  }

  private setupStudentSearch(): void {
    this.studentSearchControl.valueChanges.pipe(
      debounceTime(300),
      takeUntil(this.destroy$),
      switchMap(value => {
        const val = typeof value === 'string' ? value.trim() : '';
        if (val.length >= 1) {
          this.isSearching.set(true);
          const academicYearId = this.discountForm.get('academicYearId')?.value;
          return this.feeService.searchStudents(val, academicYearId).pipe(
            finalize(() => {
              this.isSearching.set(false);
              this.cdr.markForCheck();
            }),
            catchError(() => of({ data: [] }))
          );
        } else {
          return of({ data: [] });
        }
      })
    ).subscribe((response: any) => {
      this.filteredStudents.set(response?.data || response || []);
      this.cdr.markForCheck();
    });
  }

  loadAcademicYearsFromContext(): void {
    this.yearContext.loadAcademicYears().pipe(takeUntil(this.destroy$)).subscribe({
      next: () => {
        this.academicYears.set(this.yearContext.yearsSnapshot as any[]);
        if (this.academicYears().length > 0) {
          const selectedId = this.yearContext.selectedYearId;
          if (selectedId) {
            this.discountForm.patchValue({ academicYearId: selectedId });
            this.academicYearFilter.set(selectedId.toString());
          }
        }
        this.cdr.markForCheck();
      },
      error: () => {}
    });
  }

  displayStudent(student: any): string {
    if (!student) return '';
    // Backend search returns { firstName, lastName, ... } without displayName
    return student.displayName || `${student.firstName ?? ''} ${student.lastName ?? ''}`.trim();
  }

  onStudentSelected(event: any): void {
    const student = event.option.value;
    this.discountForm.patchValue({ studentId: student.id });
    this.cdr.markForCheck();
  }

  loadDiscounts(): void {
    this.isLoading.set(true);
    this.cdr.detectChanges();

    let url = '/fees/discounts';
    if (this.academicYearFilter()) {
      url += `?academicYearId=${this.academicYearFilter()}`;
    }

    this.apiService.get<StudentDiscount[]>(url).subscribe({
      next: (data: StudentDiscount[]) => {
        // Normalize backend StudentFeeAdjustmentDto shape into the UI model:
        // effectiveDate→appliedFrom, expiryDate→appliedTo, enum status→string,
        // plus derive studentName/discountType the table columns expect.
        this.discounts.set(((data as any[]) || []).map((d: any) => this.mapDiscount(d)));
        this.calculateDiscountAmounts();
        // Older API builds don't send studentName on the DTO — resolve names client-side
        this.resolveMissingStudentNames();
        this.updateTableData();
        this.calculateStatistics();
        this.isLoading.set(false);
        this.cdr.detectChanges();
      },
      error: (error: any) => {
        console.error('Error loading discounts:', error);
        this.notificationService.error('Failed to load discounts');
        this.isLoading.set(false);
        this.cdr.detectChanges();
      }
    });
  }

  submitDiscount(): void {
    if (!this.discountForm.valid) {
      this.notificationService.warning('Please fill all required fields correctly');
      return;
    }

    this.isSubmitting.set(true);
    this.cdr.detectChanges();

    const formValue = this.discountForm.value;
    
    // Map to the backend CreateDiscountRequest DTO
    const requestPayload = {
      id: this.editingDiscountId, // Include ID if editing
      studentId: formValue.studentId,
      academicYearId: formValue.academicYearId,
      isPercentage: formValue.discountType === 'percentage',
      discountValue: formValue.discountValue, // Backend expects DiscountValue
      effectiveDate: formValue.appliedFrom,
      expiryDate: formValue.appliedTo,
      remarks: formValue.reason,
      status: 'active'
    };

    const request = this.isEditMode() && this.editingDiscountId
      ? this.apiService.put(`/fees/discounts/${this.editingDiscountId}`, requestPayload)
      : this.apiService.post('/fees/discounts', requestPayload);

    request.subscribe({
      next: () => {
        this.notificationService.success(`Discount ${this.isEditMode() ? 'updated' : 'applied'} successfully`);
        this.resetForm();
        this.activeTab.set(this.TAB_ACTIVE);
        this.loadDiscounts();
        this.isSubmitting.set(false);
        this.cdr.detectChanges();
      },
      error: (error) => {
        console.error(`Error ${this.isEditMode() ? 'updating' : 'applying'} discount:`, error);
        this.notificationService.error(`Failed to ${this.isEditMode() ? 'update' : 'apply'} discount`);
        this.isSubmitting.set(false);
        this.cdr.detectChanges();
      }
    });
  }

  resetForm(): void {
    const currentYearId = this.discountForm.get('academicYearId')?.value;
    const today = new Date();
    this.discountForm.reset();
    this.studentSearchControl.setValue('');
    this.filteredStudents.set([]);
    this.isEditMode.set(false);
    this.editingDiscountId = null;
    this.discountForm.patchValue({
      discountType: 'percentage',
      appliedFrom: today.toISOString().split('T')[0],
      academicYearId: currentYearId
    });
    this.cdr.markForCheck();
  }

  editDiscount(discount: StudentDiscount): void {
    this.isEditMode.set(true);
    this.editingDiscountId = discount.id || null;
    
    // Populate form - use emitEvent: false for academicYearId to prevent resetting student
    this.discountForm.get('academicYearId')?.setValue(discount.academicYearId, { emitEvent: false });
    
    this.discountForm.patchValue({
      studentId: discount.studentId,
      discountType: discount.isPercentage ? 'percentage' : 'fixed',
      discountValue: discount.isPercentage ? discount.discountPercentage : discount.discountAmount,
      reason: discount.reason,
      appliedFrom: discount.appliedFrom ? new Date(discount.appliedFrom).toISOString().split('T')[0] : '',
      appliedTo: discount.appliedTo ? new Date(discount.appliedTo).toISOString().split('T')[0] : ''
    }, { emitEvent: false }); // Disable events for the whole patch to be safe during edit setup

    // Populate student search display
    this.studentSearchControl.setValue({
      id: discount.studentId,
      displayName: discount.studentName
    }, { emitEvent: false });

    // Switch to the Apply tab for editing
    this.activeTab.set(this.TAB_APPLY);
    this.cdr.markForCheck();
  }

  updateDiscount(discount: StudentDiscount): void {
    this.editDiscount(discount);
  }

  deactivateDiscount(discount: StudentDiscount): void {
    if (!discount.id) return;

    this.apiService.put(`/fees/discounts/${discount.id}`, { status: 'inactive' }).subscribe({
      next: () => {
        this.notificationService.success('Discount deactivated');
        this.loadDiscounts();
        this.cdr.detectChanges();
      },
      error: (error) => {
        console.error('Error deactivating discount:', error);
        this.notificationService.error('Failed to deactivate discount');
        this.cdr.detectChanges();
      }
    });
  }

  deleteDiscount(discount: StudentDiscount): void {
    if (!discount.id || !confirm('Are you sure you want to delete this discount?')) return;

    this.apiService.delete(`/fees/discounts/${discount.id}`).subscribe({
      next: () => {
        this.notificationService.success('Discount deleted successfully');
        this.loadDiscounts();
        this.cdr.detectChanges();
      },
      error: (error) => {
        console.error('Error deleting discount:', error);
        this.notificationService.error('Failed to delete discount');
        this.cdr.detectChanges();
      }
    });
  }

  /**
   * If the backend didn't populate studentName (pre-deploy DTO), resolve the names
   * client-side from the students list so the table shows real names, not "Student #2".
   */
  private resolveMissingStudentNames(): void {
    const needsName = (n?: string) => !n || /^Student #\d+$/.test(n);
    const missing = this.discounts().filter(d => needsName(d.studentName));
    if (missing.length === 0) return;

    const missingIds = new Set(missing.map(d => Number(d.studentId)));
    this.studentManagementService.getAllStudentFullDetails('', 1, 500)
      .pipe(
        takeUntil(this.destroy$),
        catchError(() => of([] as any[]))
      )
      .subscribe((students: any[]) => {
        const nameById = new Map<number, string>();
        (students || []).forEach((s: any) => {
          const name = s.fullName || `${s.firstName ?? ''} ${s.lastName ?? ''}`.trim();
          if (name) nameById.set(Number(s.id), name);
        });

        if (nameById.size === 0) return;

        this.discounts.set(this.discounts().map(d =>
          needsName(d.studentName)
            ? { ...d, studentName: nameById.get(Number(d.studentId)) ?? d.studentName }
            : d
        ));
        this.updateTableData();
        this.calculateStatistics();
        this.cdr.detectChanges();
      });
  }

  /** Map backend StudentFeeAdjustmentDto to the UI's StudentDiscount model. */
  private mapDiscount(d: any): StudentDiscount {
    const statusMap: Record<number, string> = { 1: 'active', 2: 'inactive', 3: 'expired', 4: 'inactive', 5: 'inactive' };
    const status = typeof d.status === 'string'
      ? d.status.toLowerCase()
      : (statusMap[d.status] ?? (d.status === 1 ? 'active' : 'inactive'));

    // Backend serializes enum as string via JsonStringEnumConverter ("Discount")
    const isPercentage = d.isPercentage ?? d.discountType === 'percentage';
    const studentName = d.studentName || d.studentName || `${d.student?.firstName ?? ''} ${d.student?.lastName ?? ''}`.trim();

    return {
      id: d.id,
      studentId: d.studentId,
      studentName: studentName || `Student #${d.studentId}`,
      discountType: isPercentage ? 'percentage' : 'fixed',
      isPercentage,
      discountPercentage: d.discountPercentage ?? undefined,
      discountAmount: d.discountAmount ?? undefined,
      discountValue: d.discountPercentage ?? d.discountAmount ?? d.discountValue,
      reason: d.remarks ?? d.reason ?? '',
      appliedFrom: d.effectiveDate ?? d.appliedFrom ?? '',
      appliedTo: d.expiryDate ?? d.appliedTo ?? '',
      status: (['active', 'inactive', 'expired'].includes(status) ? status : 'active') as any,
      CreatedOn: d.createdOn ?? d.CreatedOn ?? '',
      createdBy: d.createdBy ?? d.approvedBy,
      academicYear: d.academicYear ?? String(d.academicYearId ?? ''),
      academicYearId: d.academicYearId
    };
  }

  private calculateDiscountAmounts(): void {
    this.discounts().forEach(discount => {
      if (discount.discountType === 'percentage') {
        // This would need the actual fee amount for calculation
        // For now, it's stored as passed
      } else if (discount.discountType === 'fixed') {
        discount.discountAmount = discount.discountValue;
      }
    });
  }

  private updateTableData(): void {
    let filtered = [...this.discounts()];

    // Apply status filter
    if (this.statusFilter !== 'all') {
      filtered = filtered.filter(d => d.status === this.statusFilter);
    }

    // Apply type filter
    if (this.typeFilter !== 'all') {
      filtered = filtered.filter(d => d.discountType === this.typeFilter);
    }

    // Apply student search
    if (this.studentSearch.trim()) {
      filtered = filtered.filter(d =>
        d.studentName?.toLowerCase().includes(this.studentSearch.toLowerCase()) ||
        d.studentId.toString().toLowerCase().includes(this.studentSearch.toLowerCase())
      );
    }

    this.dataSource = new MatTableDataSource(filtered);
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  private calculateStatistics(): void {
    this.totalDiscounts = this.discounts().length;
    this.totalDiscountAmount = this.discounts().reduce((sum, d) => sum + (d.discountAmount || 0), 0);
    this.activeDiscounts = this.discounts().filter(d => d.status === 'active').length;
    this.percentageDiscounts = this.discounts().filter(d => d.discountType === 'percentage').length;
  }

  onStatusFilterChange(): void {
    this.updateTableData();
  }

  onTypeFilterChange(): void {
    this.updateTableData();
  }

  onSearchChange(): void {
    this.updateTableData();
  }

  formatDiscountValue(discount: StudentDiscount): string {
    if (discount.isPercentage) {
      return `${discount.discountPercentage}%`;
    } else {
      return `$${discount.discountAmount}`;
    }
  }
}
