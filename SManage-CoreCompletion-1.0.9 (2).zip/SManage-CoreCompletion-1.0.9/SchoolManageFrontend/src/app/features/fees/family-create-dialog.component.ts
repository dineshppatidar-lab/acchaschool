import { ChangeDetectorRef, Component, Inject, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialogModule } from '@angular/material/dialog';
import { ApiService } from '../../services/api.service';
import { NotificationService } from '../../services/notification.service';
import { AdvancedAcademicService } from '../../services/advanced-academic.service';
import { FeeManagementService } from '../../shared/services/fee-management.service';
import { AcademicYearContextService } from '../../shared/services/academic-year-context.service';
import { MatSelectModule } from '@angular/material/select';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatChipsModule } from '@angular/material/chips';
import { MatIconModule } from '@angular/material/icon';
import { MatListModule } from '@angular/material/list';
import { MatDividerModule } from '@angular/material/divider';
import { Observable, of, BehaviorSubject } from 'rxjs';
import { debounceTime, switchMap, catchError, startWith, distinctUntilChanged, map } from 'rxjs/operators';
import { StudentManagementService } from '../../shared/services/student-management.service';

@Component({
  selector: 'app-family-create-dialog',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, MatFormFieldModule, MatInputModule, MatButtonModule, MatDialogModule,
    MatSelectModule, MatAutocompleteModule, MatChipsModule, MatIconModule, MatListModule, MatDividerModule],
  templateUrl: './family-create-dialog.component.html',
  styles: [
    `:host .create-family-dialog { max-width: 560px; }
     :host .row { display:flex; gap:12px; }
     :host .half-width { flex: 1 1 0; }
     :host .full-width { width: 100%; }
     :host .item-actions { margin-left: auto; display:flex; align-items:center; }
     :host .muted { color: rgba(0,0,0,0.6); }
     :host .secondary { font-size: 12px; color: rgba(0,0,0,0.6); }
     :host .divider { margin: 12px 0; }
     :host mat-dialog-actions { justify-content: flex-end; }
    `
  ]
})
export class CreateFamilyDialogComponent implements OnInit {
  form: any; // FormGroup

  isSaving = signal(false);
  
  academicYears = signal<any[]>([]);
  classes = signal<any[]>([]);

  // student search
  searchTerm = '';
  searchResults = signal<any[]>([]);
  filteredStudents$!: Observable<any[]>;
  selectedStudents: any[] = [];
  searching$ = new BehaviorSubject<boolean>(false);

  constructor(
    private fb: FormBuilder,
    private api: ApiService,
    private notification: NotificationService,
    private academicService: AdvancedAcademicService,
    private feeService: FeeManagementService,
    private studentManagementService: StudentManagementService,
    private yearContext: AcademicYearContextService,
    private cd: ChangeDetectorRef,
    private dialogRef: MatDialogRef<CreateFamilyDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    // initialize form after fb is available
    this.form = this.fb.group({
      familyName: ['', [Validators.required, Validators.minLength(2)]],
      academicYearId: [null],
      classId: [null],
      memberStudentIds: [''], // deprecated fallback; selectedStudents preferred
      studentSearch: ['']
    });
  }

  ngOnInit(): void {
    // Defer initial data patching to avoid ExpressionChangedAfterItHasBeenCheckedError
    setTimeout(() => this.loadAcademicYears());

    // wire up autocomplete-style search similar to Process Payment dialog
    this.filteredStudents$ = this.form.get('studentSearch')!.valueChanges.pipe(
      startWith(''),
      debounceTime(300),
      distinctUntilChanged(),
      switchMap(value => {
        const searchStr = typeof value === 'string' ? value : ((value as any)?.name || '');
        if (!searchStr || searchStr.length < 2) return of([]);
        const yearId = this.form.get('academicYearId')?.value;
        return this.studentManagementService.getAllStudentFullDetails(searchStr, 1, 10).pipe(
          map((list: any[]) => {
            const mapped = (list || []).map(s => ({ id: s.id, name: `${s.firstName || ''} ${s.lastName || ''}`.trim(), rollNumber: s.rollNumber || '', classId: s.classId || s.class?.id || null, className: s.class?.name || s.className || '' }));
            const classFilter = this.form.get('classId')?.value;
            return classFilter ? mapped.filter((m: any) => Number(m.classId) === Number(classFilter)) : mapped;
          }),
          catchError((err) => { console.error('Failed to search students for family', err); return of([]); })
        );
      })
    );
  }

  loadAcademicYears(): void {
    this.yearContext.loadAcademicYears().pipe(
      catchError((err) => { console.error('Failed to load academic years', err); return of([]); })
    ).subscribe((yrs: any[]) => {
      // update model asynchronously to avoid change-detection timing issues
      setTimeout(() => {
        this.academicYears.set(this.yearContext.yearsSnapshot || []);
        const selectedId = this.yearContext.selectedYearId;
        if (selectedId) {
          this.form.patchValue({ academicYearId: selectedId });
          this.loadClassesForYear(selectedId);
        } else if (this.academicYears().length > 0) {
          const first = this.academicYears()[0];
          this.form.patchValue({ academicYearId: first.id });
          this.loadClassesForYear(first.id);
        }
        try { this.cd.detectChanges(); } catch { /* swallow in case view already destroyed */ }
      });
    });
  }

  loadClassesForYear(yearId: number): void {
    this.academicService.getClassesByAcademicYear(yearId).pipe(
      catchError((err) => { console.error('Failed to load classes for year', err); return of([]); })
    ).subscribe((c: any[]) => {
      // assign in next tick to avoid ExpressionChangedAfterItHasBeenCheckedError
      setTimeout(() => {
        this.classes.set(c || []);
        try { this.cd.detectChanges(); } catch { }
      });
    });
  }

  onYearChange(yearId: number): void {
    this.form.patchValue({ classId: null });
    this.loadClassesForYear(yearId);
  }

  searchStudentsDebounced(term: string): void {
    // legacy method retained for compatibility; prefer autocomplete above
    Promise.resolve().then(() => this.searching$.next(true));
    const yearId = this.form.get('academicYearId')?.value;
    of(term).pipe(
      debounceTime(300),
      switchMap(t => t && t.length > 1 ? this.feeService.searchStudents(t, yearId) : of([])),
      catchError((err) => { console.error('Failed to search students (legacy)', err); return of([]); })
    ).subscribe((res: any) => {
      const list = (res?.data || res) || [];
      const classId = this.form.get('classId')?.value;
      Promise.resolve().then(() => {
        this.searchResults.set(classId ? (list as any[]).filter((s: any) => s.classId === classId) : list as any[]);
        this.searching$.next(false);
        try { this.cd.detectChanges(); } catch { }
      });
    });
  }

  addStudentFromResult(student: any): void {
    if (!student || !student.id) return;
    if (this.selectedStudents.some(s => s.id === student.id)) return;
    this.selectedStudents.push(student);
    this.updateMemberIdsControl();
  }

  displayStudentFn(student: any): string {
    return student ? student.name : '';
  }

  onStudentSelected(event: any): void {
    const student = event.option.value;
    if (student) {
      this.addStudentFromResult(student);
      // clear the search box
      this.form.patchValue({ studentSearch: '' });
    }
  }

  removeStudent(studentId: number): void {
    this.selectedStudents = this.selectedStudents.filter(s => s.id !== studentId);
    this.updateMemberIdsControl();
  }

  private updateMemberIdsControl(): void {
    try {
      const ids = this.selectedStudents.map(s => Number(s.id)).filter(n => !!n);
      const str = ids.join(',');
      this.form.get('memberStudentIds')?.setValue(str);
    } catch (e) {
      // swallow silently
    }
  }

  save(): void {
    if (this.form.get('familyName')?.invalid) return;
    this.isSaving.set(true);

    const ids = this.selectedStudents.map(s => s.id).filter((n: number) => !!n);
    if (ids.length === 0) {
      const rawIds = this.form.get('memberStudentIds')?.value || '';
      const parsed = rawIds.toString().split(',').map((s: string) => Number(s.trim())).filter((n: number) => !isNaN(n) && n > 0);
      parsed.forEach((id: number) => ids.push(id));
    }

    const payload = { familyName: this.form.get('familyName')?.value, memberStudentIds: ids };

    this.api.post('/fees/families', payload).subscribe({
      next: (res: any) => {
        this.notification.success('Family created');
        this.dialogRef.close({ created: true, data: res?.data ?? res });
      },
      error: (err: any) => {
        console.error('Failed to create family', err);
        this.notification.error('Failed to create family');
        this.isSaving.set(false);
      }
    });
  }

  cancel(): void {
    this.dialogRef.close({ created: false });
  }
}
