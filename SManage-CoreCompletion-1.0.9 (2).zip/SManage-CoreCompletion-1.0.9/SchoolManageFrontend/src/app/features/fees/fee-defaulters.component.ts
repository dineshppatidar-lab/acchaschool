import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule, PageEvent } from '@angular/material/paginator';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatChipsModule } from '@angular/material/chips';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { RouterModule } from '@angular/router';

import { FeeManagementService } from '../../shared/services/fee-management.service';
import { FeePageHeaderComponent } from '../../shared/components/fees-module/fee-page-header.component';
import { FeeKpiCardComponent } from '../../shared/components/fees-module/fee-kpi-card.component';
import { FeeStatusBadgeComponent } from '../../shared/components/fees-module/fee-status-badge.component';
import { FeeStateComponent } from '../../shared/components/fees-module/fee-state.component';

export interface Defaulter {
  studentId: number;
  studentName: string;
  rollNumber: string;
  className: string;
  installmentId: number;
  installmentName: string;
  dueDate: string;
  daysOverdue: number;
  amount: number;
  paid: number;
  balance: number;
  lateFee: number;
  totalDue: number;
}

@Component({
  selector: 'app-fee-defaulters',
  standalone: true,
  imports: [
    CommonModule, ReactiveFormsModule, RouterModule,
    MatCardModule, MatTableModule, MatPaginatorModule, MatProgressBarModule,
    MatIconModule, MatButtonModule, MatChipsModule, MatFormFieldModule,
    MatInputModule, MatSelectModule, MatTooltipModule, MatSnackBarModule,
    FeePageHeaderComponent, FeeKpiCardComponent, FeeStatusBadgeComponent, FeeStateComponent
  ],
  template: `
    <div class="defaulters-page compact-screen">
      <app-fee-page-header
        title="Fee Defaulters"
        subtitle="Students with overdue fee installments">
        <ng-container headerActions>
          <a mat-stroked-button routerLink="/app/whatsapp/fee-reminders">
            <mat-icon>chat</mat-icon>
            WhatsApp Reminders
          </a>
        </ng-container>
      </app-fee-page-header>

      <!-- Filters & Actions -->
      <div class="fee-filter-bar" [formGroup]="filterForm">
        <div class="ffe-row">
          <mat-form-field appearance="outline" subscriptSizing="dynamic" class="ffe-field">
            <mat-label>Min Days Overdue</mat-label>
            <mat-select formControlName="minDaysOverdue" (selectionChange)="loadDefaulters()">
              <mat-option [value]="1">1+ days</mat-option>
              <mat-option [value]="7">7+ days</mat-option>
              <mat-option [value]="15">15+ days</mat-option>
              <mat-option [value]="30">30+ days</mat-option>
              <mat-option [value]="60">60+ days</mat-option>
              <mat-option [value]="90">90+ days</mat-option>
            </mat-select>
          </mat-form-field>

          <div class="ffe-actions">
            <button mat-stroked-button (click)="exportCsv()" [disabled]="defaulters().length === 0">
              <mat-icon>download</mat-icon> Export CSV
            </button>

            <button mat-flat-button color="warn" (click)="sendReminders()" [disabled]="loading() || sendingReminders()">
              <mat-icon>notifications_active</mat-icon>
              {{ sendingReminders() ? 'Sending...' : 'Send Reminders' }}
            </button>
          </div>
        </div>
      </div>

      <!-- Summary KPIs -->
      @if (!loading() && summary) {
        <div class="fee-kpi-grid">
          <app-fee-kpi-card icon="groups" tone="danger" [value]="summary.totalCount" label="Defaulter Records"></app-fee-kpi-card>
          <app-fee-kpi-card icon="account_balance_wallet" tone="warn" [value]="'₹' + (summary.totalBalance | number:'1.2-2')" label="Total Outstanding"></app-fee-kpi-card>
          <app-fee-kpi-card icon="timer" tone="warn" [value]="'₹' + (summary.totalLateFee | number:'1.2-2')" label="Late Fees Applicable"></app-fee-kpi-card>
          <app-fee-kpi-card icon="event_busy" tone="neutral" [value]="(summary.avgDaysOverdue | number:'1.0-0') + ' days'" label="Avg Days Overdue"></app-fee-kpi-card>
        </div>
      }

      @if (loading()) {
        <mat-progress-bar mode="indeterminate" class="fee-loading-bar"></mat-progress-bar>
      }

      @if (!loading() && defaulters().length === 0) {
        <app-fee-state
          kind="empty"
          emptyIcon="check_circle"
          title="No Defaulters"
          message="No defaulters found for the selected criteria.">
        </app-fee-state>
      }

      <!-- Defaulter Table -->
      @if (!loading() && defaulters().length > 0) {
        <div class="fee-table-card">
          <div class="fee-table-scroll">
          <table mat-table [dataSource]="defaulters()" class="defaulters-table">

            <ng-container matColumnDef="student">
              <th mat-header-cell *matHeaderCellDef>Student</th>
              <td mat-cell *matCellDef="let d">
                <div class="student-cell">
                  <span class="student-name">{{ d.studentName }}</span>
                  <span class="student-meta">{{ d.rollNumber }} · {{ d.className }}</span>
                </div>
              </td>
            </ng-container>

            <ng-container matColumnDef="installment">
              <th mat-header-cell *matHeaderCellDef>Installment</th>
              <td mat-cell *matCellDef="let d">
                <span>{{ d.installmentName }}</span>
                <span class="due-date">Due: {{ d.dueDate | date:'dd MMM yyyy' }}</span>
              </td>
            </ng-container>

            <ng-container matColumnDef="daysOverdue">
              <th mat-header-cell *matHeaderCellDef class="center-col">Days Overdue</th>
              <td mat-cell *matCellDef="let d" class="center-col">
                <app-fee-status-badge [status]="getOverdueBadgeStatus(d.daysOverdue)"></app-fee-status-badge>
              </td>
            </ng-container>

            <ng-container matColumnDef="amount">
              <th mat-header-cell *matHeaderCellDef class="amount-col">Fee Amount</th>
              <td mat-cell *matCellDef="let d" class="amount-col">₹{{ d.amount | number:'1.2-2' }}</td>
            </ng-container>

            <ng-container matColumnDef="paid">
              <th mat-header-cell *matHeaderCellDef class="amount-col">Paid</th>
              <td mat-cell *matCellDef="let d" class="amount-col paid-col">₹{{ d.paid | number:'1.2-2' }}</td>
            </ng-container>

            <ng-container matColumnDef="balance">
              <th mat-header-cell *matHeaderCellDef class="amount-col">Balance</th>
              <td mat-cell *matCellDef="let d" class="amount-col balance-col">₹{{ d.balance | number:'1.2-2' }}</td>
            </ng-container>

            <ng-container matColumnDef="lateFee">
              <th mat-header-cell *matHeaderCellDef class="amount-col">Late Fee</th>
              <td mat-cell *matCellDef="let d" class="amount-col late-fee-col">₹{{ d.lateFee | number:'1.2-2' }}</td>
            </ng-container>

            <ng-container matColumnDef="totalDue">
              <th mat-header-cell *matHeaderCellDef class="amount-col">Total Due</th>
              <td mat-cell *matCellDef="let d" class="amount-col total-col">
                <strong>₹{{ d.totalDue | number:'1.2-2' }}</strong>
              </td>
            </ng-container>

            <tr mat-header-row *matHeaderRowDef="displayedColumns"></tr>
            <tr mat-row *matRowDef="let row; columns: displayedColumns;" class="defaulter-row"></tr>
          </table>
          </div>

          <mat-paginator
            *ngIf="totalCount() > 0"
            [length]="totalCount()"
            [pageSize]="pageSize"
            [pageSizeOptions]="[10, 20, 50]"
            (page)="onPageChange($event)"
            showFirstLastButtons>
          </mat-paginator>
        </div>
        }
      </div>
  `,
  styles: [`
    .defaulters-page { padding: var(--space-sm) var(--space-sm) calc(var(--bottom-nav-height) + var(--space-lg)); }
    @media (min-width: 768px) { .defaulters-page { padding: var(--space-md) var(--space-lg) var(--space-lg); } }
    .paid-col { color: var(--md-success); }
    .balance-col { color: var(--md-error); font-weight: 500; }
    .late-fee-col { color: var(--md-warning); }
    .total-col { color: var(--md-error); }
    .student-cell { display: flex; flex-direction: column; }
    .student-name { font-weight: 500; }
    .student-meta { font-size: 12px; color: var(--color-text-secondary); }
    .due-date { display: block; font-size: 11px; color: var(--color-text-secondary); }
  `]
})
export class FeeDefaultersComponent implements OnInit {
  defaulters = signal<any[]>([]);
  totalCount = signal(0);
  currentPage = 1;
  pageSize = 20;
  loading = signal(false);
  sendingReminders = signal(false);
  summary: any = null;

  displayedColumns = ['student', 'installment', 'daysOverdue', 'amount', 'paid', 'balance', 'lateFee', 'totalDue'];

  filterForm: FormGroup;

  constructor(
    private feeService: FeeManagementService,
    private fb: FormBuilder,
    private snackBar: MatSnackBar
  ) {
    this.filterForm = this.fb.group({ minDaysOverdue: [1] });
  }

  ngOnInit(): void {
    this.loadDefaulters();
  }

  loadDefaulters(): void {
    this.loading.set(true);
    const minDays = this.filterForm.get('minDaysOverdue')?.value || 1;

    this.feeService.getDefaulterList(this.currentPage, this.pageSize, minDays).subscribe({
      next: (res) => {
        const data = res.data || res;
        this.defaulters.set(data.defaulters || []);
        this.totalCount.set(data.totalCount || 0);
        this.computeSummary();
        this.loading.set(false);
      },
      error: () => {
        this.snackBar.open('Failed to load defaulter list', 'Close', { duration: 3000 });
        this.loading.set(false);
      }
    });
  }

  computeSummary(): void {
    if (!this.defaulters().length) { this.summary = null; return; }
    this.summary = {
      totalCount: this.totalCount(),
      totalBalance: this.defaulters().reduce((s, d) => s + d.balance, 0),
      totalLateFee: this.defaulters().reduce((s, d) => s + d.lateFee, 0),
      avgDaysOverdue: this.defaulters().reduce((s, d) => s + d.daysOverdue, 0) / this.defaulters().length
    };
  }

  onPageChange(e: PageEvent): void {
    this.currentPage = e.pageIndex + 1;
    this.pageSize = e.pageSize;
    this.loadDefaulters();
  }

  getOverdueBadgeStatus(days: number): string {
    if (days >= 60) return 'danger';
    if (days >= 30) return 'warn';
    return 'pending';
  }

  sendReminders(): void {
    this.sendingReminders.set(true);
    this.feeService.sendDueReminders(0).subscribe({
      next: (res) => {
        const sent = res.data?.notificationsSent ?? 0;
        this.snackBar.open(`Sent ${sent} reminders to overdue students`, 'Close', { duration: 4000 });
        this.sendingReminders.set(false);
      },
      error: () => {
        this.snackBar.open('Failed to send reminders', 'Close', { duration: 3000 });
        this.sendingReminders.set(false);
      }
    });
  }

  exportCsv(): void {
    if (!this.defaulters().length) return;
    const headers = ['Student Name', 'Roll Number', 'Class', 'Installment', 'Due Date', 'Days Overdue', 'Amount', 'Paid', 'Balance', 'Late Fee', 'Total Due'];
    const rows = this.defaulters().map(d => [
      d.studentName, d.rollNumber, d.className, d.installmentName,
      d.dueDate, d.daysOverdue, d.amount, d.paid, d.balance, d.lateFee, d.totalDue
    ]);
    const csvContent = [headers, ...rows].map(r => r.join(',')).join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `fee-defaulters-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }
}
