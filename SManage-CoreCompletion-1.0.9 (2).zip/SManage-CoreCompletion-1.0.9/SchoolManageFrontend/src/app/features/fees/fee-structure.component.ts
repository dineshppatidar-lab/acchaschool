import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnInit, TemplateRef, ViewChild, signal } from '@angular/core';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { DialogUtils } from '../../shared/dialog-utils';
import { FeeAssignmentDialogComponent } from '../student-management/fee-assignment-dialog.component';
import { AssignedFeesListComponent } from './assigned-fees-list.component';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatSelectModule } from '@angular/material/select';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { FormsModule, FormControl } from '@angular/forms';
import { Observable, of } from 'rxjs';
import { map, startWith, debounceTime } from 'rxjs/operators';
import { StudentManagementService } from '../../shared/services/student-management.service';
import { StudentFullDetailsDto } from '../../shared/models/student-full-details-dto';
import { FeeManagementService, FeeStructure } from '../../shared/services/fee-management.service';
import { MatTabsModule } from '@angular/material/tabs';
import { MatTableModule } from '@angular/material/table';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatTooltipModule } from '@angular/material/tooltip';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators, FormArray } from '@angular/forms';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatDividerModule } from '@angular/material/divider';
import { MatChipsModule } from '@angular/material/chips';
import { MasterDataService, DropdownItem } from '../../core/services/master-data.service';
import { AcademicService } from '../../services/academic.service';
import { AcademicYearContextService } from '../../shared/services/academic-year-context.service';
import { extractApiErrorMessage } from '../../services/api-response.interceptor';
import { BackButtonComponent } from '../../shared/components/back-button.component';
import { FeeStatusBadgeComponent } from '../../shared/components/fees-module/fee-status-badge.component';

@Component({
  selector: 'app-fee-structure',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    CommonModule, 
    MatCardModule, 
    MatIconModule,    MatSelectModule,
    MatAutocompleteModule,
    MatDialogModule,
    FormsModule,
    MatTabsModule,
    MatTableModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatProgressSpinnerModule,
    MatSnackBarModule,
    MatTooltipModule,
    ReactiveFormsModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatCheckboxModule,
    MatDividerModule,
    MatChipsModule,
    AssignedFeesListComponent,
    BackButtonComponent,
    FeeStatusBadgeComponent
  ],
  templateUrl: './fee-structure.component.html',
  styleUrls: ['./fee-structure.component.scss']
})
export class FeeStructureComponent implements OnInit {
  // Dialog Template Reference
  @ViewChild('feeStructureDialog') feeStructureDialog!: TemplateRef<any>;

  // Students and Assignment
  students = signal<any[]>([]);
  selectedStudentId: number | null = null;
  isLoadingStudents = signal(false);
  studentSearchControl = new FormControl('');
  installmentStudentSearchControl = new FormControl('');
  filteredStudents$!: Observable<StudentFullDetailsDto[]>;
  filteredInstallmentStudents$!: Observable<StudentFullDetailsDto[]>;

  // Fee Structures
  feeStructures = signal<any[]>([]);
  displayedColumns: string[] = ['name', 'className', 'totalAmount', 'isActive', 'actions'];
  isLoadingFeeStructures = signal(false);

  // Form - initialize with default FormGroup
  feeStructureForm: FormGroup;
  isEditMode = signal(false);
  selectedFeeStructure: FeeStructure | null = null;
  isSubmitting = signal(false);

  // Classes (for dropdown - complete list for list-page name lookup)
  classes = signal<any[]>([]);
  isLoadingClasses = signal(false);

  // Classes filtered by the selected Academic Year (for the form dropdown)
  formClasses = signal<any[]>([]);
  isLoadingFormClasses = signal(false);

  // Academic Years (for dropdown)
  academicYears = signal<any[]>([]);
  isLoadingAcademicYears = signal(false);

  // Tab index
  activeTabIndex = 0;

  // Installment Payment Properties
  installmentStudentId: number | null = null;
  pendingInstallments = signal<any[]>([]);
  studentFeeSummary = signal<any>(null);
  isLoadingInstallments = signal(false);
  isProcessingPayment = signal(false);
  private isSyncingInstallments = false;

  /** Paid share of the total fee (0–100) for the summary card progress bar. */
  feePaidPercent(): number {
    const s = this.studentFeeSummary();
    if (!s || !s.totalFees || s.totalFees <= 0) return 0;
    return Math.max(0, Math.min(100, (s.paidAmount / s.totalFees) * 100));
  }

  /** Paid share of a single installment (0–100) for the schedule card progress bar. */
  installmentPaidPercent(installment: any): number {
    if (!installment) return 0;
    const adjusted = installment.adjustedAmount ?? (installment.amount - (installment.discountApplied || 0));
    const paid = installment.paid ?? installment.paidAmount ?? 0;
    if (!adjusted || adjusted <= 0) return paid > 0 ? 100 : 0;
    return Math.max(0, Math.min(100, Math.round((paid / adjusted) * 100)));
  }

  constructor(
    private dialog: MatDialog,
    private dialogUtils: DialogUtils,
    private studentService: StudentManagementService,
    private feeManagementService: FeeManagementService,
    private academicService: AcademicService,
    private formBuilder: FormBuilder,
    private snackBar: MatSnackBar,
    private cdr: ChangeDetectorRef,
    private masterDataService: MasterDataService,
    private yearContext: AcademicYearContextService
  ) {
    // Initialize form immediately to avoid undefined reference
    this.feeStructureForm = this.createFeeStructureForm();
  }

  ngOnInit(): void {
    this.feeStructureForm = this.createFeeStructureForm();
    this.loadStudents();
    this.loadFeeStructures();
    this.loadClasses();
    this.loadAcademicYearsFromContext();
    this.setupFeeInstallmentSync();
    this.setupStudentAutocomplete();

    // Academic Year -> Class dependency: reload the Class dropdown whenever the
    // selected year changes and clear a class that doesn't belong to the new year.
    this.feeStructureForm.get('academicYearId')?.valueChanges.subscribe(yearId => {
      this.loadFormClasses(yearId);
    });
    
    // DEBUG: Log form state after initialization
    setTimeout(() => {
      console.log('=== FEE STRUCTURE FORM DEBUG ===');
      console.log('Form:', this.feeStructureForm);
      console.log('Form Valid:', this.feeStructureForm.valid);
      console.log('Form Disabled:', this.feeStructureForm.disabled);
      console.log('Installments Array:', this.installmentsArray);
      console.log('Installments Controls:', this.installmentsArray.controls);
      this.installmentsArray.controls.forEach((ctrl, idx) => {
        console.log(`Installment ${idx}:`, ctrl);
        console.log(`  - Valid: ${ctrl.valid}`);
        console.log(`  - Disabled: ${ctrl.disabled}`);
        Object.keys((ctrl as FormGroup).controls).forEach(key => {
          const field = (ctrl as FormGroup).get(key);
          console.log(`    ${key}: valid=${field?.valid}, disabled=${field?.disabled}, value=${field?.value}`);
        });
      });
    }, 500);
  }

  /**
   * Create fee structure form
   */
  private createFeeStructureForm(): FormGroup {
    return this.formBuilder.group({
      name: ['', [Validators.required, Validators.minLength(3)]],
      classId: ['', Validators.required],
      academicYearId: ['', Validators.required],
      annualFee: [0, Validators.min(0)],
      registrationFee: [0, Validators.min(0)],
      transportFee: [0, Validators.min(0)],
      uniformFee: [0, Validators.min(0)],
      examinationFee: [0, Validators.min(0)],
      libraryFee: [0, Validators.min(0)],
      computerFee: [0, Validators.min(0)],
      laboratoryFee: [0, Validators.min(0)],
      sportsFee: [0, Validators.min(0)],
      miscellaneousFee: [0, Validators.min(0)],
      installments: this.formBuilder.array([
        this.createInstallmentForm()  // Add one default installment
      ], [Validators.required, Validators.minLength(1)]),
      isActive: [true]
    });
  }

  /**
   * Create individual installment form group
   */
  private createInstallmentForm(): FormGroup {
    return this.formBuilder.group({
      id: [0],  // 0 = new row (backend decides on update)
      name: [''],  // No validators - will auto-generate as "Installation 1", etc.
      amount: [''],  // No validators - will validate at submit time
      dueDate: [''],  // No validators - will auto-fill with today's date if empty
      lateFee: [0, Validators.min(0)],
      gracePeriodDays: [0, Validators.min(0)]
    });
  }

  /**
   * Get installments FormArray
   */
  get installmentsArray(): FormArray {
    return this.feeStructureForm.get('installments') as FormArray;
  }

  /**
   * Get installments form controls with index
   */
  getInstallmentsControls(): any[] {
    return this.installmentsArray.controls.map((control, index) => ({
      control,
      index
    }));
  }

  /**
   * Stable trackBy for the installments *ngFor. Without this, Angular's differ
   * treats every wrapper object as new on each change-detection run and rebuilds
   * the installment rows -> focused inputs are destroyed mid-typing ('can't type').
   */
  trackByInstallmentControl(index: number, control: any): any {
    return control?.id ?? index;
  }

  getFeeAmountTotal(): number {
    return [
      'annualFee',
      'registrationFee',
      'transportFee',
      'uniformFee',
      'examinationFee',
      'libraryFee',
      'computerFee',
      'laboratoryFee',
      'sportsFee',
      'miscellaneousFee'
    ].reduce((total, field) => {
      const value = this.feeStructureForm.get(field)?.value;
      return total + (value == null ? 0 : Number(value));
    }, 0);
  }

  private setupFeeInstallmentSync(): void {
    const feeFields = [
      'annualFee',
      'registrationFee',
      'transportFee',
      'uniformFee',
      'examinationFee',
      'libraryFee',
      'computerFee',
      'laboratoryFee',
      'sportsFee',
      'miscellaneousFee'
    ];

    feeFields.forEach(field => {
      this.feeStructureForm.get(field)?.valueChanges.subscribe(() => {
        this.syncInstallmentAmountsToFeeTotal();
      });
    });
  }

  private syncInstallmentAmountsToFeeTotal(): void {
    if (this.isSyncingInstallments) {
      return;
    }

    const installmentCount = this.installmentsArray.length;
    if (installmentCount === 0) {
      return;
    }

    const totalFee = this.getFeeAmountTotal();
    const currentSum = this.installmentsArray.controls.reduce((sum, control) => {
      const amount = Number(control.get('amount')?.value) || 0;
      return sum + amount;
    }, 0);

    if (currentSum === totalFee || totalFee === 0) {
      return;
    }

    this.isSyncingInstallments = true;
    try {
      if (currentSum === 0) {
        const baseValue = Math.floor((totalFee / installmentCount) * 100) / 100;
        let allocated = 0;

        this.installmentsArray.controls.forEach((control, index) => {
          if (index === installmentCount - 1) {
            control.patchValue({ amount: totalFee - allocated }, { emitEvent: false });
          } else {
            control.patchValue({ amount: baseValue }, { emitEvent: false });
            allocated += baseValue;
          }
        });
      } else {
        let allocated = 0;
        this.installmentsArray.controls.forEach((control, index) => {
          const currentAmount = Number(control.get('amount')?.value) || 0;
          if (index === installmentCount - 1) {
            control.patchValue({ amount: totalFee - allocated }, { emitEvent: false });
          } else {
            const nextValue = Math.round((currentAmount / currentSum) * totalFee * 100) / 100;
            control.patchValue({ amount: nextValue }, { emitEvent: false });
            allocated += nextValue;
          }
        });
      }
    } finally {
      this.isSyncingInstallments = false;
    }
  }

  /**
   * Add a new installment to the form
   */
  addInstallment(): void {
    this.installmentsArray.push(this.createInstallmentForm());
    this.syncInstallmentAmountsToFeeTotal();
    this.cdr.markForCheck();
  }

  /**
   * Remove installment from the form
   */
  removeInstallment(index: number): void {
    if (this.installmentsArray.length > 1) {
      this.installmentsArray.removeAt(index);
      this.syncInstallmentAmountsToFeeTotal();
      this.cdr.markForCheck();
    } else {
      this.snackBar.open('At least one installment is required', 'Close', { duration: 3000 });
    }
  }

  /**
   * Calculate total of all installments
   */
  getInstallmentsTotal(): number {
    return this.installmentsArray.controls.reduce((sum, control) => {
      const amount = (control.get('amount')?.value || 0);
      return sum + amount;
    }, 0);
  }

  /**
   * Load students list
   */
  private loadStudents(): void {
    this.isLoadingStudents.set(true);
    this.studentService.getAllStudentFullDetails('', 1, 1000).subscribe({
      next: (students: StudentFullDetailsDto[]) => {
        this.students.set(students);
        this.isLoadingStudents.set(false);
        // Trigger re-filter after students load
        this.studentSearchControl.setValue(typeof this.studentSearchControl.value === 'string' ? this.studentSearchControl.value : '');
        this.installmentStudentSearchControl.setValue(typeof this.installmentStudentSearchControl.value === 'string' ? this.installmentStudentSearchControl.value : '');
        this.cdr.markForCheck();
      },
      error: (error) => {
        console.error('Error loading students:', error);
        this.snackBar.open('Failed to load students', 'Close', { duration: 5000 });
        this.isLoadingStudents.set(false);
        this.cdr.markForCheck();
      }
    });
  }

  /**
   * Load fee structures
   */
  private loadFeeStructures(): void {
    console.log('🔄 Starting to load fee structures...');
    this.isLoadingFeeStructures.set(true);
    this.feeStructures.set([]); // Clear existing data
    this.cdr.markForCheck();
    
    this.feeManagementService.getAllFeeStructures().subscribe({
      next: (structures: FeeStructure[]) => {
        console.log('✅ Fee structures loaded successfully. Count:', structures?.length || 0);
        console.log('📊 Structures data:', structures);
        
        // Ensure array is set correctly
        this.feeStructures.set(Array.isArray(structures) ? structures : []);
        console.log('✅ FeeStructures array updated:', this.feeStructures());
        
        this.isLoadingFeeStructures.set(false);
        this.cdr.markForCheck();
        
        // Force another change detection after short delay
        setTimeout(() => {
          this.cdr.markForCheck();
        }, 100);
      },
      error: (error: any) => {
        console.error('❌ Error loading fee structures:', {
          status: error?.status,
          statusText: error?.statusText,
          message: error?.message,
          error: error?.error,
          url: error?.url,
          fullError: error
        });
        
        const errorMsg = error?.error?.message || error?.message || 'Failed to load fee structures';
        this.snackBar.open(errorMsg, 'Close', { duration: 5000 });
        this.feeStructures.set([]); // Set to empty array on error
        this.isLoadingFeeStructures.set(false);
        this.cdr.markForCheck();
      }
    });
  }

  /**
   * Load ALL classes for list-page name lookup (unpaginated endpoint).
   * The old paginated `getAll()` returned only the first 10 classes, which made
   * class names show as 'N/A' for fee structures outside that first page.
   */
  private loadClasses(): void {
    this.isLoadingClasses.set(true);
    this.academicService.getAllClasses().subscribe({
      next: (classes: any[]) => {
        this.classes.set(Array.isArray(classes) ? classes : []);
        this.isLoadingClasses.set(false);
        this.cdr.markForCheck();
      },
      error: (error) => {
        console.error('Error loading classes:', error);
        this.isLoadingClasses.set(false);
        this.cdr.markForCheck();
      }
    });
  }

  /**
   * Load classes that belong to the given academic year for the form dropdown.
   * Optionally restores a previously selected class after loading (edit mode).
   * Clears the current selection if the class doesn't belong to the year.
   */
  private loadFormClasses(yearId: number | string | null, classIdToRestore?: number | string | null): void {
    if (!yearId) {
      this.formClasses.set([]);
      this.isLoadingFormClasses.set(false);
      this.feeStructureForm.patchValue({ classId: '' }, { emitEvent: false });
      this.cdr.markForCheck();
      return;
    }

    this.isLoadingFormClasses.set(true);
    this.cdr.markForCheck();

    this.academicService.getClassesByAcademicYear(+yearId).subscribe({
      next: (classes: any[]) => {
        this.formClasses.set(Array.isArray(classes) ? classes : []);
        this.isLoadingFormClasses.set(false);

        const currentValue = this.feeStructureForm.get('classId')?.value;
        if (classIdToRestore != null && this.formClasses().some(c => +c.id === +classIdToRestore)) {
          // Edit mode: re-select the record's class now that its year's classes are loaded
          this.feeStructureForm.patchValue({ classId: +classIdToRestore }, { emitEvent: false });
        } else if (currentValue && !this.formClasses().some(c => +c.id === +currentValue)) {
          // Selected class doesn't belong to the newly chosen year -> clear it
          this.feeStructureForm.patchValue({ classId: '' }, { emitEvent: false });
        }
        this.cdr.markForCheck();
      },
      error: (error) => {
        console.error('Error loading classes for academic year:', error);
        this.formClasses.set([]);
        this.isLoadingFormClasses.set(false);
        this.cdr.markForCheck();
      }
    });
  }

  /**
   * Get formatted name for display.
   * The setup wizard could persist rows literally named "Fee Structure for
   * Unknown (...)" (stale class list at creation time), so prefer resolving
   * the display name from the row's ClassId/AcademicYearId whenever the stored
   * name is empty or contains "Unknown".
   */
  getDisplayName(element: FeeStructure): string {
    if (!element) return 'Unnamed Fee Structure';

    const classId = (element as any).classId ?? (element as any).ClassId;
    const yearId = (element as any).academicYearId ?? (element as any).AcademicYearId;
    const className = this.getClassName(classId);
    const yearName = this.getAcademicYearName(yearId);

    const storedName: string = element.name || '';
    const nameIsBad = !storedName.trim() || storedName.toLowerCase().includes('unknown');

    if (nameIsBad) {
      if (className !== 'N/A') {
        return `Fee Structure for ${className} (${yearName})`;
      }
      return storedName.trim() || 'Unnamed Fee Structure';
    }

    return storedName;
  }

  /**
   * Load academic years from centralized context service
   */
  private loadAcademicYearsFromContext(): void {
    this.yearContext.loadAcademicYears().subscribe({
      next: () => {
        this.academicYears.set(this.yearContext.yearsSnapshot.map(y => ({ id: y.id, name: y.name })));
        this.isLoadingAcademicYears.set(false);
        // Pre-fill the form with the selected year from context
        const selectedId = this.yearContext.selectedYearId;
        if (selectedId) {
          this.feeStructureForm.patchValue({ academicYearId: selectedId });
        }
        this.cdr.markForCheck();
      },
      error: () => {
        this.isLoadingAcademicYears.set(false);
        this.cdr.markForCheck();
      }
    });
  }

  /**
   * Get academic year name by ID
   */
  getAcademicYearName(yearId: number): string {
    const year = this.academicYears().find(y => +y.id === +yearId);
    return year ? year.name : 'N/A';
  }

  /**
   * Handle opening fee assignment dialog
   */
  openFeeAssignmentDialog(): void {
    const student = this.students().find(s => s.id === this.selectedStudentId);
    if (!student) {
      this.snackBar.open('Please select a student', 'Close', { duration: 3000 });
      return;
    }
    this.dialog.open(FeeAssignmentDialogComponent, {...this.dialogUtils.getMobileConfig(),
      data: {
        studentId: student.id,
        studentName: student.firstName + ' ' + student.lastName,
        classId: student.classId
      }
    });
  }

  /**
   * Submit fee structure form (create or update)
   */
  submitFeeStructure(): void {
    // Validate required fields at submit time
    if (!this.feeStructureForm.get('name')?.value || this.feeStructureForm.get('name')?.value.trim() === '') {
      this.snackBar.open('Fee structure name is required', 'Close', { duration: 3000 });
      return;
    }
    if (!this.feeStructureForm.get('classId')?.value) {
      this.snackBar.open('Please select a class', 'Close', { duration: 3000 });
      return;
    }
    if (!this.feeStructureForm.get('academicYearId')?.value) {
      this.snackBar.open('Please select an academic year', 'Close', { duration: 3000 });
      return;
    }

    // Validate installments
    const installments = this.feeStructureForm.get('installments') as FormArray;
    if (!installments.value || installments.value.length === 0) {
      this.snackBar.open('At least one installment is required', 'Close', { duration: 3000 });
      return;
    }

    // Get today's date for default (as ISO string)
    const todayDate = new Date().toISOString().split('T')[0]; // Format: YYYY-MM-DD

    // Validate and process each installment
    for (let i = 0; i < installments.value.length; i++) {
      const inst = installments.at(i) as FormGroup;
      
      // Generate dynamic name if empty or null
      if (!inst.get('name')?.value || inst.get('name')?.value.trim() === '') {
        inst.patchValue({ name: `Installation ${i + 1}` });
      }

      // Set today's date if due date is empty or null
      if (!inst.get('dueDate')?.value) {
        inst.patchValue({ dueDate: todayDate });
      }

      // Validate amount is required and > 0
      const amount = inst.value.amount;
      if (!amount || amount <= 0) {
        this.snackBar.open(`Installment ${i + 1}: Amount must be greater than 0`, 'Close', { duration: 3000 });
        return;
      }
    }

    // Business rule: installment amounts must total exactly the configured fee
    const totalFee = this.getFeeAmountTotal();
    const installmentSum = installments.controls.reduce((sum, c) => sum + (Number(c.get('amount')?.value) || 0), 0);
    if (totalFee <= 0) {
      this.snackBar.open('Total fee amount must be greater than 0', 'Close', { duration: 3000 });
      return;
    }
    if (installmentSum !== totalFee) {
      const diff = installmentSum - totalFee;
      const msg = diff > 0
        ? `Installment total (₹${installmentSum.toFixed(2)}) exceeds the fee total (₹${totalFee.toFixed(2)}) by ₹${diff.toFixed(2)}.`
        : `Installment total (₹${installmentSum.toFixed(2)}) is short of the fee total (₹${totalFee.toFixed(2)}) by ₹${Math.abs(diff).toFixed(2)}.`;
      this.snackBar.open(`${msg} Installments must total exactly the fee amount.`, 'Close', { duration: 6000 });
      return;
    }

    this.isSubmitting.set(true);
    this.cdr.markForCheck();
    
    // Get form value and ensure correct data types
    const formValue = this.feeStructureForm.value;
    
    const toNumber = (v: any): number => {
      if (v === '' || v == null) return 0;
      const n = Number(v);
      return Number.isFinite(n) ? n : 0;
    };

    // Convert dates to ISO string format for installments and coerce numerics.
    // Form inputs yield STRINGS; System.Text.Json cannot bind JSON string -> decimal,
    // which made every update fail backend model validation with a generic message.
    const feeComponents = ['annualFee', 'registrationFee', 'transportFee', 'uniformFee', 'examinationFee',
      'libraryFee', 'computerFee', 'laboratoryFee', 'sportsFee', 'miscellaneousFee'];
    const processedInstallments = (Array.isArray(formValue.installments) ? formValue.installments : []).map((inst: any) => ({
      id: toNumber(inst.id),  // existing row id (0 = new)
      name: inst.name,
      amount: toNumber(inst.amount),
      dueDate: inst.dueDate instanceof Date ? inst.dueDate.toISOString().split('T')[0] : inst.dueDate,
      lateFee: toNumber(inst.lateFee),
      gracePeriodDays: toNumber(inst.gracePeriodDays)
    }));
    
    const request: any = {
      ...formValue,
      classId: parseInt(formValue.classId, 10),
      academicYearId: parseInt(formValue.academicYearId, 10),
      installments: processedInstallments
    };
    feeComponents.forEach(f => request[f] = toNumber(formValue[f]));
    
    console.log('Submitting fee structure:', request);

    if (this.isEditMode() && this.selectedFeeStructure?.id) {
      // Update
      this.feeManagementService.updateFeeStructure(this.selectedFeeStructure.id, request).subscribe({
        next: () => {
          this.snackBar.open('Fee structure updated successfully', 'Close', { duration: 3000 });
          this.loadFeeStructures();
          this.resetForm();
          this.isSubmitting.set(false);
          this.cdr.markForCheck();
        },
        error: (error) => {
          console.error('Error updating fee structure:', error);
          const errorMsg = extractApiErrorMessage(error?.error) || error?.message || 'Failed to update fee structure';
          this.snackBar.open(errorMsg, 'Close', { duration: 5000 });
          this.isSubmitting.set(false);
          this.cdr.markForCheck();
        }
      });
    } else {
      // Create
      this.feeManagementService.createFeeStructure(request).subscribe({
        next: () => {
          this.snackBar.open('Fee structure created successfully', 'Close', { duration: 3000 });
          this.loadFeeStructures();
          this.resetForm();
          this.isSubmitting.set(false);
          this.cdr.markForCheck();
        },
        error: (error) => {
          console.error('Error creating fee structure:', error);
          const errorMsg = extractApiErrorMessage(error?.error) || error?.message || 'Failed to create fee structure';
          this.snackBar.open(errorMsg, 'Close', { duration: 5000 });
          this.isSubmitting.set(false);
          this.cdr.markForCheck();
        }
      });
    }
  }

  /**
   * Open Fee Structure Dialog for Add/Edit
   */
  openFeeStructureDialog(feeStructure?: FeeStructure): void {
    // Reset form while keeping the same FormGroup instance so subscriptions remain active.
    // NOTE: resetForm() clears selectedFeeStructure and isEditMode — the edit target must
    // be assigned AFTER it, or submit decides update vs create with a null target and
    // silently falls into the create branch (duplicated fee structures on every edit).
    this.resetForm();
    this.selectedFeeStructure = feeStructure || null;
    this.isEditMode.set(!!feeStructure);
    this.feeStructureForm.enable({ emitEvent: false });
    this.installmentsArray.controls.forEach(control => control.enable({ emitEvent: false }));
    
    if (feeStructure) {
      const editClassId = (feeStructure as any).classId ?? (feeStructure as any).ClassId;
      const editYearId = (feeStructure as any).academicYearId ?? (feeStructure as any).AcademicYearId;

      // Populate form with existing fee structure data.
      // classId is restored by loadFormClasses once the year's classes arrive.
      this.feeStructureForm.patchValue({
        name: feeStructure.name,
        academicYearId: editYearId,
        annualFee: feeStructure.annualFee || 0,
        registrationFee: feeStructure.registrationFee || 0,
        transportFee: feeStructure.transportFee || 0,
        uniformFee: feeStructure.uniformFee || 0,
        examinationFee: feeStructure.examinationFee || 0,
        libraryFee: feeStructure.libraryFee || 0,
        computerFee: feeStructure.computerFee || 0,
        laboratoryFee: feeStructure.laboratoryFee || 0,
        sportsFee: feeStructure.sportsFee || 0,
        miscellaneousFee: feeStructure.miscellaneousFee || 0,
        isActive: feeStructure.isActive
      }, { emitEvent: false });

      // Load the edit year's classes, then re-select the record's class
      this.loadFormClasses(editYearId, editClassId);

      // Clear and populate installments
      const installmentsArray = this.installmentsArray;
      while (installmentsArray.length) {
        installmentsArray.removeAt(0);
      }

      if (feeStructure.installments && feeStructure.installments.length > 0) {
        feeStructure.installments.forEach((installment: any) => {
          // Convert date to string format (YYYY-MM-DD)
          let dueDateValue = '';
          if (installment.dueDate) {
            if (installment.dueDate instanceof Date) {
              dueDateValue = installment.dueDate.toISOString().split('T')[0];
            } else if (typeof installment.dueDate === 'string') {
              dueDateValue = installment.dueDate.split('T')[0]; // Remove time part if present
            }
          }
          
          installmentsArray.push(this.formBuilder.group({
            id: [installment.id || 0],  // Existing row id: lets backend update in place
            name: [installment.name || ''],
            amount: [installment.amount || ''],
            dueDate: [dueDateValue],
            lateFee: [installment.lateFee || 0, Validators.min(0)],
            gracePeriodDays: [installment.gracePeriodDays || 0, Validators.min(0)]
          }));
        });
      } else {
        this.addInstallment();
      }
    }

    // Open dialog
    this.dialog.open(this.feeStructureDialog, {...this.dialogUtils.getMobileConfig(),
      width: '900px',
      maxHeight: '90vh',
      disableClose: false,
      panelClass: 'fee-structure-dialog'
    });
  }

  /**
   * Edit fee structure (use dialog popup)
   */
  editFeeStructure(feeStructure: FeeStructure): void {
    this.openFeeStructureDialog(feeStructure);
  }

  /**
   * Delete fee structure
   */
  deleteFeeStructure(feeStructure: FeeStructure): void {
    if (!confirm(`Are you sure you want to delete "${feeStructure.name}"?`)) {
      return;
    }

    if (!feeStructure.id) return;
    this.feeManagementService.deleteFeeStructure(feeStructure.id).subscribe({
      next: () => {
        this.snackBar.open('Fee structure deleted successfully', 'Close', { duration: 3000 });
        this.loadFeeStructures();
      },
      error: (error) => {
        console.error('Error deleting fee structure:', error);
        this.snackBar.open('Failed to delete fee structure', 'Close', { duration: 5000 });
        this.cdr.markForCheck();
      }
    });
  }

  /**
   * Reset form to create new fee structure
   */
  resetForm(): void {
    this.isEditMode.set(false);
    this.selectedFeeStructure = null;
    this.feeStructureForm.reset({
      isActive: true,
      annualFee: 0,
      registrationFee: 0,
      transportFee: 0,
      uniformFee: 0,
      examinationFee: 0,
      libraryFee: 0,
      computerFee: 0,
      laboratoryFee: 0,
      sportsFee: 0,
      miscellaneousFee: 0
    });
    
    // Reset installments to one default form
    const installmentsArray = this.installmentsArray;
    while (installmentsArray.length) {
      installmentsArray.removeAt(0);
    }
    installmentsArray.push(this.createInstallmentForm());
    installmentsArray.controls.forEach(control => control.enable({ emitEvent: false }));
    
    this.cdr.markForCheck();
  }

  /**
   * Calculate total fee amount
   */
  calculateTotalAmount(feeStructure: FeeStructure): number {
    return (
      (feeStructure.annualFee || 0) +
      (feeStructure.registrationFee || 0) +
      (feeStructure.transportFee || 0) +
      (feeStructure.uniformFee || 0) +
      (feeStructure.examinationFee || 0) +
      (feeStructure.libraryFee || 0) +
      (feeStructure.computerFee || 0) +
      (feeStructure.laboratoryFee || 0) +
      (feeStructure.sportsFee || 0) +
      (feeStructure.miscellaneousFee || 0)
    );
  }

  /**
   * Get class name by ID
   */
  getClassName(classId: number): string {
    const cls = this.classes().find(c => +c.id === +classId);
    return cls ? cls.name : 'N/A';
  }

  /**
   * Get selected student object
   */
  getSelectedStudent(): StudentFullDetailsDto | undefined {
    return this.students().find(s => s.id === this.selectedStudentId);
  }

  displayStudentName(student: StudentFullDetailsDto): string {
    if (!student) return '';
    const roll = student.rollNumber ? ` (${student.rollNumber})` : '';
    return `${student.firstName} ${student.lastName}${roll}`;
  }

  onFeeTabStudentSelected(event: any): void {
    const student = event.option.value as StudentFullDetailsDto;
    if (student) this.selectedStudentId = student.id;
  }

  onInstallmentTabStudentSelected(event: any): void {
    const student = event.option.value as StudentFullDetailsDto;
    if (student) {
      this.installmentStudentId = student.id;
      this.loadStudentInstallments();
    }
  }

  private setupStudentAutocomplete(): void {
    this.filteredStudents$ = this.studentSearchControl.valueChanges.pipe(
      startWith(''),
      debounceTime(300),
      map(val => this.filterStudents(val || ''))
    );
    this.filteredInstallmentStudents$ = this.installmentStudentSearchControl.valueChanges.pipe(
      startWith(''),
      debounceTime(300),
      map(val => this.filterStudents(val || ''))
    );
  }

  private filterStudents(searchStr: string): StudentFullDetailsDto[] {
    const str = typeof searchStr === 'string' ? searchStr : '';
    const q = str.toLowerCase().trim();
    // Require typed text (same behavior as the fees dashboard and other
    // pages): don't dump the entire student list into the dropdown on focus.
    if (q.length < 2) return [];
    return this.students().filter(s =>
      `${s.firstName} ${s.lastName}`.toLowerCase().includes(q) ||
      (s.rollNumber || '').toLowerCase().includes(q) ||
      (s.className || '').toLowerCase().includes(q)
    );
  }

  /** 'No students found' only once the user actually typed a search (≥2 chars). */
  showNoStudents(query: any): boolean {
    return typeof query === 'string' && query.trim().length >= 2;
  }

  /**
   * Load student installments
   */
  loadStudentInstallments(): void {
    if (!this.installmentStudentId) {
      this.pendingInstallments.set([]);
      this.studentFeeSummary.set(null);
      this.cdr.markForCheck();
      return;
    }

    this.isLoadingInstallments.set(true);
    this.cdr.markForCheck();

    // Load outstanding fees (summary) and installments in parallel
    this.feeManagementService.getOutstandingFees(this.installmentStudentId).subscribe({
      next: (response: any) => {
        const data = response.data || response;
        this.studentFeeSummary.set(data);
        
        // Also load all installments for this student
        this.loadFeeInstallmentsForStudent(this.installmentStudentId!);
      },
      error: (error) => {
        console.error('Error loading outstanding fees:', error);
        this.snackBar.open('Failed to load fee summary', 'Close', { duration: 3000 });
        this.isLoadingInstallments.set(false);
        this.cdr.markForCheck();
      }
    });
  }

  /**
   * Load fee installments for a specific student
   */
  private loadFeeInstallmentsForStudent(studentId: number): void {
    this.feeManagementService.getStudentInstallments(studentId).subscribe({
      next: (response: any) => {
        const data = Array.isArray(response) ? response : (response.data || response);
        this.pendingInstallments.set(this.filterPendingInstallments(data));
        this.isLoadingInstallments.set(false);
        this.cdr.markForCheck();
      },
      error: (error) => {
        console.error('Error loading installments:', error);
        this.snackBar.open('Failed to load installments', 'Close', { duration: 3000 });
        this.isLoadingInstallments.set(false);
        this.cdr.markForCheck();
      }
    });
  }

  /**
   * Filter out inactive installments (but keep paid ones for history/status)
   */
  private filterPendingInstallments(installments: any[]): any[] {
    // We want to show all active installments, even if paid, so user sees the "Paid" status
    return (installments || []).filter(inst => inst.isActive !== false);
  }

  /**
   * Check if installment is already paid
   */
  isInstallmentPaid(installment: any): boolean {
    // Check various possible properties for "paid" status
    if (installment.status?.toLowerCase() === 'paid') return true;
    if (installment.status?.toLowerCase() === 'completed') return true;
    
    // If we have paidAmount and amount fields
    const amount = installment.amount || 0;
    const paidAmount = installment.paidAmount || 0;
    if (amount > 0 && paidAmount >= amount) return true;
    
    return false;
  }

  /**
   * Check if installment is overdue
   */
  isInstallmentOverdue(installment: any): boolean {
    if (this.isInstallmentPaid(installment)) return false;
    if (!installment.dueDate) return false;
    
    const dueDate = new Date(installment.dueDate);
    return new Date() > dueDate;
  }

  /**
   * Get days overdue for installment
   */
  getDaysOverdue(installment: any): number {
    if (!installment.dueDate) return 0;
    const dueDate = new Date(installment.dueDate);
    const today = new Date();
    const diffTime = today.getTime() - dueDate.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return Math.max(0, diffDays);
  }

  /**
   * Process installment payment
   */
  payInstallment(installment: any): void {
    if (!this.installmentStudentId) return;

    const student = this.students().find(s => s.id === this.installmentStudentId);
    if (!student) return;

    // Validate amount
    if (!installment.amount || installment.amount <= 0) {
      this.snackBar.open('Amount must be greater than 0', 'Close', { duration: 3000 });
      return;
    }

    // if (installment.amount > (this.studentFeeSummary()?.outstandingAmount || 0)) {
    //   this.snackBar.open('Amount cannot exceed outstanding fees', 'Close', { duration: 3000 });
    //   return;
    // }

    this.isProcessingPayment.set(true);
    this.cdr.markForCheck();

    const paymentRequest = {
      studentId: this.installmentStudentId,
      studentName: `${student.firstName} ${student.lastName}`,
      studentEmail: student.email || '',
      feeInstallmentId: installment.id || installment.installmentId,  // Handle both property names
      amountPaid: installment.amount,
      paymentMethod: 5,  // OnlineTransfer enum value (not string 'Online')
      transactionId: `TXN_${Date.now()}`,  // Generate transaction ID
      remarks: `Payment for installment: ${installment.name}`
    };

    console.log('Processing installment payment:', paymentRequest);

    this.feeManagementService.processInstallmentPayment(paymentRequest).subscribe({
      next: (response: any) => {
        this.snackBar.open(`Payment of ₹${installment.amount} processed successfully`, 'Close', { duration: 3000 });
        this.isProcessingPayment.set(false);
        // Reload the installments to reflect the change
        this.loadStudentInstallments();
      },
      error: (error) => {
        console.error('Error processing payment:', error);
        const errorMsg = error?.error?.message || 'Failed to process payment';
        this.snackBar.open(errorMsg, 'Close', { duration: 5000 });
        this.isProcessingPayment.set(false);
        this.cdr.markForCheck();
      }
    });
  }
}
