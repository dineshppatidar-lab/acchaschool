import { ChangeDetectorRef, Component, OnInit, computed, signal } from '@angular/core';
import { FeesService, Fee } from '../../services/fees.service';
import { CommonModule } from '@angular/common';
import { MatTableModule } from '@angular/material/table';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatChipsModule } from '@angular/material/chips';
import { MatMenuModule } from '@angular/material/menu';
import { MatDialogModule } from '@angular/material/dialog';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSortModule } from '@angular/material/sort';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatDividerModule } from '@angular/material/divider';
import { Router, RouterModule } from '@angular/router';
import { ReactiveFormsModule, FormControl } from '@angular/forms';
import { Observable, combineLatest } from 'rxjs';
import { map, startWith, debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { MasterDataService } from '../../services/master-data.service';
import { DailyOpsService, FeeReminderRequest } from '../../services/daily-ops.service';
import { HttpClient } from '@angular/common/http';
import { CanWriteDirective, CanDeleteDirective } from '../../core/directives/permission.directive';
import { Permission } from '../../core/models/permission.model';
import { FeePageHeaderComponent } from '../../shared/components/fees-module/fee-page-header.component';
import { FeeFilterPanelComponent } from '../../shared/components/fees-module/fee-filter-panel.component';
import { FeeStatusBadgeComponent } from '../../shared/components/fees-module/fee-status-badge.component';
import { FeeStateComponent } from '../../shared/components/fees-module/fee-state.component';

@Component({
  selector: 'app-fees-list',
  standalone: true,
  imports: [
    CommonModule,
    MatTableModule,
    MatButtonModule, 
    MatIconModule, 
    MatCardModule, 
    MatFormFieldModule, 
    MatInputModule, 
    MatSelectModule, 
    MatChipsModule, 
    MatMenuModule, 
    MatDialogModule, 
    MatSnackBarModule, 
    MatPaginatorModule, 
    MatSortModule, 
    MatProgressSpinnerModule, 
    MatTooltipModule, 
    MatDatepickerModule,
    MatDividerModule,
    RouterModule, 
    ReactiveFormsModule,
    CanWriteDirective,
    CanDeleteDirective,
    FeePageHeaderComponent,
    FeeFilterPanelComponent,
    FeeStatusBadgeComponent,
    FeeStateComponent
  ],
  templateUrl: './fees-list.component.html',
  styleUrls: ['./fees-list.component.scss']
})
export class FeesListComponent implements OnInit {
  Permission = Permission;
  fees$?: Observable<Fee[]>;
  filteredFees$?: Observable<Fee[]>;
  displayedColumns: string[] = ['student', 'feeType', 'amount', 'dueDate', 'status', 'paymentDate', 'actions'];
  
  // View Controls
  viewMode: 'card' | 'table' = 'card';
  isLoading = signal(false);
  
  // Filter Controls
  searchControl = new FormControl('');
  typeFilterControl = new FormControl('');
  statusFilterControl = new FormControl('');
  monthFilterControl = new FormControl('');
  
  // Fee Types and Statuses
  feeTypes$!: Observable<any[]>;
  feeStatuses$!: Observable<any[]>;
  feeTypes = signal<any[]>([]);
  feeStatuses = signal<any[]>([]);
  readonly months = [
    { value: 1, name: 'January' },
    { value: 2, name: 'February' },
    { value: 3, name: 'March' },
    { value: 4, name: 'April' },
    { value: 5, name: 'May' },
    { value: 6, name: 'June' },
    { value: 7, name: 'July' },
    { value: 8, name: 'August' },
    { value: 9, name: 'September' },
    { value: 10, name: 'October' },
    { value: 11, name: 'November' },
    { value: 12, name: 'December' }
  ];

  // Statistics
  totalFees: number = 0;
  paidAmount: number = 0;
  pendingAmount: number = 0;
  overdueCount: number = 0;
  allFees = signal<any[]>([]);

  constructor(
    private feesService: FeesService, 
    public router: Router, 
    private cdr: ChangeDetectorRef,
    private masterDataService: MasterDataService,
    private dailyOpsService: DailyOpsService,
    private snackBar: MatSnackBar,
    private http: HttpClient
  ) {}

  ngOnInit() {
    this.loadFees();
    this.loadLookups();
    this.setupFiltering();
  }

  loadFees() {
    this.isLoading.set(true);
    this.fees$ = this.feesService.getAll();
    this.fees$.subscribe({
      next: (data) => {
        this.allFees.set(data);
        this.calculateStatistics();
        setTimeout(() => {
          this.isLoading.set(false);
          this.cdr.markForCheck();
        });
      },
      error: (err) => {
        console.error('Error loading fees:', err);
        setTimeout(() => {
          this.isLoading.set(false);
          this.cdr.markForCheck();
        });
      }
    });
  }

  loadLookups(): void {
    this.feeTypes$ = this.masterDataService.getFeeTypes();
    this.feeTypes$.subscribe(res => {
      this.feeTypes.set(res || []);
    });

    this.feeStatuses$ = this.masterDataService.getFeeStatuses();
    this.feeStatuses$.subscribe(res => {
      this.feeStatuses.set(res || []);
    });
  }

  setupFiltering() {
    if (!this.fees$) return;

    this.filteredFees$ = combineLatest([
      this.fees$,
      this.searchControl.valueChanges.pipe(startWith(''), debounceTime(300), distinctUntilChanged()),
      this.typeFilterControl.valueChanges.pipe(startWith('')),
      this.statusFilterControl.valueChanges.pipe(startWith('')),
      this.monthFilterControl.valueChanges.pipe(startWith(''))
    ]).pipe(
      map(([fees, search, type, status, month]) => {
        return fees.filter(fee => {
          const matchesSearch = !search || 
            fee.studentId?.toString().includes(search.toLowerCase()) ||
            fee.feeType?.toLowerCase().includes(search.toLowerCase());
          
          const matchesType = !type || fee.feeType === type;
          const matchesStatus = !status || fee.status === status;
          const matchesMonth = !month || (fee.dueDate && new Date(fee.dueDate).getMonth() + 1 === Number(month));

          return matchesSearch && matchesType && matchesStatus && matchesMonth;
        });
      })
    );
  }

  // Statistics Methods
  calculateStatistics() {
    this.totalFees = 0;
    this.paidAmount = 0;
    this.pendingAmount = 0;
    this.overdueCount = 0;

    for (const fee of this.allFees()) {
      const feeAmount = fee.amount || 0;
      this.totalFees += feeAmount;

      if (fee.status === 'Paid') {
        this.paidAmount += feeAmount;
      } else if (fee.status === 'Pending' || fee.status === 'Partial') {
        this.pendingAmount += feeAmount;
      }

      if (this.isOverdue(fee)) {
        this.overdueCount++;
      }
    }
  }

  /** Overdue dues total for the sticky summary tray (₹-formatted). */
  get overdueDuesTotal(): string {
    return this.formatAmount(
      this.allFees()
        .filter(f => this.isOverdue(f))
        .reduce((s, f) => s + (f.amount || 0), 0)
    );
  }

  /** Sending state for the bulk WhatsApp (overdue) CTA. */
  bulkReminding = signal(false);

  /** Bulk-drip WhatsApp reminder to every overdue record's guardian. */
  sendBulkOverdueReminders() {
    const overdue = this.allFees().filter(f => this.isOverdue(f));
    if (overdue.length === 0) return;
    const studentIds = [...new Set(overdue.map(f => f.studentId).filter(Boolean))];
    this.bulkReminding.set(true);
    this.dailyOpsService.sendFeeReminders({
      studentIds,
      channel: 'Email',
      message: 'Reminder: your child has overdue school fees pending. Please clear the dues at the earliest.'
    }).subscribe({
      next: (res: any) => {
        this.bulkReminding.set(false);
        const sent = res?.sent ?? 0;
        this.snackBar.open(
          sent > 0 ? `${sent} WhatsApp reminder(s) dispatched` : 'No parent contact found for these students',
          'OK',
          { duration: 3000 }
        );
      },
      error: () => {
        this.bulkReminding.set(false);
        this.snackBar.open('Failed to dispatch bulk reminders', 'Dismiss', { duration: 3000 });
      }
    });
  }

  /** Short relative cue under the due date — mockup's “Overdue by N days” / “Due in N days”. */
  getDueCue(fee: Fee): { text: string; tone: 'urgent' | 'warn' | 'ok' } {
    if (!fee?.dueDate) return { text: '', tone: 'ok' };
    const due = new Date(fee.dueDate);
    const today = new Date();
    const days = Math.ceil((today.getTime() - due.getTime()) / 86400000);
    if (today.getTime() > due.getTime()) {
      return { text: `Overdue by ${days} day${days === 1 ? '' : 's'}`, tone: 'urgent' };
    }
    if (this.isOverdue(fee)) return { text: 'Overdue', tone: 'urgent' };
    return { text: `Due in ${-days} day${days === -1 ? '' : 's'}`, tone: 'warn' };
  }

  getTotalFees(): number {
    return this.totalFees;
  }

  getPaidAmount(): number {
    return this.paidAmount;
  }

  getPendingAmount(): number {
    return this.pendingAmount;
  }

  getOverdueCount(): number {
    return this.overdueCount;
  }

  // View Methods
  toggleView(mode: 'card' | 'table') {
    this.viewMode = mode;
  }

  clearFilters() {
    this.searchControl.setValue('');
    this.typeFilterControl.setValue('');
    this.statusFilterControl.setValue('');
    this.monthFilterControl.setValue('');
  }

  // Fee Actions
  editFee(fee: Fee) {
    if (fee?.id != null) {
      this.router.navigate(['/app/fees/edit', fee.id]);
    } else {
      console.warn('Edit fee requested without a valid id:', fee);
    }
  }

  deleteFee(fee: Fee) {
    if (confirm(`Are you sure you want to delete fee record for Student ID ${fee.studentId}?`)) {
      if (fee.id != null) {
        this.feesService.delete(fee.id).subscribe({
          next: () => {
            this.loadFees();
          },
          error: (err) => {
            console.error('Error deleting fee:', err);
          }
        });
      }
    }
  }

  viewFeeDetails(fee: Fee) {
    if (fee?.id != null) {
      this.router.navigate(['/app/fees/details', fee.id]);
    }
  }

  sendPaymentReminder(fee: Fee) {
    if (!fee.studentId) {
      this.snackBar.open('No student associated with this fee record', 'Dismiss', { duration: 3000 });
      return;
    }

    const payload: FeeReminderRequest = {
      studentIds: [fee.studentId],
      channel: 'Email',
      message: `Reminder: Your fee of ${this.formatAmount(fee.amount)} for ${fee.feeType} is due on ${fee.dueDate}. Please pay at the earliest.`
    };

    this.dailyOpsService.sendFeeReminders(payload).subscribe({
      next: (res: any) => {
        const sent = res?.sent ?? 0;
        this.snackBar.open(
          sent > 0 ? `Reminder sent to ${sent} parent(s)` : 'No parent contact found for this student',
          'OK',
          { duration: 3000 }
        );
      },
      error: () => {
        this.snackBar.open('Failed to send payment reminder', 'Dismiss', { duration: 3000 });
      }
    });
  }

  /** Receipt print-template choices offered by the backend. */
  readonly receiptTemplates = [
    { value: 'classic', label: 'Classic', icon: 'receipt_long' },
    { value: 'modern', label: 'Letterhead', icon: 'description' },
    { value: 'minimal', label: 'Thermal (80mm)', icon: 'print' },
  ];

  generateReceipt(fee: Fee, template: string = 'classic') {
    if (fee?.id != null) {
      const receiptUrl = `/api/fees/${fee.id}/receipt/download?template=${encodeURIComponent(template)}`;
      window.open(receiptUrl, '_blank');
    }
  }

  emailReceipt(fee: Fee) {
    if (fee?.id == null) return;
    this.snackBar.open('Sending receipt email...', '', { duration: 2000 });
    this.http.post(`/api/fees/${fee.id}/receipt/email`, {}).subscribe({
      next: (res: any) => {
        this.snackBar.open(res?.message || 'Receipt emailed successfully', 'OK', { duration: 4000 });
      },
      error: (err) => {
        this.snackBar.open(err?.error?.message || 'Failed to send receipt email', 'Dismiss', { duration: 4000 });
      }
    });
  }

  // Helper Methods
  getStatusColor(status: string): string {
    switch (status?.toLowerCase()) {
      case 'paid': return 'var(--md-success)';
      case 'pending': return 'var(--md-warning)';
      case 'overdue': return 'var(--md-error)';
      case 'partial': return 'var(--md-primary-light)';
      default: return 'var(--color-text-secondary)';
    }
  }

  getStatusChipClass(status: string): string {
    return status?.toLowerCase() || 'pending';
  }

  formatAmount(amount: number): string {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR'
    }).format(amount || 0);
  }

  getDaysOverdue(dueDate: string): number {
    if (!dueDate) return 0;
    const due = new Date(dueDate);
    const today = new Date();
    const diffTime = today.getTime() - due.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays > 0 ? diffDays : 0;
  }

  isOverdue(fee: Fee): boolean {
    return fee.status !== 'Paid' && this.getDaysOverdue(fee.dueDate!) > 0;
  }

  /** Count of active non-default filters — drives the mobile filter badge. */
  get activeFilterCount(): number {
    return (this.searchControl.value ? 1 : 0) +
      (this.typeFilterControl.value ? 1 : 0) +
      (this.statusFilterControl.value ? 1 : 0) +
      (this.monthFilterControl.value ? 1 : 0);
  }
}
