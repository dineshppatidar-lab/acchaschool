import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HostelListComponent } from './hostel-list.component';
import { HostelFormComponent } from './hostel-form.component';

const routes: Routes = [
  { path: '', redirectTo: 'list', pathMatch: 'full' },
  { path: 'list', component: HostelListComponent },
  { path: 'form', component: HostelFormComponent },
  { path: 'edit/:id', component: HostelFormComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class HostelRoutingModule { }
