import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSortModule } from '@angular/material/sort';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { RouterModule } from '@angular/router';
import { HostelRoutingModule } from './hostel-routing.module';
import { HostelListComponent } from './hostel-list.component';
import { HostelFormComponent } from './hostel-form.component';

@NgModule({ 
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule,
    HostelRoutingModule,
    RouterModule,
    HostelListComponent,
    HostelFormComponent
    ],
  exports: [HostelListComponent, HostelFormComponent]
})
export class HostelModule {}