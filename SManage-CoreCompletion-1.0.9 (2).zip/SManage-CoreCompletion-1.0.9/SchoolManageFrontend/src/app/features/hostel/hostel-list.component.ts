import { ChangeDetectorRef, Component, OnDestroy, OnInit, signal } from '@angular/core';
import { HostelService, Hostel } from '../../services/hostel.service';
import { Router, NavigationEnd } from '@angular/router';

import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatTableModule } from '@angular/material/table';
import { MatIconModule } from '@angular/material/icon';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatChipsModule } from '@angular/material/chips';
import { MatMenuModule } from '@angular/material/menu';
import { MatDialogModule, MatDialog } from '@angular/material/dialog';
import { MatSnackBarModule, MatSnackBar } from '@angular/material/snack-bar';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSortModule } from '@angular/material/sort';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatDividerModule } from '@angular/material/divider';
import { RouterModule } from '@angular/router';
import { FormControl, ReactiveFormsModule } from '@angular/forms';
import { Observable, combineLatest, BehaviorSubject, Subscription } from 'rxjs';
import { map, startWith, debounceTime, distinctUntilChanged, filter } from 'rxjs/operators';
import { CanWriteDirective, CanDeleteDirective } from '../../core/directives/permission.directive';
import { Permission } from '../../core/models/permission.model';
import { PageHeaderComponent, KpiCardComponent } from '../../shared/components/page-patterns/index';

@Component({
  selector: 'app-hostel-list',
  standalone: true,
  imports: [
    CommonModule,
    MatTableModule,
    MatButtonModule,
    RouterModule,
    MatIconModule,
    MatCardModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatChipsModule,
    MatMenuModule,
    MatDialogModule,
    MatSnackBarModule,
    MatPaginatorModule,
    MatSortModule,
    MatProgressSpinnerModule,
    MatTooltipModule,
    MatDividerModule,
    ReactiveFormsModule,
    CanWriteDirective,
    CanDeleteDirective,
    PageHeaderComponent,
    KpiCardComponent
  ],
  templateUrl: './hostel-list.component.html',
  styleUrls: ['./hostel-list.component.scss']
})
export class HostelListComponent implements OnInit, OnDestroy {
  // Expose Permission enum to template for permission directives
  Permission = Permission;

  private hostelsSubject = new BehaviorSubject<Hostel[]>([]);
  hostels$ = this.hostelsSubject.asObservable();
  filteredHostels$?: Observable<Hostel[]>;

  stats$ = this.hostels$.pipe(
    map(hostels => {
      const total = hostels.length;
      const totalCapacity = hostels.reduce((sum, h) => sum + (h.capacity || 0), 0);
      return {
        total,
        totalCapacity,
        averageCapacity: total > 0 ? Math.round(totalCapacity / total) : 0,
        boys: hostels.filter(h => h.type === 'Boys').length,
        girls: hostels.filter(h => h.type === 'Girls').length,
        mixed: hostels.filter(h => h.type === 'Mixed').length,
        staff: hostels.filter(h => h.type === 'Staff').length
      };
    })
  );

  displayedColumns: string[] = ['name', 'type', 'capacity', 'status', 'actions'];

  // View Controls
  viewMode: 'card' | 'table' = 'table';
  isLoading = signal(false);

  // Filter Controls
  searchControl = new FormControl('');
  typeFilterControl = new FormControl('');

  // Filter Options
  hostelTypes = ['Boys', 'Girls', 'Mixed', 'Staff'];

  private routerSubscription?: Subscription;

  constructor(
    private hostelService: HostelService,
    public router: Router,
    private dialog: MatDialog,
    private snackBar: MatSnackBar,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    // Setup filtering first so it's ready when data loads
    this.setupFiltering();

    // Then load initial data
    this.loadHostels();

    // Refresh data when navigating back to this component
    this.routerSubscription = this.router.events
      .pipe(filter(event => event instanceof NavigationEnd))
      .subscribe((event: NavigationEnd) => {
        const url = event.url.split('?')[0];
        if (url === '/app/hostels' || url === '/app/hostels/rooms' || url === '/app/hostel') {
          this.loadHostels();
        }
      });
  }

  ngOnDestroy(): void {
    this.routerSubscription?.unsubscribe();
  }

  refreshData(): void {
    this.loadHostels();
  }

  loadHostels(): void {
    this.isLoading.set(true);
    this.hostelService.getAll().subscribe({
      next: (data) => {
        const hostelsArray = Array.isArray(data) ? data : [];
        this.hostelsSubject.next(hostelsArray);
        this.isLoading.set(false);
        this.cdr.markForCheck();
      },
      error: (err) => {
        console.error('❌ Error loading hostels:', err);
        this.hostelsSubject.next([]);
        this.isLoading.set(false);
        this.cdr.markForCheck();
        this.snackBar.open('Error loading hostels', 'Close', { duration: 3000 });
      }
    });
  }

  setupFiltering(): void {
    this.filteredHostels$ = combineLatest([
      this.hostels$,
      this.searchControl.valueChanges.pipe(startWith(''), debounceTime(300), distinctUntilChanged()),
      this.typeFilterControl.valueChanges.pipe(startWith(''))
    ]).pipe(
      map(([hostels, search, typeFilter]) => {
        return hostels.filter(hostel => {
          const matchesSearch = !search ||
            hostel.name?.toLowerCase().includes(search.toLowerCase()) ||
            hostel.address?.toLowerCase().includes(search.toLowerCase()) ||
            hostel.type?.toLowerCase().includes(search.toLowerCase());

          const matchesType = !typeFilter || hostel.type === typeFilter;

          return matchesSearch && matchesType;
        });
      })
    );
  }

  // View Methods
  toggleView(mode: 'card' | 'table') {
    this.viewMode = mode;
  }

  clearFilters() {
    this.searchControl.setValue('');
    this.typeFilterControl.setValue('');
  }

  // Hostel Actions
  addNewHostel() {
    this.router.navigate(['/app/hostel/form']);
  }

  editHostel(id: number | undefined) {
    if (id !== undefined) {
      this.router.navigate(['/app/hostel/edit', id]);
    }
  }

  deleteHostel(id: number | undefined, name: string) {
    if (id === undefined) return;
    const confirmed = confirm(`Are you sure you want to delete "${name}" hostel?`);
    if (confirmed) {
      this.hostelService.delete(id).subscribe({
        next: () => {
          this.snackBar.open('Hostel deleted successfully', 'Close', { duration: 3000 });
          this.loadHostels();
        },
        error: (err) => {
          console.error('Error deleting hostel:', err);
          this.snackBar.open('Error deleting hostel', 'Close', { duration: 3000 });
        }
      });
    }
  }

  // Helper Methods
  getTypeIcon(type: string): string {
    switch (type?.toLowerCase()) {
      case 'boys': return 'male';
      case 'girls': return 'female';
      case 'mixed': return 'groups';
      case 'staff': return 'business';
      default: return 'home';
    }
  }

  getTypeChipClass(type: string): string {
    switch (type?.toLowerCase()) {
      case 'boys': return 'stu-badge stu-badge-male';
      case 'girls': return 'stu-badge stu-badge-female';
      case 'mixed': return 'stu-badge stu-badge-new';
      case 'staff': return 'stu-badge stu-badge-neutral';
      default: return 'stu-badge stu-badge-neutral';
    }
  }

  exportData() {
    // Issue #29: previously a "coming soon" toast — now calls the real endpoint.
    this.hostelService.export().subscribe({
      next: (blob: Blob) => {
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `hostels_${new Date().toISOString().slice(0, 10)}.xlsx`;
        a.click();
        URL.revokeObjectURL(url);
        this.snackBar.open('Hostels exported successfully', 'Close', { duration: 3000 });
      },
      error: (err) => {
        console.error('Failed to export hostels', err);
        this.snackBar.open('Failed to export hostels', 'Close', { duration: 3500 });
      }
    });
  }
}
