import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatDividerModule } from '@angular/material/divider';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatNativeDateModule } from '@angular/material/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormBuilder } from '@angular/forms';

import { BaseFormComponent, FormFieldConfig } from '../../core/components/base-form.component';
import { PageHeaderComponent } from '../../shared/components/page-patterns/index';
import { BaseCrudService } from '../../core/services/base-crud.service';
import { HostelService } from '../../services/hostel.service';
import { MasterDataService } from '../../services/master-data.service';

export interface Hostel {
  id?: number;
  name: string;
  type: string;
  address: string;
  capacity: number;
  wardenName?: string;
  wardenContact?: string;
  monthlyFee?: number;
  facilities?: string[];
  description?: string;
  isActive?: boolean;
}

/**
 * Hostel Form Component
 * 
 * Handles creation and editing of hostel information including:
 * - Basic details (name, type, address)
 * - Capacity and contact information
 * - Facilities and monthly fees
 * 
 * Usage:
 * - Create: /app/hostel/form
 * - Edit: /app/hostel/form/123
 */
@Component({
  selector: 'app-hostel-form',
  templateUrl: '../../core/components/base-form.component.html',
  styleUrls: ['../../core/components/base-form.component.scss'],
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatButtonModule,
    MatCardModule,
    MatIconModule,
    MatDividerModule,
    MatProgressSpinnerModule,
    MatProgressBarModule,
    MatSnackBarModule,
    MatDatepickerModule,
    MatCheckboxModule,
    MatNativeDateModule,
    PageHeaderComponent,
      MatNativeDateModule
  ]
})
export class HostelFormComponent extends BaseFormComponent<Hostel> {
  hostelTypes = [
    { id: 'Boys', name: 'Boys Hostel' },
    { id: 'Girls', name: 'Girls Hostel' },
    { id: 'Mixed', name: 'Mixed Hostel' },
    { id: 'Staff', name: 'Staff Quarters' }
  ];

  facilities = [
    { id: 'WI_FI', name: 'Wi-Fi' },
    { id: 'MESS', name: 'Mess' },
    { id: 'LAUNDRY', name: 'Laundry' },
    { id: 'REC_ROOM', name: 'Recreation Room' },
    { id: 'STUDY_HALL', name: 'Study Hall' },
    { id: 'GYM', name: 'Gym' },
    { id: 'MEDICAL', name: 'Medical Room' },
    { id: 'SECURITY', name: '24/7 Security' },
    { id: 'PARKING', name: 'Parking' },
    { id: 'LIBRARY', name: 'Library' }
  ];

  constructor(
    private hostelService: HostelService,
    private masterDataService: MasterDataService
  ) {
    super();
  }

  getService(): BaseCrudService<Hostel> {
    return this.hostelService as any;
  }

  getFormTitle(): string {
    return this.isCreateMode ? 'Add New Hostel' : 'Edit Hostel';
  }

  getFormConfig(): FormFieldConfig[] {
    return [
      {
        name: 'name',
        label: 'Hostel Name',
        type: 'text',
        placeholder: 'Enter hostel name (e.g., Rashtriya Hostel)',
        required: true,
        minLength: 3,
        maxLength: 100,
        grid: 'full'
      },
      {
        name: 'type',
        label: 'Hostel Type',
        type: 'select',
        required: true,
        options: this.hostelTypes,
        grid: 'half'
      },
      {
        name: 'capacity',
        label: 'Capacity',
        type: 'number',
        placeholder: 'Maximum number of residents',
        required: true,
        min: 1,
        max: 1000,
        grid: 'half'
      },
      {
        name: 'address',
        label: 'Address',
        type: 'textarea',
        placeholder: 'Enter complete address',
        required: true,
        minLength: 10,
        maxLength: 500,
        grid: 'full'
      },
      {
        name: 'wardenName',
        label: 'Warden Name',
        type: 'text',
        placeholder: 'Enter warden\'s full name',
        minLength: 3,
        maxLength: 100,
        grid: 'half'
      },
      {
        name: 'wardenContact',
        label: 'Warden Contact',
        type: 'text',
        placeholder: 'Enter 10-digit phone number',
        pattern: '^[0-9]{10}$',
        grid: 'half'
      },
      {
        name: 'monthlyFee',
        label: 'Monthly Fee',
        type: 'number',
        placeholder: 'Monthly accommodation fee',
        min: 0,
        max: 9999999,
        grid: 'half'
      },
      {
        name: 'description',
        label: 'Description',
        type: 'textarea',
        placeholder: 'Brief description about the hostel',
        maxLength: 500,
        grid: 'full'
      },
      {
        name: 'isActive',
        label: 'Is Active',
        type: 'checkbox',
        grid: 'half'
      }
    ];
  }
}
