/** Human-friendly labels for the website CMS enums (backend may send enum numbers or names). */

const CAMPAIGN_STATUS_NAMES: { [n: number]: string } = { 0: 'Draft', 1: 'Scheduled', 2: 'Published', 3: 'Expired', 4: 'Unpublished' };
const CAMPAIGN_POSITION_NAMES: { [n: number]: string } = { 0: 'Homepage', 1: 'Admissions', 2: 'Events', 3: 'Contact', 4: 'Sidebar' };
const ENQUIRY_STATUS_NAMES: { [n: number]: string } = { 0: 'New', 1: 'Contacted', 2: 'Converted', 3: 'Closed' };

function enumName(value: string, names: { [n: number]: string }, fallback: string): string {
  const asNumber = Number(value);
  if (!isNaN(asNumber) && names[asNumber] !== undefined) return names[asNumber];
  return value;
}

export const CampaignStatusLabel = (value: string): string => enumName(value, CAMPAIGN_STATUS_NAMES, value);
export const CampaignPositionLabel = (value: string): string => enumName(value, CAMPAIGN_POSITION_NAMES, value);
export const EnquiryStatusLabel = (value: string): string => enumName(value, ENQUIRY_STATUS_NAMES, value);

export const CampaignStatuses = ['Draft', 'Scheduled', 'Published', 'Expired', 'Unpublished'] as const;
export const CampaignPositions = ['Homepage', 'Admissions', 'Events', 'Contact', 'Sidebar'] as const;
export const EnquiryStatuses = ['New', 'Contacted', 'Converted', 'Closed'] as const;
