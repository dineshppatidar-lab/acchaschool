import { ChangeDetectorRef, Component, OnInit, Pipe, PipeTransform, computed, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatDividerModule } from '@angular/material/divider';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatTabsModule } from '@angular/material/tabs';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatTableModule } from '@angular/material/table';

import { CampaignStatusLabel, CampaignPositionLabel, CampaignPositions, CampaignStatuses,
         EnquiryStatusLabel, EnquiryStatuses } from './website-labels';

import { BackButtonComponent } from '../../shared/components/back-button.component';
import { CanReadDirective, CanWriteDirective, CanDeleteDirective } from '../../core/directives/permission.directive';
import { Permission } from '../../core/models/permission.model';
import { WebsiteContentService } from '../../shared/services/website-content.service';

interface SettingsRow {
  tagline?: string | null; faviconUrl?: string | null; primaryColor?: string | null; secondaryColor?: string | null;
  websiteTitle?: string | null; metaDescription?: string | null; socialShareImageUrl?: string | null;
  address?: string | null; contactPhone?: string | null; contactEmail?: string | null; mapEmbedUrl?: string | null;
  aboutHtml?: string | null; visionMissionHtml?: string | null; academicsHtml?: string | null;
  facilitiesHtml?: string | null; admissionsHtml?: string | null;
  principalName?: string | null; principalTitle?: string | null; principalPhotoUrl?: string | null; principalMessageHtml?: string | null;
  socialLinksJson?: string | null; homepageSectionsJson?: string | null;
  isPublished: boolean; enquiriesEnabled: boolean;
}

interface MediaRow {
  id: number; filePath: string; thumbnailFilePath?: string | null; originalFileName: string;
  contentType?: string | null; sizeBytes?: number; caption?: string | null; altText?: string | null;
}

interface EventRow {
  id: number; title: string; slug?: string; excerpt?: string | null; descriptionHtml?: string | null;
  eventDate: string; endDate?: string | null; location?: string | null; coverImageUrl?: string | null;
  galleryAlbumId?: number | null; displayOrder?: number; isPublished: boolean;
}

interface AlbumRow {
  id: number; title: string; slug?: string; descriptionHtml?: string | null; category?: string | null;
  eventDate?: string | null; coverImageUrl?: string | null; studentPhotoConsentConfirmed: boolean;
  isPublished: boolean; isFeatured: boolean; displayOrder?: number;
}

interface AlbumMediaRow {
  id: number; filePath: string; thumbnailPath?: string | null; caption?: string | null;
  altText?: string | null; videoUrl?: string | null; displayOrder?: number;
}

interface AchievementRow {
  id: number; title: string; descriptionHtml?: string | null; category?: string | null;
  achievementDate?: string | null; imageUrl?: string | null; documentUrlsJson?: string | null;
  statsJson?: string | null; isVerified: boolean; isPublished: boolean; showOnHomepage: boolean; displayOrder?: number;
}

interface ArticleRow {
  id: number; title: string; slug?: string; excerpt?: string | null; bodyHtml: string; coverImageUrl?: string | null;
  category?: string | null; tagsCsv?: string | null; isPublished: boolean; isFeatured: boolean;
  scheduledForUtc?: string | null; seoTitle?: string | null; seoDescription?: string | null;
}

interface CampaignRow {
  id: number; title: string; description?: string | null; bannerImagePath?: string | null;
  mobileBannerImagePath?: string | null; ctaText?: string | null; ctaUrl?: string | null;
  displayPosition: string; startUtc: string; endUtc?: string | null; priority?: number; status: string;
}

interface EnquiryRow {
  id: number; parentId: number; parentName: string; phone: string; email?: string | null; message?: string | null;
  classOfInterest?: string | null; status: string; staffNote?: string | null;
  convertedStudentEnquiryId?: number | null; convertedOnUtc?: string | null;
}

interface SummaryRow {
  albums: number; events: number; articles: number; campaigns: number;
  pendingEnquiries: number; publishedAlbums: number;
}

/** Local wrappers for the shared label helpers (backend may enum-name or enum-number). */
const campaignStatusLabelFn = CampaignStatusLabel;
const normalizeCampaignPositionFn = CampaignPositionLabel;
const normalizeEnquiryStatusFn = EnquiryStatusLabel;

/** True when the media row should render with an <img> thumbnail. */
@Pipe({ name: 'mediaIsImage', standalone: true })
export class MediaIsImagePipe implements PipeTransform {
  transform(filePath?: string | null): boolean {
    if (!filePath) return false;
    if (filePath.startsWith('data:image')) return true;
    return /\.(jpeg|jpg|png|gif|webp|avif)(\?|$)/i.test(filePath);
  }
}

function emptyEvent(): EventRow {
  return { id: 0, title: '', eventDate: new Date().toISOString().slice(0, 10), isPublished: false, displayOrder: 0 };
}
function emptyAlbum(): AlbumRow {
  return { id: 0, title: '', category: '', studentPhotoConsentConfirmed: false, isPublished: false, isFeatured: false, displayOrder: 0 };
}
function emptyAchievement(): AchievementRow {
  return { id: 0, title: '', category: '', isVerified: false, isPublished: false, showOnHomepage: false, displayOrder: 0 };
}
function emptyArticle(): ArticleRow {
  return { id: 0, title: '', bodyHtml: '', isPublished: false, isFeatured: false };
}
function emptyCampaign(): CampaignRow {
  return {
    id: 0, title: '', displayPosition: 'Homepage', startUtc: new Date().toISOString().slice(0, 16),
    endUtc: null, priority: 0, status: 'Draft'
  };
}


/** Local alias for the mediaIsImage pipe used in the template. */
export const MediaIsImageProbePipe = MediaIsImagePipe;

@Component({
  selector: 'app-website-hub',
  standalone: true,
  imports: [
    CommonModule, FormsModule,
    MatCardModule, MatButtonModule, MatIconModule, MatFormFieldModule, MatInputModule,
    MatSelectModule, MatTabsModule, MatSlideToggleModule, MatCheckboxModule,
    MatSnackBarModule, MatProgressSpinnerModule, MatTooltipModule, MatTableModule, MatDividerModule,
    BackButtonComponent, CanReadDirective, CanWriteDirective, CanDeleteDirective, MediaIsImageProbePipe
  ],
  templateUrl: './website-hub.component.html',
  styleUrls: ['./website-hub.component.scss']
})
export class WebsiteHubComponent implements OnInit {
  Permission = Permission;

  readonly campaignStatuses = CampaignStatuses;
  readonly campaignPositions = CampaignPositions;
  readonly campaignStatusLabel = CampaignStatusLabel;
  readonly enquiryStatuses = EnquiryStatuses;
  readonly enquiryStatusLabel = (row: EnquiryRow): string => EnquiryStatusLabel(row.status);

  trimText(text: string | null | undefined, max: number): string {
    if (!text) return '';
    return text.length > max ? text.slice(0, max).trimEnd() + '…' : text;
  }

  movePhoto(from: number, to: number): void {
    const list = this.albumMedia();
    if (!list || from === to || from < 0 || from >= list.length) return;
    const next = [...list];
    const [moved] = next.splice(from, 1);
    next.splice(Math.max(0, Math.min(next.length, to)), 0, moved);
    this.albumMedia.set(next);
    this.albumMediaDirty = true;
  }

  readonly summaries = signal<SummaryRow>({
    albums: 0, events: 0, articles: 0, campaigns: 0, pendingEnquiries: 0, publishedAlbums: 0
  });

  // Settings tab
  readonly settings = signal<SettingsRow | null>(null);
  readonly settingsLoading = signal(false);
  readonly savingSettings = signal(false);
  readonly websitePublished = computed(() => this.settings()?.isPublished === true);

  // Media tab
  readonly media = signal<MediaRow[]>([]);
  readonly mediaLoading = signal(false);
  readonly uploadingMedia = signal(false);
  mediaUploadFile: File | null = null;
  mediaUploadCaption = '';
  mediaUploadAlt = '';

  // Events tab
  readonly events = signal<EventRow[]>([]);
  readonly eventsLoading = signal(false);
  readonly editingEvent = signal<EventRow | null>(null);
  readonly savingEvent = signal(false);

  // Albums tab
  readonly albums = signal<AlbumRow[]>([]);
  readonly albumsLoading = signal(false);
  readonly editingAlbum = signal<AlbumRow | null>(null);
  readonly savingAlbum = signal(false);
  readonly albumMedia = signal<AlbumMediaRow[] | null>(null); // null = no album open
  readonly albumMediaLoading = signal(false);
  readonly albumMediaBusy = signal(false);
  albumMediaUploadFile: File | null = null;
  albumMediaTemp: number[] = []; // staged media ids before saving
  albumMediaDirty = false;

  // Achievements tab
  readonly achievements = signal<AchievementRow[]>([]);
  readonly achievementsLoading = signal(false);
  readonly editingAchievement = signal<AchievementRow | null>(null);
  readonly savingAchievement = signal(false);

  // Articles tab
  readonly articles = signal<ArticleRow[]>([]);
  readonly articlesLoading = signal(false);
  readonly editingArticle = signal<ArticleRow | null>(null);
  readonly savingArticle = signal(false);
  articleSearch = '';

  // Campaigns tab
  readonly campaigns = signal<CampaignRow[]>([]);
  readonly campaignsLoading = signal(false);
  readonly editingCampaign = signal<CampaignRow | null>(null);
  readonly savingCampaign = signal(false);

  // Enquiries tab
  readonly enquiries = signal<EnquiryRow[]>([]);
  readonly enquiriesLoading = signal(false);
  readonly enquiryBusyId = signal<number | null>(null);

  dragPhotoIndex = -1;

  constructor(
    private api: WebsiteContentService,
    private snackBar: MatSnackBar,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    void this.loadSummary();
    void this.loadSettings();
    void this.loadMedia();
    void this.loadEvents();
    void this.loadAlbums();
    void this.loadAchievements();
    void this.loadArticles();
    void this.loadCampaigns();
    void this.loadEnquiries();
  }

  private toast(message: string): void {
    this.snackBar.open(message, 'Close', { duration: 3500 });
  }

  private async run(label: string, work: () => Promise<unknown>): Promise<void> {
    try {
      await work();
    } catch (err: unknown) {
      this.toast(this.errorMessage(err, `${label} failed`));
    }
  }

  private errorMessage(err: unknown, fallback: string): string {
    const anyErr = err as { error?: { message?: string | { message?: string }; errors?: Record<string, string[]> }; message?: string };
    const vm = anyErr?.error?.message;
    if (typeof vm === 'string') return vm;
    if (vm && typeof vm === 'object' && typeof vm.message === 'string') return vm.message;
    return anyErr?.message ?? fallback;
  }

  // ── Summary ──
  async loadSummary(): Promise<void> {
    await this.run('Loading website stats', async () => {
      const s = await this.api.getSummary();
      this.summaries.set({
        albums: s['PublishedAlbums'] ?? s['publishedAlbums'] ?? 0,
        events: s['Events'] ?? s['events'] ?? 0,
        articles: s['Articles'] ?? s['articles'] ?? 0,
        campaigns: s['Campaigns'] ?? s['campaigns'] ?? 0,
        pendingEnquiries: s['PendingEnquiries'] ?? s['pendingEnquiries'] ?? 0,
        publishedAlbums: s['PublishedAlbums'] ?? s['publishedAlbums'] ?? 0
      });
    });
  }

  // ── Settings ──
  async loadSettings(): Promise<void> {
    this.settingsLoading.set(true);
    await this.run('Loading website settings', async () => {
      const s = await this.api.getSettings();
      this.settings.set({
        ...s,
        isPublished: !!s['IsPublished'],
        enquiriesEnabled: s['EnquiriesEnabled'] !== false
      } as SettingsRow);
    });
    this.settingsLoading.set(false);
  }

  async saveSettings(): Promise<void> {
    const current = this.settings();
    if (!current) return;
    this.savingSettings.set(true);
    await this.run('Saving website settings', async () => {
      const saved = await this.api.saveSettings(current);
      this.settings.set({ ...saved, isPublished: !!saved['IsPublished'], enquiriesEnabled: saved['EnquiriesEnabled'] !== false } as SettingsRow);
      this.toast('Website settings saved');
    });
    this.savingSettings.set(false);
  }

  // ── Media ──
  async loadMedia(): Promise<void> {
    this.mediaLoading.set(true);
    await this.run('Loading media library', async () => {
      const list = await this.api.listMedia();
      this.media.set(list.map(this.mapMedia));
    });
    this.mediaLoading.set(false);
  }

  private mapMedia(m: Record<string, unknown>): MediaRow {
    return {
      id: Number(m['Id'] ?? m['id']),
      filePath: String(m['FilePath'] ?? m['filePath'] ?? ''),
      thumbnailFilePath: (m['ThumbnailFilePath'] ?? m['thumbnailFilePath']) as string | null,
      originalFileName: String(m['OriginalFileName'] ?? m['originalFileName'] ?? ''),
      contentType: (m['ContentType'] ?? m['contentType']) as string | null,
      sizeBytes: Number(m['SizeBytes'] ?? m['sizeBytes'] ?? 0),
      caption: (m['Caption'] ?? m['caption']) as string | null,
      altText: (m['AltText'] ?? m['altText']) as string | null
    };
  }

  async uploadMedia(): Promise<void> {
    if (!this.mediaUploadFile) return;
    this.uploadingMedia.set(true);
    await this.run('Upload failed', async () => {
      await this.api.uploadMedia(this.mediaUploadFile!, this.mediaUploadCaption || null, this.mediaUploadAlt || null);
      this.mediaUploadFile = null;
      this.mediaUploadCaption = '';
      this.mediaUploadAlt = '';
      await this.loadMedia();
      this.toast('Media uploaded');
    });
    this.uploadingMedia.set(false);
  }

  async deleteMedia(row: MediaRow): Promise<void> {
    await this.run('Delete failed', async () => {
      await this.api.deleteMedia(row.id);
      await this.loadMedia();
      this.toast('Media removed');
    });
  }

  formatBytes(n?: number): string {
    if (!n) return '';
    if (n < 1024) return `${n} B`;
    if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
    return `${(n / 1024 / 1024).toFixed(1)} MB`;
  }

  // ── Events ──
  async loadEvents(): Promise<void> {
    this.eventsLoading.set(true);
    await this.run('Loading events', async () => {
      const list = await this.api.listEvents();
      this.events.set(list.map(e => ({
        id: Number(e['Id'] ?? e['id']),
        title: String(e['Title'] ?? e['title'] ?? ''),
        slug: String(e['Slug'] ?? e['slug'] ?? ''),
        excerpt: (e['Excerpt'] ?? e['excerpt']) as string | null,
        descriptionHtml: (e['DescriptionHtml'] ?? e['descriptionHtml']) as string | null,
        eventDate: this.toDateInput(e['EventDate'] ?? e['eventDate']),
        endDate: this.toDateInput(e['EndDate'] ?? e['endDate']),
        location: (e['Location'] ?? e['location']) as string | null,
        coverImageUrl: (e['CoverImageUrl'] ?? e['coverImageUrl']) as string | null,
        galleryAlbumId: (e['GalleryAlbumId'] ?? e['galleryAlbumId']) as number | null,
        displayOrder: Number(e['DisplayOrder'] ?? e['displayOrder'] ?? 0),
        isPublished: !!(e['IsPublished'] ?? e['isPublished'])
      })));
    });
    this.eventsLoading.set(false);
  }

  private toDateInput(v: unknown): string {
    if (!v) return '';
    const d = new Date(String(v));
    return isNaN(d.getTime()) ? String(v) : d.toISOString().slice(0, 10);
  }

  private toDatePayload(v: string | null | undefined): string | null {
    if (!v) return null;
    const d = new Date(v);
    return isNaN(d.getTime()) ? null : d.toISOString();
  }

  editEvent(row: EventRow): void {
    this.editingEvent.set({ ...row });
  }
  newEvent(): void {
    this.editingEvent.set(emptyEvent());
  }
  cancelEvent(): void {
    this.editingEvent.set(null);
  }

  async saveEvent(): Promise<void> {
    const draft = this.editingEvent();
    if (!draft || !draft.title.trim()) {
      this.toast('Event title is required');
      return;
    }
    this.savingEvent.set(true);
    await this.run('Saving event failed', async () => {
      const payload = {
        id: draft.id, title: draft.title.trim(), slug: draft.slug, excerpt: draft.excerpt,
        descriptionHtml: draft.descriptionHtml, eventDate: this.toDatePayload(draft.eventDate) ?? new Date().toISOString(),
        endDate: this.toDatePayload(draft.endDate), location: draft.location, coverImageUrl: draft.coverImageUrl,
        galleryAlbumId: draft.galleryAlbumId || null, displayOrder: draft.displayOrder ?? 0, isPublished: draft.isPublished
      };
      await this.api.upsertEvent(payload);
      this.editingEvent.set(null);
      await this.loadEvents();
      await this.loadSummary();
      this.toast('Event saved');
    });
    this.savingEvent.set(false);
  }

  async toggleEvent(row: EventRow, published: boolean): Promise<void> {
    await this.run('Publish change failed', async () => {
      await this.api.setEventPublished(row.id, published);
      await this.loadEvents();
      await this.loadSummary();
      this.toast(published ? 'Event published' : 'Event unpublished');
    });
  }

  async deleteEvent(row: EventRow): Promise<void> {
    await this.run('Delete failed', async () => {
      await this.api.deleteEvent(row.id);
      await this.loadEvents();
      await this.loadSummary();
      this.toast('Event deleted');
    });
  }

  // ── Albums ──
  async loadAlbums(): Promise<void> {
    this.albumsLoading.set(true);
    await this.run('Loading albums', async () => {
      const list = await this.api.listAlbums();
      this.albums.set(list.map(a => ({
        id: Number(a['Id'] ?? a['id']),
        title: String(a['Title'] ?? a['title'] ?? ''),
        slug: String(a['Slug'] ?? a['slug'] ?? ''),
        descriptionHtml: (a['DescriptionHtml'] ?? a['descriptionHtml']) as string | null,
        category: (a['Category'] ?? a['category']) as string | null,
        eventDate: this.toDateInput(a['EventDate'] ?? a['eventDate']),
        coverImageUrl: (a['CoverImageUrl'] ?? a['coverImageUrl']) as string | null,
        studentPhotoConsentConfirmed: !!(a['StudentPhotoConsentConfirmed'] ?? a['studentPhotoConsentConfirmed']),
        isPublished: !!(a['IsPublished'] ?? a['isPublished']),
        isFeatured: !!(a['IsFeatured'] ?? a['isFeatured']),
        displayOrder: Number(a['DisplayOrder'] ?? a['displayOrder'] ?? 0)
      })));
    });
    this.albumsLoading.set(false);
  }

  editAlbum(row: AlbumRow): void {
    this.editingAlbum.set({ ...row });
    this.albumMedia.set(null);
    this.albumMediaTemp = [];
    this.albumMediaDirty = false;
  }
  newAlbum(): void {
    this.editingAlbum.set(emptyAlbum());
    this.albumMedia.set(null);
    this.albumMediaTemp = [];
    this.albumMediaDirty = false;
  }
  cancelAlbum(): void {
    this.editingAlbum.set(null);
    this.albumMedia.set(null);
  }

  async saveAlbum(tryPublish = false): Promise<void> {
    const draft = this.editingAlbum();
    if (!draft || !draft.title.trim()) {
      this.toast('Album title is required');
      return;
    }
    this.savingAlbum.set(true);
    await this.run('Saving album failed', async () => {
      const saved = await this.api.upsertAlbum({
        id: draft.id, title: draft.title.trim(), slug: draft.slug, descriptionHtml: draft.descriptionHtml,
        category: draft.category, eventDate: this.toDatePayload(draft.eventDate), coverImageUrl: draft.coverImageUrl,
        studentPhotoConsentConfirmed: draft.studentPhotoConsentConfirmed,
        isPublished: tryPublish || draft.isPublished, isFeatured: draft.isFeatured, displayOrder: draft.displayOrder ?? 0
      }, tryPublish);
      const savedId = Number(saved['Id'] ?? saved['id'] ?? draft.id);
      this.editingAlbum.set({
        ...draft,
        id: savedId,
        slug: String(saved['Slug'] ?? saved['slug'] ?? draft.slug),
        isPublished: tryPublish || draft.isPublished
      });
      if (tryPublish) await this.loadAlbums();
      await this.loadSummary();
      this.toast('Album saved');
    });
    this.savingAlbum.set(false);
  }

  async toggleAlbum(row: AlbumRow, published: boolean): Promise<void> {
    await this.run('Publish change failed', async () => {
      await this.api.setAlbumPublished(row.id, published);
      await this.loadAlbums();
      await this.loadSummary();
      this.toast(published ? 'Album published' : 'Album unpublished');
    });
  }

  async deleteAlbum(row: AlbumRow): Promise<void> {
    await this.run('Delete failed', async () => {
      await this.api.deleteAlbum(row.id);
      await this.loadAlbums();
      await this.loadSummary();
      this.toast('Album deleted');
    });
  }

  // ── Album photos (staged, saved together) ──
  async openAlbumMedia(): Promise<void> {
    const draft = this.editingAlbum();
    if (!draft || draft.id === 0) {
      this.toast('Save the album first to manage photos');
      return;
    }
    this.albumMediaLoading.set(true);
    await this.run('Loading album photos', async () => {
      const res = await this.api.getAlbum(draft.id);
      const media = res.media ?? [];
      this.albumMedia.set(media.map(m => ({
        id: Number(m['Id'] ?? m['id']),
        filePath: String(m['FilePath'] ?? m['filePath'] ?? ''),
        thumbnailPath: (m['ThumbnailPath'] ?? m['thumbnailPath']) as string | null,
        caption: (m['Caption'] ?? m['caption']) as string | null,
        altText: (m['AltText'] ?? m['altText']) as string | null,
        videoUrl: (m['VideoUrl'] ?? m['videoUrl']) as string | null,
        displayOrder: Number(m['DisplayOrder'] ?? m['displayOrder'] ?? 0)
      })));
      this.albumMediaTemp = media.map(m => Number(m['Id'] ?? m['id']));
      this.albumMediaDirty = false;
    });
    this.albumMediaLoading.set(false);
  }

  async addAlbumPhoto(): Promise<void> {
    const draft = this.editingAlbum();
    if (!draft || !this.albumMediaUploadFile) return;
    this.albumMediaBusy.set(true);
    await this.run('Upload failed', async () => {
      await this.api.addAlbumMedia(draft.id, this.albumMediaUploadFile!, { displayOrder: 0 });
      this.albumMediaUploadFile = null;
      await this.openAlbumMedia();
      this.toast('Photo added');
    });
    this.albumMediaBusy.set(false);
  }

  onAlbumMediaCaptionChange(mediaId: number, caption: string | null): void {
    if (caption === null) return;
    const list = this.albumMedia();
    if (!list) return;
    this.albumMedia.set(list.map(m => m.id === mediaId ? { ...m, caption } : m));
    this.albumMediaDirty = true;
    this.cdr.markForCheck();
  }

  removeAlbumPhoto(mediaId: number): void {
    const list = this.albumMedia();
    if (!list) return;
    this.albumMedia.set(list.filter(m => m.id !== mediaId));
    this.albumMediaDirty = true;
  }

  async saveAlbumMediaChanges(): Promise<void> {
    if (!this.albumMediaDirty) return;
    const list = this.albumMedia() ?? [];
    this.albumMediaBusy.set(true);
    await this.run('Saving photos failed', async () => {
      // Detect removed rows (present in server list but gone from the edited list).
      for (const id of this.albumMediaTemp) {
        if (!list.some(m => m.id === id)) {
          await this.api.deleteAlbumMedia(id);
        }
      }
      for (const row of list) {
        const before = this.albumMediaTemp.includes(row.id);
        await this.api.updateAlbumMediaCaption(row.id, row.caption ?? null, row.altText ?? null);
        if (!before) this.albumMediaTemp.push(row.id);
      }
      const ordered = list.map(m => m.id);
      if (ordered.length) {
        await this.api.reorderAlbumMedia(this.editingAlbum()!.id, ordered);
      }
      await this.openAlbumMedia();
      this.toast('Album photos saved');
    });
    this.albumMediaBusy.set(false);
  }

  // ── Achievements ──
  async loadAchievements(): Promise<void> {
    this.achievementsLoading.set(true);
    await this.run('Loading achievements', async () => {
      const list = await this.api.listAchievements();
      this.achievements.set(list.map(a => ({
        id: Number(a['Id'] ?? a['id']),
        title: String(a['Title'] ?? a['title'] ?? ''),
        descriptionHtml: (a['DescriptionHtml'] ?? a['descriptionHtml']) as string | null,
        category: (a['Category'] ?? a['category']) as string | null,
        achievementDate: this.toDateInput(a['AchievementDate'] ?? a['achievementDate']),
        imageUrl: (a['ImageUrl'] ?? a['imageUrl']) as string | null,
        documentUrlsJson: (a['DocumentUrlsJson'] ?? a['documentUrlsJson']) as string | null,
        statsJson: (a['StatsJson'] ?? a['statsJson']) as string | null,
        isVerified: !!(a['IsVerified'] ?? a['isVerified']),
        isPublished: !!(a['IsPublished'] ?? a['isPublished']),
        showOnHomepage: !!(a['ShowOnHomepage'] ?? a['showOnHomepage']),
        displayOrder: Number(a['DisplayOrder'] ?? a['displayOrder'] ?? 0)
      })));
    });
    this.achievementsLoading.set(false);
  }

  editAchievement(row: AchievementRow): void {
    this.editingAchievement.set({ ...row });
  }
  newAchievement(): void {
    this.editingAchievement.set(emptyAchievement());
  }
  cancelAchievement(): void {
    this.editingAchievement.set(null);
  }

  async saveAchievement(): Promise<void> {
    const draft = this.editingAchievement();
    if (!draft || !draft.title.trim()) {
      this.toast('Achievement title is required');
      return;
    }
    this.savingAchievement.set(true);
    await this.run('Saving achievement failed', async () => {
      await this.api.upsertAchievement({
        id: draft.id, title: draft.title.trim(), descriptionHtml: draft.descriptionHtml,
        category: draft.category, achievementDate: this.toDatePayload(draft.achievementDate),
        imageUrl: draft.imageUrl, documentUrlsJson: draft.documentUrlsJson, statsJson: draft.statsJson,
        isVerified: draft.isVerified, isPublished: draft.isPublished,
        showOnHomepage: draft.showOnHomepage, displayOrder: draft.displayOrder ?? 0
      });
      this.editingAchievement.set(null);
      await this.loadAchievements();
      await this.loadSummary();
      this.toast('Achievement saved');
    });
    this.savingAchievement.set(false);
  }

  async toggleAchievement(row: AchievementRow, published: boolean): Promise<void> {
    await this.run('Publish change failed', async () => {
      await this.api.setAchievementPublished(row.id, published);
      await this.loadAchievements();
      await this.loadSummary();
      this.toast(published ? 'Achievement published' : 'Achievement unpublished');
    });
  }

  async deleteAchievement(row: AchievementRow): Promise<void> {
    await this.run('Delete failed', async () => {
      await this.api.deleteAchievement(row.id);
      await this.loadAchievements();
      await this.loadSummary();
      this.toast('Achievement deleted');
    });
  }

  // ── Articles ──
  async loadArticles(): Promise<void> {
    this.articlesLoading.set(true);
    await this.run('Loading articles', async () => {
      const list = await this.api.listArticles(undefined, null, this.articleSearch || null);
      this.articles.set(list.map(a => ({
        id: Number(a['Id'] ?? a['id']),
        title: String(a['Title'] ?? a['title'] ?? ''),
        slug: String(a['Slug'] ?? a['slug'] ?? ''),
        excerpt: (a['Excerpt'] ?? a['excerpt']) as string | null,
        bodyHtml: String(a['BodyHtml'] ?? a['bodyHtml'] ?? ''),
        coverImageUrl: (a['CoverImageUrl'] ?? a['coverImageUrl']) as string | null,
        category: (a['Category'] ?? a['category']) as string | null,
        tagsCsv: (a['TagsCsv'] ?? a['tagsCsv']) as string | null,
        isPublished: !!(a['IsPublished'] ?? a['isPublished']),
        isFeatured: !!(a['IsFeatured'] ?? a['isFeatured']),
        scheduledForUtc: (a['ScheduledForUtc'] ?? a['scheduledForUtc']) as string | null,
        seoTitle: (a['SeoTitle'] ?? a['seoTitle']) as string | null,
        seoDescription: (a['SeoDescription'] ?? a['seoDescription']) as string | null
      })));
    });
    this.articlesLoading.set(false);
  }

  editArticle(row: ArticleRow): void {
    this.editingArticle.set({ ...row });
  }
  newArticle(): void {
    this.editingArticle.set(emptyArticle());
  }
  cancelArticle(): void {
    this.editingArticle.set(null);
  }

  async saveArticle(): Promise<void> {
    const draft = this.editingArticle();
    if (!draft || !draft.title.trim() || !draft.bodyHtml.trim()) {
      this.toast('Article title and body are required');
      return;
    }
    this.savingArticle.set(true);
    await this.run('Saving article failed', async () => {
      await this.api.upsertArticle({
        id: draft.id, title: draft.title.trim(), slug: draft.slug, excerpt: draft.excerpt,
        bodyHtml: draft.bodyHtml, coverImageUrl: draft.coverImageUrl, category: draft.category,
        tagsCsv: draft.tagsCsv, isPublished: draft.isPublished, isFeatured: draft.isFeatured,
        scheduledForUtc: draft.scheduledForUtc, seoTitle: draft.seoTitle, seoDescription: draft.seoDescription
      });
      this.editingArticle.set(null);
      await this.loadArticles();
      await this.loadSummary();
      this.toast('Article saved');
    });
    this.savingArticle.set(false);
  }

  async toggleArticle(row: ArticleRow, published: boolean): Promise<void> {
    await this.run('Publish change failed', async () => {
      await this.api.setArticlePublished(row.id, published);
      await this.loadArticles();
      await this.loadSummary();
      this.toast(published ? 'Article published' : 'Article unpublished');
    });
  }

  async deleteArticle(row: ArticleRow): Promise<void> {
    await this.run('Delete failed', async () => {
      await this.api.deleteArticle(row.id);
      await this.loadArticles();
      await this.loadSummary();
      this.toast('Article deleted');
    });
  }

  // ── Campaigns ──
  async loadCampaigns(): Promise<void> {
    this.campaignsLoading.set(true);
    await this.run('Loading campaigns', async () => {
      const list = await this.api.listCampaigns(null);
      this.campaigns.set(list.map(c => ({
        id: Number(c['Id'] ?? c['id']),
        title: String(c['Title'] ?? c['title'] ?? ''),
        description: (c['Description'] ?? c['description']) as string | null,
        bannerImagePath: (c['BannerImagePath'] ?? c['bannerImagePath']) as string | null,
        mobileBannerImagePath: (c['MobileBannerImagePath'] ?? c['mobileBannerImagePath']) as string | null,
        ctaText: (c['CtaText'] ?? c['ctaText']) as string | null,
        ctaUrl: (c['CtaUrl'] ?? c['ctaUrl']) as string | null,
        displayPosition: normalizeCampaignPositionFn(String(c['DisplayPosition'] ?? c['displayPosition'] ?? 'Homepage')),
        startUtc: this.toDateTimeInput(c['StartUtc'] ?? c['startUtc']),
        endUtc: this.toDateTimeInput(c['EndUtc'] ?? c['endUtc']),
        priority: Number(c['Priority'] ?? c['priority'] ?? 0),
        status: campaignStatusLabelFn(String(c['Status'] ?? c['status'] ?? 'Draft'))
      })));
    });
    this.campaignsLoading.set(false);
  }

  private toDateTimeInput(v: unknown): string {
    if (!v) return '';
    const d = new Date(String(v));
    return isNaN(d.getTime()) ? String(v) : d.toISOString().slice(0, 16);
  }

  editCampaign(row: CampaignRow): void {
    this.editingCampaign.set({ ...row });
  }
  newCampaign(): void {
    this.editingCampaign.set(emptyCampaign());
  }
  cancelCampaign(): void {
    this.editingCampaign.set(null);
  }

  async saveCampaign(): Promise<void> {
    const draft = this.editingCampaign();
    if (!draft || !draft.title.trim()) {
      this.toast('Campaign title is required');
      return;
    }
    this.savingCampaign.set(true);
    await this.run('Saving campaign failed', async () => {
      await this.api.upsertCampaign({
        id: draft.id, title: draft.title.trim(), description: draft.description,
        bannerImagePath: draft.bannerImagePath, mobileBannerImagePath: draft.mobileBannerImagePath,
        ctaText: draft.ctaText, ctaUrl: draft.ctaUrl,
        displayPosition: this.normalizeEnumName(draft.displayPosition, ['Homepage', 'Admissions', 'Events', 'Contact', 'Sidebar'], 'Homepage'),
        startUtc: this.toDatePayload(draft.startUtc.replace('T', ' ')) ?? new Date().toISOString(),
        endUtc: this.toDatePayload(draft.endUtc?.replace('T', ' ')),
        priority: draft.priority ?? 0,
        status: this.normalizeEnumName(draft.status, this.campaignStatuses, 'Draft')
      });
      this.editingCampaign.set(null);
      await this.loadCampaigns();
      await this.loadSummary();
      this.toast('Campaign saved');
    });
    this.savingCampaign.set(false);
  }

  /** Human-friendly label → exact enum member name ("Admissions" etc.). */
  private normalizeEnumName(value: string, allowed: readonly string[], fallback: string): string {
    const found = allowed.find(a => a.toLowerCase() === value.toLowerCase().trim());
    return found ?? fallback;
  }

  async setCampaignStatus(row: CampaignRow, status: string): Promise<void> {
    await this.run('Status change failed', async () => {
      await this.api.setCampaignStatus(row.id, this.normalizeEnumName(status, this.campaignStatuses, status));
      await this.loadCampaigns();
      await this.loadSummary();
      this.toast(`Campaign ${status.toLowerCase()}`);
    });
  }

  async deleteCampaign(row: CampaignRow): Promise<void> {
    await this.run('Delete failed', async () => {
      await this.api.deleteCampaign(row.id);
      await this.loadCampaigns();
      await this.loadSummary();
      this.toast('Campaign deleted');
    });
  }

  // ── Enquiries ──
  async loadEnquiries(): Promise<void> {
    this.enquiriesLoading.set(true);
    await this.run('Loading enquiries', async () => {
      const list = await this.api.listEnquiries(null);
      this.enquiries.set(list.map(e => ({
        id: Number(e['Id'] ?? e['id']),
        parentId: Number(e['Id'] ?? e['id']),
        parentName: String(e['ParentName'] ?? e['parentName'] ?? ''),
        phone: String(e['Phone'] ?? e['phone'] ?? ''),
        email: (e['Email'] ?? e['email']) as string | null,
        message: (e['Message'] ?? e['message']) as string | null,
        classOfInterest: (e['ClassOfInterest'] ?? e['classOfInterest']) as string | null,
        status: normalizeEnquiryStatusFn(String(e['Status'] ?? e['status'] ?? 'New')),
        staffNote: (e['StaffNote'] ?? e['staffNote']) as string | null,
        convertedStudentEnquiryId: (e['ConvertedStudentEnquiryId'] ?? e['convertedStudentEnquiryId']) as number | null,
        convertedOnUtc: (e['ConvertedOnUtc'] ?? e['convertedOnUtc']) as string | null
      })));
    });
    this.enquiriesLoading.set(false);
  }

  statusLabel(value: string): string {
    return EnquiryStatusLabel(value);
  }

  async changeEnquiryStatus(row: EnquiryRow, status: string): Promise<void> {
    this.enquiryBusyId.set(row.id);
    await this.run('Status change failed', async () => {
      await this.api.updateEnquiry(row.id, this.statusLabel(status), row.staffNote ?? null);
      await this.loadEnquiries();
      await this.loadSummary();
      this.toast('Enquiry updated');
    });
    this.enquiryBusyId.set(null);
  }

  async addEnquiryNote(row: EnquiryRow, note: string): Promise<void> {
    this.enquiryBusyId.set(row.id);
    await this.run('Note update failed', async () => {
      await this.api.updateEnquiry(row.id, this.statusLabel(row.status), note);
      await this.loadEnquiries();
      this.toast('Note saved');
    });
    this.enquiryBusyId.set(null);
  }

  async convertEnquiry(row: EnquiryRow): Promise<void> {
    this.enquiryBusyId.set(row.id);
    await this.run('Conversion failed', async () => {
      await this.api.convertEnquiry(row.id);
      await this.loadEnquiries();
      await this.loadSummary();
      this.toast('Enquiry converted to a student enquiry');
    });
    this.enquiryBusyId.set(null);
  }
}
