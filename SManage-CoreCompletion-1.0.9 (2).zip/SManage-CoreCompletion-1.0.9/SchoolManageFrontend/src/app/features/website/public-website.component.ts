import { Component, OnDestroy, OnInit, computed, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { ActivatedRoute, Route, RouterLink, RouterModule } from '@angular/router';

import { TenantResolutionService } from '../../services/tenant-resolution.service';
import {
  WebsiteContentService, PublicBranding, PublicEvent, PublicAlbum,
  PublicAlbumMedia, PublicCatalogItem
} from '../../shared/services/website-content.service';

type SiteView = 'home' | 'events' | 'event-detail' | 'albums' | 'album-detail' | 'news' | 'article-detail' | 'apply';

interface EnquiryForm {
  parentName: string;
  phone: string;
  email: string;
  classOfInterest: string;
  message: string;
}

@Component({
  selector: 'app-public-website',
  standalone: true,
  imports: [
    CommonModule, FormsModule, RouterLink, RouterModule,
    MatProgressSpinnerModule, MatButtonModule, MatIconModule,
    MatFormFieldModule, MatInputModule, MatSnackBarModule
  ],
  templateUrl: './public-website.component.html',
  styleUrls: ['./public-website.component.scss']
})
export class PublicWebsiteComponent implements OnInit, OnDestroy {
  readonly tenantResolution = inject(TenantResolutionService);
  private readonly route = inject(ActivatedRoute);
  private readonly api = inject(WebsiteContentService);
  private readonly snackBar = inject(MatSnackBar);

  readonly view = signal<SiteView>('home');
  readonly loading = signal(false);

  readonly branding = signal<PublicBranding | null>(null);
  readonly campaigns = signal<Record<string, unknown>[]>([]);

  // Campaign banner slider: index + auto-advance timer + touch swipe state.
  readonly campaignIndex = signal(0);
  readonly showSliderControls = computed(() => this.campaigns().length > 1);
  private campaignTimer: ReturnType<typeof setInterval> | null = null;
  private touchStartX: number | null = null;

  readonly events = signal<PublicEvent[]>([]);
  readonly currentEvent = signal<PublicEvent | null>(null);
  readonly albums = signal<PublicAlbum[]>([]);
  readonly currentAlbum = signal<PublicAlbum | null>(null);
  readonly albumPhotos = signal<PublicAlbumMedia[]>([]);
  readonly achievements = signal<PublicCatalogItem[]>([]);
  readonly articles = signal<PublicCatalogItem[]>([]);
  readonly currentArticle = signal<PublicCatalogItem | null>(null);

  readonly enquiryEnabled = signal(false);
  readonly enquirySubmitting = signal(false);
  readonly enquirySubmitted = signal(false);
  readonly enquiryForm = signal<EnquiryForm>({ parentName: '', phone: '', email: '', classOfInterest: '', message: '' });

  readonly schoolName = computed(() => this.tenantResolution.schoolName() ?? this.branding()?.tenantName ?? 'School');
  readonly suspended = computed(() => this.tenantResolution.siteKind() === 'school-inactive');
  readonly websitePublished = computed(() => this.branding()?.isWebsitePublished !== false);

  socialLinks: { label: string; url: string }[] = [];

  async ngOnInit(): Promise<void> {
    // The host must be a bound, ACTIVE school (guard also enforces; double-check).
    await this.tenantResolution.initialize();
    if (this.tenantResolution.siteKind() !== 'school') return;

    switch (this.route.snapshot.data['view'] as SiteView) {
      case 'events': this.view.set('events'); await this.loadEvents(); break;
      case 'event-detail': this.view.set('event-detail'); await this.loadEventDetail(); break;
      case 'albums': this.view.set('albums'); await this.loadAlbums(); break;
      case 'album-detail': this.view.set('album-detail'); await this.loadAlbumDetail(); break;
      case 'news': this.view.set('news'); await this.loadArticles(); break;
      case 'article-detail': this.view.set('article-detail'); await this.loadArticleDetail(); break;
      case 'apply': this.view.set('apply'); await this.loadEnquiryStatus(); break;
      default: this.view.set('home'); await this.loadHome();
    }
  }

  reloadCurrent(): void {
    window.location.reload();
  }

  private async guarded(work: () => Promise<void>): Promise<void> {
    this.loading.set(true);
    try {
      if (!this.branding()) {
        try {
          this.branding.set(await this.api.getPublicBranding());
          this.parseSocialLinks();
        } catch { /* unknown host handled by guard */ }
      }
      await work();
    } catch (err: unknown) {
      this.snackBar.open('Could not load this section. Please refresh.', 'Close', { duration: 4000 });
    }
    this.loading.set(false);
  }

  private parseSocialLinks(): void {
    try {
      const raw = this.branding()?.socialLinksJson;
      this.socialLinks = raw ? (JSON.parse(raw) as { label: string; url: string }[]) : [];
    } catch {
      this.socialLinks = [];
    }
  }

  private async loadHome(): Promise<void> {
    await this.guarded(async () => {
      // Campaigns for the top of the homepage (position:Homepage).
      this.api.getPublicCampaigns('Homepage').then(c => {
        this.campaigns.set(c as Record<string, unknown>[]);
        this.startCampaignSlider();
      }).catch(() => { });

      this.api.getPublicEvents(6).then(e => this.events.set(e)).catch(() => { });
      this.api.getPublicAlbums(6).then(a => this.albums.set(a)).catch(() => { });
      this.api.getPublicAchievements(true).then(a => this.achievements.set(a)).catch(() => { });
      this.api.getPublicArticles(null, null, 1, 3).then(n => this.articles.set(n)).catch(() => { });
      this.api.isEnquiryEnabled().then(e => this.enquiryEnabled.set(e)).catch(() => { });
    });
  }

  private async loadEvents(): Promise<void> {
    await this.guarded(async () => {
      this.events.set(await this.api.getPublicEvents(0));
    });
  }

  private async loadEventDetail(): Promise<void> {
    await this.guarded(async () => {
      const slug = this.route.snapshot.paramMap.get('slug') ?? '';
      this.currentEvent.set(await this.api.getPublicEvent(slug));
    });
  }

  private async loadAlbums(): Promise<void> {
    await this.guarded(async () => {
      this.albums.set(await this.api.getPublicAlbums(0));
    });
  }

  private async loadAlbumDetail(): Promise<void> {
    await this.guarded(async () => {
      const slug = this.route.snapshot.paramMap.get('slug') ?? '';
      const res = await this.api.getPublicAlbum(slug);
      this.currentAlbum.set(res.album);
      this.albumPhotos.set(res.media ?? []);
    });
  }

  private async loadArticles(): Promise<void> {
    await this.guarded(async () => {
      this.articles.set(await this.api.getPublicArticles(null, null, 1, 50));
    });
  }

  private async loadArticleDetail(): Promise<void> {
    await this.guarded(async () => {
      const slug = this.route.snapshot.paramMap.get('slug') ?? '';
      this.currentArticle.set(await this.api.getPublicArticle(slug));
    });
  }

  private async loadEnquiryStatus(): Promise<void> {
    await this.guarded(async () => {
      this.enquiryEnabled.set(await this.api.isEnquiryEnabled());
    });
  }

  async submitEnquiry(): Promise<void> {
    const form = this.enquiryForm();
    if (!form.parentName.trim() || !form.phone.trim()) {
      this.snackBar.open('Parent name and phone are required.', 'Close', { duration: 3500 });
      return;
    }
    this.enquirySubmitting.set(true);
    try {
      await this.api.submitEnquiry({
        parentName: form.parentName.trim(),
        phone: form.phone.trim(),
        email: form.email.trim() || null,
        classOfInterest: form.classOfInterest.trim() || null,
        message: form.message.trim() || null,
        sourcePath: '/site/apply'
      });
      this.enquirySubmitted.set(true);
    } catch (err: unknown) {
      this.snackBar.open('Could not submit the enquiry. Please try again.', 'Close', { duration: 4000 });
    }
    this.enquirySubmitting.set(false);
  }

  // ── Campaign banner slider ────────────────────────────────────────────────

  startCampaignSlider(): void {
    this.stopCampaignSlider();
    if (this.campaigns().length > 1) {
      this.campaignTimer = setInterval(() => {
        this.campaignIndex.update(i => (i + 1) % this.campaigns().length);
      }, 6000);
    }
  }

  stopCampaignSlider(): void {
    if (this.campaignTimer) {
      clearInterval(this.campaignTimer);
      this.campaignTimer = null;
    }
  }

  goToCampaign(i: number): void {
    const n = this.campaigns().length;
    if (n > 0) this.campaignIndex.set(((i % n) + n) % n);
  }

  onTouchStart(e: TouchEvent): void {
    this.touchStartX = e.touches[0]?.clientX ?? null;
  }

  onTouchEnd(e: TouchEvent): void {
    if (this.touchStartX == null) return;
    const n = this.campaigns().length;
    const dx = e.changedTouches[0].clientX - this.touchStartX;
    this.touchStartX = null;
    if (n > 1 && dx < -40) this.goToCampaign(this.campaignIndex() + 1);
    else if (n > 1 && dx > 40) this.goToCampaign(this.campaignIndex() - 1);
  }

  ngOnDestroy(): void {
    this.stopCampaignSlider();
  }

  currentYear(): number {
    return new Date().getFullYear();
  }

  detailDate(dateIso?: string | null): string {
    if (!dateIso) return '';
    const d = new Date(dateIso);
    return isNaN(d.getTime()) ? '' : d.toLocaleDateString();
  }

  imageFor(path?: string | null): string | null {
    if (!path) return null;
    return path.startsWith('http') || path.startsWith('data:') ? path : `/${path}`;
  }
}
