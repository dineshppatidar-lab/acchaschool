import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';

export interface Parent {
  id: number;
  firstName: string;
  lastName: string;
  contactNumber: string;
  email: string;
  occupation: string;
  userId?: number;
}

export interface ApiResponse<T> {
  data: T;
  message: string;
  success: boolean;
  errors?: string[];
}

@Injectable({
  providedIn: 'root'
})
export class ParentService {
  private apiUrl = '/api/parents';

  constructor(private http: HttpClient) { }

  getParents(): Observable<ApiResponse<Parent[]>> {
    return this.http.get<ApiResponse<Parent[]>>(this.apiUrl);
  }

  getParent(id: number): Observable<ApiResponse<Parent>> {
    return this.http.get<ApiResponse<Parent>>(`${this.apiUrl}/${id}`);
  }

  createParent(parent: Parent): Observable<ApiResponse<Parent>> {
    return this.http.post<ApiResponse<Parent>>(this.apiUrl, parent);
  }

  updateParent(id: number, parent: Parent): Observable<ApiResponse<any>> {
    return this.http.put<ApiResponse<any>>(`${this.apiUrl}/${id}`, parent);
  }

  deleteParent(id: number): Observable<ApiResponse<any>> {
    return this.http.delete<ApiResponse<any>>(`${this.apiUrl}/${id}`);
  }
}