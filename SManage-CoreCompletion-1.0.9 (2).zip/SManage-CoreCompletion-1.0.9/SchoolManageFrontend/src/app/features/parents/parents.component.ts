import { Component, Inject, OnInit, ViewChild, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatTableModule, MatTableDataSource } from '@angular/material/table';
import { MatPaginatorModule, MatPaginator } from '@angular/material/paginator';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatDialogModule, MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatSnackBarModule, MatSnackBar } from '@angular/material/snack-bar';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatCardModule } from '@angular/material/card';
import { MatChipsModule } from '@angular/material/chips';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { ParentService } from './parent.service';
import { StudentPageHeaderComponent } from '../../shared/components/students-module/student-page-header.component';
import { DialogUtils } from '../../shared/dialog-utils';

export interface ParentStudentInfo {
  studentId: number;
  fullName: string;
  className: string;
  sectionName: string;
}

export interface Parent {
  id: number;
  firstName: string;
  lastName: string;
  email: string;
  contactNumber: string;
  occupation: string;
  address: string;
  relationship: string;
  isEmergencyContact: boolean;
  students: ParentStudentInfo[];
}

@Component({
  selector: 'app-parents-management',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatTableModule,
    MatPaginatorModule,
    MatButtonModule,
    MatIconModule,
    MatDialogModule,
    MatSnackBarModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatCardModule,
    MatChipsModule,
    MatTooltipModule,
    StudentPageHeaderComponent
  ],
  templateUrl: './parents.component.html',
  styleUrls: ['./parents.component.scss']
})
export class ParentsComponent implements OnInit {
  @ViewChild(MatPaginator) paginator!: MatPaginator;

  dataSource = new MatTableDataSource<Parent>();
  displayedColumns: string[] = ['name', 'email', 'phone', 'relationship', 'occupation', 'students', 'actions'];

  loading = signal(false);

  constructor(
    private snackBar: MatSnackBar,
    private dialog: MatDialog,
    private dialogUtils: DialogUtils,
    private parentService: ParentService
  ) {}

  ngOnInit(): void {
    this.loadParents();
  }

  loadParents(): void {
    this.loading.set(true);
    this.parentService.getParents().subscribe({
      next: (res: any) => {
        const data: any[] = res?.data || res || [];
        this.dataSource.data = (Array.isArray(data) ? data : []).map((p: any) => this.mapParent(p));
        setTimeout(() => { this.dataSource.paginator = this.paginator; });
        this.loading.set(false);
      },
      error: (err) => {
        console.error('Failed to load parents', err);
        this.loading.set(false);
        this.showInfo(err?.error?.message || 'Failed to load parents');
      }
    });
  }

  private mapParent(p: any): Parent {
    return {
      id: p.id,
      firstName: p.firstName ?? '',
      lastName: p.lastName ?? '',
      email: p.email ?? '',
      contactNumber: p.contactNumber || p.phoneNumber || '',
      occupation: p.occupation ?? '',
      address: p.address ?? '',
      relationship: p.relationship ?? '',
      isEmergencyContact: !!p.isEmergencyContact,
      students: (p.students ?? []).map((s: any) => ({
        studentId: s.studentId ?? s.id ?? 0,
        fullName: s.fullName ?? `${s.firstName ?? ''} ${s.lastName ?? ''}`.trim(),
        className: s.className ?? '',
        sectionName: s.sectionName ?? ''
      }))
    };
  }

  applyFilter(event: Event): void {
    const term = ((event.target as HTMLInputElement).value || '').trim().toLowerCase();
    this.dataSource.filterPredicate = (p, f) =>
      `${p.firstName} ${p.lastName} ${p.email} ${p.contactNumber} ${p.occupation}`.toLowerCase().includes(f);
    this.dataSource.filter = term;
  }

  openAddDialog(): void {
    this.openEditDialog(null);
  }

  openEditDialog(parent: Parent | null): void {
    const dialogRef = this.dialog.open(ParentEditDialog, {
        ...this.dialogUtils.getMobileConfig({ width: '560px' }),
        data: {
                mode: parent ? 'edit' : 'create',
        parent: parent
      }
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (!result) return;
      this.saveParent(result, parent);
    });
  }

  private saveParent(formValue: any, existing: Parent | null): void {
    const payload = {
      id: existing?.id ?? 0,
      firstName: formValue.firstName,
      lastName: formValue.lastName,
      email: formValue.email || '',
      contactNumber: formValue.contactNumber,
      occupation: formValue.occupation || '',
      address: formValue.address || '',
      relationship: formValue.relationship || '',
      isEmergencyContact: !!formValue.isEmergencyContact
    };

    const request$ = existing
      ? this.parentService.updateParent(existing.id, payload as any)
      : this.parentService.createParent(payload as any);

    request$.subscribe({
      next: () => {
        this.showSuccess(existing ? 'Parent updated successfully' : 'Parent added successfully');
        this.loadParents();
      },
      error: (err) => {
        const msg = err?.status === 409
          ? (err?.error?.message || 'A parent with this email already exists')
          : (err?.error?.message || err?.error?.title || (existing ? 'Failed to update parent' : 'Failed to add parent'));
        this.showInfo(msg);
      }
    });
  }

  viewParentDetails(parent: Parent): void {
    this.dialog.open(ParentDetailsDialog, {
        ...this.dialogUtils.getMobileConfig({ width: '520px', data: parent }),
            });
  }

  deleteParent(parent: Parent): void {
    if (!confirm(`Delete ${parent.firstName} ${parent.lastName}? This cannot be undone.`)) {
      return;
    }
    this.parentService.deleteParent(parent.id).subscribe({
      next: () => {
        this.showSuccess('Parent deleted successfully');
        this.loadParents();
      },
      error: (err) => {
        const msg = err?.error?.message || err?.error?.errors?.join(', ') || 'Failed to delete parent';
        this.showInfo(msg);
      }
    });
  }

  private showSuccess(message: string): void {
    this.snackBar.open(message, 'Close', { duration: 3000, panelClass: ['success-snackbar'] });
  }

  private showInfo(message: string): void {
    this.snackBar.open(message, 'Close', { duration: 3500, panelClass: ['info-snackbar'] });
  }
}

/** Add/Edit dialog for parents. */
@Component({
  selector: 'app-parent-edit-dialog',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatDialogModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatButtonModule,
    MatCheckboxModule
  ],
  template: `
    <h2 mat-dialog-title>{{ data.mode === 'edit' ? 'Edit Parent' : 'Add Parent' }}</h2>
    <mat-dialog-content>
      <form [formGroup]="form" class="parent-form">
        <mat-form-field appearance="outline">
          <mat-label>First Name *</mat-label>
          <input matInput formControlName="firstName" />
          <mat-error>First name is required</mat-error>
        </mat-form-field>

        <mat-form-field appearance="outline">
          <mat-label>Last Name *</mat-label>
          <input matInput formControlName="lastName" />
          <mat-error>Last name is required</mat-error>
        </mat-form-field>

        <mat-form-field appearance="outline">
          <mat-label>Email</mat-label>
          <input matInput type="email" formControlName="email" placeholder="parent@example.com" />
          <mat-error>Please enter a valid email</mat-error>
        </mat-form-field>

        <mat-form-field appearance="outline">
          <mat-label>Contact Number *</mat-label>
          <input matInput formControlName="contactNumber" />
          <mat-error>Contact number is required</mat-error>
        </mat-form-field>

        <mat-form-field appearance="outline">
          <mat-label>Relationship</mat-label>
          <mat-select formControlName="relationship">
            <mat-option value="">Not specified</mat-option>
            <mat-option value="Father">Father</mat-option>
            <mat-option value="Mother">Mother</mat-option>
            <mat-option value="Guardian">Guardian</mat-option>
          </mat-select>
        </mat-form-field>

        <mat-form-field appearance="outline">
          <mat-label>Occupation</mat-label>
          <input matInput formControlName="occupation" />
        </mat-form-field>

        <mat-form-field appearance="outline" class="full-width">
          <mat-label>Address</mat-label>
          <textarea matInput formControlName="address" rows="2"></textarea>
        </mat-form-field>

        <div class="full-width checkbox-row">
          <mat-checkbox formControlName="isEmergencyContact">Emergency contact</mat-checkbox>
        </div>
      </form>
    </mat-dialog-content>
    <mat-dialog-actions align="end">
      <button mat-button (click)="cancel()">Cancel</button>
      <button mat-raised-button color="primary" (click)="save()" [disabled]="form.invalid">
        {{ data.mode === 'edit' ? 'Save Changes' : 'Add Parent' }}
      </button>
    </mat-dialog-actions>
  `,
  styles: [`
    .parent-form {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 14px;
    }
    .parent-form mat-form-field { width: 100%; }
    .full-width { grid-column: span 2; }
    .checkbox-row { display: flex; align-items: center; margin-top: 4px; }
    @media (max-width: 600px) {
      .parent-form { grid-template-columns: 1fr; min-width: 0; }
      .full-width { grid-column: 1 / -1; }
      h2[mat-dialog-title] { font-size: var(--font-size-base); padding: 12px 16px 8px; }
      mat-dialog-content { padding: 0 14px !important; }
    }
  `]
})
export class ParentEditDialog {
  form: FormGroup;

  constructor(
    private fb: FormBuilder,
    public dialogRef: MatDialogRef<ParentEditDialog>,
    @Inject(MAT_DIALOG_DATA) public data: { mode: 'create' | 'edit'; parent: Parent | null }
  ) {
    const p = data.parent;
    this.form = this.fb.group({
      firstName: [p?.firstName ?? '', Validators.required],
      lastName: [p?.lastName ?? '', Validators.required],
      email: [p?.email ?? '', [Validators.email]],
      contactNumber: [p?.contactNumber ?? '', Validators.required],
      relationship: [p?.relationship ?? ''],
      occupation: [p?.occupation ?? ''],
      address: [p?.address ?? ''],
      isEmergencyContact: [p?.isEmergencyContact ?? false]
    });
  }

  cancel(): void {
    this.dialogRef.close();
  }

  save(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    this.dialogRef.close(this.form.value);
  }
}

/** Read-only details dialog. */
@Component({
  selector: 'app-parent-details-dialog',
  standalone: true,
  imports: [CommonModule, MatDialogModule, MatButtonModule, MatIconModule, MatChipsModule],
  template: `
    <h2 mat-dialog-title>
      <mat-icon class="title-icon">person</mat-icon>
      {{ data.firstName }} {{ data.lastName }}
    </h2>
    <mat-dialog-content>
      <div class="detail-grid">
        <div class="detail-item"><span class="label">Email</span><span>{{ data.email || '—' }}</span></div>
        <div class="detail-item"><span class="label">Phone</span><span>{{ data.contactNumber || '—' }}</span></div>
        <div class="detail-item"><span class="label">Relationship</span><span>{{ data.relationship || '—' }}</span></div>
        <div class="detail-item"><span class="label">Occupation</span><span>{{ data.occupation || '—' }}</span></div>
        <div class="detail-item full"><span class="label">Address</span><span>{{ data.address || '—' }}</span></div>
        <div class="detail-item full">
          <span class="label">Emergency contact</span>
          <span>{{ data.isEmergencyContact ? 'Yes' : 'No' }}</span>
        </div>
      </div>

      <h3 class="section-title">Linked Students</h3>
      <mat-chip-set *ngIf="data.students?.length; else none">
        <mat-chip *ngFor="let s of data.students">
          <mat-icon matChipAvatar>school</mat-icon>
          {{ s.fullName }}{{ s.className ? ' — ' + s.className + (s.sectionName ? ' ' + s.sectionName : '') : '' }}
        </mat-chip>
      </mat-chip-set>
      <ng-template #none>
        <p class="muted">No students linked to this parent.</p>
      </ng-template>
    </mat-dialog-content>
    <mat-dialog-actions align="end">
      <button mat-button (click)="close()">Close</button>
    </mat-dialog-actions>
  `,
  styles: [`
    .title-icon { vertical-align: middle; margin-right: 8px; }
    .detail-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 12px;
      margin-bottom: 16px;
    }
    .detail-item { display: flex; flex-direction: column; gap: 2px; }
    .detail-item.full { grid-column: span 2; }
    .label { font-size: 12px; color: var(--color-text-secondary); text-transform: uppercase; letter-spacing: 0.04em; }
    .section-title { margin: 8px 0; font-size: var(--font-size-base); font-weight: 600; }
    .muted { color: var(--md-outline); font-style: italic; }
  `]
})
export class ParentDetailsDialog {
  constructor(
    @Inject(MAT_DIALOG_DATA) public data: Parent,
    public dialogRef: MatDialogRef<ParentDetailsDialog>
  ) {}

  close(): void {
    this.dialogRef.close();
  }
}
