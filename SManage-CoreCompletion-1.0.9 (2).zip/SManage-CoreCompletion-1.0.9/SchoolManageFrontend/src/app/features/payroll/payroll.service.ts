import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { PayrollRun } from './payroll.model';

@Injectable({
  providedIn: 'root'
})
export class PayrollService {
  private baseUrl = '/api/payroll';

  constructor(private http: HttpClient) {}

  getPayrollRuns(): Observable<PayrollRun[]> {
    return this.http.get<PayrollRun[]>(`${this.baseUrl}/runs`);
  }

  processPayroll(year: number, month: number): Observable<any> {
    return this.http.post(`${this.baseUrl}/process`, { year, month });
  }

  getPayrollRunDetails(id: number): Observable<PayrollRun> {
    return this.http.get<PayrollRun>(`${this.baseUrl}/runs/${id}`);
  }
}