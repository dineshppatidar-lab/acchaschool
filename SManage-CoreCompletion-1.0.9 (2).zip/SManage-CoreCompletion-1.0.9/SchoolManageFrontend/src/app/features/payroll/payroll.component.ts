import { ChangeDetectionStrategy, ChangeDetectorRef, Component, Inject, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatTableModule } from '@angular/material/table';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatDialog, MatDialogModule, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { PayrollService } from './payroll.service';
import { PayrollRun } from './payroll.model';
import { CanWriteDirective } from '../../core/directives/permission.directive';
import { Permission } from '../../core/models/permission.model';
import { DialogUtils } from '../../shared/dialog-utils';

@Component({
  selector: 'app-payroll',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatCardModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatButtonModule,
    MatTableModule,
    MatIconModule,
    MatProgressSpinnerModule,
    MatDialogModule,
    CanWriteDirective
  ],
  templateUrl: './payroll.component.html',
  styleUrls: ['./payroll.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class PayrollComponent implements OnInit {
  Permission = Permission;
  processForm: FormGroup;
  payrollRuns = signal<any[]>([]);
  displayedColumns: string[] = ['period', 'payDate', 'totalAmount', 'status', 'actions'];
  
  isLoading = signal(false);
  isProcessing = signal(false);

  months = [
    { value: 1, viewValue: 'January' }, { value: 2, viewValue: 'February' },
    { value: 3, viewValue: 'March' }, { value: 4, viewValue: 'April' },
    { value: 5, viewValue: 'May' }, { value: 6, viewValue: 'June' },
    { value: 7, viewValue: 'July' }, { value: 8, viewValue: 'August' },
    { value: 9, viewValue: 'September' }, { value: 10, viewValue: 'October' },
    { value: 11, viewValue: 'November' }, { value: 12, viewValue: 'December' }
  ];
  years: number[] = [];

  constructor(
    private fb: FormBuilder,
    private payrollService: PayrollService,
    private snackBar: MatSnackBar,
    private cdr: ChangeDetectorRef,
    private dialog: MatDialog,
    private dialogUtils: DialogUtils,
  ) {
    const currentYear = new Date().getFullYear();
    for (let i = currentYear - 5; i <= currentYear + 1; i++) {
      this.years.push(i);
    }

    this.processForm = this.fb.group({
      month: [new Date().getMonth() + 1, Validators.required],
      year: [currentYear, Validators.required],
    });
  }

  ngOnInit(): void {
    this.loadPayrollRuns();
  }

  loadPayrollRuns(): void {
    this.isLoading.set(true);
    this.payrollService.getPayrollRuns().subscribe({
      next: (data: PayrollRun[]) => {
        this.payrollRuns.set(data);
        this.isLoading.set(false);
        this.cdr.markForCheck();
      },
      error: (err: any) => {
        this.isLoading.set(false);
        this.snackBar.open('Failed to load payroll history.', 'Close', { duration: 3000 });
        this.cdr.markForCheck();
      }
    });
  }

  processPayroll(): void {
    if (this.processForm.invalid) {
      // Highlight validation errors on the UI instead of silently failing
      this.processForm.markAllAsTouched();
      console.warn('Form is invalid! Check if month and year are selected.', this.processForm.value);
      return;
    }
    
    this.isProcessing.set(true);
    
    // Ensure year and month are sent as strict integers to prevent .NET 400 Bad Request validation errors
    const year = parseInt(this.processForm.value.year, 10);
    const month = parseInt(this.processForm.value.month, 10);

    console.log(`Sending API request to /api/payroll/process for ${month}/${year}...`);

    this.payrollService.processPayroll(year, month).subscribe({
      next: (res: any) => {
        this.isProcessing.set(false);
        this.snackBar.open(res?.message || 'Payroll processed successfully!', 'Close', { duration: 3000 });
        this.loadPayrollRuns(); // Refresh the list
        this.cdr.markForCheck();
      },
      error: (err: any) => {
        this.isProcessing.set(false);
        this.snackBar.open(err?.error?.message || 'Failed to process payroll.', 'Close', { duration: 5000 });
        this.cdr.markForCheck();
      }
    });
  }

  viewPayslips(run: PayrollRun): void {
    this.payrollService.getPayrollRunDetails(run.id).subscribe({
      next: (details) => {
        this.dialog.open(PayslipsDialogComponent, {
        ...this.dialogUtils.getMobileConfig({ width: '800px', data: details }),
                });
      },
      error: () => {
        this.snackBar.open('Failed to load payslip details.', 'Close', { duration: 3000 });
      }
    });
  }
}

@Component({
  selector: 'app-payslips-dialog',
  standalone: true,
  imports: [CommonModule, MatTableModule, MatButtonModule, MatDialogModule],
  template: `
    <h2 mat-dialog-title>Payslips - {{ data.month }}/{{ data.year }}</h2>
    <mat-dialog-content>
      <table mat-table [dataSource]="data.payslips || []" class="mat-elevation-z2" style="width: 100%; margin-top: 10px;">
        <ng-container matColumnDef="staff">
          <th mat-header-cell *matHeaderCellDef> Staff </th>
          <td mat-cell *matCellDef="let p"> {{ p.staff?.firstName }} {{ p.staff?.lastName }} </td>
        </ng-container>
        <ng-container matColumnDef="role">
          <th mat-header-cell *matHeaderCellDef> Role/Position </th>
          <td mat-cell *matCellDef="let p"> {{ p.staff?.role || p.staff?.position }} </td>
        </ng-container>
        <ng-container matColumnDef="basic">
          <th mat-header-cell *matHeaderCellDef> Basic Salary </th>
          <td mat-cell *matCellDef="let p"> {{ p.basicSalary | currency:'INR' }} </td>
        </ng-container>
        <ng-container matColumnDef="net">
          <th mat-header-cell *matHeaderCellDef> Net Salary </th>
          <td mat-cell *matCellDef="let p"> {{ p.netSalary | currency:'INR' }} </td>
        </ng-container>
        <tr mat-header-row *matHeaderRowDef="['staff', 'role', 'basic', 'net']"></tr>
        <tr mat-row *matRowDef="let row; columns: ['staff', 'role', 'basic', 'net'];"></tr>
      </table>
      <div *ngIf="!data?.payslips?.length" style="padding: 20px; text-align: center; color: var(--color-text-secondary);">
        No payslips found for this run.
      </div>
    </mat-dialog-content>
    <mat-dialog-actions align="end">
      <button mat-button mat-dialog-close>Close</button>
    </mat-dialog-actions>
  `
})
export class PayslipsDialogComponent {
  constructor(@Inject(MAT_DIALOG_DATA) public data: PayrollRun) {}
}