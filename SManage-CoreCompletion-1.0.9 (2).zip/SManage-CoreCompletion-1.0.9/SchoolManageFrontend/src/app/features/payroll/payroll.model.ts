export interface PayrollRun {
  id: number;
  month: number;
  year: number;
  totalAmount: number;
  status: string;
  payDate?: string | Date;
  payslips?: Payslip[];
}

export interface Payslip {
  id?: number;
  staffId: number;
  basicSalary: number;
  netSalary: number;
  staff?: StaffSummary;
}

export interface StaffSummary {
  id: number;
  firstName: string;
  lastName: string;
  role?: string;
  position?: string;
}