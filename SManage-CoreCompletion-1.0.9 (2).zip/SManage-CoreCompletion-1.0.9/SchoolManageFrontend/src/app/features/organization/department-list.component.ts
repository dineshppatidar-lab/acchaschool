import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatTableModule } from '@angular/material/table';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { PageHeaderComponent } from '../../shared/components/page-patterns/page-header.component';
import { LookupRow } from '../staff/designation-list.component';
import { PromptDialogComponent } from '../../shared/prompt-dialog.component';
import { ConfirmDialogComponent } from '../../shared/confirm-dialog.component';
import { MasterDataService } from '../../services/master-data.service';
import { DialogUtils } from '../../shared/dialog-utils';

@Component({
  selector: 'app-department-list',
  standalone: true,
  imports: [
    CommonModule,
    MatIconModule,
    MatButtonModule,
    MatTableModule,
    MatCardModule,
    MatFormFieldModule,
    MatInputModule,
    MatTooltipModule,
    MatProgressSpinnerModule,
    MatSnackBarModule,
    PageHeaderComponent
  ],
  templateUrl: './department-list.component.html',
  styleUrls: ['./department-list.component.scss', '../../shared/styles/master-list.scss']
})
export class DepartmentListComponent implements OnInit {
  departments = signal<any[]>([]);
  filteredDepartments: LookupRow[] = [];
  // NOTE: internal row.value still holds the DB id for edit/delete — it is just not shown.
  displayedColumns: string[] = ['label', 'actions'];

  // Zoneless CD: signal writes schedule their own change-detection pass, so mutating
  // this from HTTP / dialog-close callbacks can never trip NG0100.
  readonly isLoading = signal(true);
  searchTerm = '';

  constructor(
    private masterDataService: MasterDataService,
    private dialog: MatDialog,
    private dialogUtils: DialogUtils,
    private snackBar: MatSnackBar
  ) {}

  ngOnInit() {
    this.loadDepartments();
  }

  loadDepartments() {
    this.isLoading.set(true);
    // Generic DB-backed endpoint: rows carry real IDs so edit/delete hit the right row
    // (the typed string[] endpoint is now DB-backed too, but has no IDs).
    this.masterDataService.getLookupData('staff-departments').subscribe({
      next: (rows) => {
        this.departments.set(this.toRows(rows));
        this.applySearch();
        this.isLoading.set(false);
      },
      error: (err) => {
        console.error('Error loading departments:', err);
        this.isLoading.set(false);
        this.snackBar.open('Failed to load departments', 'Close', { duration: 3000 });
      }
    });
  }

  private toRows(rows: any): LookupRow[] {
    if (!Array.isArray(rows)) return [];
    return rows.map((r: any, i: number) =>
      typeof r === 'string' ? { value: i + 1, label: r } : { value: r.value ?? i + 1, label: r.label ?? String(r) }
    );
  }

  applySearch() {
    const term = this.searchTerm.trim().toLowerCase();
    this.filteredDepartments = !term
      ? [...this.departments()]
      : this.departments().filter(d => d.label.toLowerCase().includes(term));
  }

  onSearchChange(event: Event) {
    this.searchTerm = (event.target as HTMLInputElement).value;
    this.applySearch();
  }

  createDepartment() {
    this.openDialog(null);
  }

  editDepartment(row: LookupRow) {
    this.openDialog(row);
  }

  private openDialog(row: LookupRow | null) {
    const dialogRef = this.dialog.open(PromptDialogComponent, {
        ...this.dialogUtils.getMobileConfig({ width: '420px' }),
        data: {
                title: row ? 'Edit Department' : 'New Department',
        message: row
          ? 'Rename this department. Staff already assigned keep their records.'
          : 'Enter a name for the new department.',
        initialValue: row?.label ?? '',
        placeholder: 'Department name',
        confirmText: row ? 'Save' : 'Create',
        icon: 'account_tree'
      }
    });

    dialogRef.afterClosed().subscribe((result: string | null) => {
      if (!result) return;
      const request = row
        ? this.masterDataService.updateLookupData('staff-departments', row.value, { value: row.value, label: result })
        : this.masterDataService.createLookupData('staff-departments', { value: 0, label: result });

      request.subscribe({
        next: () => {
          this.snackBar.open(row ? 'Department updated' : 'Department created', 'Close', { duration: 2500 });
          this.loadDepartments();
        },
        error: (err) => {
          this.snackBar.open(err?.error?.message || err?.error?.title || 'Failed to save department', 'Close', { duration: 3500 });
        }
      });
    });
  }

  deleteDepartment(row: LookupRow) {
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
        ...this.dialogUtils.getMobileConfig({ width: '400px' }),
        data: {
                title: 'Delete department?',
        message: `Delete "${row.label}"? Existing staff keep their records, but it won't be selectable for new staff.`,
        confirmText: 'Delete',
        cancelText: 'Cancel',
        icon: 'delete_forever',
        severity: 'danger' as const
      }
    });

    dialogRef.afterClosed().subscribe((confirmed: boolean) => {
      if (!confirmed) return;
      this.masterDataService.deleteLookupData('staff-departments', row.value).subscribe({
        next: () => {
          this.snackBar.open('Department deleted', 'Close', { duration: 2500 });
          this.loadDepartments();
        },
        error: (err) => {
          this.snackBar.open(err?.error?.message || 'Failed to delete department', 'Close', { duration: 3500 });
        }
      });
    });
  }
}
