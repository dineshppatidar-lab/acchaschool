import { Component, Inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatDialogModule, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { MatInputModule } from '@angular/material/input';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-auto-generate-timetable-dialog',
  standalone: true,
  imports: [
    CommonModule,
    MatDialogModule,
    MatButtonModule,
    MatFormFieldModule,
    MatSelectModule,
    MatInputModule,
    MatCheckboxModule,
    MatProgressBarModule,
    ReactiveFormsModule,
    MatIconModule
  ],
  template: `
    <mat-dialog-content>
      <h2 mat-dialog-title>
        <mat-icon>auto_fix_high</mat-icon>
        Auto Generate Timetable
      </h2>
      <form [formGroup]="autoGenerateForm" class="dialog-form">
        <mat-form-field>
          <mat-label>Academic Year</mat-label>
          <mat-select formControlName="academicYearId">
            <mat-option *ngFor="let year of data.academicYears" [value]="year.id">
              {{ year.name }}
            </mat-option>
          </mat-select>
        </mat-form-field>

        <mat-form-field>
          <mat-label>Class</mat-label>
          <mat-select formControlName="classId">
            <mat-option *ngFor="let class of data.classes" [value]="class.id">
              {{ class.name }}
            </mat-option>
          </mat-select>
        </mat-form-field>

        <mat-form-field>
          <mat-label>Priority Strategy</mat-label>
          <mat-select formControlName="priorityStrategy">
            <mat-option value="teacher_availability">Teacher Availability</mat-option>
            <mat-option value="subject_distribution">Subject Distribution</mat-option>
            <mat-option value="room_optimization">Room Optimization</mat-option>
            <mat-option value="balanced">Balanced Approach</mat-option>
          </mat-select>
        </mat-form-field>

        <mat-form-field>
          <mat-label>Periods Per Day</mat-label>
          <mat-select formControlName="periodsPerDay">
            <mat-option value="6">6 Periods</mat-option>
            <mat-option value="7">7 Periods</mat-option>
            <mat-option value="8">8 Periods</mat-option>
          </mat-select>
        </mat-form-field>

        <div class="options-section full-width">
          <h4>Generation Options</h4>
          <mat-checkbox formControlName="avoidConsecutive">
            Avoid consecutive periods for same subject
          </mat-checkbox>
          <mat-checkbox formControlName="balanceWorkload">
            Balance teacher workload
          </mat-checkbox>
          <mat-checkbox formControlName="considerRoomCapacity">
            Consider room capacity
          </mat-checkbox>
          <mat-checkbox formControlName="preserveExisting">
            Preserve existing entries (where possible)
          </mat-checkbox>
        </div>

        <div class="generation-progress full-width" *ngIf="isGenerating">
          <h4>Generating Timetable...</h4>
          <mat-progress-bar mode="indeterminate"></mat-progress-bar>
          <p>{{ generationStatus() }}</p>
        </div>

        <div class="generation-result full-width" *ngIf="generationResult">
          <h4>Generation Summary</h4>
          <div class="result-stats">
            <div class="stat-item">
              <span class="label">Total Periods:</span>
              <span class="value">{{ generationResult.totalPeriods }}</span>
            </div>
            <div class="stat-item">
              <span class="label">Successfully Assigned:</span>
              <span class="value success">{{ generationResult.successfulAssignments }}</span>
            </div>
            <div class="stat-item">
              <span class="label">Conflicts:</span>
              <span class="value warning">{{ generationResult.conflicts }}</span>
            </div>
            <div class="stat-item">
              <span class="label">Unassigned:</span>
              <span class="value error">{{ generationResult.unassigned }}</span>
            </div>
          </div>
        </div>
      </form>
    </mat-dialog-content>
    <mat-dialog-actions align="end">
      <button mat-button (click)="onCancel()">Cancel</button>
      <button mat-raised-button color="primary" (click)="onGenerate()" 
              [disabled]="autoGenerateForm.invalid || isGenerating">
        {{ isGenerating ? 'Generating...' : 'Generate Timetable' }}
      </button>
      <button mat-raised-button color="accent" (click)="onApply()" 
              [disabled]="!generationResult || isGenerating"
              *ngIf="generationResult">
        Apply Changes
      </button>
    </mat-dialog-actions>
  `,
  styles: [`
    .dialog-form {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 10px 12px;
      max-width: 800px;
    }
    .dialog-form mat-form-field {
      width: 100%;
    }
    .dialog-form .full-width {
      grid-column: span 2;
    }
    .options-section {
      display: flex;
      flex-direction: column;
      gap: 12px;
      margin: 16px 0;
    }
    .options-section h4 {
      margin: 0 0 8px 0;
      color: var(--md-on-surface);
    }
    .generation-progress {
      text-align: center;
      padding: 16px;
      background: var(--md-surface-container-low);
      border-radius: 8px;
    }
    .generation-result {
      padding: 16px;
      background: #f0f8ff;
      border-radius: 8px;
    }
    .result-stats {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 8px;
    }
    .stat-item {
      display: flex;
      justify-content: space-between;
      padding: 4px 8px;
      background: white;
      border-radius: 4px;
    }
    .label {
      font-weight: 500;
    }
    .value.success {
      color: var(--md-success);
      font-weight: 600;
    }
    .value.warning {
      color: var(--md-warning);
      font-weight: 600;
    }
    .value.error {
      color: var(--md-error);
      font-weight: 600;
    }

    /* ── Mobile: single column, compact stats ── */
    @media (max-width: 599px) {
      .dialog-form {
        grid-template-columns: 1fr;
        gap: 2px;
      }

      .dialog-form .full-width { grid-column: 1 / -1; }

      h2[mat-dialog-title] {
        font-size: var(--font-size-base);
        font-weight: 700;
        padding: 12px 16px 8px;
        margin: 0;
        border-bottom: 1px solid var(--st-border-soft, var(--md-surface-container-low));
      }

      mat-dialog-content { padding: 8px 14px !important; }

      .options-section { gap: 8px; margin: 8px 0; }

      .generation-progress,
      .generation-result {
        padding: 10px;
        font-size: 12px;
      }
    }
  `]
})
export class AutoGenerateTimetableDialogComponent {
  autoGenerateForm: FormGroup;
  isGenerating = false;
  generationStatus = signal('');
  generationResult: any = null;

  constructor(
    private fb: FormBuilder,
    public dialogRef: MatDialogRef<AutoGenerateTimetableDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.autoGenerateForm = this.fb.group({
      academicYearId: [this.data.selectedAcademicYear || '', Validators.required],
      classId: [this.data.selectedClass || '', Validators.required],
      priorityStrategy: ['balanced', Validators.required],
      periodsPerDay: ['7', Validators.required],
      avoidConsecutive: [true],
      balanceWorkload: [true],
      considerRoomCapacity: [true],
      preserveExisting: [false]
    });
  }

  onCancel(): void {
    this.dialogRef.close();
  }

  onGenerate(): void {
    if (this.autoGenerateForm.valid) {
      this.isGenerating = true;
      this.generationResult = null;
      this.simulateGeneration();
    }
  }

  onApply(): void {
    this.dialogRef.close({
      action: 'apply',
      config: this.autoGenerateForm.value,
      result: this.generationResult
    });
  }

  private simulateGeneration(): void {
    const steps = [
      'Analyzing teacher availability...',
      'Checking room constraints...',
      'Distributing subjects...',
      'Resolving conflicts...',
      'Optimizing schedule...',
      'Finalizing timetable...'
    ];

    let stepIndex = 0;
    const interval = setInterval(() => {
      if (stepIndex < steps.length) {
        this.generationStatus.set(steps[stepIndex]);
        stepIndex++;
      } else {
        clearInterval(interval);
        this.completeGeneration();
      }
    }, 800);
  }

  private completeGeneration(): void {
    this.isGenerating = false;
    this.generationStatus.set('');
    
    // Simulate generation results
    const totalPeriods = parseInt(this.autoGenerateForm.get('periodsPerDay')?.value || '7') * 6;
    const conflicts = Math.floor(Math.random() * 5) + 1;
    const unassigned = Math.floor(Math.random() * 3);
    const successfulAssignments = totalPeriods - conflicts - unassigned;

    this.generationResult = {
      totalPeriods,
      successfulAssignments,
      conflicts,
      unassigned
    };
  }
}
