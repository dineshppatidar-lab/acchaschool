import { Component, Inject, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatDialogModule, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AdvancedAcademicService } from '../../services/advanced-academic.service';

@Component({
  selector: 'app-assignment-dialog',
  standalone: true,
  imports: [
    CommonModule,
    MatDialogModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatButtonModule,
    MatDatepickerModule,
    MatNativeDateModule,
    ReactiveFormsModule
  ],
  template: `
    <h2 mat-dialog-title>{{ data.mode === 'create' ? 'Create' : 'Edit' }} Assignment</h2>
    <mat-dialog-content>
      <form [formGroup]="assignmentForm" class="dialog-form">
        <mat-form-field>
          <mat-label>Title</mat-label>
          <input matInput formControlName="title" placeholder="Enter assignment title">
        </mat-form-field>

        <mat-form-field>
          <mat-label>Max Marks</mat-label>
          <input matInput type="number" formControlName="maxMarks" placeholder="Enter maximum marks">
        </mat-form-field>

        <mat-form-field>
          <mat-label>Class</mat-label>
          <mat-select formControlName="classId">
            <mat-option *ngFor="let class of data.classes" [value]="class.id">
              {{ class.name }}
            </mat-option>
          </mat-select>
        </mat-form-field>

        <mat-form-field>
          <mat-label>Section</mat-label>
          <mat-select formControlName="sectionId">
            <mat-option [value]="null">Default (first section)</mat-option>
            <mat-option *ngFor="let section of sectionsForClass" [value]="section.id">
              {{ section.name }}
            </mat-option>
          </mat-select>
          <mat-hint>Leave empty to use the class's first section</mat-hint>
        </mat-form-field>

        <mat-form-field>
          <mat-label>Subject</mat-label>
          <mat-select formControlName="subjectId">
            <mat-option *ngFor="let subject of subjectsForClass" [value]="subject.id">
              {{ subject.name }}
            </mat-option>
          </mat-select>
          <mat-hint>{{ subjectsForClass.length ? 'Subjects of the selected class' : 'Select a class to load its subjects' }}</mat-hint>
        </mat-form-field>

        <mat-form-field>
          <mat-label>Due Date</mat-label>
          <input matInput [matDatepicker]="duePicker" formControlName="dueDate">
          <mat-datepicker-toggle matSuffix [for]="duePicker"></mat-datepicker-toggle>
          <mat-datepicker #duePicker></mat-datepicker>
        </mat-form-field>

        <mat-form-field class="full-width">
          <mat-label>Description</mat-label>
          <textarea matInput formControlName="description" rows="4" placeholder="Enter assignment description"></textarea>
        </mat-form-field>
      </form>
    </mat-dialog-content>
    <mat-dialog-actions align="end">
      <button mat-button (click)="onCancel()">Cancel</button>
      <button mat-raised-button color="primary" (click)="onSave()" [disabled]="assignmentForm.invalid">
        {{ data.mode === 'create' ? 'Create' : 'Update' }}
      </button>
    </mat-dialog-actions>
  `,
  styles: [`
    .dialog-form {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 10px 12px;
    }
    .dialog-form mat-form-field {
      width: 100%;
    }
    .dialog-form .full-width {
      grid-column: span 2;
    }

    /* ── Mobile: single column, compact type ── */
    @media (max-width: 599px) {
      .dialog-form {
        grid-template-columns: 1fr;
        gap: 2px;
        padding: 10px 14px 14px;
      }

      .dialog-form .full-width { grid-column: 1 / -1; }

      h2[mat-dialog-title] {
        font-size: var(--font-size-base);
        font-weight: 700;
        padding: 12px 16px 8px;
        margin: 0;
        border-bottom: 1px solid var(--st-border-soft, var(--md-surface-container-low));
      }

      mat-dialog-content {
        padding: 0 !important;
      }

      textarea[matInput] { min-height: 56px; font-size: 14px; }
    }
  `]
})
export class AssignmentDialogComponent {
  assignmentForm: FormGroup;

  /** Sections of the currently selected class (loaded from the API). */
  sectionsForClass: any[] = [];
  /** Subjects of the currently selected class (subjects are class-scoped in the DB). */
  subjectsForClass: any[] = [];

  constructor(
    private fb: FormBuilder,
    private cdr: ChangeDetectorRef,
    public dialogRef: MatDialogRef<AssignmentDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.assignmentForm = this.fb.group({
      title: [this.data.assignment?.title || '', Validators.required],
      description: [this.data.assignment?.description || '', Validators.required],
      classId: [this.data.assignment?.classId || '', Validators.required],
      sectionId: [this.data.assignment?.sectionId || null],
      subjectId: [this.data.assignment?.subjectId || '', Validators.required],
      dueDate: [this.data.assignment?.dueDate || '', Validators.required],
      maxMarks: [this.data.assignment?.maxMarks || 100, [Validators.required, Validators.min(1)]]
    });

    // Load sections + subjects when the class changes
    this.assignmentForm.get('classId')!.valueChanges.subscribe((classId: number) => {
      this.loadSections(classId);
      this.loadSubjects(classId);
      this.assignmentForm.patchValue({ sectionId: null, subjectId: null });
    });

    // Edit mode: pre-load for the existing class. Deferred (microtask) so the HTTP
    // callbacks can never mutate state mid-change-detection (NG0100 in dialogs).
    const initialClassId = this.data.assignment?.classId;
    if (initialClassId) {
      queueMicrotask(() => {
        this.loadSections(initialClassId);
        this.loadSubjects(initialClassId);
      });
    }
  }

  private loadSections(classId: number): void {
    if (!classId) { this.setList('sectionsForClass', []); return; }
    const svc: AdvancedAcademicService | undefined = (this.data as any)?.academicService;
    if (!svc) { this.setList('sectionsForClass', []); return; }
    svc.getSectionsByClass(classId).subscribe({
      next: (sections) => this.setList('sectionsForClass', sections || []),
      error: () => this.setList('sectionsForClass', [])
    });
  }

  private loadSubjects(classId: number): void {
    if (!classId) { this.setList('subjectsForClass', []); return; }
    const svc: AdvancedAcademicService | undefined = (this.data as any)?.academicService;
    if (!svc) { this.setList('subjectsForClass', []); return; }
    svc.getSubjects(classId).subscribe({
      next: (subjects) => this.setList('subjectsForClass', subjects || []),
      error: () => this.setList('subjectsForClass', [])
    });
  }

  /** Mutate list state outside any in-flight CD pass, then schedule a re-render. */
  private setList(property: 'sectionsForClass' | 'subjectsForClass', value: any[]): void {
    queueMicrotask(() => {
      this[property] = value;
      this.cdr.markForCheck();
    });
  }

  onCancel(): void {
    this.dialogRef.close();
  }

  onSave(): void {
    if (this.assignmentForm.valid) {
      this.dialogRef.close(this.assignmentForm.value);
    }
  }
}
