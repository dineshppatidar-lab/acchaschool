import { AfterViewInit, ChangeDetectorRef, Component, DestroyRef, Inject, OnInit, ViewChild, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { MatTabsModule } from '@angular/material/tabs';
import { MatCardModule } from '@angular/material/card';
import { MatTableModule, MatTableDataSource } from '@angular/material/table';
import { MatPaginatorModule, MatPaginator } from '@angular/material/paginator';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatChipsModule } from '@angular/material/chips';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { MatInputModule } from '@angular/material/input';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatMenuModule } from '@angular/material/menu';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatDialog, MatDialogModule, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { DialogUtils } from '../../shared/dialog-utils';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatNativeDateModule } from '@angular/material/core';
import { FormsModule } from '@angular/forms';
import { BackButtonComponent } from '../../shared/components/back-button.component';
import { ResultsViewComponent } from '../examinations/results-view.component';
import { AdvancedAcademicService } from '../../services/advanced-academic.service';
import { TimeTableEntry, Examination, ExaminationType, Assignment, Class, AcademicYear, Subject, Teacher } from '../../shared/models/academic.models';
import { AcademicYearContextService } from '../../shared/services/academic-year-context.service';
import { CanWriteDirective, CanDeleteDirective } from '../../core/directives/permission.directive';
import { Permission } from '../../core/models/permission.model';

interface TimetableCell {
  id: number;
  subject: string;
  teacher: string;
  room: string;
  subjectId?: number;
  teacherId?: number;
  sectionId?: number;
  section?: string;
  dayKey?: string;
  startTime?: string;
}

interface TimetableRow {
  time: string;
  [day: string]: any;
}

@Component({
  selector: 'app-advanced-academic',
  standalone: true,
  imports: [
    CommonModule,
    MatTabsModule,
    MatCardModule,
    MatTableModule,
    MatPaginatorModule,
    MatButtonModule,
    MatIconModule,
    MatChipsModule,
    MatProgressSpinnerModule,
    MatFormFieldModule,
    MatSelectModule,
    MatInputModule,
    MatSnackBarModule,
    MatMenuModule,
    MatTooltipModule,
    MatDialogModule,
    MatDatepickerModule,
    MatProgressBarModule,
    MatNativeDateModule,
    CanWriteDirective,
    CanDeleteDirective,
    BackButtonComponent,
    ResultsViewComponent
  ],
  templateUrl: './advanced-academic.component.html',
  styleUrls: ['./advanced-academic.component.scss']
})
export class AdvancedAcademicComponent implements OnInit, AfterViewInit {
  Permission = Permission;
  @ViewChild('paginator', { static: false }) paginator!: MatPaginator;
  @ViewChild('examPaginator', { static: false }) examPaginator!: MatPaginator;
  @ViewChild('assignmentPaginator', { static: false }) assignmentPaginator!: MatPaginator;

  timetableDisplayedColumns = ['time', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
  examinationDisplayedColumns = ['examName', 'examType', 'startDate', 'endDate', 'status', 'actions'];
  assignmentDisplayedColumns = ['title', 'className', 'subjectName', 'assignedDate', 'dueDate', 'status', 'actions'];

  timetableDataSource = new MatTableDataSource<TimetableRow>([]);
  examinationDataSource = new MatTableDataSource<Examination>([]);
  assignmentDataSource = new MatTableDataSource<Assignment>([]);

  // Filters
  selectedClass: number | null = null;
  selectedAcademicYear = signal<any>(null);
  assignmentClassFilter: number | null = null;
  assignmentStatusFilter: string | null = null;
  examTypeFilter: number | null = null;
  examStatusFilter: string | null = null;

  // Reference data (loaded from API — no sample fallbacks)
  classes = signal<any[]>([]);
  academicYears = signal<any[]>([]);
  subjects = signal<any[]>([]);
  teachers = signal<any[]>([]);
  examTypes = signal<any[]>([]);

  // Raw API entries for the timetable grid
  timetableEntries = signal<any[]>([]);
  sectionsForClass = signal<any[]>([]);

  // All examinations from the API; filtered copies go into examinationDataSource
  private allExaminations = signal<any[]>([]);

  loadingTimetable = signal(false);
  loadingExaminations = signal(false);
  /** Exam Results tab is loaded lazily, on first activation (signals for zoneless CD). */
  resultsTabLoaded = signal(false);

  /** Drives the page-level progress bar (any tab loading). */
  get loading(): boolean {
    return this.loadingTimetable() || this.loadingExaminations();
  }

  // Time slots derived from loaded timetable data; sensible defaults otherwise
  timeSlots: string[] = [
    '08:00:00', '09:00:00', '10:00:00', '11:00:00', '12:00:00',
    '13:00:00', '14:00:00', '15:00:00', '16:00:00'
  ];

  // Days of the week for the grid columns
  weekDays = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  private readonly enumToDayKey: Record<number, string> = {
    0: 'sunday', 1: 'monday', 2: 'tuesday', 3: 'wednesday', 4: 'thursday', 5: 'friday', 6: 'saturday'
  };

  // Index of the tab selected via deep-link (/app/advanced-academic/timetable or #timetable)
  selectedTab = signal(0);
  private readonly tabFragments: Record<string, number> = {
    timetable: 0,
    results: 1,
    examinations: 2,
    assignments: 3
  };

  constructor(
    private academicService: AdvancedAcademicService,
    private snackBar: MatSnackBar,
    private dialog: MatDialog,
    private dialogUtils: DialogUtils,
    private route: ActivatedRoute,
    private yearContext: AcademicYearContextService
  ) {}

  private readonly destroyRef = inject(DestroyRef);
  private readonly cdr = inject(ChangeDetectorRef);

  /**
   * Zoneless CD: mutate state from HTTP callbacks inside a microtask (outside any
   * in-flight change-detection pass — prevents NG0100 ExpressionChangedAfterIt-
   * HasBeenCheckedError) and then explicitly request a re-render via markForCheck.
   */
  private deferStateWrite(write: () => void): void {
    queueMicrotask(() => {
      write();
      this.cdr.markForCheck();
    });
  }

  ngOnInit(): void {
    // Subscribe (not snapshot): navigating between /timetable and /assignments reuses
    // this component instance, so ngOnInit alone would never update the tab.
    this.route.paramMap
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(pm => {
        const tab = pm.get('tab') ?? this.route.snapshot.fragment;
        if (tab && tab in this.tabFragments) {
          this.selectedTab.set(this.tabFragments[tab]);
        }
      });

    // Defer the first data loads until after the initial change-detection pass.
    // Cached BehaviorSubjects (e.g. AcademicYearContextService) emit synchronously on
    // subscribe; mutating component state mid-CD throws NG0100
    // ExpressionChangedAfterItHasBeenCheckedError.
    Promise.resolve().then(() => {
      this.loadReferenceData();
      this.refreshAssignmentsFromApi();
      this.loadExaminations();
    });
  }

  ngAfterViewInit(): void {
    this.timetableDataSource.paginator = this.paginator;
    this.examinationDataSource.paginator = this.examPaginator;
    this.assignmentDataSource.paginator = this.assignmentPaginator;
  }

  // ------------------------------------------------------------------
  // Reference data — all from API
  // ------------------------------------------------------------------
  private loadReferenceData(): void {
    // Academic year drives the class list — load years first, then classes
    // scoped to the selected year (cascading dropdowns).
    this.academicService.getAcademicYears().subscribe({
      next: (years) => this.deferStateWrite(() => {
        this.academicYears.set(years || []);
        // Prefer the year already selected app-wide (localStorage via the shared
        // context service) so this screen stays consistent with the rest of the app.
        const shared = this.yearContext.selectedYearId;
        const preferred =
          (shared && this.academicYears().some(y => y.id === shared) ? shared : null) ??
          this.academicYears().find(y => (y as any).isCurrent)?.id ??
          this.academicYears().find(y => (y as any).isActive !== false)?.id ??
          this.academicYears()[0]?.id ??
          null;
        if (preferred) {
          this.selectedAcademicYear.set(preferred);
          this.loadClassesForYear(preferred);
        }
      }),
      error: () => {}
    });

    this.academicService.getSubjects().subscribe({
      next: (subjects) => this.deferStateWrite(() => { this.subjects.set(subjects || []); }),
      error: () => {}
    });

    this.academicService.getTeachers().subscribe({
      next: (teachers) => this.deferStateWrite(() => { this.teachers.set(teachers || []); }),
      error: () => {}
    });

    this.academicService.getExaminationTypes().subscribe({
      next: (types) => this.deferStateWrite(() => { this.examTypes.set(types || []); }),
      error: () => {}
    });
  }

  /** Classes offered in the selected academic year — cascades every class dropdown. */
  private loadClassesForYear(academicYearId: number): void {
    if (!academicYearId) { this.classes.set([]); return; }
    this.academicService.getClassesByAcademicYear(academicYearId).subscribe({
      next: (classes) => this.deferStateWrite(() => { this.classes.set(classes || []); }),
      error: () => this.deferStateWrite(() => { this.classes.set([]); })
    });
  }

  /** Academic year changed → reload classes; class-scoped selections are no longer valid. */
  onAcademicYearChange(): void {
    if (this.selectedAcademicYear()) {
      this.yearContext.setYear(this.selectedAcademicYear());
    }
    this.selectedClass = null;
    this.assignmentClassFilter = null;
    this.sectionsForClass.set([]);
    this.timetableEntries.set([]);
    this.timetableDataSource.data = [];
    if (this.selectedAcademicYear()) {
      this.loadClassesForYear(this.selectedAcademicYear());
    }
  }

  // ------------------------------------------------------------------
  // Timetable — real API grid
  // ------------------------------------------------------------------
  onClassChange(): void {
    this.loadSectionsForClass();
    this.loadTimetables();
  }

  /** Sections of the selected class — offered in the timetable dialog. */
  private loadSectionsForClass(): void {
    if (!this.selectedClass) { this.sectionsForClass.set([]); return; }
    this.academicService.getSectionsByClass(this.selectedClass).subscribe({
      next: (sections) => this.deferStateWrite(() => { this.sectionsForClass.set(sections || []); }),
      error: () => this.deferStateWrite(() => { this.sectionsForClass.set([]); })
    });
  }

  loadTimetables(): void {
    if (!this.selectedClass) {
      this.timetableEntries.set([]);
      this.timetableDataSource.data = [];
      return;
    }
    this.loadingTimetable.set(true);
    this.academicService.getTimetableByClass(this.selectedClass).subscribe({
      next: (entries) => this.deferStateWrite(() => {
        this.timetableEntries.set(entries || []);
        this.buildTimetableGrid();
        this.loadingTimetable.set(false);
      }),
      error: () => {
        this.deferStateWrite(() => { this.loadingTimetable.set(false); });
        this.snackBar.open('Failed to load timetable', 'Close', { duration: 3000 });
      }
    });
  }

  /** Group API entries into a day-of-week × time-slot grid for display. */
  private buildTimetableGrid(): void {
    // Derive the time slots actually in use
    const times = [...new Set(this.timetableEntries().map(e => this.normalizeTime(e.startTime)))]
      .sort((a, b) => a.localeCompare(b));
    if (times.length > 0) this.timeSlots = times;

    const rows: TimetableRow[] = this.timeSlots.map(time => {
      const row: TimetableRow = { time: this.formatSlotTime(time) };
      for (const day of this.weekDays) row[day.toLowerCase()] = null;
      return row;
    });

    for (const entry of this.timetableEntries()) {
      const dayKey = this.enumToDayKey[Number(entry.dayOfWeek)];
      if (!dayKey) continue;
      const startTime = this.normalizeTime(entry.startTime);
      const rowIndex = this.timeSlots.indexOf(startTime);
      if (rowIndex === -1) continue;
      rows[rowIndex][dayKey] = {
        id: (entry as any).id ?? (entry as any).timeTableId,
        subject: (entry as any).subjectName || this.subjects().find(s => s.id === entry.subjectId)?.name || `Subject #${entry.subjectId}`,
        teacher: (entry as any).teacherName || this.teachers().find(t => t.id === entry.staffId)?.name || `Staff #${entry.staffId}`,
        room: (entry as any).roomNumber || (entry as any).room || '',
        subjectId: entry.subjectId,
        teacherId: entry.staffId,
        sectionId: (entry as any).sectionId,
        section: (entry as any).sectionName || '',
        dayKey,
        startTime
      } as TimetableCell;
    }

    this.timetableDataSource.data = rows;
  }

  private normalizeTime(t: string | undefined): string {
    if (!t) return '';
    // Accept "8:00 AM", "08:00", "08:00:00"
    const m = String(t).trim().match(/^(\d{1,2}):(\d{2})/);
    if (!m) return String(t);
    const h = m[1].padStart(2, '0');
    return `${h}:${m[2]}:00`;
  }

  private formatSlotTime(t: string): string {
    const m = t.match(/^(\d{1,2}):(\d{2})/);
    if (!m) return t;
    let h = parseInt(m[1], 10);
    const suffix = h >= 12 ? 'PM' : 'AM';
    h = h % 12 === 0 ? 12 : h % 12;
    return `${h}:${m[2]} ${suffix}`;
  }

  addTimetableEntry(): void {
    if (!this.selectedClass) {
      this.snackBar.open('Select a class first', 'Close', { duration: 2500 });
      return;
    }
    (async () => {
      const { TimetableEntryDialogComponent } = await import('./timetable-entry-dialog.component');
      const dialogRef = this.dialog.open(TimetableEntryDialogComponent, {
        ...this.dialogUtils.getMobileConfig({ width: '500px' }),
        data: {
          mode: 'create',
          timetableEntry: { classId: this.selectedClass },
          classes: this.classes(),
          sections: this.sectionsForClass(),
          subjects: this.subjects(),
          teachers: this.teachers(),
          timeSlots: this.timeSlots,
          weekDays: this.weekDays,
          academicService: this.academicService
        }
      });

      dialogRef.afterClosed().subscribe(result => {
        if (!result) return;
        // sectionId null → 0 so the backend defaults to the class's first section
        this.academicService.createTimetableEntry({ ...result, sectionId: result.sectionId ?? 0 }).subscribe({
          next: () => {
            this.snackBar.open('Timetable entry added', 'Close', { duration: 2500 });
            this.loadTimetables();
          },
          error: (err) => this.snackBar.open(this.getApiError(err) || 'Failed to add timetable entry', 'Close', { duration: 3500 })
        });
      });
    })();
  }

  editTimetableSlot(slot: TimetableCell, time: string, day: string): void {
    const entry = {
      id: slot.id,
      classId: this.selectedClass,
      // Use IDs stored on the cell — name-based lookup breaks with duplicates.
      subjectId: slot.subjectId ?? this.subjects().find(s => s.name === slot.subject)?.id,
      teacherId: slot.teacherId ?? this.teachers().find(t => t.name === slot.teacher)?.id,
      // API expects the day enum name (e.g. "Monday"), not the lowercase column key.
      dayOfWeek: this.toDayName(day),
      // Use the normalized time stored on the cell — row.time is display-formatted
      // ("8:00 AM") and would be mangled by the payload serializer.
      startTime: slot.startTime ?? this.normalizeTime(time),
      endTime: this.calculateEndTime(time),
      room: slot.room,
      sectionId: slot.sectionId
    };

    (async () => {
      const { TimetableEntryDialogComponent } = await import('./timetable-entry-dialog.component');
      const dialogRef = this.dialog.open(TimetableEntryDialogComponent, {
        ...this.dialogUtils.getMobileConfig({ width: '500px' }),
        data: {
          mode: 'edit',
          timetableEntry: entry,
          classes: this.classes(),
          sections: this.sectionsForClass(),
          subjects: this.subjects(),
          teachers: this.teachers(),
          timeSlots: this.timeSlots,
          weekDays: this.weekDays,
          academicService: this.academicService
        }
      });

      dialogRef.afterClosed().subscribe(result => {
        if (!result || !slot.id) return;
        this.academicService.updateTimetableEntry(slot.id, { ...result, id: slot.id, sectionId: result.sectionId ?? slot.sectionId ?? 0 }).subscribe({
          next: () => {
            this.snackBar.open('Timetable entry updated', 'Close', { duration: 2500 });
            this.loadTimetables();
          },
          error: (err) => this.snackBar.open(this.getApiError(err) || 'Failed to update timetable entry', 'Close', { duration: 3500 })
        });
      });
    })();
  }

  /** "monday" -> "Monday" for the API's day enum. */
  private toDayName(dayKey: string): string {
    return dayKey ? dayKey.charAt(0).toUpperCase() + dayKey.slice(1) : dayKey;
  }

  deleteTimetableEntry(id: number): void {
    if (!id) return;
    if (!confirm('Delete this timetable entry?')) return;
    this.academicService.deleteTimetableEntry(id).subscribe({
      next: () => {
        this.snackBar.open('Timetable entry deleted', 'Close', { duration: 2500 });
        this.loadTimetables();
      },
      error: () => this.snackBar.open('Failed to delete timetable entry', 'Close', { duration: 3000 })
    });
  }

  autoGenerateTimetable(): void {
    (async () => {
      const { AutoGenerateTimetableDialogComponent } = await import('./auto-generate-timetable-dialog.component');
      const dialogRef = this.dialog.open(AutoGenerateTimetableDialogComponent, {
        ...this.dialogUtils.getMobileConfig({ width: '800px', maxWidth: '90vw' }),
        data: {
          selectedAcademicYear: this.selectedAcademicYear(),
          selectedClass: this.selectedClass,
          academicYears: this.academicYears(),
          classes: this.classes(),
          subjects: this.subjects(),
          teachers: this.teachers()
        }
      });

      dialogRef.afterClosed().subscribe(result => {
        if (result && result.action === 'apply' && this.selectedClass) {
          this.loadTimetables();
        }
      });
    })();
  }

  generateTimetable(): void {
    if (!this.selectedClass) {
      this.snackBar.open('Select a class first', 'Close', { duration: 2500 });
      return;
    }
    (async () => {
      const { GenerateTimetableDialogComponent } = await import('./generate-timetable-dialog.component');
      const dialogRef = this.dialog.open(GenerateTimetableDialogComponent, {
        ...this.dialogUtils.getMobileConfig({ width: '900px', maxWidth: '95vw', maxHeight: '90vh' }),
        data: {
          selectedAcademicYear: this.selectedAcademicYear(),
          selectedClass: this.selectedClass,
          academicYears: this.academicYears(),
          classes: this.classes(),
          subjects: this.subjects(),
          teachers: this.teachers()
        }
      });

      dialogRef.afterClosed().subscribe(result => {
        if (result && result.action === 'generate') {
          this.academicService.generateTimetable(this.selectedClass!, result.preferences ?? {}).subscribe({
            next: () => {
              this.snackBar.open('Timetable generated', 'Close', { duration: 2500 });
              this.loadTimetables();
            },
            error: (err) => this.snackBar.open(this.getApiError(err) || 'Failed to generate timetable', 'Close', { duration: 3500 })
          });
        }
      });
    })();
  }

  exportTimetable(): void {
    if (!this.selectedClass) {
      this.snackBar.open('Select a class first', 'Close', { duration: 2500 });
      return;
    }
    this.academicService.exportTimetable(this.selectedClass, 'excel').subscribe({
      next: (blob) => this.downloadBlob(blob, `timetable_class_${this.selectedClass}.xlsx`),
      error: () => this.snackBar.open('Export failed', 'Close', { duration: 3000 })
    });
  }

  // ------------------------------------------------------------------
  // Examinations — real API
  // ------------------------------------------------------------------
  loadExaminations(): void {
    this.loadingExaminations.set(true);
    this.academicService.getExaminations().subscribe({
      next: (items) => this.deferStateWrite(() => {
        this.allExaminations.set((items || []).map((e: any) => this.mapExamination(e)));
        this.applyExamFilters();
        this.loadingExaminations.set(false);
      }),
      error: () => {
        this.deferStateWrite(() => { this.loadingExaminations.set(false); });
        this.snackBar.open('Failed to load examinations', 'Close', { duration: 3000 });
      }
    });
  }

  /** Apply client-side filters into examinationDataSource (the paginated table source). */
  applyExamFilters(): void {
    this.examinationDataSource.data = this.allExaminations().filter(e => {
      if (this.examTypeFilter != null && e.examinationTypeId !== this.examTypeFilter) return false;
      if (this.examStatusFilter && e.status !== this.examStatusFilter) return false;
      return true;
    });
    if (this.examPaginator) {
      this.examinationDataSource.paginator = this.examPaginator;
      this.examPaginator.firstPage();
    }
  }

  private mapExamination(e: any): Examination {
    const type = this.examTypes().find(t => t.id === (e.examinationTypeId ?? e.ExaminationTypeId));
    return {
      id: e.id ?? e.examId,
      examId: e.id,
      academicYearId: e.academicYearId,
      title: e.title ?? e.examName ?? '',
      examName: e.title ?? e.examName,
      examinationTypeId: e.examinationTypeId,
      examType: type?.name ?? e.examType,
      startDate: e.startDate ? new Date(e.startDate) : new Date(),
      endDate: e.endDate ? new Date(e.endDate) : new Date(),
      instructions: e.instructions ?? e.description ?? '',
      description: e.instructions ?? e.description,
      isPublished: !!e.isPublished,
      status: e.isPublished ? 'Published' : 'Draft'
    };
  }

  createExamination(): void {
    (async () => {
      const { ExaminationDialogComponent } = await import('./examination-dialog.component');
      const dialogRef = this.dialog.open(ExaminationDialogComponent, {
        ...this.dialogUtils.getMobileConfig({ width: '600px' }),
        data: {
          mode: 'create',
          academicYears: this.academicYears(),
          examTypes: this.examTypes()
        }
      });

      dialogRef.afterClosed().subscribe(result => {
        if (!result) return;
        const typeId = this.examTypes().find(t => t.name === result.examType)?.id;
        this.academicService.createExamination({
          title: result.examName,
          academicYearId: result.academicYearId,
          // 0 lets the backend pick/create a type when the table is empty —
          // hardcoding 1 caused FK failures on fresh tenants.
          examinationTypeId: typeId ?? 0,
          startDate: result.startDate,
          endDate: result.endDate,
          instructions: result.description
        }).subscribe({
          next: () => {
            this.snackBar.open('Examination created', 'Close', { duration: 2500 });
            this.loadExaminations();
          },
          error: (err) => this.snackBar.open(this.getApiError(err) || 'Failed to create examination', 'Close', { duration: 5000 })
        });
      });
    })();
  }

  editExamination(exam: Examination): void {
    (async () => {
      const { ExaminationDialogComponent } = await import('./examination-dialog.component');
      const dialogRef = this.dialog.open(ExaminationDialogComponent, {
        ...this.dialogUtils.getMobileConfig({ width: '600px' }),
        data: {
          mode: 'edit',
          examination: exam,
          academicYears: this.academicYears(),
          examTypes: this.examTypes()
        }
      });

      dialogRef.afterClosed().subscribe(result => {
        if (!result || !exam.id) return;
        const typeId = this.examTypes().find(t => t.name === result.examType)?.id ?? exam.examinationTypeId;
        this.academicService.updateExamination(exam.id, {
          title: result.examName,
          academicYearId: result.academicYearId,
          examinationTypeId: typeId,
          startDate: result.startDate,
          endDate: result.endDate,
          instructions: result.description
        }).subscribe({
          next: () => {
            this.snackBar.open('Examination updated', 'Close', { duration: 2500 });
            this.loadExaminations();
          },
          error: (err) => this.snackBar.open(this.getApiError(err) || 'Failed to update examination', 'Close', { duration: 3500 })
        });
      });
    })();
  }

  deleteExamination(exam: Examination): void {
    if (!exam.id) return;
    if (!confirm(`Delete examination "${exam.examName ?? exam.title}"?`)) return;
    this.academicService.deleteExamination(exam.id).subscribe({
      next: () => {
        this.snackBar.open('Examination deleted', 'Close', { duration: 2500 });
        this.loadExaminations();
      },
      error: () => this.snackBar.open('Failed to delete examination', 'Close', { duration: 3000 })
    });
  }

  viewExamDetails(exam: Examination): void {
    this.dialog.open(ExamDetailsDialog, {
      ...this.dialogUtils.getMobileConfig({ width: '480px' }),
      data: { exam, yearName: this.academicYears().find(y => y.id === exam.academicYearId)?.name }
    });
  }

  generateExamTimetable(): void {
    this.snackBar.open('Use the Schedules action on an examination to build its timetable', 'Close', { duration: 4000 });
  }

  scheduleExamination(exam: Examination): void {
    if (!exam.id) return;
    this.academicService.generateExamTimetable(exam.id).subscribe({
      next: () => this.snackBar.open(`Exam timetable generated for ${exam.examName ?? exam.title}`, 'Close', { duration: 3000 }),
      error: () => this.snackBar.open('Failed to generate exam timetable', 'Close', { duration: 3000 })
    });
  }

  /**
   * Type label resolved at RENDER time instead of at map time:
   * mapExamination runs as soon as exams arrive, but examTypes() may still
   * be empty (parallel request) — rows mapped in that window got
   * examType = undefined and rendered empty chips in the list. Looking the
   * name up from the examTypes signal here re-renders correctly once the
   * types land, whatever the race outcome.
   */
  getExamTypeLabel(exam: any): string {
    const id = exam.examinationTypeId ?? exam.ExaminationTypeId;
    const byId = this.examTypes().find(t => t.id === id);
    if (byId?.name) return byId.name;
    return exam.examType || '';
  }

  getExamTypeColor(type?: string): string {
    const colors: {[key: string]: string} = {
      'Unit Test': 'primary',
      'Mid Term': 'accent',
      'Final': 'warn',
      'Practical': 'basic'
    };
    return colors[type ?? ''] || 'basic';
  }

  getExamStatusColor(status?: string): string {
    const colors: {[key: string]: string} = {
      'Published': 'primary',
      'Draft': 'accent',
      'Scheduled': 'accent',
      'In Progress': 'primary',
      'Completed': 'warn',
      'Cancelled': 'basic'
    };
    return colors[status ?? ''] || 'basic';
  }

  // ------------------------------------------------------------------
  // Assignments — real API
  // ------------------------------------------------------------------
  refreshAssignmentsFromApi(): void {
    // Status maps to the backend's active/inactive flag filter
    const status = this.assignmentStatusFilter === 'Active' ? 'active'
      : this.assignmentStatusFilter === 'Inactive' ? 'inactive' : undefined;
    this.academicService.getAssignments(this.assignmentClassFilter ?? undefined, undefined, status as any)
      .subscribe({
        next: (items) => this.deferStateWrite(() => {
          const mapped: Assignment[] = (items || []).map((a: any) => ({
            assignmentId: a.assignmentId ?? a.id ?? 0,
            classId: a.classId,
            subjectId: a.subjectId,
            title: a.title,
            description: a.description,
            assignedDate: a.assignedDate ? new Date(a.assignedDate) : new Date(),
            dueDate: a.dueDate ? new Date(a.dueDate) : new Date(),
            maxMarks: a.maxMarks ?? 100,
            status: a.status ?? (a.isActive === false ? 'Inactive' : 'Active'),
            className: a.className,
            subjectName: a.subjectName
          }));
          this.assignmentDataSource.data = mapped;
          if (this.assignmentPaginator) this.assignmentDataSource.paginator = this.assignmentPaginator;
        }),
        error: () => this.snackBar.open('Failed to load assignments', 'Close', { duration: 3000 })
      });
  }

  createAssignment(): void {
    (async () => {
      const { AssignmentDialogComponent } = await import('./assignment-dialog.component');
      const dialogRef = this.dialog.open(AssignmentDialogComponent, {
        ...this.dialogUtils.getMobileConfig({ width: '600px' }),
        data: {
          mode: 'create',
          classes: this.classes(),
          subjects: this.subjects(),
          academicService: this.academicService
        }
      });

      dialogRef.afterClosed().subscribe(result => {
        if (!result) return;
        this.academicService.createAssignment({
          classId: result.classId,
          sectionId: result.sectionId ?? 0,
          subjectId: result.subjectId,
          title: result.title,
          description: result.description,
          assignedDate: new Date(),
          dueDate: new Date(result.dueDate),
          maxMarks: result.maxMarks,
          isActive: true
        } as any).subscribe({
          next: () => {
            this.snackBar.open('Assignment created', 'Close', { duration: 2500 });
            this.refreshAssignmentsFromApi();
          },
          error: (err) => this.snackBar.open(this.getApiError(err) || 'Failed to create assignment', 'Close', { duration: 3500 })
        });
      });
    })();
  }

  editAssignment(assignment: Assignment): void {
    (async () => {
      const { AssignmentDialogComponent } = await import('./assignment-dialog.component');
      const dialogRef = this.dialog.open(AssignmentDialogComponent, {
        ...this.dialogUtils.getMobileConfig({ width: '600px' }),
        data: {
          mode: 'edit',
          assignment: assignment,
          classes: this.classes(),
          subjects: this.subjects(),
          academicService: this.academicService
        }
      });

      dialogRef.afterClosed().subscribe(result => {
        if (!result || !assignment.assignmentId) return;
        this.academicService.updateAssignment(assignment.assignmentId, {
          assignmentId: assignment.assignmentId,
          classId: result.classId,
          sectionId: result.sectionId ?? (assignment as any).sectionId ?? 0,
          subjectId: result.subjectId,
          title: result.title,
          description: result.description,
          dueDate: new Date(result.dueDate),
          maxMarks: result.maxMarks,
          isActive: assignment.status !== 'Inactive'
        } as any).subscribe({
          next: () => {
            this.snackBar.open('Assignment updated', 'Close', { duration: 2500 });
            this.refreshAssignmentsFromApi();
          },
          error: (err) => this.snackBar.open(this.getApiError(err) || 'Failed to update assignment', 'Close', { duration: 3500 })
        });
      });
    })();
  }

  deleteAssignment(assignment: Assignment): void {
    if (!assignment?.assignmentId) {
      this.snackBar.open('Invalid assignment selected', 'Close', { duration: 2500 });
      return;
    }
    if (!confirm(`Delete assignment "${assignment.title}"? This cannot be undone.`)) return;
    this.academicService.deleteAssignment(assignment.assignmentId).subscribe({
      next: () => {
        this.assignmentDataSource.data = this.assignmentDataSource.data.filter(a => a.assignmentId !== assignment.assignmentId);
        this.snackBar.open('Assignment deleted', 'Close', { duration: 2500 });
      },
      error: () => this.snackBar.open('Failed to delete assignment', 'Close', { duration: 3000 })
    });
  }

  viewSubmissions(assignment: Assignment): void {
    this.academicService.getAssignmentSubmissions(assignment.assignmentId)
      .subscribe({
        next: (subs: any[]) => {
          const submitted = subs.length;
          const graded = subs.filter(s => s.status === 'Graded').length;
          const avg = subs.length ? Math.round((subs.reduce((sum, s) => sum + (s.marksObtained ?? 0), 0)) / subs.length) : 0;
          const info = `Assignment: ${assignment.title}
Class: ${assignment.className}
Subject: ${assignment.subjectName}
Due Date: ${assignment.dueDate.toDateString()}
Max Marks: ${assignment.maxMarks}

Submissions:
- ${submitted} students submitted
- ${graded} graded
- Average Score: ${avg}/${assignment.maxMarks}`;
          alert(info);
        },
        error: () => this.snackBar.open('Failed to load submissions', 'Close', { duration: 3000 })
      });
  }

  exportAssignment(assignment: Assignment): void {
    this.academicService.exportAssignmentReport(assignment.assignmentId, 'excel')
      .subscribe({
        next: (blob) => this.downloadBlob(blob, `assignment_${assignment.assignmentId}_grades.xlsx`),
        error: () => this.snackBar.open('Export failed', 'Close', { duration: 3000 })
      });
  }

  getAssignmentStatusColor(status: string): string {
    const colors: {[key: string]: string} = {
      'Active': 'primary',
      'Submitted': 'accent',
      'Completed': 'warn',
      'Overdue': 'basic',
      'Inactive': 'basic'
    };
    return colors[status] || 'basic';
  }

  // ------------------------------------------------------------------
  // Helpers
  // ------------------------------------------------------------------
  private getApiError(err: any): string {
    return err?.error?.message || err?.error?.title || (typeof err?.error === 'string' ? err.error : '');
  }

  private downloadBlob(blob: Blob, filename: string): void {
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    window.URL.revokeObjectURL(url);
  }

  calculateEndTime(startTime: string): string {
    const normalized = this.normalizeTime(startTime);
    const idx = this.timeSlots.indexOf(normalized);
    if (idx !== -1 && idx + 1 < this.timeSlots.length) {
      return this.timeSlots[idx + 1];
    }
    const m = normalized.match(/^(\d{1,2}):(\d{2})/);
    if (m) {
      const h = Math.min(23, parseInt(m[1], 10) + 1);
      return `${String(h).padStart(2, '0')}:${m[2]}:00`;
    }
    return '09:00:00';
  }

  formatDate(date: Date | string): string {
    const d = date instanceof Date ? date : new Date(date);
    return new Intl.DateTimeFormat('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    }).format(d);
  }
}

/** Read-only examination details dialog (replaces raw alert). */
@Component({
  selector: 'app-exam-details-dialog',
  standalone: true,
  imports: [CommonModule, MatDialogModule, MatButtonModule, MatIconModule, FormsModule],
  template: `
    <h2 mat-dialog-title>
      <mat-icon class="title-icon">event_note</mat-icon>
      {{ data.exam.title || data.exam.examName }}
    </h2>
    <mat-dialog-content>
      <div class="detail-grid">
        <div class="detail-item"><span class="label">Type</span><span>{{ data.exam.examType || '—' }}</span></div>
        <div class="detail-item"><span class="label">Academic Year</span><span>{{ data.yearName || data.exam.academicYearId }}</span></div>
        <div class="detail-item"><span class="label">Start Date</span><span>{{ data.exam.startDate | date:'mediumDate' }}</span></div>
        <div class="detail-item"><span class="label">End Date</span><span>{{ data.exam.endDate | date:'mediumDate' }}</span></div>
        <div class="detail-item full"><span class="label">Status</span><span>{{ data.exam.status || (data.exam.isPublished ? 'Published' : 'Draft') }}</span></div>
        <div class="detail-item full"><span class="label">Instructions</span><span>{{ data.exam.instructions || data.exam.description || '—' }}</span></div>
      </div>
    </mat-dialog-content>
    <mat-dialog-actions align="end">
      <button mat-button (click)="close()">Close</button>
    </mat-dialog-actions>
  `,
  styles: [`
    .title-icon { vertical-align: middle; margin-right: 8px; }
    .detail-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
    .detail-item { display: flex; flex-direction: column; gap: 2px; }
    .detail-item.full { grid-column: span 2; }
    .label { font-size: 12px; color: var(--color-text-secondary); text-transform: uppercase; letter-spacing: 0.04em; }

    /* Mobile: single column, compact title row */
    @media (max-width: 599px) {
      .detail-grid { grid-template-columns: 1fr; gap: 8px; }
      .detail-item.full { grid-column: 1 / -1; }
      h2[mat-dialog-title] { font-size: var(--font-size-base); padding: 12px 16px 8px; }
      mat-dialog-content { padding: 0 16px 8px !important; }
    }
  `]
})
export class ExamDetailsDialog {
  constructor(
    @Inject(MAT_DIALOG_DATA) public data: { exam: Examination; yearName?: string },
    public dialogRef: MatDialogRef<ExamDetailsDialog>
  ) {}

  close(): void {
    this.dialogRef.close();
  }
}
