import { Component, Inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatDialogModule, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-examination-dialog',
  standalone: true,
  imports: [
    CommonModule,
    MatDialogModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatButtonModule,
    MatDatepickerModule,
    MatNativeDateModule,
    ReactiveFormsModule
  ],
  template: `
    <h2 mat-dialog-title>{{ data.mode === 'create' ? 'Create' : 'Edit' }} Examination</h2>
    <mat-dialog-content>
      <form [formGroup]="examForm" class="dialog-form">
        <mat-form-field>
          <mat-label>Exam Name</mat-label>
          <input matInput formControlName="examName" placeholder="Enter examination name">
        </mat-form-field>

        <mat-form-field>
          <mat-label>Exam Type</mat-label>
          <mat-select formControlName="examType">
            <mat-option *ngFor="let t of examTypes" [value]="t.name">{{ t.name }}</mat-option>
            @if (!examTypes.length) {
              <mat-option value="General">General</mat-option>
            }
          </mat-select>
        </mat-form-field>

        <mat-form-field>
          <mat-label>Academic Year</mat-label>
          <mat-select formControlName="academicYearId">
            <mat-option *ngFor="let year of data.academicYears" [value]="year.id">
              {{ year.name }}
            </mat-option>
          </mat-select>
        </mat-form-field>

        <mat-form-field>
          <mat-label>Start Date</mat-label>
          <input matInput [matDatepicker]="startPicker" formControlName="startDate">
          <mat-datepicker-toggle matSuffix [for]="startPicker"></mat-datepicker-toggle>
          <mat-datepicker #startPicker></mat-datepicker>
        </mat-form-field>

        <mat-form-field>
          <mat-label>End Date</mat-label>
          <input matInput [matDatepicker]="endPicker" formControlName="endDate">
          <mat-datepicker-toggle matSuffix [for]="endPicker"></mat-datepicker-toggle>
          <mat-datepicker #endPicker></mat-datepicker>
        </mat-form-field>

        <mat-form-field class="full-width">
          <mat-label>Description</mat-label>
          <textarea matInput formControlName="description" rows="3" placeholder="Enter description"></textarea>
        </mat-form-field>
      </form>
    </mat-dialog-content>
    <mat-dialog-actions align="end">
      <button mat-button (click)="onCancel()">Cancel</button>
      <button mat-raised-button color="primary" (click)="onSave()" [disabled]="examForm.invalid">
        {{ data.mode === 'create' ? 'Create' : 'Update' }}
      </button>
    </mat-dialog-actions>
  `,
  styles: [`
    .dialog-form {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 10px 12px;
    }
    .dialog-form mat-form-field {
      width: 100%;
    }
    .dialog-form .full-width {
      grid-column: span 2;
    }

    /* ── Mobile: single column, compact type ── */
    @media (max-width: 599px) {
      .dialog-form {
        grid-template-columns: 1fr;
        gap: 2px;
        padding: 10px 14px 14px;
      }

      .dialog-form .full-width { grid-column: 1 / -1; }

      h2[mat-dialog-title] {
        font-size: var(--font-size-base);
        font-weight: 700;
        padding: 12px 16px 8px;
        margin: 0;
        border-bottom: 1px solid var(--st-border-soft, var(--md-surface-container-low));
      }

      mat-dialog-content {
        padding: 0 !important;
      }

      textarea[matInput] { min-height: 56px; font-size: 14px; }
    }
  `]
})
export class ExaminationDialogComponent {
  examForm: FormGroup;

  /** Examination types loaded from the API (passed by the opener component). */
  examTypes: any[] = [];

  constructor(
    private fb: FormBuilder,
    public dialogRef: MatDialogRef<ExaminationDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.examTypes = data?.examTypes ?? [];
    this.examForm = this.fb.group({
      examName: [this.data.examination?.examName || '', Validators.required],
      examType: [this.data.examination?.examType || (this.examTypes[0]?.name ?? 'General'), Validators.required],
      academicYearId: [this.data.examination?.academicYearId || '', Validators.required],
      startDate: [this.data.examination?.startDate || '', Validators.required],
      endDate: [this.data.examination?.endDate || '', Validators.required],
      description: [this.data.examination?.description || '']
    });
  }

  onCancel(): void {
    this.dialogRef.close();
  }

  onSave(): void {
    if (this.examForm.valid) {
      this.dialogRef.close(this.examForm.value);
    }
  }
}
