import { Component, Inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatDialogModule, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { MatInputModule } from '@angular/material/input';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatTabsModule } from '@angular/material/tabs';
import { MatTableModule } from '@angular/material/table';
import { MatIconModule } from '@angular/material/icon';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-generate-timetable-dialog',
  standalone: true,
  imports: [
    CommonModule,
    MatDialogModule,
    MatButtonModule,
    MatFormFieldModule,
    MatSelectModule,
    MatInputModule,
    MatCheckboxModule,
    MatProgressBarModule,
    MatTabsModule,
    MatTableModule,
    MatIconModule,
    ReactiveFormsModule
  ],
  template: `
    <mat-dialog-content>
      <h2 mat-dialog-title>
        <mat-icon>schedule</mat-icon>
        Generate Timetable
      </h2>
      
      <mat-tab-group>
        <mat-tab label="Configuration">
          <form [formGroup]="generateForm" class="dialog-form">
            <mat-form-field>
              <mat-label>Academic Year</mat-label>
              <mat-select formControlName="academicYearId">
                <mat-option *ngFor="let year of data.academicYears" [value]="year.id">
                  {{ year.name }}
                </mat-option>
              </mat-select>
            </mat-form-field>

            <mat-form-field>
              <mat-label>Class</mat-label>
              <mat-select formControlName="classId">
                <mat-option *ngFor="let class of data.classes" [value]="class.id">
                  {{ class.name }}
                </mat-option>
              </mat-select>
            </mat-form-field>

            <mat-form-field>
              <mat-label>Start Time</mat-label>
              <mat-select formControlName="startTime">
                <mat-option value="09:00">9:00 AM</mat-option>
                <mat-option value="08:30">8:30 AM</mat-option>
                <mat-option value="08:00">8:00 AM</mat-option>
              </mat-select>
            </mat-form-field>

            <mat-form-field>
              <mat-label>Period Duration (minutes)</mat-label>
              <mat-select formControlName="periodDuration">
                <mat-option value="45">45 minutes</mat-option>
                <mat-option value="50">50 minutes</mat-option>
                <mat-option value="60">60 minutes</mat-option>
              </mat-select>
            </mat-form-field>

            <mat-form-field>
              <mat-label>Break Duration (minutes)</mat-label>
              <mat-select formControlName="breakDuration">
                <mat-option value="10">10 minutes</mat-option>
                <mat-option value="15">15 minutes</mat-option>
                <mat-option value="20">20 minutes</mat-option>
              </mat-select>
            </mat-form-field>

            <mat-form-field>
              <mat-label>Lunch Break Duration (minutes)</mat-label>
              <mat-select formControlName="lunchDuration">
                <mat-option value="30">30 minutes</mat-option>
                <mat-option value="45">45 minutes</mat-option>
                <mat-option value="60">60 minutes</mat-option>
              </mat-select>
            </mat-form-field>

            <div class="working-days-section full-width">
              <h4>Working Days</h4>
              <div class="days-grid">
                <mat-checkbox formControlName="monday">Monday</mat-checkbox>
                <mat-checkbox formControlName="tuesday">Tuesday</mat-checkbox>
                <mat-checkbox formControlName="wednesday">Wednesday</mat-checkbox>
                <mat-checkbox formControlName="thursday">Thursday</mat-checkbox>
                <mat-checkbox formControlName="friday">Friday</mat-checkbox>
                <mat-checkbox formControlName="saturday">Saturday</mat-checkbox>
              </div>
            </div>
          </form>
        </mat-tab>

        <mat-tab label="Subject Allocation">
          <div class="subject-allocation">
            <h4>Subject-wise Period Allocation per Week</h4>
            <div class="allocation-grid">
              <div class="allocation-header">
                <span>Subject</span>
                <span>Periods/Week</span>
                <span>Teacher</span>
              </div>
              <div class="allocation-row" *ngFor="let subject of data.subjects">
                <span class="subject-name">{{ subject.name }}</span>
                <mat-form-field>
                  <mat-select [value]="getSubjectAllocation(subject.id)" 
                            (selectionChange)="setSubjectAllocation(subject.id, $event.value)">
                    <mat-option [value]="1">1</mat-option>
                    <mat-option [value]="2">2</mat-option>
                    <mat-option [value]="3">3</mat-option>
                    <mat-option [value]="4">4</mat-option>
                    <mat-option [value]="5">5</mat-option>
                    <mat-option [value]="6">6</mat-option>
                  </mat-select>
                </mat-form-field>
                <mat-form-field>
                  <mat-select [value]="getSubjectTeacher(subject.id)"
                            (selectionChange)="setSubjectTeacher(subject.id, $event.value)">
                    <mat-option *ngFor="let teacher of data.teachers" [value]="teacher.id">
                      {{ teacher.name }}
                    </mat-option>
                  </mat-select>
                </mat-form-field>
              </div>
            </div>
          </div>
        </mat-tab>

        <mat-tab label="Preview" [disabled]="!generationPreview">
          <div class="preview-section" *ngIf="generationPreview">
            <h4>Generated Timetable Preview</h4>
            <div class="preview-stats">
              <div class="stat">Total Periods: {{ generationPreview.totalPeriods }}</div>
              <div class="stat">Conflicts: {{ generationPreview.conflicts }}</div>
              <div class="stat">Success Rate: {{ generationPreview.successRate }}%</div>
            </div>
            
            <div class="preview-table" *ngIf="generationPreview.conflicts > 0">
              <h5>Conflicts Detected:</h5>
              <ul>
                <li *ngFor="let conflict of generationPreview.conflictDetails">
                  {{ conflict }}
                </li>
              </ul>
            </div>
          </div>
        </mat-tab>
      </mat-tab-group>

      <div class="generation-progress" *ngIf="isGenerating">
        <mat-progress-bar mode="indeterminate"></mat-progress-bar>
        <p>{{ generationStatus() }}</p>
      </div>
    </mat-dialog-content>
    
    <mat-dialog-actions align="end">
      <button mat-button (click)="onCancel()">Cancel</button>
      <button mat-raised-button color="primary" (click)="onPreview()" 
              [disabled]="generateForm.invalid || isGenerating">
        Preview
      </button>
      <button mat-raised-button color="accent" (click)="onGenerate()" 
              [disabled]="generateForm.invalid || isGenerating">
        {{ isGenerating ? 'Generating...' : 'Generate' }}
      </button>
    </mat-dialog-actions>
  `,
  styles: [`
    .dialog-form {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 10px 12px;
      padding: 20px 0;
    }
    .dialog-form mat-form-field {
      width: 100%;
    }
    .dialog-form .full-width {
      grid-column: span 2;
    }
    .working-days-section h4 {
      margin: 0 0 12px 0;
      color: var(--md-on-surface);
    }
    .days-grid {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 12px;
    }
    .subject-allocation {
      padding: 20px 0;
    }
    .allocation-grid {
      max-height: 400px;
      overflow-y: auto;
    }
    .allocation-header {
      display: grid;
      grid-template-columns: 2fr 1fr 2fr;
      gap: 16px;
      padding: 12px 0;
      font-weight: 600;
      border-bottom: 2px solid var(--color-border);
      margin-bottom: 8px;
    }
    .allocation-row {
      display: grid;
      grid-template-columns: 2fr 1fr 2fr;
      gap: 16px;
      align-items: center;
      padding: 8px 0;
      border-bottom: 1px solid var(--color-border);
    }
    .subject-name {
      font-weight: 500;
    }
    .preview-section {
      padding: 20px 0;
    }
    .preview-stats {
      display: flex;
      gap: 24px;
      margin-bottom: 16px;
      padding: 16px;
      background: var(--md-surface-container-low);
      border-radius: 8px;
    }
    .stat {
      font-weight: 600;
      padding: 8px 16px;
      background: white;
      border-radius: 4px;
    }
    .preview-table {
      background: #fff3cd;
      border: 1px solid #ffeeba;
      border-radius: 4px;
      padding: 16px;
    }
    .preview-table h5 {
      margin: 0 0 8px 0;
      color: #856404;
    }
    .preview-table ul {
      margin: 0;
      padding-left: 20px;
      color: #856404;
    }
    .generation-progress {
      text-align: center;
      padding: 16px;
      background: #f0f8ff;
      border-radius: 8px;
      margin-top: 16px;
    }

    /* ── Mobile: full-width single column, compact allocation rows ── */
    @media (max-width: 599px) {
      .dialog-form {
        grid-template-columns: 1fr;
        gap: 2px;
        padding: 8px 0;
      }

      .dialog-form .full-width { grid-column: 1 / -1; }

      h2[mat-dialog-title] {
        font-size: var(--font-size-base);
        font-weight: 700;
        padding: 12px 16px 8px;
        margin: 0;
        border-bottom: 1px solid var(--st-border-soft, var(--md-surface-container-low));
      }

      mat-dialog-content { padding: 8px 14px !important; }

      .days-grid {
        grid-template-columns: repeat(2, 1fr);
        gap: 8px;
      }

      .allocation-header,
      .allocation-row {
        grid-template-columns: 1.4fr 0.8fr 1.4fr;
        gap: 8px;
        font-size: 12px;
      }

      .allocation-header {
        padding: 8px 0;
        border-bottom-width: 1px;
      }

      .preview-section { padding: 8px 0; }

      .preview-stats {
        gap: 8px;
        padding: 10px;
        flex-wrap: wrap;
      }

      .stat { padding: 6px 10px; font-size: 12px; }

      .preview-table {
        padding: 10px;
        font-size: 12px;
      }
    }
  `]
})
export class GenerateTimetableDialogComponent {
  generateForm: FormGroup;
  isGenerating = false;
  generationStatus = signal('');
  generationPreview: any = null;
  subjectAllocations: { [key: number]: number } = {};
  subjectTeachers: { [key: number]: number } = {};

  constructor(
    private fb: FormBuilder,
    public dialogRef: MatDialogRef<GenerateTimetableDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.generateForm = this.fb.group({
      academicYearId: [this.data.selectedAcademicYear || '', Validators.required],
      classId: [this.data.selectedClass || '', Validators.required],
      startTime: ['09:00', Validators.required],
      periodDuration: [50, Validators.required],
      breakDuration: [15, Validators.required],
      lunchDuration: [45, Validators.required],
      monday: [true],
      tuesday: [true],
      wednesday: [true],
      thursday: [true],
      friday: [true],
      saturday: [true]
    });

    // Initialize default subject allocations
    this.data.subjects.forEach((subject: any) => {
      this.subjectAllocations[subject.id] = 3; // Default 3 periods per week
      this.subjectTeachers[subject.id] = this.data.teachers[0]?.id || 1;
    });
  }

  onCancel(): void {
    this.dialogRef.close();
  }

  onPreview(): void {
    if (this.generateForm.valid) {
      this.simulatePreview();
    }
  }

  onGenerate(): void {
    if (this.generateForm.valid) {
      this.isGenerating = true;
      this.simulateGeneration();
    }
  }

  getSubjectAllocation(subjectId: number): number {
    return this.subjectAllocations[subjectId] || 3;
  }

  setSubjectAllocation(subjectId: number, allocation: number): void {
    this.subjectAllocations[subjectId] = allocation;
  }

  getSubjectTeacher(subjectId: number): number {
    return this.subjectTeachers[subjectId] || 1;
  }

  setSubjectTeacher(subjectId: number, teacherId: number): void {
    this.subjectTeachers[subjectId] = teacherId;
  }

  private simulatePreview(): void {
    const totalPeriods = Object.values(this.subjectAllocations).reduce((sum, periods) => sum + periods, 0);
    const conflicts = Math.floor(Math.random() * 3);
    const successRate = Math.floor((totalPeriods - conflicts) / totalPeriods * 100);

    const conflictDetails = [
      'Teacher John Smith has overlapping periods on Monday 10:00 AM',
      'Room B-201 is double-booked on Tuesday 2:00 PM',
      'Physics lab not available during allocated time slot'
    ].slice(0, conflicts);

    this.generationPreview = {
      totalPeriods,
      conflicts,
      successRate,
      conflictDetails
    };
  }

  private simulateGeneration(): void {
    const steps = [
      'Validating configuration...',
      'Allocating periods...',
      'Checking teacher availability...',
      'Resolving room conflicts...',
      'Optimizing schedule...',
      'Finalizing timetable...'
    ];

    let stepIndex = 0;
    const interval = setInterval(() => {
      if (stepIndex < steps.length) {
        this.generationStatus.set(steps[stepIndex]);
        stepIndex++;
      } else {
        clearInterval(interval);
        this.completeGeneration();
      }
    }, 1000);
  }

  private completeGeneration(): void {
    this.isGenerating = false;
    this.generationStatus.set('');
    
    this.dialogRef.close({
      action: 'generate',
      config: this.generateForm.value,
      subjectAllocations: this.subjectAllocations,
      subjectTeachers: this.subjectTeachers
    });
  }
}
