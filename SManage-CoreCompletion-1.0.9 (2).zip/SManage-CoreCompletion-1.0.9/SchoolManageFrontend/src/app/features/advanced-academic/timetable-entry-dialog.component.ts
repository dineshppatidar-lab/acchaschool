import { ChangeDetectorRef, Component, Inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatDialogModule, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-timetable-entry-dialog',
  standalone: true,
  imports: [
    CommonModule,
    MatDialogModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatButtonModule,
    MatDatepickerModule,
    MatNativeDateModule,
    ReactiveFormsModule
  ],
  template: `
    <h2 mat-dialog-title>{{ data.mode === 'create' ? 'Add' : 'Edit' }} Timetable Entry</h2>
    <mat-dialog-content>
      <form [formGroup]="timetableForm" class="dialog-form">
        <mat-form-field>
          <mat-label>Class</mat-label>
          <mat-select formControlName="classId">
            <mat-option *ngFor="let class of data.classes" [value]="class.id">
              {{ class.name }}
            </mat-option>
          </mat-select>
        </mat-form-field>

        <mat-form-field>
          <mat-label>Section</mat-label>
          <mat-select formControlName="sectionId">
            <mat-option [value]="null">Default (first section)</mat-option>
            <mat-option *ngFor="let section of data.sections" [value]="section.id">
              {{ section.name }}
            </mat-option>
          </mat-select>
          <mat-hint>Leave empty to use the class's first section</mat-hint>
        </mat-form-field>

        <mat-form-field>
          <mat-label>Subject</mat-label>
          <mat-select formControlName="subjectId">
            <mat-option *ngFor="let subject of subjectsForClass()" [value]="subject.id">
              {{ subject.name }}
            </mat-option>
          </mat-select>
          <mat-hint>{{ subjectsForClass().length ? 'Subjects of the selected class' : 'Select a class to load its subjects' }}</mat-hint>
        </mat-form-field>

        <mat-form-field>
          <mat-label>Teacher</mat-label>
          <mat-select formControlName="teacherId">
            <mat-option *ngFor="let teacher of data.teachers" [value]="teacher.id">
              {{ teacher.name }}
            </mat-option>
          </mat-select>
        </mat-form-field>

        <mat-form-field>
          <mat-label>Day</mat-label>
          <mat-select formControlName="dayOfWeek">
            <mat-option *ngFor="let day of data.weekDays" [value]="day">
              {{ day }}
            </mat-option>
          </mat-select>
        </mat-form-field>

        <mat-form-field>
          <mat-label>Room</mat-label>
          <input matInput formControlName="room" placeholder="e.g. A-101" />
        </mat-form-field>

        <mat-form-field>
          <mat-label>Start Time</mat-label>
          <input matInput type="time" formControlName="startTime" />
        </mat-form-field>

        <mat-form-field>
          <mat-label>End Time</mat-label>
          <input matInput type="time" formControlName="endTime" />
        </mat-form-field>
      </form>
    </mat-dialog-content>
    <mat-dialog-actions align="end">
      <button mat-button (click)="onCancel()">Cancel</button>
      <button mat-raised-button color="primary" (click)="onSave()" [disabled]="timetableForm.invalid">
        {{ data.mode === 'create' ? 'Add' : 'Update' }}
      </button>
    </mat-dialog-actions>
  `,
  styles: [`
    .dialog-form {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 10px 12px;
    }
    .dialog-form mat-form-field {
      width: 100%;
    }
    .dialog-form mat-form-field.full-width,
    .dialog-form mat-form-field:nth-child(6) {
      grid-column: 1 / -1;
    }

    /* ── Mobile: single column, tighter typography, thumb-friendly actions ── */
    @media (max-width: 599px) {
      .dialog-form {
        grid-template-columns: 1fr;
        gap: 2px;
        padding: 10px 14px 14px;
      }

      h2[mat-dialog-title] {
        font-size: var(--font-size-base);
        font-weight: 700;
        padding: 12px 16px 8px;
        margin: 0;
        border-bottom: 1px solid var(--st-border-soft, var(--md-surface-container-low));
      }

      mat-dialog-content {
        padding: 0 !important;
      }

      /*denser controls per mockup: 38px input bodies, 12px label, 13px text*/
      .mat-mdc-form-field {
        --mat-form-field-outlined-input-text-size: 14px;
      }
    }
  `]
})
export class TimetableEntryDialogComponent {
  timetableForm: FormGroup;

  /** Subjects of the selected class (subjects are class-scoped in the DB). */
  subjectsForClass = signal<any[]>([]);

  constructor(
    private fb: FormBuilder,
    private cdr: ChangeDetectorRef,
    public dialogRef: MatDialogRef<TimetableEntryDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.timetableForm = this.fb.group({
      classId: [this.data.timetableEntry?.classId || '', Validators.required],
      sectionId: [this.data.timetableEntry?.sectionId || null],
      subjectId: [this.data.timetableEntry?.subjectId || '', Validators.required],
      teacherId: [this.data.timetableEntry?.teacherId || '', Validators.required],
      dayOfWeek: [this.data.timetableEntry?.dayOfWeek || '', Validators.required],
      startTime: [this.toTimeInput(this.data.timetableEntry?.startTime) || '08:00', Validators.required],
      endTime: [this.toTimeInput(this.data.timetableEntry?.endTime) || '09:00', Validators.required],
      room: [this.data.timetableEntry?.room || '']
    });

    // Subjects cascade from the selected class.
    this.timetableForm.get('classId')!.valueChanges.subscribe((classId: number) => {
      this.loadSubjects(classId);
      this.timetableForm.patchValue({ subjectId: null });
    });

    const initialClassId = this.data.timetableEntry?.classId;
    if (initialClassId) {
      queueMicrotask(() => this.loadSubjects(initialClassId));
    }
  }

  private loadSubjects(classId: number): void {
    const svc = (this.data as any)?.academicService as { getSubjects: (id: number) => import('rxjs').Observable<any[]> } | undefined;
    if (!classId || !svc) { this.setSubjects([]); return; }
    svc.getSubjects(classId).subscribe({
      next: (subjects) => this.setSubjects(subjects || []),
      error: () => this.setSubjects([])
    });
  }

  /** Mutate state outside any in-flight CD pass, then schedule a re-render. */
  private setSubjects(subjects: any[]): void {
    queueMicrotask(() => {
      this.subjectsForClass.set(subjects);
      this.cdr.markForCheck();
    });
  }

  /** Convert backend "08:00:00" to HTML time input "08:00". */
  private toTimeInput(t: string | undefined): string | null {
    if (!t) return null;
    const m = String(t).match(/^(\d{1,2}):(\d{2})/);
    return m ? `${m[1].padStart(2, '0')}:${m[2]}` : null;
  }

  onCancel(): void {
    this.dialogRef.close();
  }

  onSave(): void {
    if (this.timetableForm.valid) {
      this.dialogRef.close(this.timetableForm.value);
    }
  }
}
