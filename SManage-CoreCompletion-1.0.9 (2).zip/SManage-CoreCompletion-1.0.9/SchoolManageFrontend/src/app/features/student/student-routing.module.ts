import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { StudentImportExportComponent } from './student-import-export.component';
import { StudentListComponent } from '../../student-list/student-list-new';
import { StudentFormComponent } from '../../student-form/student-form';

const routes: Routes = [
  { path: '', redirectTo: 'full-details', pathMatch: 'full' },
  { path: 'list', component: StudentListComponent }, // Legacy route - kept for compatibility
  { path: 'form', component: StudentFormComponent },
  { path: 'edit/:id', component: StudentFormComponent },
  { path: 'admissions', component: StudentFormComponent },
  { path: 'import-export', component: StudentImportExportComponent },
  { 
    path: 'full-details', 
    loadChildren: () => import('../student-full-details/student-full-details.module').then(m => m.StudentFullDetailsModule)
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class StudentRoutingModule { }
