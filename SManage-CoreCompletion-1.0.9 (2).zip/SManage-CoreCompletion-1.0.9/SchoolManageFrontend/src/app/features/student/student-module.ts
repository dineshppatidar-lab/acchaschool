import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { StudentImportExportComponent } from './student-import-export.component';
import { MatCardModule } from '@angular/material/card';
import { MatListModule } from '@angular/material/list';
import { MatIconModule } from '@angular/material/icon';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatButtonModule } from '@angular/material/button';
import { MatInputModule } from '@angular/material/input';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatFormFieldModule } from '@angular/material/form-field';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { StudentRoutingModule } from './student-routing.module';
import { StudentListComponent } from '../../student-list/student-list-new';
import { StudentFormComponent } from '../../student-form/student-form';

@NgModule({ 
  imports: [
    CommonModule,
    MatCardModule,
    MatButtonModule,
    FormsModule,
    ReactiveFormsModule,
    StudentRoutingModule,
    
    StudentImportExportComponent,
    StudentListComponent,
    StudentFormComponent
  ],
  exports: [StudentImportExportComponent, StudentListComponent, StudentFormComponent]
})
export class StudentModule { }
