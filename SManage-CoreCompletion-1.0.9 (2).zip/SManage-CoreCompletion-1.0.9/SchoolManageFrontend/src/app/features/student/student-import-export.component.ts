import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatCardModule } from '@angular/material/card';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatTooltipModule } from '@angular/material/tooltip';
import { HttpErrorResponse } from '@angular/common/http';
import { extractApiErrorMessage } from '../../services/api-response.interceptor';
import {
  ImportExportService,
  StudentImportResult,
  StudentImportRowError
} from '../../services/import-export.service';
import { StudentPageHeaderComponent } from '../../shared/components/students-module/student-page-header.component';

@Component({
  selector: 'app-student-import-export',
  standalone: true,
  imports: [
    CommonModule,
    MatButtonModule,
    MatIconModule,
    MatCardModule,
    MatSnackBarModule,
    MatProgressSpinnerModule,
    MatTooltipModule,
    StudentPageHeaderComponent
  ],
  templateUrl: './student-import-export.component.html',
  styleUrls: ['./student-import-export.component.scss']
})
export class StudentImportExportComponent {
  selectedFile = signal<any>(null);
  importing = signal(false);
  exporting = signal(false);
  result = signal<any>(null);

  readonly maxRows = 500;

  constructor(
    private service: ImportExportService,
    private snackBar: MatSnackBar
  ) {}

  onFileChange(event: Event): void {
    const input = event.target as HTMLInputElement;
    this.setSelectedFile(input.files?.[0] ?? null);
  }

  onDrop(event: DragEvent): void {
    event.preventDefault();
    const file = event.dataTransfer?.files?.[0] ?? null;
    this.setSelectedFile(file);
  }

  onDragOver(event: DragEvent): void {
    event.preventDefault();
  }

  clearFile(event: Event): void {
    event.stopPropagation();
    this.setSelectedFile(null);
  }

  private setSelectedFile(file: File | null): void {
    this.result.set(null);
    if (!file) {
      this.selectedFile.set(null);
      return;
    }
    if (!file.name.toLowerCase().endsWith('.xlsx')) {
      this.snackBar.open('Please upload the .xlsx template downloaded from this screen.', 'Close', { duration: 5000 });
      this.selectedFile.set(null);
      return;
    }
    this.selectedFile.set(file);
  }

  downloadTemplate(): void {
    this.service.downloadAdmissionTemplate().subscribe({
      next: (blob) => {
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'Student_Admission_Template.xlsx';
        a.click();
        window.URL.revokeObjectURL(url);
        this.snackBar.open('Template downloaded. Fill it and upload it back here.', 'Close', { duration: 4000 });
      },
      error: (err: HttpErrorResponse) => {
        this.snackBar.open(extractApiErrorMessage(err.error) || 'Could not download template.', 'Close', { duration: 5000 });
      }
    });
  }

  import(): void {
    if (!this.selectedFile() || this.importing()) return;
    this.importing.set(true);
    this.result.set(null);

    this.service.importStudents(this.selectedFile()).subscribe({
      next: (res) => {
        this.result.set(res);
        this.importing.set(false);
        if (res.failedCount === 0 && (!res.errors || res.errors.length === 0)) {
          this.snackBar.open(`${res.importedCount} student(s) admitted successfully.`, 'Close', { duration: 4000 });
          this.selectedFile.set(null);
        } else {
          this.snackBar.open(
            `${res.importedCount} imported, ${res.failedCount} failed. Review the errors below.`,
            'Close',
            { duration: 6000 }
          );
        }
      },
      error: (err: HttpErrorResponse) => {
        this.importing.set(false);
        this.snackBar.open(extractApiErrorMessage(err.error) || 'Import failed.', 'Close', { duration: 6000 });
      }
    });
  }

  export(): void {
    this.exporting.set(true);
    this.service.exportStudents().subscribe({
      next: (blob) => {
        this.exporting.set(false);
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'students.csv';
        a.click();
        window.URL.revokeObjectURL(url);
      },
      error: () => {
        this.exporting.set(false);
        this.snackBar.open('Export failed.', 'Close', { duration: 5000 });
      }
    });
  }

  hasErrors(result: StudentImportResult): boolean {
    return result.failedCount > 0 || (result.errors?.length ?? 0) > 0;
  }

  trackByRow(_: number, row: StudentImportRowError): number {
    return row.rowNumber;
  }
}
