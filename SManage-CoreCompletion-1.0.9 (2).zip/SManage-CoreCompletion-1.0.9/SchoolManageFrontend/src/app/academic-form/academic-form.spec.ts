import { provideZonelessChangeDetection } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AcademicForm } from './academic-form';

describe('AcademicForm', () => {
  let component: AcademicForm;
  let fixture: ComponentFixture<AcademicForm>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AcademicForm],
      providers: [provideZonelessChangeDetection()]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AcademicForm);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
