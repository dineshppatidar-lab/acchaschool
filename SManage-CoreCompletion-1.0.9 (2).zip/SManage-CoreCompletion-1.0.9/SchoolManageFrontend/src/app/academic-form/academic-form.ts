import { Component } from '@angular/core';

@Component({
  selector: 'app-academic-form',
  imports: [],
  templateUrl: './academic-form.html',
  styleUrl: './academic-form.scss'
})
export class AcademicForm {

}
