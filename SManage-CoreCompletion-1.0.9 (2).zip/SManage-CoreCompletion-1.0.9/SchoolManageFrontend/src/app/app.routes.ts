import { Routes } from '@angular/router';
import { LoginComponent } from './features/auth/login.component';
import { RegisterComponent } from './features/auth/register.component';
import { LandingComponent } from './features/landing/landing.component';
import { DebugComponent } from './features/debug/debug.component';
import { AuthGuard } from './services/auth.guard';
import { PermissionGuard } from './core/guards/permission.guard';
import { Permission } from './core/models/permission.model';
import { UserRole } from './core/models/permission.model';
import { PlatformRootGuard, SchoolSiteGuard } from './services/website-routes.guard';

export const routes: Routes = [
  // Default route - Landing page for all visitors. On a bound ACTIVE school
  // host the public school website replaces the platform landing page.
  { path: '', component: LandingComponent, canActivate: [PlatformRootGuard] },
  
  // Public routes (no sidebar, standalone pages)
  { path: 'landing', component: LandingComponent, canActivate: [PlatformRootGuard] },

  // ── Public school website (bound school hosts only) ──
  { path: 'site', redirectTo: 'site/home', pathMatch: 'full' },
  { path: 'site/home', loadComponent: () => import('./features/website/public-website.component').then(m => m.PublicWebsiteComponent), canActivate: [SchoolSiteGuard], data: { view: 'home' } },
  { path: 'site/events', loadComponent: () => import('./features/website/public-website.component').then(m => m.PublicWebsiteComponent), canActivate: [SchoolSiteGuard], data: { view: 'events' } },
  { path: 'site/events/:slug', loadComponent: () => import('./features/website/public-website.component').then(m => m.PublicWebsiteComponent), canActivate: [SchoolSiteGuard], data: { view: 'event-detail' } },
  { path: 'site/albums', loadComponent: () => import('./features/website/public-website.component').then(m => m.PublicWebsiteComponent), canActivate: [SchoolSiteGuard], data: { view: 'albums' } },
  { path: 'site/albums/:slug', loadComponent: () => import('./features/website/public-website.component').then(m => m.PublicWebsiteComponent), canActivate: [SchoolSiteGuard], data: { view: 'album-detail' } },
  { path: 'site/news', loadComponent: () => import('./features/website/public-website.component').then(m => m.PublicWebsiteComponent), canActivate: [SchoolSiteGuard], data: { view: 'news' } },
  { path: 'site/news/:slug', loadComponent: () => import('./features/website/public-website.component').then(m => m.PublicWebsiteComponent), canActivate: [SchoolSiteGuard], data: { view: 'article-detail' } },
  { path: 'site/apply', loadComponent: () => import('./features/website/public-website.component').then(m => m.PublicWebsiteComponent), canActivate: [SchoolSiteGuard], data: { view: 'apply' } },
  { path: 'login', component: LoginComponent },
  { path: 'register-tenant', loadComponent: () => import('./features/auth/tenant-register.component').then(m => m.TenantRegisterComponent) },
  { path: 'terms', loadComponent: () => import('./features/legal/legal-document.component').then(m => m.LegalDocumentComponent), data: { doc: 'terms' } },
  { path: 'privacy', loadComponent: () => import('./features/legal/legal-document.component').then(m => m.LegalDocumentComponent), data: { doc: 'privacy' } },
  { path: 'debug', component: DebugComponent },
  { path: 'forgot-password', loadComponent: () => import('./features/auth/forgot-password.component').then(m => m.ForgotPasswordComponent) },
  { path: 'reset-password', loadComponent: () => import('./features/auth/reset-password.component').then(m => m.ResetPasswordComponent) },
  { path: 'access-denied', loadComponent: () => import('./shared/components/access-denied.component').then(m => m.AccessDeniedComponent) },

  // Protected routes with MainLayout wrapper (sidebar + navigation)
  {
    path: 'app',
    loadComponent: () => import('./layout/main-layout.component').then(m => m.MainLayoutComponent),
    canActivate: [AuthGuard],
    children: [
      // Default protected route redirects to dashboard
      { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
      
      // Main Navigation Routes
      {
        // Dashboard is available to every authenticated user (all roles get
        // DashboardView by default) – no PermissionGuard so nobody is locked out.
        path: 'dashboard',
        loadComponent: () => import('./features/dashboard/dashboard.component').then(m => m.DashboardComponent),
      },

      // Initial Setup Wizard Route (for first-time setup)
      {
        path: 'setup',
        loadComponent: () => import('./features/settings/setup-wizard.component').then(m => m.SetupWizardComponent),
        canActivate: [AuthGuard],
        data: { requiredPermission: Permission.SystemSettings }
      },

      // Top-level user management alias for legacy link
      { path: 'users', redirectTo: 'admin/user-management', pathMatch: 'full' },
      
      // Academic Management
      {
        path: 'academic',
        loadComponent: () => import('./features/academic/academic-list.component').then(m => m.AcademicListComponent),
        canActivate: [PermissionGuard],
        data: { requiredPermission: Permission.ClassesView }
      },
      // Academic create/edit routes
      {
        path: 'academic/form',
        loadComponent: () => import('./features/academic/academic-form.component').then(m => m.AcademicFormComponent),
        canActivate: [PermissionGuard],
        data: { requiredPermission: Permission.ClassesCreate }
      },
      {
        path: 'academic/edit/:id',
        loadComponent: () => import('./features/academic/academic-form.component').then(m => m.AcademicFormComponent),
        canActivate: [PermissionGuard],
        data: { requiredPermission: Permission.ClassesEdit }
      },
      // Academic child placeholders used in sidebar
      { path: 'academic/classes', loadComponent: () => import('./features/academic/academic-list.component').then(m => m.AcademicListComponent), canActivate: [PermissionGuard], data: { requiredPermission: Permission.ClassesView } },
      { path: 'academic/subjects', loadComponent: () => import('./features/academic/academic-list.component').then(m => m.AcademicListComponent), canActivate: [PermissionGuard], data: { requiredPermission: Permission.SubjectsView } },
      { path: 'academic/sections', loadComponent: () => import('./features/academic/section-list.component').then(m => m.SectionListComponent), canActivate: [PermissionGuard], data: { requiredPermission: Permission.ClassesView } },
      { path: 'academic/years', loadComponent: () => import('./features/academic/academic-year-list.component').then(m => m.AcademicYearListComponent), canActivate: [PermissionGuard], data: { requiredPermission: Permission.ClassesView } },
      { path: 'academic/timetables', loadComponent: () => import('./features/academic/academic-list.component').then(m => m.AcademicListComponent), canActivate: [PermissionGuard], data: { requiredPermission: Permission.TimetablesView } },
      // Examinations
      {
        path: 'examinations',
        loadComponent: () => import('./features/examinations/examination-list.component').then(m => m.ExaminationListComponent),
        canActivate: [PermissionGuard],
        data: { requiredPermission: Permission.ExaminationsView }
      },
      {
        path: 'examination-types',
        loadComponent: () => import('./features/examinations/examination-type-list.component').then(m => m.ExaminationTypeListComponent),
        canActivate: [PermissionGuard],
        data: { requiredPermission: Permission.ExaminationsView }
      },
      {
        path: 'examinations/:id/schedules',        loadComponent: () => import('./features/examinations/exam-schedules.component').then(m => m.ExamSchedulesComponent),
        canActivate: [PermissionGuard],
        data: { requiredPermission: Permission.ExaminationsView }
      },
      {
        // Single results page: list + enter-result popup + edit/delete.
        // The legacy /results/enter URL redirects here (menu rows and old
        // bookmarks keep working — see seed SQL for these menu routes).
        path: 'examinations/results',
        loadComponent: () => import('./features/examinations/results-view.component').then(m => m.ResultsViewComponent),
        canActivate: [PermissionGuard],
        data: { requiredPermission: Permission.ResultsView }
      },
      {
        path: 'examinations/results/enter',
        redirectTo: 'examinations/results',
        pathMatch: 'full'
      },
      {
        // Tab deep links (…/timetable, …/results, …/examinations, …/assignments)
        // of the same hub page — same ClassesView gate as the hub route above.
        path: 'advanced-academic/:tab',
        loadComponent: () => import('./features/advanced-academic/advanced-academic.component').then(m => m.AdvancedAcademicComponent),
        canActivate: [PermissionGuard],
        data: { requiredPermission: Permission.ClassesView },
      },
      {
        path: 'advanced-academic',
        loadComponent: () => import('./features/advanced-academic/advanced-academic.component').then(m => m.AdvancedAcademicComponent),
        canActivate: [PermissionGuard],
        data: { requiredPermission: Permission.ClassesView }
      },
      
      // People Management
      // Admissions route for enterprise form
      {
        path: 'students/admissions',
        loadComponent: () => import('./features/student-full-details/student-enterprise-form.component').then(m => m.StudentEnterpriseFormComponent),
        canActivate: [PermissionGuard],
        data: { requiredPermission: Permission.StudentsCreate }
      },
      // Student Enquiry — pre-admission enquiries (informational only, separate
      // StudentEnquiries table; no relation to the admission full-details form)
      {
        path: 'students/enquiry',
        loadComponent: () => import('./features/student-enquiry/student-enquiry.component').then(m => m.StudentEnquiryComponent),
        canActivate: [PermissionGuard],
        data: { requiredPermission: Permission.StudentsView }
      },
      {
        path: 'students/enquiry-list',
        loadComponent: () => import('./features/student-enquiry/student-enquiry-list.component').then(m => m.StudentEnquiryListComponent),
        canActivate: [PermissionGuard],
        data: { requiredPermission: Permission.StudentsView }
      },
      {
        path: 'students/enquiry/edit/:id',
        loadComponent: () => import('./features/student-enquiry/student-enquiry.component').then(m => m.StudentEnquiryComponent),
        canActivate: [PermissionGuard],
        data: { requiredPermission: Permission.StudentsView }
      },
      // Legacy menu URLs point to /app/students/attendance but the dedicated
      // Attendance module lives at /app/attendance. Redirect so the sidebar's
      // DB-seeded link resolves instead of rendering an empty outlet.
      { path: 'students/attendance', redirectTo: 'attendance', pathMatch: 'full' },
      {
        path: 'students',
        loadChildren: () => import('./features/student/student-module').then(m => m.StudentModule),
        canActivate: [PermissionGuard],
        data: { requiredPermission: Permission.StudentsView }
      },
      {
        path: 'staff',
        loadChildren: () => import('./features/staff/staff-module').then(m => m.StaffModule),
        canActivate: [PermissionGuard],
        data: { requiredPermission: Permission.StaffView }
      },
      // Staff sub-routes (designations for Master Entries)
      { path: 'staff/designations', loadComponent: () => import('./features/staff/designation-list.component').then(m => m.DesignationListComponent), canActivate: [PermissionGuard], data: { requiredPermission: Permission.StaffView } },
      {
        path: 'payroll',
        loadComponent: () => import('./features/payroll/payroll.component').then(m => m.PayrollComponent),
        canActivate: [AuthGuard, PermissionGuard],
        data: { requiredPermission: Permission.StaffManagePayroll }
      },
      {
        path: 'parents',
        loadComponent: () => import('./features/parents/parents.component').then(m => m.ParentsComponent),
        canActivate: [PermissionGuard],
        data: { requiredPermission: Permission.StudentsView }
      },
      
      // Organization Management
      { path: 'organization/departments', loadComponent: () => import('./features/organization/department-list.component').then(m => m.DepartmentListComponent), canActivate: [PermissionGuard], data: { requiredPermission: Permission.StaffView } },
      
      // Financial Management
      // IMPORTANT: More specific routes must come BEFORE generic routes
      // Fees form and edit (specific)
      {
        path: 'fees/form',
        loadComponent: () => import('./features/fees/fees-form.component').then(m => m.FeesFormComponent),
        canActivate: [PermissionGuard],
        data: { requiredPermission: Permission.FeesCollect }
      },
      {
        path: 'fees/edit/:id',
        loadComponent: () => import('./features/fees/fees-form.component').then(m => m.FeesFormComponent),
        canActivate: [PermissionGuard],
        data: { requiredPermission: Permission.FeesCollect }
      },
      // Fees list (specific)
      {
        path: 'fees/list',
        loadComponent: () => import('./features/fees/fees-list.component').then(m => m.FeesListComponent),
        canActivate: [PermissionGuard],
        data: { requiredPermission: Permission.FeesView }
      },
      // Fees Dashboard Route - with optional studentId for specific student view
      {
        path: 'fees/dashboard',
        loadComponent: () => import('./features/fees/student-fees-dashboard-demo.component').then(m => m.StudentFeesDashboardComponent),
        canActivate: [PermissionGuard],
        data: { requiredPermission: Permission.FeesView }
      },
      {
        path: 'fees/dashboard/:studentId',
        loadComponent: () => import('./features/fees/student-fees-dashboard-demo.component').then(m => m.StudentFeesDashboardComponent),
        canActivate: [PermissionGuard],
        data: { requiredPermission: Permission.FeesView }
      },
      // Student Ledger Route (specific - individual student ledger view)
      {
        path: 'fees/student/:studentId/ledger',
        loadComponent: () => import('./features/fees/student-ledger.component').then(m => m.StudentLedgerComponent),
        canActivate: [PermissionGuard],
        data: { requiredPermission: Permission.FeesView }
      },
      // Fee Waiver Management Route
      {
        path: 'fees/waivers',
        loadComponent: () => import('./features/fees/fee-waiver.component').then(m => m.FeeWaiverComponent),
        canActivate: [PermissionGuard],
        data: { requiredPermission: Permission.FeesView, requiredRoles: ['SuperAdmin', 'Administrator', 'Principal', 'Accountant'] }
      },
      // Student Discount Management Route
      {
        path: 'fees/discounts',
        loadComponent: () => import('./features/fees/student-discount.component').then(m => m.StudentDiscountComponent),
        canActivate: [PermissionGuard],
        data: { requiredPermission: Permission.FeesView, requiredRoles: ['SuperAdmin', 'Administrator', 'Principal', 'Accountant'] }
      },
      // Family Payment Processor Route
      {
        path: 'fees/family-payments',
        loadComponent: () => import('./features/fees/family-payment-processor.component').then(m => m.FamilyPaymentProcessorComponent),
        canActivate: [PermissionGuard],
        data: { requiredPermission: Permission.FeesCollect, requiredRoles: ['SuperAdmin', 'Administrator', 'Accountant'] }
      },
      // Fee Defaulter List (overdue installments)
      {
        path: 'fees/defaulters',
        loadComponent: () => import('./features/fees/fee-defaulters.component').then(m => m.FeeDefaultersComponent),
        canActivate: [PermissionGuard],
        data: { requiredPermission: Permission.FeesView }
      },
      // Fee Rules Engine (late fees / discounts / fines)
      {
        path: 'fees/rules',
        loadComponent: () => import('./features/fees/fee-rules.component').then(m => m.FeeRulesComponent),
        canActivate: [PermissionGuard],
        data: { requiredPermission: Permission.FeesView, requiredRoles: ['SuperAdmin', 'Administrator', 'Principal', 'Accountant'] }
      },
      // Fee Refund Route - redirects to advanced finance where refund processing lives
      {
        path: 'fees/refund',
        loadComponent: () => import('./features/advanced-finance/advanced-finance.component').then(m => m.AdvancedFinanceComponent),
        canActivate: [PermissionGuard],
        data: { requiredPermission: Permission.FeesCollect }
      },
      // Generic fees route (catches /app/fees and other unmatched paths)
      {
        path: 'fees',
        loadComponent: () => import('./features/fees/fees-list.component').then(m => m.FeesListComponent),
        canActivate: [PermissionGuard],
        data: { requiredPermission: Permission.FeesView }
      },
      
      // IMPORTANT: Specific finance routes must come BEFORE generic finance redirect
      {
        path: 'finance/structure',
        loadComponent: () => import('./features/fees/fee-structure.component').then(m => m.FeeStructureComponent),
        canActivate: [PermissionGuard],
        data: { requiredPermission: Permission.FeesManageStructure }
      },
      {
        path: 'finance/reports',
        loadComponent: () => import('./features/fees/fee-reports.component').then(m => m.FeeReportsComponent),
        canActivate: [PermissionGuard],
        data: { requiredPermission: Permission.FeesReports }
      },
      { path: 'finance/advanced', redirectTo: 'advanced-finance', pathMatch: 'full' },
      
      // Generic finance redirects come after specific routes
      { path: 'finance', redirectTo: 'fees', pathMatch: 'full' },
      { path: 'finance/fees', redirectTo: 'fees', pathMatch: 'full' },
      { path: 'finance/collect', redirectTo: 'fees', pathMatch: 'full' },
      
      {
        path: 'advanced-finance',
        loadComponent: () => import('./features/advanced-finance/advanced-finance.component').then(m => m.AdvancedFinanceComponent),
        canActivate: [PermissionGuard],
        data: { requiredPermission: Permission.FeesView }
      },
      
      // WhatsApp Integration (config, bulk fee reminders, history)
      {
        path: 'whatsapp',
        loadComponent: () => import('./features/whatsapp/whatsapp-settings.component').then(m => m.WhatsappSettingsComponent),
        canActivate: [PermissionGuard],
        data: { requiredPermission: Permission.WhatsAppView }
      },
      {
        path: 'whatsapp/fee-reminders',
        loadComponent: () => import('./features/whatsapp/whatsapp-fee-reminders.component').then(m => m.WhatsAppFeeRemindersComponent),
        canActivate: [PermissionGuard],
        data: { requiredPermission: Permission.WhatsAppSendBulk }
      },
      {
        path: 'whatsapp/history',
        loadComponent: () => import('./features/whatsapp/whatsapp-history.component').then(m => m.WhatsAppHistoryComponent),
        canActivate: [PermissionGuard],
        data: { requiredPermission: Permission.WhatsAppViewHistory }
      },

      // School Website CMS (admin side of the public website)
      {
        path: 'website',
        loadComponent: () => import('./features/website/website-hub.component').then(m => m.WebsiteHubComponent),
        canActivate: [PermissionGuard],
        data: { requiredPermission: Permission.WebsiteView }
      },

      // Communication & Events - SEPARATE PAGES
      // Messages - Standalone page
      {
        path: 'communication',
        loadComponent: () => import('./features/communication/messages.component').then(m => m.MessagesComponent),
        canActivate: [PermissionGuard],
        data: { requiredPermission: Permission.MessagesView }
      },
      {
        path: 'communication/messages',
        loadComponent: () => import('./features/communication/messages.component').then(m => m.MessagesComponent),
        canActivate: [PermissionGuard],
        data: { requiredPermission: Permission.MessagesView }
      },
      // Announcements - Standalone page
      {
        path: 'communication/announcements',
        loadComponent: () => import('./features/communication/announcements.component').then(m => m.AnnouncementsComponent),
        canActivate: [PermissionGuard],
        data: { requiredPermission: Permission.AnnouncementsSend }
      },
      // Events - Standalone page
      {
        path: 'communication/events',
        loadComponent: () => import('./features/communication/events.component').then(m => m.EventsComponent),
        canActivate: [PermissionGuard],
        data: { requiredPermission: Permission.EventsManage }
      },
      // Email Health - admin-only diagnostics page
      {
        path: 'communication/email-health',
        loadComponent: () => import('./features/communication/email-health.component').then(m => m.EmailHealthComponent),
        canActivate: [PermissionGuard],
        data: { requiredPermission: Permission.SystemManage }
      },

      {
        path: 'notifications',
        loadComponent: () => import('./features/shared/notifications.component').then(m => m.NotificationsComponent),
        canActivate: [PermissionGuard],
        data: { requiredPermission: Permission.MessagesView }
      },
      
      // Infrastructure Management
      {
        path: 'hostel',
        loadComponent: () => import('./features/hostel/hostel-list.component').then(m => m.HostelListComponent),
        canActivate: [PermissionGuard],
        data: { requiredPermission: Permission.HostelView }
      },
      // Hostels plural alias + rooms child used by sidebar
      // Legacy alias: the "Infrastructure" menu historically pointed here, but the
      // route never existed — the wildcard used to bounce users to the landing
      // page. Keep as a redirect so stale bookmarks/menu rows land somewhere sane. (#2)
      { path: 'infrastructure', redirectTo: 'hostels', pathMatch: 'full' },
      { path: 'hostels', loadComponent: () => import('./features/hostel/hostel-list.component').then(m => m.HostelListComponent), canActivate: [PermissionGuard], data: { requiredPermission: Permission.HostelView } },
      { path: 'hostels/rooms', loadComponent: () => import('./features/hostel/hostel-list.component').then(m => m.HostelListComponent), canActivate: [PermissionGuard], data: { requiredPermission: Permission.HostelManageRooms } },
      // Hostel add/edit form (standalone, same pattern as the list routes above)
      { path: 'hostel/form', loadComponent: () => import('./features/hostel/hostel-form.component').then(m => m.HostelFormComponent), canActivate: [PermissionGuard], data: { requiredPermission: Permission.HostelManageRooms } },
      { path: 'hostel/edit/:id', loadComponent: () => import('./features/hostel/hostel-form.component').then(m => m.HostelFormComponent), canActivate: [PermissionGuard], data: { requiredPermission: Permission.HostelManageRooms } },
      {
        path: 'transport',
        loadComponent: () => import('./features/transport/transport-list.component').then(m => m.TransportListComponent),
        canActivate: [PermissionGuard],
        data: { requiredPermission: Permission.TransportView }
      },
      { path: 'transport/form', loadComponent: () => import('./features/transport/transport-form.component').then(m => m.TransportFormComponent), canActivate: [PermissionGuard], data: { requiredPermission: Permission.TransportManageVehicles } },
      { path: 'transport/edit/:id', loadComponent: () => import('./features/transport/transport-form.component').then(m => m.TransportFormComponent), canActivate: [PermissionGuard], data: { requiredPermission: Permission.TransportManageVehicles } },
      { path: 'vehicles/edit/:id', loadComponent: () => import('./features/transport/transport-form.component').then(m => m.TransportFormComponent), canActivate: [PermissionGuard], data: { requiredPermission: Permission.TransportManageVehicles } },
      // Transport routes child alias
      { path: 'transport/routes', loadComponent: () => import('./features/transport/routes-list.component').then(m => m.RoutesListComponent), canActivate: [PermissionGuard], data: { requiredPermission: Permission.TransportManageRoutes } },
  { path: 'transport/routes/:routeId/stops', loadComponent: () => import('./features/transport/route-stops.component').then(m => m.RouteStopsComponent), canActivate: [PermissionGuard], data: { requiredPermission: Permission.TransportManageRoutes } },
  { path: 'transport/routes/:routeId/assign', loadComponent: () => import('./features/transport/route-assignment.component').then(m => m.RouteAssignmentComponent), canActivate: [PermissionGuard], data: { requiredPermission: Permission.TransportManageRoutes } },
     
  {
        path: 'library',
        loadComponent: () => import('./features/library/library.component').then(m => m.LibraryComponent),
        canActivate: [PermissionGuard],
        data: { requiredPermission: Permission.LibraryView }
      },
      // Library child aliases used by sidebar
      { path: 'library/issue', loadComponent: () => import('./features/library/library.component').then(m => m.LibraryComponent), canActivate: [PermissionGuard], data: { requiredPermission: Permission.LibraryIssueBooks } },
      { path: 'library/return', loadComponent: () => import('./features/library/library.component').then(m => m.LibraryComponent), canActivate: [PermissionGuard], data: { requiredPermission: Permission.LibraryReturnBooks } },
      
      // Analytics & Reports
      {
        path: 'analytics',
        loadComponent: () => import('./features/dashboard/dashboard.component').then(m => m.DashboardComponent),
        canActivate: [PermissionGuard],
        data: { requiredPermission: Permission.AnalyticsView }
      },
      {
        path: 'daily-ops',
        loadComponent: () => import('./features/daily-ops/daily-ops.component').then(m => m.DailyOpsComponent),
        canActivate: [PermissionGuard],
        data: { requiredPermission: Permission.ReportsView }
      },
      // Dedicated Attendance Module
      {
        path: 'attendance',
        loadComponent: () => import('./features/attendance/attendance.component').then(m => m.AttendanceComponent),
        canActivate: [PermissionGuard],
        data: { requiredPermission: Permission.StudentsView }
      },
      // Reports section placeholders to satisfy sidebar
      { path: 'reports', loadComponent: () => import('./features/dashboard/dashboard.component').then(m => m.DashboardComponent), canActivate: [PermissionGuard], data: { requiredPermission: Permission.ReportsView } },
      { path: 'reports/analytics', loadComponent: () => import('./features/dashboard/dashboard.component').then(m => m.DashboardComponent), canActivate: [PermissionGuard], data: { requiredPermission: Permission.ReportsGenerate } },
      { path: 'reports/generate', loadComponent: () => import('./features/dashboard/dashboard.component').then(m => m.DashboardComponent), canActivate: [PermissionGuard], data: { requiredPermission: Permission.ReportsGenerate } },
      
      // Data Management
      {
        path: 'import-export',
        loadComponent: () => import('./features/import-export/import-export.component').then(m => m.ImportExportComponent),
        canActivate: [PermissionGuard],
        data: { requiredPermission: Permission.SystemManage }
      },
      
      // Administration
      {
        path: 'admin',
        children: [
          // Default admin landing redirects to a visible page
          { path: '', redirectTo: 'audit-logs', pathMatch: 'full' },
          {
            path: 'audit-logs',
            loadComponent: () => import('./features/admin/audit-log.component').then(m => m.AuditLogComponent),
            canActivate: [PermissionGuard],
            data: { requiredPermission: Permission.SystemAuditLogs }
          },
          {
            path: 'user-management',
            canActivate: [PermissionGuard],
            data: { requiredPermission: Permission.UsersView, requiredRoles: [UserRole.SuperAdmin, UserRole.Administrator] },
            children: [
              {
                path: '',
                loadComponent: () => import('./features/user-management/user-list.component').then(m => m.UserListComponent)
              },
              {
                path: 'add',
                loadComponent: () => import('./features/user-management/user-edit.component').then(m => m.UserEditComponent)
              },
              {
                path: 'edit/:id',
                loadComponent: () => import('./features/user-management/user-edit.component').then(m => m.UserEditComponent)
              },
              {
                path: 'view/:id',
                loadComponent: () => import('./features/user-management/user-edit.component').then(m => m.UserEditComponent)
              }
            ]
          },
          {
            path: 'master-data/:type',
            loadComponent: () => import('./features/settings/settings.component').then(m => m.SettingsComponent),
            canActivate: [PermissionGuard],
            data: { requiredPermission: Permission.SystemSettings }
          },
          {
            path: 'permissions',
            loadComponent: () => import('./features/admin/permission-management.component').then(m => m.PermissionManagementComponent),
            canActivate: [PermissionGuard],
            data: { requiredPermission: Permission.SystemManage }
          },
          {
            path: 'menu-permissions',
            loadComponent: () => import('./features/admin/role-menu-permissions.component').then(m => m.RoleMenuPermissionsComponent),
            canActivate: [PermissionGuard],
            data: { requiredPermission: Permission.SystemManage }
          },
          {
            path: 'tenants',
            loadComponent: () => import('./features/admin/tenant-management.component').then(m => m.TenantManagementComponent),
            canActivate: [PermissionGuard],
            data: { requiredPermission: Permission.SystemManage }
          },
          {
            path: 'settings',
            loadComponent: () => import('./features/settings/settings.component').then(m => m.SettingsComponent),
            canActivate: [PermissionGuard],
            data: { requiredPermission: Permission.SystemSettings }
          },
          {
            path: 'backup',
            loadComponent: () => import('./features/settings/settings.component').then(m => m.SettingsComponent),
            canActivate: [PermissionGuard],
            data: { requiredPermission: Permission.SystemBackupRestore }
          }
        ]
      },
      
      // Settings & Profile
      {
        path: 'settings',
        loadComponent: () => import('./features/settings/settings.component').then(m => m.SettingsComponent),
        canActivate: [PermissionGuard],
        data: { requiredPermission: Permission.SystemSettings }
      },
      {
        path: 'profile',
        loadComponent: () => import('./features/settings/settings.component').then(m => m.SettingsComponent),
        canActivate: [PermissionGuard],
        data: { requiredPermission: Permission.DashboardView }
      },
      {
        path: 'help',
        loadComponent: () => import('./features/help/help-support.component').then(m => m.HelpSupportComponent),
        canActivate: [PermissionGuard],
        data: { requiredPermission: Permission.DashboardView }
      }
    ]
  },
  
  // Fallback routes
  // Unknown paths land on access-denied (keeps the logged-in shell) instead of
  // the public landing page, which made bad/stale menu links feel like a
  // logout. (#3)
  { path: '**', redirectTo: 'app/access-denied' }
];
