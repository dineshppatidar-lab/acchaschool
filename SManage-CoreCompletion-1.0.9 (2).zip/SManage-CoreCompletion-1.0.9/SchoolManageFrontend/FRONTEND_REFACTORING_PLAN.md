# Frontend Refactoring Plan
## Angular Application Architecture Improvements

---

## Executive Summary

This document outlines the refactoring strategy to improve the Angular frontend architecture for the School Management System, following clean architecture principles and Angular best practices.

**Status:** ⚠️ **AUDIT COMPLETE** - Multiple architectural issues identified
**Last Updated:** July 14, 2026
**Document Version:** 1.0

---

## 🔍 Complete Frontend Codebase Audit Results

### Overview

| Metric | Current State | Target State | Issue |
|--------|---------------|--------------|-------|
| Total Services | 61 | Consolidated to ~30 | Duplicate services, inconsistent patterns |
| Total Components | 120+ | Same | Many need refactoring |
| Components with Direct HttpClient | 8+ | 0 | Should use services only |
| Duplicate Services | 5+ | 0 | MasterDataService, AuthService duplicated |
| Services with TODO Comments | 5+ | 0 | Missing integrations |
| Components with TODO Comments | 3+ | 0 | Incomplete features |
| Inconsistent Service Patterns | Yes | No | Mix of inject() and constructor |

### Architecture Analysis

```
Current Issues:
├── Duplicate Services (5+)
│   ├── MasterDataService (services/ vs core/services/)
│   ├── AuthService (services/ vs core/services/)
│   └── FeeManagementService vs FeesService
├── Direct HttpClient Usage in Components (8+)
│   ├── transport-form.component.ts
│   ├── fees-list.component.ts
│   ├── forgot-password.component.ts
│   ├── reset-password.component.ts
│   └── designation-form.component.ts
├── Inconsistent Service Patterns
│   ├── Some use inject() (modern)
│   └── Some use constructor (legacy)
└── Missing Integrations (TODO comments)
    ├── NotificationService integration
    ├── AuditLogService integration
    └── Error tracking service
```

---

## Services Inventory

### ✅ Well-Structured Services (Use as Reference)

| Service | Location | Pattern | Status |
|---------|----------|---------|--------|
| BaseCrudService | core/services/ | Base class pattern | ✅ Good |
| ApiService | services/ | Central API service | ✅ Good |
| AuthService | core/services/ | Auth management | ✅ Good |
| PermissionService | core/services/ | Permission checks | ✅ Good |
| DynamicMenuService | services/ | Menu handling | ✅ Good |

### ⚠️ Services Needing Consolidation

| Duplicate | Location 1 | Location 2 | Action Required |
|-----------|------------|------------|-----------------|
| MasterDataService | services/ | core/services/ | Merge to single service |
| AuthService | services/ | core/services/ | Merge to single service |
| PayrollService | services/ | features/payroll/ | Merge to single service |
| FeeManagementService | shared/services/ | services/fees.service.ts | Consolidate |
| EnhancedFeeService | shared/services/ | services/fees.service.ts | Consolidate |

### 🔴 Services with Missing Integrations

| Service | TODO Comment | Required Integration |
|---------|--------------|----------------------|
| TransportService | Line 173 | NotificationService, AuditLogService |
| HostelService | Line 73 | NotificationService, AuditLogService |
| FeesService | Line 64 | NotificationService, AuditLogService |
| AcademicService | Line 58 | NotificationService, AuditLogService |

---

## Components Using HttpClient Directly

### 🔴 Components Bypassing Services (CRITICAL)

| Component | Line | Issue | Refactoring Required |
|-----------|------|-------|---------------------|
| transport-form.component.ts | 20, 84 | Direct HttpClient injection | Use TransportService |
| fees-list.component.ts | 27, 106 | Direct HttpClient injection | Use FeesService |
| forgot-password.component.ts | 5, 40 | Direct HttpClient injection | Use AuthService |
| reset-password.component.ts | 5, 49 | Direct HttpClient injection | Use AuthService |
| designation-form.component.ts | 17, 77 | Direct HttpClient injection | Create DesignationService |
| department-form.component.ts | 17, 71 | Direct HttpClient injection | Create DepartmentService |
| student-list-new.ts | 88 | Direct masterDataService call | Consolidate service |
| academic-list.ts | 41 | Direct academicService.delete | Verify service usage |

---

## Refactoring Plan

### Phase A: Consolidate Duplicate Services (HIGH PRIORITY)

| Priority | Task | Current State | Target State | Est. Hours |
|----------|------|---------------|--------------|------------|
| 1 | Merge MasterDataService | 2 implementations | Single in core/services/ | 2-3 |
| 2 | Merge AuthService | 2 implementations | Single in core/services/ | 2-3 |
| 3 | Consolidate Fee Services | 3 services (Fees, FeeManagement, EnhancedFee) | Single FeesService | 4-5 |
| 4 | Consolidate PayrollService | 2 implementations | Single in services/ | 2 |
| 5 | Standardize service patterns | Mix of inject() and constructor | Single pattern (inject()) | 4-6 |
| **Phase A Total** | | | | **14-19** |

### Phase B: Remove Direct HttpClient from Components (CRITICAL)

| Priority | Component | Action Required | Est. Hours |
|----------|-----------|-----------------|------------|
| 1 | transport-form.component.ts | Move HTTP calls to TransportService | 2-3 |
| 2 | fees-list.component.ts | Move HTTP calls to FeesService | 2-3 |
| 3 | forgot-password.component.ts | Move HTTP calls to AuthService | 1 |
| 4 | reset-password.component.ts | Move HTTP calls to AuthService | 1 |
| 5 | designation-form.component.ts | Create DesignationService, move HTTP calls | 2-3 |
| 6 | department-form.component.ts | Create DepartmentService, move HTTP calls | 2-3 |
| **Phase B Total** | | | **10-14** |

### Phase C: Complete Missing Integrations (MEDIUM)

| Priority | Service | TODO Item | Action Required | Est. Hours |
|----------|---------|-----------|-----------------|------------|
| 1 | TransportService | Notification/Audit integration | Add service calls | 2 |
| 2 | HostelService | Notification/Audit integration | Add service calls | 2 |
| 3 | FeesService | Notification/Audit integration | Add service calls | 2 |
| 4 | AcademicService | Notification/Audit integration | Add service calls | 2 |
| **Phase C Total** | | | | **8** |

### Phase D: Code Quality Improvements (LOW)

| Task | Description | Impact | Est. Hours |
|------|-------------|--------|------------|
| Remove unused imports | Clean up all component imports | Low | 4-6 |
| Add proper error handling | Implement global error handler | Medium | 3-4 |
| Add loading states | Consistent loading indicators | Medium | 4-6 |
| Remove console.logs | Clean up debug statements | Low | 2-3 |
| Update deprecated APIs | Replace deprecated Angular APIs | Medium | 3-4 |
| **Phase D Total** | | | **16-23** |

---

## Phase Progress Dashboard

```
Phase A: ░░░░░░░░░░░░░░░░░░░░   0% ⚠️ (Consolidate duplicate services)
Phase B: ░░░░░░░░░░░░░░░░░░░░   0% ⚠️ (Remove direct HttpClient)
Phase C: ░░░░░░░░░░░░░░░░░░░░   0% ⚠️ (Complete missing integrations)
Phase D: ░░░░░░░░░░░░░░░░░░░░   0% ⚠️ (Code quality improvements)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Overall: ░░░░░░░░░░░░░░░░░░░░   0% ⚠️
```

---

## Recommended Service Architecture

### Target Structure

```
src/app/
├── core/
│   └── services/
│       ├── api.service.ts          (Central API wrapper)
│       ├── auth.service.ts         (Authentication)
│       ├── permission.service.ts   (Authorization)
│       └── error-handler.service.ts (Global error handling)
├── services/
│   ├── student.service.ts          (Student CRUD)
│   ├── staff.service.ts            (Staff CRUD)
│   ├── fees.service.ts             (All fee operations)
│   ├── academic.service.ts         (Academic operations)
│   ├── transport.service.ts        (Transport operations)
│   ├── communication.service.ts    (Messages, Events, Announcements)
│   ├── library.service.ts          (Library & Inventory)
│   ├── notification.service.ts     (Notifications)
│   └── master-data.service.ts      (Lookup data)
└── shared/
    └── services/
        ├── theme.service.ts        (UI theming)
        ├── sidebar.service.ts      (Navigation)
        └── academic-year-context.service.ts (Year context)
```

### Base Service Pattern

```typescript
// Recommended: Use inject() pattern (modern Angular)
@Injectable({ providedIn: 'root' })
export class ExampleService {
  private http = inject(HttpClient);
  private errorHandler = inject(ApiErrorHandlerService);
  
  getAll(): Observable<Entity[]> {
    return this.http.get<Entity[]>('/api/entities').pipe(
      catchError(error => this.errorHandler.handle(error))
    );
  }
}
```

---

## Migration Pattern

### Step 1: Identify Duplicate Services
```bash
# Search for duplicate class names
grep -r "export class.*Service" src/app/
```

### Step 2: Consolidate to Single Service
```typescript
// Before: Multiple implementations
// services/master-data.service.ts
// core/services/master-data.service.ts

// After: Single implementation in core/services/
@Injectable({ providedIn: 'root' })
export class MasterDataService {
  private http = inject(HttpClient);
  // ... all methods
}
```

### Step 3: Remove HttpClient from Components
```typescript
// Before: Direct HttpClient in component
export class MyComponent {
  constructor(private http: HttpClient) {}
  
  save() {
    this.http.post('/api/data', this.data).subscribe();
  }
}

// After: Use service
export class MyComponent {
  private dataService = inject(DataService);
  
  save() {
    this.dataService.create(this.data).subscribe();
  }
}
```

### Step 4: Update Imports
```typescript
// Update all imports to use consolidated service
import { MasterDataService } from '@core/services/master-data.service';
```

---

## Final Metrics

| Metric | Current | Target | Improvement |
|--------|---------|--------|-------------|
| **Total Services** | 61 | ~30 | -50% |
| **Duplicate Services** | 5+ | 0 | -100% |
| **Direct HttpClient in Components** | 8+ | 0 | -100% |
| **Missing Integrations** | 4 | 0 | -100% |
| **TODO Comments** | 8+ | 0 | -100% |
| **Estimated Hours to Complete** | - | 48-64 | - |

---

## Conclusion

The frontend codebase has **significant refactoring needs** similar to the backend:

### Critical Issues Found:
1. **5+ duplicate services** causing confusion and maintenance issues
2. **8+ components** directly using HttpClient instead of services
3. **4 services** with missing notification/audit integrations
4. **8+ TODO comments** indicating incomplete features
5. **Inconsistent patterns** (inject() vs constructor)

### Phases to Complete:
1. **Phase A (HIGH)**: Consolidate duplicate services (14-19 hours)
2. **Phase B (CRITICAL)**: Remove direct HttpClient from components (10-14 hours)
3. **Phase C (MEDIUM)**: Complete missing integrations (8 hours)
4. **Phase D (LOW)**: Code quality improvements (16-23 hours)

### Total Estimated Hours: 48-64 hours

### Target Architecture:
```
✅ Current: Scattered services, direct HttpClient usage
🎯 Target: Centralized services, consistent patterns, no direct HTTP in components
```

---

*Document Version: 1.0*
*Last Updated: July 14, 2026*
*Author: Buffy (AI Assistant)*
*Status: ⚠️ AUDIT COMPLETE - 48-64 hours of refactoring needed*