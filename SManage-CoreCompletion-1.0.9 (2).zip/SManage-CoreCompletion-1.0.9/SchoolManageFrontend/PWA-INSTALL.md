# SchoolWala PWA — iPhone & Android Home-Screen Install

The web app already ships as a Progressive Web App: a web-app manifest
(`src/manifest.webmanifest`), Angular's service worker (`ngsw-config.json` →
`ngsw-worker.js`, registered in `app.config.ts` with auto-update on new
versions), and Apple-specific meta tags in `index.html`. The home-screen
name is **SchoolWala** with the existing favicon icon set.

## Install on iPhone (works today, no app store, no Mac)

1. Open **http://schoolwala.runasp.net/** in **Safari** (must be Safari).
2. Sign in once — the session cookie persists in the home-screen app.
3. Tap the **Share** button (⬆️) → **Add to Home Screen**.
4. Name is pre-filled as **SchoolWala** → tap **Add**.

You now get an icon that opens the site full-screen (no Safari address bar,
`standalone` display, status bar blends via `black-translucent`). Works on
iOS 12+; on iOS 16.4+ Safari may also offer **Add to Home Screen** from the
Share menu automatically since the manifest is present.

## Limitations — what requires the server's attention

- **The service worker will not register over plain HTTP.** Browsers only
  allow service workers on **HTTPS** (or localhost). The site currently has
  no TLS (`https://schoolwala.runasp.net/` fails), so:
  - iOS **Add to Home Screen** still works fine (it does not require a
    service worker — just the manifest link + tags, both present).
  - But there is **no offline shell, no background version-update prompt,**
    and Android Chrome will not show the "install app" prompt until HTTPS
    is enabled. When HTTPS lives on the host, everything switches on with
    **zero code changes** (the worker is already built and registered).

## What the service worker does (once HTTPS is on)

| Behavior | Config |
|---|---|
| App shell + JS/CSS prefetched and versioned | `ngsw-config.json` assetGroups |
| Fonts/avatars cached | `urls` in the app-shell group |
| API requests never cached blindly | `/api/**` uses `freshness` with a short timeout, so stale data is only served if the network is down; most endpoint data is never cached (students, staff, fees stay server-authoritative) |
| New app versions auto-activate | `app.config.ts` `SwUpdate` → activate + reload on `VERSION_READY` |
| Dev mode excluded | `enabled: !isDevMode()` |

## Deploy checklist (after editing `src/manifest.webmanifest` or `index.html`)

```bash
cd SchoolManageFrontend
npx ng build          # → dist/FrontendProject/browser/ (includes ngsw-worker.js + ngsw.json)
```

Copy the contents of `dist/FrontendProject/browser/` to wherever the static
site is served (wwwroot or your static host). Both `manifest.webmanifest`
and `ngsw-worker.js`/`ngsw.json` must be present at the web root.

> Note: because the Angular service worker caches `index.html`, after each
> deploy users may need one refresh (or rely on the auto-reload logic already
> in `app.config.ts`).
