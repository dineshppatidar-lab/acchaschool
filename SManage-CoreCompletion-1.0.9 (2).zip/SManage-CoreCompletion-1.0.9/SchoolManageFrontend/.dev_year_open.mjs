// Open academic-year select via keyboard focus + Enter, verify panel.
const list = await (await fetch('http://127.0.0.1:9229/json/list')).json();
const t = list.find(x => x.type === 'page' && x.url.includes('localhost:4210'));
const ws = new WebSocket(t.webSocketDebuggerUrl);
await new Promise((r, j) => { ws.onopen = r; ws.onerror = j; });
let id = 0; const pend = new Map();
ws.onmessage = ev => { const m = JSON.parse(ev.data); if (m.id && pend.has(m.id)) { pend.get(m.id)(m); pend.delete(m.id); } };
const rp = (m, p) => new Promise(r => { const i = ++id; pend.set(i, r); ws.send(JSON.stringify({ id: i, method: m, params: p || {} })); });
const ev = async e => { const r = await rp('Runtime.evaluate', { expression: e, returnByValue: true, awaitPromise: true }); return r.result?.result?.value; };
await rp('Runtime.enable');

const result = await ev(`(function(){
  return new Promise((resolve) => {
    const sel=document.querySelector('.app-header .academic-year-chip mat-select');
    if(!sel) { resolve(JSON.stringify({err:'no select'})); return; }
    sel.focus();
    setTimeout(() => {
      // Option count inside the trigger's own DOM is not rendered until open;
      // press Enter (Material handles keyboard open).
      sel.dispatchEvent(new KeyboardEvent('keydown',{key:'Enter',bubbles:true}));
      setTimeout(() => {
        const panel=document.querySelector('.mat-mdc-select-panel, .cdk-overlay-pane');
        if(!panel){ resolve(JSON.stringify({open:false, focused:document.activeElement?.tagName})); return; }
        const opts=panel.querySelectorAll('mat-option');
        const cs=getComputedStyle(panel);
        const sel0=panel.querySelector('mat-option.mat-mdc-option-active, mat-option.mat-selected');
        resolve(JSON.stringify({open:true,optionCount:opts.length,options:[...opts].map(o=>o.textContent.trim()).slice(0,5),bg:cs.backgroundColor,color:cs.color,activeLabel:sel0?.textContent.trim()}));
      }, 1200);
    }, 300);
  });
})()`);
console.log('YEAR PANEL:', result);

// Close: Escape without selecting.
await ev(`(function(){ document.body.dispatchEvent(new KeyboardEvent('keydown',{key:'Escape',bubbles:true})); return 'ok'; })()`);
const { writeFileSync } = await import('node:fs');
ws.close(); process.exit(0);
