// Dark-mode header check + academic-year dropdown usability + notif menu.
const BASE = 'http://localhost:4210';
const list = await (await fetch('http://127.0.0.1:9229/json/list')).json();
const t = list.find(x => x.type === 'page' && x.url.includes('localhost:4210'));
const ws = new WebSocket(t.webSocketDebuggerUrl);
await new Promise((r, j) => { ws.onopen = r; ws.onerror = j; });
let id = 0; const pend = new Map();
ws.onmessage = ev => { const m = JSON.parse(ev.data); if (m.id && pend.has(m.id)) { pend.get(m.id)(m); pend.delete(m.id); } };
const rp = (m, p) => new Promise(r => { const i = ++id; pend.set(i, r); ws.send(JSON.stringify({ id: i, method: m, params: p || {} })); });
const ev = async e => { const r = await rp('Runtime.evaluate', { expression: e, returnByValue: true, awaitPromise: true }); return r.result?.result?.value; };
await rp('Page.enable'); await rp('Runtime.enable');
const { writeFileSync } = await import('node:fs');

// Force app theme dark for this session.
await ev(`(function(){ localStorage.setItem('edusphere_theme','dark'); localStorage.setItem('theme','dark'); return 'ok'; })()`);

// Mobile viewport + fee form in dark mode.
await rp('Emulation.setDeviceMetricsOverride', { width: 390, height: 844, deviceScaleFactor: 2, mobile: true });
await rp('Page.navigate', { url: BASE + '/app/fees/form' });
await new Promise(r => setTimeout(r, 7000));
const dark = await ev(`(function(){
  const out={theme:localStorage.getItem('edusphere_theme'), scheme:getComputedStyle(document.body).colorScheme};
  const title=document.querySelector('.app-header .header-title');
  out.titleColor=title?getComputedStyle(title).color:null;
  out.iconColor=(()=>{const i=document.querySelector('.app-header .nav-toggle-btn mat-icon');return i?getComputedStyle(i).color:null})();
  out.title=title?.textContent.trim();
  return JSON.stringify(out);
})()`);
console.log('DARK header:', dark);
const s1 = await rp('Page.captureScreenshot', { format: 'png' });
writeFileSync('.freebuff/dark-check/hdr-dark-fee-form.png', Buffer.from(s1.result.data, 'base64'));

// Academic year dropdown: open it and count options in the overlay.
const opened = await ev(`(function(){
  try {
    const sel=document.querySelector('.app-header .academic-year-chip mat-select');
    if(!sel) return JSON.stringify({err:'no select'});
    sel.click();
    return 'ok';
  } catch(e) { return JSON.stringify({err:e.message}); }
})()`);
await new Promise(r => setTimeout(r, 1200));
const panel = await ev(`(function(){
  const pane=document.querySelector('.cdk-overlay-pane');
  if(!pane) return JSON.stringify({open:false});
  const opts=pane.querySelectorAll('mat-option');
  const cs=getComputedStyle(pane);
  return JSON.stringify({open:true,optionCount:opts.length,firstText:opts[0]?.textContent.trim(),bg:cs.backgroundColor,color:cs.color});
})()`);
console.log('YEAR DROPDOWN after open:', opened, panel);
const s2 = await rp('Page.captureScreenshot', { format: 'png' });
writeFileSync('.freebuff/dark-check/hdr-dark-year-open.png', Buffer.from(s2.result.data, 'base64'));
// Close without changing selection.
await ev(`(function(){ document.body.dispatchEvent(new KeyboardEvent('keydown',{key:'Escape',bubbles:true})); const b=document.querySelector('.cdk-overlay-backdrop'); if(b) b.dispatchEvent(new MouseEvent('mousedown',{bubbles:true})); return 'escaped'; })()`);
await new Promise(r => setTimeout(r, 600));

// Notifications menu opens.
await ev(`(function(){ document.querySelector('.app-header .notif-trigger')?.click(); return 'ok'; })()`);
await new Promise(r => setTimeout(r, 1200));
const notif = await ev(`(function(){
  const pane=document.querySelector('.notif-menu-panel, .cdk-overlay-pane');
  return JSON.stringify({open:!!pane, visible:!!(pane&&pane.offsetHeight)});
})()`);
console.log('NOTIF MENU:', notif);
await ev(`(function(){ const b=document.querySelector('.cdk-overlay-backdrop'); if(b) b.dispatchEvent(new MouseEvent('mousedown',{bubbles:true})); return 'ok'; })()`);
await new Promise(r => setTimeout(r, 500));
const s3 = await rp('Page.captureScreenshot', { format: 'png' });
writeFileSync('.freebuff/dark-check/hdr-dark-notif.png', Buffer.from(s3.result.data, 'base64'));

// Restore desktop + light theme for the user.
await rp('Emulation.clearDeviceMetricsOverride');
ws.close(); process.exit(0);
