# FrontendProject

This project was generated using [Angular CLI](https://github.com/angular/angular-cli) version 20.0.5.

## Development server

To start a local development server, run:

```bash
ng serve
```

Once the server is running, open your browser and navigate to `http://localhost:4200/`. The application will automatically reload whenever you modify any of the source files.

## Code scaffolding

Angular CLI includes powerful code scaffolding tools. To generate a new component, run:

```bash
ng generate component component-name
```

For a complete list of available schematics (such as `components`, `directives`, or `pipes`), run:

```bash
ng generate --help
```

## Building

To build the project run:

```bash
ng build
```

This will compile your project and store the build artifacts in the `dist/` directory. By default, the production build optimizes your application for performance and speed.

## Running unit tests

To execute unit tests with the [Karma](https://karma-runner.github.io) test runner, use the following command:

```bash
ng test
```

## Running end-to-end tests

For end-to-end (e2e) testing, run:

```bash
ng e2e
```

Angular CLI does not come with an end-to-end testing framework by default. You can choose one that suits your needs.

## Additional Resources

For more information on using the Angular CLI, including detailed command references, visit the [Angular CLI Overview and Command Reference](https://angular.dev/tools/cli) page.
-----------------------

Delete all fees module realted data.
--------------
BEGIN TRANSACTION;

DELETE FROM dbo.GroupPaymentAllocations;
DELETE FROM dbo.GroupPayments;

DELETE FROM dbo.FeePayments;
DELETE FROM dbo.FeeInstallments;

DELETE FROM dbo.StudentFeeAssignments;
DELETE FROM dbo.StudentFeeAdjustments;
DELETE FROM dbo.StudentLedgers;
DELETE FROM dbo.FeeNotificationLogs;
DELETE FROM dbo.FinanceAuditLogs;
DELETE FROM dbo.FeeRules;
DELETE FROM dbo.MultiInstallmentPayments;

DELETE FROM [dbo].[FamilyGroupMember];
DELETE FROM [dbo].[FamilyGroup]

DELETE FROM dbo.FeeStructures;

DELETE FROM dbo.Fees;

COMMIT;
---------------
===========---------------------------------
---------------Manu specific code-------------------

--SELECT * FROM dbo.MenuItems

--update dbo.MenuItems set isactive =0 where id=67 --Attendance
--update dbo.MenuItems set isactive =0 where id=68 --Fee Dashboard
--update dbo.MenuItems set isactive =0 where id=71 --Fee Waivers
--update dbo.MenuItems set isactive =0 where id=76 --Finance Reports
--------------------------------------------
ALTER TABLE [dbo].[FeePayments] 
ALTER COLUMN [CollectedByStaffId] int NULL;
-------
