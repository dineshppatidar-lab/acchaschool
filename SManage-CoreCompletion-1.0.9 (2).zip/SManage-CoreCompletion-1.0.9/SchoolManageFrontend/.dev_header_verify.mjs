// Verify the dynamic mobile header: scenario B (root), C/D (nested),
// E (back restores hamburger), F (widths) and desktop non-regression.
const BASE = 'http://localhost:4210';
const list = await (await fetch('http://127.0.0.1:9229/json/list')).json();
const t = list.find(x => x.type === 'page' && x.url.includes('localhost:4210')) ?? list.find(x => x.type === 'page');
const ws = new WebSocket(t.webSocketDebuggerUrl);
await new Promise((r, j) => { ws.onopen = r; ws.onerror = j; });
let id = 0; const pend = new Map();
ws.onmessage = ev => { const m = JSON.parse(ev.data); if (m.id && pend.has(m.id)) { pend.get(m.id)(m); pend.delete(m.id); } };
const rp = (m, p) => new Promise(r => { const i = ++id; pend.set(i, r); ws.send(JSON.stringify({ id: i, method: m, params: p || {} })); });
const ev = async e => { const r = await rp('Runtime.evaluate', { expression: e, returnByValue: true, awaitPromise: true }); return r.result?.result?.value; };
await rp('Page.enable'); await rp('Runtime.enable');

const { writeFileSync } = await import('node:fs');
const PROBE = `(function(){
  const out={url:location.pathname};
  const btn=document.querySelector('.app-header .nav-toggle-btn');
  const title=document.querySelector('.app-header .header-title');
  const chip=document.querySelector('.app-header .academic-year-chip');
  const notif=document.querySelector('.app-header .notif-trigger');
  const avatar=document.querySelector('.app-header .avatar-btn');
  out.icon=btn?btn.querySelector('mat-icon')?.textContent.trim():null;
  out.title=title&&!getComputedStyle(title).display.startsWith('none')?title.textContent.trim():null;
  out.chipVisible=!!chip&&!getComputedStyle(chip).display.startsWith('none');
  out.chipValue=chip?(chip.querySelector('mat-select')?.textContent.trim()||'(no options map)'):null;
  out.notif=!!notif; out.avatar=!!avatar;
  const doc=document.scrollingElement||document.documentElement;
  out.hOverflow=doc.scrollWidth-doc.clientWidth;
  out.width=innerWidth;
  return JSON.stringify(out);
})()`;
const shot = async name => { const s = await rp('Page.captureScreenshot', { format: 'png' }); writeFileSync(`.freebuff/dark-check/${name}.png`, Buffer.from(s.result.data, 'base64')); };
const go = async (url, wait) => { await rp('Page.navigate', { url: BASE + url }); await new Promise(r => setTimeout(r, wait)); };

// ── Test A: desktop untouched ──
await rp('Emulation.clearDeviceMetricsOverride');
await go('/app/students/full-details', 7000);
console.log('A-DESKTOP students:', await ev(PROBE));
await shot('hdr-A-desktop-students');

// ── Mobile emulation 390×844 ──
await rp('Emulation.setDeviceMetricsOverride', { width: 390, height: 844, deviceScaleFactor: 2, mobile: true });

// Test B: root page
await go('/app/students/full-details', 7000);
console.log('B-MOBILE root:', await ev(PROBE));
await shot('hdr-B-mobile-students');

// Test C: nested page
await go('/app/students/admissions', 7000);
console.log('C-MOBILE admission:', await ev(PROBE));
await shot('hdr-C-mobile-admission');

// Test D: Collect Fee Payment
await go('/app/fees/form', 7000);
console.log('D-MOBILE collect fee:', await ev(PROBE));
await shot('hdr-D-mobile-fee-form');

// Test E: in-app back — go list → (in-app click Add Fee Record) → form → click back
await go('/app/fees/list', 7000);
const clicked = await ev(`(function(){
  const b=[...document.querySelectorAll('button,a')].find(x=>x.textContent.trim().match(/Add Fee Record|New Fee Record/));
  if(b){b.click();return 'clicked';} return 'not found';
})()`);
await new Promise(r => setTimeout(r, 6000));
const before = await ev(PROBE);
console.log('E-before (expect back arrow):', before);
const backClicked = await ev(`(function(){ const b=document.querySelector('.app-header .nav-toggle-btn'); if(b){b.click();return 'back clicked';} return 'no btn'; })()`);
await new Promise(r => setTimeout(r, 5000));
const after = await ev(PROBE);
console.log('E-back click:', backClicked, '→ (expect menu + fees list):', after);
await shot('hdr-E-mobile-back');

// Test F: widths — 320 narrow, 700 large phone, tablet 800
for (const w of [320, 480, 700, 800]) {
  await rp('Emulation.setDeviceMetricsOverride', { width: w, height: 844, deviceScaleFactor: 2, mobile: w < 700 });
  await go('/app/fees/list', 5000);
  console.log(`F-${w}px:`, await ev(PROBE));
}

// Desktop restore
await rp('Emulation.clearDeviceMetricsOverride');
ws.close(); process.exit(0);
