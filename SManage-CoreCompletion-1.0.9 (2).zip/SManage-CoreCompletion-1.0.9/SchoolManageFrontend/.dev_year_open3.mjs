// Trusted-key open of the year select and option verification.
const list = await (await fetch('http://127.0.0.1:9229/json/list')).json();
const t = list.find(x => x.type === 'page' && x.url.includes('localhost:4210'));
const ws = new WebSocket(t.webSocketDebuggerUrl);
await new Promise((r, j) => { ws.onopen = r; ws.onerror = j; });
let id = 0; const pend = new Map();
ws.onmessage = ev => { const m = JSON.parse(ev.data); if (m.id && pend.has(m.id)) { pend.get(m.id)(m); pend.delete(m.id); } };
const rp = (m, p) => new Promise(r => { const i = ++id; pend.set(i, r); ws.send(JSON.stringify({ id: i, method: m, params: p || {} })); });
const ev = async e => { const r = await rp('Runtime.evaluate', { expression: e, returnByValue: true, awaitPromise: true }); return r.result?.result?.value; };
await rp('Runtime.enable'); await rp('Page.enable');

// Close any lingering overlays, then focus the select trigger.
await ev(`(function(){
  document.querySelectorAll('.cdk-overlay-backdrop').forEach(b=>b.click());
  const sel=document.querySelector('.app-header .academic-year-chip mat-select');
  if(sel){ sel.focus(); return 'focused'; } return 'none';
})()`);
await new Promise(r => setTimeout(r, 800));

// Trusted Enter.
await rp('Input.dispatchKeyEvent', { type: 'keyDown', key: 'Enter', code: 'Enter', windowsVirtualKeyCode: 13 });
await rp('Input.dispatchKeyEvent', { type: 'keyUp', key: 'Enter', code: 'Enter', windowsVirtualKeyCode: 13 });
await new Promise(r => setTimeout(r, 1200));

const out = await ev(`(function(){
  const panel=document.querySelector('.mat-mdc-select-panel');
  if(!panel) return JSON.stringify({open:false});
  const opts=[...panel.querySelectorAll('.mat-mdc-option')];
  const cs=getComputedStyle(panel);
  const active=panel.querySelector('.mat-mdc-option-active');
  return JSON.stringify({open:true,optionCount:opts.length,options:opts.map(o=>o.textContent.trim()).slice(0,6),bg:cs.backgroundColor,textColor:cs.color,active:active?.textContent.trim(),overlayBg:(()=>{const p=panel.closest('.cdk-overlay-pane');return p?getComputedStyle(p).backgroundColor:null})()});
})()`);
console.log('YEAR PANEL:', out);
const s = await rp('Page.captureScreenshot', { format: 'png' });
const { writeFileSync } = await import('node:fs');
writeFileSync('.freebuff/dark-check/hdr-dark-year-open.png', Buffer.from(s.result.data, 'base64'));

// Close with trusted Escape (no selection change).
await rp('Input.dispatchKeyEvent', { type: 'keyDown', key: 'Escape', code: 'Escape', windowsVirtualKeyCode: 27 });
await rp('Input.dispatchKeyEvent', { type: 'keyUp', key: 'Escape', code: 'Escape', windowsVirtualKeyCode: 27 });
const still = await ev(`(function(){
  const sel=document.querySelector('.app-header .academic-year-chip mat-select');
  return JSON.stringify({panelGone:!document.querySelector('.mat-mdc-select-panel'), value:sel?.textContent.trim()});
})()`);
console.log('AFTER ESCAPE:', still);
ws.close(); process.exit(0);
